NAME          HS35MOD
ROWS
  N OBJ.FUNC
  G R------1
COLUMNS
    C------1  OBJ.FUNC  -.800000e+01   R------1  -.100000e+01
    C------2  OBJ.FUNC  -.600000e+01   R------1  -.100000e+01
    C------3  OBJ.FUNC  -.400000e+01   R------1  -.200000e+01
RHS
    RHS       OBJ.FUNC  -.900000e+01
    RHS       R------1  -.300000e+01
RANGES
BOUNDS
 FX BOUNDS    C------2  0.500000e+00
QUADOBJ
    C------1  C------1  0.400000e+01
    C------1  C------2  0.200000e+01
    C------1  C------3  0.200000e+01
    C------2  C------2  0.400000e+01
    C------3  C------3  0.200000e+01
ENDATA
