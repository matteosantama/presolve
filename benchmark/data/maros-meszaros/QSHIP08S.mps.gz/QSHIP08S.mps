NAME          SHIP08S
ROWS
 N  COST
 G  REGMIN
 L  REGMAX
 G  OVRMIN
 L  OVRMAX
 G  REGMIN01
 G  REGMIN02
 E  REGMIN03
 G  REGMIN04
 E  REGMIN05
 E  REGMIN06
 E  REGMIN07
 E  REGMIN08
 L  REGMAX01
 L  REGMAX02
 L  REGMAX04
 G  OVRMIN01
 G  OVRMIN02
 E  OVRMIN03
 G  OVRMIN04
 E  OVRMIN05
 E  OVRMIN06
 E  OVRMIN07
 E  OVRMIN08
 L  OVRMAX01
 L  OVRMAX02
 L  OVRMAX04
 L  TRAN0101
 L  TRAN0102
 L  TRAN0103
 L  TRAN0104
 L  TRAN0105
 L  TRAN0106
 L  TRAN0107
 L  TRAN0108
 L  TRAN0201
 L  TRAN0202
 L  TRAN0203
 L  TRAN0204
 L  TRAN0205
 L  TRAN0206
 L  TRAN0207
 L  TRAN0208
 L  TRAN0301
 L  TRAN0302
 L  TRAN0303
 L  TRAN0304
 L  TRAN0305
 L  TRAN0306
 L  TRAN0307
 L  TRAN0308
 L  TRAN0401
 L  TRAN0402
 L  TRAN0403
 L  TRAN0404
 L  TRAN0405
 L  TRAN0406
 L  TRAN0407
 L  TRAN0408
 L  TRAN0501
 L  TRAN0502
 L  TRAN0503
 L  TRAN0504
 L  TRAN0505
 L  TRAN0506
 L  TRAN0507
 L  TRAN0508
 L  TRAN0601
 L  TRAN0602
 L  TRAN0603
 L  TRAN0604
 L  TRAN0605
 L  TRAN0606
 L  TRAN0607
 L  TRAN0608
 L  TRAN0701
 L  TRAN0702
 L  TRAN0703
 L  TRAN0704
 L  TRAN0705
 L  TRAN0706
 L  TRAN0707
 L  TRAN0708
 L  TRAN0801
 L  TRAN0802
 L  TRAN0803
 L  TRAN0804
 L  TRAN0805
 L  TRAN0806
 L  TRAN0807
 L  TRAN0808
 E  BAL0101
 E  BAL0102
 E  BAL0103
 E  BAL0104
 E  BAL0105
 E  BAL0106
 E  BAL0107
 E  BAL0108
 E  BAL0109
 E  BAL0110
 E  BAL0111
 E  BAL0112
 E  BAL0113
 E  BAL0114
 E  BAL0115
 E  BAL0116
 E  BAL0117
 E  BAL0118
 E  BAL0119
 E  BAL0120
 E  BAL0121
 E  BAL0122
 E  BAL0123
 E  BAL0124
 E  BAL0125
 E  BAL0126
 E  BAL0127
 E  BAL0128
 E  BAL0129
 E  BAL0130
 E  BAL0131
 E  BAL0132
 E  BAL0133
 E  BAL0134
 E  BAL0135
 E  BAL0136
 E  BAL0137
 E  BAL0138
 E  BAL0139
 E  BAL0140
 E  BAL0141
 E  BAL0142
 E  BAL0143
 E  BAL0144
 E  BAL0145
 E  BAL0146
 E  BAL0147
 E  BAL0148
 E  BAL0149
 E  BAL0150
 E  BAL0151
 E  BAL0152
 E  BAL0153
 E  BAL0154
 E  BAL0155
 E  BAL0156
 E  BAL0157
 E  BAL0158
 E  BAL0159
 E  BAL0160
 E  BAL0161
 E  BAL0162
 E  BAL0163
 E  BAL0164
 E  BAL0165
 E  BAL0166
 E  BAL0167
 E  BAL0168
 E  BAL0169
 E  BAL0170
 E  BAL0171
 E  BAL0172
 E  BAL0173
 E  BAL0174
 E  BAL0175
 E  BAL0176
 E  BAL0177
 E  BAL0178
 E  BAL0179
 E  BAL0180
 E  BAL0181
 E  BAL0182
 E  BAL0183
 E  BAL0184
 E  BAL0185
 E  BAL0186
 E  BAL0201
 E  BAL0202
 E  BAL0203
 E  BAL0204
 E  BAL0205
 E  BAL0206
 E  BAL0207
 E  BAL0208
 E  BAL0209
 E  BAL0210
 E  BAL0211
 E  BAL0212
 E  BAL0213
 E  BAL0214
 E  BAL0215
 E  BAL0216
 E  BAL0217
 E  BAL0218
 E  BAL0219
 E  BAL0220
 E  BAL0221
 E  BAL0222
 E  BAL0223
 E  BAL0224
 E  BAL0225
 E  BAL0226
 E  BAL0227
 E  BAL0228
 E  BAL0229
 E  BAL0230
 E  BAL0231
 E  BAL0232
 E  BAL0233
 E  BAL0234
 E  BAL0235
 E  BAL0236
 E  BAL0237
 E  BAL0238
 E  BAL0239
 E  BAL0240
 E  BAL0241
 E  BAL0242
 E  BAL0243
 E  BAL0244
 E  BAL0245
 E  BAL0246
 E  BAL0247
 E  BAL0248
 E  BAL0249
 E  BAL0250
 E  BAL0251
 E  BAL0252
 E  BAL0253
 E  BAL0254
 E  BAL0255
 E  BAL0256
 E  BAL0257
 E  BAL0258
 E  BAL0259
 E  BAL0260
 E  BAL0261
 E  BAL0262
 E  BAL0263
 E  BAL0264
 E  BAL0265
 E  BAL0266
 E  BAL0267
 E  BAL0268
 E  BAL0269
 E  BAL0270
 E  BAL0271
 E  BAL0272
 E  BAL0273
 E  BAL0274
 E  BAL0275
 E  BAL0276
 E  BAL0277
 E  BAL0278
 E  BAL0279
 E  BAL0280
 E  BAL0281
 E  BAL0282
 E  BAL0283
 E  BAL0284
 E  BAL0285
 E  BAL0286
 E  BAL0301
 E  BAL0302
 E  BAL0303
 E  BAL0304
 E  BAL0305
 E  BAL0306
 E  BAL0307
 E  BAL0308
 E  BAL0309
 E  BAL0310
 E  BAL0311
 E  BAL0312
 E  BAL0313
 E  BAL0314
 E  BAL0315
 E  BAL0316
 E  BAL0317
 E  BAL0318
 E  BAL0319
 E  BAL0320
 E  BAL0321
 E  BAL0322
 E  BAL0323
 E  BAL0324
 E  BAL0325
 E  BAL0326
 E  BAL0327
 E  BAL0328
 E  BAL0329
 E  BAL0330
 E  BAL0331
 E  BAL0332
 E  BAL0333
 E  BAL0334
 E  BAL0335
 E  BAL0336
 E  BAL0337
 E  BAL0338
 E  BAL0339
 E  BAL0340
 E  BAL0341
 E  BAL0342
 E  BAL0343
 E  BAL0344
 E  BAL0345
 E  BAL0346
 E  BAL0347
 E  BAL0348
 E  BAL0349
 E  BAL0350
 E  BAL0351
 E  BAL0352
 E  BAL0353
 E  BAL0354
 E  BAL0355
 E  BAL0356
 E  BAL0357
 E  BAL0358
 E  BAL0359
 E  BAL0360
 E  BAL0361
 E  BAL0362
 E  BAL0363
 E  BAL0364
 E  BAL0365
 E  BAL0366
 E  BAL0367
 E  BAL0368
 E  BAL0369
 E  BAL0370
 E  BAL0371
 E  BAL0372
 E  BAL0373
 E  BAL0374
 E  BAL0375
 E  BAL0376
 E  BAL0377
 E  BAL0378
 E  BAL0379
 E  BAL0380
 E  BAL0381
 E  BAL0382
 E  BAL0383
 E  BAL0384
 E  BAL0385
 E  BAL0386
 E  BAL0401
 E  BAL0402
 E  BAL0403
 E  BAL0404
 E  BAL0405
 E  BAL0406
 E  BAL0407
 E  BAL0408
 E  BAL0409
 E  BAL0410
 E  BAL0411
 E  BAL0412
 E  BAL0413
 E  BAL0414
 E  BAL0415
 E  BAL0416
 E  BAL0417
 E  BAL0418
 E  BAL0419
 E  BAL0420
 E  BAL0421
 E  BAL0422
 E  BAL0423
 E  BAL0424
 E  BAL0425
 E  BAL0426
 E  BAL0427
 E  BAL0428
 E  BAL0429
 E  BAL0430
 E  BAL0431
 E  BAL0432
 E  BAL0433
 E  BAL0434
 E  BAL0435
 E  BAL0436
 E  BAL0437
 E  BAL0438
 E  BAL0439
 E  BAL0440
 E  BAL0441
 E  BAL0442
 E  BAL0443
 E  BAL0444
 E  BAL0445
 E  BAL0446
 E  BAL0447
 E  BAL0448
 E  BAL0449
 E  BAL0450
 E  BAL0451
 E  BAL0452
 E  BAL0453
 E  BAL0454
 E  BAL0455
 E  BAL0456
 E  BAL0457
 E  BAL0458
 E  BAL0459
 E  BAL0460
 E  BAL0461
 E  BAL0462
 E  BAL0463
 E  BAL0464
 E  BAL0465
 E  BAL0466
 E  BAL0467
 E  BAL0468
 E  BAL0469
 E  BAL0470
 E  BAL0471
 E  BAL0472
 E  BAL0473
 E  BAL0474
 E  BAL0475
 E  BAL0476
 E  BAL0477
 E  BAL0478
 E  BAL0479
 E  BAL0480
 E  BAL0481
 E  BAL0482
 E  BAL0483
 E  BAL0484
 E  BAL0485
 E  BAL0486
 E  BAL0501
 E  BAL0502
 E  BAL0503
 E  BAL0504
 E  BAL0505
 E  BAL0506
 E  BAL0507
 E  BAL0508
 E  BAL0509
 E  BAL0510
 E  BAL0511
 E  BAL0512
 E  BAL0513
 E  BAL0514
 E  BAL0515
 E  BAL0516
 E  BAL0517
 E  BAL0518
 E  BAL0519
 E  BAL0520
 E  BAL0521
 E  BAL0522
 E  BAL0523
 E  BAL0524
 E  BAL0525
 E  BAL0526
 E  BAL0527
 E  BAL0528
 E  BAL0529
 E  BAL0530
 E  BAL0531
 E  BAL0532
 E  BAL0533
 E  BAL0534
 E  BAL0535
 E  BAL0536
 E  BAL0537
 E  BAL0538
 E  BAL0539
 E  BAL0540
 E  BAL0541
 E  BAL0542
 E  BAL0543
 E  BAL0544
 E  BAL0545
 E  BAL0546
 E  BAL0547
 E  BAL0548
 E  BAL0549
 E  BAL0550
 E  BAL0551
 E  BAL0552
 E  BAL0553
 E  BAL0554
 E  BAL0555
 E  BAL0556
 E  BAL0557
 E  BAL0558
 E  BAL0559
 E  BAL0560
 E  BAL0561
 E  BAL0562
 E  BAL0563
 E  BAL0564
 E  BAL0565
 E  BAL0566
 E  BAL0567
 E  BAL0568
 E  BAL0569
 E  BAL0570
 E  BAL0571
 E  BAL0572
 E  BAL0573
 E  BAL0574
 E  BAL0575
 E  BAL0576
 E  BAL0577
 E  BAL0578
 E  BAL0579
 E  BAL0580
 E  BAL0581
 E  BAL0582
 E  BAL0583
 E  BAL0584
 E  BAL0585
 E  BAL0586
 E  BAL0601
 E  BAL0602
 E  BAL0603
 E  BAL0604
 E  BAL0605
 E  BAL0606
 E  BAL0607
 E  BAL0608
 E  BAL0609
 E  BAL0610
 E  BAL0611
 E  BAL0612
 E  BAL0613
 E  BAL0614
 E  BAL0615
 E  BAL0616
 E  BAL0617
 E  BAL0618
 E  BAL0619
 E  BAL0620
 E  BAL0621
 E  BAL0622
 E  BAL0623
 E  BAL0624
 E  BAL0625
 E  BAL0626
 E  BAL0627
 E  BAL0628
 E  BAL0629
 E  BAL0630
 E  BAL0631
 E  BAL0632
 E  BAL0633
 E  BAL0634
 E  BAL0635
 E  BAL0636
 E  BAL0637
 E  BAL0638
 E  BAL0639
 E  BAL0640
 E  BAL0641
 E  BAL0642
 E  BAL0643
 E  BAL0644
 E  BAL0645
 E  BAL0646
 E  BAL0647
 E  BAL0648
 E  BAL0649
 E  BAL0650
 E  BAL0651
 E  BAL0652
 E  BAL0653
 E  BAL0654
 E  BAL0655
 E  BAL0656
 E  BAL0657
 E  BAL0658
 E  BAL0659
 E  BAL0660
 E  BAL0661
 E  BAL0662
 E  BAL0663
 E  BAL0664
 E  BAL0665
 E  BAL0666
 E  BAL0667
 E  BAL0668
 E  BAL0669
 E  BAL0670
 E  BAL0671
 E  BAL0672
 E  BAL0673
 E  BAL0674
 E  BAL0675
 E  BAL0676
 E  BAL0677
 E  BAL0678
 E  BAL0679
 E  BAL0680
 E  BAL0681
 E  BAL0682
 E  BAL0683
 E  BAL0684
 E  BAL0685
 E  BAL0686
 E  BAL0701
 E  BAL0702
 E  BAL0703
 E  BAL0704
 E  BAL0705
 E  BAL0706
 E  BAL0707
 E  BAL0708
 E  BAL0709
 E  BAL0710
 E  BAL0711
 E  BAL0712
 E  BAL0713
 E  BAL0714
 E  BAL0715
 E  BAL0716
 E  BAL0717
 E  BAL0718
 E  BAL0719
 E  BAL0720
 E  BAL0721
 E  BAL0722
 E  BAL0723
 E  BAL0724
 E  BAL0725
 E  BAL0726
 E  BAL0727
 E  BAL0728
 E  BAL0729
 E  BAL0730
 E  BAL0731
 E  BAL0732
 E  BAL0733
 E  BAL0734
 E  BAL0735
 E  BAL0736
 E  BAL0737
 E  BAL0738
 E  BAL0739
 E  BAL0740
 E  BAL0741
 E  BAL0742
 E  BAL0743
 E  BAL0744
 E  BAL0745
 E  BAL0746
 E  BAL0747
 E  BAL0748
 E  BAL0749
 E  BAL0750
 E  BAL0751
 E  BAL0752
 E  BAL0753
 E  BAL0754
 E  BAL0755
 E  BAL0756
 E  BAL0757
 E  BAL0758
 E  BAL0759
 E  BAL0760
 E  BAL0761
 E  BAL0762
 E  BAL0763
 E  BAL0764
 E  BAL0765
 E  BAL0766
 E  BAL0767
 E  BAL0768
 E  BAL0769
 E  BAL0770
 E  BAL0771
 E  BAL0772
 E  BAL0773
 E  BAL0774
 E  BAL0775
 E  BAL0776
 E  BAL0777
 E  BAL0778
 E  BAL0779
 E  BAL0780
 E  BAL0781
 E  BAL0782
 E  BAL0783
 E  BAL0784
 E  BAL0785
 E  BAL0786
 E  BAL0801
 E  BAL0802
 E  BAL0803
 E  BAL0804
 E  BAL0805
 E  BAL0806
 E  BAL0807
 E  BAL0808
 E  BAL0809
 E  BAL0810
 E  BAL0811
 E  BAL0812
 E  BAL0813
 E  BAL0814
 E  BAL0815
 E  BAL0816
 E  BAL0817
 E  BAL0818
 E  BAL0819
 E  BAL0820
 E  BAL0821
 E  BAL0822
 E  BAL0823
 E  BAL0824
 E  BAL0825
 E  BAL0826
 E  BAL0827
 E  BAL0828
 E  BAL0829
 E  BAL0830
 E  BAL0831
 E  BAL0832
 E  BAL0833
 E  BAL0834
 E  BAL0835
 E  BAL0836
 E  BAL0837
 E  BAL0838
 E  BAL0839
 E  BAL0840
 E  BAL0841
 E  BAL0842
 E  BAL0843
 E  BAL0844
 E  BAL0845
 E  BAL0846
 E  BAL0847
 E  BAL0848
 E  BAL0849
 E  BAL0850
 E  BAL0851
 E  BAL0852
 E  BAL0853
 E  BAL0854
 E  BAL0855
 E  BAL0856
 E  BAL0857
 E  BAL0858
 E  BAL0859
 E  BAL0860
 E  BAL0861
 E  BAL0862
 E  BAL0863
 E  BAL0864
 E  BAL0865
 E  BAL0866
 E  BAL0867
 E  BAL0868
 E  BAL0869
 E  BAL0870
 E  BAL0871
 E  BAL0872
 E  BAL0873
 E  BAL0874
 E  BAL0875
 E  BAL0876
 E  BAL0877
 E  BAL0878
 E  BAL0879
 E  BAL0880
 E  BAL0881
 E  BAL0882
 E  BAL0883
 E  BAL0884
 E  BAL0885
 E  BAL0886
COLUMNS
    PREG0101  COST             4862.   REGMIN        .0210855
    PREG0101  REGMAX        .0210855   REGMIN01      .0210855
    PREG0101  REGMAX01      .0210855   TRAN0101           -1.
    PREG0101  BAL0101             1.
    PREG0102  COST             4688.   REGMIN        .0175461
    PREG0102  REGMAX        .0175461   REGMIN01      .0175461
    PREG0102  REGMAX01      .0175461   TRAN0201           -1.
    PREG0102  BAL0201             1.
    PREG0103  COST             4872.   REGMIN        .0175461
    PREG0103  REGMAX        .0175461   REGMIN01      .0175461
    PREG0103  REGMAX01      .0175461   TRAN0301           -1.
    PREG0103  BAL0301             1.
    PREG0105  COST             4655.   REGMIN        .0175461
    PREG0105  REGMAX        .0175461   REGMIN01      .0175461
    PREG0105  REGMAX01      .0175461   TRAN0501           -1.
    PREG0105  BAL0501             1.
    PREG0202  COST             4196.   REGMIN        .0187961
    PREG0202  REGMAX        .0187961   REGMIN02      .0187961
    PREG0202  REGMAX02      .0187961   TRAN0202           -1.
    PREG0202  BAL0202             1.
    PREG0203  COST             4338.   REGMIN        .0328947
    PREG0203  REGMAX        .0328947   REGMIN02      .0328947
    PREG0203  REGMAX02      .0328947   TRAN0302           -1.
    PREG0203  BAL0302             1.
    PREG0205  COST             4283.   REGMIN        .0112105
    PREG0205  REGMAX        .0112105   REGMIN02      .0112105
    PREG0205  REGMAX02      .0112105   TRAN0502           -1.
    PREG0205  BAL0502             1.
    PREG0207  COST             4156.   REGMIN        .0131579
    PREG0207  REGMAX        .0131579   REGMIN02      .0131579
    PREG0207  REGMAX02      .0131579   TRAN0702           -1.
    PREG0207  BAL0702             1.
    PREG0401  COST             4691.   REGMIN        .0175461
    PREG0401  REGMAX        .0175461   REGMIN04      .0175461
    PREG0401  REGMAX04      .0175461   TRAN0104           -1.
    PREG0401  BAL0104             1.
    PREG0402  COST             4669.   REGMIN        .0181711
    PREG0402  REGMAX        .0181711   REGMIN04      .0181711
    PREG0402  REGMAX04      .0181711   TRAN0204           -1.
    PREG0402  BAL0204             1.
    PREG0404  COST             6724.   REGMIN        .0263158
    PREG0404  REGMAX        .0263158   REGMIN04      .0263158
    PREG0404  REGMAX04      .0263158   TRAN0404           -1.
    PREG0404  BAL0404             1.
    PREG0405  COST             4615.   REGMIN        .0181711
    PREG0405  REGMAX        .0181711   REGMIN04      .0181711
    PREG0405  REGMAX04      .0181711   TRAN0504           -1.
    PREG0405  BAL0504             1.
    PREG0406  COST             4148.   REGMIN        .0181711
    PREG0406  REGMAX        .0181711   REGMIN04      .0181711
    PREG0406  REGMAX04      .0181711   TRAN0604           -1.
    PREG0406  BAL0604             1.
    PREG0408  COST             6411.   REGMIN        .0239211
    PREG0408  REGMAX        .0239211   REGMIN04      .0239211
    PREG0408  REGMAX04      .0239211   TRAN0804           -1.
    PREG0408  BAL0804             1.
    POVR0101  COST             6552.   OVRMIN           3.205
    POVR0101  OVRMAX           3.205   OVRMIN01         3.205
    POVR0101  OVRMAX01         3.205   TRAN0101           -1.
    POVR0101  BAL0101             1.
    POVR0102  COST             6351.   OVRMIN           2.667
    POVR0102  OVRMAX           2.667   OVRMIN01         2.667
    POVR0102  OVRMAX01         2.667   TRAN0201           -1.
    POVR0102  BAL0201             1.
    POVR0103  COST             6554.   OVRMIN           2.667
    POVR0103  OVRMAX           2.667   OVRMIN01         2.667
    POVR0103  OVRMAX01         2.667   TRAN0301           -1.
    POVR0103  BAL0301             1.
    POVR0105  COST             6325.   OVRMIN           2.667
    POVR0105  OVRMAX           2.667   OVRMIN01         2.667
    POVR0105  OVRMAX01         2.667   TRAN0501           -1.
    POVR0105  BAL0501             1.
    POVR0202  COST             5756.   OVRMIN           2.857
    POVR0202  OVRMAX           2.857   OVRMIN02         2.857
    POVR0202  OVRMAX02         2.857   TRAN0202           -1.
    POVR0202  BAL0202             1.
    POVR0203  COST             6777.   OVRMIN              5.
    POVR0203  OVRMAX              5.   OVRMIN02            5.
    POVR0203  OVRMAX02            5.   TRAN0302           -1.
    POVR0203  BAL0302             1.
    POVR0205  COST             5844.   OVRMIN           1.704
    POVR0205  OVRMAX           1.704   OVRMIN02         1.704
    POVR0205  OVRMAX02         1.704   TRAN0502           -1.
    POVR0205  BAL0502             1.
    POVR0207  COST             5673.   OVRMIN              2.
    POVR0207  OVRMAX              2.   OVRMIN02            2.
    POVR0207  OVRMAX02            2.   TRAN0702           -1.
    POVR0207  BAL0702             1.
    POVR0401  COST             5794.   OVRMIN           2.667
    POVR0401  OVRMAX           2.667   OVRMIN04         2.667
    POVR0401  OVRMAX04         2.667   TRAN0104           -1.
    POVR0401  BAL0104             1.
    POVR0402  COST             5787.   OVRMIN           2.762
    POVR0402  OVRMAX           2.762   OVRMIN04         2.762
    POVR0402  OVRMAX04         2.762   TRAN0204           -1.
    POVR0402  BAL0204             1.
    POVR0404  COST             8111.   OVRMIN              4.
    POVR0404  OVRMAX              4.   OVRMIN04            4.
    POVR0404  OVRMAX04            4.   TRAN0404           -1.
    POVR0404  BAL0404             1.
    POVR0405  COST             5721.   OVRMIN           2.762
    POVR0405  OVRMAX           2.762   OVRMIN04         2.762
    POVR0405  OVRMAX04         2.762   TRAN0504           -1.
    POVR0405  BAL0504             1.
    POVR0406  COST             5303.   OVRMIN           2.762
    POVR0406  OVRMAX           2.762   OVRMIN04         2.762
    POVR0406  OVRMAX04         2.762   TRAN0604           -1.
    POVR0406  BAL0604             1.
    SH010201  COST            323.73   TRAN0102            1.
    SH010201  BAL0102            -1.   BAL0101             1.
    SH010301  COST            124.26   TRAN0103            1.
    SH010301  BAL0103            -1.   BAL0101             1.
    SH010401  COST            226.72   TRAN0104            1.
    SH010401  BAL0104            -1.   BAL0101             1.
    SH010501  COST            258.33   TRAN0105            1.
    SH010501  BAL0105            -1.   BAL0101             1.
    SH010601  COST            137.34   TRAN0106            1.
    SH010601  BAL0152            -1.   BAL0101             1.
    SH010801  COST            155.87   TRAN0108            1.
    SH010801  BAL0183            -1.   BAL0101             1.
    SH010102  COST            516.66   TRAN0101            1.
    SH010102  BAL0101            -1.   BAL0102             1.
    SH010302  COST            454.53   TRAN0103            1.
    SH010302  BAL0103            -1.   BAL0102             1.
    SH010402  COST            667.08   TRAN0104            1.
    SH010402  BAL0104            -1.   BAL0102             1.
    SH010502  COST            807.69   TRAN0105            1.
    SH010502  BAL0105            -1.   BAL0102             1.
    SH010602  COST            412.02   TRAN0106            1.
    SH010602  BAL0152            -1.   BAL0102             1.
    SH010802  COST            567.89   TRAN0108            1.
    SH010802  BAL0183            -1.   BAL0102             1.
    SH010103  COST            267.05   TRAN0101            1.
    SH010103  BAL0101            -1.   BAL0103             1.
    SH010203  COST            516.66   TRAN0102            1.
    SH010203  BAL0102            -1.   BAL0103             1.
    SH010403  COST            400.03   TRAN0104            1.
    SH010403  BAL0104            -1.   BAL0103             1.
    SH010503  COST            309.56   TRAN0105            1.
    SH010503  BAL0105            -1.   BAL0103             1.
    SH010603  COST              98.1   TRAN0106            1.
    SH010603  BAL0152            -1.   BAL0103             1.
    SH010803  COST            277.95   TRAN0108            1.
    SH010803  BAL0183            -1.   BAL0103             1.
    SH010104  COST            189.66   TRAN0101            1.
    SH010104  BAL0101            -1.   BAL0104             1.
    SH010204  COST            548.27   TRAN0102            1.
    SH010204  BAL0102            -1.   BAL0104             1.
    SH010304  COST            264.87   TRAN0103            1.
    SH010304  BAL0103            -1.   BAL0104             1.
    SH010504  COST            347.71   TRAN0105            1.
    SH010504  BAL0105            -1.   BAL0104             1.
    SH010604  COST            267.05   TRAN0106            1.
    SH010604  BAL0152            -1.   BAL0104             1.
    SH010804  COST             63.22   TRAN0108            1.
    SH010804  BAL0183            -1.   BAL0104             1.
    SH010105  COST             294.3   TRAN0101            1.
    SH010105  BAL0101            -1.   BAL0105             1.
    SH010205  COST            562.44   TRAN0102            1.
    SH010205  BAL0102            -1.   BAL0105             1.
    SH010305  COST            309.56   TRAN0103            1.
    SH010305  BAL0103            -1.   BAL0105             1.
    SH010405  COST            310.65   TRAN0104            1.
    SH010405  BAL0104            -1.   BAL0105             1.
    SH010605  COST            355.34   TRAN0106            1.
    SH010605  BAL0152            -1.   BAL0105             1.
    SH010705  COST            364.06   TRAN0107            1.
    SH010705  BAL0164            -1.   BAL0105             1.
    SH010805  COST            295.39   TRAN0108            1.
    SH010805  BAL0183            -1.   BAL0105             1.
    SH010106  COST            216.91   TRAN0101            1.
    SH010106  BAL0101            -1.   BAL0106             1.
    SH010107  COST             22.89   TRAN0101            1.
    SH010107  BAL0101            -1.   BAL0107             1.
    SH010207  COST            318.28   TRAN0102            1.
    SH010207  BAL0102            -1.   BAL0107             1.
    SH010307  COST            135.16   TRAN0103            1.
    SH010307  BAL0103            -1.   BAL0107             1.
    SH010407  COST            225.63   TRAN0104            1.
    SH010407  BAL0104            -1.   BAL0107             1.
    SH010507  COST            249.61   TRAN0105            1.
    SH010507  BAL0105            -1.   BAL0107             1.
    SH010607  COST            136.25   TRAN0106            1.
    SH010607  BAL0152            -1.   BAL0107             1.
    SH010707  COST            252.88   TRAN0107            1.
    SH010707  BAL0164            -1.   BAL0107             1.
    SH010807  COST            168.95   TRAN0108            1.
    SH010807  BAL0183            -1.   BAL0107             1.
    SH010108  COST             71.94   TRAN0101            1.
    SH010108  BAL0101            -1.   BAL0108             1.
    SH010208  COST            409.84   TRAN0102            1.
    SH010208  BAL0102            -1.   BAL0108             1.
    SH010308  COST            153.69   TRAN0103            1.
    SH010308  BAL0103            -1.   BAL0108             1.
    SH010408  COST            269.23   TRAN0104            1.
    SH010408  BAL0104            -1.   BAL0108             1.
    SH010508  COST            198.38   TRAN0105            1.
    SH010508  BAL0105            -1.   BAL0108             1.
    SH010608  COST            180.94   TRAN0106            1.
    SH010608  BAL0152            -1.   BAL0108             1.
    SH010808  COST            203.83   TRAN0108            1.
    SH010808  BAL0183            -1.   BAL0108             1.
    SH010109  COST            150.42   TRAN0101            1.
    SH010109  BAL0101            -1.   BAL0109             1.
    SH010110  COST            269.23   TRAN0101            1.
    SH010110  BAL0101            -1.   BAL0110             1.
    SH010210  COST            172.22   TRAN0102            1.
    SH010210  BAL0102            -1.   BAL0110             1.
    SH010310  COST             261.6   TRAN0103            1.
    SH010310  BAL0103            -1.   BAL0110             1.
    SH010410  COST            391.31   TRAN0104            1.
    SH010410  BAL0104            -1.   BAL0110             1.
    SH010510  COST            419.65   TRAN0105            1.
    SH010510  BAL0105            -1.   BAL0110             1.
    SH010610  COST            245.25   TRAN0106            1.
    SH010610  BAL0152            -1.   BAL0110             1.
    SH010810  COST            332.45   TRAN0108            1.
    SH010810  BAL0183            -1.   BAL0110             1.
    SH010111  COST            115.54   TRAN0101            1.
    SH010111  BAL0101            -1.   BAL0111             1.
    SH010112  COST             95.92   TRAN0101            1.
    SH010112  BAL0101            -1.   BAL0112             1.
    SH010114  COST            154.78   TRAN0101            1.
    SH010114  BAL0101            -1.   BAL0114             1.
    SH010614  COST            204.92   TRAN0106            1.
    SH010614  BAL0152            -1.   BAL0114             1.
    SH010115  COST            330.27   TRAN0101            1.
    SH010115  BAL0101            -1.   BAL0115             1.
    SH010215  COST            173.31   TRAN0102            1.
    SH010215  BAL0102            -1.   BAL0115             1.
    SH010315  COST            255.06   TRAN0103            1.
    SH010315  BAL0103            -1.   BAL0115             1.
    SH010415  COST            518.84   TRAN0104            1.
    SH010415  BAL0104            -1.   BAL0115             1.
    SH010515  COST            433.82   TRAN0105            1.
    SH010515  BAL0105            -1.   BAL0115             1.
    SH010615  COST            204.92   TRAN0106            1.
    SH010615  BAL0152            -1.   BAL0115             1.
    SH010815  COST            406.57   TRAN0108            1.
    SH010815  BAL0183            -1.   BAL0115             1.
    SH010116  COST            172.22   TRAN0101            1.
    SH010116  BAL0101            -1.   BAL0116             1.
    SH010216  COST             305.2   TRAN0102            1.
    SH010216  BAL0102            -1.   BAL0116             1.
    SH010316  COST            247.43   TRAN0103            1.
    SH010316  BAL0103            -1.   BAL0116             1.
    SH010416  COST            312.83   TRAN0104            1.
    SH010416  BAL0104            -1.   BAL0116             1.
    SH010516  COST            347.71   TRAN0105            1.
    SH010516  BAL0105            -1.   BAL0116             1.
    SH010616  COST            142.79   TRAN0106            1.
    SH010616  BAL0152            -1.   BAL0116             1.
    SH010816  COST            223.45   TRAN0108            1.
    SH010816  BAL0183            -1.   BAL0116             1.
    SH010117  COST            164.59   TRAN0101            1.
    SH010117  BAL0101            -1.   BAL0117             1.
    SH010817  COST             29.43   TRAN0108            1.
    SH010817  BAL0183            -1.   BAL0117             1.
    SH010418  COST            167.86   TRAN0104            1.
    SH010418  BAL0104            -1.   BAL0118             1.
    SH010119  COST            270.32   TRAN0101            1.
    SH010119  BAL0101            -1.   BAL0119             1.
    SH010219  COST            748.83   TRAN0102            1.
    SH010219  BAL0102            -1.   BAL0119             1.
    SH010319  COST            345.53   TRAN0103            1.
    SH010319  BAL0103            -1.   BAL0119             1.
    SH010419  COST            173.31   TRAN0104            1.
    SH010419  BAL0104            -1.   BAL0119             1.
    SH010519  COST            226.72   TRAN0105            1.
    SH010519  BAL0105            -1.   BAL0119             1.
    SH010619  COST            376.05   TRAN0106            1.
    SH010619  BAL0152            -1.   BAL0119             1.
    SH010819  COST            107.91   TRAN0108            1.
    SH010819  BAL0183            -1.   BAL0119             1.
    SH010120  COST            223.45   TRAN0101            1.
    SH010120  BAL0101            -1.   BAL0120             1.
    SH010220  COST            744.47   TRAN0102            1.
    SH010220  BAL0102            -1.   BAL0120             1.
    SH010320  COST            323.73   TRAN0103            1.
    SH010320  BAL0103            -1.   BAL0120             1.
    SH010420  COST            123.17   TRAN0104            1.
    SH010420  BAL0104            -1.   BAL0120             1.
    SH010520  COST            317.19   TRAN0105            1.
    SH010520  BAL0105            -1.   BAL0120             1.
    SH010820  COST            137.34   TRAN0108            1.
    SH010820  BAL0183            -1.   BAL0120             1.
    SH010121  COST            439.27   TRAN0101            1.
    SH010121  BAL0101            -1.   BAL0121             1.
    SH010221  COST            401.12   TRAN0102            1.
    SH010221  BAL0102            -1.   BAL0121             1.
    SH010321  COST            486.14   TRAN0103            1.
    SH010321  BAL0103            -1.   BAL0121             1.
    SH010421  COST             348.8   TRAN0104            1.
    SH010421  BAL0104            -1.   BAL0121             1.
    SH010521  COST             599.5   TRAN0105            1.
    SH010521  BAL0105            -1.   BAL0121             1.
    SH010821  COST             348.8   TRAN0108            1.
    SH010821  BAL0183            -1.   BAL0121             1.
    SH010422  COST            244.16   TRAN0104            1.
    SH010422  BAL0104            -1.   BAL0122             1.
    SH010423  COST            182.03   TRAN0104            1.
    SH010423  BAL0104            -1.   BAL0123             1.
    SH010124  COST           1565.24   TRAN0101            1.
    SH010124  BAL0101            -1.   BAL0124             1.
    SH010225  COST            465.43   TRAN0102            1.
    SH010225  BAL0102            -1.   BAL0125             1.
    SH010426  COST             294.3   TRAN0104            1.
    SH010426  BAL0104            -1.   BAL0126             1.
    SH010627  COST            292.12   TRAN0106            1.
    SH010627  BAL0152            -1.   BAL0127             1.
    SH010128  COST            264.87   TRAN0101            1.
    SH010128  BAL0101            -1.   BAL0128             1.
    SH010528  COST            111.18   TRAN0105            1.
    SH010528  BAL0105            -1.   BAL0128             1.
    SH010429  COST            216.91   TRAN0104            1.
    SH010429  BAL0104            -1.   BAL0129             1.
    SH010430  COST            331.36   TRAN0104            1.
    SH010430  BAL0104            -1.   BAL0130             1.
    SH010131  COST            120.99   TRAN0101            1.
    SH010131  BAL0101            -1.   BAL0131             1.
    SH010432  COST            171.13   TRAN0104            1.
    SH010432  BAL0104            -1.   BAL0132             1.
    SH010133  COST            537.37   TRAN0101            1.
    SH010133  BAL0101            -1.   BAL0133             1.
    SH010233  COST              436.   TRAN0102            1.
    SH010233  BAL0102            -1.   BAL0133             1.
    SH010333  COST            591.87   TRAN0103            1.
    SH010333  BAL0103            -1.   BAL0133             1.
    SH010433  COST            485.05   TRAN0104            1.
    SH010433  BAL0104            -1.   BAL0133             1.
    SH010533  COST            687.79   TRAN0105            1.
    SH010533  BAL0105            -1.   BAL0133             1.
    SH010833  COST            415.29   TRAN0108            1.
    SH010833  BAL0183            -1.   BAL0133             1.
    SH010134  COST            420.74   TRAN0101            1.
    SH010134  BAL0101            -1.   BAL0134             1.
    SH010234  COST            713.95   TRAN0102            1.
    SH010234  BAL0102            -1.   BAL0134             1.
    SH010334  COST            548.27   TRAN0103            1.
    SH010334  BAL0103            -1.   BAL0134             1.
    SH010434  COST            229.99   TRAN0104            1.
    SH010434  BAL0104            -1.   BAL0134             1.
    SH010534  COST            480.69   TRAN0105            1.
    SH010534  BAL0105            -1.   BAL0134             1.
    SH010834  COST            286.67   TRAN0108            1.
    SH010834  BAL0183            -1.   BAL0134             1.
    SH010435  COST            132.98   TRAN0104            1.
    SH010435  BAL0104            -1.   BAL0135             1.
    SH010636  COST             119.9   TRAN0106            1.
    SH010636  BAL0152            -1.   BAL0136             1.
    SH010137  COST            100.28   TRAN0101            1.
    SH010137  BAL0101            -1.   BAL0137             1.
    SH010237  COST            372.78   TRAN0102            1.
    SH010237  BAL0102            -1.   BAL0137             1.
    SH010337  COST            172.22   TRAN0103            1.
    SH010337  BAL0103            -1.   BAL0137             1.
    SH010437  COST            331.36   TRAN0104            1.
    SH010437  BAL0104            -1.   BAL0137             1.
    SH010537  COST            198.38   TRAN0105            1.
    SH010537  BAL0105            -1.   BAL0137             1.
    SH010637  COST            211.46   TRAN0106            1.
    SH010637  BAL0152            -1.   BAL0137             1.
    SH010837  COST            274.68   TRAN0108            1.
    SH010837  BAL0183            -1.   BAL0137             1.
    SH010138  COST            148.24   TRAN0101            1.
    SH010138  BAL0101            -1.   BAL0138             1.
    SH010238  COST            265.96   TRAN0102            1.
    SH010238  BAL0102            -1.   BAL0138             1.
    SH010338  COST            103.55   TRAN0103            1.
    SH010338  BAL0103            -1.   BAL0138             1.
    SH010438  COST            335.72   TRAN0104            1.
    SH010438  BAL0104            -1.   BAL0138             1.
    SH010538  COST            303.02   TRAN0105            1.
    SH010538  BAL0105            -1.   BAL0138             1.
    SH010638  COST             42.51   TRAN0106            1.
    SH010638  BAL0152            -1.   BAL0138             1.
    SH010738  COST            235.44   TRAN0107            1.
    SH010738  BAL0164            -1.   BAL0138             1.
    SH010838  COST            258.33   TRAN0108            1.
    SH010838  BAL0183            -1.   BAL0138             1.
    SH010139  COST             141.7   TRAN0101            1.
    SH010139  BAL0101            -1.   BAL0139             1.
    SH010140  COST            179.85   TRAN0101            1.
    SH010140  BAL0101            -1.   BAL0140             1.
    SH010240  COST            412.02   TRAN0102            1.
    SH010240  BAL0102            -1.   BAL0140             1.
    SH010340  COST            112.27   TRAN0103            1.
    SH010340  BAL0103            -1.   BAL0140             1.
    SH010440  COST            323.73   TRAN0104            1.
    SH010440  BAL0104            -1.   BAL0140             1.
    SH010540  COST            240.89   TRAN0105            1.
    SH010540  BAL0105            -1.   BAL0140             1.
    SH010640  COST            142.79   TRAN0106            1.
    SH010640  BAL0152            -1.   BAL0140             1.
    SH010840  COST            298.66   TRAN0108            1.
    SH010840  BAL0183            -1.   BAL0140             1.
    SH010641  COST              109.   TRAN0106            1.
    SH010641  BAL0152            -1.   BAL0141             1.
    SH010142  COST              98.1   TRAN0101            1.
    SH010142  BAL0101            -1.   BAL0142             1.
    SH010143  COST            173.31   TRAN0101            1.
    SH010143  BAL0101            -1.   BAL0143             1.
    SH010243  COST            430.55   TRAN0102            1.
    SH010243  BAL0102            -1.   BAL0143             1.
    SH010343  COST             27.25   TRAN0103            1.
    SH010343  BAL0103            -1.   BAL0143             1.
    SH010443  COST            322.64   TRAN0104            1.
    SH010443  BAL0104            -1.   BAL0143             1.
    SH010543  COST            281.22   TRAN0105            1.
    SH010543  BAL0105            -1.   BAL0143             1.
    SH010643  COST              109.   TRAN0106            1.
    SH010643  BAL0152            -1.   BAL0143             1.
    SH010743  COST            262.69   TRAN0107            1.
    SH010743  BAL0164            -1.   BAL0143             1.
    SH010843  COST            295.39   TRAN0108            1.
    SH010843  BAL0183            -1.   BAL0143             1.
    SH010644  COST             97.01   TRAN0106            1.
    SH010644  BAL0152            -1.   BAL0144             1.
    SH010145  COST            187.48   TRAN0101            1.
    SH010145  BAL0101            -1.   BAL0145             1.
    SH010245  COST            475.24   TRAN0102            1.
    SH010245  BAL0102            -1.   BAL0145             1.
    SH010345  COST            175.49   TRAN0103            1.
    SH010345  BAL0103            -1.   BAL0145             1.
    SH010445  COST            318.28   TRAN0104            1.
    SH010445  BAL0104            -1.   BAL0145             1.
    SH010545  COST            255.06   TRAN0105            1.
    SH010545  BAL0105            -1.   BAL0145             1.
    SH010645  COST            208.19   TRAN0106            1.
    SH010645  BAL0152            -1.   BAL0145             1.
    SH010745  COST            214.73   TRAN0107            1.
    SH010745  BAL0164            -1.   BAL0145             1.
    SH010845  COST            332.45   TRAN0108            1.
    SH010845  BAL0183            -1.   BAL0145             1.
    SH010146  COST            267.05   TRAN0101            1.
    SH010146  BAL0101            -1.   BAL0146             1.
    SH010246  COST            297.57   TRAN0102            1.
    SH010246  BAL0102            -1.   BAL0146             1.
    SH010346  COST            240.89   TRAN0103            1.
    SH010346  BAL0103            -1.   BAL0146             1.
    SH010446  COST            487.23   TRAN0104            1.
    SH010446  BAL0104            -1.   BAL0146             1.
    SH010546  COST             468.7   TRAN0105            1.
    SH010546  BAL0105            -1.   BAL0146             1.
    SH010646  COST            280.13   TRAN0106            1.
    SH010646  BAL0152            -1.   BAL0146             1.
    SH010846  COST            488.32   TRAN0108            1.
    SH010846  BAL0183            -1.   BAL0146             1.
    SH010147  COST             119.9   TRAN0101            1.
    SH010147  BAL0101            -1.   BAL0147             1.
    SH010148  COST            103.55   TRAN0101            1.
    SH010148  BAL0101            -1.   BAL0148             1.
    SH010149  COST            358.61   TRAN0101            1.
    SH010149  BAL0101            -1.   BAL0149             1.
    SH010549  COST            165.68   TRAN0105            1.
    SH010549  BAL0105            -1.   BAL0149             1.
    SH010150  COST            262.69   TRAN0101            1.
    SH010150  BAL0101            -1.   BAL0150             1.
    SH010151  COST            361.88   TRAN0101            1.
    SH010151  BAL0101            -1.   BAL0151             1.
    SH010551  COST            134.07   TRAN0105            1.
    SH010551  BAL0105            -1.   BAL0151             1.
    SH010152  COST            122.08   TRAN0101            1.
    SH010152  BAL0101            -1.   BAL0152             1.
    SH010252  COST              327.   TRAN0102            1.
    SH010252  BAL0102            -1.   BAL0152             1.
    SH010352  COST             89.38   TRAN0103            1.
    SH010352  BAL0103            -1.   BAL0152             1.
    SH010452  COST            350.98   TRAN0104            1.
    SH010452  BAL0104            -1.   BAL0152             1.
    SH010552  COST            321.55   TRAN0105            1.
    SH010552  BAL0105            -1.   BAL0152             1.
    SH010852  COST            275.77   TRAN0108            1.
    SH010852  BAL0183            -1.   BAL0152             1.
    SH010153  COST            391.31   TRAN0101            1.
    SH010153  BAL0101            -1.   BAL0153             1.
    SH010253  COST            693.24   TRAN0102            1.
    SH010253  BAL0102            -1.   BAL0153             1.
    SH010353  COST            354.25   TRAN0103            1.
    SH010353  BAL0103            -1.   BAL0153             1.
    SH010453  COST            449.08   TRAN0104            1.
    SH010453  BAL0104            -1.   BAL0153             1.
    SH010553  COST            200.56   TRAN0105            1.
    SH010553  BAL0105            -1.   BAL0153             1.
    SH010653  COST            391.31   TRAN0106            1.
    SH010653  BAL0152            -1.   BAL0153             1.
    SH010753  COST            159.14   TRAN0107            1.
    SH010753  BAL0164            -1.   BAL0153             1.
    SH010853  COST            439.27   TRAN0108            1.
    SH010853  BAL0183            -1.   BAL0153             1.
    SH010154  COST            201.65   TRAN0101            1.
    SH010154  BAL0101            -1.   BAL0154             1.
    SH010155  COST            303.02   TRAN0101            1.
    SH010155  BAL0101            -1.   BAL0155             1.
    SH010255  COST            522.11   TRAN0102            1.
    SH010255  BAL0102            -1.   BAL0155             1.
    SH010355  COST            306.29   TRAN0103            1.
    SH010355  BAL0103            -1.   BAL0155             1.
    SH010455  COST            320.46   TRAN0104            1.
    SH010455  BAL0104            -1.   BAL0155             1.
    SH010555  COST            167.86   TRAN0105            1.
    SH010555  BAL0105            -1.   BAL0155             1.
    SH010655  COST             316.1   TRAN0106            1.
    SH010655  BAL0152            -1.   BAL0155             1.
    SH010755  COST            116.63   TRAN0107            1.
    SH010755  BAL0164            -1.   BAL0155             1.
    SH010855  COST            320.46   TRAN0108            1.
    SH010855  BAL0183            -1.   BAL0155             1.
    SH010156  COST             425.1   TRAN0101            1.
    SH010156  BAL0101            -1.   BAL0156             1.
    SH010556  COST            148.24   TRAN0105            1.
    SH010556  BAL0105            -1.   BAL0156             1.
    SH010157  COST            284.49   TRAN0101            1.
    SH010157  BAL0101            -1.   BAL0157             1.
    SH010557  COST            183.12   TRAN0105            1.
    SH010557  BAL0105            -1.   BAL0157             1.
    SH010158  COST            320.46   TRAN0101            1.
    SH010158  BAL0101            -1.   BAL0158             1.
    SH010258  COST            567.89   TRAN0102            1.
    SH010258  BAL0102            -1.   BAL0158             1.
    SH010358  COST            303.02   TRAN0103            1.
    SH010358  BAL0103            -1.   BAL0158             1.
    SH010458  COST            373.87   TRAN0104            1.
    SH010458  BAL0104            -1.   BAL0158             1.
    SH010558  COST             22.89   TRAN0105            1.
    SH010558  BAL0105            -1.   BAL0158             1.
    SH010658  COST            355.34   TRAN0106            1.
    SH010658  BAL0152            -1.   BAL0158             1.
    SH010758  COST             74.12   TRAN0107            1.
    SH010758  BAL0164            -1.   BAL0158             1.
    SH010858  COST            276.86   TRAN0108            1.
    SH010858  BAL0183            -1.   BAL0158             1.
    SH010159  COST            224.54   TRAN0101            1.
    SH010159  BAL0101            -1.   BAL0159             1.
    SH010259  COST            542.82   TRAN0102            1.
    SH010259  BAL0102            -1.   BAL0159             1.
    SH010359  COST            259.42   TRAN0103            1.
    SH010359  BAL0103            -1.   BAL0159             1.
    SH010459  COST            265.96   TRAN0104            1.
    SH010459  BAL0104            -1.   BAL0159             1.
    SH010559  COST            173.31   TRAN0105            1.
    SH010559  BAL0105            -1.   BAL0159             1.
    SH010659  COST            323.73   TRAN0106            1.
    SH010659  BAL0152            -1.   BAL0159             1.
    SH010759  COST            114.45   TRAN0107            1.
    SH010759  BAL0164            -1.   BAL0159             1.
    SH010859  COST            277.95   TRAN0108            1.
    SH010859  BAL0183            -1.   BAL0159             1.
    SH010160  COST            284.49   TRAN0101            1.
    SH010160  BAL0101            -1.   BAL0160             1.
    SH010260  COST             599.5   TRAN0102            1.
    SH010260  BAL0102            -1.   BAL0160             1.
    SH010360  COST            308.47   TRAN0103            1.
    SH010360  BAL0103            -1.   BAL0160             1.
    SH010460  COST            340.08   TRAN0104            1.
    SH010460  BAL0104            -1.   BAL0160             1.
    SH010560  COST            147.15   TRAN0105            1.
    SH010560  BAL0105            -1.   BAL0160             1.
    SH010660  COST            352.07   TRAN0106            1.
    SH010660  BAL0152            -1.   BAL0160             1.
    SH010760  COST             95.92   TRAN0107            1.
    SH010760  BAL0164            -1.   BAL0160             1.
    SH010860  COST            325.91   TRAN0108            1.
    SH010860  BAL0183            -1.   BAL0160             1.
    SH010163  COST            289.94   TRAN0101            1.
    SH010163  BAL0101            -1.   BAL0163             1.
    SH010563  COST            165.68   TRAN0105            1.
    SH010563  BAL0105            -1.   BAL0163             1.
    SH010164  COST            216.91   TRAN0101            1.
    SH010164  BAL0101            -1.   BAL0164             1.
    SH010264  COST            573.34   TRAN0102            1.
    SH010264  BAL0102            -1.   BAL0164             1.
    SH010364  COST            243.07   TRAN0103            1.
    SH010364  BAL0103            -1.   BAL0164             1.
    SH010464  COST            366.24   TRAN0104            1.
    SH010464  BAL0104            -1.   BAL0164             1.
    SH010564  COST             63.22   TRAN0105            1.
    SH010564  BAL0105            -1.   BAL0164             1.
    SH010664  COST            345.53   TRAN0106            1.
    SH010664  BAL0152            -1.   BAL0164             1.
    SH010864  COST             272.5   TRAN0108            1.
    SH010864  BAL0183            -1.   BAL0164             1.
    SH010265  COST            334.63   TRAN0102            1.
    SH010265  BAL0102            -1.   BAL0165             1.
    SH010266  COST            282.31   TRAN0102            1.
    SH010266  BAL0102            -1.   BAL0166             1.
    SH010267  COST            252.88   TRAN0102            1.
    SH010267  BAL0102            -1.   BAL0167             1.
    SH010268  COST              436.   TRAN0102            1.
    SH010268  BAL0102            -1.   BAL0168             1.
    SH010269  COST            240.89   TRAN0102            1.
    SH010269  BAL0102            -1.   BAL0169             1.
    SH010171  COST             479.6   TRAN0101            1.
    SH010171  BAL0101            -1.   BAL0171             1.
    SH010371  COST            571.16   TRAN0103            1.
    SH010371  BAL0103            -1.   BAL0171             1.
    SH010471  COST            567.89   TRAN0104            1.
    SH010471  BAL0104            -1.   BAL0171             1.
    SH010571  COST            633.29   TRAN0105            1.
    SH010571  BAL0105            -1.   BAL0171             1.
    SH010671  COST            426.19   TRAN0106            1.
    SH010671  BAL0152            -1.   BAL0171             1.
    SH010771  COST            767.36   TRAN0107            1.
    SH010771  BAL0164            -1.   BAL0171             1.
    SH010871  COST            580.97   TRAN0108            1.
    SH010871  BAL0183            -1.   BAL0171             1.
    SH010272  COST            591.87   TRAN0102            1.
    SH010272  BAL0102            -1.   BAL0172             1.
    SH010173  COST             425.1   TRAN0101            1.
    SH010173  BAL0101            -1.   BAL0173             1.
    SH010273  COST            397.85   TRAN0102            1.
    SH010273  BAL0102            -1.   BAL0173             1.
    SH010373  COST            368.42   TRAN0103            1.
    SH010373  BAL0103            -1.   BAL0173             1.
    SH010473  COST            498.13   TRAN0104            1.
    SH010473  BAL0104            -1.   BAL0173             1.
    SH010573  COST            614.76   TRAN0105            1.
    SH010573  BAL0105            -1.   BAL0173             1.
    SH010673  COST            332.45   TRAN0106            1.
    SH010673  BAL0152            -1.   BAL0173             1.
    SH010873  COST            549.36   TRAN0108            1.
    SH010873  BAL0183            -1.   BAL0173             1.
    SH010274  COST             228.9   TRAN0102            1.
    SH010274  BAL0102            -1.   BAL0174             1.
    SH010275  COST            603.86   TRAN0102            1.
    SH010275  BAL0102            -1.   BAL0175             1.
    SH010276  COST            437.09   TRAN0102            1.
    SH010276  BAL0102            -1.   BAL0176             1.
    SH010177  COST            474.15   TRAN0101            1.
    SH010177  BAL0101            -1.   BAL0177             1.
    SH010277  COST            296.48   TRAN0102            1.
    SH010277  BAL0102            -1.   BAL0177             1.
    SH010377  COST            502.49   TRAN0103            1.
    SH010377  BAL0103            -1.   BAL0177             1.
    SH010477  COST            437.09   TRAN0104            1.
    SH010477  BAL0104            -1.   BAL0177             1.
    SH010577  COST             610.4   TRAN0105            1.
    SH010577  BAL0105            -1.   BAL0177             1.
    SH010877  COST             348.8   TRAN0108            1.
    SH010877  BAL0183            -1.   BAL0177             1.
    SH010178  COST            829.49   TRAN0101            1.
    SH010178  BAL0101            -1.   BAL0178             1.
    SH010278  COST            481.78   TRAN0102            1.
    SH010278  BAL0102            -1.   BAL0178             1.
    SH010378  COST            853.47   TRAN0103            1.
    SH010378  BAL0103            -1.   BAL0178             1.
    SH010478  COST            746.65   TRAN0104            1.
    SH010478  BAL0104            -1.   BAL0178             1.
    SH010578  COST            958.11   TRAN0105            1.
    SH010578  BAL0105            -1.   BAL0178             1.
    SH010878  COST            834.94   TRAN0108            1.
    SH010878  BAL0183            -1.   BAL0178             1.
    SH010279  COST            293.21   TRAN0102            1.
    SH010279  BAL0102            -1.   BAL0179             1.
    SH010480  COST            407.66   TRAN0104            1.
    SH010480  BAL0104            -1.   BAL0180             1.
    SH010182  COST            634.38   TRAN0101            1.
    SH010182  BAL0101            -1.   BAL0182             1.
    SH010282  COST            358.61   TRAN0102            1.
    SH010282  BAL0102            -1.   BAL0182             1.
    SH010382  COST            713.95   TRAN0103            1.
    SH010382  BAL0103            -1.   BAL0182             1.
    SH010482  COST            769.54   TRAN0104            1.
    SH010482  BAL0104            -1.   BAL0182             1.
    SH010582  COST           1250.23   TRAN0105            1.
    SH010582  BAL0105            -1.   BAL0182             1.
    SH010882  COST            853.47   TRAN0108            1.
    SH010882  BAL0183            -1.   BAL0182             1.
    SH010183  COST            192.93   TRAN0101            1.
    SH010183  BAL0101            -1.   BAL0183             1.
    SH010283  COST             566.8   TRAN0102            1.
    SH010283  BAL0102            -1.   BAL0183             1.
    SH010383  COST            296.48   TRAN0103            1.
    SH010383  BAL0103            -1.   BAL0183             1.
    SH010483  COST             64.31   TRAN0104            1.
    SH010483  BAL0104            -1.   BAL0183             1.
    SH010583  COST            378.23   TRAN0105            1.
    SH010583  BAL0105            -1.   BAL0183             1.
    SH010683  COST            270.32   TRAN0106            1.
    SH010683  BAL0152            -1.   BAL0183             1.
    SH010284  COST            209.28   TRAN0102            1.
    SH010284  BAL0102            -1.   BAL0184             1.
    SH020201  COST            368.28   TRAN0202            1.
    SH020201  BAL0202            -1.   BAL0201             1.
    SH020301  COST            141.36   TRAN0203            1.
    SH020301  BAL0203            -1.   BAL0201             1.
    SH020401  COST            257.92   TRAN0204            1.
    SH020401  BAL0204            -1.   BAL0201             1.
    SH020501  COST            293.88   TRAN0205            1.
    SH020501  BAL0205            -1.   BAL0201             1.
    SH020601  COST            156.24   TRAN0206            1.
    SH020601  BAL0252            -1.   BAL0201             1.
    SH020801  COST            177.32   TRAN0208            1.
    SH020801  BAL0283            -1.   BAL0201             1.
    SH020102  COST            587.76   TRAN0201            1.
    SH020102  BAL0201            -1.   BAL0202             1.
    SH020302  COST            517.08   TRAN0203            1.
    SH020302  BAL0203            -1.   BAL0202             1.
    SH020402  COST            758.88   TRAN0204            1.
    SH020402  BAL0204            -1.   BAL0202             1.
    SH020502  COST            918.84   TRAN0205            1.
    SH020502  BAL0205            -1.   BAL0202             1.
    SH020602  COST            468.72   TRAN0206            1.
    SH020602  BAL0252            -1.   BAL0202             1.
    SH020802  COST            646.04   TRAN0208            1.
    SH020802  BAL0283            -1.   BAL0202             1.
    SH020103  COST             303.8   TRAN0201            1.
    SH020103  BAL0201            -1.   BAL0203             1.
    SH020203  COST            587.76   TRAN0202            1.
    SH020203  BAL0202            -1.   BAL0203             1.
    SH020403  COST            455.08   TRAN0204            1.
    SH020403  BAL0204            -1.   BAL0203             1.
    SH020503  COST            352.16   TRAN0205            1.
    SH020503  BAL0205            -1.   BAL0203             1.
    SH020603  COST             111.6   TRAN0206            1.
    SH020603  BAL0252            -1.   BAL0203             1.
    SH020803  COST             316.2   TRAN0208            1.
    SH020803  BAL0283            -1.   BAL0203             1.
    SH020104  COST            215.76   TRAN0201            1.
    SH020104  BAL0201            -1.   BAL0204             1.
    SH020204  COST            623.72   TRAN0202            1.
    SH020204  BAL0202            -1.   BAL0204             1.
    SH020304  COST            301.32   TRAN0203            1.
    SH020304  BAL0203            -1.   BAL0204             1.
    SH020504  COST            395.56   TRAN0205            1.
    SH020504  BAL0205            -1.   BAL0204             1.
    SH020604  COST             303.8   TRAN0206            1.
    SH020604  BAL0252            -1.   BAL0204             1.
    SH020804  COST             71.92   TRAN0208            1.
    SH020804  BAL0283            -1.   BAL0204             1.
    SH020105  COST             334.8   TRAN0201            1.
    SH020105  BAL0201            -1.   BAL0205             1.
    SH020205  COST            639.84   TRAN0202            1.
    SH020205  BAL0202            -1.   BAL0205             1.
    SH020305  COST            352.16   TRAN0203            1.
    SH020305  BAL0203            -1.   BAL0205             1.
    SH020405  COST             353.4   TRAN0204            1.
    SH020405  BAL0204            -1.   BAL0205             1.
    SH020605  COST            404.24   TRAN0206            1.
    SH020605  BAL0252            -1.   BAL0205             1.
    SH020705  COST            414.16   TRAN0207            1.
    SH020705  BAL0264            -1.   BAL0205             1.
    SH020805  COST            336.04   TRAN0208            1.
    SH020805  BAL0283            -1.   BAL0205             1.
    SH020106  COST            246.76   TRAN0201            1.
    SH020106  BAL0201            -1.   BAL0206             1.
    SH020107  COST             26.04   TRAN0201            1.
    SH020107  BAL0201            -1.   BAL0207             1.
    SH020207  COST            362.08   TRAN0202            1.
    SH020207  BAL0202            -1.   BAL0207             1.
    SH020307  COST            153.76   TRAN0203            1.
    SH020307  BAL0203            -1.   BAL0207             1.
    SH020407  COST            256.68   TRAN0204            1.
    SH020407  BAL0204            -1.   BAL0207             1.
    SH020507  COST            283.96   TRAN0205            1.
    SH020507  BAL0205            -1.   BAL0207             1.
    SH020607  COST              155.   TRAN0206            1.
    SH020607  BAL0252            -1.   BAL0207             1.
    SH020707  COST            287.68   TRAN0207            1.
    SH020707  BAL0264            -1.   BAL0207             1.
    SH020807  COST             192.2   TRAN0208            1.
    SH020807  BAL0283            -1.   BAL0207             1.
    SH020108  COST             81.84   TRAN0201            1.
    SH020108  BAL0201            -1.   BAL0208             1.
    SH020208  COST            466.24   TRAN0202            1.
    SH020208  BAL0202            -1.   BAL0208             1.
    SH020308  COST            174.84   TRAN0203            1.
    SH020308  BAL0203            -1.   BAL0208             1.
    SH020408  COST            306.28   TRAN0204            1.
    SH020408  BAL0204            -1.   BAL0208             1.
    SH020508  COST            225.68   TRAN0205            1.
    SH020508  BAL0205            -1.   BAL0208             1.
    SH020608  COST            205.84   TRAN0206            1.
    SH020608  BAL0252            -1.   BAL0208             1.
    SH020808  COST            231.88   TRAN0208            1.
    SH020808  BAL0283            -1.   BAL0208             1.
    SH020109  COST            171.12   TRAN0201            1.
    SH020109  BAL0201            -1.   BAL0209             1.
    SH020110  COST            306.28   TRAN0201            1.
    SH020110  BAL0201            -1.   BAL0210             1.
    SH020210  COST            195.92   TRAN0202            1.
    SH020210  BAL0202            -1.   BAL0210             1.
    SH020310  COST             297.6   TRAN0203            1.
    SH020310  BAL0203            -1.   BAL0210             1.
    SH020410  COST            445.16   TRAN0204            1.
    SH020410  BAL0204            -1.   BAL0210             1.
    SH020510  COST             477.4   TRAN0205            1.
    SH020510  BAL0205            -1.   BAL0210             1.
    SH020610  COST              279.   TRAN0206            1.
    SH020610  BAL0252            -1.   BAL0210             1.
    SH020810  COST             378.2   TRAN0208            1.
    SH020810  BAL0283            -1.   BAL0210             1.
    SH020111  COST            131.44   TRAN0201            1.
    SH020111  BAL0201            -1.   BAL0211             1.
    SH020112  COST            109.12   TRAN0201            1.
    SH020112  BAL0201            -1.   BAL0212             1.
    SH020114  COST            176.08   TRAN0201            1.
    SH020114  BAL0201            -1.   BAL0214             1.
    SH020614  COST            233.12   TRAN0206            1.
    SH020614  BAL0252            -1.   BAL0214             1.
    SH020115  COST            375.72   TRAN0201            1.
    SH020115  BAL0201            -1.   BAL0215             1.
    SH020215  COST            197.16   TRAN0202            1.
    SH020215  BAL0202            -1.   BAL0215             1.
    SH020315  COST            290.16   TRAN0203            1.
    SH020315  BAL0203            -1.   BAL0215             1.
    SH020415  COST            590.24   TRAN0204            1.
    SH020415  BAL0204            -1.   BAL0215             1.
    SH020515  COST            493.52   TRAN0205            1.
    SH020515  BAL0205            -1.   BAL0215             1.
    SH020615  COST            233.12   TRAN0206            1.
    SH020615  BAL0252            -1.   BAL0215             1.
    SH020815  COST            462.52   TRAN0208            1.
    SH020815  BAL0283            -1.   BAL0215             1.
    SH020116  COST            195.92   TRAN0201            1.
    SH020116  BAL0201            -1.   BAL0216             1.
    SH020216  COST             347.2   TRAN0202            1.
    SH020216  BAL0202            -1.   BAL0216             1.
    SH020316  COST            281.48   TRAN0203            1.
    SH020316  BAL0203            -1.   BAL0216             1.
    SH020416  COST            355.88   TRAN0204            1.
    SH020416  BAL0204            -1.   BAL0216             1.
    SH020516  COST            395.56   TRAN0205            1.
    SH020516  BAL0205            -1.   BAL0216             1.
    SH020616  COST            162.44   TRAN0206            1.
    SH020616  BAL0252            -1.   BAL0216             1.
    SH020816  COST             254.2   TRAN0208            1.
    SH020816  BAL0283            -1.   BAL0216             1.
    SH020117  COST            187.24   TRAN0201            1.
    SH020117  BAL0201            -1.   BAL0217             1.
    SH020817  COST             33.48   TRAN0208            1.
    SH020817  BAL0283            -1.   BAL0217             1.
    SH020418  COST            190.96   TRAN0204            1.
    SH020418  BAL0204            -1.   BAL0218             1.
    SH020119  COST            307.52   TRAN0201            1.
    SH020119  BAL0201            -1.   BAL0219             1.
    SH020219  COST            851.88   TRAN0202            1.
    SH020219  BAL0202            -1.   BAL0219             1.
    SH020319  COST            393.08   TRAN0203            1.
    SH020319  BAL0203            -1.   BAL0219             1.
    SH020419  COST            197.16   TRAN0204            1.
    SH020419  BAL0204            -1.   BAL0219             1.
    SH020519  COST            257.92   TRAN0205            1.
    SH020519  BAL0205            -1.   BAL0219             1.
    SH020619  COST             427.8   TRAN0206            1.
    SH020619  BAL0252            -1.   BAL0219             1.
    SH020819  COST            122.76   TRAN0208            1.
    SH020819  BAL0283            -1.   BAL0219             1.
    SH020120  COST             254.2   TRAN0201            1.
    SH020120  BAL0201            -1.   BAL0220             1.
    SH020220  COST            846.92   TRAN0202            1.
    SH020220  BAL0202            -1.   BAL0220             1.
    SH020320  COST            368.28   TRAN0203            1.
    SH020320  BAL0203            -1.   BAL0220             1.
    SH020420  COST            140.12   TRAN0204            1.
    SH020420  BAL0204            -1.   BAL0220             1.
    SH020520  COST            360.84   TRAN0205            1.
    SH020520  BAL0205            -1.   BAL0220             1.
    SH020820  COST            156.24   TRAN0208            1.
    SH020820  BAL0283            -1.   BAL0220             1.
    SH020121  COST            499.72   TRAN0201            1.
    SH020121  BAL0201            -1.   BAL0221             1.
    SH020221  COST            456.32   TRAN0202            1.
    SH020221  BAL0202            -1.   BAL0221             1.
    SH020321  COST            553.04   TRAN0203            1.
    SH020321  BAL0203            -1.   BAL0221             1.
    SH020421  COST             396.8   TRAN0204            1.
    SH020421  BAL0204            -1.   BAL0221             1.
    SH020521  COST              682.   TRAN0205            1.
    SH020521  BAL0205            -1.   BAL0221             1.
    SH020821  COST             396.8   TRAN0208            1.
    SH020821  BAL0283            -1.   BAL0221             1.
    SH020422  COST            277.76   TRAN0204            1.
    SH020422  BAL0204            -1.   BAL0222             1.
    SH020423  COST            207.08   TRAN0204            1.
    SH020423  BAL0204            -1.   BAL0223             1.
    SH020124  COST           1780.64   TRAN0201            1.
    SH020124  BAL0201            -1.   BAL0224             1.
    SH020225  COST            529.48   TRAN0202            1.
    SH020225  BAL0202            -1.   BAL0225             1.
    SH020426  COST             334.8   TRAN0204            1.
    SH020426  BAL0204            -1.   BAL0226             1.
    SH020627  COST            332.32   TRAN0206            1.
    SH020627  BAL0252            -1.   BAL0227             1.
    SH020128  COST            301.32   TRAN0201            1.
    SH020128  BAL0201            -1.   BAL0228             1.
    SH020528  COST            126.48   TRAN0205            1.
    SH020528  BAL0205            -1.   BAL0228             1.
    SH020429  COST            246.76   TRAN0204            1.
    SH020429  BAL0204            -1.   BAL0229             1.
    SH020430  COST            376.96   TRAN0204            1.
    SH020430  BAL0204            -1.   BAL0230             1.
    SH020131  COST            137.64   TRAN0201            1.
    SH020131  BAL0201            -1.   BAL0231             1.
    SH020432  COST            194.68   TRAN0204            1.
    SH020432  BAL0204            -1.   BAL0232             1.
    SH020133  COST            611.32   TRAN0201            1.
    SH020133  BAL0201            -1.   BAL0233             1.
    SH020233  COST              496.   TRAN0202            1.
    SH020233  BAL0202            -1.   BAL0233             1.
    SH020333  COST            673.32   TRAN0203            1.
    SH020333  BAL0203            -1.   BAL0233             1.
    SH020433  COST             551.8   TRAN0204            1.
    SH020433  BAL0204            -1.   BAL0233             1.
    SH020533  COST            782.44   TRAN0205            1.
    SH020533  BAL0205            -1.   BAL0233             1.
    SH020833  COST            472.44   TRAN0208            1.
    SH020833  BAL0283            -1.   BAL0233             1.
    SH020134  COST            478.64   TRAN0201            1.
    SH020134  BAL0201            -1.   BAL0234             1.
    SH020234  COST             812.2   TRAN0202            1.
    SH020234  BAL0202            -1.   BAL0234             1.
    SH020334  COST            623.72   TRAN0203            1.
    SH020334  BAL0203            -1.   BAL0234             1.
    SH020434  COST            261.64   TRAN0204            1.
    SH020434  BAL0204            -1.   BAL0234             1.
    SH020534  COST            546.84   TRAN0205            1.
    SH020534  BAL0205            -1.   BAL0234             1.
    SH020834  COST            326.12   TRAN0208            1.
    SH020834  BAL0283            -1.   BAL0234             1.
    SH020435  COST            151.28   TRAN0204            1.
    SH020435  BAL0204            -1.   BAL0235             1.
    SH020636  COST             136.4   TRAN0206            1.
    SH020636  BAL0252            -1.   BAL0236             1.
    SH020137  COST            114.08   TRAN0201            1.
    SH020137  BAL0201            -1.   BAL0237             1.
    SH020237  COST            424.08   TRAN0202            1.
    SH020237  BAL0202            -1.   BAL0237             1.
    SH020337  COST            195.92   TRAN0203            1.
    SH020337  BAL0203            -1.   BAL0237             1.
    SH020437  COST            376.96   TRAN0204            1.
    SH020437  BAL0204            -1.   BAL0237             1.
    SH020537  COST            225.68   TRAN0205            1.
    SH020537  BAL0205            -1.   BAL0237             1.
    SH020637  COST            240.56   TRAN0206            1.
    SH020637  BAL0252            -1.   BAL0237             1.
    SH020837  COST            312.48   TRAN0208            1.
    SH020837  BAL0283            -1.   BAL0237             1.
    SH020138  COST            168.64   TRAN0201            1.
    SH020138  BAL0201            -1.   BAL0238             1.
    SH020238  COST            302.56   TRAN0202            1.
    SH020238  BAL0202            -1.   BAL0238             1.
    SH020338  COST             117.8   TRAN0203            1.
    SH020338  BAL0203            -1.   BAL0238             1.
    SH020438  COST            381.92   TRAN0204            1.
    SH020438  BAL0204            -1.   BAL0238             1.
    SH020538  COST            344.72   TRAN0205            1.
    SH020538  BAL0205            -1.   BAL0238             1.
    SH020638  COST             48.36   TRAN0206            1.
    SH020638  BAL0252            -1.   BAL0238             1.
    SH020738  COST            267.84   TRAN0207            1.
    SH020738  BAL0264            -1.   BAL0238             1.
    SH020838  COST            293.88   TRAN0208            1.
    SH020838  BAL0283            -1.   BAL0238             1.
    SH020139  COST             161.2   TRAN0201            1.
    SH020139  BAL0201            -1.   BAL0239             1.
    SH020140  COST             204.6   TRAN0201            1.
    SH020140  BAL0201            -1.   BAL0240             1.
    SH020240  COST            468.72   TRAN0202            1.
    SH020240  BAL0202            -1.   BAL0240             1.
    SH020340  COST            127.72   TRAN0203            1.
    SH020340  BAL0203            -1.   BAL0240             1.
    SH020440  COST            368.28   TRAN0204            1.
    SH020440  BAL0204            -1.   BAL0240             1.
    SH020540  COST            274.04   TRAN0205            1.
    SH020540  BAL0205            -1.   BAL0240             1.
    SH020640  COST            162.44   TRAN0206            1.
    SH020640  BAL0252            -1.   BAL0240             1.
    SH020840  COST            339.76   TRAN0208            1.
    SH020840  BAL0283            -1.   BAL0240             1.
    SH020641  COST              124.   TRAN0206            1.
    SH020641  BAL0252            -1.   BAL0241             1.
    SH020142  COST             111.6   TRAN0201            1.
    SH020142  BAL0201            -1.   BAL0242             1.
    SH020143  COST            197.16   TRAN0201            1.
    SH020143  BAL0201            -1.   BAL0243             1.
    SH020243  COST             489.8   TRAN0202            1.
    SH020243  BAL0202            -1.   BAL0243             1.
    SH020343  COST               31.   TRAN0203            1.
    SH020343  BAL0203            -1.   BAL0243             1.
    SH020443  COST            367.04   TRAN0204            1.
    SH020443  BAL0204            -1.   BAL0243             1.
    SH020543  COST            319.92   TRAN0205            1.
    SH020543  BAL0205            -1.   BAL0243             1.
    SH020643  COST              124.   TRAN0206            1.
    SH020643  BAL0252            -1.   BAL0243             1.
    SH020743  COST            298.84   TRAN0207            1.
    SH020743  BAL0264            -1.   BAL0243             1.
    SH020843  COST            336.04   TRAN0208            1.
    SH020843  BAL0283            -1.   BAL0243             1.
    SH020644  COST            110.36   TRAN0206            1.
    SH020644  BAL0252            -1.   BAL0244             1.
    SH020145  COST            213.28   TRAN0201            1.
    SH020145  BAL0201            -1.   BAL0245             1.
    SH020245  COST            540.64   TRAN0202            1.
    SH020245  BAL0202            -1.   BAL0245             1.
    SH020345  COST            199.64   TRAN0203            1.
    SH020345  BAL0203            -1.   BAL0245             1.
    SH020445  COST            362.08   TRAN0204            1.
    SH020445  BAL0204            -1.   BAL0245             1.
    SH020545  COST            290.16   TRAN0205            1.
    SH020545  BAL0205            -1.   BAL0245             1.
    SH020645  COST            236.84   TRAN0206            1.
    SH020645  BAL0252            -1.   BAL0245             1.
    SH020745  COST            244.28   TRAN0207            1.
    SH020745  BAL0264            -1.   BAL0245             1.
    SH020845  COST             378.2   TRAN0208            1.
    SH020845  BAL0283            -1.   BAL0245             1.
    SH020146  COST             303.8   TRAN0201            1.
    SH020146  BAL0201            -1.   BAL0246             1.
    SH020246  COST            338.52   TRAN0202            1.
    SH020246  BAL0202            -1.   BAL0246             1.
    SH020346  COST            274.04   TRAN0203            1.
    SH020346  BAL0203            -1.   BAL0246             1.
    SH020446  COST            554.28   TRAN0204            1.
    SH020446  BAL0204            -1.   BAL0246             1.
    SH020546  COST             533.2   TRAN0205            1.
    SH020546  BAL0205            -1.   BAL0246             1.
    SH020646  COST            318.68   TRAN0206            1.
    SH020646  BAL0252            -1.   BAL0246             1.
    SH020846  COST            555.52   TRAN0208            1.
    SH020846  BAL0283            -1.   BAL0246             1.
    SH020147  COST             136.4   TRAN0201            1.
    SH020147  BAL0201            -1.   BAL0247             1.
    SH020148  COST             117.8   TRAN0201            1.
    SH020148  BAL0201            -1.   BAL0248             1.
    SH020149  COST            407.96   TRAN0201            1.
    SH020149  BAL0201            -1.   BAL0249             1.
    SH020549  COST            188.48   TRAN0205            1.
    SH020549  BAL0205            -1.   BAL0249             1.
    SH020150  COST            298.84   TRAN0201            1.
    SH020150  BAL0201            -1.   BAL0250             1.
    SH020151  COST            411.68   TRAN0201            1.
    SH020151  BAL0201            -1.   BAL0251             1.
    SH020551  COST            152.52   TRAN0205            1.
    SH020551  BAL0205            -1.   BAL0251             1.
    SH020152  COST            138.88   TRAN0201            1.
    SH020152  BAL0201            -1.   BAL0252             1.
    SH020252  COST              372.   TRAN0202            1.
    SH020252  BAL0202            -1.   BAL0252             1.
    SH020352  COST            101.68   TRAN0203            1.
    SH020352  BAL0203            -1.   BAL0252             1.
    SH020452  COST            399.28   TRAN0204            1.
    SH020452  BAL0204            -1.   BAL0252             1.
    SH020552  COST             365.8   TRAN0205            1.
    SH020552  BAL0205            -1.   BAL0252             1.
    SH020852  COST            313.72   TRAN0208            1.
    SH020852  BAL0283            -1.   BAL0252             1.
    SH020153  COST            445.16   TRAN0201            1.
    SH020153  BAL0201            -1.   BAL0253             1.
    SH020253  COST            788.64   TRAN0202            1.
    SH020253  BAL0202            -1.   BAL0253             1.
    SH020353  COST              403.   TRAN0203            1.
    SH020353  BAL0203            -1.   BAL0253             1.
    SH020453  COST            510.88   TRAN0204            1.
    SH020453  BAL0204            -1.   BAL0253             1.
    SH020553  COST            228.16   TRAN0205            1.
    SH020553  BAL0205            -1.   BAL0253             1.
    SH020653  COST            445.16   TRAN0206            1.
    SH020653  BAL0252            -1.   BAL0253             1.
    SH020753  COST            181.04   TRAN0207            1.
    SH020753  BAL0264            -1.   BAL0253             1.
    SH020853  COST            499.72   TRAN0208            1.
    SH020853  BAL0283            -1.   BAL0253             1.
    SH020154  COST             229.4   TRAN0201            1.
    SH020154  BAL0201            -1.   BAL0254             1.
    SH020155  COST            344.72   TRAN0201            1.
    SH020155  BAL0201            -1.   BAL0255             1.
    SH020255  COST            593.96   TRAN0202            1.
    SH020255  BAL0202            -1.   BAL0255             1.
    SH020355  COST            348.44   TRAN0203            1.
    SH020355  BAL0203            -1.   BAL0255             1.
    SH020455  COST            364.56   TRAN0204            1.
    SH020455  BAL0204            -1.   BAL0255             1.
    SH020555  COST            190.96   TRAN0205            1.
    SH020555  BAL0205            -1.   BAL0255             1.
    SH020655  COST             359.6   TRAN0206            1.
    SH020655  BAL0252            -1.   BAL0255             1.
    SH020755  COST            132.68   TRAN0207            1.
    SH020755  BAL0264            -1.   BAL0255             1.
    SH020855  COST            364.56   TRAN0208            1.
    SH020855  BAL0283            -1.   BAL0255             1.
    SH020156  COST             483.6   TRAN0201            1.
    SH020156  BAL0201            -1.   BAL0256             1.
    SH020556  COST            168.64   TRAN0205            1.
    SH020556  BAL0205            -1.   BAL0256             1.
    SH020157  COST            323.64   TRAN0201            1.
    SH020157  BAL0201            -1.   BAL0257             1.
    SH020557  COST            208.32   TRAN0205            1.
    SH020557  BAL0205            -1.   BAL0257             1.
    SH020158  COST            364.56   TRAN0201            1.
    SH020158  BAL0201            -1.   BAL0258             1.
    SH020258  COST            646.04   TRAN0202            1.
    SH020258  BAL0202            -1.   BAL0258             1.
    SH020358  COST            344.72   TRAN0203            1.
    SH020358  BAL0203            -1.   BAL0258             1.
    SH020458  COST            425.32   TRAN0204            1.
    SH020458  BAL0204            -1.   BAL0258             1.
    SH020558  COST             26.04   TRAN0205            1.
    SH020558  BAL0205            -1.   BAL0258             1.
    SH020658  COST            404.24   TRAN0206            1.
    SH020658  BAL0252            -1.   BAL0258             1.
    SH020758  COST             84.32   TRAN0207            1.
    SH020758  BAL0264            -1.   BAL0258             1.
    SH020858  COST            314.96   TRAN0208            1.
    SH020858  BAL0283            -1.   BAL0258             1.
    SH020159  COST            255.44   TRAN0201            1.
    SH020159  BAL0201            -1.   BAL0259             1.
    SH020259  COST            617.52   TRAN0202            1.
    SH020259  BAL0202            -1.   BAL0259             1.
    SH020359  COST            295.12   TRAN0203            1.
    SH020359  BAL0203            -1.   BAL0259             1.
    SH020459  COST            302.56   TRAN0204            1.
    SH020459  BAL0204            -1.   BAL0259             1.
    SH020559  COST            197.16   TRAN0205            1.
    SH020559  BAL0205            -1.   BAL0259             1.
    SH020659  COST            368.28   TRAN0206            1.
    SH020659  BAL0252            -1.   BAL0259             1.
    SH020759  COST             130.2   TRAN0207            1.
    SH020759  BAL0264            -1.   BAL0259             1.
    SH020859  COST             316.2   TRAN0208            1.
    SH020859  BAL0283            -1.   BAL0259             1.
    SH020160  COST            323.64   TRAN0201            1.
    SH020160  BAL0201            -1.   BAL0260             1.
    SH020260  COST              682.   TRAN0202            1.
    SH020260  BAL0202            -1.   BAL0260             1.
    SH020360  COST            350.92   TRAN0203            1.
    SH020360  BAL0203            -1.   BAL0260             1.
    SH020460  COST            386.88   TRAN0204            1.
    SH020460  BAL0204            -1.   BAL0260             1.
    SH020560  COST             167.4   TRAN0205            1.
    SH020560  BAL0205            -1.   BAL0260             1.
    SH020660  COST            400.52   TRAN0206            1.
    SH020660  BAL0252            -1.   BAL0260             1.
    SH020760  COST            109.12   TRAN0207            1.
    SH020760  BAL0264            -1.   BAL0260             1.
    SH020860  COST            370.76   TRAN0208            1.
    SH020860  BAL0283            -1.   BAL0260             1.
    SH020163  COST            329.84   TRAN0201            1.
    SH020163  BAL0201            -1.   BAL0263             1.
    SH020563  COST            188.48   TRAN0205            1.
    SH020563  BAL0205            -1.   BAL0263             1.
    SH020164  COST            246.76   TRAN0201            1.
    SH020164  BAL0201            -1.   BAL0264             1.
    SH020264  COST            652.24   TRAN0202            1.
    SH020264  BAL0202            -1.   BAL0264             1.
    SH020364  COST            276.52   TRAN0203            1.
    SH020364  BAL0203            -1.   BAL0264             1.
    SH020464  COST            416.64   TRAN0204            1.
    SH020464  BAL0204            -1.   BAL0264             1.
    SH020564  COST             71.92   TRAN0205            1.
    SH020564  BAL0205            -1.   BAL0264             1.
    SH020664  COST            393.08   TRAN0206            1.
    SH020664  BAL0252            -1.   BAL0264             1.
    SH020864  COST              310.   TRAN0208            1.
    SH020864  BAL0283            -1.   BAL0264             1.
    SH020265  COST            380.68   TRAN0202            1.
    SH020265  BAL0202            -1.   BAL0265             1.
    SH020266  COST            321.16   TRAN0202            1.
    SH020266  BAL0202            -1.   BAL0266             1.
    SH020267  COST            287.68   TRAN0202            1.
    SH020267  BAL0202            -1.   BAL0267             1.
    SH020268  COST              496.   TRAN0202            1.
    SH020268  BAL0202            -1.   BAL0268             1.
    SH020269  COST            274.04   TRAN0202            1.
    SH020269  BAL0202            -1.   BAL0269             1.
    SH020171  COST             545.6   TRAN0201            1.
    SH020171  BAL0201            -1.   BAL0271             1.
    SH020371  COST            649.76   TRAN0203            1.
    SH020371  BAL0203            -1.   BAL0271             1.
    SH020471  COST            646.04   TRAN0204            1.
    SH020471  BAL0204            -1.   BAL0271             1.
    SH020571  COST            720.44   TRAN0205            1.
    SH020571  BAL0205            -1.   BAL0271             1.
    SH020671  COST            484.84   TRAN0206            1.
    SH020671  BAL0252            -1.   BAL0271             1.
    SH020771  COST            872.96   TRAN0207            1.
    SH020771  BAL0264            -1.   BAL0271             1.
    SH020871  COST            660.92   TRAN0208            1.
    SH020871  BAL0283            -1.   BAL0271             1.
    SH020272  COST            673.32   TRAN0202            1.
    SH020272  BAL0202            -1.   BAL0272             1.
    SH020173  COST             483.6   TRAN0201            1.
    SH020173  BAL0201            -1.   BAL0273             1.
    SH020273  COST             452.6   TRAN0202            1.
    SH020273  BAL0202            -1.   BAL0273             1.
    SH020373  COST            419.12   TRAN0203            1.
    SH020373  BAL0203            -1.   BAL0273             1.
    SH020473  COST            566.68   TRAN0204            1.
    SH020473  BAL0204            -1.   BAL0273             1.
    SH020573  COST            699.36   TRAN0205            1.
    SH020573  BAL0205            -1.   BAL0273             1.
    SH020673  COST             378.2   TRAN0206            1.
    SH020673  BAL0252            -1.   BAL0273             1.
    SH020873  COST            624.96   TRAN0208            1.
    SH020873  BAL0283            -1.   BAL0273             1.
    SH020274  COST             260.4   TRAN0202            1.
    SH020274  BAL0202            -1.   BAL0274             1.
    SH020275  COST            686.96   TRAN0202            1.
    SH020275  BAL0202            -1.   BAL0275             1.
    SH020276  COST            497.24   TRAN0202            1.
    SH020276  BAL0202            -1.   BAL0276             1.
    SH020177  COST             539.4   TRAN0201            1.
    SH020177  BAL0201            -1.   BAL0277             1.
    SH020277  COST            337.28   TRAN0202            1.
    SH020277  BAL0202            -1.   BAL0277             1.
    SH020377  COST            571.64   TRAN0203            1.
    SH020377  BAL0203            -1.   BAL0277             1.
    SH020477  COST            497.24   TRAN0204            1.
    SH020477  BAL0204            -1.   BAL0277             1.
    SH020577  COST             694.4   TRAN0205            1.
    SH020577  BAL0205            -1.   BAL0277             1.
    SH020877  COST             396.8   TRAN0208            1.
    SH020877  BAL0283            -1.   BAL0277             1.
    SH020178  COST            943.64   TRAN0201            1.
    SH020178  BAL0201            -1.   BAL0278             1.
    SH020278  COST            548.08   TRAN0202            1.
    SH020278  BAL0202            -1.   BAL0278             1.
    SH020378  COST            970.92   TRAN0203            1.
    SH020378  BAL0203            -1.   BAL0278             1.
    SH020478  COST             849.4   TRAN0204            1.
    SH020478  BAL0204            -1.   BAL0278             1.
    SH020578  COST           1089.96   TRAN0205            1.
    SH020578  BAL0205            -1.   BAL0278             1.
    SH020878  COST            949.84   TRAN0208            1.
    SH020878  BAL0283            -1.   BAL0278             1.
    SH020279  COST            333.56   TRAN0202            1.
    SH020279  BAL0202            -1.   BAL0279             1.
    SH020480  COST            463.76   TRAN0204            1.
    SH020480  BAL0204            -1.   BAL0280             1.
    SH020182  COST            721.68   TRAN0201            1.
    SH020182  BAL0201            -1.   BAL0282             1.
    SH020282  COST            407.96   TRAN0202            1.
    SH020282  BAL0202            -1.   BAL0282             1.
    SH020382  COST             812.2   TRAN0203            1.
    SH020382  BAL0203            -1.   BAL0282             1.
    SH020482  COST            875.44   TRAN0204            1.
    SH020482  BAL0204            -1.   BAL0282             1.
    SH020582  COST           1422.28   TRAN0205            1.
    SH020582  BAL0205            -1.   BAL0282             1.
    SH020882  COST            970.92   TRAN0208            1.
    SH020882  BAL0283            -1.   BAL0282             1.
    SH020183  COST            219.48   TRAN0201            1.
    SH020183  BAL0201            -1.   BAL0283             1.
    SH020283  COST             644.8   TRAN0202            1.
    SH020283  BAL0202            -1.   BAL0283             1.
    SH020383  COST            337.28   TRAN0203            1.
    SH020383  BAL0203            -1.   BAL0283             1.
    SH020483  COST             73.16   TRAN0204            1.
    SH020483  BAL0204            -1.   BAL0283             1.
    SH020583  COST            430.28   TRAN0205            1.
    SH020583  BAL0205            -1.   BAL0283             1.
    SH020683  COST            307.52   TRAN0206            1.
    SH020683  BAL0252            -1.   BAL0283             1.
    SH020284  COST            238.08   TRAN0202            1.
    SH020284  BAL0202            -1.   BAL0284             1.
    SH030201  COST            368.28   TRAN0302            1.
    SH030201  BAL0302            -1.   BAL0301             1.
    SH030301  COST            141.36   TRAN0303            1.
    SH030301  BAL0303            -1.   BAL0301             1.
    SH030401  COST            257.92   TRAN0304            1.
    SH030401  BAL0304            -1.   BAL0301             1.
    SH030501  COST            293.88   TRAN0305            1.
    SH030501  BAL0305            -1.   BAL0301             1.
    SH030601  COST            156.24   TRAN0306            1.
    SH030601  BAL0352            -1.   BAL0301             1.
    SH030801  COST            177.32   TRAN0308            1.
    SH030801  BAL0383            -1.   BAL0301             1.
    SH030102  COST            587.76   TRAN0301            1.
    SH030102  BAL0301            -1.   BAL0302             1.
    SH030302  COST            517.08   TRAN0303            1.
    SH030302  BAL0303            -1.   BAL0302             1.
    SH030402  COST            758.88   TRAN0304            1.
    SH030402  BAL0304            -1.   BAL0302             1.
    SH030502  COST            918.84   TRAN0305            1.
    SH030502  BAL0305            -1.   BAL0302             1.
    SH030602  COST            468.72   TRAN0306            1.
    SH030602  BAL0352            -1.   BAL0302             1.
    SH030802  COST            646.04   TRAN0308            1.
    SH030802  BAL0383            -1.   BAL0302             1.
    SH030103  COST             303.8   TRAN0301            1.
    SH030103  BAL0301            -1.   BAL0303             1.
    SH030203  COST            587.76   TRAN0302            1.
    SH030203  BAL0302            -1.   BAL0303             1.
    SH030403  COST            455.08   TRAN0304            1.
    SH030403  BAL0304            -1.   BAL0303             1.
    SH030503  COST            352.16   TRAN0305            1.
    SH030503  BAL0305            -1.   BAL0303             1.
    SH030603  COST             111.6   TRAN0306            1.
    SH030603  BAL0352            -1.   BAL0303             1.
    SH030803  COST             316.2   TRAN0308            1.
    SH030803  BAL0383            -1.   BAL0303             1.
    SH030104  COST            215.76   TRAN0301            1.
    SH030104  BAL0301            -1.   BAL0304             1.
    SH030204  COST            623.72   TRAN0302            1.
    SH030204  BAL0302            -1.   BAL0304             1.
    SH030304  COST            301.32   TRAN0303            1.
    SH030304  BAL0303            -1.   BAL0304             1.
    SH030504  COST            395.56   TRAN0305            1.
    SH030504  BAL0305            -1.   BAL0304             1.
    SH030604  COST             303.8   TRAN0306            1.
    SH030604  BAL0352            -1.   BAL0304             1.
    SH030804  COST             71.92   TRAN0308            1.
    SH030804  BAL0383            -1.   BAL0304             1.
    SH030105  COST             334.8   TRAN0301            1.
    SH030105  BAL0301            -1.   BAL0305             1.
    SH030205  COST            639.84   TRAN0302            1.
    SH030205  BAL0302            -1.   BAL0305             1.
    SH030305  COST            352.16   TRAN0303            1.
    SH030305  BAL0303            -1.   BAL0305             1.
    SH030405  COST             353.4   TRAN0304            1.
    SH030405  BAL0304            -1.   BAL0305             1.
    SH030605  COST            404.24   TRAN0306            1.
    SH030605  BAL0352            -1.   BAL0305             1.
    SH030705  COST            414.16   TRAN0307            1.
    SH030705  BAL0364            -1.   BAL0305             1.
    SH030805  COST            336.04   TRAN0308            1.
    SH030805  BAL0383            -1.   BAL0305             1.
    SH030106  COST            246.76   TRAN0301            1.
    SH030106  BAL0301            -1.   BAL0306             1.
    SH030107  COST             26.04   TRAN0301            1.
    SH030107  BAL0301            -1.   BAL0307             1.
    SH030207  COST            362.08   TRAN0302            1.
    SH030207  BAL0302            -1.   BAL0307             1.
    SH030307  COST            153.76   TRAN0303            1.
    SH030307  BAL0303            -1.   BAL0307             1.
    SH030407  COST            256.68   TRAN0304            1.
    SH030407  BAL0304            -1.   BAL0307             1.
    SH030507  COST            283.96   TRAN0305            1.
    SH030507  BAL0305            -1.   BAL0307             1.
    SH030607  COST              155.   TRAN0306            1.
    SH030607  BAL0352            -1.   BAL0307             1.
    SH030707  COST            287.68   TRAN0307            1.
    SH030707  BAL0364            -1.   BAL0307             1.
    SH030807  COST             192.2   TRAN0308            1.
    SH030807  BAL0383            -1.   BAL0307             1.
    SH030108  COST             81.84   TRAN0301            1.
    SH030108  BAL0301            -1.   BAL0308             1.
    SH030208  COST            466.24   TRAN0302            1.
    SH030208  BAL0302            -1.   BAL0308             1.
    SH030308  COST            174.84   TRAN0303            1.
    SH030308  BAL0303            -1.   BAL0308             1.
    SH030408  COST            306.28   TRAN0304            1.
    SH030408  BAL0304            -1.   BAL0308             1.
    SH030508  COST            225.68   TRAN0305            1.
    SH030508  BAL0305            -1.   BAL0308             1.
    SH030608  COST            205.84   TRAN0306            1.
    SH030608  BAL0352            -1.   BAL0308             1.
    SH030808  COST            231.88   TRAN0308            1.
    SH030808  BAL0383            -1.   BAL0308             1.
    SH030109  COST            171.12   TRAN0301            1.
    SH030109  BAL0301            -1.   BAL0309             1.
    SH030110  COST            306.28   TRAN0301            1.
    SH030110  BAL0301            -1.   BAL0310             1.
    SH030210  COST            195.92   TRAN0302            1.
    SH030210  BAL0302            -1.   BAL0310             1.
    SH030310  COST             297.6   TRAN0303            1.
    SH030310  BAL0303            -1.   BAL0310             1.
    SH030410  COST            445.16   TRAN0304            1.
    SH030410  BAL0304            -1.   BAL0310             1.
    SH030510  COST             477.4   TRAN0305            1.
    SH030510  BAL0305            -1.   BAL0310             1.
    SH030610  COST              279.   TRAN0306            1.
    SH030610  BAL0352            -1.   BAL0310             1.
    SH030810  COST             378.2   TRAN0308            1.
    SH030810  BAL0383            -1.   BAL0310             1.
    SH030111  COST            131.44   TRAN0301            1.
    SH030111  BAL0301            -1.   BAL0311             1.
    SH030112  COST            109.12   TRAN0301            1.
    SH030112  BAL0301            -1.   BAL0312             1.
    SH030114  COST            176.08   TRAN0301            1.
    SH030114  BAL0301            -1.   BAL0314             1.
    SH030614  COST            233.12   TRAN0306            1.
    SH030614  BAL0352            -1.   BAL0314             1.
    SH030115  COST            375.72   TRAN0301            1.
    SH030115  BAL0301            -1.   BAL0315             1.
    SH030215  COST            197.16   TRAN0302            1.
    SH030215  BAL0302            -1.   BAL0315             1.
    SH030315  COST            290.16   TRAN0303            1.
    SH030315  BAL0303            -1.   BAL0315             1.
    SH030415  COST            590.24   TRAN0304            1.
    SH030415  BAL0304            -1.   BAL0315             1.
    SH030515  COST            493.52   TRAN0305            1.
    SH030515  BAL0305            -1.   BAL0315             1.
    SH030615  COST            233.12   TRAN0306            1.
    SH030615  BAL0352            -1.   BAL0315             1.
    SH030815  COST            462.52   TRAN0308            1.
    SH030815  BAL0383            -1.   BAL0315             1.
    SH030116  COST            195.92   TRAN0301            1.
    SH030116  BAL0301            -1.   BAL0316             1.
    SH030216  COST             347.2   TRAN0302            1.
    SH030216  BAL0302            -1.   BAL0316             1.
    SH030316  COST            281.48   TRAN0303            1.
    SH030316  BAL0303            -1.   BAL0316             1.
    SH030416  COST            355.88   TRAN0304            1.
    SH030416  BAL0304            -1.   BAL0316             1.
    SH030516  COST            395.56   TRAN0305            1.
    SH030516  BAL0305            -1.   BAL0316             1.
    SH030616  COST            162.44   TRAN0306            1.
    SH030616  BAL0352            -1.   BAL0316             1.
    SH030816  COST             254.2   TRAN0308            1.
    SH030816  BAL0383            -1.   BAL0316             1.
    SH030117  COST            187.24   TRAN0301            1.
    SH030117  BAL0301            -1.   BAL0317             1.
    SH030817  COST             33.48   TRAN0308            1.
    SH030817  BAL0383            -1.   BAL0317             1.
    SH030418  COST            190.96   TRAN0304            1.
    SH030418  BAL0304            -1.   BAL0318             1.
    SH030119  COST            307.52   TRAN0301            1.
    SH030119  BAL0301            -1.   BAL0319             1.
    SH030219  COST            851.88   TRAN0302            1.
    SH030219  BAL0302            -1.   BAL0319             1.
    SH030319  COST            393.08   TRAN0303            1.
    SH030319  BAL0303            -1.   BAL0319             1.
    SH030419  COST            197.16   TRAN0304            1.
    SH030419  BAL0304            -1.   BAL0319             1.
    SH030519  COST            257.92   TRAN0305            1.
    SH030519  BAL0305            -1.   BAL0319             1.
    SH030619  COST             427.8   TRAN0306            1.
    SH030619  BAL0352            -1.   BAL0319             1.
    SH030819  COST            122.76   TRAN0308            1.
    SH030819  BAL0383            -1.   BAL0319             1.
    SH030120  COST             254.2   TRAN0301            1.
    SH030120  BAL0301            -1.   BAL0320             1.
    SH030220  COST            846.92   TRAN0302            1.
    SH030220  BAL0302            -1.   BAL0320             1.
    SH030320  COST            368.28   TRAN0303            1.
    SH030320  BAL0303            -1.   BAL0320             1.
    SH030420  COST            140.12   TRAN0304            1.
    SH030420  BAL0304            -1.   BAL0320             1.
    SH030520  COST            360.84   TRAN0305            1.
    SH030520  BAL0305            -1.   BAL0320             1.
    SH030820  COST            156.24   TRAN0308            1.
    SH030820  BAL0383            -1.   BAL0320             1.
    SH030121  COST            499.72   TRAN0301            1.
    SH030121  BAL0301            -1.   BAL0321             1.
    SH030221  COST            456.32   TRAN0302            1.
    SH030221  BAL0302            -1.   BAL0321             1.
    SH030321  COST            553.04   TRAN0303            1.
    SH030321  BAL0303            -1.   BAL0321             1.
    SH030421  COST             396.8   TRAN0304            1.
    SH030421  BAL0304            -1.   BAL0321             1.
    SH030521  COST              682.   TRAN0305            1.
    SH030521  BAL0305            -1.   BAL0321             1.
    SH030821  COST             396.8   TRAN0308            1.
    SH030821  BAL0383            -1.   BAL0321             1.
    SH030422  COST            277.76   TRAN0304            1.
    SH030422  BAL0304            -1.   BAL0322             1.
    SH030423  COST            207.08   TRAN0304            1.
    SH030423  BAL0304            -1.   BAL0323             1.
    SH030124  COST           1780.64   TRAN0301            1.
    SH030124  BAL0301            -1.   BAL0324             1.
    SH030225  COST            529.48   TRAN0302            1.
    SH030225  BAL0302            -1.   BAL0325             1.
    SH030426  COST             334.8   TRAN0304            1.
    SH030426  BAL0304            -1.   BAL0326             1.
    SH030627  COST            332.32   TRAN0306            1.
    SH030627  BAL0352            -1.   BAL0327             1.
    SH030128  COST            301.32   TRAN0301            1.
    SH030128  BAL0301            -1.   BAL0328             1.
    SH030528  COST            126.48   TRAN0305            1.
    SH030528  BAL0305            -1.   BAL0328             1.
    SH030429  COST            246.76   TRAN0304            1.
    SH030429  BAL0304            -1.   BAL0329             1.
    SH030430  COST            376.96   TRAN0304            1.
    SH030430  BAL0304            -1.   BAL0330             1.
    SH030131  COST            137.64   TRAN0301            1.
    SH030131  BAL0301            -1.   BAL0331             1.
    SH030432  COST            194.68   TRAN0304            1.
    SH030432  BAL0304            -1.   BAL0332             1.
    SH030133  COST            611.32   TRAN0301            1.
    SH030133  BAL0301            -1.   BAL0333             1.
    SH030233  COST              496.   TRAN0302            1.
    SH030233  BAL0302            -1.   BAL0333             1.
    SH030333  COST            673.32   TRAN0303            1.
    SH030333  BAL0303            -1.   BAL0333             1.
    SH030433  COST             551.8   TRAN0304            1.
    SH030433  BAL0304            -1.   BAL0333             1.
    SH030533  COST            782.44   TRAN0305            1.
    SH030533  BAL0305            -1.   BAL0333             1.
    SH030833  COST            472.44   TRAN0308            1.
    SH030833  BAL0383            -1.   BAL0333             1.
    SH030134  COST            478.64   TRAN0301            1.
    SH030134  BAL0301            -1.   BAL0334             1.
    SH030234  COST             812.2   TRAN0302            1.
    SH030234  BAL0302            -1.   BAL0334             1.
    SH030334  COST            623.72   TRAN0303            1.
    SH030334  BAL0303            -1.   BAL0334             1.
    SH030434  COST            261.64   TRAN0304            1.
    SH030434  BAL0304            -1.   BAL0334             1.
    SH030534  COST            546.84   TRAN0305            1.
    SH030534  BAL0305            -1.   BAL0334             1.
    SH030834  COST            326.12   TRAN0308            1.
    SH030834  BAL0383            -1.   BAL0334             1.
    SH030435  COST            151.28   TRAN0304            1.
    SH030435  BAL0304            -1.   BAL0335             1.
    SH030636  COST             136.4   TRAN0306            1.
    SH030636  BAL0352            -1.   BAL0336             1.
    SH030137  COST            114.08   TRAN0301            1.
    SH030137  BAL0301            -1.   BAL0337             1.
    SH030237  COST            424.08   TRAN0302            1.
    SH030237  BAL0302            -1.   BAL0337             1.
    SH030337  COST            195.92   TRAN0303            1.
    SH030337  BAL0303            -1.   BAL0337             1.
    SH030437  COST            376.96   TRAN0304            1.
    SH030437  BAL0304            -1.   BAL0337             1.
    SH030537  COST            225.68   TRAN0305            1.
    SH030537  BAL0305            -1.   BAL0337             1.
    SH030637  COST            240.56   TRAN0306            1.
    SH030637  BAL0352            -1.   BAL0337             1.
    SH030837  COST            312.48   TRAN0308            1.
    SH030837  BAL0383            -1.   BAL0337             1.
    SH030138  COST            168.64   TRAN0301            1.
    SH030138  BAL0301            -1.   BAL0338             1.
    SH030238  COST            302.56   TRAN0302            1.
    SH030238  BAL0302            -1.   BAL0338             1.
    SH030338  COST             117.8   TRAN0303            1.
    SH030338  BAL0303            -1.   BAL0338             1.
    SH030438  COST            381.92   TRAN0304            1.
    SH030438  BAL0304            -1.   BAL0338             1.
    SH030538  COST            344.72   TRAN0305            1.
    SH030538  BAL0305            -1.   BAL0338             1.
    SH030638  COST             48.36   TRAN0306            1.
    SH030638  BAL0352            -1.   BAL0338             1.
    SH030738  COST            267.84   TRAN0307            1.
    SH030738  BAL0364            -1.   BAL0338             1.
    SH030838  COST            293.88   TRAN0308            1.
    SH030838  BAL0383            -1.   BAL0338             1.
    SH030139  COST             161.2   TRAN0301            1.
    SH030139  BAL0301            -1.   BAL0339             1.
    SH030140  COST             204.6   TRAN0301            1.
    SH030140  BAL0301            -1.   BAL0340             1.
    SH030240  COST            468.72   TRAN0302            1.
    SH030240  BAL0302            -1.   BAL0340             1.
    SH030340  COST            127.72   TRAN0303            1.
    SH030340  BAL0303            -1.   BAL0340             1.
    SH030440  COST            368.28   TRAN0304            1.
    SH030440  BAL0304            -1.   BAL0340             1.
    SH030540  COST            274.04   TRAN0305            1.
    SH030540  BAL0305            -1.   BAL0340             1.
    SH030640  COST            162.44   TRAN0306            1.
    SH030640  BAL0352            -1.   BAL0340             1.
    SH030840  COST            339.76   TRAN0308            1.
    SH030840  BAL0383            -1.   BAL0340             1.
    SH030641  COST              124.   TRAN0306            1.
    SH030641  BAL0352            -1.   BAL0341             1.
    SH030142  COST             111.6   TRAN0301            1.
    SH030142  BAL0301            -1.   BAL0342             1.
    SH030143  COST            197.16   TRAN0301            1.
    SH030143  BAL0301            -1.   BAL0343             1.
    SH030243  COST             489.8   TRAN0302            1.
    SH030243  BAL0302            -1.   BAL0343             1.
    SH030343  COST               31.   TRAN0303            1.
    SH030343  BAL0303            -1.   BAL0343             1.
    SH030443  COST            367.04   TRAN0304            1.
    SH030443  BAL0304            -1.   BAL0343             1.
    SH030543  COST            319.92   TRAN0305            1.
    SH030543  BAL0305            -1.   BAL0343             1.
    SH030643  COST              124.   TRAN0306            1.
    SH030643  BAL0352            -1.   BAL0343             1.
    SH030743  COST            298.84   TRAN0307            1.
    SH030743  BAL0364            -1.   BAL0343             1.
    SH030843  COST            336.04   TRAN0308            1.
    SH030843  BAL0383            -1.   BAL0343             1.
    SH030644  COST            110.36   TRAN0306            1.
    SH030644  BAL0352            -1.   BAL0344             1.
    SH030145  COST            213.28   TRAN0301            1.
    SH030145  BAL0301            -1.   BAL0345             1.
    SH030245  COST            540.64   TRAN0302            1.
    SH030245  BAL0302            -1.   BAL0345             1.
    SH030345  COST            199.64   TRAN0303            1.
    SH030345  BAL0303            -1.   BAL0345             1.
    SH030445  COST            362.08   TRAN0304            1.
    SH030445  BAL0304            -1.   BAL0345             1.
    SH030545  COST            290.16   TRAN0305            1.
    SH030545  BAL0305            -1.   BAL0345             1.
    SH030645  COST            236.84   TRAN0306            1.
    SH030645  BAL0352            -1.   BAL0345             1.
    SH030745  COST            244.28   TRAN0307            1.
    SH030745  BAL0364            -1.   BAL0345             1.
    SH030845  COST             378.2   TRAN0308            1.
    SH030845  BAL0383            -1.   BAL0345             1.
    SH030146  COST             303.8   TRAN0301            1.
    SH030146  BAL0301            -1.   BAL0346             1.
    SH030246  COST            338.52   TRAN0302            1.
    SH030246  BAL0302            -1.   BAL0346             1.
    SH030346  COST            274.04   TRAN0303            1.
    SH030346  BAL0303            -1.   BAL0346             1.
    SH030446  COST            554.28   TRAN0304            1.
    SH030446  BAL0304            -1.   BAL0346             1.
    SH030546  COST             533.2   TRAN0305            1.
    SH030546  BAL0305            -1.   BAL0346             1.
    SH030646  COST            318.68   TRAN0306            1.
    SH030646  BAL0352            -1.   BAL0346             1.
    SH030846  COST            555.52   TRAN0308            1.
    SH030846  BAL0383            -1.   BAL0346             1.
    SH030147  COST             136.4   TRAN0301            1.
    SH030147  BAL0301            -1.   BAL0347             1.
    SH030148  COST             117.8   TRAN0301            1.
    SH030148  BAL0301            -1.   BAL0348             1.
    SH030149  COST            407.96   TRAN0301            1.
    SH030149  BAL0301            -1.   BAL0349             1.
    SH030549  COST            188.48   TRAN0305            1.
    SH030549  BAL0305            -1.   BAL0349             1.
    SH030150  COST            298.84   TRAN0301            1.
    SH030150  BAL0301            -1.   BAL0350             1.
    SH030151  COST            411.68   TRAN0301            1.
    SH030151  BAL0301            -1.   BAL0351             1.
    SH030551  COST            152.52   TRAN0305            1.
    SH030551  BAL0305            -1.   BAL0351             1.
    SH030152  COST            138.88   TRAN0301            1.
    SH030152  BAL0301            -1.   BAL0352             1.
    SH030252  COST              372.   TRAN0302            1.
    SH030252  BAL0302            -1.   BAL0352             1.
    SH030352  COST            101.68   TRAN0303            1.
    SH030352  BAL0303            -1.   BAL0352             1.
    SH030452  COST            399.28   TRAN0304            1.
    SH030452  BAL0304            -1.   BAL0352             1.
    SH030552  COST             365.8   TRAN0305            1.
    SH030552  BAL0305            -1.   BAL0352             1.
    SH030852  COST            313.72   TRAN0308            1.
    SH030852  BAL0383            -1.   BAL0352             1.
    SH030153  COST            445.16   TRAN0301            1.
    SH030153  BAL0301            -1.   BAL0353             1.
    SH030253  COST            788.64   TRAN0302            1.
    SH030253  BAL0302            -1.   BAL0353             1.
    SH030353  COST              403.   TRAN0303            1.
    SH030353  BAL0303            -1.   BAL0353             1.
    SH030453  COST            510.88   TRAN0304            1.
    SH030453  BAL0304            -1.   BAL0353             1.
    SH030553  COST            228.16   TRAN0305            1.
    SH030553  BAL0305            -1.   BAL0353             1.
    SH030653  COST            445.16   TRAN0306            1.
    SH030653  BAL0352            -1.   BAL0353             1.
    SH030753  COST            181.04   TRAN0307            1.
    SH030753  BAL0364            -1.   BAL0353             1.
    SH030853  COST            499.72   TRAN0308            1.
    SH030853  BAL0383            -1.   BAL0353             1.
    SH030154  COST             229.4   TRAN0301            1.
    SH030154  BAL0301            -1.   BAL0354             1.
    SH030155  COST            344.72   TRAN0301            1.
    SH030155  BAL0301            -1.   BAL0355             1.
    SH030255  COST            593.96   TRAN0302            1.
    SH030255  BAL0302            -1.   BAL0355             1.
    SH030355  COST            348.44   TRAN0303            1.
    SH030355  BAL0303            -1.   BAL0355             1.
    SH030455  COST            364.56   TRAN0304            1.
    SH030455  BAL0304            -1.   BAL0355             1.
    SH030555  COST            190.96   TRAN0305            1.
    SH030555  BAL0305            -1.   BAL0355             1.
    SH030655  COST             359.6   TRAN0306            1.
    SH030655  BAL0352            -1.   BAL0355             1.
    SH030755  COST            132.68   TRAN0307            1.
    SH030755  BAL0364            -1.   BAL0355             1.
    SH030855  COST            364.56   TRAN0308            1.
    SH030855  BAL0383            -1.   BAL0355             1.
    SH030156  COST             483.6   TRAN0301            1.
    SH030156  BAL0301            -1.   BAL0356             1.
    SH030556  COST            168.64   TRAN0305            1.
    SH030556  BAL0305            -1.   BAL0356             1.
    SH030157  COST            323.64   TRAN0301            1.
    SH030157  BAL0301            -1.   BAL0357             1.
    SH030557  COST            208.32   TRAN0305            1.
    SH030557  BAL0305            -1.   BAL0357             1.
    SH030158  COST            364.56   TRAN0301            1.
    SH030158  BAL0301            -1.   BAL0358             1.
    SH030258  COST            646.04   TRAN0302            1.
    SH030258  BAL0302            -1.   BAL0358             1.
    SH030358  COST            344.72   TRAN0303            1.
    SH030358  BAL0303            -1.   BAL0358             1.
    SH030458  COST            425.32   TRAN0304            1.
    SH030458  BAL0304            -1.   BAL0358             1.
    SH030558  COST             26.04   TRAN0305            1.
    SH030558  BAL0305            -1.   BAL0358             1.
    SH030658  COST            404.24   TRAN0306            1.
    SH030658  BAL0352            -1.   BAL0358             1.
    SH030758  COST             84.32   TRAN0307            1.
    SH030758  BAL0364            -1.   BAL0358             1.
    SH030858  COST            314.96   TRAN0308            1.
    SH030858  BAL0383            -1.   BAL0358             1.
    SH030159  COST            255.44   TRAN0301            1.
    SH030159  BAL0301            -1.   BAL0359             1.
    SH030259  COST            617.52   TRAN0302            1.
    SH030259  BAL0302            -1.   BAL0359             1.
    SH030359  COST            295.12   TRAN0303            1.
    SH030359  BAL0303            -1.   BAL0359             1.
    SH030459  COST            302.56   TRAN0304            1.
    SH030459  BAL0304            -1.   BAL0359             1.
    SH030559  COST            197.16   TRAN0305            1.
    SH030559  BAL0305            -1.   BAL0359             1.
    SH030659  COST            368.28   TRAN0306            1.
    SH030659  BAL0352            -1.   BAL0359             1.
    SH030759  COST             130.2   TRAN0307            1.
    SH030759  BAL0364            -1.   BAL0359             1.
    SH030859  COST             316.2   TRAN0308            1.
    SH030859  BAL0383            -1.   BAL0359             1.
    SH030160  COST            323.64   TRAN0301            1.
    SH030160  BAL0301            -1.   BAL0360             1.
    SH030260  COST              682.   TRAN0302            1.
    SH030260  BAL0302            -1.   BAL0360             1.
    SH030360  COST            350.92   TRAN0303            1.
    SH030360  BAL0303            -1.   BAL0360             1.
    SH030460  COST            386.88   TRAN0304            1.
    SH030460  BAL0304            -1.   BAL0360             1.
    SH030560  COST             167.4   TRAN0305            1.
    SH030560  BAL0305            -1.   BAL0360             1.
    SH030660  COST            400.52   TRAN0306            1.
    SH030660  BAL0352            -1.   BAL0360             1.
    SH030760  COST            109.12   TRAN0307            1.
    SH030760  BAL0364            -1.   BAL0360             1.
    SH030860  COST            370.76   TRAN0308            1.
    SH030860  BAL0383            -1.   BAL0360             1.
    SH030163  COST            329.84   TRAN0301            1.
    SH030163  BAL0301            -1.   BAL0363             1.
    SH030563  COST            188.48   TRAN0305            1.
    SH030563  BAL0305            -1.   BAL0363             1.
    SH030164  COST            246.76   TRAN0301            1.
    SH030164  BAL0301            -1.   BAL0364             1.
    SH030264  COST            652.24   TRAN0302            1.
    SH030264  BAL0302            -1.   BAL0364             1.
    SH030364  COST            276.52   TRAN0303            1.
    SH030364  BAL0303            -1.   BAL0364             1.
    SH030464  COST            416.64   TRAN0304            1.
    SH030464  BAL0304            -1.   BAL0364             1.
    SH030564  COST             71.92   TRAN0305            1.
    SH030564  BAL0305            -1.   BAL0364             1.
    SH030664  COST            393.08   TRAN0306            1.
    SH030664  BAL0352            -1.   BAL0364             1.
    SH030864  COST              310.   TRAN0308            1.
    SH030864  BAL0383            -1.   BAL0364             1.
    SH030265  COST            380.68   TRAN0302            1.
    SH030265  BAL0302            -1.   BAL0365             1.
    SH030266  COST            321.16   TRAN0302            1.
    SH030266  BAL0302            -1.   BAL0366             1.
    SH030267  COST            287.68   TRAN0302            1.
    SH030267  BAL0302            -1.   BAL0367             1.
    SH030268  COST              496.   TRAN0302            1.
    SH030268  BAL0302            -1.   BAL0368             1.
    SH030269  COST            274.04   TRAN0302            1.
    SH030269  BAL0302            -1.   BAL0369             1.
    SH030171  COST             545.6   TRAN0301            1.
    SH030171  BAL0301            -1.   BAL0371             1.
    SH030371  COST            649.76   TRAN0303            1.
    SH030371  BAL0303            -1.   BAL0371             1.
    SH030471  COST            646.04   TRAN0304            1.
    SH030471  BAL0304            -1.   BAL0371             1.
    SH030571  COST            720.44   TRAN0305            1.
    SH030571  BAL0305            -1.   BAL0371             1.
    SH030671  COST            484.84   TRAN0306            1.
    SH030671  BAL0352            -1.   BAL0371             1.
    SH030771  COST            872.96   TRAN0307            1.
    SH030771  BAL0364            -1.   BAL0371             1.
    SH030871  COST            660.92   TRAN0308            1.
    SH030871  BAL0383            -1.   BAL0371             1.
    SH030272  COST            673.32   TRAN0302            1.
    SH030272  BAL0302            -1.   BAL0372             1.
    SH030173  COST             483.6   TRAN0301            1.
    SH030173  BAL0301            -1.   BAL0373             1.
    SH030273  COST             452.6   TRAN0302            1.
    SH030273  BAL0302            -1.   BAL0373             1.
    SH030373  COST            419.12   TRAN0303            1.
    SH030373  BAL0303            -1.   BAL0373             1.
    SH030473  COST            566.68   TRAN0304            1.
    SH030473  BAL0304            -1.   BAL0373             1.
    SH030573  COST            699.36   TRAN0305            1.
    SH030573  BAL0305            -1.   BAL0373             1.
    SH030673  COST             378.2   TRAN0306            1.
    SH030673  BAL0352            -1.   BAL0373             1.
    SH030873  COST            624.96   TRAN0308            1.
    SH030873  BAL0383            -1.   BAL0373             1.
    SH030274  COST             260.4   TRAN0302            1.
    SH030274  BAL0302            -1.   BAL0374             1.
    SH030275  COST            686.96   TRAN0302            1.
    SH030275  BAL0302            -1.   BAL0375             1.
    SH030276  COST            497.24   TRAN0302            1.
    SH030276  BAL0302            -1.   BAL0376             1.
    SH030177  COST             539.4   TRAN0301            1.
    SH030177  BAL0301            -1.   BAL0377             1.
    SH030277  COST            337.28   TRAN0302            1.
    SH030277  BAL0302            -1.   BAL0377             1.
    SH030377  COST            571.64   TRAN0303            1.
    SH030377  BAL0303            -1.   BAL0377             1.
    SH030477  COST            497.24   TRAN0304            1.
    SH030477  BAL0304            -1.   BAL0377             1.
    SH030577  COST             694.4   TRAN0305            1.
    SH030577  BAL0305            -1.   BAL0377             1.
    SH030877  COST             396.8   TRAN0308            1.
    SH030877  BAL0383            -1.   BAL0377             1.
    SH030178  COST            943.64   TRAN0301            1.
    SH030178  BAL0301            -1.   BAL0378             1.
    SH030278  COST            548.08   TRAN0302            1.
    SH030278  BAL0302            -1.   BAL0378             1.
    SH030378  COST            970.92   TRAN0303            1.
    SH030378  BAL0303            -1.   BAL0378             1.
    SH030478  COST             849.4   TRAN0304            1.
    SH030478  BAL0304            -1.   BAL0378             1.
    SH030578  COST           1089.96   TRAN0305            1.
    SH030578  BAL0305            -1.   BAL0378             1.
    SH030878  COST            949.84   TRAN0308            1.
    SH030878  BAL0383            -1.   BAL0378             1.
    SH030279  COST            333.56   TRAN0302            1.
    SH030279  BAL0302            -1.   BAL0379             1.
    SH030480  COST            463.76   TRAN0304            1.
    SH030480  BAL0304            -1.   BAL0380             1.
    SH030182  COST            721.68   TRAN0301            1.
    SH030182  BAL0301            -1.   BAL0382             1.
    SH030282  COST            407.96   TRAN0302            1.
    SH030282  BAL0302            -1.   BAL0382             1.
    SH030382  COST             812.2   TRAN0303            1.
    SH030382  BAL0303            -1.   BAL0382             1.
    SH030482  COST            875.44   TRAN0304            1.
    SH030482  BAL0304            -1.   BAL0382             1.
    SH030582  COST           1422.28   TRAN0305            1.
    SH030582  BAL0305            -1.   BAL0382             1.
    SH030882  COST            970.92   TRAN0308            1.
    SH030882  BAL0383            -1.   BAL0382             1.
    SH030183  COST            219.48   TRAN0301            1.
    SH030183  BAL0301            -1.   BAL0383             1.
    SH030283  COST             644.8   TRAN0302            1.
    SH030283  BAL0302            -1.   BAL0383             1.
    SH030383  COST            337.28   TRAN0303            1.
    SH030383  BAL0303            -1.   BAL0383             1.
    SH030483  COST             73.16   TRAN0304            1.
    SH030483  BAL0304            -1.   BAL0383             1.
    SH030583  COST            430.28   TRAN0305            1.
    SH030583  BAL0305            -1.   BAL0383             1.
    SH030683  COST            307.52   TRAN0306            1.
    SH030683  BAL0352            -1.   BAL0383             1.
    SH030284  COST            238.08   TRAN0302            1.
    SH030284  BAL0302            -1.   BAL0384             1.
    SH040201  COST            299.97   TRAN0402            1.
    SH040201  BAL0402            -1.   BAL0401             1.
    SH040301  COST            115.14   TRAN0403            1.
    SH040301  BAL0403            -1.   BAL0401             1.
    SH040401  COST            210.08   TRAN0404            1.
    SH040401  BAL0404            -1.   BAL0401             1.
    SH040501  COST            239.37   TRAN0405            1.
    SH040501  BAL0405            -1.   BAL0401             1.
    SH040601  COST            127.26   TRAN0406            1.
    SH040601  BAL0452            -1.   BAL0401             1.
    SH040801  COST            144.43   TRAN0408            1.
    SH040801  BAL0483            -1.   BAL0401             1.
    SH040102  COST            478.74   TRAN0401            1.
    SH040102  BAL0401            -1.   BAL0402             1.
    SH040302  COST            421.17   TRAN0403            1.
    SH040302  BAL0403            -1.   BAL0402             1.
    SH040402  COST            618.12   TRAN0404            1.
    SH040402  BAL0404            -1.   BAL0402             1.
    SH040502  COST            748.41   TRAN0405            1.
    SH040502  BAL0405            -1.   BAL0402             1.
    SH040602  COST            381.78   TRAN0406            1.
    SH040602  BAL0452            -1.   BAL0402             1.
    SH040802  COST            526.21   TRAN0408            1.
    SH040802  BAL0483            -1.   BAL0402             1.
    SH040103  COST            247.45   TRAN0401            1.
    SH040103  BAL0401            -1.   BAL0403             1.
    SH040203  COST            478.74   TRAN0402            1.
    SH040203  BAL0402            -1.   BAL0403             1.
    SH040403  COST            370.67   TRAN0404            1.
    SH040403  BAL0404            -1.   BAL0403             1.
    SH040503  COST            286.84   TRAN0405            1.
    SH040503  BAL0405            -1.   BAL0403             1.
    SH040603  COST              90.9   TRAN0406            1.
    SH040603  BAL0452            -1.   BAL0403             1.
    SH040803  COST            257.55   TRAN0408            1.
    SH040803  BAL0483            -1.   BAL0403             1.
    SH040104  COST            175.74   TRAN0401            1.
    SH040104  BAL0401            -1.   BAL0404             1.
    SH040204  COST            508.03   TRAN0402            1.
    SH040204  BAL0402            -1.   BAL0404             1.
    SH040304  COST            245.43   TRAN0403            1.
    SH040304  BAL0403            -1.   BAL0404             1.
    SH040504  COST            322.19   TRAN0405            1.
    SH040504  BAL0405            -1.   BAL0404             1.
    SH040604  COST            247.45   TRAN0406            1.
    SH040604  BAL0452            -1.   BAL0404             1.
    SH040804  COST             58.58   TRAN0408            1.
    SH040804  BAL0483            -1.   BAL0404             1.
    SH040105  COST             272.7   TRAN0401            1.
    SH040105  BAL0401            -1.   BAL0405             1.
    SH040205  COST            521.16   TRAN0402            1.
    SH040205  BAL0402            -1.   BAL0405             1.
    SH040305  COST            286.84   TRAN0403            1.
    SH040305  BAL0403            -1.   BAL0405             1.
    SH040405  COST            287.85   TRAN0404            1.
    SH040405  BAL0404            -1.   BAL0405             1.
    SH040605  COST            329.26   TRAN0406            1.
    SH040605  BAL0452            -1.   BAL0405             1.
    SH040705  COST            337.34   TRAN0407            1.
    SH040705  BAL0464            -1.   BAL0405             1.
    SH040805  COST            273.71   TRAN0408            1.
    SH040805  BAL0483            -1.   BAL0405             1.
    SH040106  COST            200.99   TRAN0401            1.
    SH040106  BAL0401            -1.   BAL0406             1.
    SH040107  COST             21.21   TRAN0401            1.
    SH040107  BAL0401            -1.   BAL0407             1.
    SH040207  COST            294.92   TRAN0402            1.
    SH040207  BAL0402            -1.   BAL0407             1.
    SH040307  COST            125.24   TRAN0403            1.
    SH040307  BAL0403            -1.   BAL0407             1.
    SH040407  COST            209.07   TRAN0404            1.
    SH040407  BAL0404            -1.   BAL0407             1.
    SH040507  COST            231.29   TRAN0405            1.
    SH040507  BAL0405            -1.   BAL0407             1.
    SH040607  COST            126.25   TRAN0406            1.
    SH040607  BAL0452            -1.   BAL0407             1.
    SH040707  COST            234.32   TRAN0407            1.
    SH040707  BAL0464            -1.   BAL0407             1.
    SH040807  COST            156.55   TRAN0408            1.
    SH040807  BAL0483            -1.   BAL0407             1.
    SH040108  COST             66.66   TRAN0401            1.
    SH040108  BAL0401            -1.   BAL0408             1.
    SH040208  COST            379.76   TRAN0402            1.
    SH040208  BAL0402            -1.   BAL0408             1.
    SH040308  COST            142.41   TRAN0403            1.
    SH040308  BAL0403            -1.   BAL0408             1.
    SH040408  COST            249.47   TRAN0404            1.
    SH040408  BAL0404            -1.   BAL0408             1.
    SH040508  COST            183.82   TRAN0405            1.
    SH040508  BAL0405            -1.   BAL0408             1.
    SH040608  COST            167.66   TRAN0406            1.
    SH040608  BAL0452            -1.   BAL0408             1.
    SH040808  COST            188.87   TRAN0408            1.
    SH040808  BAL0483            -1.   BAL0408             1.
    SH040109  COST            139.38   TRAN0401            1.
    SH040109  BAL0401            -1.   BAL0409             1.
    SH040110  COST            249.47   TRAN0401            1.
    SH040110  BAL0401            -1.   BAL0410             1.
    SH040210  COST            159.58   TRAN0402            1.
    SH040210  BAL0402            -1.   BAL0410             1.
    SH040310  COST             242.4   TRAN0403            1.
    SH040310  BAL0403            -1.   BAL0410             1.
    SH040410  COST            362.59   TRAN0404            1.
    SH040410  BAL0404            -1.   BAL0410             1.
    SH040510  COST            388.85   TRAN0405            1.
    SH040510  BAL0405            -1.   BAL0410             1.
    SH040610  COST            227.25   TRAN0406            1.
    SH040610  BAL0452            -1.   BAL0410             1.
    SH040810  COST            308.05   TRAN0408            1.
    SH040810  BAL0483            -1.   BAL0410             1.
    SH040111  COST            107.06   TRAN0401            1.
    SH040111  BAL0401            -1.   BAL0411             1.
    SH040112  COST             88.88   TRAN0401            1.
    SH040112  BAL0401            -1.   BAL0412             1.
    SH040114  COST            143.42   TRAN0401            1.
    SH040114  BAL0401            -1.   BAL0414             1.
    SH040614  COST            189.88   TRAN0406            1.
    SH040614  BAL0452            -1.   BAL0414             1.
    SH040115  COST            306.03   TRAN0401            1.
    SH040115  BAL0401            -1.   BAL0415             1.
    SH040215  COST            160.59   TRAN0402            1.
    SH040215  BAL0402            -1.   BAL0415             1.
    SH040315  COST            236.34   TRAN0403            1.
    SH040315  BAL0403            -1.   BAL0415             1.
    SH040415  COST            480.76   TRAN0404            1.
    SH040415  BAL0404            -1.   BAL0415             1.
    SH040515  COST            401.98   TRAN0405            1.
    SH040515  BAL0405            -1.   BAL0415             1.
    SH040615  COST            189.88   TRAN0406            1.
    SH040615  BAL0452            -1.   BAL0415             1.
    SH040815  COST            376.73   TRAN0408            1.
    SH040815  BAL0483            -1.   BAL0415             1.
    SH040116  COST            159.58   TRAN0401            1.
    SH040116  BAL0401            -1.   BAL0416             1.
    SH040216  COST             282.8   TRAN0402            1.
    SH040216  BAL0402            -1.   BAL0416             1.
    SH040316  COST            229.27   TRAN0403            1.
    SH040316  BAL0403            -1.   BAL0416             1.
    SH040416  COST            289.87   TRAN0404            1.
    SH040416  BAL0404            -1.   BAL0416             1.
    SH040516  COST            322.19   TRAN0405            1.
    SH040516  BAL0405            -1.   BAL0416             1.
    SH040616  COST            132.31   TRAN0406            1.
    SH040616  BAL0452            -1.   BAL0416             1.
    SH040816  COST            207.05   TRAN0408            1.
    SH040816  BAL0483            -1.   BAL0416             1.
    SH040117  COST            152.51   TRAN0401            1.
    SH040117  BAL0401            -1.   BAL0417             1.
    SH040817  COST             27.27   TRAN0408            1.
    SH040817  BAL0483            -1.   BAL0417             1.
    SH040418  COST            155.54   TRAN0404            1.
    SH040418  BAL0404            -1.   BAL0418             1.
    SH040119  COST            250.48   TRAN0401            1.
    SH040119  BAL0401            -1.   BAL0419             1.
    SH040219  COST            693.87   TRAN0402            1.
    SH040219  BAL0402            -1.   BAL0419             1.
    SH040319  COST            320.17   TRAN0403            1.
    SH040319  BAL0403            -1.   BAL0419             1.
    SH040419  COST            160.59   TRAN0404            1.
    SH040419  BAL0404            -1.   BAL0419             1.
    SH040519  COST            210.08   TRAN0405            1.
    SH040519  BAL0405            -1.   BAL0419             1.
    SH040619  COST            348.45   TRAN0406            1.
    SH040619  BAL0452            -1.   BAL0419             1.
    SH040819  COST             99.99   TRAN0408            1.
    SH040819  BAL0483            -1.   BAL0419             1.
    SH040120  COST            207.05   TRAN0401            1.
    SH040120  BAL0401            -1.   BAL0420             1.
    SH040220  COST            689.83   TRAN0402            1.
    SH040220  BAL0402            -1.   BAL0420             1.
    SH040320  COST            299.97   TRAN0403            1.
    SH040320  BAL0403            -1.   BAL0420             1.
    SH040420  COST            114.13   TRAN0404            1.
    SH040420  BAL0404            -1.   BAL0420             1.
    SH040520  COST            293.91   TRAN0405            1.
    SH040520  BAL0405            -1.   BAL0420             1.
    SH040820  COST            127.26   TRAN0408            1.
    SH040820  BAL0483            -1.   BAL0420             1.
    SH040121  COST            407.03   TRAN0401            1.
    SH040121  BAL0401            -1.   BAL0421             1.
    SH040221  COST            371.68   TRAN0402            1.
    SH040221  BAL0402            -1.   BAL0421             1.
    SH040321  COST            450.46   TRAN0403            1.
    SH040321  BAL0403            -1.   BAL0421             1.
    SH040421  COST             323.2   TRAN0404            1.
    SH040421  BAL0404            -1.   BAL0421             1.
    SH040521  COST             555.5   TRAN0405            1.
    SH040521  BAL0405            -1.   BAL0421             1.
    SH040821  COST             323.2   TRAN0408            1.
    SH040821  BAL0483            -1.   BAL0421             1.
    SH040422  COST            226.24   TRAN0404            1.
    SH040422  BAL0404            -1.   BAL0422             1.
    SH040423  COST            168.67   TRAN0404            1.
    SH040423  BAL0404            -1.   BAL0423             1.
    SH040124  COST           1450.36   TRAN0401            1.
    SH040124  BAL0401            -1.   BAL0424             1.
    SH040225  COST            431.27   TRAN0402            1.
    SH040225  BAL0402            -1.   BAL0425             1.
    SH040426  COST             272.7   TRAN0404            1.
    SH040426  BAL0404            -1.   BAL0426             1.
    SH040627  COST            270.68   TRAN0406            1.
    SH040627  BAL0452            -1.   BAL0427             1.
    SH040128  COST            245.43   TRAN0401            1.
    SH040128  BAL0401            -1.   BAL0428             1.
    SH040528  COST            103.02   TRAN0405            1.
    SH040528  BAL0405            -1.   BAL0428             1.
    SH040429  COST            200.99   TRAN0404            1.
    SH040429  BAL0404            -1.   BAL0429             1.
    SH040430  COST            307.04   TRAN0404            1.
    SH040430  BAL0404            -1.   BAL0430             1.
    SH040131  COST            112.11   TRAN0401            1.
    SH040131  BAL0401            -1.   BAL0431             1.
    SH040432  COST            158.57   TRAN0404            1.
    SH040432  BAL0404            -1.   BAL0432             1.
    SH040133  COST            497.93   TRAN0401            1.
    SH040133  BAL0401            -1.   BAL0433             1.
    SH040233  COST              404.   TRAN0402            1.
    SH040233  BAL0402            -1.   BAL0433             1.
    SH040333  COST            548.43   TRAN0403            1.
    SH040333  BAL0403            -1.   BAL0433             1.
    SH040433  COST            449.45   TRAN0404            1.
    SH040433  BAL0404            -1.   BAL0433             1.
    SH040533  COST            637.31   TRAN0405            1.
    SH040533  BAL0405            -1.   BAL0433             1.
    SH040833  COST            384.81   TRAN0408            1.
    SH040833  BAL0483            -1.   BAL0433             1.
    SH040134  COST            389.86   TRAN0401            1.
    SH040134  BAL0401            -1.   BAL0434             1.
    SH040234  COST            661.55   TRAN0402            1.
    SH040234  BAL0402            -1.   BAL0434             1.
    SH040334  COST            508.03   TRAN0403            1.
    SH040334  BAL0403            -1.   BAL0434             1.
    SH040434  COST            213.11   TRAN0404            1.
    SH040434  BAL0404            -1.   BAL0434             1.
    SH040534  COST            445.41   TRAN0405            1.
    SH040534  BAL0405            -1.   BAL0434             1.
    SH040834  COST            265.63   TRAN0408            1.
    SH040834  BAL0483            -1.   BAL0434             1.
    SH040435  COST            123.22   TRAN0404            1.
    SH040435  BAL0404            -1.   BAL0435             1.
    SH040636  COST             111.1   TRAN0406            1.
    SH040636  BAL0452            -1.   BAL0436             1.
    SH040137  COST             92.92   TRAN0401            1.
    SH040137  BAL0401            -1.   BAL0437             1.
    SH040237  COST            345.42   TRAN0402            1.
    SH040237  BAL0402            -1.   BAL0437             1.
    SH040337  COST            159.58   TRAN0403            1.
    SH040337  BAL0403            -1.   BAL0437             1.
    SH040437  COST            307.04   TRAN0404            1.
    SH040437  BAL0404            -1.   BAL0437             1.
    SH040537  COST            183.82   TRAN0405            1.
    SH040537  BAL0405            -1.   BAL0437             1.
    SH040637  COST            195.94   TRAN0406            1.
    SH040637  BAL0452            -1.   BAL0437             1.
    SH040837  COST            254.52   TRAN0408            1.
    SH040837  BAL0483            -1.   BAL0437             1.
    SH040138  COST            137.36   TRAN0401            1.
    SH040138  BAL0401            -1.   BAL0438             1.
    SH040238  COST            246.44   TRAN0402            1.
    SH040238  BAL0402            -1.   BAL0438             1.
    SH040338  COST             95.95   TRAN0403            1.
    SH040338  BAL0403            -1.   BAL0438             1.
    SH040438  COST            311.08   TRAN0404            1.
    SH040438  BAL0404            -1.   BAL0438             1.
    SH040538  COST            280.78   TRAN0405            1.
    SH040538  BAL0405            -1.   BAL0438             1.
    SH040638  COST             39.39   TRAN0406            1.
    SH040638  BAL0452            -1.   BAL0438             1.
    SH040738  COST            218.16   TRAN0407            1.
    SH040738  BAL0464            -1.   BAL0438             1.
    SH040838  COST            239.37   TRAN0408            1.
    SH040838  BAL0483            -1.   BAL0438             1.
    SH040139  COST             131.3   TRAN0401            1.
    SH040139  BAL0401            -1.   BAL0439             1.
    SH040140  COST            166.65   TRAN0401            1.
    SH040140  BAL0401            -1.   BAL0440             1.
    SH040240  COST            381.78   TRAN0402            1.
    SH040240  BAL0402            -1.   BAL0440             1.
    SH040340  COST            104.03   TRAN0403            1.
    SH040340  BAL0403            -1.   BAL0440             1.
    SH040440  COST            299.97   TRAN0404            1.
    SH040440  BAL0404            -1.   BAL0440             1.
    SH040540  COST            223.21   TRAN0405            1.
    SH040540  BAL0405            -1.   BAL0440             1.
    SH040640  COST            132.31   TRAN0406            1.
    SH040640  BAL0452            -1.   BAL0440             1.
    SH040840  COST            276.74   TRAN0408            1.
    SH040840  BAL0483            -1.   BAL0440             1.
    SH040641  COST              101.   TRAN0406            1.
    SH040641  BAL0452            -1.   BAL0441             1.
    SH040142  COST              90.9   TRAN0401            1.
    SH040142  BAL0401            -1.   BAL0442             1.
    SH040143  COST            160.59   TRAN0401            1.
    SH040143  BAL0401            -1.   BAL0443             1.
    SH040243  COST            398.95   TRAN0402            1.
    SH040243  BAL0402            -1.   BAL0443             1.
    SH040343  COST             25.25   TRAN0403            1.
    SH040343  BAL0403            -1.   BAL0443             1.
    SH040443  COST            298.96   TRAN0404            1.
    SH040443  BAL0404            -1.   BAL0443             1.
    SH040543  COST            260.58   TRAN0405            1.
    SH040543  BAL0405            -1.   BAL0443             1.
    SH040643  COST              101.   TRAN0406            1.
    SH040643  BAL0452            -1.   BAL0443             1.
    SH040743  COST            243.41   TRAN0407            1.
    SH040743  BAL0464            -1.   BAL0443             1.
    SH040843  COST            273.71   TRAN0408            1.
    SH040843  BAL0483            -1.   BAL0443             1.
    SH040644  COST             89.89   TRAN0406            1.
    SH040644  BAL0452            -1.   BAL0444             1.
    SH040145  COST            173.72   TRAN0401            1.
    SH040145  BAL0401            -1.   BAL0445             1.
    SH040245  COST            440.36   TRAN0402            1.
    SH040245  BAL0402            -1.   BAL0445             1.
    SH040345  COST            162.61   TRAN0403            1.
    SH040345  BAL0403            -1.   BAL0445             1.
    SH040445  COST            294.92   TRAN0404            1.
    SH040445  BAL0404            -1.   BAL0445             1.
    SH040545  COST            236.34   TRAN0405            1.
    SH040545  BAL0405            -1.   BAL0445             1.
    SH040645  COST            192.91   TRAN0406            1.
    SH040645  BAL0452            -1.   BAL0445             1.
    SH040745  COST            198.97   TRAN0407            1.
    SH040745  BAL0464            -1.   BAL0445             1.
    SH040845  COST            308.05   TRAN0408            1.
    SH040845  BAL0483            -1.   BAL0445             1.
    SH040146  COST            247.45   TRAN0401            1.
    SH040146  BAL0401            -1.   BAL0446             1.
    SH040246  COST            275.73   TRAN0402            1.
    SH040246  BAL0402            -1.   BAL0446             1.
    SH040346  COST            223.21   TRAN0403            1.
    SH040346  BAL0403            -1.   BAL0446             1.
    SH040446  COST            451.47   TRAN0404            1.
    SH040446  BAL0404            -1.   BAL0446             1.
    SH040546  COST             434.3   TRAN0405            1.
    SH040546  BAL0405            -1.   BAL0446             1.
    SH040646  COST            259.57   TRAN0406            1.
    SH040646  BAL0452            -1.   BAL0446             1.
    SH040846  COST            452.48   TRAN0408            1.
    SH040846  BAL0483            -1.   BAL0446             1.
    SH040147  COST             111.1   TRAN0401            1.
    SH040147  BAL0401            -1.   BAL0447             1.
    SH040148  COST             95.95   TRAN0401            1.
    SH040148  BAL0401            -1.   BAL0448             1.
    SH040149  COST            332.29   TRAN0401            1.
    SH040149  BAL0401            -1.   BAL0449             1.
    SH040549  COST            153.52   TRAN0405            1.
    SH040549  BAL0405            -1.   BAL0449             1.
    SH040150  COST            243.41   TRAN0401            1.
    SH040150  BAL0401            -1.   BAL0450             1.
    SH040151  COST            335.32   TRAN0401            1.
    SH040151  BAL0401            -1.   BAL0451             1.
    SH040551  COST            124.23   TRAN0405            1.
    SH040551  BAL0405            -1.   BAL0451             1.
    SH040152  COST            113.12   TRAN0401            1.
    SH040152  BAL0401            -1.   BAL0452             1.
    SH040252  COST              303.   TRAN0402            1.
    SH040252  BAL0402            -1.   BAL0452             1.
    SH040352  COST             82.82   TRAN0403            1.
    SH040352  BAL0403            -1.   BAL0452             1.
    SH040452  COST            325.22   TRAN0404            1.
    SH040452  BAL0404            -1.   BAL0452             1.
    SH040552  COST            297.95   TRAN0405            1.
    SH040552  BAL0405            -1.   BAL0452             1.
    SH040852  COST            255.53   TRAN0408            1.
    SH040852  BAL0483            -1.   BAL0452             1.
    SH040153  COST            362.59   TRAN0401            1.
    SH040153  BAL0401            -1.   BAL0453             1.
    SH040253  COST            642.36   TRAN0402            1.
    SH040253  BAL0402            -1.   BAL0453             1.
    SH040353  COST            328.25   TRAN0403            1.
    SH040353  BAL0403            -1.   BAL0453             1.
    SH040453  COST            416.12   TRAN0404            1.
    SH040453  BAL0404            -1.   BAL0453             1.
    SH040553  COST            185.84   TRAN0405            1.
    SH040553  BAL0405            -1.   BAL0453             1.
    SH040653  COST            362.59   TRAN0406            1.
    SH040653  BAL0452            -1.   BAL0453             1.
    SH040753  COST            147.46   TRAN0407            1.
    SH040753  BAL0464            -1.   BAL0453             1.
    SH040853  COST            407.03   TRAN0408            1.
    SH040853  BAL0483            -1.   BAL0453             1.
    SH040154  COST            186.85   TRAN0401            1.
    SH040154  BAL0401            -1.   BAL0454             1.
    SH040155  COST            280.78   TRAN0401            1.
    SH040155  BAL0401            -1.   BAL0455             1.
    SH040255  COST            483.79   TRAN0402            1.
    SH040255  BAL0402            -1.   BAL0455             1.
    SH040355  COST            283.81   TRAN0403            1.
    SH040355  BAL0403            -1.   BAL0455             1.
    SH040455  COST            296.94   TRAN0404            1.
    SH040455  BAL0404            -1.   BAL0455             1.
    SH040555  COST            155.54   TRAN0405            1.
    SH040555  BAL0405            -1.   BAL0455             1.
    SH040655  COST             292.9   TRAN0406            1.
    SH040655  BAL0452            -1.   BAL0455             1.
    SH040755  COST            108.07   TRAN0407            1.
    SH040755  BAL0464            -1.   BAL0455             1.
    SH040855  COST            296.94   TRAN0408            1.
    SH040855  BAL0483            -1.   BAL0455             1.
    SH040156  COST             393.9   TRAN0401            1.
    SH040156  BAL0401            -1.   BAL0456             1.
    SH040556  COST            137.36   TRAN0405            1.
    SH040556  BAL0405            -1.   BAL0456             1.
    SH040157  COST            263.61   TRAN0401            1.
    SH040157  BAL0401            -1.   BAL0457             1.
    SH040557  COST            169.68   TRAN0405            1.
    SH040557  BAL0405            -1.   BAL0457             1.
    SH040158  COST            296.94   TRAN0401            1.
    SH040158  BAL0401            -1.   BAL0458             1.
    SH040258  COST            526.21   TRAN0402            1.
    SH040258  BAL0402            -1.   BAL0458             1.
    SH040358  COST            280.78   TRAN0403            1.
    SH040358  BAL0403            -1.   BAL0458             1.
    SH040458  COST            346.43   TRAN0404            1.
    SH040458  BAL0404            -1.   BAL0458             1.
    SH040558  COST             21.21   TRAN0405            1.
    SH040558  BAL0405            -1.   BAL0458             1.
    SH040658  COST            329.26   TRAN0406            1.
    SH040658  BAL0452            -1.   BAL0458             1.
    SH040758  COST             68.68   TRAN0407            1.
    SH040758  BAL0464            -1.   BAL0458             1.
    SH040858  COST            256.54   TRAN0408            1.
    SH040858  BAL0483            -1.   BAL0458             1.
    SH040159  COST            208.06   TRAN0401            1.
    SH040159  BAL0401            -1.   BAL0459             1.
    SH040259  COST            502.98   TRAN0402            1.
    SH040259  BAL0402            -1.   BAL0459             1.
    SH040359  COST            240.38   TRAN0403            1.
    SH040359  BAL0403            -1.   BAL0459             1.
    SH040459  COST            246.44   TRAN0404            1.
    SH040459  BAL0404            -1.   BAL0459             1.
    SH040559  COST            160.59   TRAN0405            1.
    SH040559  BAL0405            -1.   BAL0459             1.
    SH040659  COST            299.97   TRAN0406            1.
    SH040659  BAL0452            -1.   BAL0459             1.
    SH040759  COST            106.05   TRAN0407            1.
    SH040759  BAL0464            -1.   BAL0459             1.
    SH040859  COST            257.55   TRAN0408            1.
    SH040859  BAL0483            -1.   BAL0459             1.
    SH040160  COST            263.61   TRAN0401            1.
    SH040160  BAL0401            -1.   BAL0460             1.
    SH040260  COST             555.5   TRAN0402            1.
    SH040260  BAL0402            -1.   BAL0460             1.
    SH040360  COST            285.83   TRAN0403            1.
    SH040360  BAL0403            -1.   BAL0460             1.
    SH040460  COST            315.12   TRAN0404            1.
    SH040460  BAL0404            -1.   BAL0460             1.
    SH040560  COST            136.35   TRAN0405            1.
    SH040560  BAL0405            -1.   BAL0460             1.
    SH040660  COST            326.23   TRAN0406            1.
    SH040660  BAL0452            -1.   BAL0460             1.
    SH040760  COST             88.88   TRAN0407            1.
    SH040760  BAL0464            -1.   BAL0460             1.
    SH040860  COST            301.99   TRAN0408            1.
    SH040860  BAL0483            -1.   BAL0460             1.
    SH040163  COST            268.66   TRAN0401            1.
    SH040163  BAL0401            -1.   BAL0463             1.
    SH040563  COST            153.52   TRAN0405            1.
    SH040563  BAL0405            -1.   BAL0463             1.
    SH040164  COST            200.99   TRAN0401            1.
    SH040164  BAL0401            -1.   BAL0464             1.
    SH040264  COST            531.26   TRAN0402            1.
    SH040264  BAL0402            -1.   BAL0464             1.
    SH040364  COST            225.23   TRAN0403            1.
    SH040364  BAL0403            -1.   BAL0464             1.
    SH040464  COST            339.36   TRAN0404            1.
    SH040464  BAL0404            -1.   BAL0464             1.
    SH040564  COST             58.58   TRAN0405            1.
    SH040564  BAL0405            -1.   BAL0464             1.
    SH040664  COST            320.17   TRAN0406            1.
    SH040664  BAL0452            -1.   BAL0464             1.
    SH040864  COST             252.5   TRAN0408            1.
    SH040864  BAL0483            -1.   BAL0464             1.
    SH040265  COST            310.07   TRAN0402            1.
    SH040265  BAL0402            -1.   BAL0465             1.
    SH040266  COST            261.59   TRAN0402            1.
    SH040266  BAL0402            -1.   BAL0466             1.
    SH040267  COST            234.32   TRAN0402            1.
    SH040267  BAL0402            -1.   BAL0467             1.
    SH040268  COST              404.   TRAN0402            1.
    SH040268  BAL0402            -1.   BAL0468             1.
    SH040269  COST            223.21   TRAN0402            1.
    SH040269  BAL0402            -1.   BAL0469             1.
    SH040171  COST             444.4   TRAN0401            1.
    SH040171  BAL0401            -1.   BAL0471             1.
    SH040371  COST            529.24   TRAN0403            1.
    SH040371  BAL0403            -1.   BAL0471             1.
    SH040471  COST            526.21   TRAN0404            1.
    SH040471  BAL0404            -1.   BAL0471             1.
    SH040571  COST            586.81   TRAN0405            1.
    SH040571  BAL0405            -1.   BAL0471             1.
    SH040671  COST            394.91   TRAN0406            1.
    SH040671  BAL0452            -1.   BAL0471             1.
    SH040771  COST            711.04   TRAN0407            1.
    SH040771  BAL0464            -1.   BAL0471             1.
    SH040871  COST            538.33   TRAN0408            1.
    SH040871  BAL0483            -1.   BAL0471             1.
    SH040272  COST            548.43   TRAN0402            1.
    SH040272  BAL0402            -1.   BAL0472             1.
    SH040173  COST             393.9   TRAN0401            1.
    SH040173  BAL0401            -1.   BAL0473             1.
    SH040273  COST            368.65   TRAN0402            1.
    SH040273  BAL0402            -1.   BAL0473             1.
    SH040373  COST            341.38   TRAN0403            1.
    SH040373  BAL0403            -1.   BAL0473             1.
    SH040473  COST            461.57   TRAN0404            1.
    SH040473  BAL0404            -1.   BAL0473             1.
    SH040573  COST            569.64   TRAN0405            1.
    SH040573  BAL0405            -1.   BAL0473             1.
    SH040673  COST            308.05   TRAN0406            1.
    SH040673  BAL0452            -1.   BAL0473             1.
    SH040873  COST            509.04   TRAN0408            1.
    SH040873  BAL0483            -1.   BAL0473             1.
    SH040274  COST             212.1   TRAN0402            1.
    SH040274  BAL0402            -1.   BAL0474             1.
    SH040275  COST            559.54   TRAN0402            1.
    SH040275  BAL0402            -1.   BAL0475             1.
    SH040276  COST            405.01   TRAN0402            1.
    SH040276  BAL0402            -1.   BAL0476             1.
    SH040177  COST            439.35   TRAN0401            1.
    SH040177  BAL0401            -1.   BAL0477             1.
    SH040277  COST            274.72   TRAN0402            1.
    SH040277  BAL0402            -1.   BAL0477             1.
    SH040377  COST            465.61   TRAN0403            1.
    SH040377  BAL0403            -1.   BAL0477             1.
    SH040477  COST            405.01   TRAN0404            1.
    SH040477  BAL0404            -1.   BAL0477             1.
    SH040577  COST             565.6   TRAN0405            1.
    SH040577  BAL0405            -1.   BAL0477             1.
    SH040877  COST             323.2   TRAN0408            1.
    SH040877  BAL0483            -1.   BAL0477             1.
    SH040178  COST            768.61   TRAN0401            1.
    SH040178  BAL0401            -1.   BAL0478             1.
    SH040278  COST            446.42   TRAN0402            1.
    SH040278  BAL0402            -1.   BAL0478             1.
    SH040378  COST            790.83   TRAN0403            1.
    SH040378  BAL0403            -1.   BAL0478             1.
    SH040478  COST            691.85   TRAN0404            1.
    SH040478  BAL0404            -1.   BAL0478             1.
    SH040578  COST            887.79   TRAN0405            1.
    SH040578  BAL0405            -1.   BAL0478             1.
    SH040878  COST            773.66   TRAN0408            1.
    SH040878  BAL0483            -1.   BAL0478             1.
    SH040279  COST            271.69   TRAN0402            1.
    SH040279  BAL0402            -1.   BAL0479             1.
    SH040480  COST            377.74   TRAN0404            1.
    SH040480  BAL0404            -1.   BAL0480             1.
    SH040182  COST            587.82   TRAN0401            1.
    SH040182  BAL0401            -1.   BAL0482             1.
    SH040282  COST            332.29   TRAN0402            1.
    SH040282  BAL0402            -1.   BAL0482             1.
    SH040382  COST            661.55   TRAN0403            1.
    SH040382  BAL0403            -1.   BAL0482             1.
    SH040482  COST            713.06   TRAN0404            1.
    SH040482  BAL0404            -1.   BAL0482             1.
    SH040582  COST           1158.47   TRAN0405            1.
    SH040582  BAL0405            -1.   BAL0482             1.
    SH040882  COST            790.83   TRAN0408            1.
    SH040882  BAL0483            -1.   BAL0482             1.
    SH040183  COST            178.77   TRAN0401            1.
    SH040183  BAL0401            -1.   BAL0483             1.
    SH040283  COST             525.2   TRAN0402            1.
    SH040283  BAL0402            -1.   BAL0483             1.
    SH040383  COST            274.72   TRAN0403            1.
    SH040383  BAL0403            -1.   BAL0483             1.
    SH040483  COST             59.59   TRAN0404            1.
    SH040483  BAL0404            -1.   BAL0483             1.
    SH040583  COST            350.47   TRAN0405            1.
    SH040583  BAL0405            -1.   BAL0483             1.
    SH040683  COST            250.48   TRAN0406            1.
    SH040683  BAL0452            -1.   BAL0483             1.
    SH040284  COST            193.92   TRAN0402            1.
    SH040284  BAL0402            -1.   BAL0484             1.
    SH050201  COST            490.05   TRAN0502            1.
    SH050201  BAL0502            -1.   BAL0501             1.
    SH050301  COST             188.1   TRAN0503            1.
    SH050301  BAL0503            -1.   BAL0501             1.
    SH050401  COST             343.2   TRAN0504            1.
    SH050401  BAL0504            -1.   BAL0501             1.
    SH050501  COST            391.05   TRAN0505            1.
    SH050501  BAL0505            -1.   BAL0501             1.
    SH050601  COST             207.9   TRAN0506            1.
    SH050601  BAL0552            -1.   BAL0501             1.
    SH050801  COST            235.95   TRAN0508            1.
    SH050801  BAL0583            -1.   BAL0501             1.
    SH050102  COST             782.1   TRAN0501            1.
    SH050102  BAL0501            -1.   BAL0502             1.
    SH050302  COST            688.05   TRAN0503            1.
    SH050302  BAL0503            -1.   BAL0502             1.
    SH050402  COST            1009.8   TRAN0504            1.
    SH050402  BAL0504            -1.   BAL0502             1.
    SH050502  COST           1222.65   TRAN0505            1.
    SH050502  BAL0505            -1.   BAL0502             1.
    SH050602  COST             623.7   TRAN0506            1.
    SH050602  BAL0552            -1.   BAL0502             1.
    SH050802  COST            859.65   TRAN0508            1.
    SH050802  BAL0583            -1.   BAL0502             1.
    SH050103  COST            404.25   TRAN0501            1.
    SH050103  BAL0501            -1.   BAL0503             1.
    SH050203  COST             782.1   TRAN0502            1.
    SH050203  BAL0502            -1.   BAL0503             1.
    SH050403  COST            605.55   TRAN0504            1.
    SH050403  BAL0504            -1.   BAL0503             1.
    SH050503  COST             468.6   TRAN0505            1.
    SH050503  BAL0505            -1.   BAL0503             1.
    SH050603  COST             148.5   TRAN0506            1.
    SH050603  BAL0552            -1.   BAL0503             1.
    SH050803  COST            420.75   TRAN0508            1.
    SH050803  BAL0583            -1.   BAL0503             1.
    SH050104  COST             287.1   TRAN0501            1.
    SH050104  BAL0501            -1.   BAL0504             1.
    SH050204  COST            829.95   TRAN0502            1.
    SH050204  BAL0502            -1.   BAL0504             1.
    SH050304  COST            400.95   TRAN0503            1.
    SH050304  BAL0503            -1.   BAL0504             1.
    SH050504  COST            526.35   TRAN0505            1.
    SH050504  BAL0505            -1.   BAL0504             1.
    SH050604  COST            404.25   TRAN0506            1.
    SH050604  BAL0552            -1.   BAL0504             1.
    SH050804  COST              95.7   TRAN0508            1.
    SH050804  BAL0583            -1.   BAL0504             1.
    SH050105  COST             445.5   TRAN0501            1.
    SH050105  BAL0501            -1.   BAL0505             1.
    SH050205  COST             851.4   TRAN0502            1.
    SH050205  BAL0502            -1.   BAL0505             1.
    SH050305  COST             468.6   TRAN0503            1.
    SH050305  BAL0503            -1.   BAL0505             1.
    SH050405  COST            470.25   TRAN0504            1.
    SH050405  BAL0504            -1.   BAL0505             1.
    SH050605  COST             537.9   TRAN0506            1.
    SH050605  BAL0552            -1.   BAL0505             1.
    SH050705  COST             551.1   TRAN0507            1.
    SH050705  BAL0564            -1.   BAL0505             1.
    SH050805  COST            447.15   TRAN0508            1.
    SH050805  BAL0583            -1.   BAL0505             1.
    SH050106  COST            328.35   TRAN0501            1.
    SH050106  BAL0501            -1.   BAL0506             1.
    SH050107  COST             34.65   TRAN0501            1.
    SH050107  BAL0501            -1.   BAL0507             1.
    SH050207  COST             481.8   TRAN0502            1.
    SH050207  BAL0502            -1.   BAL0507             1.
    SH050307  COST             204.6   TRAN0503            1.
    SH050307  BAL0503            -1.   BAL0507             1.
    SH050407  COST            341.55   TRAN0504            1.
    SH050407  BAL0504            -1.   BAL0507             1.
    SH050507  COST            377.85   TRAN0505            1.
    SH050507  BAL0505            -1.   BAL0507             1.
    SH050607  COST            206.25   TRAN0506            1.
    SH050607  BAL0552            -1.   BAL0507             1.
    SH050707  COST             382.8   TRAN0507            1.
    SH050707  BAL0564            -1.   BAL0507             1.
    SH050807  COST            255.75   TRAN0508            1.
    SH050807  BAL0583            -1.   BAL0507             1.
    SH050108  COST             108.9   TRAN0501            1.
    SH050108  BAL0501            -1.   BAL0508             1.
    SH050208  COST             620.4   TRAN0502            1.
    SH050208  BAL0502            -1.   BAL0508             1.
    SH050308  COST            232.65   TRAN0503            1.
    SH050308  BAL0503            -1.   BAL0508             1.
    SH050408  COST            407.55   TRAN0504            1.
    SH050408  BAL0504            -1.   BAL0508             1.
    SH050508  COST             300.3   TRAN0505            1.
    SH050508  BAL0505            -1.   BAL0508             1.
    SH050608  COST             273.9   TRAN0506            1.
    SH050608  BAL0552            -1.   BAL0508             1.
    SH050808  COST            308.55   TRAN0508            1.
    SH050808  BAL0583            -1.   BAL0508             1.
    SH050109  COST             227.7   TRAN0501            1.
    SH050109  BAL0501            -1.   BAL0509             1.
    SH050110  COST            407.55   TRAN0501            1.
    SH050110  BAL0501            -1.   BAL0510             1.
    SH050210  COST             260.7   TRAN0502            1.
    SH050210  BAL0502            -1.   BAL0510             1.
    SH050310  COST              396.   TRAN0503            1.
    SH050310  BAL0503            -1.   BAL0510             1.
    SH050410  COST            592.35   TRAN0504            1.
    SH050410  BAL0504            -1.   BAL0510             1.
    SH050510  COST            635.25   TRAN0505            1.
    SH050510  BAL0505            -1.   BAL0510             1.
    SH050610  COST            371.25   TRAN0506            1.
    SH050610  BAL0552            -1.   BAL0510             1.
    SH050810  COST            503.25   TRAN0508            1.
    SH050810  BAL0583            -1.   BAL0510             1.
    SH050111  COST             174.9   TRAN0501            1.
    SH050111  BAL0501            -1.   BAL0511             1.
    SH050112  COST             145.2   TRAN0501            1.
    SH050112  BAL0501            -1.   BAL0512             1.
    SH050114  COST             234.3   TRAN0501            1.
    SH050114  BAL0501            -1.   BAL0514             1.
    SH050614  COST             310.2   TRAN0506            1.
    SH050614  BAL0552            -1.   BAL0514             1.
    SH050115  COST            499.95   TRAN0501            1.
    SH050115  BAL0501            -1.   BAL0515             1.
    SH050215  COST            262.35   TRAN0502            1.
    SH050215  BAL0502            -1.   BAL0515             1.
    SH050315  COST             386.1   TRAN0503            1.
    SH050315  BAL0503            -1.   BAL0515             1.
    SH050415  COST             785.4   TRAN0504            1.
    SH050415  BAL0504            -1.   BAL0515             1.
    SH050515  COST             656.7   TRAN0505            1.
    SH050515  BAL0505            -1.   BAL0515             1.
    SH050615  COST             310.2   TRAN0506            1.
    SH050615  BAL0552            -1.   BAL0515             1.
    SH050815  COST            615.45   TRAN0508            1.
    SH050815  BAL0583            -1.   BAL0515             1.
    SH050116  COST             260.7   TRAN0501            1.
    SH050116  BAL0501            -1.   BAL0516             1.
    SH050216  COST              462.   TRAN0502            1.
    SH050216  BAL0502            -1.   BAL0516             1.
    SH050316  COST            374.55   TRAN0503            1.
    SH050316  BAL0503            -1.   BAL0516             1.
    SH050416  COST            473.55   TRAN0504            1.
    SH050416  BAL0504            -1.   BAL0516             1.
    SH050516  COST            526.35   TRAN0505            1.
    SH050516  BAL0505            -1.   BAL0516             1.
    SH050616  COST            216.15   TRAN0506            1.
    SH050616  BAL0552            -1.   BAL0516             1.
    SH050816  COST            338.25   TRAN0508            1.
    SH050816  BAL0583            -1.   BAL0516             1.
    SH050117  COST            249.15   TRAN0501            1.
    SH050117  BAL0501            -1.   BAL0517             1.
    SH050817  COST             44.55   TRAN0508            1.
    SH050817  BAL0583            -1.   BAL0517             1.
    SH050418  COST             254.1   TRAN0504            1.
    SH050418  BAL0504            -1.   BAL0518             1.
    SH050119  COST             409.2   TRAN0501            1.
    SH050119  BAL0501            -1.   BAL0519             1.
    SH050219  COST           1133.55   TRAN0502            1.
    SH050219  BAL0502            -1.   BAL0519             1.
    SH050319  COST            523.05   TRAN0503            1.
    SH050319  BAL0503            -1.   BAL0519             1.
    SH050419  COST            262.35   TRAN0504            1.
    SH050419  BAL0504            -1.   BAL0519             1.
    SH050519  COST             343.2   TRAN0505            1.
    SH050519  BAL0505            -1.   BAL0519             1.
    SH050619  COST            569.25   TRAN0506            1.
    SH050619  BAL0552            -1.   BAL0519             1.
    SH050819  COST            163.35   TRAN0508            1.
    SH050819  BAL0583            -1.   BAL0519             1.
    SH050120  COST            338.25   TRAN0501            1.
    SH050120  BAL0501            -1.   BAL0520             1.
    SH050220  COST           1126.95   TRAN0502            1.
    SH050220  BAL0502            -1.   BAL0520             1.
    SH050320  COST            490.05   TRAN0503            1.
    SH050320  BAL0503            -1.   BAL0520             1.
    SH050420  COST            186.45   TRAN0504            1.
    SH050420  BAL0504            -1.   BAL0520             1.
    SH050520  COST            480.15   TRAN0505            1.
    SH050520  BAL0505            -1.   BAL0520             1.
    SH050820  COST             207.9   TRAN0508            1.
    SH050820  BAL0583            -1.   BAL0520             1.
    SH050121  COST            664.95   TRAN0501            1.
    SH050121  BAL0501            -1.   BAL0521             1.
    SH050221  COST             607.2   TRAN0502            1.
    SH050221  BAL0502            -1.   BAL0521             1.
    SH050321  COST             735.9   TRAN0503            1.
    SH050321  BAL0503            -1.   BAL0521             1.
    SH050421  COST              528.   TRAN0504            1.
    SH050421  BAL0504            -1.   BAL0521             1.
    SH050521  COST             907.5   TRAN0505            1.
    SH050521  BAL0505            -1.   BAL0521             1.
    SH050821  COST              528.   TRAN0508            1.
    SH050821  BAL0583            -1.   BAL0521             1.
    SH050422  COST             369.6   TRAN0504            1.
    SH050422  BAL0504            -1.   BAL0522             1.
    SH050423  COST            275.55   TRAN0504            1.
    SH050423  BAL0504            -1.   BAL0523             1.
    SH050124  COST            2369.4   TRAN0501            1.
    SH050124  BAL0501            -1.   BAL0524             1.
    SH050225  COST            704.55   TRAN0502            1.
    SH050225  BAL0502            -1.   BAL0525             1.
    SH050426  COST             445.5   TRAN0504            1.
    SH050426  BAL0504            -1.   BAL0526             1.
    SH050627  COST             442.2   TRAN0506            1.
    SH050627  BAL0552            -1.   BAL0527             1.
    SH050128  COST            400.95   TRAN0501            1.
    SH050128  BAL0501            -1.   BAL0528             1.
    SH050528  COST             168.3   TRAN0505            1.
    SH050528  BAL0505            -1.   BAL0528             1.
    SH050429  COST            328.35   TRAN0504            1.
    SH050429  BAL0504            -1.   BAL0529             1.
    SH050430  COST             501.6   TRAN0504            1.
    SH050430  BAL0504            -1.   BAL0530             1.
    SH050131  COST            183.15   TRAN0501            1.
    SH050131  BAL0501            -1.   BAL0531             1.
    SH050432  COST            259.05   TRAN0504            1.
    SH050432  BAL0504            -1.   BAL0532             1.
    SH050133  COST            813.45   TRAN0501            1.
    SH050133  BAL0501            -1.   BAL0533             1.
    SH050233  COST              660.   TRAN0502            1.
    SH050233  BAL0502            -1.   BAL0533             1.
    SH050333  COST            895.95   TRAN0503            1.
    SH050333  BAL0503            -1.   BAL0533             1.
    SH050433  COST            734.25   TRAN0504            1.
    SH050433  BAL0504            -1.   BAL0533             1.
    SH050533  COST           1041.15   TRAN0505            1.
    SH050533  BAL0505            -1.   BAL0533             1.
    SH050833  COST            628.65   TRAN0508            1.
    SH050833  BAL0583            -1.   BAL0533             1.
    SH050134  COST             636.9   TRAN0501            1.
    SH050134  BAL0501            -1.   BAL0534             1.
    SH050234  COST           1080.75   TRAN0502            1.
    SH050234  BAL0502            -1.   BAL0534             1.
    SH050334  COST            829.95   TRAN0503            1.
    SH050334  BAL0503            -1.   BAL0534             1.
    SH050434  COST            348.15   TRAN0504            1.
    SH050434  BAL0504            -1.   BAL0534             1.
    SH050534  COST            727.65   TRAN0505            1.
    SH050534  BAL0505            -1.   BAL0534             1.
    SH050834  COST            433.95   TRAN0508            1.
    SH050834  BAL0583            -1.   BAL0534             1.
    SH050435  COST             201.3   TRAN0504            1.
    SH050435  BAL0504            -1.   BAL0535             1.
    SH050636  COST             181.5   TRAN0506            1.
    SH050636  BAL0552            -1.   BAL0536             1.
    SH050137  COST             151.8   TRAN0501            1.
    SH050137  BAL0501            -1.   BAL0537             1.
    SH050237  COST             564.3   TRAN0502            1.
    SH050237  BAL0502            -1.   BAL0537             1.
    SH050337  COST             260.7   TRAN0503            1.
    SH050337  BAL0503            -1.   BAL0537             1.
    SH050437  COST             501.6   TRAN0504            1.
    SH050437  BAL0504            -1.   BAL0537             1.
    SH050537  COST             300.3   TRAN0505            1.
    SH050537  BAL0505            -1.   BAL0537             1.
    SH050637  COST             320.1   TRAN0506            1.
    SH050637  BAL0552            -1.   BAL0537             1.
    SH050837  COST             415.8   TRAN0508            1.
    SH050837  BAL0583            -1.   BAL0537             1.
    SH050138  COST             224.4   TRAN0501            1.
    SH050138  BAL0501            -1.   BAL0538             1.
    SH050238  COST             402.6   TRAN0502            1.
    SH050238  BAL0502            -1.   BAL0538             1.
    SH050338  COST            156.75   TRAN0503            1.
    SH050338  BAL0503            -1.   BAL0538             1.
    SH050438  COST             508.2   TRAN0504            1.
    SH050438  BAL0504            -1.   BAL0538             1.
    SH050538  COST             458.7   TRAN0505            1.
    SH050538  BAL0505            -1.   BAL0538             1.
    SH050638  COST             64.35   TRAN0506            1.
    SH050638  BAL0552            -1.   BAL0538             1.
    SH050738  COST             356.4   TRAN0507            1.
    SH050738  BAL0564            -1.   BAL0538             1.
    SH050838  COST            391.05   TRAN0508            1.
    SH050838  BAL0583            -1.   BAL0538             1.
    SH050139  COST             214.5   TRAN0501            1.
    SH050139  BAL0501            -1.   BAL0539             1.
    SH050140  COST            272.25   TRAN0501            1.
    SH050140  BAL0501            -1.   BAL0540             1.
    SH050240  COST             623.7   TRAN0502            1.
    SH050240  BAL0502            -1.   BAL0540             1.
    SH050340  COST            169.95   TRAN0503            1.
    SH050340  BAL0503            -1.   BAL0540             1.
    SH050440  COST            490.05   TRAN0504            1.
    SH050440  BAL0504            -1.   BAL0540             1.
    SH050540  COST            364.65   TRAN0505            1.
    SH050540  BAL0505            -1.   BAL0540             1.
    SH050640  COST            216.15   TRAN0506            1.
    SH050640  BAL0552            -1.   BAL0540             1.
    SH050840  COST             452.1   TRAN0508            1.
    SH050840  BAL0583            -1.   BAL0540             1.
    SH050641  COST              165.   TRAN0506            1.
    SH050641  BAL0552            -1.   BAL0541             1.
    SH050142  COST             148.5   TRAN0501            1.
    SH050142  BAL0501            -1.   BAL0542             1.
    SH050143  COST            262.35   TRAN0501            1.
    SH050143  BAL0501            -1.   BAL0543             1.
    SH050243  COST            651.75   TRAN0502            1.
    SH050243  BAL0502            -1.   BAL0543             1.
    SH050343  COST             41.25   TRAN0503            1.
    SH050343  BAL0503            -1.   BAL0543             1.
    SH050443  COST             488.4   TRAN0504            1.
    SH050443  BAL0504            -1.   BAL0543             1.
    SH050543  COST             425.7   TRAN0505            1.
    SH050543  BAL0505            -1.   BAL0543             1.
    SH050643  COST              165.   TRAN0506            1.
    SH050643  BAL0552            -1.   BAL0543             1.
    SH050743  COST            397.65   TRAN0507            1.
    SH050743  BAL0564            -1.   BAL0543             1.
    SH050843  COST            447.15   TRAN0508            1.
    SH050843  BAL0583            -1.   BAL0543             1.
    SH050644  COST            146.85   TRAN0506            1.
    SH050644  BAL0552            -1.   BAL0544             1.
    SH050145  COST             283.8   TRAN0501            1.
    SH050145  BAL0501            -1.   BAL0545             1.
    SH050245  COST             719.4   TRAN0502            1.
    SH050245  BAL0502            -1.   BAL0545             1.
    SH050345  COST            265.65   TRAN0503            1.
    SH050345  BAL0503            -1.   BAL0545             1.
    SH050445  COST             481.8   TRAN0504            1.
    SH050445  BAL0504            -1.   BAL0545             1.
    SH050545  COST             386.1   TRAN0505            1.
    SH050545  BAL0505            -1.   BAL0545             1.
    SH050645  COST            315.15   TRAN0506            1.
    SH050645  BAL0552            -1.   BAL0545             1.
    SH050745  COST            325.05   TRAN0507            1.
    SH050745  BAL0564            -1.   BAL0545             1.
    SH050845  COST            503.25   TRAN0508            1.
    SH050845  BAL0583            -1.   BAL0545             1.
    SH050146  COST            404.25   TRAN0501            1.
    SH050146  BAL0501            -1.   BAL0546             1.
    SH050246  COST            450.45   TRAN0502            1.
    SH050246  BAL0502            -1.   BAL0546             1.
    SH050346  COST            364.65   TRAN0503            1.
    SH050346  BAL0503            -1.   BAL0546             1.
    SH050446  COST            737.55   TRAN0504            1.
    SH050446  BAL0504            -1.   BAL0546             1.
    SH050546  COST             709.5   TRAN0505            1.
    SH050546  BAL0505            -1.   BAL0546             1.
    SH050646  COST            424.05   TRAN0506            1.
    SH050646  BAL0552            -1.   BAL0546             1.
    SH050846  COST             739.2   TRAN0508            1.
    SH050846  BAL0583            -1.   BAL0546             1.
    SH050147  COST             181.5   TRAN0501            1.
    SH050147  BAL0501            -1.   BAL0547             1.
    SH050148  COST            156.75   TRAN0501            1.
    SH050148  BAL0501            -1.   BAL0548             1.
    SH050149  COST            542.85   TRAN0501            1.
    SH050149  BAL0501            -1.   BAL0549             1.
    SH050549  COST             250.8   TRAN0505            1.
    SH050549  BAL0505            -1.   BAL0549             1.
    SH050150  COST            397.65   TRAN0501            1.
    SH050150  BAL0501            -1.   BAL0550             1.
    SH050151  COST             547.8   TRAN0501            1.
    SH050151  BAL0501            -1.   BAL0551             1.
    SH050551  COST            202.95   TRAN0505            1.
    SH050551  BAL0505            -1.   BAL0551             1.
    SH050152  COST             184.8   TRAN0501            1.
    SH050152  BAL0501            -1.   BAL0552             1.
    SH050252  COST              495.   TRAN0502            1.
    SH050252  BAL0502            -1.   BAL0552             1.
    SH050352  COST             135.3   TRAN0503            1.
    SH050352  BAL0503            -1.   BAL0552             1.
    SH050452  COST             531.3   TRAN0504            1.
    SH050452  BAL0504            -1.   BAL0552             1.
    SH050552  COST            486.75   TRAN0505            1.
    SH050552  BAL0505            -1.   BAL0552             1.
    SH050852  COST            417.45   TRAN0508            1.
    SH050852  BAL0583            -1.   BAL0552             1.
    SH050153  COST            592.35   TRAN0501            1.
    SH050153  BAL0501            -1.   BAL0553             1.
    SH050253  COST            1049.4   TRAN0502            1.
    SH050253  BAL0502            -1.   BAL0553             1.
    SH050353  COST            536.25   TRAN0503            1.
    SH050353  BAL0503            -1.   BAL0553             1.
    SH050453  COST             679.8   TRAN0504            1.
    SH050453  BAL0504            -1.   BAL0553             1.
    SH050553  COST             303.6   TRAN0505            1.
    SH050553  BAL0505            -1.   BAL0553             1.
    SH050653  COST            592.35   TRAN0506            1.
    SH050653  BAL0552            -1.   BAL0553             1.
    SH050753  COST             240.9   TRAN0507            1.
    SH050753  BAL0564            -1.   BAL0553             1.
    SH050853  COST            664.95   TRAN0508            1.
    SH050853  BAL0583            -1.   BAL0553             1.
    SH050154  COST            305.25   TRAN0501            1.
    SH050154  BAL0501            -1.   BAL0554             1.
    SH050155  COST             458.7   TRAN0501            1.
    SH050155  BAL0501            -1.   BAL0555             1.
    SH050255  COST            790.35   TRAN0502            1.
    SH050255  BAL0502            -1.   BAL0555             1.
    SH050355  COST            463.65   TRAN0503            1.
    SH050355  BAL0503            -1.   BAL0555             1.
    SH050455  COST             485.1   TRAN0504            1.
    SH050455  BAL0504            -1.   BAL0555             1.
    SH050555  COST             254.1   TRAN0505            1.
    SH050555  BAL0505            -1.   BAL0555             1.
    SH050655  COST             478.5   TRAN0506            1.
    SH050655  BAL0552            -1.   BAL0555             1.
    SH050755  COST            176.55   TRAN0507            1.
    SH050755  BAL0564            -1.   BAL0555             1.
    SH050855  COST             485.1   TRAN0508            1.
    SH050855  BAL0583            -1.   BAL0555             1.
    SH050156  COST             643.5   TRAN0501            1.
    SH050156  BAL0501            -1.   BAL0556             1.
    SH050556  COST             224.4   TRAN0505            1.
    SH050556  BAL0505            -1.   BAL0556             1.
    SH050157  COST            430.65   TRAN0501            1.
    SH050157  BAL0501            -1.   BAL0557             1.
    SH050557  COST             277.2   TRAN0505            1.
    SH050557  BAL0505            -1.   BAL0557             1.
    SH050158  COST             485.1   TRAN0501            1.
    SH050158  BAL0501            -1.   BAL0558             1.
    SH050258  COST            859.65   TRAN0502            1.
    SH050258  BAL0502            -1.   BAL0558             1.
    SH050358  COST             458.7   TRAN0503            1.
    SH050358  BAL0503            -1.   BAL0558             1.
    SH050458  COST            565.95   TRAN0504            1.
    SH050458  BAL0504            -1.   BAL0558             1.
    SH050558  COST             34.65   TRAN0505            1.
    SH050558  BAL0505            -1.   BAL0558             1.
    SH050658  COST             537.9   TRAN0506            1.
    SH050658  BAL0552            -1.   BAL0558             1.
    SH050758  COST             112.2   TRAN0507            1.
    SH050758  BAL0564            -1.   BAL0558             1.
    SH050858  COST             419.1   TRAN0508            1.
    SH050858  BAL0583            -1.   BAL0558             1.
    SH050159  COST             339.9   TRAN0501            1.
    SH050159  BAL0501            -1.   BAL0559             1.
    SH050259  COST             821.7   TRAN0502            1.
    SH050259  BAL0502            -1.   BAL0559             1.
    SH050359  COST             392.7   TRAN0503            1.
    SH050359  BAL0503            -1.   BAL0559             1.
    SH050459  COST             402.6   TRAN0504            1.
    SH050459  BAL0504            -1.   BAL0559             1.
    SH050559  COST            262.35   TRAN0505            1.
    SH050559  BAL0505            -1.   BAL0559             1.
    SH050659  COST            490.05   TRAN0506            1.
    SH050659  BAL0552            -1.   BAL0559             1.
    SH050759  COST            173.25   TRAN0507            1.
    SH050759  BAL0564            -1.   BAL0559             1.
    SH050859  COST            420.75   TRAN0508            1.
    SH050859  BAL0583            -1.   BAL0559             1.
    SH050160  COST            430.65   TRAN0501            1.
    SH050160  BAL0501            -1.   BAL0560             1.
    SH050260  COST             907.5   TRAN0502            1.
    SH050260  BAL0502            -1.   BAL0560             1.
    SH050360  COST            466.95   TRAN0503            1.
    SH050360  BAL0503            -1.   BAL0560             1.
    SH050460  COST             514.8   TRAN0504            1.
    SH050460  BAL0504            -1.   BAL0560             1.
    SH050560  COST            222.75   TRAN0505            1.
    SH050560  BAL0505            -1.   BAL0560             1.
    SH050660  COST            532.95   TRAN0506            1.
    SH050660  BAL0552            -1.   BAL0560             1.
    SH050760  COST             145.2   TRAN0507            1.
    SH050760  BAL0564            -1.   BAL0560             1.
    SH050860  COST            493.35   TRAN0508            1.
    SH050860  BAL0583            -1.   BAL0560             1.
    SH050163  COST             438.9   TRAN0501            1.
    SH050163  BAL0501            -1.   BAL0563             1.
    SH050563  COST             250.8   TRAN0505            1.
    SH050563  BAL0505            -1.   BAL0563             1.
    SH050164  COST            328.35   TRAN0501            1.
    SH050164  BAL0501            -1.   BAL0564             1.
    SH050264  COST             867.9   TRAN0502            1.
    SH050264  BAL0502            -1.   BAL0564             1.
    SH050364  COST            367.95   TRAN0503            1.
    SH050364  BAL0503            -1.   BAL0564             1.
    SH050464  COST             554.4   TRAN0504            1.
    SH050464  BAL0504            -1.   BAL0564             1.
    SH050564  COST              95.7   TRAN0505            1.
    SH050564  BAL0505            -1.   BAL0564             1.
    SH050664  COST            523.05   TRAN0506            1.
    SH050664  BAL0552            -1.   BAL0564             1.
    SH050864  COST             412.5   TRAN0508            1.
    SH050864  BAL0583            -1.   BAL0564             1.
    SH050265  COST            506.55   TRAN0502            1.
    SH050265  BAL0502            -1.   BAL0565             1.
    SH050266  COST            427.35   TRAN0502            1.
    SH050266  BAL0502            -1.   BAL0566             1.
    SH050267  COST             382.8   TRAN0502            1.
    SH050267  BAL0502            -1.   BAL0567             1.
    SH050268  COST              660.   TRAN0502            1.
    SH050268  BAL0502            -1.   BAL0568             1.
    SH050269  COST            364.65   TRAN0502            1.
    SH050269  BAL0502            -1.   BAL0569             1.
    SH050171  COST              726.   TRAN0501            1.
    SH050171  BAL0501            -1.   BAL0571             1.
    SH050371  COST             864.6   TRAN0503            1.
    SH050371  BAL0503            -1.   BAL0571             1.
    SH050471  COST            859.65   TRAN0504            1.
    SH050471  BAL0504            -1.   BAL0571             1.
    SH050571  COST            958.65   TRAN0505            1.
    SH050571  BAL0505            -1.   BAL0571             1.
    SH050671  COST            645.15   TRAN0506            1.
    SH050671  BAL0552            -1.   BAL0571             1.
    SH050771  COST            1161.6   TRAN0507            1.
    SH050771  BAL0564            -1.   BAL0571             1.
    SH050871  COST            879.45   TRAN0508            1.
    SH050871  BAL0583            -1.   BAL0571             1.
    SH050272  COST            895.95   TRAN0502            1.
    SH050272  BAL0502            -1.   BAL0572             1.
    SH050173  COST             643.5   TRAN0501            1.
    SH050173  BAL0501            -1.   BAL0573             1.
    SH050273  COST            602.25   TRAN0502            1.
    SH050273  BAL0502            -1.   BAL0573             1.
    SH050373  COST             557.7   TRAN0503            1.
    SH050373  BAL0503            -1.   BAL0573             1.
    SH050473  COST            754.05   TRAN0504            1.
    SH050473  BAL0504            -1.   BAL0573             1.
    SH050573  COST             930.6   TRAN0505            1.
    SH050573  BAL0505            -1.   BAL0573             1.
    SH050673  COST            503.25   TRAN0506            1.
    SH050673  BAL0552            -1.   BAL0573             1.
    SH050873  COST             831.6   TRAN0508            1.
    SH050873  BAL0583            -1.   BAL0573             1.
    SH050274  COST             346.5   TRAN0502            1.
    SH050274  BAL0502            -1.   BAL0574             1.
    SH050275  COST             914.1   TRAN0502            1.
    SH050275  BAL0502            -1.   BAL0575             1.
    SH050276  COST            661.65   TRAN0502            1.
    SH050276  BAL0502            -1.   BAL0576             1.
    SH050177  COST            717.75   TRAN0501            1.
    SH050177  BAL0501            -1.   BAL0577             1.
    SH050277  COST             448.8   TRAN0502            1.
    SH050277  BAL0502            -1.   BAL0577             1.
    SH050377  COST            760.65   TRAN0503            1.
    SH050377  BAL0503            -1.   BAL0577             1.
    SH050477  COST            661.65   TRAN0504            1.
    SH050477  BAL0504            -1.   BAL0577             1.
    SH050577  COST              924.   TRAN0505            1.
    SH050577  BAL0505            -1.   BAL0577             1.
    SH050877  COST              528.   TRAN0508            1.
    SH050877  BAL0583            -1.   BAL0577             1.
    SH050178  COST           1255.65   TRAN0501            1.
    SH050178  BAL0501            -1.   BAL0578             1.
    SH050278  COST             729.3   TRAN0502            1.
    SH050278  BAL0502            -1.   BAL0578             1.
    SH050378  COST           1291.95   TRAN0503            1.
    SH050378  BAL0503            -1.   BAL0578             1.
    SH050478  COST           1130.25   TRAN0504            1.
    SH050478  BAL0504            -1.   BAL0578             1.
    SH050578  COST           1450.35   TRAN0505            1.
    SH050578  BAL0505            -1.   BAL0578             1.
    SH050878  COST            1263.9   TRAN0508            1.
    SH050878  BAL0583            -1.   BAL0578             1.
    SH050279  COST            443.85   TRAN0502            1.
    SH050279  BAL0502            -1.   BAL0579             1.
    SH050480  COST             617.1   TRAN0504            1.
    SH050480  BAL0504            -1.   BAL0580             1.
    SH050182  COST             960.3   TRAN0501            1.
    SH050182  BAL0501            -1.   BAL0582             1.
    SH050282  COST            542.85   TRAN0502            1.
    SH050282  BAL0502            -1.   BAL0582             1.
    SH050382  COST           1080.75   TRAN0503            1.
    SH050382  BAL0503            -1.   BAL0582             1.
    SH050482  COST            1164.9   TRAN0504            1.
    SH050482  BAL0504            -1.   BAL0582             1.
    SH050582  COST           1892.55   TRAN0505            1.
    SH050582  BAL0505            -1.   BAL0582             1.
    SH050882  COST           1291.95   TRAN0508            1.
    SH050882  BAL0583            -1.   BAL0582             1.
    SH050183  COST            292.05   TRAN0501            1.
    SH050183  BAL0501            -1.   BAL0583             1.
    SH050283  COST              858.   TRAN0502            1.
    SH050283  BAL0502            -1.   BAL0583             1.
    SH050383  COST             448.8   TRAN0503            1.
    SH050383  BAL0503            -1.   BAL0583             1.
    SH050483  COST             97.35   TRAN0504            1.
    SH050483  BAL0504            -1.   BAL0583             1.
    SH050583  COST            572.55   TRAN0505            1.
    SH050583  BAL0505            -1.   BAL0583             1.
    SH050683  COST             409.2   TRAN0506            1.
    SH050683  BAL0552            -1.   BAL0583             1.
    SH050284  COST             316.8   TRAN0502            1.
    SH050284  BAL0502            -1.   BAL0584             1.
    SH060201  COST            365.31   TRAN0602            1.
    SH060201  BAL0602            -1.   BAL0601             1.
    SH060301  COST            140.22   TRAN0603            1.
    SH060301  BAL0603            -1.   BAL0601             1.
    SH060401  COST            255.84   TRAN0604            1.
    SH060401  BAL0604            -1.   BAL0601             1.
    SH060501  COST            291.51   TRAN0605            1.
    SH060501  BAL0605            -1.   BAL0601             1.
    SH060601  COST            154.98   TRAN0606            1.
    SH060601  BAL0652            -1.   BAL0601             1.
    SH060801  COST            175.89   TRAN0608            1.
    SH060801  BAL0683            -1.   BAL0601             1.
    SH060102  COST            583.02   TRAN0601            1.
    SH060102  BAL0601            -1.   BAL0602             1.
    SH060302  COST            512.91   TRAN0603            1.
    SH060302  BAL0603            -1.   BAL0602             1.
    SH060402  COST            752.76   TRAN0604            1.
    SH060402  BAL0604            -1.   BAL0602             1.
    SH060502  COST            911.43   TRAN0605            1.
    SH060502  BAL0605            -1.   BAL0602             1.
    SH060602  COST            464.94   TRAN0606            1.
    SH060602  BAL0652            -1.   BAL0602             1.
    SH060802  COST            640.83   TRAN0608            1.
    SH060802  BAL0683            -1.   BAL0602             1.
    SH060103  COST            301.35   TRAN0601            1.
    SH060103  BAL0601            -1.   BAL0603             1.
    SH060203  COST            583.02   TRAN0602            1.
    SH060203  BAL0602            -1.   BAL0603             1.
    SH060403  COST            451.41   TRAN0604            1.
    SH060403  BAL0604            -1.   BAL0603             1.
    SH060503  COST            349.32   TRAN0605            1.
    SH060503  BAL0605            -1.   BAL0603             1.
    SH060603  COST             110.7   TRAN0606            1.
    SH060603  BAL0652            -1.   BAL0603             1.
    SH060803  COST            313.65   TRAN0608            1.
    SH060803  BAL0683            -1.   BAL0603             1.
    SH060104  COST            214.02   TRAN0601            1.
    SH060104  BAL0601            -1.   BAL0604             1.
    SH060204  COST            618.69   TRAN0602            1.
    SH060204  BAL0602            -1.   BAL0604             1.
    SH060304  COST            298.89   TRAN0603            1.
    SH060304  BAL0603            -1.   BAL0604             1.
    SH060504  COST            392.37   TRAN0605            1.
    SH060504  BAL0605            -1.   BAL0604             1.
    SH060604  COST            301.35   TRAN0606            1.
    SH060604  BAL0652            -1.   BAL0604             1.
    SH060804  COST             71.34   TRAN0608            1.
    SH060804  BAL0683            -1.   BAL0604             1.
    SH060105  COST             332.1   TRAN0601            1.
    SH060105  BAL0601            -1.   BAL0605             1.
    SH060205  COST            634.68   TRAN0602            1.
    SH060205  BAL0602            -1.   BAL0605             1.
    SH060305  COST            349.32   TRAN0603            1.
    SH060305  BAL0603            -1.   BAL0605             1.
    SH060405  COST            350.55   TRAN0604            1.
    SH060405  BAL0604            -1.   BAL0605             1.
    SH060605  COST            400.98   TRAN0606            1.
    SH060605  BAL0652            -1.   BAL0605             1.
    SH060705  COST            410.82   TRAN0607            1.
    SH060705  BAL0664            -1.   BAL0605             1.
    SH060805  COST            333.33   TRAN0608            1.
    SH060805  BAL0683            -1.   BAL0605             1.
    SH060106  COST            244.77   TRAN0601            1.
    SH060106  BAL0601            -1.   BAL0606             1.
    SH060107  COST             25.83   TRAN0601            1.
    SH060107  BAL0601            -1.   BAL0607             1.
    SH060207  COST            359.16   TRAN0602            1.
    SH060207  BAL0602            -1.   BAL0607             1.
    SH060307  COST            152.52   TRAN0603            1.
    SH060307  BAL0603            -1.   BAL0607             1.
    SH060407  COST            254.61   TRAN0604            1.
    SH060407  BAL0604            -1.   BAL0607             1.
    SH060507  COST            281.67   TRAN0605            1.
    SH060507  BAL0605            -1.   BAL0607             1.
    SH060607  COST            153.75   TRAN0606            1.
    SH060607  BAL0652            -1.   BAL0607             1.
    SH060707  COST            285.36   TRAN0607            1.
    SH060707  BAL0664            -1.   BAL0607             1.
    SH060807  COST            190.65   TRAN0608            1.
    SH060807  BAL0683            -1.   BAL0607             1.
    SH060108  COST             81.18   TRAN0601            1.
    SH060108  BAL0601            -1.   BAL0608             1.
    SH060208  COST            462.48   TRAN0602            1.
    SH060208  BAL0602            -1.   BAL0608             1.
    SH060308  COST            173.43   TRAN0603            1.
    SH060308  BAL0603            -1.   BAL0608             1.
    SH060408  COST            303.81   TRAN0604            1.
    SH060408  BAL0604            -1.   BAL0608             1.
    SH060508  COST            223.86   TRAN0605            1.
    SH060508  BAL0605            -1.   BAL0608             1.
    SH060608  COST            204.18   TRAN0606            1.
    SH060608  BAL0652            -1.   BAL0608             1.
    SH060808  COST            230.01   TRAN0608            1.
    SH060808  BAL0683            -1.   BAL0608             1.
    SH060109  COST            169.74   TRAN0601            1.
    SH060109  BAL0601            -1.   BAL0609             1.
    SH060110  COST            303.81   TRAN0601            1.
    SH060110  BAL0601            -1.   BAL0610             1.
    SH060210  COST            194.34   TRAN0602            1.
    SH060210  BAL0602            -1.   BAL0610             1.
    SH060310  COST             295.2   TRAN0603            1.
    SH060310  BAL0603            -1.   BAL0610             1.
    SH060410  COST            441.57   TRAN0604            1.
    SH060410  BAL0604            -1.   BAL0610             1.
    SH060510  COST            473.55   TRAN0605            1.
    SH060510  BAL0605            -1.   BAL0610             1.
    SH060610  COST            276.75   TRAN0606            1.
    SH060610  BAL0652            -1.   BAL0610             1.
    SH060810  COST            375.15   TRAN0608            1.
    SH060810  BAL0683            -1.   BAL0610             1.
    SH060111  COST            130.38   TRAN0601            1.
    SH060111  BAL0601            -1.   BAL0611             1.
    SH060112  COST            108.24   TRAN0601            1.
    SH060112  BAL0601            -1.   BAL0612             1.
    SH060114  COST            174.66   TRAN0601            1.
    SH060114  BAL0601            -1.   BAL0614             1.
    SH060614  COST            231.24   TRAN0606            1.
    SH060614  BAL0652            -1.   BAL0614             1.
    SH060115  COST            372.69   TRAN0601            1.
    SH060115  BAL0601            -1.   BAL0615             1.
    SH060215  COST            195.57   TRAN0602            1.
    SH060215  BAL0602            -1.   BAL0615             1.
    SH060315  COST            287.82   TRAN0603            1.
    SH060315  BAL0603            -1.   BAL0615             1.
    SH060415  COST            585.48   TRAN0604            1.
    SH060415  BAL0604            -1.   BAL0615             1.
    SH060515  COST            489.54   TRAN0605            1.
    SH060515  BAL0605            -1.   BAL0615             1.
    SH060615  COST            231.24   TRAN0606            1.
    SH060615  BAL0652            -1.   BAL0615             1.
    SH060815  COST            458.79   TRAN0608            1.
    SH060815  BAL0683            -1.   BAL0615             1.
    SH060116  COST            194.34   TRAN0601            1.
    SH060116  BAL0601            -1.   BAL0616             1.
    SH060216  COST             344.4   TRAN0602            1.
    SH060216  BAL0602            -1.   BAL0616             1.
    SH060316  COST            279.21   TRAN0603            1.
    SH060316  BAL0603            -1.   BAL0616             1.
    SH060416  COST            353.01   TRAN0604            1.
    SH060416  BAL0604            -1.   BAL0616             1.
    SH060516  COST            392.37   TRAN0605            1.
    SH060516  BAL0605            -1.   BAL0616             1.
    SH060616  COST            161.13   TRAN0606            1.
    SH060616  BAL0652            -1.   BAL0616             1.
    SH060816  COST            252.15   TRAN0608            1.
    SH060816  BAL0683            -1.   BAL0616             1.
    SH060117  COST            185.73   TRAN0601            1.
    SH060117  BAL0601            -1.   BAL0617             1.
    SH060817  COST             33.21   TRAN0608            1.
    SH060817  BAL0683            -1.   BAL0617             1.
    SH060418  COST            189.42   TRAN0604            1.
    SH060418  BAL0604            -1.   BAL0618             1.
    SH060119  COST            305.04   TRAN0601            1.
    SH060119  BAL0601            -1.   BAL0619             1.
    SH060219  COST            845.01   TRAN0602            1.
    SH060219  BAL0602            -1.   BAL0619             1.
    SH060319  COST            389.91   TRAN0603            1.
    SH060319  BAL0603            -1.   BAL0619             1.
    SH060419  COST            195.57   TRAN0604            1.
    SH060419  BAL0604            -1.   BAL0619             1.
    SH060519  COST            255.84   TRAN0605            1.
    SH060519  BAL0605            -1.   BAL0619             1.
    SH060619  COST            424.35   TRAN0606            1.
    SH060619  BAL0652            -1.   BAL0619             1.
    SH060819  COST            121.77   TRAN0608            1.
    SH060819  BAL0683            -1.   BAL0619             1.
    SH060120  COST            252.15   TRAN0601            1.
    SH060120  BAL0601            -1.   BAL0620             1.
    SH060220  COST            840.09   TRAN0602            1.
    SH060220  BAL0602            -1.   BAL0620             1.
    SH060320  COST            365.31   TRAN0603            1.
    SH060320  BAL0603            -1.   BAL0620             1.
    SH060420  COST            138.99   TRAN0604            1.
    SH060420  BAL0604            -1.   BAL0620             1.
    SH060520  COST            357.93   TRAN0605            1.
    SH060520  BAL0605            -1.   BAL0620             1.
    SH060820  COST            154.98   TRAN0608            1.
    SH060820  BAL0683            -1.   BAL0620             1.
    SH060121  COST            495.69   TRAN0601            1.
    SH060121  BAL0601            -1.   BAL0621             1.
    SH060221  COST            452.64   TRAN0602            1.
    SH060221  BAL0602            -1.   BAL0621             1.
    SH060321  COST            548.58   TRAN0603            1.
    SH060321  BAL0603            -1.   BAL0621             1.
    SH060421  COST             393.6   TRAN0604            1.
    SH060421  BAL0604            -1.   BAL0621             1.
    SH060521  COST             676.5   TRAN0605            1.
    SH060521  BAL0605            -1.   BAL0621             1.
    SH060821  COST             393.6   TRAN0608            1.
    SH060821  BAL0683            -1.   BAL0621             1.
    SH060422  COST            275.52   TRAN0604            1.
    SH060422  BAL0604            -1.   BAL0622             1.
    SH060423  COST            205.41   TRAN0604            1.
    SH060423  BAL0604            -1.   BAL0623             1.
    SH060124  COST           1766.28   TRAN0601            1.
    SH060124  BAL0601            -1.   BAL0624             1.
    SH060225  COST            525.21   TRAN0602            1.
    SH060225  BAL0602            -1.   BAL0625             1.
    SH060426  COST             332.1   TRAN0604            1.
    SH060426  BAL0604            -1.   BAL0626             1.
    SH060627  COST            329.64   TRAN0606            1.
    SH060627  BAL0652            -1.   BAL0627             1.
    SH060128  COST            298.89   TRAN0601            1.
    SH060128  BAL0601            -1.   BAL0628             1.
    SH060528  COST            125.46   TRAN0605            1.
    SH060528  BAL0605            -1.   BAL0628             1.
    SH060429  COST            244.77   TRAN0604            1.
    SH060429  BAL0604            -1.   BAL0629             1.
    SH060430  COST            373.92   TRAN0604            1.
    SH060430  BAL0604            -1.   BAL0630             1.
    SH060131  COST            136.53   TRAN0601            1.
    SH060131  BAL0601            -1.   BAL0631             1.
    SH060432  COST            193.11   TRAN0604            1.
    SH060432  BAL0604            -1.   BAL0632             1.
    SH060133  COST            606.39   TRAN0601            1.
    SH060133  BAL0601            -1.   BAL0633             1.
    SH060233  COST              492.   TRAN0602            1.
    SH060233  BAL0602            -1.   BAL0633             1.
    SH060333  COST            667.89   TRAN0603            1.
    SH060333  BAL0603            -1.   BAL0633             1.
    SH060433  COST            547.35   TRAN0604            1.
    SH060433  BAL0604            -1.   BAL0633             1.
    SH060533  COST            776.13   TRAN0605            1.
    SH060533  BAL0605            -1.   BAL0633             1.
    SH060833  COST            468.63   TRAN0608            1.
    SH060833  BAL0683            -1.   BAL0633             1.
    SH060134  COST            474.78   TRAN0601            1.
    SH060134  BAL0601            -1.   BAL0634             1.
    SH060234  COST            805.65   TRAN0602            1.
    SH060234  BAL0602            -1.   BAL0634             1.
    SH060334  COST            618.69   TRAN0603            1.
    SH060334  BAL0603            -1.   BAL0634             1.
    SH060434  COST            259.53   TRAN0604            1.
    SH060434  BAL0604            -1.   BAL0634             1.
    SH060534  COST            542.43   TRAN0605            1.
    SH060534  BAL0605            -1.   BAL0634             1.
    SH060834  COST            323.49   TRAN0608            1.
    SH060834  BAL0683            -1.   BAL0634             1.
    SH060435  COST            150.06   TRAN0604            1.
    SH060435  BAL0604            -1.   BAL0635             1.
    SH060636  COST             135.3   TRAN0606            1.
    SH060636  BAL0652            -1.   BAL0636             1.
    SH060137  COST            113.16   TRAN0601            1.
    SH060137  BAL0601            -1.   BAL0637             1.
    SH060237  COST            420.66   TRAN0602            1.
    SH060237  BAL0602            -1.   BAL0637             1.
    SH060337  COST            194.34   TRAN0603            1.
    SH060337  BAL0603            -1.   BAL0637             1.
    SH060437  COST            373.92   TRAN0604            1.
    SH060437  BAL0604            -1.   BAL0637             1.
    SH060537  COST            223.86   TRAN0605            1.
    SH060537  BAL0605            -1.   BAL0637             1.
    SH060637  COST            238.62   TRAN0606            1.
    SH060637  BAL0652            -1.   BAL0637             1.
    SH060837  COST            309.96   TRAN0608            1.
    SH060837  BAL0683            -1.   BAL0637             1.
    SH060138  COST            167.28   TRAN0601            1.
    SH060138  BAL0601            -1.   BAL0638             1.
    SH060238  COST            300.12   TRAN0602            1.
    SH060238  BAL0602            -1.   BAL0638             1.
    SH060338  COST            116.85   TRAN0603            1.
    SH060338  BAL0603            -1.   BAL0638             1.
    SH060438  COST            378.84   TRAN0604            1.
    SH060438  BAL0604            -1.   BAL0638             1.
    SH060538  COST            341.94   TRAN0605            1.
    SH060538  BAL0605            -1.   BAL0638             1.
    SH060638  COST             47.97   TRAN0606            1.
    SH060638  BAL0652            -1.   BAL0638             1.
    SH060738  COST            265.68   TRAN0607            1.
    SH060738  BAL0664            -1.   BAL0638             1.
    SH060838  COST            291.51   TRAN0608            1.
    SH060838  BAL0683            -1.   BAL0638             1.
    SH060139  COST             159.9   TRAN0601            1.
    SH060139  BAL0601            -1.   BAL0639             1.
    SH060140  COST            202.95   TRAN0601            1.
    SH060140  BAL0601            -1.   BAL0640             1.
    SH060240  COST            464.94   TRAN0602            1.
    SH060240  BAL0602            -1.   BAL0640             1.
    SH060340  COST            126.69   TRAN0603            1.
    SH060340  BAL0603            -1.   BAL0640             1.
    SH060440  COST            365.31   TRAN0604            1.
    SH060440  BAL0604            -1.   BAL0640             1.
    SH060540  COST            271.83   TRAN0605            1.
    SH060540  BAL0605            -1.   BAL0640             1.
    SH060640  COST            161.13   TRAN0606            1.
    SH060640  BAL0652            -1.   BAL0640             1.
    SH060840  COST            337.02   TRAN0608            1.
    SH060840  BAL0683            -1.   BAL0640             1.
    SH060641  COST              123.   TRAN0606            1.
    SH060641  BAL0652            -1.   BAL0641             1.
    SH060142  COST             110.7   TRAN0601            1.
    SH060142  BAL0601            -1.   BAL0642             1.
    SH060143  COST            195.57   TRAN0601            1.
    SH060143  BAL0601            -1.   BAL0643             1.
    SH060243  COST            485.85   TRAN0602            1.
    SH060243  BAL0602            -1.   BAL0643             1.
    SH060343  COST             30.75   TRAN0603            1.
    SH060343  BAL0603            -1.   BAL0643             1.
    SH060443  COST            364.08   TRAN0604            1.
    SH060443  BAL0604            -1.   BAL0643             1.
    SH060543  COST            317.34   TRAN0605            1.
    SH060543  BAL0605            -1.   BAL0643             1.
    SH060643  COST              123.   TRAN0606            1.
    SH060643  BAL0652            -1.   BAL0643             1.
    SH060743  COST            296.43   TRAN0607            1.
    SH060743  BAL0664            -1.   BAL0643             1.
    SH060843  COST            333.33   TRAN0608            1.
    SH060843  BAL0683            -1.   BAL0643             1.
    SH060644  COST            109.47   TRAN0606            1.
    SH060644  BAL0652            -1.   BAL0644             1.
    SH060145  COST            211.56   TRAN0601            1.
    SH060145  BAL0601            -1.   BAL0645             1.
    SH060245  COST            536.28   TRAN0602            1.
    SH060245  BAL0602            -1.   BAL0645             1.
    SH060345  COST            198.03   TRAN0603            1.
    SH060345  BAL0603            -1.   BAL0645             1.
    SH060445  COST            359.16   TRAN0604            1.
    SH060445  BAL0604            -1.   BAL0645             1.
    SH060545  COST            287.82   TRAN0605            1.
    SH060545  BAL0605            -1.   BAL0645             1.
    SH060645  COST            234.93   TRAN0606            1.
    SH060645  BAL0652            -1.   BAL0645             1.
    SH060745  COST            242.31   TRAN0607            1.
    SH060745  BAL0664            -1.   BAL0645             1.
    SH060845  COST            375.15   TRAN0608            1.
    SH060845  BAL0683            -1.   BAL0645             1.
    SH060146  COST            301.35   TRAN0601            1.
    SH060146  BAL0601            -1.   BAL0646             1.
    SH060246  COST            335.79   TRAN0602            1.
    SH060246  BAL0602            -1.   BAL0646             1.
    SH060346  COST            271.83   TRAN0603            1.
    SH060346  BAL0603            -1.   BAL0646             1.
    SH060446  COST            549.81   TRAN0604            1.
    SH060446  BAL0604            -1.   BAL0646             1.
    SH060546  COST             528.9   TRAN0605            1.
    SH060546  BAL0605            -1.   BAL0646             1.
    SH060646  COST            316.11   TRAN0606            1.
    SH060646  BAL0652            -1.   BAL0646             1.
    SH060846  COST            551.04   TRAN0608            1.
    SH060846  BAL0683            -1.   BAL0646             1.
    SH060147  COST             135.3   TRAN0601            1.
    SH060147  BAL0601            -1.   BAL0647             1.
    SH060148  COST            116.85   TRAN0601            1.
    SH060148  BAL0601            -1.   BAL0648             1.
    SH060149  COST            404.67   TRAN0601            1.
    SH060149  BAL0601            -1.   BAL0649             1.
    SH060549  COST            186.96   TRAN0605            1.
    SH060549  BAL0605            -1.   BAL0649             1.
    SH060150  COST            296.43   TRAN0601            1.
    SH060150  BAL0601            -1.   BAL0650             1.
    SH060151  COST            408.36   TRAN0601            1.
    SH060151  BAL0601            -1.   BAL0651             1.
    SH060551  COST            151.29   TRAN0605            1.
    SH060551  BAL0605            -1.   BAL0651             1.
    SH060152  COST            137.76   TRAN0601            1.
    SH060152  BAL0601            -1.   BAL0652             1.
    SH060252  COST              369.   TRAN0602            1.
    SH060252  BAL0602            -1.   BAL0652             1.
    SH060352  COST            100.86   TRAN0603            1.
    SH060352  BAL0603            -1.   BAL0652             1.
    SH060452  COST            396.06   TRAN0604            1.
    SH060452  BAL0604            -1.   BAL0652             1.
    SH060552  COST            362.85   TRAN0605            1.
    SH060552  BAL0605            -1.   BAL0652             1.
    SH060852  COST            311.19   TRAN0608            1.
    SH060852  BAL0683            -1.   BAL0652             1.
    SH060153  COST            441.57   TRAN0601            1.
    SH060153  BAL0601            -1.   BAL0653             1.
    SH060253  COST            782.28   TRAN0602            1.
    SH060253  BAL0602            -1.   BAL0653             1.
    SH060353  COST            399.75   TRAN0603            1.
    SH060353  BAL0603            -1.   BAL0653             1.
    SH060453  COST            506.76   TRAN0604            1.
    SH060453  BAL0604            -1.   BAL0653             1.
    SH060553  COST            226.32   TRAN0605            1.
    SH060553  BAL0605            -1.   BAL0653             1.
    SH060653  COST            441.57   TRAN0606            1.
    SH060653  BAL0652            -1.   BAL0653             1.
    SH060753  COST            179.58   TRAN0607            1.
    SH060753  BAL0664            -1.   BAL0653             1.
    SH060853  COST            495.69   TRAN0608            1.
    SH060853  BAL0683            -1.   BAL0653             1.
    SH060154  COST            227.55   TRAN0601            1.
    SH060154  BAL0601            -1.   BAL0654             1.
    SH060155  COST            341.94   TRAN0601            1.
    SH060155  BAL0601            -1.   BAL0655             1.
    SH060255  COST            589.17   TRAN0602            1.
    SH060255  BAL0602            -1.   BAL0655             1.
    SH060355  COST            345.63   TRAN0603            1.
    SH060355  BAL0603            -1.   BAL0655             1.
    SH060455  COST            361.62   TRAN0604            1.
    SH060455  BAL0604            -1.   BAL0655             1.
    SH060555  COST            189.42   TRAN0605            1.
    SH060555  BAL0605            -1.   BAL0655             1.
    SH060655  COST             356.7   TRAN0606            1.
    SH060655  BAL0652            -1.   BAL0655             1.
    SH060755  COST            131.61   TRAN0607            1.
    SH060755  BAL0664            -1.   BAL0655             1.
    SH060855  COST            361.62   TRAN0608            1.
    SH060855  BAL0683            -1.   BAL0655             1.
    SH060156  COST             479.7   TRAN0601            1.
    SH060156  BAL0601            -1.   BAL0656             1.
    SH060556  COST            167.28   TRAN0605            1.
    SH060556  BAL0605            -1.   BAL0656             1.
    SH060157  COST            321.03   TRAN0601            1.
    SH060157  BAL0601            -1.   BAL0657             1.
    SH060557  COST            206.64   TRAN0605            1.
    SH060557  BAL0605            -1.   BAL0657             1.
    SH060158  COST            361.62   TRAN0601            1.
    SH060158  BAL0601            -1.   BAL0658             1.
    SH060258  COST            640.83   TRAN0602            1.
    SH060258  BAL0602            -1.   BAL0658             1.
    SH060358  COST            341.94   TRAN0603            1.
    SH060358  BAL0603            -1.   BAL0658             1.
    SH060458  COST            421.89   TRAN0604            1.
    SH060458  BAL0604            -1.   BAL0658             1.
    SH060558  COST             25.83   TRAN0605            1.
    SH060558  BAL0605            -1.   BAL0658             1.
    SH060658  COST            400.98   TRAN0606            1.
    SH060658  BAL0652            -1.   BAL0658             1.
    SH060758  COST             83.64   TRAN0607            1.
    SH060758  BAL0664            -1.   BAL0658             1.
    SH060858  COST            312.42   TRAN0608            1.
    SH060858  BAL0683            -1.   BAL0658             1.
    SH060159  COST            253.38   TRAN0601            1.
    SH060159  BAL0601            -1.   BAL0659             1.
    SH060259  COST            612.54   TRAN0602            1.
    SH060259  BAL0602            -1.   BAL0659             1.
    SH060359  COST            292.74   TRAN0603            1.
    SH060359  BAL0603            -1.   BAL0659             1.
    SH060459  COST            300.12   TRAN0604            1.
    SH060459  BAL0604            -1.   BAL0659             1.
    SH060559  COST            195.57   TRAN0605            1.
    SH060559  BAL0605            -1.   BAL0659             1.
    SH060659  COST            365.31   TRAN0606            1.
    SH060659  BAL0652            -1.   BAL0659             1.
    SH060759  COST            129.15   TRAN0607            1.
    SH060759  BAL0664            -1.   BAL0659             1.
    SH060859  COST            313.65   TRAN0608            1.
    SH060859  BAL0683            -1.   BAL0659             1.
    SH060160  COST            321.03   TRAN0601            1.
    SH060160  BAL0601            -1.   BAL0660             1.
    SH060260  COST             676.5   TRAN0602            1.
    SH060260  BAL0602            -1.   BAL0660             1.
    SH060360  COST            348.09   TRAN0603            1.
    SH060360  BAL0603            -1.   BAL0660             1.
    SH060460  COST            383.76   TRAN0604            1.
    SH060460  BAL0604            -1.   BAL0660             1.
    SH060560  COST            166.05   TRAN0605            1.
    SH060560  BAL0605            -1.   BAL0660             1.
    SH060660  COST            397.29   TRAN0606            1.
    SH060660  BAL0652            -1.   BAL0660             1.
    SH060760  COST            108.24   TRAN0607            1.
    SH060760  BAL0664            -1.   BAL0660             1.
    SH060860  COST            367.77   TRAN0608            1.
    SH060860  BAL0683            -1.   BAL0660             1.
    SH060163  COST            327.18   TRAN0601            1.
    SH060163  BAL0601            -1.   BAL0663             1.
    SH060563  COST            186.96   TRAN0605            1.
    SH060563  BAL0605            -1.   BAL0663             1.
    SH060164  COST            244.77   TRAN0601            1.
    SH060164  BAL0601            -1.   BAL0664             1.
    SH060264  COST            646.98   TRAN0602            1.
    SH060264  BAL0602            -1.   BAL0664             1.
    SH060364  COST            274.29   TRAN0603            1.
    SH060364  BAL0603            -1.   BAL0664             1.
    SH060464  COST            413.28   TRAN0604            1.
    SH060464  BAL0604            -1.   BAL0664             1.
    SH060564  COST             71.34   TRAN0605            1.
    SH060564  BAL0605            -1.   BAL0664             1.
    SH060664  COST            389.91   TRAN0606            1.
    SH060664  BAL0652            -1.   BAL0664             1.
    SH060864  COST             307.5   TRAN0608            1.
    SH060864  BAL0683            -1.   BAL0664             1.
    SH060265  COST            377.61   TRAN0602            1.
    SH060265  BAL0602            -1.   BAL0665             1.
    SH060266  COST            318.57   TRAN0602            1.
    SH060266  BAL0602            -1.   BAL0666             1.
    SH060267  COST            285.36   TRAN0602            1.
    SH060267  BAL0602            -1.   BAL0667             1.
    SH060268  COST              492.   TRAN0602            1.
    SH060268  BAL0602            -1.   BAL0668             1.
    SH060269  COST            271.83   TRAN0602            1.
    SH060269  BAL0602            -1.   BAL0669             1.
    SH060171  COST             541.2   TRAN0601            1.
    SH060171  BAL0601            -1.   BAL0671             1.
    SH060371  COST            644.52   TRAN0603            1.
    SH060371  BAL0603            -1.   BAL0671             1.
    SH060471  COST            640.83   TRAN0604            1.
    SH060471  BAL0604            -1.   BAL0671             1.
    SH060571  COST            714.63   TRAN0605            1.
    SH060571  BAL0605            -1.   BAL0671             1.
    SH060671  COST            480.93   TRAN0606            1.
    SH060671  BAL0652            -1.   BAL0671             1.
    SH060771  COST            865.92   TRAN0607            1.
    SH060771  BAL0664            -1.   BAL0671             1.
    SH060871  COST            655.59   TRAN0608            1.
    SH060871  BAL0683            -1.   BAL0671             1.
    SH060272  COST            667.89   TRAN0602            1.
    SH060272  BAL0602            -1.   BAL0672             1.
    SH060173  COST             479.7   TRAN0601            1.
    SH060173  BAL0601            -1.   BAL0673             1.
    SH060273  COST            448.95   TRAN0602            1.
    SH060273  BAL0602            -1.   BAL0673             1.
    SH060373  COST            415.74   TRAN0603            1.
    SH060373  BAL0603            -1.   BAL0673             1.
    SH060473  COST            562.11   TRAN0604            1.
    SH060473  BAL0604            -1.   BAL0673             1.
    SH060573  COST            693.72   TRAN0605            1.
    SH060573  BAL0605            -1.   BAL0673             1.
    SH060673  COST            375.15   TRAN0606            1.
    SH060673  BAL0652            -1.   BAL0673             1.
    SH060873  COST            619.92   TRAN0608            1.
    SH060873  BAL0683            -1.   BAL0673             1.
    SH060274  COST             258.3   TRAN0602            1.
    SH060274  BAL0602            -1.   BAL0674             1.
    SH060275  COST            681.42   TRAN0602            1.
    SH060275  BAL0602            -1.   BAL0675             1.
    SH060276  COST            493.23   TRAN0602            1.
    SH060276  BAL0602            -1.   BAL0676             1.
    SH060177  COST            535.05   TRAN0601            1.
    SH060177  BAL0601            -1.   BAL0677             1.
    SH060277  COST            334.56   TRAN0602            1.
    SH060277  BAL0602            -1.   BAL0677             1.
    SH060377  COST            567.03   TRAN0603            1.
    SH060377  BAL0603            -1.   BAL0677             1.
    SH060477  COST            493.23   TRAN0604            1.
    SH060477  BAL0604            -1.   BAL0677             1.
    SH060577  COST             688.8   TRAN0605            1.
    SH060577  BAL0605            -1.   BAL0677             1.
    SH060877  COST             393.6   TRAN0608            1.
    SH060877  BAL0683            -1.   BAL0677             1.
    SH060178  COST            936.03   TRAN0601            1.
    SH060178  BAL0601            -1.   BAL0678             1.
    SH060278  COST            543.66   TRAN0602            1.
    SH060278  BAL0602            -1.   BAL0678             1.
    SH060378  COST            963.09   TRAN0603            1.
    SH060378  BAL0603            -1.   BAL0678             1.
    SH060478  COST            842.55   TRAN0604            1.
    SH060478  BAL0604            -1.   BAL0678             1.
    SH060578  COST           1081.17   TRAN0605            1.
    SH060578  BAL0605            -1.   BAL0678             1.
    SH060878  COST            942.18   TRAN0608            1.
    SH060878  BAL0683            -1.   BAL0678             1.
    SH060279  COST            330.87   TRAN0602            1.
    SH060279  BAL0602            -1.   BAL0679             1.
    SH060480  COST            460.02   TRAN0604            1.
    SH060480  BAL0604            -1.   BAL0680             1.
    SH060182  COST            715.86   TRAN0601            1.
    SH060182  BAL0601            -1.   BAL0682             1.
    SH060282  COST            404.67   TRAN0602            1.
    SH060282  BAL0602            -1.   BAL0682             1.
    SH060382  COST            805.65   TRAN0603            1.
    SH060382  BAL0603            -1.   BAL0682             1.
    SH060482  COST            868.38   TRAN0604            1.
    SH060482  BAL0604            -1.   BAL0682             1.
    SH060582  COST           1410.81   TRAN0605            1.
    SH060582  BAL0605            -1.   BAL0682             1.
    SH060882  COST            963.09   TRAN0608            1.
    SH060882  BAL0683            -1.   BAL0682             1.
    SH060183  COST            217.71   TRAN0601            1.
    SH060183  BAL0601            -1.   BAL0683             1.
    SH060283  COST             639.6   TRAN0602            1.
    SH060283  BAL0602            -1.   BAL0683             1.
    SH060383  COST            334.56   TRAN0603            1.
    SH060383  BAL0603            -1.   BAL0683             1.
    SH060483  COST             72.57   TRAN0604            1.
    SH060483  BAL0604            -1.   BAL0683             1.
    SH060583  COST            426.81   TRAN0605            1.
    SH060583  BAL0605            -1.   BAL0683             1.
    SH060683  COST            305.04   TRAN0606            1.
    SH060683  BAL0652            -1.   BAL0683             1.
    SH060284  COST            236.16   TRAN0602            1.
    SH060284  BAL0602            -1.   BAL0684             1.
    SH070201  COST            323.73   TRAN0702            1.
    SH070201  BAL0702            -1.   BAL0701             1.
    SH070301  COST            124.26   TRAN0703            1.
    SH070301  BAL0703            -1.   BAL0701             1.
    SH070401  COST            226.72   TRAN0704            1.
    SH070401  BAL0704            -1.   BAL0701             1.
    SH070501  COST            258.33   TRAN0705            1.
    SH070501  BAL0705            -1.   BAL0701             1.
    SH070601  COST            137.34   TRAN0706            1.
    SH070601  BAL0752            -1.   BAL0701             1.
    SH070801  COST            155.87   TRAN0708            1.
    SH070801  BAL0783            -1.   BAL0701             1.
    SH070102  COST            516.66   TRAN0701            1.
    SH070102  BAL0701            -1.   BAL0702             1.
    SH070302  COST            454.53   TRAN0703            1.
    SH070302  BAL0703            -1.   BAL0702             1.
    SH070402  COST            667.08   TRAN0704            1.
    SH070402  BAL0704            -1.   BAL0702             1.
    SH070502  COST            807.69   TRAN0705            1.
    SH070502  BAL0705            -1.   BAL0702             1.
    SH070602  COST            412.02   TRAN0706            1.
    SH070602  BAL0752            -1.   BAL0702             1.
    SH070802  COST            567.89   TRAN0708            1.
    SH070802  BAL0783            -1.   BAL0702             1.
    SH070103  COST            267.05   TRAN0701            1.
    SH070103  BAL0701            -1.   BAL0703             1.
    SH070203  COST            516.66   TRAN0702            1.
    SH070203  BAL0702            -1.   BAL0703             1.
    SH070403  COST            400.03   TRAN0704            1.
    SH070403  BAL0704            -1.   BAL0703             1.
    SH070503  COST            309.56   TRAN0705            1.
    SH070503  BAL0705            -1.   BAL0703             1.
    SH070603  COST              98.1   TRAN0706            1.
    SH070603  BAL0752            -1.   BAL0703             1.
    SH070803  COST            277.95   TRAN0708            1.
    SH070803  BAL0783            -1.   BAL0703             1.
    SH070104  COST            189.66   TRAN0701            1.
    SH070104  BAL0701            -1.   BAL0704             1.
    SH070204  COST            548.27   TRAN0702            1.
    SH070204  BAL0702            -1.   BAL0704             1.
    SH070304  COST            264.87   TRAN0703            1.
    SH070304  BAL0703            -1.   BAL0704             1.
    SH070504  COST            347.71   TRAN0705            1.
    SH070504  BAL0705            -1.   BAL0704             1.
    SH070604  COST            267.05   TRAN0706            1.
    SH070604  BAL0752            -1.   BAL0704             1.
    SH070804  COST             63.22   TRAN0708            1.
    SH070804  BAL0783            -1.   BAL0704             1.
    SH070105  COST             294.3   TRAN0701            1.
    SH070105  BAL0701            -1.   BAL0705             1.
    SH070205  COST            562.44   TRAN0702            1.
    SH070205  BAL0702            -1.   BAL0705             1.
    SH070305  COST            309.56   TRAN0703            1.
    SH070305  BAL0703            -1.   BAL0705             1.
    SH070405  COST            310.65   TRAN0704            1.
    SH070405  BAL0704            -1.   BAL0705             1.
    SH070605  COST            355.34   TRAN0706            1.
    SH070605  BAL0752            -1.   BAL0705             1.
    SH070705  COST            364.06   TRAN0707            1.
    SH070705  BAL0764            -1.   BAL0705             1.
    SH070805  COST            295.39   TRAN0708            1.
    SH070805  BAL0783            -1.   BAL0705             1.
    SH070106  COST            216.91   TRAN0701            1.
    SH070106  BAL0701            -1.   BAL0706             1.
    SH070107  COST             22.89   TRAN0701            1.
    SH070107  BAL0701            -1.   BAL0707             1.
    SH070207  COST            318.28   TRAN0702            1.
    SH070207  BAL0702            -1.   BAL0707             1.
    SH070307  COST            135.16   TRAN0703            1.
    SH070307  BAL0703            -1.   BAL0707             1.
    SH070407  COST            225.63   TRAN0704            1.
    SH070407  BAL0704            -1.   BAL0707             1.
    SH070507  COST            249.61   TRAN0705            1.
    SH070507  BAL0705            -1.   BAL0707             1.
    SH070607  COST            136.25   TRAN0706            1.
    SH070607  BAL0752            -1.   BAL0707             1.
    SH070707  COST            252.88   TRAN0707            1.
    SH070707  BAL0764            -1.   BAL0707             1.
    SH070807  COST            168.95   TRAN0708            1.
    SH070807  BAL0783            -1.   BAL0707             1.
    SH070108  COST             71.94   TRAN0701            1.
    SH070108  BAL0701            -1.   BAL0708             1.
    SH070208  COST            409.84   TRAN0702            1.
    SH070208  BAL0702            -1.   BAL0708             1.
    SH070308  COST            153.69   TRAN0703            1.
    SH070308  BAL0703            -1.   BAL0708             1.
    SH070408  COST            269.23   TRAN0704            1.
    SH070408  BAL0704            -1.   BAL0708             1.
    SH070508  COST            198.38   TRAN0705            1.
    SH070508  BAL0705            -1.   BAL0708             1.
    SH070608  COST            180.94   TRAN0706            1.
    SH070608  BAL0752            -1.   BAL0708             1.
    SH070808  COST            203.83   TRAN0708            1.
    SH070808  BAL0783            -1.   BAL0708             1.
    SH070109  COST            150.42   TRAN0701            1.
    SH070109  BAL0701            -1.   BAL0709             1.
    SH070110  COST            269.23   TRAN0701            1.
    SH070110  BAL0701            -1.   BAL0710             1.
    SH070210  COST            172.22   TRAN0702            1.
    SH070210  BAL0702            -1.   BAL0710             1.
    SH070310  COST             261.6   TRAN0703            1.
    SH070310  BAL0703            -1.   BAL0710             1.
    SH070410  COST            391.31   TRAN0704            1.
    SH070410  BAL0704            -1.   BAL0710             1.
    SH070510  COST            419.65   TRAN0705            1.
    SH070510  BAL0705            -1.   BAL0710             1.
    SH070610  COST            245.25   TRAN0706            1.
    SH070610  BAL0752            -1.   BAL0710             1.
    SH070810  COST            332.45   TRAN0708            1.
    SH070810  BAL0783            -1.   BAL0710             1.
    SH070111  COST            115.54   TRAN0701            1.
    SH070111  BAL0701            -1.   BAL0711             1.
    SH070112  COST             95.92   TRAN0701            1.
    SH070112  BAL0701            -1.   BAL0712             1.
    SH070114  COST            154.78   TRAN0701            1.
    SH070114  BAL0701            -1.   BAL0714             1.
    SH070614  COST            204.92   TRAN0706            1.
    SH070614  BAL0752            -1.   BAL0714             1.
    SH070115  COST            330.27   TRAN0701            1.
    SH070115  BAL0701            -1.   BAL0715             1.
    SH070215  COST            173.31   TRAN0702            1.
    SH070215  BAL0702            -1.   BAL0715             1.
    SH070315  COST            255.06   TRAN0703            1.
    SH070315  BAL0703            -1.   BAL0715             1.
    SH070415  COST            518.84   TRAN0704            1.
    SH070415  BAL0704            -1.   BAL0715             1.
    SH070515  COST            433.82   TRAN0705            1.
    SH070515  BAL0705            -1.   BAL0715             1.
    SH070615  COST            204.92   TRAN0706            1.
    SH070615  BAL0752            -1.   BAL0715             1.
    SH070815  COST            406.57   TRAN0708            1.
    SH070815  BAL0783            -1.   BAL0715             1.
    SH070116  COST            172.22   TRAN0701            1.
    SH070116  BAL0701            -1.   BAL0716             1.
    SH070216  COST             305.2   TRAN0702            1.
    SH070216  BAL0702            -1.   BAL0716             1.
    SH070316  COST            247.43   TRAN0703            1.
    SH070316  BAL0703            -1.   BAL0716             1.
    SH070416  COST            312.83   TRAN0704            1.
    SH070416  BAL0704            -1.   BAL0716             1.
    SH070516  COST            347.71   TRAN0705            1.
    SH070516  BAL0705            -1.   BAL0716             1.
    SH070616  COST            142.79   TRAN0706            1.
    SH070616  BAL0752            -1.   BAL0716             1.
    SH070816  COST            223.45   TRAN0708            1.
    SH070816  BAL0783            -1.   BAL0716             1.
    SH070117  COST            164.59   TRAN0701            1.
    SH070117  BAL0701            -1.   BAL0717             1.
    SH070817  COST             29.43   TRAN0708            1.
    SH070817  BAL0783            -1.   BAL0717             1.
    SH070418  COST            167.86   TRAN0704            1.
    SH070418  BAL0704            -1.   BAL0718             1.
    SH070119  COST            270.32   TRAN0701            1.
    SH070119  BAL0701            -1.   BAL0719             1.
    SH070219  COST            748.83   TRAN0702            1.
    SH070219  BAL0702            -1.   BAL0719             1.
    SH070319  COST            345.53   TRAN0703            1.
    SH070319  BAL0703            -1.   BAL0719             1.
    SH070419  COST            173.31   TRAN0704            1.
    SH070419  BAL0704            -1.   BAL0719             1.
    SH070519  COST            226.72   TRAN0705            1.
    SH070519  BAL0705            -1.   BAL0719             1.
    SH070619  COST            376.05   TRAN0706            1.
    SH070619  BAL0752            -1.   BAL0719             1.
    SH070819  COST            107.91   TRAN0708            1.
    SH070819  BAL0783            -1.   BAL0719             1.
    SH070120  COST            223.45   TRAN0701            1.
    SH070120  BAL0701            -1.   BAL0720             1.
    SH070220  COST            744.47   TRAN0702            1.
    SH070220  BAL0702            -1.   BAL0720             1.
    SH070320  COST            323.73   TRAN0703            1.
    SH070320  BAL0703            -1.   BAL0720             1.
    SH070420  COST            123.17   TRAN0704            1.
    SH070420  BAL0704            -1.   BAL0720             1.
    SH070520  COST            317.19   TRAN0705            1.
    SH070520  BAL0705            -1.   BAL0720             1.
    SH070820  COST            137.34   TRAN0708            1.
    SH070820  BAL0783            -1.   BAL0720             1.
    SH070121  COST            439.27   TRAN0701            1.
    SH070121  BAL0701            -1.   BAL0721             1.
    SH070221  COST            401.12   TRAN0702            1.
    SH070221  BAL0702            -1.   BAL0721             1.
    SH070321  COST            486.14   TRAN0703            1.
    SH070321  BAL0703            -1.   BAL0721             1.
    SH070421  COST             348.8   TRAN0704            1.
    SH070421  BAL0704            -1.   BAL0721             1.
    SH070521  COST             599.5   TRAN0705            1.
    SH070521  BAL0705            -1.   BAL0721             1.
    SH070821  COST             348.8   TRAN0708            1.
    SH070821  BAL0783            -1.   BAL0721             1.
    SH070422  COST            244.16   TRAN0704            1.
    SH070422  BAL0704            -1.   BAL0722             1.
    SH070423  COST            182.03   TRAN0704            1.
    SH070423  BAL0704            -1.   BAL0723             1.
    SH070124  COST           1565.24   TRAN0701            1.
    SH070124  BAL0701            -1.   BAL0724             1.
    SH070225  COST            465.43   TRAN0702            1.
    SH070225  BAL0702            -1.   BAL0725             1.
    SH070426  COST             294.3   TRAN0704            1.
    SH070426  BAL0704            -1.   BAL0726             1.
    SH070627  COST            292.12   TRAN0706            1.
    SH070627  BAL0752            -1.   BAL0727             1.
    SH070128  COST            264.87   TRAN0701            1.
    SH070128  BAL0701            -1.   BAL0728             1.
    SH070528  COST            111.18   TRAN0705            1.
    SH070528  BAL0705            -1.   BAL0728             1.
    SH070429  COST            216.91   TRAN0704            1.
    SH070429  BAL0704            -1.   BAL0729             1.
    SH070430  COST            331.36   TRAN0704            1.
    SH070430  BAL0704            -1.   BAL0730             1.
    SH070131  COST            120.99   TRAN0701            1.
    SH070131  BAL0701            -1.   BAL0731             1.
    SH070432  COST            171.13   TRAN0704            1.
    SH070432  BAL0704            -1.   BAL0732             1.
    SH070133  COST            537.37   TRAN0701            1.
    SH070133  BAL0701            -1.   BAL0733             1.
    SH070233  COST              436.   TRAN0702            1.
    SH070233  BAL0702            -1.   BAL0733             1.
    SH070333  COST            591.87   TRAN0703            1.
    SH070333  BAL0703            -1.   BAL0733             1.
    SH070433  COST            485.05   TRAN0704            1.
    SH070433  BAL0704            -1.   BAL0733             1.
    SH070533  COST            687.79   TRAN0705            1.
    SH070533  BAL0705            -1.   BAL0733             1.
    SH070833  COST            415.29   TRAN0708            1.
    SH070833  BAL0783            -1.   BAL0733             1.
    SH070134  COST            420.74   TRAN0701            1.
    SH070134  BAL0701            -1.   BAL0734             1.
    SH070234  COST            713.95   TRAN0702            1.
    SH070234  BAL0702            -1.   BAL0734             1.
    SH070334  COST            548.27   TRAN0703            1.
    SH070334  BAL0703            -1.   BAL0734             1.
    SH070434  COST            229.99   TRAN0704            1.
    SH070434  BAL0704            -1.   BAL0734             1.
    SH070534  COST            480.69   TRAN0705            1.
    SH070534  BAL0705            -1.   BAL0734             1.
    SH070834  COST            286.67   TRAN0708            1.
    SH070834  BAL0783            -1.   BAL0734             1.
    SH070435  COST            132.98   TRAN0704            1.
    SH070435  BAL0704            -1.   BAL0735             1.
    SH070636  COST             119.9   TRAN0706            1.
    SH070636  BAL0752            -1.   BAL0736             1.
    SH070137  COST            100.28   TRAN0701            1.
    SH070137  BAL0701            -1.   BAL0737             1.
    SH070237  COST            372.78   TRAN0702            1.
    SH070237  BAL0702            -1.   BAL0737             1.
    SH070337  COST            172.22   TRAN0703            1.
    SH070337  BAL0703            -1.   BAL0737             1.
    SH070437  COST            331.36   TRAN0704            1.
    SH070437  BAL0704            -1.   BAL0737             1.
    SH070537  COST            198.38   TRAN0705            1.
    SH070537  BAL0705            -1.   BAL0737             1.
    SH070637  COST            211.46   TRAN0706            1.
    SH070637  BAL0752            -1.   BAL0737             1.
    SH070837  COST            274.68   TRAN0708            1.
    SH070837  BAL0783            -1.   BAL0737             1.
    SH070138  COST            148.24   TRAN0701            1.
    SH070138  BAL0701            -1.   BAL0738             1.
    SH070238  COST            265.96   TRAN0702            1.
    SH070238  BAL0702            -1.   BAL0738             1.
    SH070338  COST            103.55   TRAN0703            1.
    SH070338  BAL0703            -1.   BAL0738             1.
    SH070438  COST            335.72   TRAN0704            1.
    SH070438  BAL0704            -1.   BAL0738             1.
    SH070538  COST            303.02   TRAN0705            1.
    SH070538  BAL0705            -1.   BAL0738             1.
    SH070638  COST             42.51   TRAN0706            1.
    SH070638  BAL0752            -1.   BAL0738             1.
    SH070738  COST            235.44   TRAN0707            1.
    SH070738  BAL0764            -1.   BAL0738             1.
    SH070838  COST            258.33   TRAN0708            1.
    SH070838  BAL0783            -1.   BAL0738             1.
    SH070139  COST             141.7   TRAN0701            1.
    SH070139  BAL0701            -1.   BAL0739             1.
    SH070140  COST            179.85   TRAN0701            1.
    SH070140  BAL0701            -1.   BAL0740             1.
    SH070240  COST            412.02   TRAN0702            1.
    SH070240  BAL0702            -1.   BAL0740             1.
    SH070340  COST            112.27   TRAN0703            1.
    SH070340  BAL0703            -1.   BAL0740             1.
    SH070440  COST            323.73   TRAN0704            1.
    SH070440  BAL0704            -1.   BAL0740             1.
    SH070540  COST            240.89   TRAN0705            1.
    SH070540  BAL0705            -1.   BAL0740             1.
    SH070640  COST            142.79   TRAN0706            1.
    SH070640  BAL0752            -1.   BAL0740             1.
    SH070840  COST            298.66   TRAN0708            1.
    SH070840  BAL0783            -1.   BAL0740             1.
    SH070641  COST              109.   TRAN0706            1.
    SH070641  BAL0752            -1.   BAL0741             1.
    SH070142  COST              98.1   TRAN0701            1.
    SH070142  BAL0701            -1.   BAL0742             1.
    SH070143  COST            173.31   TRAN0701            1.
    SH070143  BAL0701            -1.   BAL0743             1.
    SH070243  COST            430.55   TRAN0702            1.
    SH070243  BAL0702            -1.   BAL0743             1.
    SH070343  COST             27.25   TRAN0703            1.
    SH070343  BAL0703            -1.   BAL0743             1.
    SH070443  COST            322.64   TRAN0704            1.
    SH070443  BAL0704            -1.   BAL0743             1.
    SH070543  COST            281.22   TRAN0705            1.
    SH070543  BAL0705            -1.   BAL0743             1.
    SH070643  COST              109.   TRAN0706            1.
    SH070643  BAL0752            -1.   BAL0743             1.
    SH070743  COST            262.69   TRAN0707            1.
    SH070743  BAL0764            -1.   BAL0743             1.
    SH070843  COST            295.39   TRAN0708            1.
    SH070843  BAL0783            -1.   BAL0743             1.
    SH070644  COST             97.01   TRAN0706            1.
    SH070644  BAL0752            -1.   BAL0744             1.
    SH070145  COST            187.48   TRAN0701            1.
    SH070145  BAL0701            -1.   BAL0745             1.
    SH070245  COST            475.24   TRAN0702            1.
    SH070245  BAL0702            -1.   BAL0745             1.
    SH070345  COST            175.49   TRAN0703            1.
    SH070345  BAL0703            -1.   BAL0745             1.
    SH070445  COST            318.28   TRAN0704            1.
    SH070445  BAL0704            -1.   BAL0745             1.
    SH070545  COST            255.06   TRAN0705            1.
    SH070545  BAL0705            -1.   BAL0745             1.
    SH070645  COST            208.19   TRAN0706            1.
    SH070645  BAL0752            -1.   BAL0745             1.
    SH070745  COST            214.73   TRAN0707            1.
    SH070745  BAL0764            -1.   BAL0745             1.
    SH070845  COST            332.45   TRAN0708            1.
    SH070845  BAL0783            -1.   BAL0745             1.
    SH070146  COST            267.05   TRAN0701            1.
    SH070146  BAL0701            -1.   BAL0746             1.
    SH070246  COST            297.57   TRAN0702            1.
    SH070246  BAL0702            -1.   BAL0746             1.
    SH070346  COST            240.89   TRAN0703            1.
    SH070346  BAL0703            -1.   BAL0746             1.
    SH070446  COST            487.23   TRAN0704            1.
    SH070446  BAL0704            -1.   BAL0746             1.
    SH070546  COST             468.7   TRAN0705            1.
    SH070546  BAL0705            -1.   BAL0746             1.
    SH070646  COST            280.13   TRAN0706            1.
    SH070646  BAL0752            -1.   BAL0746             1.
    SH070846  COST            488.32   TRAN0708            1.
    SH070846  BAL0783            -1.   BAL0746             1.
    SH070147  COST             119.9   TRAN0701            1.
    SH070147  BAL0701            -1.   BAL0747             1.
    SH070148  COST            103.55   TRAN0701            1.
    SH070148  BAL0701            -1.   BAL0748             1.
    SH070149  COST            358.61   TRAN0701            1.
    SH070149  BAL0701            -1.   BAL0749             1.
    SH070549  COST            165.68   TRAN0705            1.
    SH070549  BAL0705            -1.   BAL0749             1.
    SH070150  COST            262.69   TRAN0701            1.
    SH070150  BAL0701            -1.   BAL0750             1.
    SH070151  COST            361.88   TRAN0701            1.
    SH070151  BAL0701            -1.   BAL0751             1.
    SH070551  COST            134.07   TRAN0705            1.
    SH070551  BAL0705            -1.   BAL0751             1.
    SH070152  COST            122.08   TRAN0701            1.
    SH070152  BAL0701            -1.   BAL0752             1.
    SH070252  COST              327.   TRAN0702            1.
    SH070252  BAL0702            -1.   BAL0752             1.
    SH070352  COST             89.38   TRAN0703            1.
    SH070352  BAL0703            -1.   BAL0752             1.
    SH070452  COST            350.98   TRAN0704            1.
    SH070452  BAL0704            -1.   BAL0752             1.
    SH070552  COST            321.55   TRAN0705            1.
    SH070552  BAL0705            -1.   BAL0752             1.
    SH070852  COST            275.77   TRAN0708            1.
    SH070852  BAL0783            -1.   BAL0752             1.
    SH070153  COST            391.31   TRAN0701            1.
    SH070153  BAL0701            -1.   BAL0753             1.
    SH070253  COST            693.24   TRAN0702            1.
    SH070253  BAL0702            -1.   BAL0753             1.
    SH070353  COST            354.25   TRAN0703            1.
    SH070353  BAL0703            -1.   BAL0753             1.
    SH070453  COST            449.08   TRAN0704            1.
    SH070453  BAL0704            -1.   BAL0753             1.
    SH070553  COST            200.56   TRAN0705            1.
    SH070553  BAL0705            -1.   BAL0753             1.
    SH070653  COST            391.31   TRAN0706            1.
    SH070653  BAL0752            -1.   BAL0753             1.
    SH070753  COST            159.14   TRAN0707            1.
    SH070753  BAL0764            -1.   BAL0753             1.
    SH070853  COST            439.27   TRAN0708            1.
    SH070853  BAL0783            -1.   BAL0753             1.
    SH070154  COST            201.65   TRAN0701            1.
    SH070154  BAL0701            -1.   BAL0754             1.
    SH070155  COST            303.02   TRAN0701            1.
    SH070155  BAL0701            -1.   BAL0755             1.
    SH070255  COST            522.11   TRAN0702            1.
    SH070255  BAL0702            -1.   BAL0755             1.
    SH070355  COST            306.29   TRAN0703            1.
    SH070355  BAL0703            -1.   BAL0755             1.
    SH070455  COST            320.46   TRAN0704            1.
    SH070455  BAL0704            -1.   BAL0755             1.
    SH070555  COST            167.86   TRAN0705            1.
    SH070555  BAL0705            -1.   BAL0755             1.
    SH070655  COST             316.1   TRAN0706            1.
    SH070655  BAL0752            -1.   BAL0755             1.
    SH070755  COST            116.63   TRAN0707            1.
    SH070755  BAL0764            -1.   BAL0755             1.
    SH070855  COST            320.46   TRAN0708            1.
    SH070855  BAL0783            -1.   BAL0755             1.
    SH070156  COST             425.1   TRAN0701            1.
    SH070156  BAL0701            -1.   BAL0756             1.
    SH070556  COST            148.24   TRAN0705            1.
    SH070556  BAL0705            -1.   BAL0756             1.
    SH070157  COST            284.49   TRAN0701            1.
    SH070157  BAL0701            -1.   BAL0757             1.
    SH070557  COST            183.12   TRAN0705            1.
    SH070557  BAL0705            -1.   BAL0757             1.
    SH070158  COST            320.46   TRAN0701            1.
    SH070158  BAL0701            -1.   BAL0758             1.
    SH070258  COST            567.89   TRAN0702            1.
    SH070258  BAL0702            -1.   BAL0758             1.
    SH070358  COST            303.02   TRAN0703            1.
    SH070358  BAL0703            -1.   BAL0758             1.
    SH070458  COST            373.87   TRAN0704            1.
    SH070458  BAL0704            -1.   BAL0758             1.
    SH070558  COST             22.89   TRAN0705            1.
    SH070558  BAL0705            -1.   BAL0758             1.
    SH070658  COST            355.34   TRAN0706            1.
    SH070658  BAL0752            -1.   BAL0758             1.
    SH070758  COST             74.12   TRAN0707            1.
    SH070758  BAL0764            -1.   BAL0758             1.
    SH070858  COST            276.86   TRAN0708            1.
    SH070858  BAL0783            -1.   BAL0758             1.
    SH070159  COST            224.54   TRAN0701            1.
    SH070159  BAL0701            -1.   BAL0759             1.
    SH070259  COST            542.82   TRAN0702            1.
    SH070259  BAL0702            -1.   BAL0759             1.
    SH070359  COST            259.42   TRAN0703            1.
    SH070359  BAL0703            -1.   BAL0759             1.
    SH070459  COST            265.96   TRAN0704            1.
    SH070459  BAL0704            -1.   BAL0759             1.
    SH070559  COST            173.31   TRAN0705            1.
    SH070559  BAL0705            -1.   BAL0759             1.
    SH070659  COST            323.73   TRAN0706            1.
    SH070659  BAL0752            -1.   BAL0759             1.
    SH070759  COST            114.45   TRAN0707            1.
    SH070759  BAL0764            -1.   BAL0759             1.
    SH070859  COST            277.95   TRAN0708            1.
    SH070859  BAL0783            -1.   BAL0759             1.
    SH070160  COST            284.49   TRAN0701            1.
    SH070160  BAL0701            -1.   BAL0760             1.
    SH070260  COST             599.5   TRAN0702            1.
    SH070260  BAL0702            -1.   BAL0760             1.
    SH070360  COST            308.47   TRAN0703            1.
    SH070360  BAL0703            -1.   BAL0760             1.
    SH070460  COST            340.08   TRAN0704            1.
    SH070460  BAL0704            -1.   BAL0760             1.
    SH070560  COST            147.15   TRAN0705            1.
    SH070560  BAL0705            -1.   BAL0760             1.
    SH070660  COST            352.07   TRAN0706            1.
    SH070660  BAL0752            -1.   BAL0760             1.
    SH070760  COST             95.92   TRAN0707            1.
    SH070760  BAL0764            -1.   BAL0760             1.
    SH070860  COST            325.91   TRAN0708            1.
    SH070860  BAL0783            -1.   BAL0760             1.
    SH070163  COST            289.94   TRAN0701            1.
    SH070163  BAL0701            -1.   BAL0763             1.
    SH070563  COST            165.68   TRAN0705            1.
    SH070563  BAL0705            -1.   BAL0763             1.
    SH070164  COST            216.91   TRAN0701            1.
    SH070164  BAL0701            -1.   BAL0764             1.
    SH070264  COST            573.34   TRAN0702            1.
    SH070264  BAL0702            -1.   BAL0764             1.
    SH070364  COST            243.07   TRAN0703            1.
    SH070364  BAL0703            -1.   BAL0764             1.
    SH070464  COST            366.24   TRAN0704            1.
    SH070464  BAL0704            -1.   BAL0764             1.
    SH070564  COST             63.22   TRAN0705            1.
    SH070564  BAL0705            -1.   BAL0764             1.
    SH070664  COST            345.53   TRAN0706            1.
    SH070664  BAL0752            -1.   BAL0764             1.
    SH070864  COST             272.5   TRAN0708            1.
    SH070864  BAL0783            -1.   BAL0764             1.
    SH070265  COST            334.63   TRAN0702            1.
    SH070265  BAL0702            -1.   BAL0765             1.
    SH070266  COST            282.31   TRAN0702            1.
    SH070266  BAL0702            -1.   BAL0766             1.
    SH070267  COST            252.88   TRAN0702            1.
    SH070267  BAL0702            -1.   BAL0767             1.
    SH070268  COST              436.   TRAN0702            1.
    SH070268  BAL0702            -1.   BAL0768             1.
    SH070269  COST            240.89   TRAN0702            1.
    SH070269  BAL0702            -1.   BAL0769             1.
    SH070171  COST             479.6   TRAN0701            1.
    SH070171  BAL0701            -1.   BAL0771             1.
    SH070371  COST            571.16   TRAN0703            1.
    SH070371  BAL0703            -1.   BAL0771             1.
    SH070471  COST            567.89   TRAN0704            1.
    SH070471  BAL0704            -1.   BAL0771             1.
    SH070571  COST            633.29   TRAN0705            1.
    SH070571  BAL0705            -1.   BAL0771             1.
    SH070671  COST            426.19   TRAN0706            1.
    SH070671  BAL0752            -1.   BAL0771             1.
    SH070771  COST            767.36   TRAN0707            1.
    SH070771  BAL0764            -1.   BAL0771             1.
    SH070871  COST            580.97   TRAN0708            1.
    SH070871  BAL0783            -1.   BAL0771             1.
    SH070272  COST            591.87   TRAN0702            1.
    SH070272  BAL0702            -1.   BAL0772             1.
    SH070173  COST             425.1   TRAN0701            1.
    SH070173  BAL0701            -1.   BAL0773             1.
    SH070273  COST            397.85   TRAN0702            1.
    SH070273  BAL0702            -1.   BAL0773             1.
    SH070373  COST            368.42   TRAN0703            1.
    SH070373  BAL0703            -1.   BAL0773             1.
    SH070473  COST            498.13   TRAN0704            1.
    SH070473  BAL0704            -1.   BAL0773             1.
    SH070573  COST            614.76   TRAN0705            1.
    SH070573  BAL0705            -1.   BAL0773             1.
    SH070673  COST            332.45   TRAN0706            1.
    SH070673  BAL0752            -1.   BAL0773             1.
    SH070873  COST            549.36   TRAN0708            1.
    SH070873  BAL0783            -1.   BAL0773             1.
    SH070274  COST             228.9   TRAN0702            1.
    SH070274  BAL0702            -1.   BAL0774             1.
    SH070275  COST            603.86   TRAN0702            1.
    SH070275  BAL0702            -1.   BAL0775             1.
    SH070276  COST            437.09   TRAN0702            1.
    SH070276  BAL0702            -1.   BAL0776             1.
    SH070177  COST            474.15   TRAN0701            1.
    SH070177  BAL0701            -1.   BAL0777             1.
    SH070277  COST            296.48   TRAN0702            1.
    SH070277  BAL0702            -1.   BAL0777             1.
    SH070377  COST            502.49   TRAN0703            1.
    SH070377  BAL0703            -1.   BAL0777             1.
    SH070477  COST            437.09   TRAN0704            1.
    SH070477  BAL0704            -1.   BAL0777             1.
    SH070577  COST             610.4   TRAN0705            1.
    SH070577  BAL0705            -1.   BAL0777             1.
    SH070877  COST             348.8   TRAN0708            1.
    SH070877  BAL0783            -1.   BAL0777             1.
    SH070178  COST            829.49   TRAN0701            1.
    SH070178  BAL0701            -1.   BAL0778             1.
    SH070278  COST            481.78   TRAN0702            1.
    SH070278  BAL0702            -1.   BAL0778             1.
    SH070378  COST            853.47   TRAN0703            1.
    SH070378  BAL0703            -1.   BAL0778             1.
    SH070478  COST            746.65   TRAN0704            1.
    SH070478  BAL0704            -1.   BAL0778             1.
    SH070578  COST            958.11   TRAN0705            1.
    SH070578  BAL0705            -1.   BAL0778             1.
    SH070878  COST            834.94   TRAN0708            1.
    SH070878  BAL0783            -1.   BAL0778             1.
    SH070279  COST            293.21   TRAN0702            1.
    SH070279  BAL0702            -1.   BAL0779             1.
    SH070480  COST            407.66   TRAN0704            1.
    SH070480  BAL0704            -1.   BAL0780             1.
    SH070182  COST            634.38   TRAN0701            1.
    SH070182  BAL0701            -1.   BAL0782             1.
    SH070282  COST            358.61   TRAN0702            1.
    SH070282  BAL0702            -1.   BAL0782             1.
    SH070382  COST            713.95   TRAN0703            1.
    SH070382  BAL0703            -1.   BAL0782             1.
    SH070482  COST            769.54   TRAN0704            1.
    SH070482  BAL0704            -1.   BAL0782             1.
    SH070582  COST           1250.23   TRAN0705            1.
    SH070582  BAL0705            -1.   BAL0782             1.
    SH070882  COST            853.47   TRAN0708            1.
    SH070882  BAL0783            -1.   BAL0782             1.
    SH070183  COST            192.93   TRAN0701            1.
    SH070183  BAL0701            -1.   BAL0783             1.
    SH070283  COST             566.8   TRAN0702            1.
    SH070283  BAL0702            -1.   BAL0783             1.
    SH070383  COST            296.48   TRAN0703            1.
    SH070383  BAL0703            -1.   BAL0783             1.
    SH070483  COST             64.31   TRAN0704            1.
    SH070483  BAL0704            -1.   BAL0783             1.
    SH070583  COST            378.23   TRAN0705            1.
    SH070583  BAL0705            -1.   BAL0783             1.
    SH070683  COST            270.32   TRAN0706            1.
    SH070683  BAL0752            -1.   BAL0783             1.
    SH070284  COST            209.28   TRAN0702            1.
    SH070284  BAL0702            -1.   BAL0784             1.
    SH080201  COST            513.81   TRAN0802            1.
    SH080201  BAL0802            -1.   BAL0801             1.
    SH080301  COST            197.22   TRAN0803            1.
    SH080301  BAL0803            -1.   BAL0801             1.
    SH080401  COST            359.84   TRAN0804            1.
    SH080401  BAL0804            -1.   BAL0801             1.
    SH080501  COST            410.01   TRAN0805            1.
    SH080501  BAL0805            -1.   BAL0801             1.
    SH080601  COST            217.98   TRAN0806            1.
    SH080601  BAL0852            -1.   BAL0801             1.
    SH080801  COST            247.39   TRAN0808            1.
    SH080801  BAL0883            -1.   BAL0801             1.
    SH080102  COST            820.02   TRAN0801            1.
    SH080102  BAL0801            -1.   BAL0802             1.
    SH080302  COST            721.41   TRAN0803            1.
    SH080302  BAL0803            -1.   BAL0802             1.
    SH080402  COST           1058.76   TRAN0804            1.
    SH080402  BAL0804            -1.   BAL0802             1.
    SH080502  COST           1281.93   TRAN0805            1.
    SH080502  BAL0805            -1.   BAL0802             1.
    SH080602  COST            653.94   TRAN0806            1.
    SH080602  BAL0852            -1.   BAL0802             1.
    SH080802  COST            901.33   TRAN0808            1.
    SH080802  BAL0883            -1.   BAL0802             1.
    SH080103  COST            423.85   TRAN0801            1.
    SH080103  BAL0801            -1.   BAL0803             1.
    SH080203  COST            820.02   TRAN0802            1.
    SH080203  BAL0802            -1.   BAL0803             1.
    SH080403  COST            634.91   TRAN0804            1.
    SH080403  BAL0804            -1.   BAL0803             1.
    SH080503  COST            491.32   TRAN0805            1.
    SH080503  BAL0805            -1.   BAL0803             1.
    SH080603  COST             155.7   TRAN0806            1.
    SH080603  BAL0852            -1.   BAL0803             1.
    SH080803  COST            441.15   TRAN0808            1.
    SH080803  BAL0883            -1.   BAL0803             1.
    SH080104  COST            301.02   TRAN0801            1.
    SH080104  BAL0801            -1.   BAL0804             1.
    SH080204  COST            870.19   TRAN0802            1.
    SH080204  BAL0802            -1.   BAL0804             1.
    SH080304  COST            420.39   TRAN0803            1.
    SH080304  BAL0803            -1.   BAL0804             1.
    SH080504  COST            551.87   TRAN0805            1.
    SH080504  BAL0805            -1.   BAL0804             1.
    SH080604  COST            423.85   TRAN0806            1.
    SH080604  BAL0852            -1.   BAL0804             1.
    SH080804  COST            100.34   TRAN0808            1.
    SH080804  BAL0883            -1.   BAL0804             1.
    SH080105  COST             467.1   TRAN0801            1.
    SH080105  BAL0801            -1.   BAL0805             1.
    SH080205  COST            892.68   TRAN0802            1.
    SH080205  BAL0802            -1.   BAL0805             1.
    SH080305  COST            491.32   TRAN0803            1.
    SH080305  BAL0803            -1.   BAL0805             1.
    SH080405  COST            493.05   TRAN0804            1.
    SH080405  BAL0804            -1.   BAL0805             1.
    SH080605  COST            563.98   TRAN0806            1.
    SH080605  BAL0852            -1.   BAL0805             1.
    SH080705  COST            577.82   TRAN0807            1.
    SH080705  BAL0864            -1.   BAL0805             1.
    SH080805  COST            468.83   TRAN0808            1.
    SH080805  BAL0883            -1.   BAL0805             1.
    SH080106  COST            344.27   TRAN0801            1.
    SH080106  BAL0801            -1.   BAL0806             1.
    SH080107  COST             36.33   TRAN0801            1.
    SH080107  BAL0801            -1.   BAL0807             1.
    SH080207  COST            505.16   TRAN0802            1.
    SH080207  BAL0802            -1.   BAL0807             1.
    SH080307  COST            214.52   TRAN0803            1.
    SH080307  BAL0803            -1.   BAL0807             1.
    SH080407  COST            358.11   TRAN0804            1.
    SH080407  BAL0804            -1.   BAL0807             1.
    SH080507  COST            396.17   TRAN0805            1.
    SH080507  BAL0805            -1.   BAL0807             1.
    SH080607  COST            216.25   TRAN0806            1.
    SH080607  BAL0852            -1.   BAL0807             1.
    SH080707  COST            401.36   TRAN0807            1.
    SH080707  BAL0864            -1.   BAL0807             1.
    SH080807  COST            268.15   TRAN0808            1.
    SH080807  BAL0883            -1.   BAL0807             1.
    SH080108  COST            114.18   TRAN0801            1.
    SH080108  BAL0801            -1.   BAL0808             1.
    SH080208  COST            650.48   TRAN0802            1.
    SH080208  BAL0802            -1.   BAL0808             1.
    SH080308  COST            243.93   TRAN0803            1.
    SH080308  BAL0803            -1.   BAL0808             1.
    SH080408  COST            427.31   TRAN0804            1.
    SH080408  BAL0804            -1.   BAL0808             1.
    SH080508  COST            314.86   TRAN0805            1.
    SH080508  BAL0805            -1.   BAL0808             1.
    SH080608  COST            287.18   TRAN0806            1.
    SH080608  BAL0852            -1.   BAL0808             1.
    SH080808  COST            323.51   TRAN0808            1.
    SH080808  BAL0883            -1.   BAL0808             1.
    SH080109  COST            238.74   TRAN0801            1.
    SH080109  BAL0801            -1.   BAL0809             1.
    SH080110  COST            427.31   TRAN0801            1.
    SH080110  BAL0801            -1.   BAL0810             1.
    SH080210  COST            273.34   TRAN0802            1.
    SH080210  BAL0802            -1.   BAL0810             1.
    SH080310  COST             415.2   TRAN0803            1.
    SH080310  BAL0803            -1.   BAL0810             1.
    SH080410  COST            621.07   TRAN0804            1.
    SH080410  BAL0804            -1.   BAL0810             1.
    SH080510  COST            666.05   TRAN0805            1.
    SH080510  BAL0805            -1.   BAL0810             1.
    SH080610  COST            389.25   TRAN0806            1.
    SH080610  BAL0852            -1.   BAL0810             1.
    SH080810  COST            527.65   TRAN0808            1.
    SH080810  BAL0883            -1.   BAL0810             1.
    SH080111  COST            183.38   TRAN0801            1.
    SH080111  BAL0801            -1.   BAL0811             1.
    SH080112  COST            152.24   TRAN0801            1.
    SH080112  BAL0801            -1.   BAL0812             1.
    SH080114  COST            245.66   TRAN0801            1.
    SH080114  BAL0801            -1.   BAL0814             1.
    SH080614  COST            325.24   TRAN0806            1.
    SH080614  BAL0852            -1.   BAL0814             1.
    SH080115  COST            524.19   TRAN0801            1.
    SH080115  BAL0801            -1.   BAL0815             1.
    SH080215  COST            275.07   TRAN0802            1.
    SH080215  BAL0802            -1.   BAL0815             1.
    SH080315  COST            404.82   TRAN0803            1.
    SH080315  BAL0803            -1.   BAL0815             1.
    SH080415  COST            823.48   TRAN0804            1.
    SH080415  BAL0804            -1.   BAL0815             1.
    SH080515  COST            688.54   TRAN0805            1.
    SH080515  BAL0805            -1.   BAL0815             1.
    SH080615  COST            325.24   TRAN0806            1.
    SH080615  BAL0852            -1.   BAL0815             1.
    SH080815  COST            645.29   TRAN0808            1.
    SH080815  BAL0883            -1.   BAL0815             1.
    SH080116  COST            273.34   TRAN0801            1.
    SH080116  BAL0801            -1.   BAL0816             1.
    SH080216  COST             484.4   TRAN0802            1.
    SH080216  BAL0802            -1.   BAL0816             1.
    SH080316  COST            392.71   TRAN0803            1.
    SH080316  BAL0803            -1.   BAL0816             1.
    SH080416  COST            496.51   TRAN0804            1.
    SH080416  BAL0804            -1.   BAL0816             1.
    SH080516  COST            551.87   TRAN0805            1.
    SH080516  BAL0805            -1.   BAL0816             1.
    SH080616  COST            226.63   TRAN0806            1.
    SH080616  BAL0852            -1.   BAL0816             1.
    SH080816  COST            354.65   TRAN0808            1.
    SH080816  BAL0883            -1.   BAL0816             1.
    SH080117  COST            261.23   TRAN0801            1.
    SH080117  BAL0801            -1.   BAL0817             1.
    SH080817  COST             46.71   TRAN0808            1.
    SH080817  BAL0883            -1.   BAL0817             1.
    SH080418  COST            266.42   TRAN0804            1.
    SH080418  BAL0804            -1.   BAL0818             1.
    SH080119  COST            429.04   TRAN0801            1.
    SH080119  BAL0801            -1.   BAL0819             1.
    SH080219  COST           1188.51   TRAN0802            1.
    SH080219  BAL0802            -1.   BAL0819             1.
    SH080319  COST            548.41   TRAN0803            1.
    SH080319  BAL0803            -1.   BAL0819             1.
    SH080419  COST            275.07   TRAN0804            1.
    SH080419  BAL0804            -1.   BAL0819             1.
    SH080519  COST            359.84   TRAN0805            1.
    SH080519  BAL0805            -1.   BAL0819             1.
    SH080619  COST            596.85   TRAN0806            1.
    SH080619  BAL0852            -1.   BAL0819             1.
    SH080819  COST            171.27   TRAN0808            1.
    SH080819  BAL0883            -1.   BAL0819             1.
    SH080120  COST            354.65   TRAN0801            1.
    SH080120  BAL0801            -1.   BAL0820             1.
    SH080220  COST           1181.59   TRAN0802            1.
    SH080220  BAL0802            -1.   BAL0820             1.
    SH080320  COST            513.81   TRAN0803            1.
    SH080320  BAL0803            -1.   BAL0820             1.
    SH080420  COST            195.49   TRAN0804            1.
    SH080420  BAL0804            -1.   BAL0820             1.
    SH080520  COST            503.43   TRAN0805            1.
    SH080520  BAL0805            -1.   BAL0820             1.
    SH080820  COST            217.98   TRAN0808            1.
    SH080820  BAL0883            -1.   BAL0820             1.
    SH080121  COST            697.19   TRAN0801            1.
    SH080121  BAL0801            -1.   BAL0821             1.
    SH080221  COST            636.64   TRAN0802            1.
    SH080221  BAL0802            -1.   BAL0821             1.
    SH080321  COST            771.58   TRAN0803            1.
    SH080321  BAL0803            -1.   BAL0821             1.
    SH080421  COST             553.6   TRAN0804            1.
    SH080421  BAL0804            -1.   BAL0821             1.
    SH080521  COST             951.5   TRAN0805            1.
    SH080521  BAL0805            -1.   BAL0821             1.
    SH080821  COST             553.6   TRAN0808            1.
    SH080821  BAL0883            -1.   BAL0821             1.
    SH080422  COST            387.52   TRAN0804            1.
    SH080422  BAL0804            -1.   BAL0822             1.
    SH080423  COST            288.91   TRAN0804            1.
    SH080423  BAL0804            -1.   BAL0823             1.
    SH080124  COST           2484.28   TRAN0801            1.
    SH080124  BAL0801            -1.   BAL0824             1.
    SH080225  COST            738.71   TRAN0802            1.
    SH080225  BAL0802            -1.   BAL0825             1.
    SH080426  COST             467.1   TRAN0804            1.
    SH080426  BAL0804            -1.   BAL0826             1.
    SH080627  COST            463.64   TRAN0806            1.
    SH080627  BAL0852            -1.   BAL0827             1.
    SH080128  COST            420.39   TRAN0801            1.
    SH080128  BAL0801            -1.   BAL0828             1.
    SH080528  COST            176.46   TRAN0805            1.
    SH080528  BAL0805            -1.   BAL0828             1.
    SH080429  COST            344.27   TRAN0804            1.
    SH080429  BAL0804            -1.   BAL0829             1.
    SH080430  COST            525.92   TRAN0804            1.
    SH080430  BAL0804            -1.   BAL0830             1.
    SH080131  COST            192.03   TRAN0801            1.
    SH080131  BAL0801            -1.   BAL0831             1.
    SH080432  COST            271.61   TRAN0804            1.
    SH080432  BAL0804            -1.   BAL0832             1.
    SH080133  COST            852.89   TRAN0801            1.
    SH080133  BAL0801            -1.   BAL0833             1.
    SH080233  COST              692.   TRAN0802            1.
    SH080233  BAL0802            -1.   BAL0833             1.
    SH080333  COST            939.39   TRAN0803            1.
    SH080333  BAL0803            -1.   BAL0833             1.
    SH080433  COST            769.85   TRAN0804            1.
    SH080433  BAL0804            -1.   BAL0833             1.
    SH080533  COST           1091.63   TRAN0805            1.
    SH080533  BAL0805            -1.   BAL0833             1.
    SH080833  COST            659.13   TRAN0808            1.
    SH080833  BAL0883            -1.   BAL0833             1.
    SH080134  COST            667.78   TRAN0801            1.
    SH080134  BAL0801            -1.   BAL0834             1.
    SH080234  COST           1133.15   TRAN0802            1.
    SH080234  BAL0802            -1.   BAL0834             1.
    SH080334  COST            870.19   TRAN0803            1.
    SH080334  BAL0803            -1.   BAL0834             1.
    SH080434  COST            365.03   TRAN0804            1.
    SH080434  BAL0804            -1.   BAL0834             1.
    SH080534  COST            762.93   TRAN0805            1.
    SH080534  BAL0805            -1.   BAL0834             1.
    SH080834  COST            454.99   TRAN0808            1.
    SH080834  BAL0883            -1.   BAL0834             1.
    SH080435  COST            211.06   TRAN0804            1.
    SH080435  BAL0804            -1.   BAL0835             1.
    SH080636  COST             190.3   TRAN0806            1.
    SH080636  BAL0852            -1.   BAL0836             1.
    SH080137  COST            159.16   TRAN0801            1.
    SH080137  BAL0801            -1.   BAL0837             1.
    SH080237  COST            591.66   TRAN0802            1.
    SH080237  BAL0802            -1.   BAL0837             1.
    SH080337  COST            273.34   TRAN0803            1.
    SH080337  BAL0803            -1.   BAL0837             1.
    SH080437  COST            525.92   TRAN0804            1.
    SH080437  BAL0804            -1.   BAL0837             1.
    SH080537  COST            314.86   TRAN0805            1.
    SH080537  BAL0805            -1.   BAL0837             1.
    SH080637  COST            335.62   TRAN0806            1.
    SH080637  BAL0852            -1.   BAL0837             1.
    SH080837  COST            435.96   TRAN0808            1.
    SH080837  BAL0883            -1.   BAL0837             1.
    SH080138  COST            235.28   TRAN0801            1.
    SH080138  BAL0801            -1.   BAL0838             1.
    SH080238  COST            422.12   TRAN0802            1.
    SH080238  BAL0802            -1.   BAL0838             1.
    SH080338  COST            164.35   TRAN0803            1.
    SH080338  BAL0803            -1.   BAL0838             1.
    SH080438  COST            532.84   TRAN0804            1.
    SH080438  BAL0804            -1.   BAL0838             1.
    SH080538  COST            480.94   TRAN0805            1.
    SH080538  BAL0805            -1.   BAL0838             1.
    SH080638  COST             67.47   TRAN0806            1.
    SH080638  BAL0852            -1.   BAL0838             1.
    SH080738  COST            373.68   TRAN0807            1.
    SH080738  BAL0864            -1.   BAL0838             1.
    SH080838  COST            410.01   TRAN0808            1.
    SH080838  BAL0883            -1.   BAL0838             1.
    SH080139  COST             224.9   TRAN0801            1.
    SH080139  BAL0801            -1.   BAL0839             1.
    SH080140  COST            285.45   TRAN0801            1.
    SH080140  BAL0801            -1.   BAL0840             1.
    SH080240  COST            653.94   TRAN0802            1.
    SH080240  BAL0802            -1.   BAL0840             1.
    SH080340  COST            178.19   TRAN0803            1.
    SH080340  BAL0803            -1.   BAL0840             1.
    SH080440  COST            513.81   TRAN0804            1.
    SH080440  BAL0804            -1.   BAL0840             1.
    SH080540  COST            382.33   TRAN0805            1.
    SH080540  BAL0805            -1.   BAL0840             1.
    SH080640  COST            226.63   TRAN0806            1.
    SH080640  BAL0852            -1.   BAL0840             1.
    SH080840  COST            474.02   TRAN0808            1.
    SH080840  BAL0883            -1.   BAL0840             1.
    SH080641  COST              173.   TRAN0806            1.
    SH080641  BAL0852            -1.   BAL0841             1.
    SH080142  COST             155.7   TRAN0801            1.
    SH080142  BAL0801            -1.   BAL0842             1.
    SH080143  COST            275.07   TRAN0801            1.
    SH080143  BAL0801            -1.   BAL0843             1.
    SH080243  COST            683.35   TRAN0802            1.
    SH080243  BAL0802            -1.   BAL0843             1.
    SH080343  COST             43.25   TRAN0803            1.
    SH080343  BAL0803            -1.   BAL0843             1.
    SH080443  COST            512.08   TRAN0804            1.
    SH080443  BAL0804            -1.   BAL0843             1.
    SH080543  COST            446.34   TRAN0805            1.
    SH080543  BAL0805            -1.   BAL0843             1.
    SH080643  COST              173.   TRAN0806            1.
    SH080643  BAL0852            -1.   BAL0843             1.
    SH080743  COST            416.93   TRAN0807            1.
    SH080743  BAL0864            -1.   BAL0843             1.
    SH080843  COST            468.83   TRAN0808            1.
    SH080843  BAL0883            -1.   BAL0843             1.
    SH080644  COST            153.97   TRAN0806            1.
    SH080644  BAL0852            -1.   BAL0844             1.
    SH080145  COST            297.56   TRAN0801            1.
    SH080145  BAL0801            -1.   BAL0845             1.
    SH080245  COST            754.28   TRAN0802            1.
    SH080245  BAL0802            -1.   BAL0845             1.
    SH080345  COST            278.53   TRAN0803            1.
    SH080345  BAL0803            -1.   BAL0845             1.
    SH080445  COST            505.16   TRAN0804            1.
    SH080445  BAL0804            -1.   BAL0845             1.
    SH080545  COST            404.82   TRAN0805            1.
    SH080545  BAL0805            -1.   BAL0845             1.
    SH080645  COST            330.43   TRAN0806            1.
    SH080645  BAL0852            -1.   BAL0845             1.
    SH080745  COST            340.81   TRAN0807            1.
    SH080745  BAL0864            -1.   BAL0845             1.
    SH080845  COST            527.65   TRAN0808            1.
    SH080845  BAL0883            -1.   BAL0845             1.
    SH080146  COST            423.85   TRAN0801            1.
    SH080146  BAL0801            -1.   BAL0846             1.
    SH080246  COST            472.29   TRAN0802            1.
    SH080246  BAL0802            -1.   BAL0846             1.
    SH080346  COST            382.33   TRAN0803            1.
    SH080346  BAL0803            -1.   BAL0846             1.
    SH080446  COST            773.31   TRAN0804            1.
    SH080446  BAL0804            -1.   BAL0846             1.
    SH080546  COST             743.9   TRAN0805            1.
    SH080546  BAL0805            -1.   BAL0846             1.
    SH080646  COST            444.61   TRAN0806            1.
    SH080646  BAL0852            -1.   BAL0846             1.
    SH080846  COST            775.04   TRAN0808            1.
    SH080846  BAL0883            -1.   BAL0846             1.
    SH080147  COST             190.3   TRAN0801            1.
    SH080147  BAL0801            -1.   BAL0847             1.
    SH080148  COST            164.35   TRAN0801            1.
    SH080148  BAL0801            -1.   BAL0848             1.
    SH080149  COST            569.17   TRAN0801            1.
    SH080149  BAL0801            -1.   BAL0849             1.
    SH080549  COST            262.96   TRAN0805            1.
    SH080549  BAL0805            -1.   BAL0849             1.
    SH080150  COST            416.93   TRAN0801            1.
    SH080150  BAL0801            -1.   BAL0850             1.
    SH080151  COST            574.36   TRAN0801            1.
    SH080151  BAL0801            -1.   BAL0851             1.
    SH080551  COST            212.79   TRAN0805            1.
    SH080551  BAL0805            -1.   BAL0851             1.
    SH080152  COST            193.76   TRAN0801            1.
    SH080152  BAL0801            -1.   BAL0852             1.
    SH080252  COST              519.   TRAN0802            1.
    SH080252  BAL0802            -1.   BAL0852             1.
    SH080352  COST            141.86   TRAN0803            1.
    SH080352  BAL0803            -1.   BAL0852             1.
    SH080452  COST            557.06   TRAN0804            1.
    SH080452  BAL0804            -1.   BAL0852             1.
    SH080552  COST            510.35   TRAN0805            1.
    SH080552  BAL0805            -1.   BAL0852             1.
    SH080852  COST            437.69   TRAN0808            1.
    SH080852  BAL0883            -1.   BAL0852             1.
    SH080153  COST            621.07   TRAN0801            1.
    SH080153  BAL0801            -1.   BAL0853             1.
    SH080253  COST           1100.28   TRAN0802            1.
    SH080253  BAL0802            -1.   BAL0853             1.
    SH080353  COST            562.25   TRAN0803            1.
    SH080353  BAL0803            -1.   BAL0853             1.
    SH080453  COST            712.76   TRAN0804            1.
    SH080453  BAL0804            -1.   BAL0853             1.
    SH080553  COST            318.32   TRAN0805            1.
    SH080553  BAL0805            -1.   BAL0853             1.
    SH080653  COST            621.07   TRAN0806            1.
    SH080653  BAL0852            -1.   BAL0853             1.
    SH080753  COST            252.58   TRAN0807            1.
    SH080753  BAL0864            -1.   BAL0853             1.
    SH080853  COST            697.19   TRAN0808            1.
    SH080853  BAL0883            -1.   BAL0853             1.
    SH080154  COST            320.05   TRAN0801            1.
    SH080154  BAL0801            -1.   BAL0854             1.
    SH080155  COST            480.94   TRAN0801            1.
    SH080155  BAL0801            -1.   BAL0855             1.
    SH080255  COST            828.67   TRAN0802            1.
    SH080255  BAL0802            -1.   BAL0855             1.
    SH080355  COST            486.13   TRAN0803            1.
    SH080355  BAL0803            -1.   BAL0855             1.
    SH080455  COST            508.62   TRAN0804            1.
    SH080455  BAL0804            -1.   BAL0855             1.
    SH080555  COST            266.42   TRAN0805            1.
    SH080555  BAL0805            -1.   BAL0855             1.
    SH080655  COST             501.7   TRAN0806            1.
    SH080655  BAL0852            -1.   BAL0855             1.
    SH080755  COST            185.11   TRAN0807            1.
    SH080755  BAL0864            -1.   BAL0855             1.
    SH080855  COST            508.62   TRAN0808            1.
    SH080855  BAL0883            -1.   BAL0855             1.
    SH080156  COST             674.7   TRAN0801            1.
    SH080156  BAL0801            -1.   BAL0856             1.
    SH080556  COST            235.28   TRAN0805            1.
    SH080556  BAL0805            -1.   BAL0856             1.
    SH080157  COST            451.53   TRAN0801            1.
    SH080157  BAL0801            -1.   BAL0857             1.
    SH080557  COST            290.64   TRAN0805            1.
    SH080557  BAL0805            -1.   BAL0857             1.
    SH080158  COST            508.62   TRAN0801            1.
    SH080158  BAL0801            -1.   BAL0858             1.
    SH080258  COST            901.33   TRAN0802            1.
    SH080258  BAL0802            -1.   BAL0858             1.
    SH080358  COST            480.94   TRAN0803            1.
    SH080358  BAL0803            -1.   BAL0858             1.
    SH080458  COST            593.39   TRAN0804            1.
    SH080458  BAL0804            -1.   BAL0858             1.
    SH080558  COST             36.33   TRAN0805            1.
    SH080558  BAL0805            -1.   BAL0858             1.
    SH080658  COST            563.98   TRAN0806            1.
    SH080658  BAL0852            -1.   BAL0858             1.
    SH080758  COST            117.64   TRAN0807            1.
    SH080758  BAL0864            -1.   BAL0858             1.
    SH080858  COST            439.42   TRAN0808            1.
    SH080858  BAL0883            -1.   BAL0858             1.
    SH080159  COST            356.38   TRAN0801            1.
    SH080159  BAL0801            -1.   BAL0859             1.
    SH080259  COST            861.54   TRAN0802            1.
    SH080259  BAL0802            -1.   BAL0859             1.
    SH080359  COST            411.74   TRAN0803            1.
    SH080359  BAL0803            -1.   BAL0859             1.
    SH080459  COST            422.12   TRAN0804            1.
    SH080459  BAL0804            -1.   BAL0859             1.
    SH080559  COST            275.07   TRAN0805            1.
    SH080559  BAL0805            -1.   BAL0859             1.
    SH080659  COST            513.81   TRAN0806            1.
    SH080659  BAL0852            -1.   BAL0859             1.
    SH080759  COST            181.65   TRAN0807            1.
    SH080759  BAL0864            -1.   BAL0859             1.
    SH080859  COST            441.15   TRAN0808            1.
    SH080859  BAL0883            -1.   BAL0859             1.
    SH080160  COST            451.53   TRAN0801            1.
    SH080160  BAL0801            -1.   BAL0860             1.
    SH080260  COST             951.5   TRAN0802            1.
    SH080260  BAL0802            -1.   BAL0860             1.
    SH080360  COST            489.59   TRAN0803            1.
    SH080360  BAL0803            -1.   BAL0860             1.
    SH080460  COST            539.76   TRAN0804            1.
    SH080460  BAL0804            -1.   BAL0860             1.
    SH080560  COST            233.55   TRAN0805            1.
    SH080560  BAL0805            -1.   BAL0860             1.
    SH080660  COST            558.79   TRAN0806            1.
    SH080660  BAL0852            -1.   BAL0860             1.
    SH080760  COST            152.24   TRAN0807            1.
    SH080760  BAL0864            -1.   BAL0860             1.
    SH080860  COST            517.27   TRAN0808            1.
    SH080860  BAL0883            -1.   BAL0860             1.
    SH080163  COST            460.18   TRAN0801            1.
    SH080163  BAL0801            -1.   BAL0863             1.
    SH080563  COST            262.96   TRAN0805            1.
    SH080563  BAL0805            -1.   BAL0863             1.
    SH080164  COST            344.27   TRAN0801            1.
    SH080164  BAL0801            -1.   BAL0864             1.
    SH080264  COST            909.98   TRAN0802            1.
    SH080264  BAL0802            -1.   BAL0864             1.
    SH080364  COST            385.79   TRAN0803            1.
    SH080364  BAL0803            -1.   BAL0864             1.
    SH080464  COST            581.28   TRAN0804            1.
    SH080464  BAL0804            -1.   BAL0864             1.
    SH080564  COST            100.34   TRAN0805            1.
    SH080564  BAL0805            -1.   BAL0864             1.
    SH080664  COST            548.41   TRAN0806            1.
    SH080664  BAL0852            -1.   BAL0864             1.
    SH080864  COST             432.5   TRAN0808            1.
    SH080864  BAL0883            -1.   BAL0864             1.
    SH080265  COST            531.11   TRAN0802            1.
    SH080265  BAL0802            -1.   BAL0865             1.
    SH080266  COST            448.07   TRAN0802            1.
    SH080266  BAL0802            -1.   BAL0866             1.
    SH080267  COST            401.36   TRAN0802            1.
    SH080267  BAL0802            -1.   BAL0867             1.
    SH080268  COST              692.   TRAN0802            1.
    SH080268  BAL0802            -1.   BAL0868             1.
    SH080269  COST            382.33   TRAN0802            1.
    SH080269  BAL0802            -1.   BAL0869             1.
    SH080171  COST             761.2   TRAN0801            1.
    SH080171  BAL0801            -1.   BAL0871             1.
    SH080371  COST            906.52   TRAN0803            1.
    SH080371  BAL0803            -1.   BAL0871             1.
    SH080471  COST            901.33   TRAN0804            1.
    SH080471  BAL0804            -1.   BAL0871             1.
    SH080571  COST           1005.13   TRAN0805            1.
    SH080571  BAL0805            -1.   BAL0871             1.
    SH080671  COST            676.43   TRAN0806            1.
    SH080671  BAL0852            -1.   BAL0871             1.
    SH080771  COST           1217.92   TRAN0807            1.
    SH080771  BAL0864            -1.   BAL0871             1.
    SH080871  COST            922.09   TRAN0808            1.
    SH080871  BAL0883            -1.   BAL0871             1.
    SH080272  COST            939.39   TRAN0802            1.
    SH080272  BAL0802            -1.   BAL0872             1.
    SH080173  COST             674.7   TRAN0801            1.
    SH080173  BAL0801            -1.   BAL0873             1.
    SH080273  COST            631.45   TRAN0802            1.
    SH080273  BAL0802            -1.   BAL0873             1.
    SH080373  COST            584.74   TRAN0803            1.
    SH080373  BAL0803            -1.   BAL0873             1.
    SH080473  COST            790.61   TRAN0804            1.
    SH080473  BAL0804            -1.   BAL0873             1.
    SH080573  COST            975.72   TRAN0805            1.
    SH080573  BAL0805            -1.   BAL0873             1.
    SH080673  COST            527.65   TRAN0806            1.
    SH080673  BAL0852            -1.   BAL0873             1.
    SH080873  COST            871.92   TRAN0808            1.
    SH080873  BAL0883            -1.   BAL0873             1.
    SH080274  COST             363.3   TRAN0802            1.
    SH080274  BAL0802            -1.   BAL0874             1.
    SH080275  COST            958.42   TRAN0802            1.
    SH080275  BAL0802            -1.   BAL0875             1.
    SH080276  COST            693.73   TRAN0802            1.
    SH080276  BAL0802            -1.   BAL0876             1.
    SH080177  COST            752.55   TRAN0801            1.
    SH080177  BAL0801            -1.   BAL0877             1.
    SH080277  COST            470.56   TRAN0802            1.
    SH080277  BAL0802            -1.   BAL0877             1.
    SH080377  COST            797.53   TRAN0803            1.
    SH080377  BAL0803            -1.   BAL0877             1.
    SH080477  COST            693.73   TRAN0804            1.
    SH080477  BAL0804            -1.   BAL0877             1.
    SH080577  COST             968.8   TRAN0805            1.
    SH080577  BAL0805            -1.   BAL0877             1.
    SH080877  COST             553.6   TRAN0808            1.
    SH080877  BAL0883            -1.   BAL0877             1.
    SH080178  COST           1316.53   TRAN0801            1.
    SH080178  BAL0801            -1.   BAL0878             1.
    SH080278  COST            764.66   TRAN0802            1.
    SH080278  BAL0802            -1.   BAL0878             1.
    SH080378  COST           1354.59   TRAN0803            1.
    SH080378  BAL0803            -1.   BAL0878             1.
    SH080478  COST           1185.05   TRAN0804            1.
    SH080478  BAL0804            -1.   BAL0878             1.
    SH080578  COST           1520.67   TRAN0805            1.
    SH080578  BAL0805            -1.   BAL0878             1.
    SH080878  COST           1325.18   TRAN0808            1.
    SH080878  BAL0883            -1.   BAL0878             1.
    SH080279  COST            465.37   TRAN0802            1.
    SH080279  BAL0802            -1.   BAL0879             1.
    SH080480  COST            647.02   TRAN0804            1.
    SH080480  BAL0804            -1.   BAL0880             1.
    SH080182  COST           1006.86   TRAN0801            1.
    SH080182  BAL0801            -1.   BAL0882             1.
    SH080282  COST            569.17   TRAN0802            1.
    SH080282  BAL0802            -1.   BAL0882             1.
    SH080382  COST           1133.15   TRAN0803            1.
    SH080382  BAL0803            -1.   BAL0882             1.
    SH080482  COST           1221.38   TRAN0804            1.
    SH080482  BAL0804            -1.   BAL0882             1.
    SH080582  COST           1984.31   TRAN0805            1.
    SH080582  BAL0805            -1.   BAL0882             1.
    SH080882  COST           1354.59   TRAN0808            1.
    SH080882  BAL0883            -1.   BAL0882             1.
    SH080183  COST            306.21   TRAN0801            1.
    SH080183  BAL0801            -1.   BAL0883             1.
    SH080283  COST             899.6   TRAN0802            1.
    SH080283  BAL0802            -1.   BAL0883             1.
    SH080383  COST            470.56   TRAN0803            1.
    SH080383  BAL0803            -1.   BAL0883             1.
    SH080483  COST            102.07   TRAN0804            1.
    SH080483  BAL0804            -1.   BAL0883             1.
    SH080583  COST            600.31   TRAN0805            1.
    SH080583  BAL0805            -1.   BAL0883             1.
    SH080683  COST            429.04   TRAN0806            1.
    SH080683  BAL0852            -1.   BAL0883             1.
    SH080284  COST            332.16   TRAN0802            1.
    SH080284  BAL0802            -1.   BAL0884             1.
    TRSH0101  COST               78.   TRAN0101           -1.
    TRSH0102  COST               78.   TRAN0201           -1.
    TRSH0103  COST               78.   TRAN0301           -1.
    TRSH0104  COST             101.5   TRAN0401           -1.
    TRSH0105  COST               78.   TRAN0501           -1.
    TRSH0106  COST               78.   TRAN0601           -1.
    TRSH0107  COST               78.   TRAN0701           -1.
    TRSH0108  COST             101.5   TRAN0801           -1.
    TRSH0201  COST               78.   TRAN0102           -1.
    TRSH0202  COST               78.   TRAN0202           -1.
    TRSH0203  COST               78.   TRAN0302           -1.
    TRSH0204  COST             101.5   TRAN0402           -1.
    TRSH0205  COST               78.   TRAN0502           -1.
    TRSH0206  COST               78.   TRAN0602           -1.
    TRSH0207  COST               78.   TRAN0702           -1.
    TRSH0208  COST             101.5   TRAN0802           -1.
    TRSH0301  COST               78.   TRAN0103           -1.
    TRSH0302  COST               78.   TRAN0203           -1.
    TRSH0303  COST               78.   TRAN0303           -1.
    TRSH0304  COST             101.5   TRAN0403           -1.
    TRSH0305  COST               78.   TRAN0503           -1.
    TRSH0306  COST               78.   TRAN0603           -1.
    TRSH0307  COST               78.   TRAN0703           -1.
    TRSH0308  COST             101.5   TRAN0803           -1.
    TRSH0401  COST               78.   TRAN0104           -1.
    TRSH0402  COST               78.   TRAN0204           -1.
    TRSH0403  COST               78.   TRAN0304           -1.
    TRSH0404  COST             101.5   TRAN0404           -1.
    TRSH0405  COST               78.   TRAN0504           -1.
    TRSH0406  COST               78.   TRAN0604           -1.
    TRSH0407  COST               78.   TRAN0704           -1.
    TRSH0408  COST             101.5   TRAN0804           -1.
    TRSH0501  COST               78.   TRAN0105           -1.
    TRSH0502  COST               78.   TRAN0205           -1.
    TRSH0503  COST               78.   TRAN0305           -1.
    TRSH0504  COST             101.5   TRAN0405           -1.
    TRSH0505  COST               78.   TRAN0505           -1.
    TRSH0506  COST               78.   TRAN0605           -1.
    TRSH0507  COST               78.   TRAN0705           -1.
    TRSH0508  COST             101.5   TRAN0805           -1.
    TRSH0601  COST               78.   TRAN0106           -1.
    TRSH0602  COST               78.   TRAN0206           -1.
    TRSH0603  COST               78.   TRAN0306           -1.
    TRSH0604  COST             101.5   TRAN0406           -1.
    TRSH0605  COST               78.   TRAN0506           -1.
    TRSH0606  COST               78.   TRAN0606           -1.
    TRSH0607  COST               78.   TRAN0706           -1.
    TRSH0608  COST             101.5   TRAN0806           -1.
    TRSH0701  COST               78.   TRAN0107           -1.
    TRSH0702  COST               78.   TRAN0207           -1.
    TRSH0703  COST               78.   TRAN0307           -1.
    TRSH0704  COST             101.5   TRAN0407           -1.
    TRSH0705  COST               78.   TRAN0507           -1.
    TRSH0706  COST               78.   TRAN0607           -1.
    TRSH0707  COST               78.   TRAN0707           -1.
    TRSH0708  COST             101.5   TRAN0807           -1.
    TRSH0801  COST               78.   TRAN0108           -1.
    TRSH0802  COST               78.   TRAN0208           -1.
    TRSH0803  COST               78.   TRAN0308           -1.
    TRSH0804  COST             101.5   TRAN0408           -1.
    TRSH0805  COST               78.   TRAN0508           -1.
    TRSH0806  COST               78.   TRAN0608           -1.
    TRSH0807  COST               78.   TRAN0708           -1.
    TRSH0808  COST             101.5   TRAN0808           -1.
RHS
    RHS       REGMAX              7.   OVRMAX            126.
    RHS       REGMAX01            3.   REGMAX02            3.
    RHS       REGMAX04            3.   OVRMAX01           48.
    RHS       OVRMAX02           48.   OVRMAX04           30.
    RHS       BAL0102        .105342   BAL0104        .316026
    RHS       BAL0106        .263355   BAL0107        1.15876
    RHS       BAL0108        .948077   BAL0109        .421368
    RHS       BAL0110         .57938   BAL0111        .632051
    RHS       BAL0112        .526709   BAL0114        .421368
    RHS       BAL0115        1.21143   BAL0116        .948077
    RHS       BAL0117        1.05342   BAL0118        .421368
    RHS       BAL0119        .684722   BAL0120        1.15876
    RHS       BAL0121        1.10609   BAL0122        .684722
    RHS       BAL0123         .57938   BAL0124       .0526709
    RHS       BAL0125        .684722   BAL0126        .210684
    RHS       BAL0127        .316026   BAL0128        .895406
    RHS       BAL0129        .474038   BAL0130        .842735
    RHS       BAL0131         .57938   BAL0132        1.00075
    RHS       BAL0133        1.15876   BAL0134        1.05342
    RHS       BAL0135        .632051   BAL0136        .368697
    RHS       BAL0137        1.94882   BAL0138        1.79081
    RHS       BAL0139        .368697   BAL0140        1.10609
    RHS       BAL0141        .737393   BAL0142        .263355
    RHS       BAL0143        1.52746   BAL0144        .895406
    RHS       BAL0145        1.36944   BAL0146        .895406
    RHS       BAL0147        .632051   BAL0148        .526709
    RHS       BAL0149        .368697   BAL0150        .526709
    RHS       BAL0151        .421368   BAL0153        1.00075
    RHS       BAL0154        .421368   BAL0155        1.10609
    RHS       BAL0156        .790064   BAL0157        .684722
    RHS       BAL0158         2.0015   BAL0159        1.21143
    RHS       BAL0160        1.21143   BAL0163        .526709
    RHS       BAL0165        .210684   BAL0166        .263355
    RHS       BAL0167        .210684   BAL0168        .105342
    RHS       BAL0169        .158013   BAL0171        .948077
    RHS       BAL0172        .210684   BAL0173        .158013
    RHS       BAL0174        .105342   BAL0175        .210684
    RHS       BAL0176       .0526709   BAL0177        1.00075
    RHS       BAL0178        .842735   BAL0179        .105342
    RHS       BAL0180        .263355   BAL0182        .316026
    RHS       BAL0184        .316026   BAL0201        .130917
    RHS       BAL0202        .261834   BAL0204        .785501
    RHS       BAL0206        1.17825   BAL0207        3.79659
    RHS       BAL0208        2.74925   BAL0209          1.571
    RHS       BAL0210        2.09467   BAL0211        1.96375
    RHS       BAL0212        1.83284   BAL0214        1.70192
    RHS       BAL0215        6.15309   BAL0216        2.09467
    RHS       BAL0217        2.09467   BAL0218          1.571
    RHS       BAL0219        3.01109   BAL0220        3.01109
    RHS       BAL0221          3.142   BAL0222        2.22559
    RHS       BAL0223        2.22559   BAL0224        .130917
    RHS       BAL0225        1.30917   BAL0226        .523667
    RHS       BAL0227        1.17825   BAL0228          1.571
    RHS       BAL0229        1.30917   BAL0230          1.571
    RHS       BAL0231          1.571   BAL0232        1.96375
    RHS       BAL0233        2.74925   BAL0234        2.09467
    RHS       BAL0235        1.30917   BAL0236        .654584
    RHS       BAL0237        3.66567   BAL0238          3.142
    RHS       BAL0239          1.571   BAL0240        1.70192
    RHS       BAL0241        1.17825   BAL0242        1.30917
    RHS       BAL0243        4.18934   BAL0244        1.17825
    RHS       BAL0245        2.22559   BAL0246        2.09467
    RHS       BAL0247        1.44009   BAL0248        1.04733
    RHS       BAL0249        .654584   BAL0250        .785501
    RHS       BAL0251        .523667   BAL0253        2.22559
    RHS       BAL0254        .654584   BAL0255        1.83284
    RHS       BAL0256          1.571   BAL0257        1.30917
    RHS       BAL0258        3.27292   BAL0259         2.3565
    RHS       BAL0260        1.83284   BAL0263        .785501
    RHS       BAL0265        .916418   BAL0266        .916418
    RHS       BAL0267        .785501   BAL0268        .261834
    RHS       BAL0269        .654584   BAL0271        3.27292
    RHS       BAL0272        .392751   BAL0273        1.04733
    RHS       BAL0274        .523667   BAL0275        .523667
    RHS       BAL0276        .392751   BAL0277        3.53475
    RHS       BAL0278        2.09467   BAL0279        .392751
    RHS       BAL0280        .654584   BAL0282        1.04733
    RHS       BAL0284        1.30917   BAL0302        .067364
    RHS       BAL0307        .471548   BAL0308        .404184
    RHS       BAL0309        .134728   BAL0310        1.48201
    RHS       BAL0311        .067364   BAL0312        .067364
    RHS       BAL0315        7.94895   BAL0316        .202092
    RHS       BAL0321        .134728   BAL0327        .875732
    RHS       BAL0329        .134728   BAL0331        .269456
    RHS       BAL0333        .269456   BAL0336        .875732
    RHS       BAL0337        .875732   BAL0338        .134728
    RHS       BAL0339        .134728   BAL0340         .33682
    RHS       BAL0341        .538912   BAL0342        .067364
    RHS       BAL0343        3.70502   BAL0344        1.54937
    RHS       BAL0345        .404184   BAL0346        3.03138
    RHS       BAL0347        .404184   BAL0348        .067364
    RHS       BAL0354        .067364   BAL0355        .134728
    RHS       BAL0358        .067364   BAL0365        .134728
    RHS       BAL0366        1.34728   BAL0367        .404184
    RHS       BAL0368        1.75146   BAL0369        1.88619
    RHS       BAL0371        5.72594   BAL0372         .67364
    RHS       BAL0373        3.70502   BAL0374        1.95356
    RHS       BAL0375        .269456   BAL0376        1.61674
    RHS       BAL0377        1.41464   BAL0378        2.22301
    RHS       BAL0379        3.16611   BAL0382        11.8561
    RHS       BAL0384        1.34728   BAL0502        .135821
    RHS       BAL0504        .543284   BAL0506        .543284
    RHS       BAL0507         2.5806   BAL0508        2.03731
    RHS       BAL0509        .814925   BAL0510        2.85224
    RHS       BAL0511        1.08657   BAL0512        1.22239
    RHS       BAL0514        1.35821   BAL0515        5.70448
    RHS       BAL0516        3.12388   BAL0517        1.49403
    RHS       BAL0518        1.35821   BAL0519        1.22239
    RHS       BAL0520        1.35821   BAL0521        6.24776
    RHS       BAL0522        .950746   BAL0523        1.08657
    RHS       BAL0525        2.71642   BAL0526        .407463
    RHS       BAL0527        1.90149   BAL0528        2.17313
    RHS       BAL0529        1.76567   BAL0530        1.22239
    RHS       BAL0531        1.49403   BAL0532        1.62985
    RHS       BAL0533        3.39552   BAL0534        2.03731
    RHS       BAL0535        .814925   BAL0536        .407463
    RHS       BAL0537        3.39552   BAL0538         2.5806
    RHS       BAL0539        1.08657   BAL0540        2.98806
    RHS       BAL0541        1.49403   BAL0542        .679104
    RHS       BAL0543        4.07463   BAL0544        .814925
    RHS       BAL0545         3.2597   BAL0546        4.34627
    RHS       BAL0547        2.03731   BAL0548        1.90149
    RHS       BAL0549        .543284   BAL0550        1.90149
    RHS       BAL0551        .407463   BAL0552        .135821
    RHS       BAL0553        1.22239   BAL0554        .950746
    RHS       BAL0555         3.2597   BAL0556        .950746
    RHS       BAL0557        1.49403   BAL0558        3.66716
    RHS       BAL0559         2.5806   BAL0560        2.17313
    RHS       BAL0563        1.62985   BAL0565        1.35821
    RHS       BAL0566        .679104   BAL0567        1.35821
    RHS       BAL0568        .407463   BAL0569        .679104
    RHS       BAL0571        4.21045   BAL0572        .679104
    RHS       BAL0573        .950746   BAL0574        .679104
    RHS       BAL0575        .271642   BAL0576        .407463
    RHS       BAL0577        4.61791   BAL0578        2.03731
    RHS       BAL0579        .407463   BAL0580        .543284
    RHS       BAL0582        1.22239   BAL0584        1.62985
    RHS       BAL0604       .0460795   BAL0606        .153598
    RHS       BAL0607        .122879   BAL0608        .291837
    RHS       BAL0609        .184318   BAL0610        .307197
    RHS       BAL0611        .291837   BAL0612       .0614393
    RHS       BAL0614        .445435   BAL0615        .368636
    RHS       BAL0616       .0614393   BAL0617        .138238
    RHS       BAL0618        .122879   BAL0619        .307197
    RHS       BAL0620        .215038   BAL0621        .522234
    RHS       BAL0622        .153598   BAL0623        .383996
    RHS       BAL0625        .383996   BAL0626       .0460795
    RHS       BAL0627       .0614393   BAL0628        .368636
    RHS       BAL0629        .122879   BAL0630       .0614393
    RHS       BAL0631       .0767991   BAL0632        .153598
    RHS       BAL0633        .353276   BAL0634        .245757
    RHS       BAL0635       .0460795   BAL0636       .0307197
    RHS       BAL0637        .583673   BAL0638        .368636
    RHS       BAL0639       .0767991   BAL0640        .122879
    RHS       BAL0641       .0767991   BAL0642       .0767991
    RHS       BAL0643        .215038   BAL0644       .0460795
    RHS       BAL0645        .491514   BAL0646        .261117
    RHS       BAL0647        .184318   BAL0648        .184318
    RHS       BAL0649        .138238   BAL0650        .107519
    RHS       BAL0651        .184318   BAL0653        .568314
    RHS       BAL0654       .0614393   BAL0655        .552954
    RHS       BAL0656        .276477   BAL0657        .153598
    RHS       BAL0658        .552954   BAL0659        .460795
    RHS       BAL0660        .460795   BAL0663        .138238
    RHS       BAL0665        .107519   BAL0666       .0767991
    RHS       BAL0667       .0614393   BAL0668       .0614393
    RHS       BAL0669       .0614393   BAL0671        .414715
    RHS       BAL0672        .107519   BAL0673       .0767991
    RHS       BAL0674       .0307197   BAL0676       .0767991
    RHS       BAL0677        .138238   BAL0678        .291837
    RHS       BAL0679       .0460795   BAL0680       .0460795
    RHS       BAL0682       .0614393   BAL0684        .168958
    RHS       BAL0706        .125786   BAL0707        .330189
    RHS       BAL0708        .188679   BAL0709        .125786
    RHS       BAL0710        .235849   BAL0711        .235849
    RHS       BAL0712        .141509   BAL0714        .204403
    RHS       BAL0715        .471698   BAL0716        .172956
    RHS       BAL0717        .204403   BAL0718        .235849
    RHS       BAL0719        .393082   BAL0720        .408805
    RHS       BAL0721        .361635   BAL0722        .188679
    RHS       BAL0723        .220126   BAL0725       .0786164
    RHS       BAL0726       .0786164   BAL0727       .0943396
    RHS       BAL0728        .267296   BAL0729        .157233
    RHS       BAL0730        .393082   BAL0731        .220126
    RHS       BAL0732        .188679   BAL0733        .204403
    RHS       BAL0734        .172956   BAL0735        .157233
    RHS       BAL0736       .0943396   BAL0737        .408805
    RHS       BAL0738        .707547   BAL0739        .141509
    RHS       BAL0740        .110063   BAL0741        .157233
    RHS       BAL0742        .125786   BAL0743        .283019
    RHS       BAL0744        .235849   BAL0745        .471698
    RHS       BAL0746        .220126   BAL0747        .125786
    RHS       BAL0748        .141509   BAL0749        .188679
    RHS       BAL0750        .235849   BAL0751        .251572
    RHS       BAL0753        .707547   BAL0754        .172956
    RHS       BAL0755        .314465   BAL0756        .424528
    RHS       BAL0757        .204403   BAL0758        .896226
    RHS       BAL0759        .220126   BAL0760        .550314
    RHS       BAL0763        .220126   BAL0765       .0786164
    RHS       BAL0766       .0628931   BAL0767       .0628931
    RHS       BAL0768       .0471698   BAL0769       .0314465
    RHS       BAL0771       .0943396   BAL0772       .0628931
    RHS       BAL0773       .0943396   BAL0774       .0157233
    RHS       BAL0776       .0471698   BAL0777       .0786164
    RHS       BAL0778        .141509   BAL0779       .0314465
    RHS       BAL0780       .0471698   BAL0782       .0786164
    RHS       BAL0784        .157233
QUADOBJ
    PREG0101  PREG0101        50.   
    PREG0101  PREG0102         4.   
    PREG0101  PREG0103         4.   
    PREG0101  PREG0105         4.   
    PREG0101  PREG0202         2.   
    PREG0101  PREG0203         2.   
    PREG0101  PREG0205         2.   
    PREG0101  PREG0207         2.   
    PREG0101  PREG0401         2.   
    PREG0101  PREG0402         2.   
    PREG0101  PREG0404         2.   
    PREG0101  PREG0405         2.   
    PREG0101  PREG0406         2.   
    PREG0101  PREG0408         2.   
    PREG0101  POVR0101         1.   
    PREG0101  SH010102         1.   
    PREG0101  SH010103         1.   
    PREG0101  SH010104         1.   
    PREG0101  SH010105         1.   
    PREG0101  SH010106         1.   
    PREG0101  SH010107         1.   
    PREG0101  SH010108         1.   
    PREG0101  SH010109         1.   
    PREG0101  SH010110         1.   
    PREG0101  SH010111         1.   
    PREG0101  SH010112         1.   
    PREG0101  SH010114         1.   
    PREG0101  SH010115         1.   
    PREG0101  SH010116         1.   
    PREG0101  SH010117         1.   
    PREG0101  SH010119         1.   
    PREG0101  SH010120         1.   
    PREG0101  SH010121         1.   
    PREG0101  SH010124         1.   
    PREG0101  SH010128         1.   
    PREG0101  SH010131         1.   
    PREG0101  SH010133         1.   
    PREG0101  SH010134         1.   
    PREG0101  SH010137         1.   
    PREG0101  SH010138         1.   
    PREG0101  SH010139         1.   
    PREG0101  SH010140         1.   
    PREG0101  SH010142         1.   
    PREG0101  SH010143         1.   
    PREG0101  SH010145         1.   
    PREG0101  SH010146         1.   
    PREG0101  SH010147         1.   
    PREG0101  SH010148         1.   
    PREG0101  SH010149         1.   
    PREG0101  SH010150         1.   
    PREG0101  SH010151         1.   
    PREG0101  SH010152         1.   
    PREG0101  SH010153         1.   
    PREG0101  SH010154         1.   
    PREG0101  SH010155         1.   
    PREG0101  SH010156         1.   
    PREG0101  SH010157         1.   
    PREG0101  SH010158         1.   
    PREG0101  SH010159         1.   
    PREG0101  SH010160         1.   
    PREG0101  SH010163         1.   
    PREG0101  SH010164         1.   
    PREG0101  SH010171         1.   
    PREG0101  SH010173         1.   
    PREG0101  SH010177         1.   
    PREG0101  SH010178         1.   
    PREG0101  SH010182         1.   
    PREG0101  SH010183         1.   
    PREG0101  TRSH0101         1.   
    PREG0102  PREG0102        50.   
    PREG0102  PREG0103         4.   
    PREG0102  PREG0105         4.   
    PREG0102  PREG0202         2.   
    PREG0102  PREG0203         2.   
    PREG0102  PREG0205         2.   
    PREG0102  PREG0207         2.   
    PREG0102  PREG0401         2.   
    PREG0102  PREG0402         2.   
    PREG0102  PREG0404         2.   
    PREG0102  PREG0405         2.   
    PREG0102  PREG0406         2.   
    PREG0102  PREG0408         2.   
    PREG0102  POVR0102         1.   
    PREG0102  SH020102         1.   
    PREG0102  SH020103         1.   
    PREG0102  SH020104         1.   
    PREG0102  SH020105         1.   
    PREG0102  SH020106         1.   
    PREG0102  SH020107         1.   
    PREG0102  SH020108         1.   
    PREG0102  SH020109         1.   
    PREG0102  SH020110         1.   
    PREG0102  SH020111         1.   
    PREG0102  SH020112         1.   
    PREG0102  SH020114         1.   
    PREG0102  SH020115         1.   
    PREG0102  SH020116         1.   
    PREG0102  SH020117         1.   
    PREG0102  SH020119         1.   
    PREG0102  SH020120         1.   
    PREG0102  SH020121         1.   
    PREG0102  SH020124         1.   
    PREG0102  SH020128         1.   
    PREG0102  SH020131         1.   
    PREG0102  SH020133         1.   
    PREG0102  SH020134         1.   
    PREG0102  SH020137         1.   
    PREG0102  SH020138         1.   
    PREG0102  SH020139         1.   
    PREG0102  SH020140         1.   
    PREG0102  SH020142         1.   
    PREG0102  SH020143         1.   
    PREG0102  SH020145         1.   
    PREG0102  SH020146         1.   
    PREG0102  SH020147         1.   
    PREG0102  SH020148         1.   
    PREG0102  SH020149         1.   
    PREG0102  SH020150         1.   
    PREG0102  SH020151         1.   
    PREG0102  SH020152         1.   
    PREG0102  SH020153         1.   
    PREG0102  SH020154         1.   
    PREG0102  SH020155         1.   
    PREG0102  SH020156         1.   
    PREG0102  SH020157         1.   
    PREG0102  SH020158         1.   
    PREG0102  SH020159         1.   
    PREG0102  SH020160         1.   
    PREG0102  SH020163         1.   
    PREG0102  SH020164         1.   
    PREG0102  SH020171         1.   
    PREG0102  SH020173         1.   
    PREG0102  SH020177         1.   
    PREG0102  SH020178         1.   
    PREG0102  SH020182         1.   
    PREG0102  SH020183         1.   
    PREG0102  TRSH0102         1.   
    PREG0103  PREG0103        40.   
    PREG0103  PREG0105         4.   
    PREG0103  PREG0202         2.   
    PREG0103  PREG0203         2.   
    PREG0103  PREG0205         2.   
    PREG0103  PREG0207         2.   
    PREG0103  PREG0401         2.   
    PREG0103  PREG0402         2.   
    PREG0103  PREG0404         2.   
    PREG0103  PREG0405         2.   
    PREG0103  PREG0406         2.   
    PREG0103  PREG0408         2.   
    PREG0105  PREG0105        40.   
    PREG0105  PREG0202         2.   
    PREG0105  PREG0203         2.   
    PREG0105  PREG0205         2.   
    PREG0105  PREG0207         2.   
    PREG0105  PREG0401         2.   
    PREG0105  PREG0402         2.   
    PREG0105  PREG0404         2.   
    PREG0105  PREG0405         2.   
    PREG0105  PREG0406         2.   
    PREG0105  PREG0408         2.   
    PREG0202  PREG0202        50.   
    PREG0202  PREG0203         4.   
    PREG0202  PREG0205         4.   
    PREG0202  PREG0207         4.   
    PREG0202  PREG0401         2.   
    PREG0202  PREG0402         2.   
    PREG0202  PREG0404         2.   
    PREG0202  PREG0405         2.   
    PREG0202  PREG0406         2.   
    PREG0202  PREG0408         2.   
    PREG0202  POVR0202         1.   
    PREG0202  SH020201         1.   
    PREG0202  SH020203         1.   
    PREG0202  SH020204         1.   
    PREG0202  SH020205         1.   
    PREG0202  SH020207         1.   
    PREG0202  SH020208         1.   
    PREG0202  SH020210         1.   
    PREG0202  SH020215         1.   
    PREG0202  SH020216         1.   
    PREG0202  SH020219         1.   
    PREG0202  SH020220         1.   
    PREG0202  SH020221         1.   
    PREG0202  SH020225         1.   
    PREG0202  SH020233         1.   
    PREG0202  SH020234         1.   
    PREG0202  SH020237         1.   
    PREG0202  SH020238         1.   
    PREG0202  SH020240         1.   
    PREG0202  SH020243         1.   
    PREG0202  SH020245         1.   
    PREG0202  SH020246         1.   
    PREG0202  SH020252         1.   
    PREG0202  SH020253         1.   
    PREG0202  SH020255         1.   
    PREG0202  SH020258         1.   
    PREG0202  SH020259         1.   
    PREG0202  SH020260         1.   
    PREG0202  SH020264         1.   
    PREG0202  SH020265         1.   
    PREG0202  SH020266         1.   
    PREG0202  SH020267         1.   
    PREG0202  SH020268         1.   
    PREG0202  SH020269         1.   
    PREG0202  SH020272         1.   
    PREG0202  SH020273         1.   
    PREG0202  SH020274         1.   
    PREG0202  SH020275         1.   
    PREG0202  SH020276         1.   
    PREG0202  SH020277         1.   
    PREG0202  SH020278         1.   
    PREG0202  SH020279         1.   
    PREG0202  SH020282         1.   
    PREG0202  SH020283         1.   
    PREG0202  SH020284         1.   
    PREG0202  TRSH0202         1.   
    PREG0203  PREG0203        40.   
    PREG0203  PREG0205         4.   
    PREG0203  PREG0207         4.   
    PREG0203  PREG0401         2.   
    PREG0203  PREG0402         2.   
    PREG0203  PREG0404         2.   
    PREG0203  PREG0405         2.   
    PREG0203  PREG0406         2.   
    PREG0203  PREG0408         2.   
    PREG0205  PREG0205        40.   
    PREG0205  PREG0207         4.   
    PREG0205  PREG0401         2.   
    PREG0205  PREG0402         2.   
    PREG0205  PREG0404         2.   
    PREG0205  PREG0405         2.   
    PREG0205  PREG0406         2.   
    PREG0205  PREG0408         2.   
    PREG0207  PREG0207        40.   
    PREG0207  PREG0401         2.   
    PREG0207  PREG0402         2.   
    PREG0207  PREG0404         2.   
    PREG0207  PREG0405         2.   
    PREG0207  PREG0406         2.   
    PREG0207  PREG0408         2.   
    PREG0401  PREG0401        50.   
    PREG0401  PREG0402         4.   
    PREG0401  PREG0404         4.   
    PREG0401  PREG0405         4.   
    PREG0401  PREG0406         4.   
    PREG0401  PREG0408         4.   
    PREG0401  POVR0401         1.   
    PREG0401  SH010401         1.   
    PREG0401  SH010402         1.   
    PREG0401  SH010403         1.   
    PREG0401  SH010405         1.   
    PREG0401  SH010407         1.   
    PREG0401  SH010408         1.   
    PREG0401  SH010410         1.   
    PREG0401  SH010415         1.   
    PREG0401  SH010416         1.   
    PREG0401  SH010418         1.   
    PREG0401  SH010419         1.   
    PREG0401  SH010420         1.   
    PREG0401  SH010421         1.   
    PREG0401  SH010422         1.   
    PREG0401  SH010423         1.   
    PREG0401  SH010426         1.   
    PREG0401  SH010429         1.   
    PREG0401  SH010430         1.   
    PREG0401  SH010432         1.   
    PREG0401  SH010433         1.   
    PREG0401  SH010434         1.   
    PREG0401  SH010435         1.   
    PREG0401  SH010437         1.   
    PREG0401  SH010438         1.   
    PREG0401  SH010440         1.   
    PREG0401  SH010443         1.   
    PREG0401  SH010445         1.   
    PREG0401  SH010446         1.   
    PREG0401  SH010452         1.   
    PREG0401  SH010453         1.   
    PREG0401  SH010455         1.   
    PREG0401  SH010458         1.   
    PREG0401  SH010459         1.   
    PREG0401  SH010460         1.   
    PREG0401  SH010464         1.   
    PREG0401  SH010471         1.   
    PREG0401  SH010473         1.   
    PREG0401  SH010477         1.   
    PREG0401  SH010478         1.   
    PREG0401  SH010480         1.   
    PREG0401  SH010482         1.   
    PREG0401  SH010483         1.   
    PREG0401  TRSH0401         1.   
    PREG0402  PREG0402        50.   
    PREG0402  PREG0404         4.   
    PREG0402  PREG0405         4.   
    PREG0402  PREG0406         4.   
    PREG0402  PREG0408         4.   
    PREG0402  POVR0402         1.   
    PREG0402  SH020401         1.   
    PREG0402  SH020402         1.   
    PREG0402  SH020403         1.   
    PREG0402  SH020405         1.   
    PREG0402  SH020407         1.   
    PREG0402  SH020408         1.   
    PREG0402  SH020410         1.   
    PREG0402  SH020415         1.   
    PREG0402  SH020416         1.   
    PREG0402  SH020418         1.   
    PREG0402  SH020419         1.   
    PREG0402  SH020420         1.   
    PREG0402  SH020421         1.   
    PREG0402  SH020422         1.   
    PREG0402  SH020423         1.   
    PREG0402  SH020426         1.   
    PREG0402  SH020429         1.   
    PREG0402  SH020430         1.   
    PREG0402  SH020432         1.   
    PREG0402  SH020433         1.   
    PREG0402  SH020434         1.   
    PREG0402  SH020435         1.   
    PREG0402  SH020437         1.   
    PREG0402  SH020438         1.   
    PREG0402  SH020440         1.   
    PREG0402  SH020443         1.   
    PREG0402  SH020445         1.   
    PREG0402  SH020446         1.   
    PREG0402  SH020452         1.   
    PREG0402  SH020453         1.   
    PREG0402  SH020455         1.   
    PREG0402  SH020458         1.   
    PREG0402  SH020459         1.   
    PREG0402  SH020460         1.   
    PREG0402  SH020464         1.   
    PREG0402  SH020471         1.   
    PREG0402  SH020473         1.   
    PREG0402  SH020477         1.   
    PREG0402  SH020478         1.   
    PREG0402  SH020480         1.   
    PREG0402  SH020482         1.   
    PREG0402  SH020483         1.   
    PREG0402  TRSH0402         1.   
    PREG0404  PREG0404        40.   
    PREG0404  PREG0405         4.   
    PREG0404  PREG0406         4.   
    PREG0404  PREG0408         4.   
    PREG0405  PREG0405        40.   
    PREG0405  PREG0406         4.   
    PREG0405  PREG0408         4.   
    PREG0406  PREG0406        40.   
    PREG0406  PREG0408         4.   
    PREG0408  PREG0408        40.   
    POVR0101  POVR0101        50.   
    POVR0101  POVR0102         4.   
    POVR0101  POVR0103         4.   
    POVR0101  POVR0105         4.   
    POVR0101  POVR0202         2.   
    POVR0101  POVR0203         2.   
    POVR0101  POVR0205         2.   
    POVR0101  POVR0207         2.   
    POVR0101  POVR0401         2.   
    POVR0101  POVR0402         2.   
    POVR0101  POVR0404         2.   
    POVR0101  POVR0405         2.   
    POVR0101  POVR0406         2.   
    POVR0101  SH010102         1.   
    POVR0101  SH010103         1.   
    POVR0101  SH010104         1.   
    POVR0101  SH010105         1.   
    POVR0101  SH010106         1.   
    POVR0101  SH010107         1.   
    POVR0101  SH010108         1.   
    POVR0101  SH010109         1.   
    POVR0101  SH010110         1.   
    POVR0101  SH010111         1.   
    POVR0101  SH010112         1.   
    POVR0101  SH010114         1.   
    POVR0101  SH010115         1.   
    POVR0101  SH010116         1.   
    POVR0101  SH010117         1.   
    POVR0101  SH010119         1.   
    POVR0101  SH010120         1.   
    POVR0101  SH010121         1.   
    POVR0101  SH010124         1.   
    POVR0101  SH010128         1.   
    POVR0101  SH010131         1.   
    POVR0101  SH010133         1.   
    POVR0101  SH010134         1.   
    POVR0101  SH010137         1.   
    POVR0101  SH010138         1.   
    POVR0101  SH010139         1.   
    POVR0101  SH010140         1.   
    POVR0101  SH010142         1.   
    POVR0101  SH010143         1.   
    POVR0101  SH010145         1.   
    POVR0101  SH010146         1.   
    POVR0101  SH010147         1.   
    POVR0101  SH010148         1.   
    POVR0101  SH010149         1.   
    POVR0101  SH010150         1.   
    POVR0101  SH010151         1.   
    POVR0101  SH010152         1.   
    POVR0101  SH010153         1.   
    POVR0101  SH010154         1.   
    POVR0101  SH010155         1.   
    POVR0101  SH010156         1.   
    POVR0101  SH010157         1.   
    POVR0101  SH010158         1.   
    POVR0101  SH010159         1.   
    POVR0101  SH010160         1.   
    POVR0101  SH010163         1.   
    POVR0101  SH010164         1.   
    POVR0101  SH010171         1.   
    POVR0101  SH010173         1.   
    POVR0101  SH010177         1.   
    POVR0101  SH010178         1.   
    POVR0101  SH010182         1.   
    POVR0101  SH010183         1.   
    POVR0101  TRSH0101         1.   
    POVR0102  POVR0102        50.   
    POVR0102  POVR0103         4.   
    POVR0102  POVR0105         4.   
    POVR0102  POVR0202         2.   
    POVR0102  POVR0203         2.   
    POVR0102  POVR0205         2.   
    POVR0102  POVR0207         2.   
    POVR0102  POVR0401         2.   
    POVR0102  POVR0402         2.   
    POVR0102  POVR0404         2.   
    POVR0102  POVR0405         2.   
    POVR0102  POVR0406         2.   
    POVR0102  SH020102         1.   
    POVR0102  SH020103         1.   
    POVR0102  SH020104         1.   
    POVR0102  SH020105         1.   
    POVR0102  SH020106         1.   
    POVR0102  SH020107         1.   
    POVR0102  SH020108         1.   
    POVR0102  SH020109         1.   
    POVR0102  SH020110         1.   
    POVR0102  SH020111         1.   
    POVR0102  SH020112         1.   
    POVR0102  SH020114         1.   
    POVR0102  SH020115         1.   
    POVR0102  SH020116         1.   
    POVR0102  SH020117         1.   
    POVR0102  SH020119         1.   
    POVR0102  SH020120         1.   
    POVR0102  SH020121         1.   
    POVR0102  SH020124         1.   
    POVR0102  SH020128         1.   
    POVR0102  SH020131         1.   
    POVR0102  SH020133         1.   
    POVR0102  SH020134         1.   
    POVR0102  SH020137         1.   
    POVR0102  SH020138         1.   
    POVR0102  SH020139         1.   
    POVR0102  SH020140         1.   
    POVR0102  SH020142         1.   
    POVR0102  SH020143         1.   
    POVR0102  SH020145         1.   
    POVR0102  SH020146         1.   
    POVR0102  SH020147         1.   
    POVR0102  SH020148         1.   
    POVR0102  SH020149         1.   
    POVR0102  SH020150         1.   
    POVR0102  SH020151         1.   
    POVR0102  SH020152         1.   
    POVR0102  SH020153         1.   
    POVR0102  SH020154         1.   
    POVR0102  SH020155         1.   
    POVR0102  SH020156         1.   
    POVR0102  SH020157         1.   
    POVR0102  SH020158         1.   
    POVR0102  SH020159         1.   
    POVR0102  SH020160         1.   
    POVR0102  SH020163         1.   
    POVR0102  SH020164         1.   
    POVR0102  SH020171         1.   
    POVR0102  SH020173         1.   
    POVR0102  SH020177         1.   
    POVR0102  SH020178         1.   
    POVR0102  SH020182         1.   
    POVR0102  SH020183         1.   
    POVR0102  TRSH0102         1.   
    POVR0103  POVR0103        40.   
    POVR0103  POVR0105         4.   
    POVR0103  POVR0202         2.   
    POVR0103  POVR0203         2.   
    POVR0103  POVR0205         2.   
    POVR0103  POVR0207         2.   
    POVR0103  POVR0401         2.   
    POVR0103  POVR0402         2.   
    POVR0103  POVR0404         2.   
    POVR0103  POVR0405         2.   
    POVR0103  POVR0406         2.   
    POVR0105  POVR0105        40.   
    POVR0105  POVR0202         2.   
    POVR0105  POVR0203         2.   
    POVR0105  POVR0205         2.   
    POVR0105  POVR0207         2.   
    POVR0105  POVR0401         2.   
    POVR0105  POVR0402         2.   
    POVR0105  POVR0404         2.   
    POVR0105  POVR0405         2.   
    POVR0105  POVR0406         2.   
    POVR0202  POVR0202        50.   
    POVR0202  POVR0203         4.   
    POVR0202  POVR0205         4.   
    POVR0202  POVR0207         4.   
    POVR0202  POVR0401         2.   
    POVR0202  POVR0402         2.   
    POVR0202  POVR0404         2.   
    POVR0202  POVR0405         2.   
    POVR0202  POVR0406         2.   
    POVR0202  SH020201         1.   
    POVR0202  SH020203         1.   
    POVR0202  SH020204         1.   
    POVR0202  SH020205         1.   
    POVR0202  SH020207         1.   
    POVR0202  SH020208         1.   
    POVR0202  SH020210         1.   
    POVR0202  SH020215         1.   
    POVR0202  SH020216         1.   
    POVR0202  SH020219         1.   
    POVR0202  SH020220         1.   
    POVR0202  SH020221         1.   
    POVR0202  SH020225         1.   
    POVR0202  SH020233         1.   
    POVR0202  SH020234         1.   
    POVR0202  SH020237         1.   
    POVR0202  SH020238         1.   
    POVR0202  SH020240         1.   
    POVR0202  SH020243         1.   
    POVR0202  SH020245         1.   
    POVR0202  SH020246         1.   
    POVR0202  SH020252         1.   
    POVR0202  SH020253         1.   
    POVR0202  SH020255         1.   
    POVR0202  SH020258         1.   
    POVR0202  SH020259         1.   
    POVR0202  SH020260         1.   
    POVR0202  SH020264         1.   
    POVR0202  SH020265         1.   
    POVR0202  SH020266         1.   
    POVR0202  SH020267         1.   
    POVR0202  SH020268         1.   
    POVR0202  SH020269         1.   
    POVR0202  SH020272         1.   
    POVR0202  SH020273         1.   
    POVR0202  SH020274         1.   
    POVR0202  SH020275         1.   
    POVR0202  SH020276         1.   
    POVR0202  SH020277         1.   
    POVR0202  SH020278         1.   
    POVR0202  SH020279         1.   
    POVR0202  SH020282         1.   
    POVR0202  SH020283         1.   
    POVR0202  SH020284         1.   
    POVR0202  TRSH0202         1.   
    POVR0203  POVR0203        40.   
    POVR0203  POVR0205         4.   
    POVR0203  POVR0207         4.   
    POVR0203  POVR0401         2.   
    POVR0203  POVR0402         2.   
    POVR0203  POVR0404         2.   
    POVR0203  POVR0405         2.   
    POVR0203  POVR0406         2.   
    POVR0205  POVR0205        40.   
    POVR0205  POVR0207         4.   
    POVR0205  POVR0401         2.   
    POVR0205  POVR0402         2.   
    POVR0205  POVR0404         2.   
    POVR0205  POVR0405         2.   
    POVR0205  POVR0406         2.   
    POVR0207  POVR0207        40.   
    POVR0207  POVR0401         2.   
    POVR0207  POVR0402         2.   
    POVR0207  POVR0404         2.   
    POVR0207  POVR0405         2.   
    POVR0207  POVR0406         2.   
    POVR0401  POVR0401        50.   
    POVR0401  POVR0402         4.   
    POVR0401  POVR0404         4.   
    POVR0401  POVR0405         4.   
    POVR0401  POVR0406         4.   
    POVR0401  SH010401         1.   
    POVR0401  SH010402         1.   
    POVR0401  SH010403         1.   
    POVR0401  SH010405         1.   
    POVR0401  SH010407         1.   
    POVR0401  SH010408         1.   
    POVR0401  SH010410         1.   
    POVR0401  SH010415         1.   
    POVR0401  SH010416         1.   
    POVR0401  SH010418         1.   
    POVR0401  SH010419         1.   
    POVR0401  SH010420         1.   
    POVR0401  SH010421         1.   
    POVR0401  SH010422         1.   
    POVR0401  SH010423         1.   
    POVR0401  SH010426         1.   
    POVR0401  SH010429         1.   
    POVR0401  SH010430         1.   
    POVR0401  SH010432         1.   
    POVR0401  SH010433         1.   
    POVR0401  SH010434         1.   
    POVR0401  SH010435         1.   
    POVR0401  SH010437         1.   
    POVR0401  SH010438         1.   
    POVR0401  SH010440         1.   
    POVR0401  SH010443         1.   
    POVR0401  SH010445         1.   
    POVR0401  SH010446         1.   
    POVR0401  SH010452         1.   
    POVR0401  SH010453         1.   
    POVR0401  SH010455         1.   
    POVR0401  SH010458         1.   
    POVR0401  SH010459         1.   
    POVR0401  SH010460         1.   
    POVR0401  SH010464         1.   
    POVR0401  SH010471         1.   
    POVR0401  SH010473         1.   
    POVR0401  SH010477         1.   
    POVR0401  SH010478         1.   
    POVR0401  SH010480         1.   
    POVR0401  SH010482         1.   
    POVR0401  SH010483         1.   
    POVR0401  TRSH0401         1.   
    POVR0402  POVR0402        50.   
    POVR0402  POVR0404         4.   
    POVR0402  POVR0405         4.   
    POVR0402  POVR0406         4.   
    POVR0402  SH020401         1.   
    POVR0402  SH020402         1.   
    POVR0402  SH020403         1.   
    POVR0402  SH020405         1.   
    POVR0402  SH020407         1.   
    POVR0402  SH020408         1.   
    POVR0402  SH020410         1.   
    POVR0402  SH020415         1.   
    POVR0402  SH020416         1.   
    POVR0402  SH020418         1.   
    POVR0402  SH020419         1.   
    POVR0402  SH020420         1.   
    POVR0402  SH020421         1.   
    POVR0402  SH020422         1.   
    POVR0402  SH020423         1.   
    POVR0402  SH020426         1.   
    POVR0402  SH020429         1.   
    POVR0402  SH020430         1.   
    POVR0402  SH020432         1.   
    POVR0402  SH020433         1.   
    POVR0402  SH020434         1.   
    POVR0402  SH020435         1.   
    POVR0402  SH020437         1.   
    POVR0402  SH020438         1.   
    POVR0402  SH020440         1.   
    POVR0402  SH020443         1.   
    POVR0402  SH020445         1.   
    POVR0402  SH020446         1.   
    POVR0402  SH020452         1.   
    POVR0402  SH020453         1.   
    POVR0402  SH020455         1.   
    POVR0402  SH020458         1.   
    POVR0402  SH020459         1.   
    POVR0402  SH020460         1.   
    POVR0402  SH020464         1.   
    POVR0402  SH020471         1.   
    POVR0402  SH020473         1.   
    POVR0402  SH020477         1.   
    POVR0402  SH020478         1.   
    POVR0402  SH020480         1.   
    POVR0402  SH020482         1.   
    POVR0402  SH020483         1.   
    POVR0402  TRSH0402         1.   
    POVR0404  POVR0404        40.   
    POVR0404  POVR0405         4.   
    POVR0404  POVR0406         4.   
    POVR0405  POVR0405        40.   
    POVR0405  POVR0406         4.   
    POVR0406  POVR0406        40.   
    SH010201  SH010201        10.   
    SH010201  SH010203         1.   
    SH010201  SH010204         1.   
    SH010201  SH010205         1.   
    SH010201  SH010207         1.   
    SH010201  SH010208         1.   
    SH010201  SH010210         1.   
    SH010201  SH010215         1.   
    SH010201  SH010216         1.   
    SH010201  SH010219         1.   
    SH010201  SH010220         1.   
    SH010201  SH010221         1.   
    SH010201  SH010225         1.   
    SH010201  SH010233         1.   
    SH010201  SH010234         1.   
    SH010201  SH010237         1.   
    SH010201  SH010238         1.   
    SH010201  SH010240         1.   
    SH010201  SH010243         1.   
    SH010201  SH010245         1.   
    SH010201  SH010246         1.   
    SH010201  SH010252         1.   
    SH010201  SH010253         1.   
    SH010201  SH010255         1.   
    SH010201  SH010258         1.   
    SH010201  SH010259         1.   
    SH010201  SH010260         1.   
    SH010201  SH010264         1.   
    SH010201  SH010265         1.   
    SH010201  SH010266         1.   
    SH010201  SH010267         1.   
    SH010201  SH010268         1.   
    SH010201  SH010269         1.   
    SH010201  SH010272         1.   
    SH010201  SH010273         1.   
    SH010201  SH010274         1.   
    SH010201  SH010275         1.   
    SH010201  SH010276         1.   
    SH010201  SH010277         1.   
    SH010201  SH010278         1.   
    SH010201  SH010279         1.   
    SH010201  SH010282         1.   
    SH010201  SH010283         1.   
    SH010201  SH010284         1.   
    SH010201  TRSH0201         1.   
    SH010301  SH010301        10.   
    SH010301  SH010302         1.   
    SH010301  SH010304         1.   
    SH010301  SH010305         1.   
    SH010301  SH010307         1.   
    SH010301  SH010308         1.   
    SH010301  SH010310         1.   
    SH010301  SH010315         1.   
    SH010301  SH010316         1.   
    SH010301  SH010319         1.   
    SH010301  SH010320         1.   
    SH010301  SH010321         1.   
    SH010301  SH010333         1.   
    SH010301  SH010334         1.   
    SH010301  SH010337         1.   
    SH010301  SH010338         1.   
    SH010301  SH010340         1.   
    SH010301  SH010343         1.   
    SH010301  SH010345         1.   
    SH010301  SH010346         1.   
    SH010301  SH010352         1.   
    SH010301  SH010353         1.   
    SH010301  SH010355         1.   
    SH010301  SH010358         1.   
    SH010301  SH010359         1.   
    SH010301  SH010360         1.   
    SH010301  SH010364         1.   
    SH010301  SH010371         1.   
    SH010301  SH010373         1.   
    SH010301  SH010377         1.   
    SH010301  SH010378         1.   
    SH010301  SH010382         1.   
    SH010301  SH010383         1.   
    SH010301  TRSH0301         1.   
    SH010401  SH010401        10.   
    SH010401  SH010402         1.   
    SH010401  SH010403         1.   
    SH010401  SH010405         1.   
    SH010401  SH010407         1.   
    SH010401  SH010408         1.   
    SH010401  SH010410         1.   
    SH010401  SH010415         1.   
    SH010401  SH010416         1.   
    SH010401  SH010418         1.   
    SH010401  SH010419         1.   
    SH010401  SH010420         1.   
    SH010401  SH010421         1.   
    SH010401  SH010422         1.   
    SH010401  SH010423         1.   
    SH010401  SH010426         1.   
    SH010401  SH010429         1.   
    SH010401  SH010430         1.   
    SH010401  SH010432         1.   
    SH010401  SH010433         1.   
    SH010401  SH010434         1.   
    SH010401  SH010435         1.   
    SH010401  SH010437         1.   
    SH010401  SH010438         1.   
    SH010401  SH010440         1.   
    SH010401  SH010443         1.   
    SH010401  SH010445         1.   
    SH010401  SH010446         1.   
    SH010401  SH010452         1.   
    SH010401  SH010453         1.   
    SH010401  SH010455         1.   
    SH010401  SH010458         1.   
    SH010401  SH010459         1.   
    SH010401  SH010460         1.   
    SH010401  SH010464         1.   
    SH010401  SH010471         1.   
    SH010401  SH010473         1.   
    SH010401  SH010477         1.   
    SH010401  SH010478         1.   
    SH010401  SH010480         1.   
    SH010401  SH010482         1.   
    SH010401  SH010483         1.   
    SH010401  TRSH0401         1.   
    SH010501  SH010501        10.   
    SH010501  SH010502         1.   
    SH010501  SH010503         1.   
    SH010501  SH010504         1.   
    SH010501  SH010507         1.   
    SH010501  SH010508         1.   
    SH010501  SH010510         1.   
    SH010501  SH010515         1.   
    SH010501  SH010516         1.   
    SH010501  SH010519         1.   
    SH010501  SH010520         1.   
    SH010501  SH010521         1.   
    SH010501  SH010528         1.   
    SH010501  SH010533         1.   
    SH010501  SH010534         1.   
    SH010501  SH010537         1.   
    SH010501  SH010538         1.   
    SH010501  SH010540         1.   
    SH010501  SH010543         1.   
    SH010501  SH010545         1.   
    SH010501  SH010546         1.   
    SH010501  SH010549         1.   
    SH010501  SH010551         1.   
    SH010501  SH010552         1.   
    SH010501  SH010553         1.   
    SH010501  SH010555         1.   
    SH010501  SH010556         1.   
    SH010501  SH010557         1.   
    SH010501  SH010558         1.   
    SH010501  SH010559         1.   
    SH010501  SH010560         1.   
    SH010501  SH010563         1.   
    SH010501  SH010564         1.   
    SH010501  SH010571         1.   
    SH010501  SH010573         1.   
    SH010501  SH010577         1.   
    SH010501  SH010578         1.   
    SH010501  SH010582         1.   
    SH010501  SH010583         1.   
    SH010501  TRSH0501         1.   
    SH010601  SH010601        10.   
    SH010601  SH010602         1.   
    SH010601  SH010603         1.   
    SH010601  SH010604         1.   
    SH010601  SH010605         1.   
    SH010601  SH010607         1.   
    SH010601  SH010608         1.   
    SH010601  SH010610         1.   
    SH010601  SH010614         1.   
    SH010601  SH010615         1.   
    SH010601  SH010616         1.   
    SH010601  SH010619         1.   
    SH010601  SH010627         1.   
    SH010601  SH010636         1.   
    SH010601  SH010637         1.   
    SH010601  SH010638         1.   
    SH010601  SH010640         1.   
    SH010601  SH010641         1.   
    SH010601  SH010643         1.   
    SH010601  SH010644         1.   
    SH010601  SH010645         1.   
    SH010601  SH010646         1.   
    SH010601  SH010653         1.   
    SH010601  SH010655         1.   
    SH010601  SH010658         1.   
    SH010601  SH010659         1.   
    SH010601  SH010660         1.   
    SH010601  SH010664         1.   
    SH010601  SH010671         1.   
    SH010601  SH010673         1.   
    SH010601  SH010683         1.   
    SH010601  TRSH0601         1.   
    SH010801  SH010801        10.   
    SH010801  SH010802         1.   
    SH010801  SH010803         1.   
    SH010801  SH010804         1.   
    SH010801  SH010805         1.   
    SH010801  SH010807         1.   
    SH010801  SH010808         1.   
    SH010801  SH010810         1.   
    SH010801  SH010815         1.   
    SH010801  SH010816         1.   
    SH010801  SH010817         1.   
    SH010801  SH010819         1.   
    SH010801  SH010820         1.   
    SH010801  SH010821         1.   
    SH010801  SH010833         1.   
    SH010801  SH010834         1.   
    SH010801  SH010837         1.   
    SH010801  SH010838         1.   
    SH010801  SH010840         1.   
    SH010801  SH010843         1.   
    SH010801  SH010845         1.   
    SH010801  SH010846         1.   
    SH010801  SH010852         1.   
    SH010801  SH010853         1.   
    SH010801  SH010855         1.   
    SH010801  SH010858         1.   
    SH010801  SH010859         1.   
    SH010801  SH010860         1.   
    SH010801  SH010864         1.   
    SH010801  SH010871         1.   
    SH010801  SH010873         1.   
    SH010801  SH010877         1.   
    SH010801  SH010878         1.   
    SH010801  SH010882         1.   
    SH010801  TRSH0801         1.   
    SH010102  SH010102        10.   
    SH010102  SH010103         1.   
    SH010102  SH010104         1.   
    SH010102  SH010105         1.   
    SH010102  SH010106         1.   
    SH010102  SH010107         1.   
    SH010102  SH010108         1.   
    SH010102  SH010109         1.   
    SH010102  SH010110         1.   
    SH010102  SH010111         1.   
    SH010102  SH010112         1.   
    SH010102  SH010114         1.   
    SH010102  SH010115         1.   
    SH010102  SH010116         1.   
    SH010102  SH010117         1.   
    SH010102  SH010119         1.   
    SH010102  SH010120         1.   
    SH010102  SH010121         1.   
    SH010102  SH010124         1.   
    SH010102  SH010128         1.   
    SH010102  SH010131         1.   
    SH010102  SH010133         1.   
    SH010102  SH010134         1.   
    SH010102  SH010137         1.   
    SH010102  SH010138         1.   
    SH010102  SH010139         1.   
    SH010102  SH010140         1.   
    SH010102  SH010142         1.   
    SH010102  SH010143         1.   
    SH010102  SH010145         1.   
    SH010102  SH010146         1.   
    SH010102  SH010147         1.   
    SH010102  SH010148         1.   
    SH010102  SH010149         1.   
    SH010102  SH010150         1.   
    SH010102  SH010151         1.   
    SH010102  SH010152         1.   
    SH010102  SH010153         1.   
    SH010102  SH010154         1.   
    SH010102  SH010155         1.   
    SH010102  SH010156         1.   
    SH010102  SH010157         1.   
    SH010102  SH010158         1.   
    SH010102  SH010159         1.   
    SH010102  SH010160         1.   
    SH010102  SH010163         1.   
    SH010102  SH010164         1.   
    SH010102  SH010171         1.   
    SH010102  SH010173         1.   
    SH010102  SH010177         1.   
    SH010102  SH010178         1.   
    SH010102  SH010182         1.   
    SH010102  SH010183         1.   
    SH010102  TRSH0101         1.   
    SH010302  SH010302        10.   
    SH010302  SH010304         1.   
    SH010302  SH010305         1.   
    SH010302  SH010307         1.   
    SH010302  SH010308         1.   
    SH010302  SH010310         1.   
    SH010302  SH010315         1.   
    SH010302  SH010316         1.   
    SH010302  SH010319         1.   
    SH010302  SH010320         1.   
    SH010302  SH010321         1.   
    SH010302  SH010333         1.   
    SH010302  SH010334         1.   
    SH010302  SH010337         1.   
    SH010302  SH010338         1.   
    SH010302  SH010340         1.   
    SH010302  SH010343         1.   
    SH010302  SH010345         1.   
    SH010302  SH010346         1.   
    SH010302  SH010352         1.   
    SH010302  SH010353         1.   
    SH010302  SH010355         1.   
    SH010302  SH010358         1.   
    SH010302  SH010359         1.   
    SH010302  SH010360         1.   
    SH010302  SH010364         1.   
    SH010302  SH010371         1.   
    SH010302  SH010373         1.   
    SH010302  SH010377         1.   
    SH010302  SH010378         1.   
    SH010302  SH010382         1.   
    SH010302  SH010383         1.   
    SH010302  TRSH0301         1.   
    SH010402  SH010402        10.   
    SH010402  SH010403         1.   
    SH010402  SH010405         1.   
    SH010402  SH010407         1.   
    SH010402  SH010408         1.   
    SH010402  SH010410         1.   
    SH010402  SH010415         1.   
    SH010402  SH010416         1.   
    SH010402  SH010418         1.   
    SH010402  SH010419         1.   
    SH010402  SH010420         1.   
    SH010402  SH010421         1.   
    SH010402  SH010422         1.   
    SH010402  SH010423         1.   
    SH010402  SH010426         1.   
    SH010402  SH010429         1.   
    SH010402  SH010430         1.   
    SH010402  SH010432         1.   
    SH010402  SH010433         1.   
    SH010402  SH010434         1.   
    SH010402  SH010435         1.   
    SH010402  SH010437         1.   
    SH010402  SH010438         1.   
    SH010402  SH010440         1.   
    SH010402  SH010443         1.   
    SH010402  SH010445         1.   
    SH010402  SH010446         1.   
    SH010402  SH010452         1.   
    SH010402  SH010453         1.   
    SH010402  SH010455         1.   
    SH010402  SH010458         1.   
    SH010402  SH010459         1.   
    SH010402  SH010460         1.   
    SH010402  SH010464         1.   
    SH010402  SH010471         1.   
    SH010402  SH010473         1.   
    SH010402  SH010477         1.   
    SH010402  SH010478         1.   
    SH010402  SH010480         1.   
    SH010402  SH010482         1.   
    SH010402  SH010483         1.   
    SH010402  TRSH0401         1.   
    SH010502  SH010502        10.   
    SH010502  SH010503         1.   
    SH010502  SH010504         1.   
    SH010502  SH010507         1.   
    SH010502  SH010508         1.   
    SH010502  SH010510         1.   
    SH010502  SH010515         1.   
    SH010502  SH010516         1.   
    SH010502  SH010519         1.   
    SH010502  SH010520         1.   
    SH010502  SH010521         1.   
    SH010502  SH010528         1.   
    SH010502  SH010533         1.   
    SH010502  SH010534         1.   
    SH010502  SH010537         1.   
    SH010502  SH010538         1.   
    SH010502  SH010540         1.   
    SH010502  SH010543         1.   
    SH010502  SH010545         1.   
    SH010502  SH010546         1.   
    SH010502  SH010549         1.   
    SH010502  SH010551         1.   
    SH010502  SH010552         1.   
    SH010502  SH010553         1.   
    SH010502  SH010555         1.   
    SH010502  SH010556         1.   
    SH010502  SH010557         1.   
    SH010502  SH010558         1.   
    SH010502  SH010559         1.   
    SH010502  SH010560         1.   
    SH010502  SH010563         1.   
    SH010502  SH010564         1.   
    SH010502  SH010571         1.   
    SH010502  SH010573         1.   
    SH010502  SH010577         1.   
    SH010502  SH010578         1.   
    SH010502  SH010582         1.   
    SH010502  SH010583         1.   
    SH010502  TRSH0501         1.   
    SH010602  SH010602        10.   
    SH010602  SH010603         1.   
    SH010602  SH010604         1.   
    SH010602  SH010605         1.   
    SH010602  SH010607         1.   
    SH010602  SH010608         1.   
    SH010602  SH010610         1.   
    SH010602  SH010614         1.   
    SH010602  SH010615         1.   
    SH010602  SH010616         1.   
    SH010602  SH010619         1.   
    SH010602  SH010627         1.   
    SH010602  SH010636         1.   
    SH010602  SH010637         1.   
    SH010602  SH010638         1.   
    SH010602  SH010640         1.   
    SH010602  SH010641         1.   
    SH010602  SH010643         1.   
    SH010602  SH010644         1.   
    SH010602  SH010645         1.   
    SH010602  SH010646         1.   
    SH010602  SH010653         1.   
    SH010602  SH010655         1.   
    SH010602  SH010658         1.   
    SH010602  SH010659         1.   
    SH010602  SH010660         1.   
    SH010602  SH010664         1.   
    SH010602  SH010671         1.   
    SH010602  SH010673         1.   
    SH010602  SH010683         1.   
    SH010602  TRSH0601         1.   
    SH010802  SH010802        10.   
    SH010802  SH010803         1.   
    SH010802  SH010804         1.   
    SH010802  SH010805         1.   
    SH010802  SH010807         1.   
    SH010802  SH010808         1.   
    SH010802  SH010810         1.   
    SH010802  SH010815         1.   
    SH010802  SH010816         1.   
    SH010802  SH010817         1.   
    SH010802  SH010819         1.   
    SH010802  SH010820         1.   
    SH010802  SH010821         1.   
    SH010802  SH010833         1.   
    SH010802  SH010834         1.   
    SH010802  SH010837         1.   
    SH010802  SH010838         1.   
    SH010802  SH010840         1.   
    SH010802  SH010843         1.   
    SH010802  SH010845         1.   
    SH010802  SH010846         1.   
    SH010802  SH010852         1.   
    SH010802  SH010853         1.   
    SH010802  SH010855         1.   
    SH010802  SH010858         1.   
    SH010802  SH010859         1.   
    SH010802  SH010860         1.   
    SH010802  SH010864         1.   
    SH010802  SH010871         1.   
    SH010802  SH010873         1.   
    SH010802  SH010877         1.   
    SH010802  SH010878         1.   
    SH010802  SH010882         1.   
    SH010802  TRSH0801         1.   
    SH010103  SH010103        10.   
    SH010103  SH010104         1.   
    SH010103  SH010105         1.   
    SH010103  SH010106         1.   
    SH010103  SH010107         1.   
    SH010103  SH010108         1.   
    SH010103  SH010109         1.   
    SH010103  SH010110         1.   
    SH010103  SH010111         1.   
    SH010103  SH010112         1.   
    SH010103  SH010114         1.   
    SH010103  SH010115         1.   
    SH010103  SH010116         1.   
    SH010103  SH010117         1.   
    SH010103  SH010119         1.   
    SH010103  SH010120         1.   
    SH010103  SH010121         1.   
    SH010103  SH010124         1.   
    SH010103  SH010128         1.   
    SH010103  SH010131         1.   
    SH010103  SH010133         1.   
    SH010103  SH010134         1.   
    SH010103  SH010137         1.   
    SH010103  SH010138         1.   
    SH010103  SH010139         1.   
    SH010103  SH010140         1.   
    SH010103  SH010142         1.   
    SH010103  SH010143         1.   
    SH010103  SH010145         1.   
    SH010103  SH010146         1.   
    SH010103  SH010147         1.   
    SH010103  SH010148         1.   
    SH010103  SH010149         1.   
    SH010103  SH010150         1.   
    SH010103  SH010151         1.   
    SH010103  SH010152         1.   
    SH010103  SH010153         1.   
    SH010103  SH010154         1.   
    SH010103  SH010155         1.   
    SH010103  SH010156         1.   
    SH010103  SH010157         1.   
    SH010103  SH010158         1.   
    SH010103  SH010159         1.   
    SH010103  SH010160         1.   
    SH010103  SH010163         1.   
    SH010103  SH010164         1.   
    SH010103  SH010171         1.   
    SH010103  SH010173         1.   
    SH010103  SH010177         1.   
    SH010103  SH010178         1.   
    SH010103  SH010182         1.   
    SH010103  SH010183         1.   
    SH010103  TRSH0101         1.   
    SH010203  SH010203        10.   
    SH010203  SH010204         1.   
    SH010203  SH010205         1.   
    SH010203  SH010207         1.   
    SH010203  SH010208         1.   
    SH010203  SH010210         1.   
    SH010203  SH010215         1.   
    SH010203  SH010216         1.   
    SH010203  SH010219         1.   
    SH010203  SH010220         1.   
    SH010203  SH010221         1.   
    SH010203  SH010225         1.   
    SH010203  SH010233         1.   
    SH010203  SH010234         1.   
    SH010203  SH010237         1.   
    SH010203  SH010238         1.   
    SH010203  SH010240         1.   
    SH010203  SH010243         1.   
    SH010203  SH010245         1.   
    SH010203  SH010246         1.   
    SH010203  SH010252         1.   
    SH010203  SH010253         1.   
    SH010203  SH010255         1.   
    SH010203  SH010258         1.   
    SH010203  SH010259         1.   
    SH010203  SH010260         1.   
    SH010203  SH010264         1.   
    SH010203  SH010265         1.   
    SH010203  SH010266         1.   
    SH010203  SH010267         1.   
    SH010203  SH010268         1.   
    SH010203  SH010269         1.   
    SH010203  SH010272         1.   
    SH010203  SH010273         1.   
    SH010203  SH010274         1.   
    SH010203  SH010275         1.   
    SH010203  SH010276         1.   
    SH010203  SH010277         1.   
    SH010203  SH010278         1.   
    SH010203  SH010279         1.   
    SH010203  SH010282         1.   
    SH010203  SH010283         1.   
    SH010203  SH010284         1.   
    SH010203  TRSH0201         1.   
    SH010403  SH010403        10.   
    SH010403  SH010405         1.   
    SH010403  SH010407         1.   
    SH010403  SH010408         1.   
    SH010403  SH010410         1.   
    SH010403  SH010415         1.   
    SH010403  SH010416         1.   
    SH010403  SH010418         1.   
    SH010403  SH010419         1.   
    SH010403  SH010420         1.   
    SH010403  SH010421         1.   
    SH010403  SH010422         1.   
    SH010403  SH010423         1.   
    SH010403  SH010426         1.   
    SH010403  SH010429         1.   
    SH010403  SH010430         1.   
    SH010403  SH010432         1.   
    SH010403  SH010433         1.   
    SH010403  SH010434         1.   
    SH010403  SH010435         1.   
    SH010403  SH010437         1.   
    SH010403  SH010438         1.   
    SH010403  SH010440         1.   
    SH010403  SH010443         1.   
    SH010403  SH010445         1.   
    SH010403  SH010446         1.   
    SH010403  SH010452         1.   
    SH010403  SH010453         1.   
    SH010403  SH010455         1.   
    SH010403  SH010458         1.   
    SH010403  SH010459         1.   
    SH010403  SH010460         1.   
    SH010403  SH010464         1.   
    SH010403  SH010471         1.   
    SH010403  SH010473         1.   
    SH010403  SH010477         1.   
    SH010403  SH010478         1.   
    SH010403  SH010480         1.   
    SH010403  SH010482         1.   
    SH010403  SH010483         1.   
    SH010403  TRSH0401         1.   
    SH010503  SH010503        10.   
    SH010503  SH010504         1.   
    SH010503  SH010507         1.   
    SH010503  SH010508         1.   
    SH010503  SH010510         1.   
    SH010503  SH010515         1.   
    SH010503  SH010516         1.   
    SH010503  SH010519         1.   
    SH010503  SH010520         1.   
    SH010503  SH010521         1.   
    SH010503  SH010528         1.   
    SH010503  SH010533         1.   
    SH010503  SH010534         1.   
    SH010503  SH010537         1.   
    SH010503  SH010538         1.   
    SH010503  SH010540         1.   
    SH010503  SH010543         1.   
    SH010503  SH010545         1.   
    SH010503  SH010546         1.   
    SH010503  SH010549         1.   
    SH010503  SH010551         1.   
    SH010503  SH010552         1.   
    SH010503  SH010553         1.   
    SH010503  SH010555         1.   
    SH010503  SH010556         1.   
    SH010503  SH010557         1.   
    SH010503  SH010558         1.   
    SH010503  SH010559         1.   
    SH010503  SH010560         1.   
    SH010503  SH010563         1.   
    SH010503  SH010564         1.   
    SH010503  SH010571         1.   
    SH010503  SH010573         1.   
    SH010503  SH010577         1.   
    SH010503  SH010578         1.   
    SH010503  SH010582         1.   
    SH010503  SH010583         1.   
    SH010503  TRSH0501         1.   
    SH010603  SH010603        10.   
    SH010603  SH010604         1.   
    SH010603  SH010605         1.   
    SH010603  SH010607         1.   
    SH010603  SH010608         1.   
    SH010603  SH010610         1.   
    SH010603  SH010614         1.   
    SH010603  SH010615         1.   
    SH010603  SH010616         1.   
    SH010603  SH010619         1.   
    SH010603  SH010627         1.   
    SH010603  SH010636         1.   
    SH010603  SH010637         1.   
    SH010603  SH010638         1.   
    SH010603  SH010640         1.   
    SH010603  SH010641         1.   
    SH010603  SH010643         1.   
    SH010603  SH010644         1.   
    SH010603  SH010645         1.   
    SH010603  SH010646         1.   
    SH010603  SH010653         1.   
    SH010603  SH010655         1.   
    SH010603  SH010658         1.   
    SH010603  SH010659         1.   
    SH010603  SH010660         1.   
    SH010603  SH010664         1.   
    SH010603  SH010671         1.   
    SH010603  SH010673         1.   
    SH010603  SH010683         1.   
    SH010603  TRSH0601         1.   
    SH010803  SH010803        10.   
    SH010803  SH010804         1.   
    SH010803  SH010805         1.   
    SH010803  SH010807         1.   
    SH010803  SH010808         1.   
    SH010803  SH010810         1.   
    SH010803  SH010815         1.   
    SH010803  SH010816         1.   
    SH010803  SH010817         1.   
    SH010803  SH010819         1.   
    SH010803  SH010820         1.   
    SH010803  SH010821         1.   
    SH010803  SH010833         1.   
    SH010803  SH010834         1.   
    SH010803  SH010837         1.   
    SH010803  SH010838         1.   
    SH010803  SH010840         1.   
    SH010803  SH010843         1.   
    SH010803  SH010845         1.   
    SH010803  SH010846         1.   
    SH010803  SH010852         1.   
    SH010803  SH010853         1.   
    SH010803  SH010855         1.   
    SH010803  SH010858         1.   
    SH010803  SH010859         1.   
    SH010803  SH010860         1.   
    SH010803  SH010864         1.   
    SH010803  SH010871         1.   
    SH010803  SH010873         1.   
    SH010803  SH010877         1.   
    SH010803  SH010878         1.   
    SH010803  SH010882         1.   
    SH010803  TRSH0801         1.   
    SH010104  SH010104        10.   
    SH010104  SH010105         1.   
    SH010104  SH010106         1.   
    SH010104  SH010107         1.   
    SH010104  SH010108         1.   
    SH010104  SH010109         1.   
    SH010104  SH010110         1.   
    SH010104  SH010111         1.   
    SH010104  SH010112         1.   
    SH010104  SH010114         1.   
    SH010104  SH010115         1.   
    SH010104  SH010116         1.   
    SH010104  SH010117         1.   
    SH010104  SH010119         1.   
    SH010104  SH010120         1.   
    SH010104  SH010121         1.   
    SH010104  SH010124         1.   
    SH010104  SH010128         1.   
    SH010104  SH010131         1.   
    SH010104  SH010133         1.   
    SH010104  SH010134         1.   
    SH010104  SH010137         1.   
    SH010104  SH010138         1.   
    SH010104  SH010139         1.   
    SH010104  SH010140         1.   
    SH010104  SH010142         1.   
    SH010104  SH010143         1.   
    SH010104  SH010145         1.   
    SH010104  SH010146         1.   
    SH010104  SH010147         1.   
    SH010104  SH010148         1.   
    SH010104  SH010149         1.   
    SH010104  SH010150         1.   
    SH010104  SH010151         1.   
    SH010104  SH010152         1.   
    SH010104  SH010153         1.   
    SH010104  SH010154         1.   
    SH010104  SH010155         1.   
    SH010104  SH010156         1.   
    SH010104  SH010157         1.   
    SH010104  SH010158         1.   
    SH010104  SH010159         1.   
    SH010104  SH010160         1.   
    SH010104  SH010163         1.   
    SH010104  SH010164         1.   
    SH010104  SH010171         1.   
    SH010104  SH010173         1.   
    SH010104  SH010177         1.   
    SH010104  SH010178         1.   
    SH010104  SH010182         1.   
    SH010104  SH010183         1.   
    SH010104  TRSH0101         1.   
    SH010204  SH010204        10.   
    SH010204  SH010205         1.   
    SH010204  SH010207         1.   
    SH010204  SH010208         1.   
    SH010204  SH010210         1.   
    SH010204  SH010215         1.   
    SH010204  SH010216         1.   
    SH010204  SH010219         1.   
    SH010204  SH010220         1.   
    SH010204  SH010221         1.   
    SH010204  SH010225         1.   
    SH010204  SH010233         1.   
    SH010204  SH010234         1.   
    SH010204  SH010237         1.   
    SH010204  SH010238         1.   
    SH010204  SH010240         1.   
    SH010204  SH010243         1.   
    SH010204  SH010245         1.   
    SH010204  SH010246         1.   
    SH010204  SH010252         1.   
    SH010204  SH010253         1.   
    SH010204  SH010255         1.   
    SH010204  SH010258         1.   
    SH010204  SH010259         1.   
    SH010204  SH010260         1.   
    SH010204  SH010264         1.   
    SH010204  SH010265         1.   
    SH010204  SH010266         1.   
    SH010204  SH010267         1.   
    SH010204  SH010268         1.   
    SH010204  SH010269         1.   
    SH010204  SH010272         1.   
    SH010204  SH010273         1.   
    SH010204  SH010274         1.   
    SH010204  SH010275         1.   
    SH010204  SH010276         1.   
    SH010204  SH010277         1.   
    SH010204  SH010278         1.   
    SH010204  SH010279         1.   
    SH010204  SH010282         1.   
    SH010204  SH010283         1.   
    SH010204  SH010284         1.   
    SH010204  TRSH0201         1.   
    SH010304  SH010304        10.   
    SH010304  SH010305         1.   
    SH010304  SH010307         1.   
    SH010304  SH010308         1.   
    SH010304  SH010310         1.   
    SH010304  SH010315         1.   
    SH010304  SH010316         1.   
    SH010304  SH010319         1.   
    SH010304  SH010320         1.   
    SH010304  SH010321         1.   
    SH010304  SH010333         1.   
    SH010304  SH010334         1.   
    SH010304  SH010337         1.   
    SH010304  SH010338         1.   
    SH010304  SH010340         1.   
    SH010304  SH010343         1.   
    SH010304  SH010345         1.   
    SH010304  SH010346         1.   
    SH010304  SH010352         1.   
    SH010304  SH010353         1.   
    SH010304  SH010355         1.   
    SH010304  SH010358         1.   
    SH010304  SH010359         1.   
    SH010304  SH010360         1.   
    SH010304  SH010364         1.   
    SH010304  SH010371         1.   
    SH010304  SH010373         1.   
    SH010304  SH010377         1.   
    SH010304  SH010378         1.   
    SH010304  SH010382         1.   
    SH010304  SH010383         1.   
    SH010304  TRSH0301         1.   
    SH010504  SH010504        10.   
    SH010504  SH010507         1.   
    SH010504  SH010508         1.   
    SH010504  SH010510         1.   
    SH010504  SH010515         1.   
    SH010504  SH010516         1.   
    SH010504  SH010519         1.   
    SH010504  SH010520         1.   
    SH010504  SH010521         1.   
    SH010504  SH010528         1.   
    SH010504  SH010533         1.   
    SH010504  SH010534         1.   
    SH010504  SH010537         1.   
    SH010504  SH010538         1.   
    SH010504  SH010540         1.   
    SH010504  SH010543         1.   
    SH010504  SH010545         1.   
    SH010504  SH010546         1.   
    SH010504  SH010549         1.   
    SH010504  SH010551         1.   
    SH010504  SH010552         1.   
    SH010504  SH010553         1.   
    SH010504  SH010555         1.   
    SH010504  SH010556         1.   
    SH010504  SH010557         1.   
    SH010504  SH010558         1.   
    SH010504  SH010559         1.   
    SH010504  SH010560         1.   
    SH010504  SH010563         1.   
    SH010504  SH010564         1.   
    SH010504  SH010571         1.   
    SH010504  SH010573         1.   
    SH010504  SH010577         1.   
    SH010504  SH010578         1.   
    SH010504  SH010582         1.   
    SH010504  SH010583         1.   
    SH010504  TRSH0501         1.   
    SH010604  SH010604        10.   
    SH010604  SH010605         1.   
    SH010604  SH010607         1.   
    SH010604  SH010608         1.   
    SH010604  SH010610         1.   
    SH010604  SH010614         1.   
    SH010604  SH010615         1.   
    SH010604  SH010616         1.   
    SH010604  SH010619         1.   
    SH010604  SH010627         1.   
    SH010604  SH010636         1.   
    SH010604  SH010637         1.   
    SH010604  SH010638         1.   
    SH010604  SH010640         1.   
    SH010604  SH010641         1.   
    SH010604  SH010643         1.   
    SH010604  SH010644         1.   
    SH010604  SH010645         1.   
    SH010604  SH010646         1.   
    SH010604  SH010653         1.   
    SH010604  SH010655         1.   
    SH010604  SH010658         1.   
    SH010604  SH010659         1.   
    SH010604  SH010660         1.   
    SH010604  SH010664         1.   
    SH010604  SH010671         1.   
    SH010604  SH010673         1.   
    SH010604  SH010683         1.   
    SH010604  TRSH0601         1.   
    SH010804  SH010804        10.   
    SH010804  SH010805         1.   
    SH010804  SH010807         1.   
    SH010804  SH010808         1.   
    SH010804  SH010810         1.   
    SH010804  SH010815         1.   
    SH010804  SH010816         1.   
    SH010804  SH010817         1.   
    SH010804  SH010819         1.   
    SH010804  SH010820         1.   
    SH010804  SH010821         1.   
    SH010804  SH010833         1.   
    SH010804  SH010834         1.   
    SH010804  SH010837         1.   
    SH010804  SH010838         1.   
    SH010804  SH010840         1.   
    SH010804  SH010843         1.   
    SH010804  SH010845         1.   
    SH010804  SH010846         1.   
    SH010804  SH010852         1.   
    SH010804  SH010853         1.   
    SH010804  SH010855         1.   
    SH010804  SH010858         1.   
    SH010804  SH010859         1.   
    SH010804  SH010860         1.   
    SH010804  SH010864         1.   
    SH010804  SH010871         1.   
    SH010804  SH010873         1.   
    SH010804  SH010877         1.   
    SH010804  SH010878         1.   
    SH010804  SH010882         1.   
    SH010804  TRSH0801         1.   
    SH010105  SH010105        10.   
    SH010105  SH010106         1.   
    SH010105  SH010107         1.   
    SH010105  SH010108         1.   
    SH010105  SH010109         1.   
    SH010105  SH010110         1.   
    SH010105  SH010111         1.   
    SH010105  SH010112         1.   
    SH010105  SH010114         1.   
    SH010105  SH010115         1.   
    SH010105  SH010116         1.   
    SH010105  SH010117         1.   
    SH010105  SH010119         1.   
    SH010105  SH010120         1.   
    SH010105  SH010121         1.   
    SH010105  SH010124         1.   
    SH010105  SH010128         1.   
    SH010105  SH010131         1.   
    SH010105  SH010133         1.   
    SH010105  SH010134         1.   
    SH010105  SH010137         1.   
    SH010105  SH010138         1.   
    SH010105  SH010139         1.   
    SH010105  SH010140         1.   
    SH010105  SH010142         1.   
    SH010105  SH010143         1.   
    SH010105  SH010145         1.   
    SH010105  SH010146         1.   
    SH010105  SH010147         1.   
    SH010105  SH010148         1.   
    SH010105  SH010149         1.   
    SH010105  SH010150         1.   
    SH010105  SH010151         1.   
    SH010105  SH010152         1.   
    SH010105  SH010153         1.   
    SH010105  SH010154         1.   
    SH010105  SH010155         1.   
    SH010105  SH010156         1.   
    SH010105  SH010157         1.   
    SH010105  SH010158         1.   
    SH010105  SH010159         1.   
    SH010105  SH010160         1.   
    SH010105  SH010163         1.   
    SH010105  SH010164         1.   
    SH010105  SH010171         1.   
    SH010105  SH010173         1.   
    SH010105  SH010177         1.   
    SH010105  SH010178         1.   
    SH010105  SH010182         1.   
    SH010105  SH010183         1.   
    SH010105  TRSH0101         1.   
    SH010205  SH010205        10.   
    SH010205  SH010207         1.   
    SH010205  SH010208         1.   
    SH010205  SH010210         1.   
    SH010205  SH010215         1.   
    SH010205  SH010216         1.   
    SH010205  SH010219         1.   
    SH010205  SH010220         1.   
    SH010205  SH010221         1.   
    SH010205  SH010225         1.   
    SH010205  SH010233         1.   
    SH010205  SH010234         1.   
    SH010205  SH010237         1.   
    SH010205  SH010238         1.   
    SH010205  SH010240         1.   
    SH010205  SH010243         1.   
    SH010205  SH010245         1.   
    SH010205  SH010246         1.   
    SH010205  SH010252         1.   
    SH010205  SH010253         1.   
    SH010205  SH010255         1.   
    SH010205  SH010258         1.   
    SH010205  SH010259         1.   
    SH010205  SH010260         1.   
    SH010205  SH010264         1.   
    SH010205  SH010265         1.   
    SH010205  SH010266         1.   
    SH010205  SH010267         1.   
    SH010205  SH010268         1.   
    SH010205  SH010269         1.   
    SH010205  SH010272         1.   
    SH010205  SH010273         1.   
    SH010205  SH010274         1.   
    SH010205  SH010275         1.   
    SH010205  SH010276         1.   
    SH010205  SH010277         1.   
    SH010205  SH010278         1.   
    SH010205  SH010279         1.   
    SH010205  SH010282         1.   
    SH010205  SH010283         1.   
    SH010205  SH010284         1.   
    SH010205  TRSH0201         1.   
    SH010305  SH010305        10.   
    SH010305  SH010307         1.   
    SH010305  SH010308         1.   
    SH010305  SH010310         1.   
    SH010305  SH010315         1.   
    SH010305  SH010316         1.   
    SH010305  SH010319         1.   
    SH010305  SH010320         1.   
    SH010305  SH010321         1.   
    SH010305  SH010333         1.   
    SH010305  SH010334         1.   
    SH010305  SH010337         1.   
    SH010305  SH010338         1.   
    SH010305  SH010340         1.   
    SH010305  SH010343         1.   
    SH010305  SH010345         1.   
    SH010305  SH010346         1.   
    SH010305  SH010352         1.   
    SH010305  SH010353         1.   
    SH010305  SH010355         1.   
    SH010305  SH010358         1.   
    SH010305  SH010359         1.   
    SH010305  SH010360         1.   
    SH010305  SH010364         1.   
    SH010305  SH010371         1.   
    SH010305  SH010373         1.   
    SH010305  SH010377         1.   
    SH010305  SH010378         1.   
    SH010305  SH010382         1.   
    SH010305  SH010383         1.   
    SH010305  TRSH0301         1.   
    SH010405  SH010405        10.   
    SH010405  SH010407         1.   
    SH010405  SH010408         1.   
    SH010405  SH010410         1.   
    SH010405  SH010415         1.   
    SH010405  SH010416         1.   
    SH010405  SH010418         1.   
    SH010405  SH010419         1.   
    SH010405  SH010420         1.   
    SH010405  SH010421         1.   
    SH010405  SH010422         1.   
    SH010405  SH010423         1.   
    SH010405  SH010426         1.   
    SH010405  SH010429         1.   
    SH010405  SH010430         1.   
    SH010405  SH010432         1.   
    SH010405  SH010433         1.   
    SH010405  SH010434         1.   
    SH010405  SH010435         1.   
    SH010405  SH010437         1.   
    SH010405  SH010438         1.   
    SH010405  SH010440         1.   
    SH010405  SH010443         1.   
    SH010405  SH010445         1.   
    SH010405  SH010446         1.   
    SH010405  SH010452         1.   
    SH010405  SH010453         1.   
    SH010405  SH010455         1.   
    SH010405  SH010458         1.   
    SH010405  SH010459         1.   
    SH010405  SH010460         1.   
    SH010405  SH010464         1.   
    SH010405  SH010471         1.   
    SH010405  SH010473         1.   
    SH010405  SH010477         1.   
    SH010405  SH010478         1.   
    SH010405  SH010480         1.   
    SH010405  SH010482         1.   
    SH010405  SH010483         1.   
    SH010405  TRSH0401         1.   
    SH010605  SH010605        10.   
    SH010605  SH010607         1.   
    SH010605  SH010608         1.   
    SH010605  SH010610         1.   
    SH010605  SH010614         1.   
    SH010605  SH010615         1.   
    SH010605  SH010616         1.   
    SH010605  SH010619         1.   
    SH010605  SH010627         1.   
    SH010605  SH010636         1.   
    SH010605  SH010637         1.   
    SH010605  SH010638         1.   
    SH010605  SH010640         1.   
    SH010605  SH010641         1.   
    SH010605  SH010643         1.   
    SH010605  SH010644         1.   
    SH010605  SH010645         1.   
    SH010605  SH010646         1.   
    SH010605  SH010653         1.   
    SH010605  SH010655         1.   
    SH010605  SH010658         1.   
    SH010605  SH010659         1.   
    SH010605  SH010660         1.   
    SH010605  SH010664         1.   
    SH010605  SH010671         1.   
    SH010605  SH010673         1.   
    SH010605  SH010683         1.   
    SH010605  TRSH0601         1.   
    SH010705  SH010705        10.   
    SH010705  SH010707         1.   
    SH010705  SH010738         1.   
    SH010705  SH010743         1.   
    SH010705  SH010745         1.   
    SH010705  SH010753         1.   
    SH010705  SH010755         1.   
    SH010705  SH010758         1.   
    SH010705  SH010759         1.   
    SH010705  SH010760         1.   
    SH010705  SH010771         1.   
    SH010705  TRSH0701         1.   
    SH010805  SH010805        10.   
    SH010805  SH010807         1.   
    SH010805  SH010808         1.   
    SH010805  SH010810         1.   
    SH010805  SH010815         1.   
    SH010805  SH010816         1.   
    SH010805  SH010817         1.   
    SH010805  SH010819         1.   
    SH010805  SH010820         1.   
    SH010805  SH010821         1.   
    SH010805  SH010833         1.   
    SH010805  SH010834         1.   
    SH010805  SH010837         1.   
    SH010805  SH010838         1.   
    SH010805  SH010840         1.   
    SH010805  SH010843         1.   
    SH010805  SH010845         1.   
    SH010805  SH010846         1.   
    SH010805  SH010852         1.   
    SH010805  SH010853         1.   
    SH010805  SH010855         1.   
    SH010805  SH010858         1.   
    SH010805  SH010859         1.   
    SH010805  SH010860         1.   
    SH010805  SH010864         1.   
    SH010805  SH010871         1.   
    SH010805  SH010873         1.   
    SH010805  SH010877         1.   
    SH010805  SH010878         1.   
    SH010805  SH010882         1.   
    SH010805  TRSH0801         1.   
    SH010106  SH010106        10.   
    SH010106  SH010107         1.   
    SH010106  SH010108         1.   
    SH010106  SH010109         1.   
    SH010106  SH010110         1.   
    SH010106  SH010111         1.   
    SH010106  SH010112         1.   
    SH010106  SH010114         1.   
    SH010106  SH010115         1.   
    SH010106  SH010116         1.   
    SH010106  SH010117         1.   
    SH010106  SH010119         1.   
    SH010106  SH010120         1.   
    SH010106  SH010121         1.   
    SH010106  SH010124         1.   
    SH010106  SH010128         1.   
    SH010106  SH010131         1.   
    SH010106  SH010133         1.   
    SH010106  SH010134         1.   
    SH010106  SH010137         1.   
    SH010106  SH010138         1.   
    SH010106  SH010139         1.   
    SH010106  SH010140         1.   
    SH010106  SH010142         1.   
    SH010106  SH010143         1.   
    SH010106  SH010145         1.   
    SH010106  SH010146         1.   
    SH010106  SH010147         1.   
    SH010106  SH010148         1.   
    SH010106  SH010149         1.   
    SH010106  SH010150         1.   
    SH010106  SH010151         1.   
    SH010106  SH010152         1.   
    SH010106  SH010153         1.   
    SH010106  SH010154         1.   
    SH010106  SH010155         1.   
    SH010106  SH010156         1.   
    SH010106  SH010157         1.   
    SH010106  SH010158         1.   
    SH010106  SH010159         1.   
    SH010106  SH010160         1.   
    SH010106  SH010163         1.   
    SH010106  SH010164         1.   
    SH010106  SH010171         1.   
    SH010106  SH010173         1.   
    SH010106  SH010177         1.   
    SH010106  SH010178         1.   
    SH010106  SH010182         1.   
    SH010106  SH010183         1.   
    SH010106  TRSH0101         1.   
    SH010107  SH010107        10.   
    SH010107  SH010108         1.   
    SH010107  SH010109         1.   
    SH010107  SH010110         1.   
    SH010107  SH010111         1.   
    SH010107  SH010112         1.   
    SH010107  SH010114         1.   
    SH010107  SH010115         1.   
    SH010107  SH010116         1.   
    SH010107  SH010117         1.   
    SH010107  SH010119         1.   
    SH010107  SH010120         1.   
    SH010107  SH010121         1.   
    SH010107  SH010124         1.   
    SH010107  SH010128         1.   
    SH010107  SH010131         1.   
    SH010107  SH010133         1.   
    SH010107  SH010134         1.   
    SH010107  SH010137         1.   
    SH010107  SH010138         1.   
    SH010107  SH010139         1.   
    SH010107  SH010140         1.   
    SH010107  SH010142         1.   
    SH010107  SH010143         1.   
    SH010107  SH010145         1.   
    SH010107  SH010146         1.   
    SH010107  SH010147         1.   
    SH010107  SH010148         1.   
    SH010107  SH010149         1.   
    SH010107  SH010150         1.   
    SH010107  SH010151         1.   
    SH010107  SH010152         1.   
    SH010107  SH010153         1.   
    SH010107  SH010154         1.   
    SH010107  SH010155         1.   
    SH010107  SH010156         1.   
    SH010107  SH010157         1.   
    SH010107  SH010158         1.   
    SH010107  SH010159         1.   
    SH010107  SH010160         1.   
    SH010107  SH010163         1.   
    SH010107  SH010164         1.   
    SH010107  SH010171         1.   
    SH010107  SH010173         1.   
    SH010107  SH010177         1.   
    SH010107  SH010178         1.   
    SH010107  SH010182         1.   
    SH010107  SH010183         1.   
    SH010107  TRSH0101         1.   
    SH010207  SH010207        10.   
    SH010207  SH010208         1.   
    SH010207  SH010210         1.   
    SH010207  SH010215         1.   
    SH010207  SH010216         1.   
    SH010207  SH010219         1.   
    SH010207  SH010220         1.   
    SH010207  SH010221         1.   
    SH010207  SH010225         1.   
    SH010207  SH010233         1.   
    SH010207  SH010234         1.   
    SH010207  SH010237         1.   
    SH010207  SH010238         1.   
    SH010207  SH010240         1.   
    SH010207  SH010243         1.   
    SH010207  SH010245         1.   
    SH010207  SH010246         1.   
    SH010207  SH010252         1.   
    SH010207  SH010253         1.   
    SH010207  SH010255         1.   
    SH010207  SH010258         1.   
    SH010207  SH010259         1.   
    SH010207  SH010260         1.   
    SH010207  SH010264         1.   
    SH010207  SH010265         1.   
    SH010207  SH010266         1.   
    SH010207  SH010267         1.   
    SH010207  SH010268         1.   
    SH010207  SH010269         1.   
    SH010207  SH010272         1.   
    SH010207  SH010273         1.   
    SH010207  SH010274         1.   
    SH010207  SH010275         1.   
    SH010207  SH010276         1.   
    SH010207  SH010277         1.   
    SH010207  SH010278         1.   
    SH010207  SH010279         1.   
    SH010207  SH010282         1.   
    SH010207  SH010283         1.   
    SH010207  SH010284         1.   
    SH010207  TRSH0201         1.   
    SH010307  SH010307        10.   
    SH010307  SH010308         1.   
    SH010307  SH010310         1.   
    SH010307  SH010315         1.   
    SH010307  SH010316         1.   
    SH010307  SH010319         1.   
    SH010307  SH010320         1.   
    SH010307  SH010321         1.   
    SH010307  SH010333         1.   
    SH010307  SH010334         1.   
    SH010307  SH010337         1.   
    SH010307  SH010338         1.   
    SH010307  SH010340         1.   
    SH010307  SH010343         1.   
    SH010307  SH010345         1.   
    SH010307  SH010346         1.   
    SH010307  SH010352         1.   
    SH010307  SH010353         1.   
    SH010307  SH010355         1.   
    SH010307  SH010358         1.   
    SH010307  SH010359         1.   
    SH010307  SH010360         1.   
    SH010307  SH010364         1.   
    SH010307  SH010371         1.   
    SH010307  SH010373         1.   
    SH010307  SH010377         1.   
    SH010307  SH010378         1.   
    SH010307  SH010382         1.   
    SH010307  SH010383         1.   
    SH010307  TRSH0301         1.   
    SH010407  SH010407        10.   
    SH010407  SH010408         1.   
    SH010407  SH010410         1.   
    SH010407  SH010415         1.   
    SH010407  SH010416         1.   
    SH010407  SH010418         1.   
    SH010407  SH010419         1.   
    SH010407  SH010420         1.   
    SH010407  SH010421         1.   
    SH010407  SH010422         1.   
    SH010407  SH010423         1.   
    SH010407  SH010426         1.   
    SH010407  SH010429         1.   
    SH010407  SH010430         1.   
    SH010407  SH010432         1.   
    SH010407  SH010433         1.   
    SH010407  SH010434         1.   
    SH010407  SH010435         1.   
    SH010407  SH010437         1.   
    SH010407  SH010438         1.   
    SH010407  SH010440         1.   
    SH010407  SH010443         1.   
    SH010407  SH010445         1.   
    SH010407  SH010446         1.   
    SH010407  SH010452         1.   
    SH010407  SH010453         1.   
    SH010407  SH010455         1.   
    SH010407  SH010458         1.   
    SH010407  SH010459         1.   
    SH010407  SH010460         1.   
    SH010407  SH010464         1.   
    SH010407  SH010471         1.   
    SH010407  SH010473         1.   
    SH010407  SH010477         1.   
    SH010407  SH010478         1.   
    SH010407  SH010480         1.   
    SH010407  SH010482         1.   
    SH010407  SH010483         1.   
    SH010407  TRSH0401         1.   
    SH010507  SH010507        10.   
    SH010507  SH010508         1.   
    SH010507  SH010510         1.   
    SH010507  SH010515         1.   
    SH010507  SH010516         1.   
    SH010507  SH010519         1.   
    SH010507  SH010520         1.   
    SH010507  SH010521         1.   
    SH010507  SH010528         1.   
    SH010507  SH010533         1.   
    SH010507  SH010534         1.   
    SH010507  SH010537         1.   
    SH010507  SH010538         1.   
    SH010507  SH010540         1.   
    SH010507  SH010543         1.   
    SH010507  SH010545         1.   
    SH010507  SH010546         1.   
    SH010507  SH010549         1.   
    SH010507  SH010551         1.   
    SH010507  SH010552         1.   
    SH010507  SH010553         1.   
    SH010507  SH010555         1.   
    SH010507  SH010556         1.   
    SH010507  SH010557         1.   
    SH010507  SH010558         1.   
    SH010507  SH010559         1.   
    SH010507  SH010560         1.   
    SH010507  SH010563         1.   
    SH010507  SH010564         1.   
    SH010507  SH010571         1.   
    SH010507  SH010573         1.   
    SH010507  SH010577         1.   
    SH010507  SH010578         1.   
    SH010507  SH010582         1.   
    SH010507  SH010583         1.   
    SH010507  TRSH0501         1.   
    SH010607  SH010607        10.   
    SH010607  SH010608         1.   
    SH010607  SH010610         1.   
    SH010607  SH010614         1.   
    SH010607  SH010615         1.   
    SH010607  SH010616         1.   
    SH010607  SH010619         1.   
    SH010607  SH010627         1.   
    SH010607  SH010636         1.   
    SH010607  SH010637         1.   
    SH010607  SH010638         1.   
    SH010607  SH010640         1.   
    SH010607  SH010641         1.   
    SH010607  SH010643         1.   
    SH010607  SH010644         1.   
    SH010607  SH010645         1.   
    SH010607  SH010646         1.   
    SH010607  SH010653         1.   
    SH010607  SH010655         1.   
    SH010607  SH010658         1.   
    SH010607  SH010659         1.   
    SH010607  SH010660         1.   
    SH010607  SH010664         1.   
    SH010607  SH010671         1.   
    SH010607  SH010673         1.   
    SH010607  SH010683         1.   
    SH010607  TRSH0601         1.   
    SH010707  SH010707        10.   
    SH010707  SH010738         1.   
    SH010707  SH010743         1.   
    SH010707  SH010745         1.   
    SH010707  SH010753         1.   
    SH010707  SH010755         1.   
    SH010707  SH010758         1.   
    SH010707  SH010759         1.   
    SH010707  SH010760         1.   
    SH010707  SH010771         1.   
    SH010707  TRSH0701         1.   
    SH010807  SH010807        10.   
    SH010807  SH010808         1.   
    SH010807  SH010810         1.   
    SH010807  SH010815         1.   
    SH010807  SH010816         1.   
    SH010807  SH010817         1.   
    SH010807  SH010819         1.   
    SH010807  SH010820         1.   
    SH010807  SH010821         1.   
    SH010807  SH010833         1.   
    SH010807  SH010834         1.   
    SH010807  SH010837         1.   
    SH010807  SH010838         1.   
    SH010807  SH010840         1.   
    SH010807  SH010843         1.   
    SH010807  SH010845         1.   
    SH010807  SH010846         1.   
    SH010807  SH010852         1.   
    SH010807  SH010853         1.   
    SH010807  SH010855         1.   
    SH010807  SH010858         1.   
    SH010807  SH010859         1.   
    SH010807  SH010860         1.   
    SH010807  SH010864         1.   
    SH010807  SH010871         1.   
    SH010807  SH010873         1.   
    SH010807  SH010877         1.   
    SH010807  SH010878         1.   
    SH010807  SH010882         1.   
    SH010807  TRSH0801         1.   
    SH010108  SH010108        10.   
    SH010108  SH010109         1.   
    SH010108  SH010110         1.   
    SH010108  SH010111         1.   
    SH010108  SH010112         1.   
    SH010108  SH010114         1.   
    SH010108  SH010115         1.   
    SH010108  SH010116         1.   
    SH010108  SH010117         1.   
    SH010108  SH010119         1.   
    SH010108  SH010120         1.   
    SH010108  SH010121         1.   
    SH010108  SH010124         1.   
    SH010108  SH010128         1.   
    SH010108  SH010131         1.   
    SH010108  SH010133         1.   
    SH010108  SH010134         1.   
    SH010108  SH010137         1.   
    SH010108  SH010138         1.   
    SH010108  SH010139         1.   
    SH010108  SH010140         1.   
    SH010108  SH010142         1.   
    SH010108  SH010143         1.   
    SH010108  SH010145         1.   
    SH010108  SH010146         1.   
    SH010108  SH010147         1.   
    SH010108  SH010148         1.   
    SH010108  SH010149         1.   
    SH010108  SH010150         1.   
    SH010108  SH010151         1.   
    SH010108  SH010152         1.   
    SH010108  SH010153         1.   
    SH010108  SH010154         1.   
    SH010108  SH010155         1.   
    SH010108  SH010156         1.   
    SH010108  SH010157         1.   
    SH010108  SH010158         1.   
    SH010108  SH010159         1.   
    SH010108  SH010160         1.   
    SH010108  SH010163         1.   
    SH010108  SH010164         1.   
    SH010108  SH010171         1.   
    SH010108  SH010173         1.   
    SH010108  SH010177         1.   
    SH010108  SH010178         1.   
    SH010108  SH010182         1.   
    SH010108  SH010183         1.   
    SH010108  TRSH0101         1.   
    SH010208  SH010208        10.   
    SH010208  SH010210         1.   
    SH010208  SH010215         1.   
    SH010208  SH010216         1.   
    SH010208  SH010219         1.   
    SH010208  SH010220         1.   
    SH010208  SH010221         1.   
    SH010208  SH010225         1.   
    SH010208  SH010233         1.   
    SH010208  SH010234         1.   
    SH010208  SH010237         1.   
    SH010208  SH010238         1.   
    SH010208  SH010240         1.   
    SH010208  SH010243         1.   
    SH010208  SH010245         1.   
    SH010208  SH010246         1.   
    SH010208  SH010252         1.   
    SH010208  SH010253         1.   
    SH010208  SH010255         1.   
    SH010208  SH010258         1.   
    SH010208  SH010259         1.   
    SH010208  SH010260         1.   
    SH010208  SH010264         1.   
    SH010208  SH010265         1.   
    SH010208  SH010266         1.   
    SH010208  SH010267         1.   
    SH010208  SH010268         1.   
    SH010208  SH010269         1.   
    SH010208  SH010272         1.   
    SH010208  SH010273         1.   
    SH010208  SH010274         1.   
    SH010208  SH010275         1.   
    SH010208  SH010276         1.   
    SH010208  SH010277         1.   
    SH010208  SH010278         1.   
    SH010208  SH010279         1.   
    SH010208  SH010282         1.   
    SH010208  SH010283         1.   
    SH010208  SH010284         1.   
    SH010208  TRSH0201         1.   
    SH010308  SH010308        10.   
    SH010308  SH010310         1.   
    SH010308  SH010315         1.   
    SH010308  SH010316         1.   
    SH010308  SH010319         1.   
    SH010308  SH010320         1.   
    SH010308  SH010321         1.   
    SH010308  SH010333         1.   
    SH010308  SH010334         1.   
    SH010308  SH010337         1.   
    SH010308  SH010338         1.   
    SH010308  SH010340         1.   
    SH010308  SH010343         1.   
    SH010308  SH010345         1.   
    SH010308  SH010346         1.   
    SH010308  SH010352         1.   
    SH010308  SH010353         1.   
    SH010308  SH010355         1.   
    SH010308  SH010358         1.   
    SH010308  SH010359         1.   
    SH010308  SH010360         1.   
    SH010308  SH010364         1.   
    SH010308  SH010371         1.   
    SH010308  SH010373         1.   
    SH010308  SH010377         1.   
    SH010308  SH010378         1.   
    SH010308  SH010382         1.   
    SH010308  SH010383         1.   
    SH010308  TRSH0301         1.   
    SH010408  SH010408        10.   
    SH010408  SH010410         1.   
    SH010408  SH010415         1.   
    SH010408  SH010416         1.   
    SH010408  SH010418         1.   
    SH010408  SH010419         1.   
    SH010408  SH010420         1.   
    SH010408  SH010421         1.   
    SH010408  SH010422         1.   
    SH010408  SH010423         1.   
    SH010408  SH010426         1.   
    SH010408  SH010429         1.   
    SH010408  SH010430         1.   
    SH010408  SH010432         1.   
    SH010408  SH010433         1.   
    SH010408  SH010434         1.   
    SH010408  SH010435         1.   
    SH010408  SH010437         1.   
    SH010408  SH010438         1.   
    SH010408  SH010440         1.   
    SH010408  SH010443         1.   
    SH010408  SH010445         1.   
    SH010408  SH010446         1.   
    SH010408  SH010452         1.   
    SH010408  SH010453         1.   
    SH010408  SH010455         1.   
    SH010408  SH010458         1.   
    SH010408  SH010459         1.   
    SH010408  SH010460         1.   
    SH010408  SH010464         1.   
    SH010408  SH010471         1.   
    SH010408  SH010473         1.   
    SH010408  SH010477         1.   
    SH010408  SH010478         1.   
    SH010408  SH010480         1.   
    SH010408  SH010482         1.   
    SH010408  SH010483         1.   
    SH010408  TRSH0401         1.   
    SH010508  SH010508        10.   
    SH010508  SH010510         1.   
    SH010508  SH010515         1.   
    SH010508  SH010516         1.   
    SH010508  SH010519         1.   
    SH010508  SH010520         1.   
    SH010508  SH010521         1.   
    SH010508  SH010528         1.   
    SH010508  SH010533         1.   
    SH010508  SH010534         1.   
    SH010508  SH010537         1.   
    SH010508  SH010538         1.   
    SH010508  SH010540         1.   
    SH010508  SH010543         1.   
    SH010508  SH010545         1.   
    SH010508  SH010546         1.   
    SH010508  SH010549         1.   
    SH010508  SH010551         1.   
    SH010508  SH010552         1.   
    SH010508  SH010553         1.   
    SH010508  SH010555         1.   
    SH010508  SH010556         1.   
    SH010508  SH010557         1.   
    SH010508  SH010558         1.   
    SH010508  SH010559         1.   
    SH010508  SH010560         1.   
    SH010508  SH010563         1.   
    SH010508  SH010564         1.   
    SH010508  SH010571         1.   
    SH010508  SH010573         1.   
    SH010508  SH010577         1.   
    SH010508  SH010578         1.   
    SH010508  SH010582         1.   
    SH010508  SH010583         1.   
    SH010508  TRSH0501         1.   
    SH010608  SH010608        10.   
    SH010608  SH010610         1.   
    SH010608  SH010614         1.   
    SH010608  SH010615         1.   
    SH010608  SH010616         1.   
    SH010608  SH010619         1.   
    SH010608  SH010627         1.   
    SH010608  SH010636         1.   
    SH010608  SH010637         1.   
    SH010608  SH010638         1.   
    SH010608  SH010640         1.   
    SH010608  SH010641         1.   
    SH010608  SH010643         1.   
    SH010608  SH010644         1.   
    SH010608  SH010645         1.   
    SH010608  SH010646         1.   
    SH010608  SH010653         1.   
    SH010608  SH010655         1.   
    SH010608  SH010658         1.   
    SH010608  SH010659         1.   
    SH010608  SH010660         1.   
    SH010608  SH010664         1.   
    SH010608  SH010671         1.   
    SH010608  SH010673         1.   
    SH010608  SH010683         1.   
    SH010608  TRSH0601         1.   
    SH010808  SH010808        10.   
    SH010808  SH010810         1.   
    SH010808  SH010815         1.   
    SH010808  SH010816         1.   
    SH010808  SH010817         1.   
    SH010808  SH010819         1.   
    SH010808  SH010820         1.   
    SH010808  SH010821         1.   
    SH010808  SH010833         1.   
    SH010808  SH010834         1.   
    SH010808  SH010837         1.   
    SH010808  SH010838         1.   
    SH010808  SH010840         1.   
    SH010808  SH010843         1.   
    SH010808  SH010845         1.   
    SH010808  SH010846         1.   
    SH010808  SH010852         1.   
    SH010808  SH010853         1.   
    SH010808  SH010855         1.   
    SH010808  SH010858         1.   
    SH010808  SH010859         1.   
    SH010808  SH010860         1.   
    SH010808  SH010864         1.   
    SH010808  SH010871         1.   
    SH010808  SH010873         1.   
    SH010808  SH010877         1.   
    SH010808  SH010878         1.   
    SH010808  SH010882         1.   
    SH010808  TRSH0801         1.   
    SH010109  SH010109        10.   
    SH010109  SH010110         1.   
    SH010109  SH010111         1.   
    SH010109  SH010112         1.   
    SH010109  SH010114         1.   
    SH010109  SH010115         1.   
    SH010109  SH010116         1.   
    SH010109  SH010117         1.   
    SH010109  SH010119         1.   
    SH010109  SH010120         1.   
    SH010109  SH010121         1.   
    SH010109  SH010124         1.   
    SH010109  SH010128         1.   
    SH010109  SH010131         1.   
    SH010109  SH010133         1.   
    SH010109  SH010134         1.   
    SH010109  SH010137         1.   
    SH010109  SH010138         1.   
    SH010109  SH010139         1.   
    SH010109  SH010140         1.   
    SH010109  SH010142         1.   
    SH010109  SH010143         1.   
    SH010109  SH010145         1.   
    SH010109  SH010146         1.   
    SH010109  SH010147         1.   
    SH010109  SH010148         1.   
    SH010109  SH010149         1.   
    SH010109  SH010150         1.   
    SH010109  SH010151         1.   
    SH010109  SH010152         1.   
    SH010109  SH010153         1.   
    SH010109  SH010154         1.   
    SH010109  SH010155         1.   
    SH010109  SH010156         1.   
    SH010109  SH010157         1.   
    SH010109  SH010158         1.   
    SH010109  SH010159         1.   
    SH010109  SH010160         1.   
    SH010109  SH010163         1.   
    SH010109  SH010164         1.   
    SH010109  SH010171         1.   
    SH010109  SH010173         1.   
    SH010109  SH010177         1.   
    SH010109  SH010178         1.   
    SH010109  SH010182         1.   
    SH010109  SH010183         1.   
    SH010109  TRSH0101         1.   
    SH010110  SH010110        10.   
    SH010110  SH010111         1.   
    SH010110  SH010112         1.   
    SH010110  SH010114         1.   
    SH010110  SH010115         1.   
    SH010110  SH010116         1.   
    SH010110  SH010117         1.   
    SH010110  SH010119         1.   
    SH010110  SH010120         1.   
    SH010110  SH010121         1.   
    SH010110  SH010124         1.   
    SH010110  SH010128         1.   
    SH010110  SH010131         1.   
    SH010110  SH010133         1.   
    SH010110  SH010134         1.   
    SH010110  SH010137         1.   
    SH010110  SH010138         1.   
    SH010110  SH010139         1.   
    SH010110  SH010140         1.   
    SH010110  SH010142         1.   
    SH010110  SH010143         1.   
    SH010110  SH010145         1.   
    SH010110  SH010146         1.   
    SH010110  SH010147         1.   
    SH010110  SH010148         1.   
    SH010110  SH010149         1.   
    SH010110  SH010150         1.   
    SH010110  SH010151         1.   
    SH010110  SH010152         1.   
    SH010110  SH010153         1.   
    SH010110  SH010154         1.   
    SH010110  SH010155         1.   
    SH010110  SH010156         1.   
    SH010110  SH010157         1.   
    SH010110  SH010158         1.   
    SH010110  SH010159         1.   
    SH010110  SH010160         1.   
    SH010110  SH010163         1.   
    SH010110  SH010164         1.   
    SH010110  SH010171         1.   
    SH010110  SH010173         1.   
    SH010110  SH010177         1.   
    SH010110  SH010178         1.   
    SH010110  SH010182         1.   
    SH010110  SH010183         1.   
    SH010110  TRSH0101         1.   
    SH010210  SH010210        10.   
    SH010210  SH010215         1.   
    SH010210  SH010216         1.   
    SH010210  SH010219         1.   
    SH010210  SH010220         1.   
    SH010210  SH010221         1.   
    SH010210  SH010225         1.   
    SH010210  SH010233         1.   
    SH010210  SH010234         1.   
    SH010210  SH010237         1.   
    SH010210  SH010238         1.   
    SH010210  SH010240         1.   
    SH010210  SH010243         1.   
    SH010210  SH010245         1.   
    SH010210  SH010246         1.   
    SH010210  SH010252         1.   
    SH010210  SH010253         1.   
    SH010210  SH010255         1.   
    SH010210  SH010258         1.   
    SH010210  SH010259         1.   
    SH010210  SH010260         1.   
    SH010210  SH010264         1.   
    SH010210  SH010265         1.   
    SH010210  SH010266         1.   
    SH010210  SH010267         1.   
    SH010210  SH010268         1.   
    SH010210  SH010269         1.   
    SH010210  SH010272         1.   
    SH010210  SH010273         1.   
    SH010210  SH010274         1.   
    SH010210  SH010275         1.   
    SH010210  SH010276         1.   
    SH010210  SH010277         1.   
    SH010210  SH010278         1.   
    SH010210  SH010279         1.   
    SH010210  SH010282         1.   
    SH010210  SH010283         1.   
    SH010210  SH010284         1.   
    SH010210  TRSH0201         1.   
    SH010310  SH010310        10.   
    SH010310  SH010315         1.   
    SH010310  SH010316         1.   
    SH010310  SH010319         1.   
    SH010310  SH010320         1.   
    SH010310  SH010321         1.   
    SH010310  SH010333         1.   
    SH010310  SH010334         1.   
    SH010310  SH010337         1.   
    SH010310  SH010338         1.   
    SH010310  SH010340         1.   
    SH010310  SH010343         1.   
    SH010310  SH010345         1.   
    SH010310  SH010346         1.   
    SH010310  SH010352         1.   
    SH010310  SH010353         1.   
    SH010310  SH010355         1.   
    SH010310  SH010358         1.   
    SH010310  SH010359         1.   
    SH010310  SH010360         1.   
    SH010310  SH010364         1.   
    SH010310  SH010371         1.   
    SH010310  SH010373         1.   
    SH010310  SH010377         1.   
    SH010310  SH010378         1.   
    SH010310  SH010382         1.   
    SH010310  SH010383         1.   
    SH010310  TRSH0301         1.   
    SH010410  SH010410        10.   
    SH010410  SH010415         1.   
    SH010410  SH010416         1.   
    SH010410  SH010418         1.   
    SH010410  SH010419         1.   
    SH010410  SH010420         1.   
    SH010410  SH010421         1.   
    SH010410  SH010422         1.   
    SH010410  SH010423         1.   
    SH010410  SH010426         1.   
    SH010410  SH010429         1.   
    SH010410  SH010430         1.   
    SH010410  SH010432         1.   
    SH010410  SH010433         1.   
    SH010410  SH010434         1.   
    SH010410  SH010435         1.   
    SH010410  SH010437         1.   
    SH010410  SH010438         1.   
    SH010410  SH010440         1.   
    SH010410  SH010443         1.   
    SH010410  SH010445         1.   
    SH010410  SH010446         1.   
    SH010410  SH010452         1.   
    SH010410  SH010453         1.   
    SH010410  SH010455         1.   
    SH010410  SH010458         1.   
    SH010410  SH010459         1.   
    SH010410  SH010460         1.   
    SH010410  SH010464         1.   
    SH010410  SH010471         1.   
    SH010410  SH010473         1.   
    SH010410  SH010477         1.   
    SH010410  SH010478         1.   
    SH010410  SH010480         1.   
    SH010410  SH010482         1.   
    SH010410  SH010483         1.   
    SH010410  TRSH0401         1.   
    SH010510  SH010510        10.   
    SH010510  SH010515         1.   
    SH010510  SH010516         1.   
    SH010510  SH010519         1.   
    SH010510  SH010520         1.   
    SH010510  SH010521         1.   
    SH010510  SH010528         1.   
    SH010510  SH010533         1.   
    SH010510  SH010534         1.   
    SH010510  SH010537         1.   
    SH010510  SH010538         1.   
    SH010510  SH010540         1.   
    SH010510  SH010543         1.   
    SH010510  SH010545         1.   
    SH010510  SH010546         1.   
    SH010510  SH010549         1.   
    SH010510  SH010551         1.   
    SH010510  SH010552         1.   
    SH010510  SH010553         1.   
    SH010510  SH010555         1.   
    SH010510  SH010556         1.   
    SH010510  SH010557         1.   
    SH010510  SH010558         1.   
    SH010510  SH010559         1.   
    SH010510  SH010560         1.   
    SH010510  SH010563         1.   
    SH010510  SH010564         1.   
    SH010510  SH010571         1.   
    SH010510  SH010573         1.   
    SH010510  SH010577         1.   
    SH010510  SH010578         1.   
    SH010510  SH010582         1.   
    SH010510  SH010583         1.   
    SH010510  TRSH0501         1.   
    SH010610  SH010610        10.   
    SH010610  SH010614         1.   
    SH010610  SH010615         1.   
    SH010610  SH010616         1.   
    SH010610  SH010619         1.   
    SH010610  SH010627         1.   
    SH010610  SH010636         1.   
    SH010610  SH010637         1.   
    SH010610  SH010638         1.   
    SH010610  SH010640         1.   
    SH010610  SH010641         1.   
    SH010610  SH010643         1.   
    SH010610  SH010644         1.   
    SH010610  SH010645         1.   
    SH010610  SH010646         1.   
    SH010610  SH010653         1.   
    SH010610  SH010655         1.   
    SH010610  SH010658         1.   
    SH010610  SH010659         1.   
    SH010610  SH010660         1.   
    SH010610  SH010664         1.   
    SH010610  SH010671         1.   
    SH010610  SH010673         1.   
    SH010610  SH010683         1.   
    SH010610  TRSH0601         1.   
    SH010810  SH010810        10.   
    SH010810  SH010815         1.   
    SH010810  SH010816         1.   
    SH010810  SH010817         1.   
    SH010810  SH010819         1.   
    SH010810  SH010820         1.   
    SH010810  SH010821         1.   
    SH010810  SH010833         1.   
    SH010810  SH010834         1.   
    SH010810  SH010837         1.   
    SH010810  SH010838         1.   
    SH010810  SH010840         1.   
    SH010810  SH010843         1.   
    SH010810  SH010845         1.   
    SH010810  SH010846         1.   
    SH010810  SH010852         1.   
    SH010810  SH010853         1.   
    SH010810  SH010855         1.   
    SH010810  SH010858         1.   
    SH010810  SH010859         1.   
    SH010810  SH010860         1.   
    SH010810  SH010864         1.   
    SH010810  SH010871         1.   
    SH010810  SH010873         1.   
    SH010810  SH010877         1.   
    SH010810  SH010878         1.   
    SH010810  SH010882         1.   
    SH010810  TRSH0801         1.   
    SH010111  SH010111        10.   
    SH010111  SH010112         1.   
    SH010111  SH010114         1.   
    SH010111  SH010115         1.   
    SH010111  SH010116         1.   
    SH010111  SH010117         1.   
    SH010111  SH010119         1.   
    SH010111  SH010120         1.   
    SH010111  SH010121         1.   
    SH010111  SH010124         1.   
    SH010111  SH010128         1.   
    SH010111  SH010131         1.   
    SH010111  SH010133         1.   
    SH010111  SH010134         1.   
    SH010111  SH010137         1.   
    SH010111  SH010138         1.   
    SH010111  SH010139         1.   
    SH010111  SH010140         1.   
    SH010111  SH010142         1.   
    SH010111  SH010143         1.   
    SH010111  SH010145         1.   
    SH010111  SH010146         1.   
    SH010111  SH010147         1.   
    SH010111  SH010148         1.   
    SH010111  SH010149         1.   
    SH010111  SH010150         1.   
    SH010111  SH010151         1.   
    SH010111  SH010152         1.   
    SH010111  SH010153         1.   
    SH010111  SH010154         1.   
    SH010111  SH010155         1.   
    SH010111  SH010156         1.   
    SH010111  SH010157         1.   
    SH010111  SH010158         1.   
    SH010111  SH010159         1.   
    SH010111  SH010160         1.   
    SH010111  SH010163         1.   
    SH010111  SH010164         1.   
    SH010111  SH010171         1.   
    SH010111  SH010173         1.   
    SH010111  SH010177         1.   
    SH010111  SH010178         1.   
    SH010111  SH010182         1.   
    SH010111  SH010183         1.   
    SH010111  TRSH0101         1.   
    SH010112  SH010112        10.   
    SH010112  SH010114         1.   
    SH010112  SH010115         1.   
    SH010112  SH010116         1.   
    SH010112  SH010117         1.   
    SH010112  SH010119         1.   
    SH010112  SH010120         1.   
    SH010112  SH010121         1.   
    SH010112  SH010124         1.   
    SH010112  SH010128         1.   
    SH010112  SH010131         1.   
    SH010112  SH010133         1.   
    SH010112  SH010134         1.   
    SH010112  SH010137         1.   
    SH010112  SH010138         1.   
    SH010112  SH010139         1.   
    SH010112  SH010140         1.   
    SH010112  SH010142         1.   
    SH010112  SH010143         1.   
    SH010112  SH010145         1.   
    SH010112  SH010146         1.   
    SH010112  SH010147         1.   
    SH010112  SH010148         1.   
    SH010112  SH010149         1.   
    SH010112  SH010150         1.   
    SH010112  SH010151         1.   
    SH010112  SH010152         1.   
    SH010112  SH010153         1.   
    SH010112  SH010154         1.   
    SH010112  SH010155         1.   
    SH010112  SH010156         1.   
    SH010112  SH010157         1.   
    SH010112  SH010158         1.   
    SH010112  SH010159         1.   
    SH010112  SH010160         1.   
    SH010112  SH010163         1.   
    SH010112  SH010164         1.   
    SH010112  SH010171         1.   
    SH010112  SH010173         1.   
    SH010112  SH010177         1.   
    SH010112  SH010178         1.   
    SH010112  SH010182         1.   
    SH010112  SH010183         1.   
    SH010112  TRSH0101         1.   
    SH010114  SH010114        10.   
    SH010114  SH010115         1.   
    SH010114  SH010116         1.   
    SH010114  SH010117         1.   
    SH010114  SH010119         1.   
    SH010114  SH010120         1.   
    SH010114  SH010121         1.   
    SH010114  SH010124         1.   
    SH010114  SH010128         1.   
    SH010114  SH010131         1.   
    SH010114  SH010133         1.   
    SH010114  SH010134         1.   
    SH010114  SH010137         1.   
    SH010114  SH010138         1.   
    SH010114  SH010139         1.   
    SH010114  SH010140         1.   
    SH010114  SH010142         1.   
    SH010114  SH010143         1.   
    SH010114  SH010145         1.   
    SH010114  SH010146         1.   
    SH010114  SH010147         1.   
    SH010114  SH010148         1.   
    SH010114  SH010149         1.   
    SH010114  SH010150         1.   
    SH010114  SH010151         1.   
    SH010114  SH010152         1.   
    SH010114  SH010153         1.   
    SH010114  SH010154         1.   
    SH010114  SH010155         1.   
    SH010114  SH010156         1.   
    SH010114  SH010157         1.   
    SH010114  SH010158         1.   
    SH010114  SH010159         1.   
    SH010114  SH010160         1.   
    SH010114  SH010163         1.   
    SH010114  SH010164         1.   
    SH010114  SH010171         1.   
    SH010114  SH010173         1.   
    SH010114  SH010177         1.   
    SH010114  SH010178         1.   
    SH010114  SH010182         1.   
    SH010114  SH010183         1.   
    SH010114  TRSH0101         1.   
    SH010614  SH010614        10.   
    SH010614  SH010615         1.   
    SH010614  SH010616         1.   
    SH010614  SH010619         1.   
    SH010614  SH010627         1.   
    SH010614  SH010636         1.   
    SH010614  SH010637         1.   
    SH010614  SH010638         1.   
    SH010614  SH010640         1.   
    SH010614  SH010641         1.   
    SH010614  SH010643         1.   
    SH010614  SH010644         1.   
    SH010614  SH010645         1.   
    SH010614  SH010646         1.   
    SH010614  SH010653         1.   
    SH010614  SH010655         1.   
    SH010614  SH010658         1.   
    SH010614  SH010659         1.   
    SH010614  SH010660         1.   
    SH010614  SH010664         1.   
    SH010614  SH010671         1.   
    SH010614  SH010673         1.   
    SH010614  SH010683         1.   
    SH010614  TRSH0601         1.   
    SH010115  SH010115        10.   
    SH010115  SH010116         1.   
    SH010115  SH010117         1.   
    SH010115  SH010119         1.   
    SH010115  SH010120         1.   
    SH010115  SH010121         1.   
    SH010115  SH010124         1.   
    SH010115  SH010128         1.   
    SH010115  SH010131         1.   
    SH010115  SH010133         1.   
    SH010115  SH010134         1.   
    SH010115  SH010137         1.   
    SH010115  SH010138         1.   
    SH010115  SH010139         1.   
    SH010115  SH010140         1.   
    SH010115  SH010142         1.   
    SH010115  SH010143         1.   
    SH010115  SH010145         1.   
    SH010115  SH010146         1.   
    SH010115  SH010147         1.   
    SH010115  SH010148         1.   
    SH010115  SH010149         1.   
    SH010115  SH010150         1.   
    SH010115  SH010151         1.   
    SH010115  SH010152         1.   
    SH010115  SH010153         1.   
    SH010115  SH010154         1.   
    SH010115  SH010155         1.   
    SH010115  SH010156         1.   
    SH010115  SH010157         1.   
    SH010115  SH010158         1.   
    SH010115  SH010159         1.   
    SH010115  SH010160         1.   
    SH010115  SH010163         1.   
    SH010115  SH010164         1.   
    SH010115  SH010171         1.   
    SH010115  SH010173         1.   
    SH010115  SH010177         1.   
    SH010115  SH010178         1.   
    SH010115  SH010182         1.   
    SH010115  SH010183         1.   
    SH010115  TRSH0101         1.   
    SH010215  SH010215        10.   
    SH010215  SH010216         1.   
    SH010215  SH010219         1.   
    SH010215  SH010220         1.   
    SH010215  SH010221         1.   
    SH010215  SH010225         1.   
    SH010215  SH010233         1.   
    SH010215  SH010234         1.   
    SH010215  SH010237         1.   
    SH010215  SH010238         1.   
    SH010215  SH010240         1.   
    SH010215  SH010243         1.   
    SH010215  SH010245         1.   
    SH010215  SH010246         1.   
    SH010215  SH010252         1.   
    SH010215  SH010253         1.   
    SH010215  SH010255         1.   
    SH010215  SH010258         1.   
    SH010215  SH010259         1.   
    SH010215  SH010260         1.   
    SH010215  SH010264         1.   
    SH010215  SH010265         1.   
    SH010215  SH010266         1.   
    SH010215  SH010267         1.   
    SH010215  SH010268         1.   
    SH010215  SH010269         1.   
    SH010215  SH010272         1.   
    SH010215  SH010273         1.   
    SH010215  SH010274         1.   
    SH010215  SH010275         1.   
    SH010215  SH010276         1.   
    SH010215  SH010277         1.   
    SH010215  SH010278         1.   
    SH010215  SH010279         1.   
    SH010215  SH010282         1.   
    SH010215  SH010283         1.   
    SH010215  SH010284         1.   
    SH010215  TRSH0201         1.   
    SH010315  SH010315        10.   
    SH010315  SH010316         1.   
    SH010315  SH010319         1.   
    SH010315  SH010320         1.   
    SH010315  SH010321         1.   
    SH010315  SH010333         1.   
    SH010315  SH010334         1.   
    SH010315  SH010337         1.   
    SH010315  SH010338         1.   
    SH010315  SH010340         1.   
    SH010315  SH010343         1.   
    SH010315  SH010345         1.   
    SH010315  SH010346         1.   
    SH010315  SH010352         1.   
    SH010315  SH010353         1.   
    SH010315  SH010355         1.   
    SH010315  SH010358         1.   
    SH010315  SH010359         1.   
    SH010315  SH010360         1.   
    SH010315  SH010364         1.   
    SH010315  SH010371         1.   
    SH010315  SH010373         1.   
    SH010315  SH010377         1.   
    SH010315  SH010378         1.   
    SH010315  SH010382         1.   
    SH010315  SH010383         1.   
    SH010315  TRSH0301         1.   
    SH010415  SH010415        10.   
    SH010415  SH010416         1.   
    SH010415  SH010418         1.   
    SH010415  SH010419         1.   
    SH010415  SH010420         1.   
    SH010415  SH010421         1.   
    SH010415  SH010422         1.   
    SH010415  SH010423         1.   
    SH010415  SH010426         1.   
    SH010415  SH010429         1.   
    SH010415  SH010430         1.   
    SH010415  SH010432         1.   
    SH010415  SH010433         1.   
    SH010415  SH010434         1.   
    SH010415  SH010435         1.   
    SH010415  SH010437         1.   
    SH010415  SH010438         1.   
    SH010415  SH010440         1.   
    SH010415  SH010443         1.   
    SH010415  SH010445         1.   
    SH010415  SH010446         1.   
    SH010415  SH010452         1.   
    SH010415  SH010453         1.   
    SH010415  SH010455         1.   
    SH010415  SH010458         1.   
    SH010415  SH010459         1.   
    SH010415  SH010460         1.   
    SH010415  SH010464         1.   
    SH010415  SH010471         1.   
    SH010415  SH010473         1.   
    SH010415  SH010477         1.   
    SH010415  SH010478         1.   
    SH010415  SH010480         1.   
    SH010415  SH010482         1.   
    SH010415  SH010483         1.   
    SH010415  TRSH0401         1.   
    SH010515  SH010515        10.   
    SH010515  SH010516         1.   
    SH010515  SH010519         1.   
    SH010515  SH010520         1.   
    SH010515  SH010521         1.   
    SH010515  SH010528         1.   
    SH010515  SH010533         1.   
    SH010515  SH010534         1.   
    SH010515  SH010537         1.   
    SH010515  SH010538         1.   
    SH010515  SH010540         1.   
    SH010515  SH010543         1.   
    SH010515  SH010545         1.   
    SH010515  SH010546         1.   
    SH010515  SH010549         1.   
    SH010515  SH010551         1.   
    SH010515  SH010552         1.   
    SH010515  SH010553         1.   
    SH010515  SH010555         1.   
    SH010515  SH010556         1.   
    SH010515  SH010557         1.   
    SH010515  SH010558         1.   
    SH010515  SH010559         1.   
    SH010515  SH010560         1.   
    SH010515  SH010563         1.   
    SH010515  SH010564         1.   
    SH010515  SH010571         1.   
    SH010515  SH010573         1.   
    SH010515  SH010577         1.   
    SH010515  SH010578         1.   
    SH010515  SH010582         1.   
    SH010515  SH010583         1.   
    SH010515  TRSH0501         1.   
    SH010615  SH010615        10.   
    SH010615  SH010616         1.   
    SH010615  SH010619         1.   
    SH010615  SH010627         1.   
    SH010615  SH010636         1.   
    SH010615  SH010637         1.   
    SH010615  SH010638         1.   
    SH010615  SH010640         1.   
    SH010615  SH010641         1.   
    SH010615  SH010643         1.   
    SH010615  SH010644         1.   
    SH010615  SH010645         1.   
    SH010615  SH010646         1.   
    SH010615  SH010653         1.   
    SH010615  SH010655         1.   
    SH010615  SH010658         1.   
    SH010615  SH010659         1.   
    SH010615  SH010660         1.   
    SH010615  SH010664         1.   
    SH010615  SH010671         1.   
    SH010615  SH010673         1.   
    SH010615  SH010683         1.   
    SH010615  TRSH0601         1.   
    SH010815  SH010815        10.   
    SH010815  SH010816         1.   
    SH010815  SH010817         1.   
    SH010815  SH010819         1.   
    SH010815  SH010820         1.   
    SH010815  SH010821         1.   
    SH010815  SH010833         1.   
    SH010815  SH010834         1.   
    SH010815  SH010837         1.   
    SH010815  SH010838         1.   
    SH010815  SH010840         1.   
    SH010815  SH010843         1.   
    SH010815  SH010845         1.   
    SH010815  SH010846         1.   
    SH010815  SH010852         1.   
    SH010815  SH010853         1.   
    SH010815  SH010855         1.   
    SH010815  SH010858         1.   
    SH010815  SH010859         1.   
    SH010815  SH010860         1.   
    SH010815  SH010864         1.   
    SH010815  SH010871         1.   
    SH010815  SH010873         1.   
    SH010815  SH010877         1.   
    SH010815  SH010878         1.   
    SH010815  SH010882         1.   
    SH010815  TRSH0801         1.   
    SH010116  SH010116        10.   
    SH010116  SH010117         1.   
    SH010116  SH010119         1.   
    SH010116  SH010120         1.   
    SH010116  SH010121         1.   
    SH010116  SH010124         1.   
    SH010116  SH010128         1.   
    SH010116  SH010131         1.   
    SH010116  SH010133         1.   
    SH010116  SH010134         1.   
    SH010116  SH010137         1.   
    SH010116  SH010138         1.   
    SH010116  SH010139         1.   
    SH010116  SH010140         1.   
    SH010116  SH010142         1.   
    SH010116  SH010143         1.   
    SH010116  SH010145         1.   
    SH010116  SH010146         1.   
    SH010116  SH010147         1.   
    SH010116  SH010148         1.   
    SH010116  SH010149         1.   
    SH010116  SH010150         1.   
    SH010116  SH010151         1.   
    SH010116  SH010152         1.   
    SH010116  SH010153         1.   
    SH010116  SH010154         1.   
    SH010116  SH010155         1.   
    SH010116  SH010156         1.   
    SH010116  SH010157         1.   
    SH010116  SH010158         1.   
    SH010116  SH010159         1.   
    SH010116  SH010160         1.   
    SH010116  SH010163         1.   
    SH010116  SH010164         1.   
    SH010116  SH010171         1.   
    SH010116  SH010173         1.   
    SH010116  SH010177         1.   
    SH010116  SH010178         1.   
    SH010116  SH010182         1.   
    SH010116  SH010183         1.   
    SH010116  TRSH0101         1.   
    SH010216  SH010216        10.   
    SH010216  SH010219         1.   
    SH010216  SH010220         1.   
    SH010216  SH010221         1.   
    SH010216  SH010225         1.   
    SH010216  SH010233         1.   
    SH010216  SH010234         1.   
    SH010216  SH010237         1.   
    SH010216  SH010238         1.   
    SH010216  SH010240         1.   
    SH010216  SH010243         1.   
    SH010216  SH010245         1.   
    SH010216  SH010246         1.   
    SH010216  SH010252         1.   
    SH010216  SH010253         1.   
    SH010216  SH010255         1.   
    SH010216  SH010258         1.   
    SH010216  SH010259         1.   
    SH010216  SH010260         1.   
    SH010216  SH010264         1.   
    SH010216  SH010265         1.   
    SH010216  SH010266         1.   
    SH010216  SH010267         1.   
    SH010216  SH010268         1.   
    SH010216  SH010269         1.   
    SH010216  SH010272         1.   
    SH010216  SH010273         1.   
    SH010216  SH010274         1.   
    SH010216  SH010275         1.   
    SH010216  SH010276         1.   
    SH010216  SH010277         1.   
    SH010216  SH010278         1.   
    SH010216  SH010279         1.   
    SH010216  SH010282         1.   
    SH010216  SH010283         1.   
    SH010216  SH010284         1.   
    SH010216  TRSH0201         1.   
    SH010316  SH010316        10.   
    SH010316  SH010319         1.   
    SH010316  SH010320         1.   
    SH010316  SH010321         1.   
    SH010316  SH010333         1.   
    SH010316  SH010334         1.   
    SH010316  SH010337         1.   
    SH010316  SH010338         1.   
    SH010316  SH010340         1.   
    SH010316  SH010343         1.   
    SH010316  SH010345         1.   
    SH010316  SH010346         1.   
    SH010316  SH010352         1.   
    SH010316  SH010353         1.   
    SH010316  SH010355         1.   
    SH010316  SH010358         1.   
    SH010316  SH010359         1.   
    SH010316  SH010360         1.   
    SH010316  SH010364         1.   
    SH010316  SH010371         1.   
    SH010316  SH010373         1.   
    SH010316  SH010377         1.   
    SH010316  SH010378         1.   
    SH010316  SH010382         1.   
    SH010316  SH010383         1.   
    SH010316  TRSH0301         1.   
    SH010416  SH010416        10.   
    SH010416  SH010418         1.   
    SH010416  SH010419         1.   
    SH010416  SH010420         1.   
    SH010416  SH010421         1.   
    SH010416  SH010422         1.   
    SH010416  SH010423         1.   
    SH010416  SH010426         1.   
    SH010416  SH010429         1.   
    SH010416  SH010430         1.   
    SH010416  SH010432         1.   
    SH010416  SH010433         1.   
    SH010416  SH010434         1.   
    SH010416  SH010435         1.   
    SH010416  SH010437         1.   
    SH010416  SH010438         1.   
    SH010416  SH010440         1.   
    SH010416  SH010443         1.   
    SH010416  SH010445         1.   
    SH010416  SH010446         1.   
    SH010416  SH010452         1.   
    SH010416  SH010453         1.   
    SH010416  SH010455         1.   
    SH010416  SH010458         1.   
    SH010416  SH010459         1.   
    SH010416  SH010460         1.   
    SH010416  SH010464         1.   
    SH010416  SH010471         1.   
    SH010416  SH010473         1.   
    SH010416  SH010477         1.   
    SH010416  SH010478         1.   
    SH010416  SH010480         1.   
    SH010416  SH010482         1.   
    SH010416  SH010483         1.   
    SH010416  TRSH0401         1.   
    SH010516  SH010516        10.   
    SH010516  SH010519         1.   
    SH010516  SH010520         1.   
    SH010516  SH010521         1.   
    SH010516  SH010528         1.   
    SH010516  SH010533         1.   
    SH010516  SH010534         1.   
    SH010516  SH010537         1.   
    SH010516  SH010538         1.   
    SH010516  SH010540         1.   
    SH010516  SH010543         1.   
    SH010516  SH010545         1.   
    SH010516  SH010546         1.   
    SH010516  SH010549         1.   
    SH010516  SH010551         1.   
    SH010516  SH010552         1.   
    SH010516  SH010553         1.   
    SH010516  SH010555         1.   
    SH010516  SH010556         1.   
    SH010516  SH010557         1.   
    SH010516  SH010558         1.   
    SH010516  SH010559         1.   
    SH010516  SH010560         1.   
    SH010516  SH010563         1.   
    SH010516  SH010564         1.   
    SH010516  SH010571         1.   
    SH010516  SH010573         1.   
    SH010516  SH010577         1.   
    SH010516  SH010578         1.   
    SH010516  SH010582         1.   
    SH010516  SH010583         1.   
    SH010516  TRSH0501         1.   
    SH010616  SH010616        10.   
    SH010616  SH010619         1.   
    SH010616  SH010627         1.   
    SH010616  SH010636         1.   
    SH010616  SH010637         1.   
    SH010616  SH010638         1.   
    SH010616  SH010640         1.   
    SH010616  SH010641         1.   
    SH010616  SH010643         1.   
    SH010616  SH010644         1.   
    SH010616  SH010645         1.   
    SH010616  SH010646         1.   
    SH010616  SH010653         1.   
    SH010616  SH010655         1.   
    SH010616  SH010658         1.   
    SH010616  SH010659         1.   
    SH010616  SH010660         1.   
    SH010616  SH010664         1.   
    SH010616  SH010671         1.   
    SH010616  SH010673         1.   
    SH010616  SH010683         1.   
    SH010616  TRSH0601         1.   
    SH010816  SH010816        10.   
    SH010816  SH010817         1.   
    SH010816  SH010819         1.   
    SH010816  SH010820         1.   
    SH010816  SH010821         1.   
    SH010816  SH010833         1.   
    SH010816  SH010834         1.   
    SH010816  SH010837         1.   
    SH010816  SH010838         1.   
    SH010816  SH010840         1.   
    SH010816  SH010843         1.   
    SH010816  SH010845         1.   
    SH010816  SH010846         1.   
    SH010816  SH010852         1.   
    SH010816  SH010853         1.   
    SH010816  SH010855         1.   
    SH010816  SH010858         1.   
    SH010816  SH010859         1.   
    SH010816  SH010860         1.   
    SH010816  SH010864         1.   
    SH010816  SH010871         1.   
    SH010816  SH010873         1.   
    SH010816  SH010877         1.   
    SH010816  SH010878         1.   
    SH010816  SH010882         1.   
    SH010816  TRSH0801         1.   
    SH010117  SH010117        10.   
    SH010117  SH010119         1.   
    SH010117  SH010120         1.   
    SH010117  SH010121         1.   
    SH010117  SH010124         1.   
    SH010117  SH010128         1.   
    SH010117  SH010131         1.   
    SH010117  SH010133         1.   
    SH010117  SH010134         1.   
    SH010117  SH010137         1.   
    SH010117  SH010138         1.   
    SH010117  SH010139         1.   
    SH010117  SH010140         1.   
    SH010117  SH010142         1.   
    SH010117  SH010143         1.   
    SH010117  SH010145         1.   
    SH010117  SH010146         1.   
    SH010117  SH010147         1.   
    SH010117  SH010148         1.   
    SH010117  SH010149         1.   
    SH010117  SH010150         1.   
    SH010117  SH010151         1.   
    SH010117  SH010152         1.   
    SH010117  SH010153         1.   
    SH010117  SH010154         1.   
    SH010117  SH010155         1.   
    SH010117  SH010156         1.   
    SH010117  SH010157         1.   
    SH010117  SH010158         1.   
    SH010117  SH010159         1.   
    SH010117  SH010160         1.   
    SH010117  SH010163         1.   
    SH010117  SH010164         1.   
    SH010117  SH010171         1.   
    SH010117  SH010173         1.   
    SH010117  SH010177         1.   
    SH010117  SH010178         1.   
    SH010117  SH010182         1.   
    SH010117  SH010183         1.   
    SH010117  TRSH0101         1.   
    SH010817  SH010817        10.   
    SH010817  SH010819         1.   
    SH010817  SH010820         1.   
    SH010817  SH010821         1.   
    SH010817  SH010833         1.   
    SH010817  SH010834         1.   
    SH010817  SH010837         1.   
    SH010817  SH010838         1.   
    SH010817  SH010840         1.   
    SH010817  SH010843         1.   
    SH010817  SH010845         1.   
    SH010817  SH010846         1.   
    SH010817  SH010852         1.   
    SH010817  SH010853         1.   
    SH010817  SH010855         1.   
    SH010817  SH010858         1.   
    SH010817  SH010859         1.   
    SH010817  SH010860         1.   
    SH010817  SH010864         1.   
    SH010817  SH010871         1.   
    SH010817  SH010873         1.   
    SH010817  SH010877         1.   
    SH010817  SH010878         1.   
    SH010817  SH010882         1.   
    SH010817  TRSH0801         1.   
    SH010418  SH010418        10.   
    SH010418  SH010419         1.   
    SH010418  SH010420         1.   
    SH010418  SH010421         1.   
    SH010418  SH010422         1.   
    SH010418  SH010423         1.   
    SH010418  SH010426         1.   
    SH010418  SH010429         1.   
    SH010418  SH010430         1.   
    SH010418  SH010432         1.   
    SH010418  SH010433         1.   
    SH010418  SH010434         1.   
    SH010418  SH010435         1.   
    SH010418  SH010437         1.   
    SH010418  SH010438         1.   
    SH010418  SH010440         1.   
    SH010418  SH010443         1.   
    SH010418  SH010445         1.   
    SH010418  SH010446         1.   
    SH010418  SH010452         1.   
    SH010418  SH010453         1.   
    SH010418  SH010455         1.   
    SH010418  SH010458         1.   
    SH010418  SH010459         1.   
    SH010418  SH010460         1.   
    SH010418  SH010464         1.   
    SH010418  SH010471         1.   
    SH010418  SH010473         1.   
    SH010418  SH010477         1.   
    SH010418  SH010478         1.   
    SH010418  SH010480         1.   
    SH010418  SH010482         1.   
    SH010418  SH010483         1.   
    SH010418  TRSH0401         1.   
    SH010119  SH010119        10.   
    SH010119  SH010120         1.   
    SH010119  SH010121         1.   
    SH010119  SH010124         1.   
    SH010119  SH010128         1.   
    SH010119  SH010131         1.   
    SH010119  SH010133         1.   
    SH010119  SH010134         1.   
    SH010119  SH010137         1.   
    SH010119  SH010138         1.   
    SH010119  SH010139         1.   
    SH010119  SH010140         1.   
    SH010119  SH010142         1.   
    SH010119  SH010143         1.   
    SH010119  SH010145         1.   
    SH010119  SH010146         1.   
    SH010119  SH010147         1.   
    SH010119  SH010148         1.   
    SH010119  SH010149         1.   
    SH010119  SH010150         1.   
    SH010119  SH010151         1.   
    SH010119  SH010152         1.   
    SH010119  SH010153         1.   
    SH010119  SH010154         1.   
    SH010119  SH010155         1.   
    SH010119  SH010156         1.   
    SH010119  SH010157         1.   
    SH010119  SH010158         1.   
    SH010119  SH010159         1.   
    SH010119  SH010160         1.   
    SH010119  SH010163         1.   
    SH010119  SH010164         1.   
    SH010119  SH010171         1.   
    SH010119  SH010173         1.   
    SH010119  SH010177         1.   
    SH010119  SH010178         1.   
    SH010119  SH010182         1.   
    SH010119  SH010183         1.   
    SH010119  TRSH0101         1.   
    SH010219  SH010219        10.   
    SH010219  SH010220         1.   
    SH010219  SH010221         1.   
    SH010219  SH010225         1.   
    SH010219  SH010233         1.   
    SH010219  SH010234         1.   
    SH010219  SH010237         1.   
    SH010219  SH010238         1.   
    SH010219  SH010240         1.   
    SH010219  SH010243         1.   
    SH010219  SH010245         1.   
    SH010219  SH010246         1.   
    SH010219  SH010252         1.   
    SH010219  SH010253         1.   
    SH010219  SH010255         1.   
    SH010219  SH010258         1.   
    SH010219  SH010259         1.   
    SH010219  SH010260         1.   
    SH010219  SH010264         1.   
    SH010219  SH010265         1.   
    SH010219  SH010266         1.   
    SH010219  SH010267         1.   
    SH010219  SH010268         1.   
    SH010219  SH010269         1.   
    SH010219  SH010272         1.   
    SH010219  SH010273         1.   
    SH010219  SH010274         1.   
    SH010219  SH010275         1.   
    SH010219  SH010276         1.   
    SH010219  SH010277         1.   
    SH010219  SH010278         1.   
    SH010219  SH010279         1.   
    SH010219  SH010282         1.   
    SH010219  SH010283         1.   
    SH010219  SH010284         1.   
    SH010219  TRSH0201         1.   
    SH010319  SH010319        10.   
    SH010319  SH010320         1.   
    SH010319  SH010321         1.   
    SH010319  SH010333         1.   
    SH010319  SH010334         1.   
    SH010319  SH010337         1.   
    SH010319  SH010338         1.   
    SH010319  SH010340         1.   
    SH010319  SH010343         1.   
    SH010319  SH010345         1.   
    SH010319  SH010346         1.   
    SH010319  SH010352         1.   
    SH010319  SH010353         1.   
    SH010319  SH010355         1.   
    SH010319  SH010358         1.   
    SH010319  SH010359         1.   
    SH010319  SH010360         1.   
    SH010319  SH010364         1.   
    SH010319  SH010371         1.   
    SH010319  SH010373         1.   
    SH010319  SH010377         1.   
    SH010319  SH010378         1.   
    SH010319  SH010382         1.   
    SH010319  SH010383         1.   
    SH010319  TRSH0301         1.   
    SH010419  SH010419        10.   
    SH010419  SH010420         1.   
    SH010419  SH010421         1.   
    SH010419  SH010422         1.   
    SH010419  SH010423         1.   
    SH010419  SH010426         1.   
    SH010419  SH010429         1.   
    SH010419  SH010430         1.   
    SH010419  SH010432         1.   
    SH010419  SH010433         1.   
    SH010419  SH010434         1.   
    SH010419  SH010435         1.   
    SH010419  SH010437         1.   
    SH010419  SH010438         1.   
    SH010419  SH010440         1.   
    SH010419  SH010443         1.   
    SH010419  SH010445         1.   
    SH010419  SH010446         1.   
    SH010419  SH010452         1.   
    SH010419  SH010453         1.   
    SH010419  SH010455         1.   
    SH010419  SH010458         1.   
    SH010419  SH010459         1.   
    SH010419  SH010460         1.   
    SH010419  SH010464         1.   
    SH010419  SH010471         1.   
    SH010419  SH010473         1.   
    SH010419  SH010477         1.   
    SH010419  SH010478         1.   
    SH010419  SH010480         1.   
    SH010419  SH010482         1.   
    SH010419  SH010483         1.   
    SH010419  TRSH0401         1.   
    SH010519  SH010519        10.   
    SH010519  SH010520         1.   
    SH010519  SH010521         1.   
    SH010519  SH010528         1.   
    SH010519  SH010533         1.   
    SH010519  SH010534         1.   
    SH010519  SH010537         1.   
    SH010519  SH010538         1.   
    SH010519  SH010540         1.   
    SH010519  SH010543         1.   
    SH010519  SH010545         1.   
    SH010519  SH010546         1.   
    SH010519  SH010549         1.   
    SH010519  SH010551         1.   
    SH010519  SH010552         1.   
    SH010519  SH010553         1.   
    SH010519  SH010555         1.   
    SH010519  SH010556         1.   
    SH010519  SH010557         1.   
    SH010519  SH010558         1.   
    SH010519  SH010559         1.   
    SH010519  SH010560         1.   
    SH010519  SH010563         1.   
    SH010519  SH010564         1.   
    SH010519  SH010571         1.   
    SH010519  SH010573         1.   
    SH010519  SH010577         1.   
    SH010519  SH010578         1.   
    SH010519  SH010582         1.   
    SH010519  SH010583         1.   
    SH010519  TRSH0501         1.   
    SH010619  SH010619        10.   
    SH010619  SH010627         1.   
    SH010619  SH010636         1.   
    SH010619  SH010637         1.   
    SH010619  SH010638         1.   
    SH010619  SH010640         1.   
    SH010619  SH010641         1.   
    SH010619  SH010643         1.   
    SH010619  SH010644         1.   
    SH010619  SH010645         1.   
    SH010619  SH010646         1.   
    SH010619  SH010653         1.   
    SH010619  SH010655         1.   
    SH010619  SH010658         1.   
    SH010619  SH010659         1.   
    SH010619  SH010660         1.   
    SH010619  SH010664         1.   
    SH010619  SH010671         1.   
    SH010619  SH010673         1.   
    SH010619  SH010683         1.   
    SH010619  TRSH0601         1.   
    SH010819  SH010819        10.   
    SH010819  SH010820         1.   
    SH010819  SH010821         1.   
    SH010819  SH010833         1.   
    SH010819  SH010834         1.   
    SH010819  SH010837         1.   
    SH010819  SH010838         1.   
    SH010819  SH010840         1.   
    SH010819  SH010843         1.   
    SH010819  SH010845         1.   
    SH010819  SH010846         1.   
    SH010819  SH010852         1.   
    SH010819  SH010853         1.   
    SH010819  SH010855         1.   
    SH010819  SH010858         1.   
    SH010819  SH010859         1.   
    SH010819  SH010860         1.   
    SH010819  SH010864         1.   
    SH010819  SH010871         1.   
    SH010819  SH010873         1.   
    SH010819  SH010877         1.   
    SH010819  SH010878         1.   
    SH010819  SH010882         1.   
    SH010819  TRSH0801         1.   
    SH010120  SH010120        10.   
    SH010120  SH010121         1.   
    SH010120  SH010124         1.   
    SH010120  SH010128         1.   
    SH010120  SH010131         1.   
    SH010120  SH010133         1.   
    SH010120  SH010134         1.   
    SH010120  SH010137         1.   
    SH010120  SH010138         1.   
    SH010120  SH010139         1.   
    SH010120  SH010140         1.   
    SH010120  SH010142         1.   
    SH010120  SH010143         1.   
    SH010120  SH010145         1.   
    SH010120  SH010146         1.   
    SH010120  SH010147         1.   
    SH010120  SH010148         1.   
    SH010120  SH010149         1.   
    SH010120  SH010150         1.   
    SH010120  SH010151         1.   
    SH010120  SH010152         1.   
    SH010120  SH010153         1.   
    SH010120  SH010154         1.   
    SH010120  SH010155         1.   
    SH010120  SH010156         1.   
    SH010120  SH010157         1.   
    SH010120  SH010158         1.   
    SH010120  SH010159         1.   
    SH010120  SH010160         1.   
    SH010120  SH010163         1.   
    SH010120  SH010164         1.   
    SH010120  SH010171         1.   
    SH010120  SH010173         1.   
    SH010120  SH010177         1.   
    SH010120  SH010178         1.   
    SH010120  SH010182         1.   
    SH010120  SH010183         1.   
    SH010120  TRSH0101         1.   
    SH010220  SH010220        10.   
    SH010220  SH010221         1.   
    SH010220  SH010225         1.   
    SH010220  SH010233         1.   
    SH010220  SH010234         1.   
    SH010220  SH010237         1.   
    SH010220  SH010238         1.   
    SH010220  SH010240         1.   
    SH010220  SH010243         1.   
    SH010220  SH010245         1.   
    SH010220  SH010246         1.   
    SH010220  SH010252         1.   
    SH010220  SH010253         1.   
    SH010220  SH010255         1.   
    SH010220  SH010258         1.   
    SH010220  SH010259         1.   
    SH010220  SH010260         1.   
    SH010220  SH010264         1.   
    SH010220  SH010265         1.   
    SH010220  SH010266         1.   
    SH010220  SH010267         1.   
    SH010220  SH010268         1.   
    SH010220  SH010269         1.   
    SH010220  SH010272         1.   
    SH010220  SH010273         1.   
    SH010220  SH010274         1.   
    SH010220  SH010275         1.   
    SH010220  SH010276         1.   
    SH010220  SH010277         1.   
    SH010220  SH010278         1.   
    SH010220  SH010279         1.   
    SH010220  SH010282         1.   
    SH010220  SH010283         1.   
    SH010220  SH010284         1.   
    SH010220  TRSH0201         1.   
    SH010320  SH010320        10.   
    SH010320  SH010321         1.   
    SH010320  SH010333         1.   
    SH010320  SH010334         1.   
    SH010320  SH010337         1.   
    SH010320  SH010338         1.   
    SH010320  SH010340         1.   
    SH010320  SH010343         1.   
    SH010320  SH010345         1.   
    SH010320  SH010346         1.   
    SH010320  SH010352         1.   
    SH010320  SH010353         1.   
    SH010320  SH010355         1.   
    SH010320  SH010358         1.   
    SH010320  SH010359         1.   
    SH010320  SH010360         1.   
    SH010320  SH010364         1.   
    SH010320  SH010371         1.   
    SH010320  SH010373         1.   
    SH010320  SH010377         1.   
    SH010320  SH010378         1.   
    SH010320  SH010382         1.   
    SH010320  SH010383         1.   
    SH010320  TRSH0301         1.   
    SH010420  SH010420        10.   
    SH010420  SH010421         1.   
    SH010420  SH010422         1.   
    SH010420  SH010423         1.   
    SH010420  SH010426         1.   
    SH010420  SH010429         1.   
    SH010420  SH010430         1.   
    SH010420  SH010432         1.   
    SH010420  SH010433         1.   
    SH010420  SH010434         1.   
    SH010420  SH010435         1.   
    SH010420  SH010437         1.   
    SH010420  SH010438         1.   
    SH010420  SH010440         1.   
    SH010420  SH010443         1.   
    SH010420  SH010445         1.   
    SH010420  SH010446         1.   
    SH010420  SH010452         1.   
    SH010420  SH010453         1.   
    SH010420  SH010455         1.   
    SH010420  SH010458         1.   
    SH010420  SH010459         1.   
    SH010420  SH010460         1.   
    SH010420  SH010464         1.   
    SH010420  SH010471         1.   
    SH010420  SH010473         1.   
    SH010420  SH010477         1.   
    SH010420  SH010478         1.   
    SH010420  SH010480         1.   
    SH010420  SH010482         1.   
    SH010420  SH010483         1.   
    SH010420  TRSH0401         1.   
    SH010520  SH010520        10.   
    SH010520  SH010521         1.   
    SH010520  SH010528         1.   
    SH010520  SH010533         1.   
    SH010520  SH010534         1.   
    SH010520  SH010537         1.   
    SH010520  SH010538         1.   
    SH010520  SH010540         1.   
    SH010520  SH010543         1.   
    SH010520  SH010545         1.   
    SH010520  SH010546         1.   
    SH010520  SH010549         1.   
    SH010520  SH010551         1.   
    SH010520  SH010552         1.   
    SH010520  SH010553         1.   
    SH010520  SH010555         1.   
    SH010520  SH010556         1.   
    SH010520  SH010557         1.   
    SH010520  SH010558         1.   
    SH010520  SH010559         1.   
    SH010520  SH010560         1.   
    SH010520  SH010563         1.   
    SH010520  SH010564         1.   
    SH010520  SH010571         1.   
    SH010520  SH010573         1.   
    SH010520  SH010577         1.   
    SH010520  SH010578         1.   
    SH010520  SH010582         1.   
    SH010520  SH010583         1.   
    SH010520  TRSH0501         1.   
    SH010820  SH010820        10.   
    SH010820  SH010821         1.   
    SH010820  SH010833         1.   
    SH010820  SH010834         1.   
    SH010820  SH010837         1.   
    SH010820  SH010838         1.   
    SH010820  SH010840         1.   
    SH010820  SH010843         1.   
    SH010820  SH010845         1.   
    SH010820  SH010846         1.   
    SH010820  SH010852         1.   
    SH010820  SH010853         1.   
    SH010820  SH010855         1.   
    SH010820  SH010858         1.   
    SH010820  SH010859         1.   
    SH010820  SH010860         1.   
    SH010820  SH010864         1.   
    SH010820  SH010871         1.   
    SH010820  SH010873         1.   
    SH010820  SH010877         1.   
    SH010820  SH010878         1.   
    SH010820  SH010882         1.   
    SH010820  TRSH0801         1.   
    SH010121  SH010121        10.   
    SH010121  SH010124         1.   
    SH010121  SH010128         1.   
    SH010121  SH010131         1.   
    SH010121  SH010133         1.   
    SH010121  SH010134         1.   
    SH010121  SH010137         1.   
    SH010121  SH010138         1.   
    SH010121  SH010139         1.   
    SH010121  SH010140         1.   
    SH010121  SH010142         1.   
    SH010121  SH010143         1.   
    SH010121  SH010145         1.   
    SH010121  SH010146         1.   
    SH010121  SH010147         1.   
    SH010121  SH010148         1.   
    SH010121  SH010149         1.   
    SH010121  SH010150         1.   
    SH010121  SH010151         1.   
    SH010121  SH010152         1.   
    SH010121  SH010153         1.   
    SH010121  SH010154         1.   
    SH010121  SH010155         1.   
    SH010121  SH010156         1.   
    SH010121  SH010157         1.   
    SH010121  SH010158         1.   
    SH010121  SH010159         1.   
    SH010121  SH010160         1.   
    SH010121  SH010163         1.   
    SH010121  SH010164         1.   
    SH010121  SH010171         1.   
    SH010121  SH010173         1.   
    SH010121  SH010177         1.   
    SH010121  SH010178         1.   
    SH010121  SH010182         1.   
    SH010121  SH010183         1.   
    SH010121  TRSH0101         1.   
    SH010221  SH010221        10.   
    SH010221  SH010225         1.   
    SH010221  SH010233         1.   
    SH010221  SH010234         1.   
    SH010221  SH010237         1.   
    SH010221  SH010238         1.   
    SH010221  SH010240         1.   
    SH010221  SH010243         1.   
    SH010221  SH010245         1.   
    SH010221  SH010246         1.   
    SH010221  SH010252         1.   
    SH010221  SH010253         1.   
    SH010221  SH010255         1.   
    SH010221  SH010258         1.   
    SH010221  SH010259         1.   
    SH010221  SH010260         1.   
    SH010221  SH010264         1.   
    SH010221  SH010265         1.   
    SH010221  SH010266         1.   
    SH010221  SH010267         1.   
    SH010221  SH010268         1.   
    SH010221  SH010269         1.   
    SH010221  SH010272         1.   
    SH010221  SH010273         1.   
    SH010221  SH010274         1.   
    SH010221  SH010275         1.   
    SH010221  SH010276         1.   
    SH010221  SH010277         1.   
    SH010221  SH010278         1.   
    SH010221  SH010279         1.   
    SH010221  SH010282         1.   
    SH010221  SH010283         1.   
    SH010221  SH010284         1.   
    SH010221  TRSH0201         1.   
    SH010321  SH010321        10.   
    SH010321  SH010333         1.   
    SH010321  SH010334         1.   
    SH010321  SH010337         1.   
    SH010321  SH010338         1.   
    SH010321  SH010340         1.   
    SH010321  SH010343         1.   
    SH010321  SH010345         1.   
    SH010321  SH010346         1.   
    SH010321  SH010352         1.   
    SH010321  SH010353         1.   
    SH010321  SH010355         1.   
    SH010321  SH010358         1.   
    SH010321  SH010359         1.   
    SH010321  SH010360         1.   
    SH010321  SH010364         1.   
    SH010321  SH010371         1.   
    SH010321  SH010373         1.   
    SH010321  SH010377         1.   
    SH010321  SH010378         1.   
    SH010321  SH010382         1.   
    SH010321  SH010383         1.   
    SH010321  TRSH0301         1.   
    SH010421  SH010421        10.   
    SH010421  SH010422         1.   
    SH010421  SH010423         1.   
    SH010421  SH010426         1.   
    SH010421  SH010429         1.   
    SH010421  SH010430         1.   
    SH010421  SH010432         1.   
    SH010421  SH010433         1.   
    SH010421  SH010434         1.   
    SH010421  SH010435         1.   
    SH010421  SH010437         1.   
    SH010421  SH010438         1.   
    SH010421  SH010440         1.   
    SH010421  SH010443         1.   
    SH010421  SH010445         1.   
    SH010421  SH010446         1.   
    SH010421  SH010452         1.   
    SH010421  SH010453         1.   
    SH010421  SH010455         1.   
    SH010421  SH010458         1.   
    SH010421  SH010459         1.   
    SH010421  SH010460         1.   
    SH010421  SH010464         1.   
    SH010421  SH010471         1.   
    SH010421  SH010473         1.   
    SH010421  SH010477         1.   
    SH010421  SH010478         1.   
    SH010421  SH010480         1.   
    SH010421  SH010482         1.   
    SH010421  SH010483         1.   
    SH010421  TRSH0401         1.   
    SH010521  SH010521        10.   
    SH010521  SH010528         1.   
    SH010521  SH010533         1.   
    SH010521  SH010534         1.   
    SH010521  SH010537         1.   
    SH010521  SH010538         1.   
    SH010521  SH010540         1.   
    SH010521  SH010543         1.   
    SH010521  SH010545         1.   
    SH010521  SH010546         1.   
    SH010521  SH010549         1.   
    SH010521  SH010551         1.   
    SH010521  SH010552         1.   
    SH010521  SH010553         1.   
    SH010521  SH010555         1.   
    SH010521  SH010556         1.   
    SH010521  SH010557         1.   
    SH010521  SH010558         1.   
    SH010521  SH010559         1.   
    SH010521  SH010560         1.   
    SH010521  SH010563         1.   
    SH010521  SH010564         1.   
    SH010521  SH010571         1.   
    SH010521  SH010573         1.   
    SH010521  SH010577         1.   
    SH010521  SH010578         1.   
    SH010521  SH010582         1.   
    SH010521  SH010583         1.   
    SH010521  TRSH0501         1.   
    SH010821  SH010821        10.   
    SH010821  SH010833         1.   
    SH010821  SH010834         1.   
    SH010821  SH010837         1.   
    SH010821  SH010838         1.   
    SH010821  SH010840         1.   
    SH010821  SH010843         1.   
    SH010821  SH010845         1.   
    SH010821  SH010846         1.   
    SH010821  SH010852         1.   
    SH010821  SH010853         1.   
    SH010821  SH010855         1.   
    SH010821  SH010858         1.   
    SH010821  SH010859         1.   
    SH010821  SH010860         1.   
    SH010821  SH010864         1.   
    SH010821  SH010871         1.   
    SH010821  SH010873         1.   
    SH010821  SH010877         1.   
    SH010821  SH010878         1.   
    SH010821  SH010882         1.   
    SH010821  TRSH0801         1.   
    SH010422  SH010422        10.   
    SH010422  SH010423         1.   
    SH010422  SH010426         1.   
    SH010422  SH010429         1.   
    SH010422  SH010430         1.   
    SH010422  SH010432         1.   
    SH010422  SH010433         1.   
    SH010422  SH010434         1.   
    SH010422  SH010435         1.   
    SH010422  SH010437         1.   
    SH010422  SH010438         1.   
    SH010422  SH010440         1.   
    SH010422  SH010443         1.   
    SH010422  SH010445         1.   
    SH010422  SH010446         1.   
    SH010422  SH010452         1.   
    SH010422  SH010453         1.   
    SH010422  SH010455         1.   
    SH010422  SH010458         1.   
    SH010422  SH010459         1.   
    SH010422  SH010460         1.   
    SH010422  SH010464         1.   
    SH010422  SH010471         1.   
    SH010422  SH010473         1.   
    SH010422  SH010477         1.   
    SH010422  SH010478         1.   
    SH010422  SH010480         1.   
    SH010422  SH010482         1.   
    SH010422  SH010483         1.   
    SH010422  TRSH0401         1.   
    SH010423  SH010423        10.   
    SH010423  SH010426         1.   
    SH010423  SH010429         1.   
    SH010423  SH010430         1.   
    SH010423  SH010432         1.   
    SH010423  SH010433         1.   
    SH010423  SH010434         1.   
    SH010423  SH010435         1.   
    SH010423  SH010437         1.   
    SH010423  SH010438         1.   
    SH010423  SH010440         1.   
    SH010423  SH010443         1.   
    SH010423  SH010445         1.   
    SH010423  SH010446         1.   
    SH010423  SH010452         1.   
    SH010423  SH010453         1.   
    SH010423  SH010455         1.   
    SH010423  SH010458         1.   
    SH010423  SH010459         1.   
    SH010423  SH010460         1.   
    SH010423  SH010464         1.   
    SH010423  SH010471         1.   
    SH010423  SH010473         1.   
    SH010423  SH010477         1.   
    SH010423  SH010478         1.   
    SH010423  SH010480         1.   
    SH010423  SH010482         1.   
    SH010423  SH010483         1.   
    SH010423  TRSH0401         1.   
    SH010124  SH010124        10.   
    SH010124  SH010128         1.   
    SH010124  SH010131         1.   
    SH010124  SH010133         1.   
    SH010124  SH010134         1.   
    SH010124  SH010137         1.   
    SH010124  SH010138         1.   
    SH010124  SH010139         1.   
    SH010124  SH010140         1.   
    SH010124  SH010142         1.   
    SH010124  SH010143         1.   
    SH010124  SH010145         1.   
    SH010124  SH010146         1.   
    SH010124  SH010147         1.   
    SH010124  SH010148         1.   
    SH010124  SH010149         1.   
    SH010124  SH010150         1.   
    SH010124  SH010151         1.   
    SH010124  SH010152         1.   
    SH010124  SH010153         1.   
    SH010124  SH010154         1.   
    SH010124  SH010155         1.   
    SH010124  SH010156         1.   
    SH010124  SH010157         1.   
    SH010124  SH010158         1.   
    SH010124  SH010159         1.   
    SH010124  SH010160         1.   
    SH010124  SH010163         1.   
    SH010124  SH010164         1.   
    SH010124  SH010171         1.   
    SH010124  SH010173         1.   
    SH010124  SH010177         1.   
    SH010124  SH010178         1.   
    SH010124  SH010182         1.   
    SH010124  SH010183         1.   
    SH010124  TRSH0101         1.   
    SH010225  SH010225        10.   
    SH010225  SH010233         1.   
    SH010225  SH010234         1.   
    SH010225  SH010237         1.   
    SH010225  SH010238         1.   
    SH010225  SH010240         1.   
    SH010225  SH010243         1.   
    SH010225  SH010245         1.   
    SH010225  SH010246         1.   
    SH010225  SH010252         1.   
    SH010225  SH010253         1.   
    SH010225  SH010255         1.   
    SH010225  SH010258         1.   
    SH010225  SH010259         1.   
    SH010225  SH010260         1.   
    SH010225  SH010264         1.   
    SH010225  SH010265         1.   
    SH010225  SH010266         1.   
    SH010225  SH010267         1.   
    SH010225  SH010268         1.   
    SH010225  SH010269         1.   
    SH010225  SH010272         1.   
    SH010225  SH010273         1.   
    SH010225  SH010274         1.   
    SH010225  SH010275         1.   
    SH010225  SH010276         1.   
    SH010225  SH010277         1.   
    SH010225  SH010278         1.   
    SH010225  SH010279         1.   
    SH010225  SH010282         1.   
    SH010225  SH010283         1.   
    SH010225  SH010284         1.   
    SH010225  TRSH0201         1.   
    SH010426  SH010426        10.   
    SH010426  SH010429         1.   
    SH010426  SH010430         1.   
    SH010426  SH010432         1.   
    SH010426  SH010433         1.   
    SH010426  SH010434         1.   
    SH010426  SH010435         1.   
    SH010426  SH010437         1.   
    SH010426  SH010438         1.   
    SH010426  SH010440         1.   
    SH010426  SH010443         1.   
    SH010426  SH010445         1.   
    SH010426  SH010446         1.   
    SH010426  SH010452         1.   
    SH010426  SH010453         1.   
    SH010426  SH010455         1.   
    SH010426  SH010458         1.   
    SH010426  SH010459         1.   
    SH010426  SH010460         1.   
    SH010426  SH010464         1.   
    SH010426  SH010471         1.   
    SH010426  SH010473         1.   
    SH010426  SH010477         1.   
    SH010426  SH010478         1.   
    SH010426  SH010480         1.   
    SH010426  SH010482         1.   
    SH010426  SH010483         1.   
    SH010426  TRSH0401         1.   
    SH010627  SH010627        10.   
    SH010627  SH010636         1.   
    SH010627  SH010637         1.   
    SH010627  SH010638         1.   
    SH010627  SH010640         1.   
    SH010627  SH010641         1.   
    SH010627  SH010643         1.   
    SH010627  SH010644         1.   
    SH010627  SH010645         1.   
    SH010627  SH010646         1.   
    SH010627  SH010653         1.   
    SH010627  SH010655         1.   
    SH010627  SH010658         1.   
    SH010627  SH010659         1.   
    SH010627  SH010660         1.   
    SH010627  SH010664         1.   
    SH010627  SH010671         1.   
    SH010627  SH010673         1.   
    SH010627  SH010683         1.   
    SH010627  TRSH0601         1.   
    SH010128  SH010128        10.   
    SH010128  SH010131         1.   
    SH010128  SH010133         1.   
    SH010128  SH010134         1.   
    SH010128  SH010137         1.   
    SH010128  SH010138         1.   
    SH010128  SH010139         1.   
    SH010128  SH010140         1.   
    SH010128  SH010142         1.   
    SH010128  SH010143         1.   
    SH010128  SH010145         1.   
    SH010128  SH010146         1.   
    SH010128  SH010147         1.   
    SH010128  SH010148         1.   
    SH010128  SH010149         1.   
    SH010128  SH010150         1.   
    SH010128  SH010151         1.   
    SH010128  SH010152         1.   
    SH010128  SH010153         1.   
    SH010128  SH010154         1.   
    SH010128  SH010155         1.   
    SH010128  SH010156         1.   
    SH010128  SH010157         1.   
    SH010128  SH010158         1.   
    SH010128  SH010159         1.   
    SH010128  SH010160         1.   
    SH010128  SH010163         1.   
    SH010128  SH010164         1.   
    SH010128  SH010171         1.   
    SH010128  SH010173         1.   
    SH010128  SH010177         1.   
    SH010128  SH010178         1.   
    SH010128  SH010182         1.   
    SH010128  SH010183         1.   
    SH010128  TRSH0101         1.   
    SH010528  SH010528        10.   
    SH010528  SH010533         1.   
    SH010528  SH010534         1.   
    SH010528  SH010537         1.   
    SH010528  SH010538         1.   
    SH010528  SH010540         1.   
    SH010528  SH010543         1.   
    SH010528  SH010545         1.   
    SH010528  SH010546         1.   
    SH010528  SH010549         1.   
    SH010528  SH010551         1.   
    SH010528  SH010552         1.   
    SH010528  SH010553         1.   
    SH010528  SH010555         1.   
    SH010528  SH010556         1.   
    SH010528  SH010557         1.   
    SH010528  SH010558         1.   
    SH010528  SH010559         1.   
    SH010528  SH010560         1.   
    SH010528  SH010563         1.   
    SH010528  SH010564         1.   
    SH010528  SH010571         1.   
    SH010528  SH010573         1.   
    SH010528  SH010577         1.   
    SH010528  SH010578         1.   
    SH010528  SH010582         1.   
    SH010528  SH010583         1.   
    SH010528  TRSH0501         1.   
    SH010429  SH010429        10.   
    SH010429  SH010430         1.   
    SH010429  SH010432         1.   
    SH010429  SH010433         1.   
    SH010429  SH010434         1.   
    SH010429  SH010435         1.   
    SH010429  SH010437         1.   
    SH010429  SH010438         1.   
    SH010429  SH010440         1.   
    SH010429  SH010443         1.   
    SH010429  SH010445         1.   
    SH010429  SH010446         1.   
    SH010429  SH010452         1.   
    SH010429  SH010453         1.   
    SH010429  SH010455         1.   
    SH010429  SH010458         1.   
    SH010429  SH010459         1.   
    SH010429  SH010460         1.   
    SH010429  SH010464         1.   
    SH010429  SH010471         1.   
    SH010429  SH010473         1.   
    SH010429  SH010477         1.   
    SH010429  SH010478         1.   
    SH010429  SH010480         1.   
    SH010429  SH010482         1.   
    SH010429  SH010483         1.   
    SH010429  TRSH0401         1.   
    SH010430  SH010430        10.   
    SH010430  SH010432         1.   
    SH010430  SH010433         1.   
    SH010430  SH010434         1.   
    SH010430  SH010435         1.   
    SH010430  SH010437         1.   
    SH010430  SH010438         1.   
    SH010430  SH010440         1.   
    SH010430  SH010443         1.   
    SH010430  SH010445         1.   
    SH010430  SH010446         1.   
    SH010430  SH010452         1.   
    SH010430  SH010453         1.   
    SH010430  SH010455         1.   
    SH010430  SH010458         1.   
    SH010430  SH010459         1.   
    SH010430  SH010460         1.   
    SH010430  SH010464         1.   
    SH010430  SH010471         1.   
    SH010430  SH010473         1.   
    SH010430  SH010477         1.   
    SH010430  SH010478         1.   
    SH010430  SH010480         1.   
    SH010430  SH010482         1.   
    SH010430  SH010483         1.   
    SH010430  TRSH0401         1.   
    SH010131  SH010131        10.   
    SH010131  SH010133         1.   
    SH010131  SH010134         1.   
    SH010131  SH010137         1.   
    SH010131  SH010138         1.   
    SH010131  SH010139         1.   
    SH010131  SH010140         1.   
    SH010131  SH010142         1.   
    SH010131  SH010143         1.   
    SH010131  SH010145         1.   
    SH010131  SH010146         1.   
    SH010131  SH010147         1.   
    SH010131  SH010148         1.   
    SH010131  SH010149         1.   
    SH010131  SH010150         1.   
    SH010131  SH010151         1.   
    SH010131  SH010152         1.   
    SH010131  SH010153         1.   
    SH010131  SH010154         1.   
    SH010131  SH010155         1.   
    SH010131  SH010156         1.   
    SH010131  SH010157         1.   
    SH010131  SH010158         1.   
    SH010131  SH010159         1.   
    SH010131  SH010160         1.   
    SH010131  SH010163         1.   
    SH010131  SH010164         1.   
    SH010131  SH010171         1.   
    SH010131  SH010173         1.   
    SH010131  SH010177         1.   
    SH010131  SH010178         1.   
    SH010131  SH010182         1.   
    SH010131  SH010183         1.   
    SH010131  TRSH0101         1.   
    SH010432  SH010432        10.   
    SH010432  SH010433         1.   
    SH010432  SH010434         1.   
    SH010432  SH010435         1.   
    SH010432  SH010437         1.   
    SH010432  SH010438         1.   
    SH010432  SH010440         1.   
    SH010432  SH010443         1.   
    SH010432  SH010445         1.   
    SH010432  SH010446         1.   
    SH010432  SH010452         1.   
    SH010432  SH010453         1.   
    SH010432  SH010455         1.   
    SH010432  SH010458         1.   
    SH010432  SH010459         1.   
    SH010432  SH010460         1.   
    SH010432  SH010464         1.   
    SH010432  SH010471         1.   
    SH010432  SH010473         1.   
    SH010432  SH010477         1.   
    SH010432  SH010478         1.   
    SH010432  SH010480         1.   
    SH010432  SH010482         1.   
    SH010432  SH010483         1.   
    SH010432  TRSH0401         1.   
    SH010133  SH010133        10.   
    SH010133  SH010134         1.   
    SH010133  SH010137         1.   
    SH010133  SH010138         1.   
    SH010133  SH010139         1.   
    SH010133  SH010140         1.   
    SH010133  SH010142         1.   
    SH010133  SH010143         1.   
    SH010133  SH010145         1.   
    SH010133  SH010146         1.   
    SH010133  SH010147         1.   
    SH010133  SH010148         1.   
    SH010133  SH010149         1.   
    SH010133  SH010150         1.   
    SH010133  SH010151         1.   
    SH010133  SH010152         1.   
    SH010133  SH010153         1.   
    SH010133  SH010154         1.   
    SH010133  SH010155         1.   
    SH010133  SH010156         1.   
    SH010133  SH010157         1.   
    SH010133  SH010158         1.   
    SH010133  SH010159         1.   
    SH010133  SH010160         1.   
    SH010133  SH010163         1.   
    SH010133  SH010164         1.   
    SH010133  SH010171         1.   
    SH010133  SH010173         1.   
    SH010133  SH010177         1.   
    SH010133  SH010178         1.   
    SH010133  SH010182         1.   
    SH010133  SH010183         1.   
    SH010133  TRSH0101         1.   
    SH010233  SH010233        10.   
    SH010233  SH010234         1.   
    SH010233  SH010237         1.   
    SH010233  SH010238         1.   
    SH010233  SH010240         1.   
    SH010233  SH010243         1.   
    SH010233  SH010245         1.   
    SH010233  SH010246         1.   
    SH010233  SH010252         1.   
    SH010233  SH010253         1.   
    SH010233  SH010255         1.   
    SH010233  SH010258         1.   
    SH010233  SH010259         1.   
    SH010233  SH010260         1.   
    SH010233  SH010264         1.   
    SH010233  SH010265         1.   
    SH010233  SH010266         1.   
    SH010233  SH010267         1.   
    SH010233  SH010268         1.   
    SH010233  SH010269         1.   
    SH010233  SH010272         1.   
    SH010233  SH010273         1.   
    SH010233  SH010274         1.   
    SH010233  SH010275         1.   
    SH010233  SH010276         1.   
    SH010233  SH010277         1.   
    SH010233  SH010278         1.   
    SH010233  SH010279         1.   
    SH010233  SH010282         1.   
    SH010233  SH010283         1.   
    SH010233  SH010284         1.   
    SH010233  TRSH0201         1.   
    SH010333  SH010333        10.   
    SH010333  SH010334         1.   
    SH010333  SH010337         1.   
    SH010333  SH010338         1.   
    SH010333  SH010340         1.   
    SH010333  SH010343         1.   
    SH010333  SH010345         1.   
    SH010333  SH010346         1.   
    SH010333  SH010352         1.   
    SH010333  SH010353         1.   
    SH010333  SH010355         1.   
    SH010333  SH010358         1.   
    SH010333  SH010359         1.   
    SH010333  SH010360         1.   
    SH010333  SH010364         1.   
    SH010333  SH010371         1.   
    SH010333  SH010373         1.   
    SH010333  SH010377         1.   
    SH010333  SH010378         1.   
    SH010333  SH010382         1.   
    SH010333  SH010383         1.   
    SH010333  TRSH0301         1.   
    SH010433  SH010433        10.   
    SH010433  SH010434         1.   
    SH010433  SH010435         1.   
    SH010433  SH010437         1.   
    SH010433  SH010438         1.   
    SH010433  SH010440         1.   
    SH010433  SH010443         1.   
    SH010433  SH010445         1.   
    SH010433  SH010446         1.   
    SH010433  SH010452         1.   
    SH010433  SH010453         1.   
    SH010433  SH010455         1.   
    SH010433  SH010458         1.   
    SH010433  SH010459         1.   
    SH010433  SH010460         1.   
    SH010433  SH010464         1.   
    SH010433  SH010471         1.   
    SH010433  SH010473         1.   
    SH010433  SH010477         1.   
    SH010433  SH010478         1.   
    SH010433  SH010480         1.   
    SH010433  SH010482         1.   
    SH010433  SH010483         1.   
    SH010433  TRSH0401         1.   
    SH010533  SH010533        10.   
    SH010533  SH010534         1.   
    SH010533  SH010537         1.   
    SH010533  SH010538         1.   
    SH010533  SH010540         1.   
    SH010533  SH010543         1.   
    SH010533  SH010545         1.   
    SH010533  SH010546         1.   
    SH010533  SH010549         1.   
    SH010533  SH010551         1.   
    SH010533  SH010552         1.   
    SH010533  SH010553         1.   
    SH010533  SH010555         1.   
    SH010533  SH010556         1.   
    SH010533  SH010557         1.   
    SH010533  SH010558         1.   
    SH010533  SH010559         1.   
    SH010533  SH010560         1.   
    SH010533  SH010563         1.   
    SH010533  SH010564         1.   
    SH010533  SH010571         1.   
    SH010533  SH010573         1.   
    SH010533  SH010577         1.   
    SH010533  SH010578         1.   
    SH010533  SH010582         1.   
    SH010533  SH010583         1.   
    SH010533  TRSH0501         1.   
    SH010833  SH010833        10.   
    SH010833  SH010834         1.   
    SH010833  SH010837         1.   
    SH010833  SH010838         1.   
    SH010833  SH010840         1.   
    SH010833  SH010843         1.   
    SH010833  SH010845         1.   
    SH010833  SH010846         1.   
    SH010833  SH010852         1.   
    SH010833  SH010853         1.   
    SH010833  SH010855         1.   
    SH010833  SH010858         1.   
    SH010833  SH010859         1.   
    SH010833  SH010860         1.   
    SH010833  SH010864         1.   
    SH010833  SH010871         1.   
    SH010833  SH010873         1.   
    SH010833  SH010877         1.   
    SH010833  SH010878         1.   
    SH010833  SH010882         1.   
    SH010833  TRSH0801         1.   
    SH010134  SH010134        10.   
    SH010134  SH010137         1.   
    SH010134  SH010138         1.   
    SH010134  SH010139         1.   
    SH010134  SH010140         1.   
    SH010134  SH010142         1.   
    SH010134  SH010143         1.   
    SH010134  SH010145         1.   
    SH010134  SH010146         1.   
    SH010134  SH010147         1.   
    SH010134  SH010148         1.   
    SH010134  SH010149         1.   
    SH010134  SH010150         1.   
    SH010134  SH010151         1.   
    SH010134  SH010152         1.   
    SH010134  SH010153         1.   
    SH010134  SH010154         1.   
    SH010134  SH010155         1.   
    SH010134  SH010156         1.   
    SH010134  SH010157         1.   
    SH010134  SH010158         1.   
    SH010134  SH010159         1.   
    SH010134  SH010160         1.   
    SH010134  SH010163         1.   
    SH010134  SH010164         1.   
    SH010134  SH010171         1.   
    SH010134  SH010173         1.   
    SH010134  SH010177         1.   
    SH010134  SH010178         1.   
    SH010134  SH010182         1.   
    SH010134  SH010183         1.   
    SH010134  TRSH0101         1.   
    SH010234  SH010234        10.   
    SH010234  SH010237         1.   
    SH010234  SH010238         1.   
    SH010234  SH010240         1.   
    SH010234  SH010243         1.   
    SH010234  SH010245         1.   
    SH010234  SH010246         1.   
    SH010234  SH010252         1.   
    SH010234  SH010253         1.   
    SH010234  SH010255         1.   
    SH010234  SH010258         1.   
    SH010234  SH010259         1.   
    SH010234  SH010260         1.   
    SH010234  SH010264         1.   
    SH010234  SH010265         1.   
    SH010234  SH010266         1.   
    SH010234  SH010267         1.   
    SH010234  SH010268         1.   
    SH010234  SH010269         1.   
    SH010234  SH010272         1.   
    SH010234  SH010273         1.   
    SH010234  SH010274         1.   
    SH010234  SH010275         1.   
    SH010234  SH010276         1.   
    SH010234  SH010277         1.   
    SH010234  SH010278         1.   
    SH010234  SH010279         1.   
    SH010234  SH010282         1.   
    SH010234  SH010283         1.   
    SH010234  SH010284         1.   
    SH010234  TRSH0201         1.   
    SH010334  SH010334        10.   
    SH010334  SH010337         1.   
    SH010334  SH010338         1.   
    SH010334  SH010340         1.   
    SH010334  SH010343         1.   
    SH010334  SH010345         1.   
    SH010334  SH010346         1.   
    SH010334  SH010352         1.   
    SH010334  SH010353         1.   
    SH010334  SH010355         1.   
    SH010334  SH010358         1.   
    SH010334  SH010359         1.   
    SH010334  SH010360         1.   
    SH010334  SH010364         1.   
    SH010334  SH010371         1.   
    SH010334  SH010373         1.   
    SH010334  SH010377         1.   
    SH010334  SH010378         1.   
    SH010334  SH010382         1.   
    SH010334  SH010383         1.   
    SH010334  TRSH0301         1.   
    SH010434  SH010434        10.   
    SH010434  SH010435         1.   
    SH010434  SH010437         1.   
    SH010434  SH010438         1.   
    SH010434  SH010440         1.   
    SH010434  SH010443         1.   
    SH010434  SH010445         1.   
    SH010434  SH010446         1.   
    SH010434  SH010452         1.   
    SH010434  SH010453         1.   
    SH010434  SH010455         1.   
    SH010434  SH010458         1.   
    SH010434  SH010459         1.   
    SH010434  SH010460         1.   
    SH010434  SH010464         1.   
    SH010434  SH010471         1.   
    SH010434  SH010473         1.   
    SH010434  SH010477         1.   
    SH010434  SH010478         1.   
    SH010434  SH010480         1.   
    SH010434  SH010482         1.   
    SH010434  SH010483         1.   
    SH010434  TRSH0401         1.   
    SH010534  SH010534        10.   
    SH010534  SH010537         1.   
    SH010534  SH010538         1.   
    SH010534  SH010540         1.   
    SH010534  SH010543         1.   
    SH010534  SH010545         1.   
    SH010534  SH010546         1.   
    SH010534  SH010549         1.   
    SH010534  SH010551         1.   
    SH010534  SH010552         1.   
    SH010534  SH010553         1.   
    SH010534  SH010555         1.   
    SH010534  SH010556         1.   
    SH010534  SH010557         1.   
    SH010534  SH010558         1.   
    SH010534  SH010559         1.   
    SH010534  SH010560         1.   
    SH010534  SH010563         1.   
    SH010534  SH010564         1.   
    SH010534  SH010571         1.   
    SH010534  SH010573         1.   
    SH010534  SH010577         1.   
    SH010534  SH010578         1.   
    SH010534  SH010582         1.   
    SH010534  SH010583         1.   
    SH010534  TRSH0501         1.   
    SH010834  SH010834        10.   
    SH010834  SH010837         1.   
    SH010834  SH010838         1.   
    SH010834  SH010840         1.   
    SH010834  SH010843         1.   
    SH010834  SH010845         1.   
    SH010834  SH010846         1.   
    SH010834  SH010852         1.   
    SH010834  SH010853         1.   
    SH010834  SH010855         1.   
    SH010834  SH010858         1.   
    SH010834  SH010859         1.   
    SH010834  SH010860         1.   
    SH010834  SH010864         1.   
    SH010834  SH010871         1.   
    SH010834  SH010873         1.   
    SH010834  SH010877         1.   
    SH010834  SH010878         1.   
    SH010834  SH010882         1.   
    SH010834  TRSH0801         1.   
    SH010435  SH010435        10.   
    SH010435  SH010437         1.   
    SH010435  SH010438         1.   
    SH010435  SH010440         1.   
    SH010435  SH010443         1.   
    SH010435  SH010445         1.   
    SH010435  SH010446         1.   
    SH010435  SH010452         1.   
    SH010435  SH010453         1.   
    SH010435  SH010455         1.   
    SH010435  SH010458         1.   
    SH010435  SH010459         1.   
    SH010435  SH010460         1.   
    SH010435  SH010464         1.   
    SH010435  SH010471         1.   
    SH010435  SH010473         1.   
    SH010435  SH010477         1.   
    SH010435  SH010478         1.   
    SH010435  SH010480         1.   
    SH010435  SH010482         1.   
    SH010435  SH010483         1.   
    SH010435  TRSH0401         1.   
    SH010636  SH010636        10.   
    SH010636  SH010637         1.   
    SH010636  SH010638         1.   
    SH010636  SH010640         1.   
    SH010636  SH010641         1.   
    SH010636  SH010643         1.   
    SH010636  SH010644         1.   
    SH010636  SH010645         1.   
    SH010636  SH010646         1.   
    SH010636  SH010653         1.   
    SH010636  SH010655         1.   
    SH010636  SH010658         1.   
    SH010636  SH010659         1.   
    SH010636  SH010660         1.   
    SH010636  SH010664         1.   
    SH010636  SH010671         1.   
    SH010636  SH010673         1.   
    SH010636  SH010683         1.   
    SH010636  TRSH0601         1.   
    SH010137  SH010137        10.   
    SH010137  SH010138         1.   
    SH010137  SH010139         1.   
    SH010137  SH010140         1.   
    SH010137  SH010142         1.   
    SH010137  SH010143         1.   
    SH010137  SH010145         1.   
    SH010137  SH010146         1.   
    SH010137  SH010147         1.   
    SH010137  SH010148         1.   
    SH010137  SH010149         1.   
    SH010137  SH010150         1.   
    SH010137  SH010151         1.   
    SH010137  SH010152         1.   
    SH010137  SH010153         1.   
    SH010137  SH010154         1.   
    SH010137  SH010155         1.   
    SH010137  SH010156         1.   
    SH010137  SH010157         1.   
    SH010137  SH010158         1.   
    SH010137  SH010159         1.   
    SH010137  SH010160         1.   
    SH010137  SH010163         1.   
    SH010137  SH010164         1.   
    SH010137  SH010171         1.   
    SH010137  SH010173         1.   
    SH010137  SH010177         1.   
    SH010137  SH010178         1.   
    SH010137  SH010182         1.   
    SH010137  SH010183         1.   
    SH010137  TRSH0101         1.   
    SH010237  SH010237        10.   
    SH010237  SH010238         1.   
    SH010237  SH010240         1.   
    SH010237  SH010243         1.   
    SH010237  SH010245         1.   
    SH010237  SH010246         1.   
    SH010237  SH010252         1.   
    SH010237  SH010253         1.   
    SH010237  SH010255         1.   
    SH010237  SH010258         1.   
    SH010237  SH010259         1.   
    SH010237  SH010260         1.   
    SH010237  SH010264         1.   
    SH010237  SH010265         1.   
    SH010237  SH010266         1.   
    SH010237  SH010267         1.   
    SH010237  SH010268         1.   
    SH010237  SH010269         1.   
    SH010237  SH010272         1.   
    SH010237  SH010273         1.   
    SH010237  SH010274         1.   
    SH010237  SH010275         1.   
    SH010237  SH010276         1.   
    SH010237  SH010277         1.   
    SH010237  SH010278         1.   
    SH010237  SH010279         1.   
    SH010237  SH010282         1.   
    SH010237  SH010283         1.   
    SH010237  SH010284         1.   
    SH010237  TRSH0201         1.   
    SH010337  SH010337        10.   
    SH010337  SH010338         1.   
    SH010337  SH010340         1.   
    SH010337  SH010343         1.   
    SH010337  SH010345         1.   
    SH010337  SH010346         1.   
    SH010337  SH010352         1.   
    SH010337  SH010353         1.   
    SH010337  SH010355         1.   
    SH010337  SH010358         1.   
    SH010337  SH010359         1.   
    SH010337  SH010360         1.   
    SH010337  SH010364         1.   
    SH010337  SH010371         1.   
    SH010337  SH010373         1.   
    SH010337  SH010377         1.   
    SH010337  SH010378         1.   
    SH010337  SH010382         1.   
    SH010337  SH010383         1.   
    SH010337  TRSH0301         1.   
    SH010437  SH010437        10.   
    SH010437  SH010438         1.   
    SH010437  SH010440         1.   
    SH010437  SH010443         1.   
    SH010437  SH010445         1.   
    SH010437  SH010446         1.   
    SH010437  SH010452         1.   
    SH010437  SH010453         1.   
    SH010437  SH010455         1.   
    SH010437  SH010458         1.   
    SH010437  SH010459         1.   
    SH010437  SH010460         1.   
    SH010437  SH010464         1.   
    SH010437  SH010471         1.   
    SH010437  SH010473         1.   
    SH010437  SH010477         1.   
    SH010437  SH010478         1.   
    SH010437  SH010480         1.   
    SH010437  SH010482         1.   
    SH010437  SH010483         1.   
    SH010437  TRSH0401         1.   
    SH010537  SH010537        10.   
    SH010537  SH010538         1.   
    SH010537  SH010540         1.   
    SH010537  SH010543         1.   
    SH010537  SH010545         1.   
    SH010537  SH010546         1.   
    SH010537  SH010549         1.   
    SH010537  SH010551         1.   
    SH010537  SH010552         1.   
    SH010537  SH010553         1.   
    SH010537  SH010555         1.   
    SH010537  SH010556         1.   
    SH010537  SH010557         1.   
    SH010537  SH010558         1.   
    SH010537  SH010559         1.   
    SH010537  SH010560         1.   
    SH010537  SH010563         1.   
    SH010537  SH010564         1.   
    SH010537  SH010571         1.   
    SH010537  SH010573         1.   
    SH010537  SH010577         1.   
    SH010537  SH010578         1.   
    SH010537  SH010582         1.   
    SH010537  SH010583         1.   
    SH010537  TRSH0501         1.   
    SH010637  SH010637        10.   
    SH010637  SH010638         1.   
    SH010637  SH010640         1.   
    SH010637  SH010641         1.   
    SH010637  SH010643         1.   
    SH010637  SH010644         1.   
    SH010637  SH010645         1.   
    SH010637  SH010646         1.   
    SH010637  SH010653         1.   
    SH010637  SH010655         1.   
    SH010637  SH010658         1.   
    SH010637  SH010659         1.   
    SH010637  SH010660         1.   
    SH010637  SH010664         1.   
    SH010637  SH010671         1.   
    SH010637  SH010673         1.   
    SH010637  SH010683         1.   
    SH010637  TRSH0601         1.   
    SH010837  SH010837        10.   
    SH010837  SH010838         1.   
    SH010837  SH010840         1.   
    SH010837  SH010843         1.   
    SH010837  SH010845         1.   
    SH010837  SH010846         1.   
    SH010837  SH010852         1.   
    SH010837  SH010853         1.   
    SH010837  SH010855         1.   
    SH010837  SH010858         1.   
    SH010837  SH010859         1.   
    SH010837  SH010860         1.   
    SH010837  SH010864         1.   
    SH010837  SH010871         1.   
    SH010837  SH010873         1.   
    SH010837  SH010877         1.   
    SH010837  SH010878         1.   
    SH010837  SH010882         1.   
    SH010837  TRSH0801         1.   
    SH010138  SH010138        10.   
    SH010138  SH010139         1.   
    SH010138  SH010140         1.   
    SH010138  SH010142         1.   
    SH010138  SH010143         1.   
    SH010138  SH010145         1.   
    SH010138  SH010146         1.   
    SH010138  SH010147         1.   
    SH010138  SH010148         1.   
    SH010138  SH010149         1.   
    SH010138  SH010150         1.   
    SH010138  SH010151         1.   
    SH010138  SH010152         1.   
    SH010138  SH010153         1.   
    SH010138  SH010154         1.   
    SH010138  SH010155         1.   
    SH010138  SH010156         1.   
    SH010138  SH010157         1.   
    SH010138  SH010158         1.   
    SH010138  SH010159         1.   
    SH010138  SH010160         1.   
    SH010138  SH010163         1.   
    SH010138  SH010164         1.   
    SH010138  SH010171         1.   
    SH010138  SH010173         1.   
    SH010138  SH010177         1.   
    SH010138  SH010178         1.   
    SH010138  SH010182         1.   
    SH010138  SH010183         1.   
    SH010138  TRSH0101         1.   
    SH010238  SH010238        10.   
    SH010238  SH010240         1.   
    SH010238  SH010243         1.   
    SH010238  SH010245         1.   
    SH010238  SH010246         1.   
    SH010238  SH010252         1.   
    SH010238  SH010253         1.   
    SH010238  SH010255         1.   
    SH010238  SH010258         1.   
    SH010238  SH010259         1.   
    SH010238  SH010260         1.   
    SH010238  SH010264         1.   
    SH010238  SH010265         1.   
    SH010238  SH010266         1.   
    SH010238  SH010267         1.   
    SH010238  SH010268         1.   
    SH010238  SH010269         1.   
    SH010238  SH010272         1.   
    SH010238  SH010273         1.   
    SH010238  SH010274         1.   
    SH010238  SH010275         1.   
    SH010238  SH010276         1.   
    SH010238  SH010277         1.   
    SH010238  SH010278         1.   
    SH010238  SH010279         1.   
    SH010238  SH010282         1.   
    SH010238  SH010283         1.   
    SH010238  SH010284         1.   
    SH010238  TRSH0201         1.   
    SH010338  SH010338        10.   
    SH010338  SH010340         1.   
    SH010338  SH010343         1.   
    SH010338  SH010345         1.   
    SH010338  SH010346         1.   
    SH010338  SH010352         1.   
    SH010338  SH010353         1.   
    SH010338  SH010355         1.   
    SH010338  SH010358         1.   
    SH010338  SH010359         1.   
    SH010338  SH010360         1.   
    SH010338  SH010364         1.   
    SH010338  SH010371         1.   
    SH010338  SH010373         1.   
    SH010338  SH010377         1.   
    SH010338  SH010378         1.   
    SH010338  SH010382         1.   
    SH010338  SH010383         1.   
    SH010338  TRSH0301         1.   
    SH010438  SH010438        10.   
    SH010438  SH010440         1.   
    SH010438  SH010443         1.   
    SH010438  SH010445         1.   
    SH010438  SH010446         1.   
    SH010438  SH010452         1.   
    SH010438  SH010453         1.   
    SH010438  SH010455         1.   
    SH010438  SH010458         1.   
    SH010438  SH010459         1.   
    SH010438  SH010460         1.   
    SH010438  SH010464         1.   
    SH010438  SH010471         1.   
    SH010438  SH010473         1.   
    SH010438  SH010477         1.   
    SH010438  SH010478         1.   
    SH010438  SH010480         1.   
    SH010438  SH010482         1.   
    SH010438  SH010483         1.   
    SH010438  TRSH0401         1.   
    SH010538  SH010538        10.   
    SH010538  SH010540         1.   
    SH010538  SH010543         1.   
    SH010538  SH010545         1.   
    SH010538  SH010546         1.   
    SH010538  SH010549         1.   
    SH010538  SH010551         1.   
    SH010538  SH010552         1.   
    SH010538  SH010553         1.   
    SH010538  SH010555         1.   
    SH010538  SH010556         1.   
    SH010538  SH010557         1.   
    SH010538  SH010558         1.   
    SH010538  SH010559         1.   
    SH010538  SH010560         1.   
    SH010538  SH010563         1.   
    SH010538  SH010564         1.   
    SH010538  SH010571         1.   
    SH010538  SH010573         1.   
    SH010538  SH010577         1.   
    SH010538  SH010578         1.   
    SH010538  SH010582         1.   
    SH010538  SH010583         1.   
    SH010538  TRSH0501         1.   
    SH010638  SH010638        10.   
    SH010638  SH010640         1.   
    SH010638  SH010641         1.   
    SH010638  SH010643         1.   
    SH010638  SH010644         1.   
    SH010638  SH010645         1.   
    SH010638  SH010646         1.   
    SH010638  SH010653         1.   
    SH010638  SH010655         1.   
    SH010638  SH010658         1.   
    SH010638  SH010659         1.   
    SH010638  SH010660         1.   
    SH010638  SH010664         1.   
    SH010638  SH010671         1.   
    SH010638  SH010673         1.   
    SH010638  SH010683         1.   
    SH010638  TRSH0601         1.   
    SH010738  SH010738        10.   
    SH010738  SH010743         1.   
    SH010738  SH010745         1.   
    SH010738  SH010753         1.   
    SH010738  SH010755         1.   
    SH010738  SH010758         1.   
    SH010738  SH010759         1.   
    SH010738  SH010760         1.   
    SH010738  SH010771         1.   
    SH010738  TRSH0701         1.   
    SH010838  SH010838        10.   
    SH010838  SH010840         1.   
    SH010838  SH010843         1.   
    SH010838  SH010845         1.   
    SH010838  SH010846         1.   
    SH010838  SH010852         1.   
    SH010838  SH010853         1.   
    SH010838  SH010855         1.   
    SH010838  SH010858         1.   
    SH010838  SH010859         1.   
    SH010838  SH010860         1.   
    SH010838  SH010864         1.   
    SH010838  SH010871         1.   
    SH010838  SH010873         1.   
    SH010838  SH010877         1.   
    SH010838  SH010878         1.   
    SH010838  SH010882         1.   
    SH010838  TRSH0801         1.   
    SH010139  SH010139        10.   
    SH010139  SH010140         1.   
    SH010139  SH010142         1.   
    SH010139  SH010143         1.   
    SH010139  SH010145         1.   
    SH010139  SH010146         1.   
    SH010139  SH010147         1.   
    SH010139  SH010148         1.   
    SH010139  SH010149         1.   
    SH010139  SH010150         1.   
    SH010139  SH010151         1.   
    SH010139  SH010152         1.   
    SH010139  SH010153         1.   
    SH010139  SH010154         1.   
    SH010139  SH010155         1.   
    SH010139  SH010156         1.   
    SH010139  SH010157         1.   
    SH010139  SH010158         1.   
    SH010139  SH010159         1.   
    SH010139  SH010160         1.   
    SH010139  SH010163         1.   
    SH010139  SH010164         1.   
    SH010139  SH010171         1.   
    SH010139  SH010173         1.   
    SH010139  SH010177         1.   
    SH010139  SH010178         1.   
    SH010139  SH010182         1.   
    SH010139  SH010183         1.   
    SH010139  TRSH0101         1.   
    SH010140  SH010140        10.   
    SH010140  SH010142         1.   
    SH010140  SH010143         1.   
    SH010140  SH010145         1.   
    SH010140  SH010146         1.   
    SH010140  SH010147         1.   
    SH010140  SH010148         1.   
    SH010140  SH010149         1.   
    SH010140  SH010150         1.   
    SH010140  SH010151         1.   
    SH010140  SH010152         1.   
    SH010140  SH010153         1.   
    SH010140  SH010154         1.   
    SH010140  SH010155         1.   
    SH010140  SH010156         1.   
    SH010140  SH010157         1.   
    SH010140  SH010158         1.   
    SH010140  SH010159         1.   
    SH010140  SH010160         1.   
    SH010140  SH010163         1.   
    SH010140  SH010164         1.   
    SH010140  SH010171         1.   
    SH010140  SH010173         1.   
    SH010140  SH010177         1.   
    SH010140  SH010178         1.   
    SH010140  SH010182         1.   
    SH010140  SH010183         1.   
    SH010140  TRSH0101         1.   
    SH010240  SH010240        10.   
    SH010240  SH010243         1.   
    SH010240  SH010245         1.   
    SH010240  SH010246         1.   
    SH010240  SH010252         1.   
    SH010240  SH010253         1.   
    SH010240  SH010255         1.   
    SH010240  SH010258         1.   
    SH010240  SH010259         1.   
    SH010240  SH010260         1.   
    SH010240  SH010264         1.   
    SH010240  SH010265         1.   
    SH010240  SH010266         1.   
    SH010240  SH010267         1.   
    SH010240  SH010268         1.   
    SH010240  SH010269         1.   
    SH010240  SH010272         1.   
    SH010240  SH010273         1.   
    SH010240  SH010274         1.   
    SH010240  SH010275         1.   
    SH010240  SH010276         1.   
    SH010240  SH010277         1.   
    SH010240  SH010278         1.   
    SH010240  SH010279         1.   
    SH010240  SH010282         1.   
    SH010240  SH010283         1.   
    SH010240  SH010284         1.   
    SH010240  TRSH0201         1.   
    SH010340  SH010340        10.   
    SH010340  SH010343         1.   
    SH010340  SH010345         1.   
    SH010340  SH010346         1.   
    SH010340  SH010352         1.   
    SH010340  SH010353         1.   
    SH010340  SH010355         1.   
    SH010340  SH010358         1.   
    SH010340  SH010359         1.   
    SH010340  SH010360         1.   
    SH010340  SH010364         1.   
    SH010340  SH010371         1.   
    SH010340  SH010373         1.   
    SH010340  SH010377         1.   
    SH010340  SH010378         1.   
    SH010340  SH010382         1.   
    SH010340  SH010383         1.   
    SH010340  TRSH0301         1.   
    SH010440  SH010440        10.   
    SH010440  SH010443         1.   
    SH010440  SH010445         1.   
    SH010440  SH010446         1.   
    SH010440  SH010452         1.   
    SH010440  SH010453         1.   
    SH010440  SH010455         1.   
    SH010440  SH010458         1.   
    SH010440  SH010459         1.   
    SH010440  SH010460         1.   
    SH010440  SH010464         1.   
    SH010440  SH010471         1.   
    SH010440  SH010473         1.   
    SH010440  SH010477         1.   
    SH010440  SH010478         1.   
    SH010440  SH010480         1.   
    SH010440  SH010482         1.   
    SH010440  SH010483         1.   
    SH010440  TRSH0401         1.   
    SH010540  SH010540        10.   
    SH010540  SH010543         1.   
    SH010540  SH010545         1.   
    SH010540  SH010546         1.   
    SH010540  SH010549         1.   
    SH010540  SH010551         1.   
    SH010540  SH010552         1.   
    SH010540  SH010553         1.   
    SH010540  SH010555         1.   
    SH010540  SH010556         1.   
    SH010540  SH010557         1.   
    SH010540  SH010558         1.   
    SH010540  SH010559         1.   
    SH010540  SH010560         1.   
    SH010540  SH010563         1.   
    SH010540  SH010564         1.   
    SH010540  SH010571         1.   
    SH010540  SH010573         1.   
    SH010540  SH010577         1.   
    SH010540  SH010578         1.   
    SH010540  SH010582         1.   
    SH010540  SH010583         1.   
    SH010540  TRSH0501         1.   
    SH010640  SH010640        10.   
    SH010640  SH010641         1.   
    SH010640  SH010643         1.   
    SH010640  SH010644         1.   
    SH010640  SH010645         1.   
    SH010640  SH010646         1.   
    SH010640  SH010653         1.   
    SH010640  SH010655         1.   
    SH010640  SH010658         1.   
    SH010640  SH010659         1.   
    SH010640  SH010660         1.   
    SH010640  SH010664         1.   
    SH010640  SH010671         1.   
    SH010640  SH010673         1.   
    SH010640  SH010683         1.   
    SH010640  TRSH0601         1.   
    SH010840  SH010840        10.   
    SH010840  SH010843         1.   
    SH010840  SH010845         1.   
    SH010840  SH010846         1.   
    SH010840  SH010852         1.   
    SH010840  SH010853         1.   
    SH010840  SH010855         1.   
    SH010840  SH010858         1.   
    SH010840  SH010859         1.   
    SH010840  SH010860         1.   
    SH010840  SH010864         1.   
    SH010840  SH010871         1.   
    SH010840  SH010873         1.   
    SH010840  SH010877         1.   
    SH010840  SH010878         1.   
    SH010840  SH010882         1.   
    SH010840  TRSH0801         1.   
    SH010641  SH010641        10.   
    SH010641  SH010643         1.   
    SH010641  SH010644         1.   
    SH010641  SH010645         1.   
    SH010641  SH010646         1.   
    SH010641  SH010653         1.   
    SH010641  SH010655         1.   
    SH010641  SH010658         1.   
    SH010641  SH010659         1.   
    SH010641  SH010660         1.   
    SH010641  SH010664         1.   
    SH010641  SH010671         1.   
    SH010641  SH010673         1.   
    SH010641  SH010683         1.   
    SH010641  TRSH0601         1.   
    SH010142  SH010142        10.   
    SH010142  SH010143         1.   
    SH010142  SH010145         1.   
    SH010142  SH010146         1.   
    SH010142  SH010147         1.   
    SH010142  SH010148         1.   
    SH010142  SH010149         1.   
    SH010142  SH010150         1.   
    SH010142  SH010151         1.   
    SH010142  SH010152         1.   
    SH010142  SH010153         1.   
    SH010142  SH010154         1.   
    SH010142  SH010155         1.   
    SH010142  SH010156         1.   
    SH010142  SH010157         1.   
    SH010142  SH010158         1.   
    SH010142  SH010159         1.   
    SH010142  SH010160         1.   
    SH010142  SH010163         1.   
    SH010142  SH010164         1.   
    SH010142  SH010171         1.   
    SH010142  SH010173         1.   
    SH010142  SH010177         1.   
    SH010142  SH010178         1.   
    SH010142  SH010182         1.   
    SH010142  SH010183         1.   
    SH010142  TRSH0101         1.   
    SH010143  SH010143        10.   
    SH010143  SH010145         1.   
    SH010143  SH010146         1.   
    SH010143  SH010147         1.   
    SH010143  SH010148         1.   
    SH010143  SH010149         1.   
    SH010143  SH010150         1.   
    SH010143  SH010151         1.   
    SH010143  SH010152         1.   
    SH010143  SH010153         1.   
    SH010143  SH010154         1.   
    SH010143  SH010155         1.   
    SH010143  SH010156         1.   
    SH010143  SH010157         1.   
    SH010143  SH010158         1.   
    SH010143  SH010159         1.   
    SH010143  SH010160         1.   
    SH010143  SH010163         1.   
    SH010143  SH010164         1.   
    SH010143  SH010171         1.   
    SH010143  SH010173         1.   
    SH010143  SH010177         1.   
    SH010143  SH010178         1.   
    SH010143  SH010182         1.   
    SH010143  SH010183         1.   
    SH010143  TRSH0101         1.   
    SH010243  SH010243        10.   
    SH010243  SH010245         1.   
    SH010243  SH010246         1.   
    SH010243  SH010252         1.   
    SH010243  SH010253         1.   
    SH010243  SH010255         1.   
    SH010243  SH010258         1.   
    SH010243  SH010259         1.   
    SH010243  SH010260         1.   
    SH010243  SH010264         1.   
    SH010243  SH010265         1.   
    SH010243  SH010266         1.   
    SH010243  SH010267         1.   
    SH010243  SH010268         1.   
    SH010243  SH010269         1.   
    SH010243  SH010272         1.   
    SH010243  SH010273         1.   
    SH010243  SH010274         1.   
    SH010243  SH010275         1.   
    SH010243  SH010276         1.   
    SH010243  SH010277         1.   
    SH010243  SH010278         1.   
    SH010243  SH010279         1.   
    SH010243  SH010282         1.   
    SH010243  SH010283         1.   
    SH010243  SH010284         1.   
    SH010243  TRSH0201         1.   
    SH010343  SH010343        10.   
    SH010343  SH010345         1.   
    SH010343  SH010346         1.   
    SH010343  SH010352         1.   
    SH010343  SH010353         1.   
    SH010343  SH010355         1.   
    SH010343  SH010358         1.   
    SH010343  SH010359         1.   
    SH010343  SH010360         1.   
    SH010343  SH010364         1.   
    SH010343  SH010371         1.   
    SH010343  SH010373         1.   
    SH010343  SH010377         1.   
    SH010343  SH010378         1.   
    SH010343  SH010382         1.   
    SH010343  SH010383         1.   
    SH010343  TRSH0301         1.   
    SH010443  SH010443        10.   
    SH010443  SH010445         1.   
    SH010443  SH010446         1.   
    SH010443  SH010452         1.   
    SH010443  SH010453         1.   
    SH010443  SH010455         1.   
    SH010443  SH010458         1.   
    SH010443  SH010459         1.   
    SH010443  SH010460         1.   
    SH010443  SH010464         1.   
    SH010443  SH010471         1.   
    SH010443  SH010473         1.   
    SH010443  SH010477         1.   
    SH010443  SH010478         1.   
    SH010443  SH010480         1.   
    SH010443  SH010482         1.   
    SH010443  SH010483         1.   
    SH010443  TRSH0401         1.   
    SH010543  SH010543        10.   
    SH010543  SH010545         1.   
    SH010543  SH010546         1.   
    SH010543  SH010549         1.   
    SH010543  SH010551         1.   
    SH010543  SH010552         1.   
    SH010543  SH010553         1.   
    SH010543  SH010555         1.   
    SH010543  SH010556         1.   
    SH010543  SH010557         1.   
    SH010543  SH010558         1.   
    SH010543  SH010559         1.   
    SH010543  SH010560         1.   
    SH010543  SH010563         1.   
    SH010543  SH010564         1.   
    SH010543  SH010571         1.   
    SH010543  SH010573         1.   
    SH010543  SH010577         1.   
    SH010543  SH010578         1.   
    SH010543  SH010582         1.   
    SH010543  SH010583         1.   
    SH010543  TRSH0501         1.   
    SH010643  SH010643        10.   
    SH010643  SH010644         1.   
    SH010643  SH010645         1.   
    SH010643  SH010646         1.   
    SH010643  SH010653         1.   
    SH010643  SH010655         1.   
    SH010643  SH010658         1.   
    SH010643  SH010659         1.   
    SH010643  SH010660         1.   
    SH010643  SH010664         1.   
    SH010643  SH010671         1.   
    SH010643  SH010673         1.   
    SH010643  SH010683         1.   
    SH010643  TRSH0601         1.   
    SH010743  SH010743        10.   
    SH010743  SH010745         1.   
    SH010743  SH010753         1.   
    SH010743  SH010755         1.   
    SH010743  SH010758         1.   
    SH010743  SH010759         1.   
    SH010743  SH010760         1.   
    SH010743  SH010771         1.   
    SH010743  TRSH0701         1.   
    SH010843  SH010843        10.   
    SH010843  SH010845         1.   
    SH010843  SH010846         1.   
    SH010843  SH010852         1.   
    SH010843  SH010853         1.   
    SH010843  SH010855         1.   
    SH010843  SH010858         1.   
    SH010843  SH010859         1.   
    SH010843  SH010860         1.   
    SH010843  SH010864         1.   
    SH010843  SH010871         1.   
    SH010843  SH010873         1.   
    SH010843  SH010877         1.   
    SH010843  SH010878         1.   
    SH010843  SH010882         1.   
    SH010843  TRSH0801         1.   
    SH010644  SH010644        10.   
    SH010644  SH010645         1.   
    SH010644  SH010646         1.   
    SH010644  SH010653         1.   
    SH010644  SH010655         1.   
    SH010644  SH010658         1.   
    SH010644  SH010659         1.   
    SH010644  SH010660         1.   
    SH010644  SH010664         1.   
    SH010644  SH010671         1.   
    SH010644  SH010673         1.   
    SH010644  SH010683         1.   
    SH010644  TRSH0601         1.   
    SH010145  SH010145        10.   
    SH010145  SH010146         1.   
    SH010145  SH010147         1.   
    SH010145  SH010148         1.   
    SH010145  SH010149         1.   
    SH010145  SH010150         1.   
    SH010145  SH010151         1.   
    SH010145  SH010152         1.   
    SH010145  SH010153         1.   
    SH010145  SH010154         1.   
    SH010145  SH010155         1.   
    SH010145  SH010156         1.   
    SH010145  SH010157         1.   
    SH010145  SH010158         1.   
    SH010145  SH010159         1.   
    SH010145  SH010160         1.   
    SH010145  SH010163         1.   
    SH010145  SH010164         1.   
    SH010145  SH010171         1.   
    SH010145  SH010173         1.   
    SH010145  SH010177         1.   
    SH010145  SH010178         1.   
    SH010145  SH010182         1.   
    SH010145  SH010183         1.   
    SH010145  TRSH0101         1.   
    SH010245  SH010245        10.   
    SH010245  SH010246         1.   
    SH010245  SH010252         1.   
    SH010245  SH010253         1.   
    SH010245  SH010255         1.   
    SH010245  SH010258         1.   
    SH010245  SH010259         1.   
    SH010245  SH010260         1.   
    SH010245  SH010264         1.   
    SH010245  SH010265         1.   
    SH010245  SH010266         1.   
    SH010245  SH010267         1.   
    SH010245  SH010268         1.   
    SH010245  SH010269         1.   
    SH010245  SH010272         1.   
    SH010245  SH010273         1.   
    SH010245  SH010274         1.   
    SH010245  SH010275         1.   
    SH010245  SH010276         1.   
    SH010245  SH010277         1.   
    SH010245  SH010278         1.   
    SH010245  SH010279         1.   
    SH010245  SH010282         1.   
    SH010245  SH010283         1.   
    SH010245  SH010284         1.   
    SH010245  TRSH0201         1.   
    SH010345  SH010345        10.   
    SH010345  SH010346         1.   
    SH010345  SH010352         1.   
    SH010345  SH010353         1.   
    SH010345  SH010355         1.   
    SH010345  SH010358         1.   
    SH010345  SH010359         1.   
    SH010345  SH010360         1.   
    SH010345  SH010364         1.   
    SH010345  SH010371         1.   
    SH010345  SH010373         1.   
    SH010345  SH010377         1.   
    SH010345  SH010378         1.   
    SH010345  SH010382         1.   
    SH010345  SH010383         1.   
    SH010345  TRSH0301         1.   
    SH010445  SH010445        10.   
    SH010445  SH010446         1.   
    SH010445  SH010452         1.   
    SH010445  SH010453         1.   
    SH010445  SH010455         1.   
    SH010445  SH010458         1.   
    SH010445  SH010459         1.   
    SH010445  SH010460         1.   
    SH010445  SH010464         1.   
    SH010445  SH010471         1.   
    SH010445  SH010473         1.   
    SH010445  SH010477         1.   
    SH010445  SH010478         1.   
    SH010445  SH010480         1.   
    SH010445  SH010482         1.   
    SH010445  SH010483         1.   
    SH010445  TRSH0401         1.   
    SH010545  SH010545        10.   
    SH010545  SH010546         1.   
    SH010545  SH010549         1.   
    SH010545  SH010551         1.   
    SH010545  SH010552         1.   
    SH010545  SH010553         1.   
    SH010545  SH010555         1.   
    SH010545  SH010556         1.   
    SH010545  SH010557         1.   
    SH010545  SH010558         1.   
    SH010545  SH010559         1.   
    SH010545  SH010560         1.   
    SH010545  SH010563         1.   
    SH010545  SH010564         1.   
    SH010545  SH010571         1.   
    SH010545  SH010573         1.   
    SH010545  SH010577         1.   
    SH010545  SH010578         1.   
    SH010545  SH010582         1.   
    SH010545  SH010583         1.   
    SH010545  TRSH0501         1.   
    SH010645  SH010645        10.   
    SH010645  SH010646         1.   
    SH010645  SH010653         1.   
    SH010645  SH010655         1.   
    SH010645  SH010658         1.   
    SH010645  SH010659         1.   
    SH010645  SH010660         1.   
    SH010645  SH010664         1.   
    SH010645  SH010671         1.   
    SH010645  SH010673         1.   
    SH010645  SH010683         1.   
    SH010645  TRSH0601         1.   
    SH010745  SH010745        10.   
    SH010745  SH010753         1.   
    SH010745  SH010755         1.   
    SH010745  SH010758         1.   
    SH010745  SH010759         1.   
    SH010745  SH010760         1.   
    SH010745  SH010771         1.   
    SH010745  TRSH0701         1.   
    SH010845  SH010845        10.   
    SH010845  SH010846         1.   
    SH010845  SH010852         1.   
    SH010845  SH010853         1.   
    SH010845  SH010855         1.   
    SH010845  SH010858         1.   
    SH010845  SH010859         1.   
    SH010845  SH010860         1.   
    SH010845  SH010864         1.   
    SH010845  SH010871         1.   
    SH010845  SH010873         1.   
    SH010845  SH010877         1.   
    SH010845  SH010878         1.   
    SH010845  SH010882         1.   
    SH010845  TRSH0801         1.   
    SH010146  SH010146        10.   
    SH010146  SH010147         1.   
    SH010146  SH010148         1.   
    SH010146  SH010149         1.   
    SH010146  SH010150         1.   
    SH010146  SH010151         1.   
    SH010146  SH010152         1.   
    SH010146  SH010153         1.   
    SH010146  SH010154         1.   
    SH010146  SH010155         1.   
    SH010146  SH010156         1.   
    SH010146  SH010157         1.   
    SH010146  SH010158         1.   
    SH010146  SH010159         1.   
    SH010146  SH010160         1.   
    SH010146  SH010163         1.   
    SH010146  SH010164         1.   
    SH010146  SH010171         1.   
    SH010146  SH010173         1.   
    SH010146  SH010177         1.   
    SH010146  SH010178         1.   
    SH010146  SH010182         1.   
    SH010146  SH010183         1.   
    SH010146  TRSH0101         1.   
    SH010246  SH010246        10.   
    SH010246  SH010252         1.   
    SH010246  SH010253         1.   
    SH010246  SH010255         1.   
    SH010246  SH010258         1.   
    SH010246  SH010259         1.   
    SH010246  SH010260         1.   
    SH010246  SH010264         1.   
    SH010246  SH010265         1.   
    SH010246  SH010266         1.   
    SH010246  SH010267         1.   
    SH010246  SH010268         1.   
    SH010246  SH010269         1.   
    SH010246  SH010272         1.   
    SH010246  SH010273         1.   
    SH010246  SH010274         1.   
    SH010246  SH010275         1.   
    SH010246  SH010276         1.   
    SH010246  SH010277         1.   
    SH010246  SH010278         1.   
    SH010246  SH010279         1.   
    SH010246  SH010282         1.   
    SH010246  SH010283         1.   
    SH010246  SH010284         1.   
    SH010246  TRSH0201         1.   
    SH010346  SH010346        10.   
    SH010346  SH010352         1.   
    SH010346  SH010353         1.   
    SH010346  SH010355         1.   
    SH010346  SH010358         1.   
    SH010346  SH010359         1.   
    SH010346  SH010360         1.   
    SH010346  SH010364         1.   
    SH010346  SH010371         1.   
    SH010346  SH010373         1.   
    SH010346  SH010377         1.   
    SH010346  SH010378         1.   
    SH010346  SH010382         1.   
    SH010346  SH010383         1.   
    SH010346  TRSH0301         1.   
    SH010446  SH010446        10.   
    SH010446  SH010452         1.   
    SH010446  SH010453         1.   
    SH010446  SH010455         1.   
    SH010446  SH010458         1.   
    SH010446  SH010459         1.   
    SH010446  SH010460         1.   
    SH010446  SH010464         1.   
    SH010446  SH010471         1.   
    SH010446  SH010473         1.   
    SH010446  SH010477         1.   
    SH010446  SH010478         1.   
    SH010446  SH010480         1.   
    SH010446  SH010482         1.   
    SH010446  SH010483         1.   
    SH010446  TRSH0401         1.   
    SH010546  SH010546        10.   
    SH010546  SH010549         1.   
    SH010546  SH010551         1.   
    SH010546  SH010552         1.   
    SH010546  SH010553         1.   
    SH010546  SH010555         1.   
    SH010546  SH010556         1.   
    SH010546  SH010557         1.   
    SH010546  SH010558         1.   
    SH010546  SH010559         1.   
    SH010546  SH010560         1.   
    SH010546  SH010563         1.   
    SH010546  SH010564         1.   
    SH010546  SH010571         1.   
    SH010546  SH010573         1.   
    SH010546  SH010577         1.   
    SH010546  SH010578         1.   
    SH010546  SH010582         1.   
    SH010546  SH010583         1.   
    SH010546  TRSH0501         1.   
    SH010646  SH010646        10.   
    SH010646  SH010653         1.   
    SH010646  SH010655         1.   
    SH010646  SH010658         1.   
    SH010646  SH010659         1.   
    SH010646  SH010660         1.   
    SH010646  SH010664         1.   
    SH010646  SH010671         1.   
    SH010646  SH010673         1.   
    SH010646  SH010683         1.   
    SH010646  TRSH0601         1.   
    SH010846  SH010846        10.   
    SH010846  SH010852         1.   
    SH010846  SH010853         1.   
    SH010846  SH010855         1.   
    SH010846  SH010858         1.   
    SH010846  SH010859         1.   
    SH010846  SH010860         1.   
    SH010846  SH010864         1.   
    SH010846  SH010871         1.   
    SH010846  SH010873         1.   
    SH010846  SH010877         1.   
    SH010846  SH010878         1.   
    SH010846  SH010882         1.   
    SH010846  TRSH0801         1.   
    SH010147  SH010147        10.   
    SH010147  SH010148         1.   
    SH010147  SH010149         1.   
    SH010147  SH010150         1.   
    SH010147  SH010151         1.   
    SH010147  SH010152         1.   
    SH010147  SH010153         1.   
    SH010147  SH010154         1.   
    SH010147  SH010155         1.   
    SH010147  SH010156         1.   
    SH010147  SH010157         1.   
    SH010147  SH010158         1.   
    SH010147  SH010159         1.   
    SH010147  SH010160         1.   
    SH010147  SH010163         1.   
    SH010147  SH010164         1.   
    SH010147  SH010171         1.   
    SH010147  SH010173         1.   
    SH010147  SH010177         1.   
    SH010147  SH010178         1.   
    SH010147  SH010182         1.   
    SH010147  SH010183         1.   
    SH010147  TRSH0101         1.   
    SH010148  SH010148        10.   
    SH010148  SH010149         1.   
    SH010148  SH010150         1.   
    SH010148  SH010151         1.   
    SH010148  SH010152         1.   
    SH010148  SH010153         1.   
    SH010148  SH010154         1.   
    SH010148  SH010155         1.   
    SH010148  SH010156         1.   
    SH010148  SH010157         1.   
    SH010148  SH010158         1.   
    SH010148  SH010159         1.   
    SH010148  SH010160         1.   
    SH010148  SH010163         1.   
    SH010148  SH010164         1.   
    SH010148  SH010171         1.   
    SH010148  SH010173         1.   
    SH010148  SH010177         1.   
    SH010148  SH010178         1.   
    SH010148  SH010182         1.   
    SH010148  SH010183         1.   
    SH010148  TRSH0101         1.   
    SH010149  SH010149        10.   
    SH010149  SH010150         1.   
    SH010149  SH010151         1.   
    SH010149  SH010152         1.   
    SH010149  SH010153         1.   
    SH010149  SH010154         1.   
    SH010149  SH010155         1.   
    SH010149  SH010156         1.   
    SH010149  SH010157         1.   
    SH010149  SH010158         1.   
    SH010149  SH010159         1.   
    SH010149  SH010160         1.   
    SH010149  SH010163         1.   
    SH010149  SH010164         1.   
    SH010149  SH010171         1.   
    SH010149  SH010173         1.   
    SH010149  SH010177         1.   
    SH010149  SH010178         1.   
    SH010149  SH010182         1.   
    SH010149  SH010183         1.   
    SH010149  TRSH0101         1.   
    SH010549  SH010549        10.   
    SH010549  SH010551         1.   
    SH010549  SH010552         1.   
    SH010549  SH010553         1.   
    SH010549  SH010555         1.   
    SH010549  SH010556         1.   
    SH010549  SH010557         1.   
    SH010549  SH010558         1.   
    SH010549  SH010559         1.   
    SH010549  SH010560         1.   
    SH010549  SH010563         1.   
    SH010549  SH010564         1.   
    SH010549  SH010571         1.   
    SH010549  SH010573         1.   
    SH010549  SH010577         1.   
    SH010549  SH010578         1.   
    SH010549  SH010582         1.   
    SH010549  SH010583         1.   
    SH010549  TRSH0501         1.   
    SH010150  SH010150        10.   
    SH010150  SH010151         1.   
    SH010150  SH010152         1.   
    SH010150  SH010153         1.   
    SH010150  SH010154         1.   
    SH010150  SH010155         1.   
    SH010150  SH010156         1.   
    SH010150  SH010157         1.   
    SH010150  SH010158         1.   
    SH010150  SH010159         1.   
    SH010150  SH010160         1.   
    SH010150  SH010163         1.   
    SH010150  SH010164         1.   
    SH010150  SH010171         1.   
    SH010150  SH010173         1.   
    SH010150  SH010177         1.   
    SH010150  SH010178         1.   
    SH010150  SH010182         1.   
    SH010150  SH010183         1.   
    SH010150  TRSH0101         1.   
    SH010151  SH010151        10.   
    SH010151  SH010152         1.   
    SH010151  SH010153         1.   
    SH010151  SH010154         1.   
    SH010151  SH010155         1.   
    SH010151  SH010156         1.   
    SH010151  SH010157         1.   
    SH010151  SH010158         1.   
    SH010151  SH010159         1.   
    SH010151  SH010160         1.   
    SH010151  SH010163         1.   
    SH010151  SH010164         1.   
    SH010151  SH010171         1.   
    SH010151  SH010173         1.   
    SH010151  SH010177         1.   
    SH010151  SH010178         1.   
    SH010151  SH010182         1.   
    SH010151  SH010183         1.   
    SH010151  TRSH0101         1.   
    SH010551  SH010551        10.   
    SH010551  SH010552         1.   
    SH010551  SH010553         1.   
    SH010551  SH010555         1.   
    SH010551  SH010556         1.   
    SH010551  SH010557         1.   
    SH010551  SH010558         1.   
    SH010551  SH010559         1.   
    SH010551  SH010560         1.   
    SH010551  SH010563         1.   
    SH010551  SH010564         1.   
    SH010551  SH010571         1.   
    SH010551  SH010573         1.   
    SH010551  SH010577         1.   
    SH010551  SH010578         1.   
    SH010551  SH010582         1.   
    SH010551  SH010583         1.   
    SH010551  TRSH0501         1.   
    SH010152  SH010152        10.   
    SH010152  SH010153         1.   
    SH010152  SH010154         1.   
    SH010152  SH010155         1.   
    SH010152  SH010156         1.   
    SH010152  SH010157         1.   
    SH010152  SH010158         1.   
    SH010152  SH010159         1.   
    SH010152  SH010160         1.   
    SH010152  SH010163         1.   
    SH010152  SH010164         1.   
    SH010152  SH010171         1.   
    SH010152  SH010173         1.   
    SH010152  SH010177         1.   
    SH010152  SH010178         1.   
    SH010152  SH010182         1.   
    SH010152  SH010183         1.   
    SH010152  TRSH0101         1.   
    SH010252  SH010252        10.   
    SH010252  SH010253         1.   
    SH010252  SH010255         1.   
    SH010252  SH010258         1.   
    SH010252  SH010259         1.   
    SH010252  SH010260         1.   
    SH010252  SH010264         1.   
    SH010252  SH010265         1.   
    SH010252  SH010266         1.   
    SH010252  SH010267         1.   
    SH010252  SH010268         1.   
    SH010252  SH010269         1.   
    SH010252  SH010272         1.   
    SH010252  SH010273         1.   
    SH010252  SH010274         1.   
    SH010252  SH010275         1.   
    SH010252  SH010276         1.   
    SH010252  SH010277         1.   
    SH010252  SH010278         1.   
    SH010252  SH010279         1.   
    SH010252  SH010282         1.   
    SH010252  SH010283         1.   
    SH010252  SH010284         1.   
    SH010252  TRSH0201         1.   
    SH010352  SH010352        10.   
    SH010352  SH010353         1.   
    SH010352  SH010355         1.   
    SH010352  SH010358         1.   
    SH010352  SH010359         1.   
    SH010352  SH010360         1.   
    SH010352  SH010364         1.   
    SH010352  SH010371         1.   
    SH010352  SH010373         1.   
    SH010352  SH010377         1.   
    SH010352  SH010378         1.   
    SH010352  SH010382         1.   
    SH010352  SH010383         1.   
    SH010352  TRSH0301         1.   
    SH010452  SH010452        10.   
    SH010452  SH010453         1.   
    SH010452  SH010455         1.   
    SH010452  SH010458         1.   
    SH010452  SH010459         1.   
    SH010452  SH010460         1.   
    SH010452  SH010464         1.   
    SH010452  SH010471         1.   
    SH010452  SH010473         1.   
    SH010452  SH010477         1.   
    SH010452  SH010478         1.   
    SH010452  SH010480         1.   
    SH010452  SH010482         1.   
    SH010452  SH010483         1.   
    SH010452  TRSH0401         1.   
    SH010552  SH010552        10.   
    SH010552  SH010553         1.   
    SH010552  SH010555         1.   
    SH010552  SH010556         1.   
    SH010552  SH010557         1.   
    SH010552  SH010558         1.   
    SH010552  SH010559         1.   
    SH010552  SH010560         1.   
    SH010552  SH010563         1.   
    SH010552  SH010564         1.   
    SH010552  SH010571         1.   
    SH010552  SH010573         1.   
    SH010552  SH010577         1.   
    SH010552  SH010578         1.   
    SH010552  SH010582         1.   
    SH010552  SH010583         1.   
    SH010552  TRSH0501         1.   
    SH010852  SH010852        10.   
    SH010852  SH010853         1.   
    SH010852  SH010855         1.   
    SH010852  SH010858         1.   
    SH010852  SH010859         1.   
    SH010852  SH010860         1.   
    SH010852  SH010864         1.   
    SH010852  SH010871         1.   
    SH010852  SH010873         1.   
    SH010852  SH010877         1.   
    SH010852  SH010878         1.   
    SH010852  SH010882         1.   
    SH010852  TRSH0801         1.   
    SH010153  SH010153        10.   
    SH010153  SH010154         1.   
    SH010153  SH010155         1.   
    SH010153  SH010156         1.   
    SH010153  SH010157         1.   
    SH010153  SH010158         1.   
    SH010153  SH010159         1.   
    SH010153  SH010160         1.   
    SH010153  SH010163         1.   
    SH010153  SH010164         1.   
    SH010153  SH010171         1.   
    SH010153  SH010173         1.   
    SH010153  SH010177         1.   
    SH010153  SH010178         1.   
    SH010153  SH010182         1.   
    SH010153  SH010183         1.   
    SH010153  TRSH0101         1.   
    SH010253  SH010253        10.   
    SH010253  SH010255         1.   
    SH010253  SH010258         1.   
    SH010253  SH010259         1.   
    SH010253  SH010260         1.   
    SH010253  SH010264         1.   
    SH010253  SH010265         1.   
    SH010253  SH010266         1.   
    SH010253  SH010267         1.   
    SH010253  SH010268         1.   
    SH010253  SH010269         1.   
    SH010253  SH010272         1.   
    SH010253  SH010273         1.   
    SH010253  SH010274         1.   
    SH010253  SH010275         1.   
    SH010253  SH010276         1.   
    SH010253  SH010277         1.   
    SH010253  SH010278         1.   
    SH010253  SH010279         1.   
    SH010253  SH010282         1.   
    SH010253  SH010283         1.   
    SH010253  SH010284         1.   
    SH010253  TRSH0201         1.   
    SH010353  SH010353        10.   
    SH010353  SH010355         1.   
    SH010353  SH010358         1.   
    SH010353  SH010359         1.   
    SH010353  SH010360         1.   
    SH010353  SH010364         1.   
    SH010353  SH010371         1.   
    SH010353  SH010373         1.   
    SH010353  SH010377         1.   
    SH010353  SH010378         1.   
    SH010353  SH010382         1.   
    SH010353  SH010383         1.   
    SH010353  TRSH0301         1.   
    SH010453  SH010453        10.   
    SH010453  SH010455         1.   
    SH010453  SH010458         1.   
    SH010453  SH010459         1.   
    SH010453  SH010460         1.   
    SH010453  SH010464         1.   
    SH010453  SH010471         1.   
    SH010453  SH010473         1.   
    SH010453  SH010477         1.   
    SH010453  SH010478         1.   
    SH010453  SH010480         1.   
    SH010453  SH010482         1.   
    SH010453  SH010483         1.   
    SH010453  TRSH0401         1.   
    SH010553  SH010553        10.   
    SH010553  SH010555         1.   
    SH010553  SH010556         1.   
    SH010553  SH010557         1.   
    SH010553  SH010558         1.   
    SH010553  SH010559         1.   
    SH010553  SH010560         1.   
    SH010553  SH010563         1.   
    SH010553  SH010564         1.   
    SH010553  SH010571         1.   
    SH010553  SH010573         1.   
    SH010553  SH010577         1.   
    SH010553  SH010578         1.   
    SH010553  SH010582         1.   
    SH010553  SH010583         1.   
    SH010553  TRSH0501         1.   
    SH010653  SH010653        10.   
    SH010653  SH010655         1.   
    SH010653  SH010658         1.   
    SH010653  SH010659         1.   
    SH010653  SH010660         1.   
    SH010653  SH010664         1.   
    SH010653  SH010671         1.   
    SH010653  SH010673         1.   
    SH010653  SH010683         1.   
    SH010653  TRSH0601         1.   
    SH010753  SH010753        10.   
    SH010753  SH010755         1.   
    SH010753  SH010758         1.   
    SH010753  SH010759         1.   
    SH010753  SH010760         1.   
    SH010753  SH010771         1.   
    SH010753  TRSH0701         1.   
    SH010853  SH010853        10.   
    SH010853  SH010855         1.   
    SH010853  SH010858         1.   
    SH010853  SH010859         1.   
    SH010853  SH010860         1.   
    SH010853  SH010864         1.   
    SH010853  SH010871         1.   
    SH010853  SH010873         1.   
    SH010853  SH010877         1.   
    SH010853  SH010878         1.   
    SH010853  SH010882         1.   
    SH010853  TRSH0801         1.   
    SH010154  SH010154        10.   
    SH010154  SH010155         1.   
    SH010154  SH010156         1.   
    SH010154  SH010157         1.   
    SH010154  SH010158         1.   
    SH010154  SH010159         1.   
    SH010154  SH010160         1.   
    SH010154  SH010163         1.   
    SH010154  SH010164         1.   
    SH010154  SH010171         1.   
    SH010154  SH010173         1.   
    SH010154  SH010177         1.   
    SH010154  SH010178         1.   
    SH010154  SH010182         1.   
    SH010154  SH010183         1.   
    SH010154  TRSH0101         1.   
    SH010155  SH010155        10.   
    SH010155  SH010156         1.   
    SH010155  SH010157         1.   
    SH010155  SH010158         1.   
    SH010155  SH010159         1.   
    SH010155  SH010160         1.   
    SH010155  SH010163         1.   
    SH010155  SH010164         1.   
    SH010155  SH010171         1.   
    SH010155  SH010173         1.   
    SH010155  SH010177         1.   
    SH010155  SH010178         1.   
    SH010155  SH010182         1.   
    SH010155  SH010183         1.   
    SH010155  TRSH0101         1.   
    SH010255  SH010255        10.   
    SH010255  SH010258         1.   
    SH010255  SH010259         1.   
    SH010255  SH010260         1.   
    SH010255  SH010264         1.   
    SH010255  SH010265         1.   
    SH010255  SH010266         1.   
    SH010255  SH010267         1.   
    SH010255  SH010268         1.   
    SH010255  SH010269         1.   
    SH010255  SH010272         1.   
    SH010255  SH010273         1.   
    SH010255  SH010274         1.   
    SH010255  SH010275         1.   
    SH010255  SH010276         1.   
    SH010255  SH010277         1.   
    SH010255  SH010278         1.   
    SH010255  SH010279         1.   
    SH010255  SH010282         1.   
    SH010255  SH010283         1.   
    SH010255  SH010284         1.   
    SH010255  TRSH0201         1.   
    SH010355  SH010355        10.   
    SH010355  SH010358         1.   
    SH010355  SH010359         1.   
    SH010355  SH010360         1.   
    SH010355  SH010364         1.   
    SH010355  SH010371         1.   
    SH010355  SH010373         1.   
    SH010355  SH010377         1.   
    SH010355  SH010378         1.   
    SH010355  SH010382         1.   
    SH010355  SH010383         1.   
    SH010355  TRSH0301         1.   
    SH010455  SH010455        10.   
    SH010455  SH010458         1.   
    SH010455  SH010459         1.   
    SH010455  SH010460         1.   
    SH010455  SH010464         1.   
    SH010455  SH010471         1.   
    SH010455  SH010473         1.   
    SH010455  SH010477         1.   
    SH010455  SH010478         1.   
    SH010455  SH010480         1.   
    SH010455  SH010482         1.   
    SH010455  SH010483         1.   
    SH010455  TRSH0401         1.   
    SH010555  SH010555        10.   
    SH010555  SH010556         1.   
    SH010555  SH010557         1.   
    SH010555  SH010558         1.   
    SH010555  SH010559         1.   
    SH010555  SH010560         1.   
    SH010555  SH010563         1.   
    SH010555  SH010564         1.   
    SH010555  SH010571         1.   
    SH010555  SH010573         1.   
    SH010555  SH010577         1.   
    SH010555  SH010578         1.   
    SH010555  SH010582         1.   
    SH010555  SH010583         1.   
    SH010555  TRSH0501         1.   
    SH010655  SH010655        10.   
    SH010655  SH010658         1.   
    SH010655  SH010659         1.   
    SH010655  SH010660         1.   
    SH010655  SH010664         1.   
    SH010655  SH010671         1.   
    SH010655  SH010673         1.   
    SH010655  SH010683         1.   
    SH010655  TRSH0601         1.   
    SH010755  SH010755        10.   
    SH010755  SH010758         1.   
    SH010755  SH010759         1.   
    SH010755  SH010760         1.   
    SH010755  SH010771         1.   
    SH010755  TRSH0701         1.   
    SH010855  SH010855        10.   
    SH010855  SH010858         1.   
    SH010855  SH010859         1.   
    SH010855  SH010860         1.   
    SH010855  SH010864         1.   
    SH010855  SH010871         1.   
    SH010855  SH010873         1.   
    SH010855  SH010877         1.   
    SH010855  SH010878         1.   
    SH010855  SH010882         1.   
    SH010855  TRSH0801         1.   
    SH010156  SH010156        10.   
    SH010156  SH010157         1.   
    SH010156  SH010158         1.   
    SH010156  SH010159         1.   
    SH010156  SH010160         1.   
    SH010156  SH010163         1.   
    SH010156  SH010164         1.   
    SH010156  SH010171         1.   
    SH010156  SH010173         1.   
    SH010156  SH010177         1.   
    SH010156  SH010178         1.   
    SH010156  SH010182         1.   
    SH010156  SH010183         1.   
    SH010156  TRSH0101         1.   
    SH010556  SH010556        10.   
    SH010556  SH010557         1.   
    SH010556  SH010558         1.   
    SH010556  SH010559         1.   
    SH010556  SH010560         1.   
    SH010556  SH010563         1.   
    SH010556  SH010564         1.   
    SH010556  SH010571         1.   
    SH010556  SH010573         1.   
    SH010556  SH010577         1.   
    SH010556  SH010578         1.   
    SH010556  SH010582         1.   
    SH010556  SH010583         1.   
    SH010556  TRSH0501         1.   
    SH010157  SH010157        10.   
    SH010157  SH010158         1.   
    SH010157  SH010159         1.   
    SH010157  SH010160         1.   
    SH010157  SH010163         1.   
    SH010157  SH010164         1.   
    SH010157  SH010171         1.   
    SH010157  SH010173         1.   
    SH010157  SH010177         1.   
    SH010157  SH010178         1.   
    SH010157  SH010182         1.   
    SH010157  SH010183         1.   
    SH010157  TRSH0101         1.   
    SH010557  SH010557        10.   
    SH010557  SH010558         1.   
    SH010557  SH010559         1.   
    SH010557  SH010560         1.   
    SH010557  SH010563         1.   
    SH010557  SH010564         1.   
    SH010557  SH010571         1.   
    SH010557  SH010573         1.   
    SH010557  SH010577         1.   
    SH010557  SH010578         1.   
    SH010557  SH010582         1.   
    SH010557  SH010583         1.   
    SH010557  TRSH0501         1.   
    SH010158  SH010158        10.   
    SH010158  SH010159         1.   
    SH010158  SH010160         1.   
    SH010158  SH010163         1.   
    SH010158  SH010164         1.   
    SH010158  SH010171         1.   
    SH010158  SH010173         1.   
    SH010158  SH010177         1.   
    SH010158  SH010178         1.   
    SH010158  SH010182         1.   
    SH010158  SH010183         1.   
    SH010158  TRSH0101         1.   
    SH010258  SH010258        10.   
    SH010258  SH010259         1.   
    SH010258  SH010260         1.   
    SH010258  SH010264         1.   
    SH010258  SH010265         1.   
    SH010258  SH010266         1.   
    SH010258  SH010267         1.   
    SH010258  SH010268         1.   
    SH010258  SH010269         1.   
    SH010258  SH010272         1.   
    SH010258  SH010273         1.   
    SH010258  SH010274         1.   
    SH010258  SH010275         1.   
    SH010258  SH010276         1.   
    SH010258  SH010277         1.   
    SH010258  SH010278         1.   
    SH010258  SH010279         1.   
    SH010258  SH010282         1.   
    SH010258  SH010283         1.   
    SH010258  SH010284         1.   
    SH010258  TRSH0201         1.   
    SH010358  SH010358        10.   
    SH010358  SH010359         1.   
    SH010358  SH010360         1.   
    SH010358  SH010364         1.   
    SH010358  SH010371         1.   
    SH010358  SH010373         1.   
    SH010358  SH010377         1.   
    SH010358  SH010378         1.   
    SH010358  SH010382         1.   
    SH010358  SH010383         1.   
    SH010358  TRSH0301         1.   
    SH010458  SH010458        10.   
    SH010458  SH010459         1.   
    SH010458  SH010460         1.   
    SH010458  SH010464         1.   
    SH010458  SH010471         1.   
    SH010458  SH010473         1.   
    SH010458  SH010477         1.   
    SH010458  SH010478         1.   
    SH010458  SH010480         1.   
    SH010458  SH010482         1.   
    SH010458  SH010483         1.   
    SH010458  TRSH0401         1.   
    SH010558  SH010558        10.   
    SH010558  SH010559         1.   
    SH010558  SH010560         1.   
    SH010558  SH010563         1.   
    SH010558  SH010564         1.   
    SH010558  SH010571         1.   
    SH010558  SH010573         1.   
    SH010558  SH010577         1.   
    SH010558  SH010578         1.   
    SH010558  SH010582         1.   
    SH010558  SH010583         1.   
    SH010558  TRSH0501         1.   
    SH010658  SH010658        10.   
    SH010658  SH010659         1.   
    SH010658  SH010660         1.   
    SH010658  SH010664         1.   
    SH010658  SH010671         1.   
    SH010658  SH010673         1.   
    SH010658  SH010683         1.   
    SH010658  TRSH0601         1.   
    SH010758  SH010758        10.   
    SH010758  SH010759         1.   
    SH010758  SH010760         1.   
    SH010758  SH010771         1.   
    SH010758  TRSH0701         1.   
    SH010858  SH010858        10.   
    SH010858  SH010859         1.   
    SH010858  SH010860         1.   
    SH010858  SH010864         1.   
    SH010858  SH010871         1.   
    SH010858  SH010873         1.   
    SH010858  SH010877         1.   
    SH010858  SH010878         1.   
    SH010858  SH010882         1.   
    SH010858  TRSH0801         1.   
    SH010159  SH010159        10.   
    SH010159  SH010160         1.   
    SH010159  SH010163         1.   
    SH010159  SH010164         1.   
    SH010159  SH010171         1.   
    SH010159  SH010173         1.   
    SH010159  SH010177         1.   
    SH010159  SH010178         1.   
    SH010159  SH010182         1.   
    SH010159  SH010183         1.   
    SH010159  TRSH0101         1.   
    SH010259  SH010259        10.   
    SH010259  SH010260         1.   
    SH010259  SH010264         1.   
    SH010259  SH010265         1.   
    SH010259  SH010266         1.   
    SH010259  SH010267         1.   
    SH010259  SH010268         1.   
    SH010259  SH010269         1.   
    SH010259  SH010272         1.   
    SH010259  SH010273         1.   
    SH010259  SH010274         1.   
    SH010259  SH010275         1.   
    SH010259  SH010276         1.   
    SH010259  SH010277         1.   
    SH010259  SH010278         1.   
    SH010259  SH010279         1.   
    SH010259  SH010282         1.   
    SH010259  SH010283         1.   
    SH010259  SH010284         1.   
    SH010259  TRSH0201         1.   
    SH010359  SH010359        10.   
    SH010359  SH010360         1.   
    SH010359  SH010364         1.   
    SH010359  SH010371         1.   
    SH010359  SH010373         1.   
    SH010359  SH010377         1.   
    SH010359  SH010378         1.   
    SH010359  SH010382         1.   
    SH010359  SH010383         1.   
    SH010359  TRSH0301         1.   
    SH010459  SH010459        10.   
    SH010459  SH010460         1.   
    SH010459  SH010464         1.   
    SH010459  SH010471         1.   
    SH010459  SH010473         1.   
    SH010459  SH010477         1.   
    SH010459  SH010478         1.   
    SH010459  SH010480         1.   
    SH010459  SH010482         1.   
    SH010459  SH010483         1.   
    SH010459  TRSH0401         1.   
    SH010559  SH010559        10.   
    SH010559  SH010560         1.   
    SH010559  SH010563         1.   
    SH010559  SH010564         1.   
    SH010559  SH010571         1.   
    SH010559  SH010573         1.   
    SH010559  SH010577         1.   
    SH010559  SH010578         1.   
    SH010559  SH010582         1.   
    SH010559  SH010583         1.   
    SH010559  TRSH0501         1.   
    SH010659  SH010659        10.   
    SH010659  SH010660         1.   
    SH010659  SH010664         1.   
    SH010659  SH010671         1.   
    SH010659  SH010673         1.   
    SH010659  SH010683         1.   
    SH010659  TRSH0601         1.   
    SH010759  SH010759        10.   
    SH010759  SH010760         1.   
    SH010759  SH010771         1.   
    SH010759  TRSH0701         1.   
    SH010859  SH010859        10.   
    SH010859  SH010860         1.   
    SH010859  SH010864         1.   
    SH010859  SH010871         1.   
    SH010859  SH010873         1.   
    SH010859  SH010877         1.   
    SH010859  SH010878         1.   
    SH010859  SH010882         1.   
    SH010859  TRSH0801         1.   
    SH010160  SH010160        10.   
    SH010160  SH010163         1.   
    SH010160  SH010164         1.   
    SH010160  SH010171         1.   
    SH010160  SH010173         1.   
    SH010160  SH010177         1.   
    SH010160  SH010178         1.   
    SH010160  SH010182         1.   
    SH010160  SH010183         1.   
    SH010160  TRSH0101         1.   
    SH010260  SH010260        10.   
    SH010260  SH010264         1.   
    SH010260  SH010265         1.   
    SH010260  SH010266         1.   
    SH010260  SH010267         1.   
    SH010260  SH010268         1.   
    SH010260  SH010269         1.   
    SH010260  SH010272         1.   
    SH010260  SH010273         1.   
    SH010260  SH010274         1.   
    SH010260  SH010275         1.   
    SH010260  SH010276         1.   
    SH010260  SH010277         1.   
    SH010260  SH010278         1.   
    SH010260  SH010279         1.   
    SH010260  SH010282         1.   
    SH010260  SH010283         1.   
    SH010260  SH010284         1.   
    SH010260  TRSH0201         1.   
    SH010360  SH010360        10.   
    SH010360  SH010364         1.   
    SH010360  SH010371         1.   
    SH010360  SH010373         1.   
    SH010360  SH010377         1.   
    SH010360  SH010378         1.   
    SH010360  SH010382         1.   
    SH010360  SH010383         1.   
    SH010360  TRSH0301         1.   
    SH010460  SH010460        10.   
    SH010460  SH010464         1.   
    SH010460  SH010471         1.   
    SH010460  SH010473         1.   
    SH010460  SH010477         1.   
    SH010460  SH010478         1.   
    SH010460  SH010480         1.   
    SH010460  SH010482         1.   
    SH010460  SH010483         1.   
    SH010460  TRSH0401         1.   
    SH010560  SH010560        10.   
    SH010560  SH010563         1.   
    SH010560  SH010564         1.   
    SH010560  SH010571         1.   
    SH010560  SH010573         1.   
    SH010560  SH010577         1.   
    SH010560  SH010578         1.   
    SH010560  SH010582         1.   
    SH010560  SH010583         1.   
    SH010560  TRSH0501         1.   
    SH010660  SH010660        10.   
    SH010660  SH010664         1.   
    SH010660  SH010671         1.   
    SH010660  SH010673         1.   
    SH010660  SH010683         1.   
    SH010660  TRSH0601         1.   
    SH010760  SH010760        10.   
    SH010760  SH010771         1.   
    SH010760  TRSH0701         1.   
    SH010860  SH010860        10.   
    SH010860  SH010864         1.   
    SH010860  SH010871         1.   
    SH010860  SH010873         1.   
    SH010860  SH010877         1.   
    SH010860  SH010878         1.   
    SH010860  SH010882         1.   
    SH010860  TRSH0801         1.   
    SH010163  SH010163        10.   
    SH010163  SH010164         1.   
    SH010163  SH010171         1.   
    SH010163  SH010173         1.   
    SH010163  SH010177         1.   
    SH010163  SH010178         1.   
    SH010163  SH010182         1.   
    SH010163  SH010183         1.   
    SH010163  TRSH0101         1.   
    SH010563  SH010563        10.   
    SH010563  SH010564         1.   
    SH010563  SH010571         1.   
    SH010563  SH010573         1.   
    SH010563  SH010577         1.   
    SH010563  SH010578         1.   
    SH010563  SH010582         1.   
    SH010563  SH010583         1.   
    SH010563  TRSH0501         1.   
    SH010164  SH010164        10.   
    SH010164  SH010171         1.   
    SH010164  SH010173         1.   
    SH010164  SH010177         1.   
    SH010164  SH010178         1.   
    SH010164  SH010182         1.   
    SH010164  SH010183         1.   
    SH010164  TRSH0101         1.   
    SH010264  SH010264        10.   
    SH010264  SH010265         1.   
    SH010264  SH010266         1.   
    SH010264  SH010267         1.   
    SH010264  SH010268         1.   
    SH010264  SH010269         1.   
    SH010264  SH010272         1.   
    SH010264  SH010273         1.   
    SH010264  SH010274         1.   
    SH010264  SH010275         1.   
    SH010264  SH010276         1.   
    SH010264  SH010277         1.   
    SH010264  SH010278         1.   
    SH010264  SH010279         1.   
    SH010264  SH010282         1.   
    SH010264  SH010283         1.   
    SH010264  SH010284         1.   
    SH010264  TRSH0201         1.   
    SH010364  SH010364        10.   
    SH010364  SH010371         1.   
    SH010364  SH010373         1.   
    SH010364  SH010377         1.   
    SH010364  SH010378         1.   
    SH010364  SH010382         1.   
    SH010364  SH010383         1.   
    SH010364  TRSH0301         1.   
    SH010464  SH010464        10.   
    SH010464  SH010471         1.   
    SH010464  SH010473         1.   
    SH010464  SH010477         1.   
    SH010464  SH010478         1.   
    SH010464  SH010480         1.   
    SH010464  SH010482         1.   
    SH010464  SH010483         1.   
    SH010464  TRSH0401         1.   
    SH010564  SH010564        10.   
    SH010564  SH010571         1.   
    SH010564  SH010573         1.   
    SH010564  SH010577         1.   
    SH010564  SH010578         1.   
    SH010564  SH010582         1.   
    SH010564  SH010583         1.   
    SH010564  TRSH0501         1.   
    SH010664  SH010664        10.   
    SH010664  SH010671         1.   
    SH010664  SH010673         1.   
    SH010664  SH010683         1.   
    SH010664  TRSH0601         1.   
    SH010864  SH010864        10.   
    SH010864  SH010871         1.   
    SH010864  SH010873         1.   
    SH010864  SH010877         1.   
    SH010864  SH010878         1.   
    SH010864  SH010882         1.   
    SH010864  TRSH0801         1.   
    SH010265  SH010265        10.   
    SH010265  SH010266         1.   
    SH010265  SH010267         1.   
    SH010265  SH010268         1.   
    SH010265  SH010269         1.   
    SH010265  SH010272         1.   
    SH010265  SH010273         1.   
    SH010265  SH010274         1.   
    SH010265  SH010275         1.   
    SH010265  SH010276         1.   
    SH010265  SH010277         1.   
    SH010265  SH010278         1.   
    SH010265  SH010279         1.   
    SH010265  SH010282         1.   
    SH010265  SH010283         1.   
    SH010265  SH010284         1.   
    SH010265  TRSH0201         1.   
    SH010266  SH010266        10.   
    SH010266  SH010267         1.   
    SH010266  SH010268         1.   
    SH010266  SH010269         1.   
    SH010266  SH010272         1.   
    SH010266  SH010273         1.   
    SH010266  SH010274         1.   
    SH010266  SH010275         1.   
    SH010266  SH010276         1.   
    SH010266  SH010277         1.   
    SH010266  SH010278         1.   
    SH010266  SH010279         1.   
    SH010266  SH010282         1.   
    SH010266  SH010283         1.   
    SH010266  SH010284         1.   
    SH010266  TRSH0201         1.   
    SH010267  SH010267        10.   
    SH010267  SH010268         1.   
    SH010267  SH010269         1.   
    SH010267  SH010272         1.   
    SH010267  SH010273         1.   
    SH010267  SH010274         1.   
    SH010267  SH010275         1.   
    SH010267  SH010276         1.   
    SH010267  SH010277         1.   
    SH010267  SH010278         1.   
    SH010267  SH010279         1.   
    SH010267  SH010282         1.   
    SH010267  SH010283         1.   
    SH010267  SH010284         1.   
    SH010267  TRSH0201         1.   
    SH010268  SH010268        10.   
    SH010268  SH010269         1.   
    SH010268  SH010272         1.   
    SH010268  SH010273         1.   
    SH010268  SH010274         1.   
    SH010268  SH010275         1.   
    SH010268  SH010276         1.   
    SH010268  SH010277         1.   
    SH010268  SH010278         1.   
    SH010268  SH010279         1.   
    SH010268  SH010282         1.   
    SH010268  SH010283         1.   
    SH010268  SH010284         1.   
    SH010268  TRSH0201         1.   
    SH010269  SH010269        10.   
    SH010269  SH010272         1.   
    SH010269  SH010273         1.   
    SH010269  SH010274         1.   
    SH010269  SH010275         1.   
    SH010269  SH010276         1.   
    SH010269  SH010277         1.   
    SH010269  SH010278         1.   
    SH010269  SH010279         1.   
    SH010269  SH010282         1.   
    SH010269  SH010283         1.   
    SH010269  SH010284         1.   
    SH010269  TRSH0201         1.   
    SH010171  SH010171        10.   
    SH010171  SH010173         1.   
    SH010171  SH010177         1.   
    SH010171  SH010178         1.   
    SH010171  SH010182         1.   
    SH010171  SH010183         1.   
    SH010171  TRSH0101         1.   
    SH010371  SH010371        10.   
    SH010371  SH010373         1.   
    SH010371  SH010377         1.   
    SH010371  SH010378         1.   
    SH010371  SH010382         1.   
    SH010371  SH010383         1.   
    SH010371  TRSH0301         1.   
    SH010471  SH010471        10.   
    SH010471  SH010473         1.   
    SH010471  SH010477         1.   
    SH010471  SH010478         1.   
    SH010471  SH010480         1.   
    SH010471  SH010482         1.   
    SH010471  SH010483         1.   
    SH010471  TRSH0401         1.   
    SH010571  SH010571        10.   
    SH010571  SH010573         1.   
    SH010571  SH010577         1.   
    SH010571  SH010578         1.   
    SH010571  SH010582         1.   
    SH010571  SH010583         1.   
    SH010571  TRSH0501         1.   
    SH010671  SH010671        10.   
    SH010671  SH010673         1.   
    SH010671  SH010683         1.   
    SH010671  TRSH0601         1.   
    SH010771  SH010771        10.   
    SH010771  TRSH0701         1.   
    SH010871  SH010871        10.   
    SH010871  SH010873         1.   
    SH010871  SH010877         1.   
    SH010871  SH010878         1.   
    SH010871  SH010882         1.   
    SH010871  TRSH0801         1.   
    SH010272  SH010272        10.   
    SH010272  SH010273         1.   
    SH010272  SH010274         1.   
    SH010272  SH010275         1.   
    SH010272  SH010276         1.   
    SH010272  SH010277         1.   
    SH010272  SH010278         1.   
    SH010272  SH010279         1.   
    SH010272  SH010282         1.   
    SH010272  SH010283         1.   
    SH010272  SH010284         1.   
    SH010272  TRSH0201         1.   
    SH010173  SH010173        10.   
    SH010173  SH010177         1.   
    SH010173  SH010178         1.   
    SH010173  SH010182         1.   
    SH010173  SH010183         1.   
    SH010173  TRSH0101         1.   
    SH010273  SH010273        10.   
    SH010273  SH010274         1.   
    SH010273  SH010275         1.   
    SH010273  SH010276         1.   
    SH010273  SH010277         1.   
    SH010273  SH010278         1.   
    SH010273  SH010279         1.   
    SH010273  SH010282         1.   
    SH010273  SH010283         1.   
    SH010273  SH010284         1.   
    SH010273  TRSH0201         1.   
    SH010373  SH010373        10.   
    SH010373  SH010377         1.   
    SH010373  SH010378         1.   
    SH010373  SH010382         1.   
    SH010373  SH010383         1.   
    SH010373  TRSH0301         1.   
    SH010473  SH010473        10.   
    SH010473  SH010477         1.   
    SH010473  SH010478         1.   
    SH010473  SH010480         1.   
    SH010473  SH010482         1.   
    SH010473  SH010483         1.   
    SH010473  TRSH0401         1.   
    SH010573  SH010573        10.   
    SH010573  SH010577         1.   
    SH010573  SH010578         1.   
    SH010573  SH010582         1.   
    SH010573  SH010583         1.   
    SH010573  TRSH0501         1.   
    SH010673  SH010673        10.   
    SH010673  SH010683         1.   
    SH010673  TRSH0601         1.   
    SH010873  SH010873        10.   
    SH010873  SH010877         1.   
    SH010873  SH010878         1.   
    SH010873  SH010882         1.   
    SH010873  TRSH0801         1.   
    SH010274  SH010274        10.   
    SH010274  SH010275         1.   
    SH010274  SH010276         1.   
    SH010274  SH010277         1.   
    SH010274  SH010278         1.   
    SH010274  SH010279         1.   
    SH010274  SH010282         1.   
    SH010274  SH010283         1.   
    SH010274  SH010284         1.   
    SH010274  TRSH0201         1.   
    SH010275  SH010275        10.   
    SH010275  SH010276         1.   
    SH010275  SH010277         1.   
    SH010275  SH010278         1.   
    SH010275  SH010279         1.   
    SH010275  SH010282         1.   
    SH010275  SH010283         1.   
    SH010275  SH010284         1.   
    SH010275  TRSH0201         1.   
    SH010276  SH010276        10.   
    SH010276  SH010277         1.   
    SH010276  SH010278         1.   
    SH010276  SH010279         1.   
    SH010276  SH010282         1.   
    SH010276  SH010283         1.   
    SH010276  SH010284         1.   
    SH010276  TRSH0201         1.   
    SH010177  SH010177        10.   
    SH010177  SH010178         1.   
    SH010177  SH010182         1.   
    SH010177  SH010183         1.   
    SH010177  TRSH0101         1.   
    SH010277  SH010277        10.   
    SH010277  SH010278         1.   
    SH010277  SH010279         1.   
    SH010277  SH010282         1.   
    SH010277  SH010283         1.   
    SH010277  SH010284         1.   
    SH010277  TRSH0201         1.   
    SH010377  SH010377        10.   
    SH010377  SH010378         1.   
    SH010377  SH010382         1.   
    SH010377  SH010383         1.   
    SH010377  TRSH0301         1.   
    SH010477  SH010477        10.   
    SH010477  SH010478         1.   
    SH010477  SH010480         1.   
    SH010477  SH010482         1.   
    SH010477  SH010483         1.   
    SH010477  TRSH0401         1.   
    SH010577  SH010577        10.   
    SH010577  SH010578         1.   
    SH010577  SH010582         1.   
    SH010577  SH010583         1.   
    SH010577  TRSH0501         1.   
    SH010877  SH010877        10.   
    SH010877  SH010878         1.   
    SH010877  SH010882         1.   
    SH010877  TRSH0801         1.   
    SH010178  SH010178        10.   
    SH010178  SH010182         1.   
    SH010178  SH010183         1.   
    SH010178  TRSH0101         1.   
    SH010278  SH010278        10.   
    SH010278  SH010279         1.   
    SH010278  SH010282         1.   
    SH010278  SH010283         1.   
    SH010278  SH010284         1.   
    SH010278  TRSH0201         1.   
    SH010378  SH010378        10.   
    SH010378  SH010382         1.   
    SH010378  SH010383         1.   
    SH010378  TRSH0301         1.   
    SH010478  SH010478        10.   
    SH010478  SH010480         1.   
    SH010478  SH010482         1.   
    SH010478  SH010483         1.   
    SH010478  TRSH0401         1.   
    SH010578  SH010578        10.   
    SH010578  SH010582         1.   
    SH010578  SH010583         1.   
    SH010578  TRSH0501         1.   
    SH010878  SH010878        10.   
    SH010878  SH010882         1.   
    SH010878  TRSH0801         1.   
    SH010279  SH010279        10.   
    SH010279  SH010282         1.   
    SH010279  SH010283         1.   
    SH010279  SH010284         1.   
    SH010279  TRSH0201         1.   
    SH010480  SH010480        10.   
    SH010480  SH010482         1.   
    SH010480  SH010483         1.   
    SH010480  TRSH0401         1.   
    SH010182  SH010182        10.   
    SH010182  SH010183         1.   
    SH010182  TRSH0101         1.   
    SH010282  SH010282        10.   
    SH010282  SH010283         1.   
    SH010282  SH010284         1.   
    SH010282  TRSH0201         1.   
    SH010382  SH010382        10.   
    SH010382  SH010383         1.   
    SH010382  TRSH0301         1.   
    SH010482  SH010482        10.   
    SH010482  SH010483         1.   
    SH010482  TRSH0401         1.   
    SH010582  SH010582        10.   
    SH010582  SH010583         1.   
    SH010582  TRSH0501         1.   
    SH010882  SH010882        10.   
    SH010882  TRSH0801         1.   
    SH010183  SH010183        10.   
    SH010183  TRSH0101         1.   
    SH010283  SH010283        10.   
    SH010283  SH010284         1.   
    SH010283  TRSH0201         1.   
    SH010383  SH010383        10.   
    SH010383  TRSH0301         1.   
    SH010483  SH010483        10.   
    SH010483  TRSH0401         1.   
    SH010583  SH010583        10.   
    SH010583  TRSH0501         1.   
    SH010683  SH010683        10.   
    SH010683  TRSH0601         1.   
    SH010284  SH010284        10.   
    SH010284  TRSH0201         1.   
    SH020201  SH020201        10.   
    SH020201  SH020203         1.   
    SH020201  SH020204         1.   
    SH020201  SH020205         1.   
    SH020201  SH020207         1.   
    SH020201  SH020208         1.   
    SH020201  SH020210         1.   
    SH020201  SH020215         1.   
    SH020201  SH020216         1.   
    SH020201  SH020219         1.   
    SH020201  SH020220         1.   
    SH020201  SH020221         1.   
    SH020201  SH020225         1.   
    SH020201  SH020233         1.   
    SH020201  SH020234         1.   
    SH020201  SH020237         1.   
    SH020201  SH020238         1.   
    SH020201  SH020240         1.   
    SH020201  SH020243         1.   
    SH020201  SH020245         1.   
    SH020201  SH020246         1.   
    SH020201  SH020252         1.   
    SH020201  SH020253         1.   
    SH020201  SH020255         1.   
    SH020201  SH020258         1.   
    SH020201  SH020259         1.   
    SH020201  SH020260         1.   
    SH020201  SH020264         1.   
    SH020201  SH020265         1.   
    SH020201  SH020266         1.   
    SH020201  SH020267         1.   
    SH020201  SH020268         1.   
    SH020201  SH020269         1.   
    SH020201  SH020272         1.   
    SH020201  SH020273         1.   
    SH020201  SH020274         1.   
    SH020201  SH020275         1.   
    SH020201  SH020276         1.   
    SH020201  SH020277         1.   
    SH020201  SH020278         1.   
    SH020201  SH020279         1.   
    SH020201  SH020282         1.   
    SH020201  SH020283         1.   
    SH020201  SH020284         1.   
    SH020201  TRSH0202         1.   
    SH020301  SH020301        10.   
    SH020301  SH020302         1.   
    SH020301  SH020304         1.   
    SH020301  SH020305         1.   
    SH020301  SH020307         1.   
    SH020301  SH020308         1.   
    SH020301  SH020310         1.   
    SH020301  SH020315         1.   
    SH020301  SH020316         1.   
    SH020301  SH020319         1.   
    SH020301  SH020320         1.   
    SH020301  SH020321         1.   
    SH020301  SH020333         1.   
    SH020301  SH020334         1.   
    SH020301  SH020337         1.   
    SH020301  SH020338         1.   
    SH020301  SH020340         1.   
    SH020301  SH020343         1.   
    SH020301  SH020345         1.   
    SH020301  SH020346         1.   
    SH020301  SH020352         1.   
    SH020301  SH020353         1.   
    SH020301  SH020355         1.   
    SH020301  SH020358         1.   
    SH020301  SH020359         1.   
    SH020301  SH020360         1.   
    SH020301  SH020364         1.   
    SH020301  SH020371         1.   
    SH020301  SH020373         1.   
    SH020301  SH020377         1.   
    SH020301  SH020378         1.   
    SH020301  SH020382         1.   
    SH020301  SH020383         1.   
    SH020301  TRSH0302         1.   
    SH020401  SH020401        10.   
    SH020401  SH020402         1.   
    SH020401  SH020403         1.   
    SH020401  SH020405         1.   
    SH020401  SH020407         1.   
    SH020401  SH020408         1.   
    SH020401  SH020410         1.   
    SH020401  SH020415         1.   
    SH020401  SH020416         1.   
    SH020401  SH020418         1.   
    SH020401  SH020419         1.   
    SH020401  SH020420         1.   
    SH020401  SH020421         1.   
    SH020401  SH020422         1.   
    SH020401  SH020423         1.   
    SH020401  SH020426         1.   
    SH020401  SH020429         1.   
    SH020401  SH020430         1.   
    SH020401  SH020432         1.   
    SH020401  SH020433         1.   
    SH020401  SH020434         1.   
    SH020401  SH020435         1.   
    SH020401  SH020437         1.   
    SH020401  SH020438         1.   
    SH020401  SH020440         1.   
    SH020401  SH020443         1.   
    SH020401  SH020445         1.   
    SH020401  SH020446         1.   
    SH020401  SH020452         1.   
    SH020401  SH020453         1.   
    SH020401  SH020455         1.   
    SH020401  SH020458         1.   
    SH020401  SH020459         1.   
    SH020401  SH020460         1.   
    SH020401  SH020464         1.   
    SH020401  SH020471         1.   
    SH020401  SH020473         1.   
    SH020401  SH020477         1.   
    SH020401  SH020478         1.   
    SH020401  SH020480         1.   
    SH020401  SH020482         1.   
    SH020401  SH020483         1.   
    SH020401  TRSH0402         1.   
    SH020501  SH020501        10.   
    SH020501  SH020502         1.   
    SH020501  SH020503         1.   
    SH020501  SH020504         1.   
    SH020501  SH020507         1.   
    SH020501  SH020508         1.   
    SH020501  SH020510         1.   
    SH020501  SH020515         1.   
    SH020501  SH020516         1.   
    SH020501  SH020519         1.   
    SH020501  SH020520         1.   
    SH020501  SH020521         1.   
    SH020501  SH020528         1.   
    SH020501  SH020533         1.   
    SH020501  SH020534         1.   
    SH020501  SH020537         1.   
    SH020501  SH020538         1.   
    SH020501  SH020540         1.   
    SH020501  SH020543         1.   
    SH020501  SH020545         1.   
    SH020501  SH020546         1.   
    SH020501  SH020549         1.   
    SH020501  SH020551         1.   
    SH020501  SH020552         1.   
    SH020501  SH020553         1.   
    SH020501  SH020555         1.   
    SH020501  SH020556         1.   
    SH020501  SH020557         1.   
    SH020501  SH020558         1.   
    SH020501  SH020559         1.   
    SH020501  SH020560         1.   
    SH020501  SH020563         1.   
    SH020501  SH020564         1.   
    SH020501  SH020571         1.   
    SH020501  SH020573         1.   
    SH020501  SH020577         1.   
    SH020501  SH020578         1.   
    SH020501  SH020582         1.   
    SH020501  SH020583         1.   
    SH020501  TRSH0502         1.   
    SH020102  SH020102        10.   
    SH020102  SH020103         1.   
    SH020102  SH020104         1.   
    SH020102  SH020105         1.   
    SH020102  SH020106         1.   
    SH020102  SH020107         1.   
    SH020102  SH020108         1.   
    SH020102  SH020109         1.   
    SH020102  SH020110         1.   
    SH020102  SH020111         1.   
    SH020102  SH020112         1.   
    SH020102  SH020114         1.   
    SH020102  SH020115         1.   
    SH020102  SH020116         1.   
    SH020102  SH020117         1.   
    SH020102  SH020119         1.   
    SH020102  SH020120         1.   
    SH020102  SH020121         1.   
    SH020102  SH020124         1.   
    SH020102  SH020128         1.   
    SH020102  SH020131         1.   
    SH020102  SH020133         1.   
    SH020102  SH020134         1.   
    SH020102  SH020137         1.   
    SH020102  SH020138         1.   
    SH020102  SH020139         1.   
    SH020102  SH020140         1.   
    SH020102  SH020142         1.   
    SH020102  SH020143         1.   
    SH020102  SH020145         1.   
    SH020102  SH020146         1.   
    SH020102  SH020147         1.   
    SH020102  SH020148         1.   
    SH020102  SH020149         1.   
    SH020102  SH020150         1.   
    SH020102  SH020151         1.   
    SH020102  SH020152         1.   
    SH020102  SH020153         1.   
    SH020102  SH020154         1.   
    SH020102  SH020155         1.   
    SH020102  SH020156         1.   
    SH020102  SH020157         1.   
    SH020102  SH020158         1.   
    SH020102  SH020159         1.   
    SH020102  SH020160         1.   
    SH020102  SH020163         1.   
    SH020102  SH020164         1.   
    SH020102  SH020171         1.   
    SH020102  SH020173         1.   
    SH020102  SH020177         1.   
    SH020102  SH020178         1.   
    SH020102  SH020182         1.   
    SH020102  SH020183         1.   
    SH020102  TRSH0102         1.   
    SH020302  SH020302        10.   
    SH020302  SH020304         1.   
    SH020302  SH020305         1.   
    SH020302  SH020307         1.   
    SH020302  SH020308         1.   
    SH020302  SH020310         1.   
    SH020302  SH020315         1.   
    SH020302  SH020316         1.   
    SH020302  SH020319         1.   
    SH020302  SH020320         1.   
    SH020302  SH020321         1.   
    SH020302  SH020333         1.   
    SH020302  SH020334         1.   
    SH020302  SH020337         1.   
    SH020302  SH020338         1.   
    SH020302  SH020340         1.   
    SH020302  SH020343         1.   
    SH020302  SH020345         1.   
    SH020302  SH020346         1.   
    SH020302  SH020352         1.   
    SH020302  SH020353         1.   
    SH020302  SH020355         1.   
    SH020302  SH020358         1.   
    SH020302  SH020359         1.   
    SH020302  SH020360         1.   
    SH020302  SH020364         1.   
    SH020302  SH020371         1.   
    SH020302  SH020373         1.   
    SH020302  SH020377         1.   
    SH020302  SH020378         1.   
    SH020302  SH020382         1.   
    SH020302  SH020383         1.   
    SH020302  TRSH0302         1.   
    SH020402  SH020402        10.   
    SH020402  SH020403         1.   
    SH020402  SH020405         1.   
    SH020402  SH020407         1.   
    SH020402  SH020408         1.   
    SH020402  SH020410         1.   
    SH020402  SH020415         1.   
    SH020402  SH020416         1.   
    SH020402  SH020418         1.   
    SH020402  SH020419         1.   
    SH020402  SH020420         1.   
    SH020402  SH020421         1.   
    SH020402  SH020422         1.   
    SH020402  SH020423         1.   
    SH020402  SH020426         1.   
    SH020402  SH020429         1.   
    SH020402  SH020430         1.   
    SH020402  SH020432         1.   
    SH020402  SH020433         1.   
    SH020402  SH020434         1.   
    SH020402  SH020435         1.   
    SH020402  SH020437         1.   
    SH020402  SH020438         1.   
    SH020402  SH020440         1.   
    SH020402  SH020443         1.   
    SH020402  SH020445         1.   
    SH020402  SH020446         1.   
    SH020402  SH020452         1.   
    SH020402  SH020453         1.   
    SH020402  SH020455         1.   
    SH020402  SH020458         1.   
    SH020402  SH020459         1.   
    SH020402  SH020460         1.   
    SH020402  SH020464         1.   
    SH020402  SH020471         1.   
    SH020402  SH020473         1.   
    SH020402  SH020477         1.   
    SH020402  SH020478         1.   
    SH020402  SH020480         1.   
    SH020402  SH020482         1.   
    SH020402  SH020483         1.   
    SH020402  TRSH0402         1.   
    SH020502  SH020502        10.   
    SH020502  SH020503         1.   
    SH020502  SH020504         1.   
    SH020502  SH020507         1.   
    SH020502  SH020508         1.   
    SH020502  SH020510         1.   
    SH020502  SH020515         1.   
    SH020502  SH020516         1.   
    SH020502  SH020519         1.   
    SH020502  SH020520         1.   
    SH020502  SH020521         1.   
    SH020502  SH020528         1.   
    SH020502  SH020533         1.   
    SH020502  SH020534         1.   
    SH020502  SH020537         1.   
    SH020502  SH020538         1.   
    SH020502  SH020540         1.   
    SH020502  SH020543         1.   
    SH020502  SH020545         1.   
    SH020502  SH020546         1.   
    SH020502  SH020549         1.   
    SH020502  SH020551         1.   
    SH020502  SH020552         1.   
    SH020502  SH020553         1.   
    SH020502  SH020555         1.   
    SH020502  SH020556         1.   
    SH020502  SH020557         1.   
    SH020502  SH020558         1.   
    SH020502  SH020559         1.   
    SH020502  SH020560         1.   
    SH020502  SH020563         1.   
    SH020502  SH020564         1.   
    SH020502  SH020571         1.   
    SH020502  SH020573         1.   
    SH020502  SH020577         1.   
    SH020502  SH020578         1.   
    SH020502  SH020582         1.   
    SH020502  SH020583         1.   
    SH020502  TRSH0502         1.   
    SH020103  SH020103        10.   
    SH020103  SH020104         1.   
    SH020103  SH020105         1.   
    SH020103  SH020106         1.   
    SH020103  SH020107         1.   
    SH020103  SH020108         1.   
    SH020103  SH020109         1.   
    SH020103  SH020110         1.   
    SH020103  SH020111         1.   
    SH020103  SH020112         1.   
    SH020103  SH020114         1.   
    SH020103  SH020115         1.   
    SH020103  SH020116         1.   
    SH020103  SH020117         1.   
    SH020103  SH020119         1.   
    SH020103  SH020120         1.   
    SH020103  SH020121         1.   
    SH020103  SH020124         1.   
    SH020103  SH020128         1.   
    SH020103  SH020131         1.   
    SH020103  SH020133         1.   
    SH020103  SH020134         1.   
    SH020103  SH020137         1.   
    SH020103  SH020138         1.   
    SH020103  SH020139         1.   
    SH020103  SH020140         1.   
    SH020103  SH020142         1.   
    SH020103  SH020143         1.   
    SH020103  SH020145         1.   
    SH020103  SH020146         1.   
    SH020103  SH020147         1.   
    SH020103  SH020148         1.   
    SH020103  SH020149         1.   
    SH020103  SH020150         1.   
    SH020103  SH020151         1.   
    SH020103  SH020152         1.   
    SH020103  SH020153         1.   
    SH020103  SH020154         1.   
    SH020103  SH020155         1.   
    SH020103  SH020156         1.   
    SH020103  SH020157         1.   
    SH020103  SH020158         1.   
    SH020103  SH020159         1.   
    SH020103  SH020160         1.   
    SH020103  SH020163         1.   
    SH020103  SH020164         1.   
    SH020103  SH020171         1.   
    SH020103  SH020173         1.   
    SH020103  SH020177         1.   
    SH020103  SH020178         1.   
    SH020103  SH020182         1.   
    SH020103  SH020183         1.   
    SH020103  TRSH0102         1.   
    SH020203  SH020203        10.   
    SH020203  SH020204         1.   
    SH020203  SH020205         1.   
    SH020203  SH020207         1.   
    SH020203  SH020208         1.   
    SH020203  SH020210         1.   
    SH020203  SH020215         1.   
    SH020203  SH020216         1.   
    SH020203  SH020219         1.   
    SH020203  SH020220         1.   
    SH020203  SH020221         1.   
    SH020203  SH020225         1.   
    SH020203  SH020233         1.   
    SH020203  SH020234         1.   
    SH020203  SH020237         1.   
    SH020203  SH020238         1.   
    SH020203  SH020240         1.   
    SH020203  SH020243         1.   
    SH020203  SH020245         1.   
    SH020203  SH020246         1.   
    SH020203  SH020252         1.   
    SH020203  SH020253         1.   
    SH020203  SH020255         1.   
    SH020203  SH020258         1.   
    SH020203  SH020259         1.   
    SH020203  SH020260         1.   
    SH020203  SH020264         1.   
    SH020203  SH020265         1.   
    SH020203  SH020266         1.   
    SH020203  SH020267         1.   
    SH020203  SH020268         1.   
    SH020203  SH020269         1.   
    SH020203  SH020272         1.   
    SH020203  SH020273         1.   
    SH020203  SH020274         1.   
    SH020203  SH020275         1.   
    SH020203  SH020276         1.   
    SH020203  SH020277         1.   
    SH020203  SH020278         1.   
    SH020203  SH020279         1.   
    SH020203  SH020282         1.   
    SH020203  SH020283         1.   
    SH020203  SH020284         1.   
    SH020203  TRSH0202         1.   
    SH020403  SH020403        10.   
    SH020403  SH020405         1.   
    SH020403  SH020407         1.   
    SH020403  SH020408         1.   
    SH020403  SH020410         1.   
    SH020403  SH020415         1.   
    SH020403  SH020416         1.   
    SH020403  SH020418         1.   
    SH020403  SH020419         1.   
    SH020403  SH020420         1.   
    SH020403  SH020421         1.   
    SH020403  SH020422         1.   
    SH020403  SH020423         1.   
    SH020403  SH020426         1.   
    SH020403  SH020429         1.   
    SH020403  SH020430         1.   
    SH020403  SH020432         1.   
    SH020403  SH020433         1.   
    SH020403  SH020434         1.   
    SH020403  SH020435         1.   
    SH020403  SH020437         1.   
    SH020403  SH020438         1.   
    SH020403  SH020440         1.   
    SH020403  SH020443         1.   
    SH020403  SH020445         1.   
    SH020403  SH020446         1.   
    SH020403  SH020452         1.   
    SH020403  SH020453         1.   
    SH020403  SH020455         1.   
    SH020403  SH020458         1.   
    SH020403  SH020459         1.   
    SH020403  SH020460         1.   
    SH020403  SH020464         1.   
    SH020403  SH020471         1.   
    SH020403  SH020473         1.   
    SH020403  SH020477         1.   
    SH020403  SH020478         1.   
    SH020403  SH020480         1.   
    SH020403  SH020482         1.   
    SH020403  SH020483         1.   
    SH020403  TRSH0402         1.   
    SH020503  SH020503        10.   
    SH020503  SH020504         1.   
    SH020503  SH020507         1.   
    SH020503  SH020508         1.   
    SH020503  SH020510         1.   
    SH020503  SH020515         1.   
    SH020503  SH020516         1.   
    SH020503  SH020519         1.   
    SH020503  SH020520         1.   
    SH020503  SH020521         1.   
    SH020503  SH020528         1.   
    SH020503  SH020533         1.   
    SH020503  SH020534         1.   
    SH020503  SH020537         1.   
    SH020503  SH020538         1.   
    SH020503  SH020540         1.   
    SH020503  SH020543         1.   
    SH020503  SH020545         1.   
    SH020503  SH020546         1.   
    SH020503  SH020549         1.   
    SH020503  SH020551         1.   
    SH020503  SH020552         1.   
    SH020503  SH020553         1.   
    SH020503  SH020555         1.   
    SH020503  SH020556         1.   
    SH020503  SH020557         1.   
    SH020503  SH020558         1.   
    SH020503  SH020559         1.   
    SH020503  SH020560         1.   
    SH020503  SH020563         1.   
    SH020503  SH020564         1.   
    SH020503  SH020571         1.   
    SH020503  SH020573         1.   
    SH020503  SH020577         1.   
    SH020503  SH020578         1.   
    SH020503  SH020582         1.   
    SH020503  SH020583         1.   
    SH020503  TRSH0502         1.   
    SH020104  SH020104        10.   
    SH020104  SH020105         1.   
    SH020104  SH020106         1.   
    SH020104  SH020107         1.   
    SH020104  SH020108         1.   
    SH020104  SH020109         1.   
    SH020104  SH020110         1.   
    SH020104  SH020111         1.   
    SH020104  SH020112         1.   
    SH020104  SH020114         1.   
    SH020104  SH020115         1.   
    SH020104  SH020116         1.   
    SH020104  SH020117         1.   
    SH020104  SH020119         1.   
    SH020104  SH020120         1.   
    SH020104  SH020121         1.   
    SH020104  SH020124         1.   
    SH020104  SH020128         1.   
    SH020104  SH020131         1.   
    SH020104  SH020133         1.   
    SH020104  SH020134         1.   
    SH020104  SH020137         1.   
    SH020104  SH020138         1.   
    SH020104  SH020139         1.   
    SH020104  SH020140         1.   
    SH020104  SH020142         1.   
    SH020104  SH020143         1.   
    SH020104  SH020145         1.   
    SH020104  SH020146         1.   
    SH020104  SH020147         1.   
    SH020104  SH020148         1.   
    SH020104  SH020149         1.   
    SH020104  SH020150         1.   
    SH020104  SH020151         1.   
    SH020104  SH020152         1.   
    SH020104  SH020153         1.   
    SH020104  SH020154         1.   
    SH020104  SH020155         1.   
    SH020104  SH020156         1.   
    SH020104  SH020157         1.   
    SH020104  SH020158         1.   
    SH020104  SH020159         1.   
    SH020104  SH020160         1.   
    SH020104  SH020163         1.   
    SH020104  SH020164         1.   
    SH020104  SH020171         1.   
    SH020104  SH020173         1.   
    SH020104  SH020177         1.   
    SH020104  SH020178         1.   
    SH020104  SH020182         1.   
    SH020104  SH020183         1.   
    SH020104  TRSH0102         1.   
    SH020204  SH020204        10.   
    SH020204  SH020205         1.   
    SH020204  SH020207         1.   
    SH020204  SH020208         1.   
    SH020204  SH020210         1.   
    SH020204  SH020215         1.   
    SH020204  SH020216         1.   
    SH020204  SH020219         1.   
    SH020204  SH020220         1.   
    SH020204  SH020221         1.   
    SH020204  SH020225         1.   
    SH020204  SH020233         1.   
    SH020204  SH020234         1.   
    SH020204  SH020237         1.   
    SH020204  SH020238         1.   
    SH020204  SH020240         1.   
    SH020204  SH020243         1.   
    SH020204  SH020245         1.   
    SH020204  SH020246         1.   
    SH020204  SH020252         1.   
    SH020204  SH020253         1.   
    SH020204  SH020255         1.   
    SH020204  SH020258         1.   
    SH020204  SH020259         1.   
    SH020204  SH020260         1.   
    SH020204  SH020264         1.   
    SH020204  SH020265         1.   
    SH020204  SH020266         1.   
    SH020204  SH020267         1.   
    SH020204  SH020268         1.   
    SH020204  SH020269         1.   
    SH020204  SH020272         1.   
    SH020204  SH020273         1.   
    SH020204  SH020274         1.   
    SH020204  SH020275         1.   
    SH020204  SH020276         1.   
    SH020204  SH020277         1.   
    SH020204  SH020278         1.   
    SH020204  SH020279         1.   
    SH020204  SH020282         1.   
    SH020204  SH020283         1.   
    SH020204  SH020284         1.   
    SH020204  TRSH0202         1.   
    SH020304  SH020304        10.   
    SH020304  SH020305         1.   
    SH020304  SH020307         1.   
    SH020304  SH020308         1.   
    SH020304  SH020310         1.   
    SH020304  SH020315         1.   
    SH020304  SH020316         1.   
    SH020304  SH020319         1.   
    SH020304  SH020320         1.   
    SH020304  SH020321         1.   
    SH020304  SH020333         1.   
    SH020304  SH020334         1.   
    SH020304  SH020337         1.   
    SH020304  SH020338         1.   
    SH020304  SH020340         1.   
    SH020304  SH020343         1.   
    SH020304  SH020345         1.   
    SH020304  SH020346         1.   
    SH020304  SH020352         1.   
    SH020304  SH020353         1.   
    SH020304  SH020355         1.   
    SH020304  SH020358         1.   
    SH020304  SH020359         1.   
    SH020304  SH020360         1.   
    SH020304  SH020364         1.   
    SH020304  SH020371         1.   
    SH020304  SH020373         1.   
    SH020304  SH020377         1.   
    SH020304  SH020378         1.   
    SH020304  SH020382         1.   
    SH020304  SH020383         1.   
    SH020304  TRSH0302         1.   
    SH020504  SH020504        10.   
    SH020504  SH020507         1.   
    SH020504  SH020508         1.   
    SH020504  SH020510         1.   
    SH020504  SH020515         1.   
    SH020504  SH020516         1.   
    SH020504  SH020519         1.   
    SH020504  SH020520         1.   
    SH020504  SH020521         1.   
    SH020504  SH020528         1.   
    SH020504  SH020533         1.   
    SH020504  SH020534         1.   
    SH020504  SH020537         1.   
    SH020504  SH020538         1.   
    SH020504  SH020540         1.   
    SH020504  SH020543         1.   
    SH020504  SH020545         1.   
    SH020504  SH020546         1.   
    SH020504  SH020549         1.   
    SH020504  SH020551         1.   
    SH020504  SH020552         1.   
    SH020504  SH020553         1.   
    SH020504  SH020555         1.   
    SH020504  SH020556         1.   
    SH020504  SH020557         1.   
    SH020504  SH020558         1.   
    SH020504  SH020559         1.   
    SH020504  SH020560         1.   
    SH020504  SH020563         1.   
    SH020504  SH020564         1.   
    SH020504  SH020571         1.   
    SH020504  SH020573         1.   
    SH020504  SH020577         1.   
    SH020504  SH020578         1.   
    SH020504  SH020582         1.   
    SH020504  SH020583         1.   
    SH020504  TRSH0502         1.   
    SH020105  SH020105        10.   
    SH020105  SH020106         1.   
    SH020105  SH020107         1.   
    SH020105  SH020108         1.   
    SH020105  SH020109         1.   
    SH020105  SH020110         1.   
    SH020105  SH020111         1.   
    SH020105  SH020112         1.   
    SH020105  SH020114         1.   
    SH020105  SH020115         1.   
    SH020105  SH020116         1.   
    SH020105  SH020117         1.   
    SH020105  SH020119         1.   
    SH020105  SH020120         1.   
    SH020105  SH020121         1.   
    SH020105  SH020124         1.   
    SH020105  SH020128         1.   
    SH020105  SH020131         1.   
    SH020105  SH020133         1.   
    SH020105  SH020134         1.   
    SH020105  SH020137         1.   
    SH020105  SH020138         1.   
    SH020105  SH020139         1.   
    SH020105  SH020140         1.   
    SH020105  SH020142         1.   
    SH020105  SH020143         1.   
    SH020105  SH020145         1.   
    SH020105  SH020146         1.   
    SH020105  SH020147         1.   
    SH020105  SH020148         1.   
    SH020105  SH020149         1.   
    SH020105  SH020150         1.   
    SH020105  SH020151         1.   
    SH020105  SH020152         1.   
    SH020105  SH020153         1.   
    SH020105  SH020154         1.   
    SH020105  SH020155         1.   
    SH020105  SH020156         1.   
    SH020105  SH020157         1.   
    SH020105  SH020158         1.   
    SH020105  SH020159         1.   
    SH020105  SH020160         1.   
    SH020105  SH020163         1.   
    SH020105  SH020164         1.   
    SH020105  SH020171         1.   
    SH020105  SH020173         1.   
    SH020105  SH020177         1.   
    SH020105  SH020178         1.   
    SH020105  SH020182         1.   
    SH020105  SH020183         1.   
    SH020105  TRSH0102         1.   
    SH020205  SH020205        10.   
    SH020205  SH020207         1.   
    SH020205  SH020208         1.   
    SH020205  SH020210         1.   
    SH020205  SH020215         1.   
    SH020205  SH020216         1.   
    SH020205  SH020219         1.   
    SH020205  SH020220         1.   
    SH020205  SH020221         1.   
    SH020205  SH020225         1.   
    SH020205  SH020233         1.   
    SH020205  SH020234         1.   
    SH020205  SH020237         1.   
    SH020205  SH020238         1.   
    SH020205  SH020240         1.   
    SH020205  SH020243         1.   
    SH020205  SH020245         1.   
    SH020205  SH020246         1.   
    SH020205  SH020252         1.   
    SH020205  SH020253         1.   
    SH020205  SH020255         1.   
    SH020205  SH020258         1.   
    SH020205  SH020259         1.   
    SH020205  SH020260         1.   
    SH020205  SH020264         1.   
    SH020205  SH020265         1.   
    SH020205  SH020266         1.   
    SH020205  SH020267         1.   
    SH020205  SH020268         1.   
    SH020205  SH020269         1.   
    SH020205  SH020272         1.   
    SH020205  SH020273         1.   
    SH020205  SH020274         1.   
    SH020205  SH020275         1.   
    SH020205  SH020276         1.   
    SH020205  SH020277         1.   
    SH020205  SH020278         1.   
    SH020205  SH020279         1.   
    SH020205  SH020282         1.   
    SH020205  SH020283         1.   
    SH020205  SH020284         1.   
    SH020205  TRSH0202         1.   
    SH020305  SH020305        10.   
    SH020305  SH020307         1.   
    SH020305  SH020308         1.   
    SH020305  SH020310         1.   
    SH020305  SH020315         1.   
    SH020305  SH020316         1.   
    SH020305  SH020319         1.   
    SH020305  SH020320         1.   
    SH020305  SH020321         1.   
    SH020305  SH020333         1.   
    SH020305  SH020334         1.   
    SH020305  SH020337         1.   
    SH020305  SH020338         1.   
    SH020305  SH020340         1.   
    SH020305  SH020343         1.   
    SH020305  SH020345         1.   
    SH020305  SH020346         1.   
    SH020305  SH020352         1.   
    SH020305  SH020353         1.   
    SH020305  SH020355         1.   
    SH020305  SH020358         1.   
    SH020305  SH020359         1.   
    SH020305  SH020360         1.   
    SH020305  SH020364         1.   
    SH020305  SH020371         1.   
    SH020305  SH020373         1.   
    SH020305  SH020377         1.   
    SH020305  SH020378         1.   
    SH020305  SH020382         1.   
    SH020305  SH020383         1.   
    SH020305  TRSH0302         1.   
    SH020405  SH020405        10.   
    SH020405  SH020407         1.   
    SH020405  SH020408         1.   
    SH020405  SH020410         1.   
    SH020405  SH020415         1.   
    SH020405  SH020416         1.   
    SH020405  SH020418         1.   
    SH020405  SH020419         1.   
    SH020405  SH020420         1.   
    SH020405  SH020421         1.   
    SH020405  SH020422         1.   
    SH020405  SH020423         1.   
    SH020405  SH020426         1.   
    SH020405  SH020429         1.   
    SH020405  SH020430         1.   
    SH020405  SH020432         1.   
    SH020405  SH020433         1.   
    SH020405  SH020434         1.   
    SH020405  SH020435         1.   
    SH020405  SH020437         1.   
    SH020405  SH020438         1.   
    SH020405  SH020440         1.   
    SH020405  SH020443         1.   
    SH020405  SH020445         1.   
    SH020405  SH020446         1.   
    SH020405  SH020452         1.   
    SH020405  SH020453         1.   
    SH020405  SH020455         1.   
    SH020405  SH020458         1.   
    SH020405  SH020459         1.   
    SH020405  SH020460         1.   
    SH020405  SH020464         1.   
    SH020405  SH020471         1.   
    SH020405  SH020473         1.   
    SH020405  SH020477         1.   
    SH020405  SH020478         1.   
    SH020405  SH020480         1.   
    SH020405  SH020482         1.   
    SH020405  SH020483         1.   
    SH020405  TRSH0402         1.   
    SH020106  SH020106        10.   
    SH020106  SH020107         1.   
    SH020106  SH020108         1.   
    SH020106  SH020109         1.   
    SH020106  SH020110         1.   
    SH020106  SH020111         1.   
    SH020106  SH020112         1.   
    SH020106  SH020114         1.   
    SH020106  SH020115         1.   
    SH020106  SH020116         1.   
    SH020106  SH020117         1.   
    SH020106  SH020119         1.   
    SH020106  SH020120         1.   
    SH020106  SH020121         1.   
    SH020106  SH020124         1.   
    SH020106  SH020128         1.   
    SH020106  SH020131         1.   
    SH020106  SH020133         1.   
    SH020106  SH020134         1.   
    SH020106  SH020137         1.   
    SH020106  SH020138         1.   
    SH020106  SH020139         1.   
    SH020106  SH020140         1.   
    SH020106  SH020142         1.   
    SH020106  SH020143         1.   
    SH020106  SH020145         1.   
    SH020106  SH020146         1.   
    SH020106  SH020147         1.   
    SH020106  SH020148         1.   
    SH020106  SH020149         1.   
    SH020106  SH020150         1.   
    SH020106  SH020151         1.   
    SH020106  SH020152         1.   
    SH020106  SH020153         1.   
    SH020106  SH020154         1.   
    SH020106  SH020155         1.   
    SH020106  SH020156         1.   
    SH020106  SH020157         1.   
    SH020106  SH020158         1.   
    SH020106  SH020159         1.   
    SH020106  SH020160         1.   
    SH020106  SH020163         1.   
    SH020106  SH020164         1.   
    SH020106  SH020171         1.   
    SH020106  SH020173         1.   
    SH020106  SH020177         1.   
    SH020106  SH020178         1.   
    SH020106  SH020182         1.   
    SH020106  SH020183         1.   
    SH020106  TRSH0102         1.   
    SH020107  SH020107        10.   
    SH020107  SH020108         1.   
    SH020107  SH020109         1.   
    SH020107  SH020110         1.   
    SH020107  SH020111         1.   
    SH020107  SH020112         1.   
    SH020107  SH020114         1.   
    SH020107  SH020115         1.   
    SH020107  SH020116         1.   
    SH020107  SH020117         1.   
    SH020107  SH020119         1.   
    SH020107  SH020120         1.   
    SH020107  SH020121         1.   
    SH020107  SH020124         1.   
    SH020107  SH020128         1.   
    SH020107  SH020131         1.   
    SH020107  SH020133         1.   
    SH020107  SH020134         1.   
    SH020107  SH020137         1.   
    SH020107  SH020138         1.   
    SH020107  SH020139         1.   
    SH020107  SH020140         1.   
    SH020107  SH020142         1.   
    SH020107  SH020143         1.   
    SH020107  SH020145         1.   
    SH020107  SH020146         1.   
    SH020107  SH020147         1.   
    SH020107  SH020148         1.   
    SH020107  SH020149         1.   
    SH020107  SH020150         1.   
    SH020107  SH020151         1.   
    SH020107  SH020152         1.   
    SH020107  SH020153         1.   
    SH020107  SH020154         1.   
    SH020107  SH020155         1.   
    SH020107  SH020156         1.   
    SH020107  SH020157         1.   
    SH020107  SH020158         1.   
    SH020107  SH020159         1.   
    SH020107  SH020160         1.   
    SH020107  SH020163         1.   
    SH020107  SH020164         1.   
    SH020107  SH020171         1.   
    SH020107  SH020173         1.   
    SH020107  SH020177         1.   
    SH020107  SH020178         1.   
    SH020107  SH020182         1.   
    SH020107  SH020183         1.   
    SH020107  TRSH0102         1.   
    SH020207  SH020207        10.   
    SH020207  SH020208         1.   
    SH020207  SH020210         1.   
    SH020207  SH020215         1.   
    SH020207  SH020216         1.   
    SH020207  SH020219         1.   
    SH020207  SH020220         1.   
    SH020207  SH020221         1.   
    SH020207  SH020225         1.   
    SH020207  SH020233         1.   
    SH020207  SH020234         1.   
    SH020207  SH020237         1.   
    SH020207  SH020238         1.   
    SH020207  SH020240         1.   
    SH020207  SH020243         1.   
    SH020207  SH020245         1.   
    SH020207  SH020246         1.   
    SH020207  SH020252         1.   
    SH020207  SH020253         1.   
    SH020207  SH020255         1.   
    SH020207  SH020258         1.   
    SH020207  SH020259         1.   
    SH020207  SH020260         1.   
    SH020207  SH020264         1.   
    SH020207  SH020265         1.   
    SH020207  SH020266         1.   
    SH020207  SH020267         1.   
    SH020207  SH020268         1.   
    SH020207  SH020269         1.   
    SH020207  SH020272         1.   
    SH020207  SH020273         1.   
    SH020207  SH020274         1.   
    SH020207  SH020275         1.   
    SH020207  SH020276         1.   
    SH020207  SH020277         1.   
    SH020207  SH020278         1.   
    SH020207  SH020279         1.   
    SH020207  SH020282         1.   
    SH020207  SH020283         1.   
    SH020207  SH020284         1.   
    SH020207  TRSH0202         1.   
    SH020307  SH020307        10.   
    SH020307  SH020308         1.   
    SH020307  SH020310         1.   
    SH020307  SH020315         1.   
    SH020307  SH020316         1.   
    SH020307  SH020319         1.   
    SH020307  SH020320         1.   
    SH020307  SH020321         1.   
    SH020307  SH020333         1.   
    SH020307  SH020334         1.   
    SH020307  SH020337         1.   
    SH020307  SH020338         1.   
    SH020307  SH020340         1.   
    SH020307  SH020343         1.   
    SH020307  SH020345         1.   
    SH020307  SH020346         1.   
    SH020307  SH020352         1.   
    SH020307  SH020353         1.   
    SH020307  SH020355         1.   
    SH020307  SH020358         1.   
    SH020307  SH020359         1.   
    SH020307  SH020360         1.   
    SH020307  SH020364         1.   
    SH020307  SH020371         1.   
    SH020307  SH020373         1.   
    SH020307  SH020377         1.   
    SH020307  SH020378         1.   
    SH020307  SH020382         1.   
    SH020307  SH020383         1.   
    SH020307  TRSH0302         1.   
    SH020407  SH020407        10.   
    SH020407  SH020408         1.   
    SH020407  SH020410         1.   
    SH020407  SH020415         1.   
    SH020407  SH020416         1.   
    SH020407  SH020418         1.   
    SH020407  SH020419         1.   
    SH020407  SH020420         1.   
    SH020407  SH020421         1.   
    SH020407  SH020422         1.   
    SH020407  SH020423         1.   
    SH020407  SH020426         1.   
    SH020407  SH020429         1.   
    SH020407  SH020430         1.   
    SH020407  SH020432         1.   
    SH020407  SH020433         1.   
    SH020407  SH020434         1.   
    SH020407  SH020435         1.   
    SH020407  SH020437         1.   
    SH020407  SH020438         1.   
    SH020407  SH020440         1.   
    SH020407  SH020443         1.   
    SH020407  SH020445         1.   
    SH020407  SH020446         1.   
    SH020407  SH020452         1.   
    SH020407  SH020453         1.   
    SH020407  SH020455         1.   
    SH020407  SH020458         1.   
    SH020407  SH020459         1.   
    SH020407  SH020460         1.   
    SH020407  SH020464         1.   
    SH020407  SH020471         1.   
    SH020407  SH020473         1.   
    SH020407  SH020477         1.   
    SH020407  SH020478         1.   
    SH020407  SH020480         1.   
    SH020407  SH020482         1.   
    SH020407  SH020483         1.   
    SH020407  TRSH0402         1.   
    SH020507  SH020507        10.   
    SH020507  SH020508         1.   
    SH020507  SH020510         1.   
    SH020507  SH020515         1.   
    SH020507  SH020516         1.   
    SH020507  SH020519         1.   
    SH020507  SH020520         1.   
    SH020507  SH020521         1.   
    SH020507  SH020528         1.   
    SH020507  SH020533         1.   
    SH020507  SH020534         1.   
    SH020507  SH020537         1.   
    SH020507  SH020538         1.   
    SH020507  SH020540         1.   
    SH020507  SH020543         1.   
    SH020507  SH020545         1.   
    SH020507  SH020546         1.   
    SH020507  SH020549         1.   
    SH020507  SH020551         1.   
    SH020507  SH020552         1.   
    SH020507  SH020553         1.   
    SH020507  SH020555         1.   
    SH020507  SH020556         1.   
    SH020507  SH020557         1.   
    SH020507  SH020558         1.   
    SH020507  SH020559         1.   
    SH020507  SH020560         1.   
    SH020507  SH020563         1.   
    SH020507  SH020564         1.   
    SH020507  SH020571         1.   
    SH020507  SH020573         1.   
    SH020507  SH020577         1.   
    SH020507  SH020578         1.   
    SH020507  SH020582         1.   
    SH020507  SH020583         1.   
    SH020507  TRSH0502         1.   
    SH020108  SH020108        10.   
    SH020108  SH020109         1.   
    SH020108  SH020110         1.   
    SH020108  SH020111         1.   
    SH020108  SH020112         1.   
    SH020108  SH020114         1.   
    SH020108  SH020115         1.   
    SH020108  SH020116         1.   
    SH020108  SH020117         1.   
    SH020108  SH020119         1.   
    SH020108  SH020120         1.   
    SH020108  SH020121         1.   
    SH020108  SH020124         1.   
    SH020108  SH020128         1.   
    SH020108  SH020131         1.   
    SH020108  SH020133         1.   
    SH020108  SH020134         1.   
    SH020108  SH020137         1.   
    SH020108  SH020138         1.   
    SH020108  SH020139         1.   
    SH020108  SH020140         1.   
    SH020108  SH020142         1.   
    SH020108  SH020143         1.   
    SH020108  SH020145         1.   
    SH020108  SH020146         1.   
    SH020108  SH020147         1.   
    SH020108  SH020148         1.   
    SH020108  SH020149         1.   
    SH020108  SH020150         1.   
    SH020108  SH020151         1.   
    SH020108  SH020152         1.   
    SH020108  SH020153         1.   
    SH020108  SH020154         1.   
    SH020108  SH020155         1.   
    SH020108  SH020156         1.   
    SH020108  SH020157         1.   
    SH020108  SH020158         1.   
    SH020108  SH020159         1.   
    SH020108  SH020160         1.   
    SH020108  SH020163         1.   
    SH020108  SH020164         1.   
    SH020108  SH020171         1.   
    SH020108  SH020173         1.   
    SH020108  SH020177         1.   
    SH020108  SH020178         1.   
    SH020108  SH020182         1.   
    SH020108  SH020183         1.   
    SH020108  TRSH0102         1.   
    SH020208  SH020208        10.   
    SH020208  SH020210         1.   
    SH020208  SH020215         1.   
    SH020208  SH020216         1.   
    SH020208  SH020219         1.   
    SH020208  SH020220         1.   
    SH020208  SH020221         1.   
    SH020208  SH020225         1.   
    SH020208  SH020233         1.   
    SH020208  SH020234         1.   
    SH020208  SH020237         1.   
    SH020208  SH020238         1.   
    SH020208  SH020240         1.   
    SH020208  SH020243         1.   
    SH020208  SH020245         1.   
    SH020208  SH020246         1.   
    SH020208  SH020252         1.   
    SH020208  SH020253         1.   
    SH020208  SH020255         1.   
    SH020208  SH020258         1.   
    SH020208  SH020259         1.   
    SH020208  SH020260         1.   
    SH020208  SH020264         1.   
    SH020208  SH020265         1.   
    SH020208  SH020266         1.   
    SH020208  SH020267         1.   
    SH020208  SH020268         1.   
    SH020208  SH020269         1.   
    SH020208  SH020272         1.   
    SH020208  SH020273         1.   
    SH020208  SH020274         1.   
    SH020208  SH020275         1.   
    SH020208  SH020276         1.   
    SH020208  SH020277         1.   
    SH020208  SH020278         1.   
    SH020208  SH020279         1.   
    SH020208  SH020282         1.   
    SH020208  SH020283         1.   
    SH020208  SH020284         1.   
    SH020208  TRSH0202         1.   
    SH020308  SH020308        10.   
    SH020308  SH020310         1.   
    SH020308  SH020315         1.   
    SH020308  SH020316         1.   
    SH020308  SH020319         1.   
    SH020308  SH020320         1.   
    SH020308  SH020321         1.   
    SH020308  SH020333         1.   
    SH020308  SH020334         1.   
    SH020308  SH020337         1.   
    SH020308  SH020338         1.   
    SH020308  SH020340         1.   
    SH020308  SH020343         1.   
    SH020308  SH020345         1.   
    SH020308  SH020346         1.   
    SH020308  SH020352         1.   
    SH020308  SH020353         1.   
    SH020308  SH020355         1.   
    SH020308  SH020358         1.   
    SH020308  SH020359         1.   
    SH020308  SH020360         1.   
    SH020308  SH020364         1.   
    SH020308  SH020371         1.   
    SH020308  SH020373         1.   
    SH020308  SH020377         1.   
    SH020308  SH020378         1.   
    SH020308  SH020382         1.   
    SH020308  SH020383         1.   
    SH020308  TRSH0302         1.   
    SH020408  SH020408        10.   
    SH020408  SH020410         1.   
    SH020408  SH020415         1.   
    SH020408  SH020416         1.   
    SH020408  SH020418         1.   
    SH020408  SH020419         1.   
    SH020408  SH020420         1.   
    SH020408  SH020421         1.   
    SH020408  SH020422         1.   
    SH020408  SH020423         1.   
    SH020408  SH020426         1.   
    SH020408  SH020429         1.   
    SH020408  SH020430         1.   
    SH020408  SH020432         1.   
    SH020408  SH020433         1.   
    SH020408  SH020434         1.   
    SH020408  SH020435         1.   
    SH020408  SH020437         1.   
    SH020408  SH020438         1.   
    SH020408  SH020440         1.   
    SH020408  SH020443         1.   
    SH020408  SH020445         1.   
    SH020408  SH020446         1.   
    SH020408  SH020452         1.   
    SH020408  SH020453         1.   
    SH020408  SH020455         1.   
    SH020408  SH020458         1.   
    SH020408  SH020459         1.   
    SH020408  SH020460         1.   
    SH020408  SH020464         1.   
    SH020408  SH020471         1.   
    SH020408  SH020473         1.   
    SH020408  SH020477         1.   
    SH020408  SH020478         1.   
    SH020408  SH020480         1.   
    SH020408  SH020482         1.   
    SH020408  SH020483         1.   
    SH020408  TRSH0402         1.   
    SH020508  SH020508        10.   
    SH020508  SH020510         1.   
    SH020508  SH020515         1.   
    SH020508  SH020516         1.   
    SH020508  SH020519         1.   
    SH020508  SH020520         1.   
    SH020508  SH020521         1.   
    SH020508  SH020528         1.   
    SH020508  SH020533         1.   
    SH020508  SH020534         1.   
    SH020508  SH020537         1.   
    SH020508  SH020538         1.   
    SH020508  SH020540         1.   
    SH020508  SH020543         1.   
    SH020508  SH020545         1.   
    SH020508  SH020546         1.   
    SH020508  SH020549         1.   
    SH020508  SH020551         1.   
    SH020508  SH020552         1.   
    SH020508  SH020553         1.   
    SH020508  SH020555         1.   
    SH020508  SH020556         1.   
    SH020508  SH020557         1.   
    SH020508  SH020558         1.   
    SH020508  SH020559         1.   
    SH020508  SH020560         1.   
    SH020508  SH020563         1.   
    SH020508  SH020564         1.   
    SH020508  SH020571         1.   
    SH020508  SH020573         1.   
    SH020508  SH020577         1.   
    SH020508  SH020578         1.   
    SH020508  SH020582         1.   
    SH020508  SH020583         1.   
    SH020508  TRSH0502         1.   
    SH020109  SH020109        10.   
    SH020109  SH020110         1.   
    SH020109  SH020111         1.   
    SH020109  SH020112         1.   
    SH020109  SH020114         1.   
    SH020109  SH020115         1.   
    SH020109  SH020116         1.   
    SH020109  SH020117         1.   
    SH020109  SH020119         1.   
    SH020109  SH020120         1.   
    SH020109  SH020121         1.   
    SH020109  SH020124         1.   
    SH020109  SH020128         1.   
    SH020109  SH020131         1.   
    SH020109  SH020133         1.   
    SH020109  SH020134         1.   
    SH020109  SH020137         1.   
    SH020109  SH020138         1.   
    SH020109  SH020139         1.   
    SH020109  SH020140         1.   
    SH020109  SH020142         1.   
    SH020109  SH020143         1.   
    SH020109  SH020145         1.   
    SH020109  SH020146         1.   
    SH020109  SH020147         1.   
    SH020109  SH020148         1.   
    SH020109  SH020149         1.   
    SH020109  SH020150         1.   
    SH020109  SH020151         1.   
    SH020109  SH020152         1.   
    SH020109  SH020153         1.   
    SH020109  SH020154         1.   
    SH020109  SH020155         1.   
    SH020109  SH020156         1.   
    SH020109  SH020157         1.   
    SH020109  SH020158         1.   
    SH020109  SH020159         1.   
    SH020109  SH020160         1.   
    SH020109  SH020163         1.   
    SH020109  SH020164         1.   
    SH020109  SH020171         1.   
    SH020109  SH020173         1.   
    SH020109  SH020177         1.   
    SH020109  SH020178         1.   
    SH020109  SH020182         1.   
    SH020109  SH020183         1.   
    SH020109  TRSH0102         1.   
    SH020110  SH020110        10.   
    SH020110  SH020111         1.   
    SH020110  SH020112         1.   
    SH020110  SH020114         1.   
    SH020110  SH020115         1.   
    SH020110  SH020116         1.   
    SH020110  SH020117         1.   
    SH020110  SH020119         1.   
    SH020110  SH020120         1.   
    SH020110  SH020121         1.   
    SH020110  SH020124         1.   
    SH020110  SH020128         1.   
    SH020110  SH020131         1.   
    SH020110  SH020133         1.   
    SH020110  SH020134         1.   
    SH020110  SH020137         1.   
    SH020110  SH020138         1.   
    SH020110  SH020139         1.   
    SH020110  SH020140         1.   
    SH020110  SH020142         1.   
    SH020110  SH020143         1.   
    SH020110  SH020145         1.   
    SH020110  SH020146         1.   
    SH020110  SH020147         1.   
    SH020110  SH020148         1.   
    SH020110  SH020149         1.   
    SH020110  SH020150         1.   
    SH020110  SH020151         1.   
    SH020110  SH020152         1.   
    SH020110  SH020153         1.   
    SH020110  SH020154         1.   
    SH020110  SH020155         1.   
    SH020110  SH020156         1.   
    SH020110  SH020157         1.   
    SH020110  SH020158         1.   
    SH020110  SH020159         1.   
    SH020110  SH020160         1.   
    SH020110  SH020163         1.   
    SH020110  SH020164         1.   
    SH020110  SH020171         1.   
    SH020110  SH020173         1.   
    SH020110  SH020177         1.   
    SH020110  SH020178         1.   
    SH020110  SH020182         1.   
    SH020110  SH020183         1.   
    SH020110  TRSH0102         1.   
    SH020210  SH020210        10.   
    SH020210  SH020215         1.   
    SH020210  SH020216         1.   
    SH020210  SH020219         1.   
    SH020210  SH020220         1.   
    SH020210  SH020221         1.   
    SH020210  SH020225         1.   
    SH020210  SH020233         1.   
    SH020210  SH020234         1.   
    SH020210  SH020237         1.   
    SH020210  SH020238         1.   
    SH020210  SH020240         1.   
    SH020210  SH020243         1.   
    SH020210  SH020245         1.   
    SH020210  SH020246         1.   
    SH020210  SH020252         1.   
    SH020210  SH020253         1.   
    SH020210  SH020255         1.   
    SH020210  SH020258         1.   
    SH020210  SH020259         1.   
    SH020210  SH020260         1.   
    SH020210  SH020264         1.   
    SH020210  SH020265         1.   
    SH020210  SH020266         1.   
    SH020210  SH020267         1.   
    SH020210  SH020268         1.   
    SH020210  SH020269         1.   
    SH020210  SH020272         1.   
    SH020210  SH020273         1.   
    SH020210  SH020274         1.   
    SH020210  SH020275         1.   
    SH020210  SH020276         1.   
    SH020210  SH020277         1.   
    SH020210  SH020278         1.   
    SH020210  SH020279         1.   
    SH020210  SH020282         1.   
    SH020210  SH020283         1.   
    SH020210  SH020284         1.   
    SH020210  TRSH0202         1.   
    SH020310  SH020310        10.   
    SH020310  SH020315         1.   
    SH020310  SH020316         1.   
    SH020310  SH020319         1.   
    SH020310  SH020320         1.   
    SH020310  SH020321         1.   
    SH020310  SH020333         1.   
    SH020310  SH020334         1.   
    SH020310  SH020337         1.   
    SH020310  SH020338         1.   
    SH020310  SH020340         1.   
    SH020310  SH020343         1.   
    SH020310  SH020345         1.   
    SH020310  SH020346         1.   
    SH020310  SH020352         1.   
    SH020310  SH020353         1.   
    SH020310  SH020355         1.   
    SH020310  SH020358         1.   
    SH020310  SH020359         1.   
    SH020310  SH020360         1.   
    SH020310  SH020364         1.   
    SH020310  SH020371         1.   
    SH020310  SH020373         1.   
    SH020310  SH020377         1.   
    SH020310  SH020378         1.   
    SH020310  SH020382         1.   
    SH020310  SH020383         1.   
    SH020310  TRSH0302         1.   
    SH020410  SH020410        10.   
    SH020410  SH020415         1.   
    SH020410  SH020416         1.   
    SH020410  SH020418         1.   
    SH020410  SH020419         1.   
    SH020410  SH020420         1.   
    SH020410  SH020421         1.   
    SH020410  SH020422         1.   
    SH020410  SH020423         1.   
    SH020410  SH020426         1.   
    SH020410  SH020429         1.   
    SH020410  SH020430         1.   
    SH020410  SH020432         1.   
    SH020410  SH020433         1.   
    SH020410  SH020434         1.   
    SH020410  SH020435         1.   
    SH020410  SH020437         1.   
    SH020410  SH020438         1.   
    SH020410  SH020440         1.   
    SH020410  SH020443         1.   
    SH020410  SH020445         1.   
    SH020410  SH020446         1.   
    SH020410  SH020452         1.   
    SH020410  SH020453         1.   
    SH020410  SH020455         1.   
    SH020410  SH020458         1.   
    SH020410  SH020459         1.   
    SH020410  SH020460         1.   
    SH020410  SH020464         1.   
    SH020410  SH020471         1.   
    SH020410  SH020473         1.   
    SH020410  SH020477         1.   
    SH020410  SH020478         1.   
    SH020410  SH020480         1.   
    SH020410  SH020482         1.   
    SH020410  SH020483         1.   
    SH020410  TRSH0402         1.   
    SH020510  SH020510        10.   
    SH020510  SH020515         1.   
    SH020510  SH020516         1.   
    SH020510  SH020519         1.   
    SH020510  SH020520         1.   
    SH020510  SH020521         1.   
    SH020510  SH020528         1.   
    SH020510  SH020533         1.   
    SH020510  SH020534         1.   
    SH020510  SH020537         1.   
    SH020510  SH020538         1.   
    SH020510  SH020540         1.   
    SH020510  SH020543         1.   
    SH020510  SH020545         1.   
    SH020510  SH020546         1.   
    SH020510  SH020549         1.   
    SH020510  SH020551         1.   
    SH020510  SH020552         1.   
    SH020510  SH020553         1.   
    SH020510  SH020555         1.   
    SH020510  SH020556         1.   
    SH020510  SH020557         1.   
    SH020510  SH020558         1.   
    SH020510  SH020559         1.   
    SH020510  SH020560         1.   
    SH020510  SH020563         1.   
    SH020510  SH020564         1.   
    SH020510  SH020571         1.   
    SH020510  SH020573         1.   
    SH020510  SH020577         1.   
    SH020510  SH020578         1.   
    SH020510  SH020582         1.   
    SH020510  SH020583         1.   
    SH020510  TRSH0502         1.   
    SH020111  SH020111        10.   
    SH020111  SH020112         1.   
    SH020111  SH020114         1.   
    SH020111  SH020115         1.   
    SH020111  SH020116         1.   
    SH020111  SH020117         1.   
    SH020111  SH020119         1.   
    SH020111  SH020120         1.   
    SH020111  SH020121         1.   
    SH020111  SH020124         1.   
    SH020111  SH020128         1.   
    SH020111  SH020131         1.   
    SH020111  SH020133         1.   
    SH020111  SH020134         1.   
    SH020111  SH020137         1.   
    SH020111  SH020138         1.   
    SH020111  SH020139         1.   
    SH020111  SH020140         1.   
    SH020111  SH020142         1.   
    SH020111  SH020143         1.   
    SH020111  SH020145         1.   
    SH020111  SH020146         1.   
    SH020111  SH020147         1.   
    SH020111  SH020148         1.   
    SH020111  SH020149         1.   
    SH020111  SH020150         1.   
    SH020111  SH020151         1.   
    SH020111  SH020152         1.   
    SH020111  SH020153         1.   
    SH020111  SH020154         1.   
    SH020111  SH020155         1.   
    SH020111  SH020156         1.   
    SH020111  SH020157         1.   
    SH020111  SH020158         1.   
    SH020111  SH020159         1.   
    SH020111  SH020160         1.   
    SH020111  SH020163         1.   
    SH020111  SH020164         1.   
    SH020111  SH020171         1.   
    SH020111  SH020173         1.   
    SH020111  SH020177         1.   
    SH020111  SH020178         1.   
    SH020111  SH020182         1.   
    SH020111  SH020183         1.   
    SH020111  TRSH0102         1.   
    SH020112  SH020112        10.   
    SH020112  SH020114         1.   
    SH020112  SH020115         1.   
    SH020112  SH020116         1.   
    SH020112  SH020117         1.   
    SH020112  SH020119         1.   
    SH020112  SH020120         1.   
    SH020112  SH020121         1.   
    SH020112  SH020124         1.   
    SH020112  SH020128         1.   
    SH020112  SH020131         1.   
    SH020112  SH020133         1.   
    SH020112  SH020134         1.   
    SH020112  SH020137         1.   
    SH020112  SH020138         1.   
    SH020112  SH020139         1.   
    SH020112  SH020140         1.   
    SH020112  SH020142         1.   
    SH020112  SH020143         1.   
    SH020112  SH020145         1.   
    SH020112  SH020146         1.   
    SH020112  SH020147         1.   
    SH020112  SH020148         1.   
    SH020112  SH020149         1.   
    SH020112  SH020150         1.   
    SH020112  SH020151         1.   
    SH020112  SH020152         1.   
    SH020112  SH020153         1.   
    SH020112  SH020154         1.   
    SH020112  SH020155         1.   
    SH020112  SH020156         1.   
    SH020112  SH020157         1.   
    SH020112  SH020158         1.   
    SH020112  SH020159         1.   
    SH020112  SH020160         1.   
    SH020112  SH020163         1.   
    SH020112  SH020164         1.   
    SH020112  SH020171         1.   
    SH020112  SH020173         1.   
    SH020112  SH020177         1.   
    SH020112  SH020178         1.   
    SH020112  SH020182         1.   
    SH020112  SH020183         1.   
    SH020112  TRSH0102         1.   
    SH020114  SH020114        10.   
    SH020114  SH020115         1.   
    SH020114  SH020116         1.   
    SH020114  SH020117         1.   
    SH020114  SH020119         1.   
    SH020114  SH020120         1.   
    SH020114  SH020121         1.   
    SH020114  SH020124         1.   
    SH020114  SH020128         1.   
    SH020114  SH020131         1.   
    SH020114  SH020133         1.   
    SH020114  SH020134         1.   
    SH020114  SH020137         1.   
    SH020114  SH020138         1.   
    SH020114  SH020139         1.   
    SH020114  SH020140         1.   
    SH020114  SH020142         1.   
    SH020114  SH020143         1.   
    SH020114  SH020145         1.   
    SH020114  SH020146         1.   
    SH020114  SH020147         1.   
    SH020114  SH020148         1.   
    SH020114  SH020149         1.   
    SH020114  SH020150         1.   
    SH020114  SH020151         1.   
    SH020114  SH020152         1.   
    SH020114  SH020153         1.   
    SH020114  SH020154         1.   
    SH020114  SH020155         1.   
    SH020114  SH020156         1.   
    SH020114  SH020157         1.   
    SH020114  SH020158         1.   
    SH020114  SH020159         1.   
    SH020114  SH020160         1.   
    SH020114  SH020163         1.   
    SH020114  SH020164         1.   
    SH020114  SH020171         1.   
    SH020114  SH020173         1.   
    SH020114  SH020177         1.   
    SH020114  SH020178         1.   
    SH020114  SH020182         1.   
    SH020114  SH020183         1.   
    SH020114  TRSH0102         1.   
    SH020115  SH020115        10.   
    SH020115  SH020116         1.   
    SH020115  SH020117         1.   
    SH020115  SH020119         1.   
    SH020115  SH020120         1.   
    SH020115  SH020121         1.   
    SH020115  SH020124         1.   
    SH020115  SH020128         1.   
    SH020115  SH020131         1.   
    SH020115  SH020133         1.   
    SH020115  SH020134         1.   
    SH020115  SH020137         1.   
    SH020115  SH020138         1.   
    SH020115  SH020139         1.   
    SH020115  SH020140         1.   
    SH020115  SH020142         1.   
    SH020115  SH020143         1.   
    SH020115  SH020145         1.   
    SH020115  SH020146         1.   
    SH020115  SH020147         1.   
    SH020115  SH020148         1.   
    SH020115  SH020149         1.   
    SH020115  SH020150         1.   
    SH020115  SH020151         1.   
    SH020115  SH020152         1.   
    SH020115  SH020153         1.   
    SH020115  SH020154         1.   
    SH020115  SH020155         1.   
    SH020115  SH020156         1.   
    SH020115  SH020157         1.   
    SH020115  SH020158         1.   
    SH020115  SH020159         1.   
    SH020115  SH020160         1.   
    SH020115  SH020163         1.   
    SH020115  SH020164         1.   
    SH020115  SH020171         1.   
    SH020115  SH020173         1.   
    SH020115  SH020177         1.   
    SH020115  SH020178         1.   
    SH020115  SH020182         1.   
    SH020115  SH020183         1.   
    SH020115  TRSH0102         1.   
    SH020215  SH020215        10.   
    SH020215  SH020216         1.   
    SH020215  SH020219         1.   
    SH020215  SH020220         1.   
    SH020215  SH020221         1.   
    SH020215  SH020225         1.   
    SH020215  SH020233         1.   
    SH020215  SH020234         1.   
    SH020215  SH020237         1.   
    SH020215  SH020238         1.   
    SH020215  SH020240         1.   
    SH020215  SH020243         1.   
    SH020215  SH020245         1.   
    SH020215  SH020246         1.   
    SH020215  SH020252         1.   
    SH020215  SH020253         1.   
    SH020215  SH020255         1.   
    SH020215  SH020258         1.   
    SH020215  SH020259         1.   
    SH020215  SH020260         1.   
    SH020215  SH020264         1.   
    SH020215  SH020265         1.   
    SH020215  SH020266         1.   
    SH020215  SH020267         1.   
    SH020215  SH020268         1.   
    SH020215  SH020269         1.   
    SH020215  SH020272         1.   
    SH020215  SH020273         1.   
    SH020215  SH020274         1.   
    SH020215  SH020275         1.   
    SH020215  SH020276         1.   
    SH020215  SH020277         1.   
    SH020215  SH020278         1.   
    SH020215  SH020279         1.   
    SH020215  SH020282         1.   
    SH020215  SH020283         1.   
    SH020215  SH020284         1.   
    SH020215  TRSH0202         1.   
    SH020315  SH020315        10.   
    SH020315  SH020316         1.   
    SH020315  SH020319         1.   
    SH020315  SH020320         1.   
    SH020315  SH020321         1.   
    SH020315  SH020333         1.   
    SH020315  SH020334         1.   
    SH020315  SH020337         1.   
    SH020315  SH020338         1.   
    SH020315  SH020340         1.   
    SH020315  SH020343         1.   
    SH020315  SH020345         1.   
    SH020315  SH020346         1.   
    SH020315  SH020352         1.   
    SH020315  SH020353         1.   
    SH020315  SH020355         1.   
    SH020315  SH020358         1.   
    SH020315  SH020359         1.   
    SH020315  SH020360         1.   
    SH020315  SH020364         1.   
    SH020315  SH020371         1.   
    SH020315  SH020373         1.   
    SH020315  SH020377         1.   
    SH020315  SH020378         1.   
    SH020315  SH020382         1.   
    SH020315  SH020383         1.   
    SH020315  TRSH0302         1.   
    SH020415  SH020415        10.   
    SH020415  SH020416         1.   
    SH020415  SH020418         1.   
    SH020415  SH020419         1.   
    SH020415  SH020420         1.   
    SH020415  SH020421         1.   
    SH020415  SH020422         1.   
    SH020415  SH020423         1.   
    SH020415  SH020426         1.   
    SH020415  SH020429         1.   
    SH020415  SH020430         1.   
    SH020415  SH020432         1.   
    SH020415  SH020433         1.   
    SH020415  SH020434         1.   
    SH020415  SH020435         1.   
    SH020415  SH020437         1.   
    SH020415  SH020438         1.   
    SH020415  SH020440         1.   
    SH020415  SH020443         1.   
    SH020415  SH020445         1.   
    SH020415  SH020446         1.   
    SH020415  SH020452         1.   
    SH020415  SH020453         1.   
    SH020415  SH020455         1.   
    SH020415  SH020458         1.   
    SH020415  SH020459         1.   
    SH020415  SH020460         1.   
    SH020415  SH020464         1.   
    SH020415  SH020471         1.   
    SH020415  SH020473         1.   
    SH020415  SH020477         1.   
    SH020415  SH020478         1.   
    SH020415  SH020480         1.   
    SH020415  SH020482         1.   
    SH020415  SH020483         1.   
    SH020415  TRSH0402         1.   
    SH020515  SH020515        10.   
    SH020515  SH020516         1.   
    SH020515  SH020519         1.   
    SH020515  SH020520         1.   
    SH020515  SH020521         1.   
    SH020515  SH020528         1.   
    SH020515  SH020533         1.   
    SH020515  SH020534         1.   
    SH020515  SH020537         1.   
    SH020515  SH020538         1.   
    SH020515  SH020540         1.   
    SH020515  SH020543         1.   
    SH020515  SH020545         1.   
    SH020515  SH020546         1.   
    SH020515  SH020549         1.   
    SH020515  SH020551         1.   
    SH020515  SH020552         1.   
    SH020515  SH020553         1.   
    SH020515  SH020555         1.   
    SH020515  SH020556         1.   
    SH020515  SH020557         1.   
    SH020515  SH020558         1.   
    SH020515  SH020559         1.   
    SH020515  SH020560         1.   
    SH020515  SH020563         1.   
    SH020515  SH020564         1.   
    SH020515  SH020571         1.   
    SH020515  SH020573         1.   
    SH020515  SH020577         1.   
    SH020515  SH020578         1.   
    SH020515  SH020582         1.   
    SH020515  SH020583         1.   
    SH020515  TRSH0502         1.   
    SH020116  SH020116        10.   
    SH020116  SH020117         1.   
    SH020116  SH020119         1.   
    SH020116  SH020120         1.   
    SH020116  SH020121         1.   
    SH020116  SH020124         1.   
    SH020116  SH020128         1.   
    SH020116  SH020131         1.   
    SH020116  SH020133         1.   
    SH020116  SH020134         1.   
    SH020116  SH020137         1.   
    SH020116  SH020138         1.   
    SH020116  SH020139         1.   
    SH020116  SH020140         1.   
    SH020116  SH020142         1.   
    SH020116  SH020143         1.   
    SH020116  SH020145         1.   
    SH020116  SH020146         1.   
    SH020116  SH020147         1.   
    SH020116  SH020148         1.   
    SH020116  SH020149         1.   
    SH020116  SH020150         1.   
    SH020116  SH020151         1.   
    SH020116  SH020152         1.   
    SH020116  SH020153         1.   
    SH020116  SH020154         1.   
    SH020116  SH020155         1.   
    SH020116  SH020156         1.   
    SH020116  SH020157         1.   
    SH020116  SH020158         1.   
    SH020116  SH020159         1.   
    SH020116  SH020160         1.   
    SH020116  SH020163         1.   
    SH020116  SH020164         1.   
    SH020116  SH020171         1.   
    SH020116  SH020173         1.   
    SH020116  SH020177         1.   
    SH020116  SH020178         1.   
    SH020116  SH020182         1.   
    SH020116  SH020183         1.   
    SH020116  TRSH0102         1.   
    SH020216  SH020216        10.   
    SH020216  SH020219         1.   
    SH020216  SH020220         1.   
    SH020216  SH020221         1.   
    SH020216  SH020225         1.   
    SH020216  SH020233         1.   
    SH020216  SH020234         1.   
    SH020216  SH020237         1.   
    SH020216  SH020238         1.   
    SH020216  SH020240         1.   
    SH020216  SH020243         1.   
    SH020216  SH020245         1.   
    SH020216  SH020246         1.   
    SH020216  SH020252         1.   
    SH020216  SH020253         1.   
    SH020216  SH020255         1.   
    SH020216  SH020258         1.   
    SH020216  SH020259         1.   
    SH020216  SH020260         1.   
    SH020216  SH020264         1.   
    SH020216  SH020265         1.   
    SH020216  SH020266         1.   
    SH020216  SH020267         1.   
    SH020216  SH020268         1.   
    SH020216  SH020269         1.   
    SH020216  SH020272         1.   
    SH020216  SH020273         1.   
    SH020216  SH020274         1.   
    SH020216  SH020275         1.   
    SH020216  SH020276         1.   
    SH020216  SH020277         1.   
    SH020216  SH020278         1.   
    SH020216  SH020279         1.   
    SH020216  SH020282         1.   
    SH020216  SH020283         1.   
    SH020216  SH020284         1.   
    SH020216  TRSH0202         1.   
    SH020316  SH020316        10.   
    SH020316  SH020319         1.   
    SH020316  SH020320         1.   
    SH020316  SH020321         1.   
    SH020316  SH020333         1.   
    SH020316  SH020334         1.   
    SH020316  SH020337         1.   
    SH020316  SH020338         1.   
    SH020316  SH020340         1.   
    SH020316  SH020343         1.   
    SH020316  SH020345         1.   
    SH020316  SH020346         1.   
    SH020316  SH020352         1.   
    SH020316  SH020353         1.   
    SH020316  SH020355         1.   
    SH020316  SH020358         1.   
    SH020316  SH020359         1.   
    SH020316  SH020360         1.   
    SH020316  SH020364         1.   
    SH020316  SH020371         1.   
    SH020316  SH020373         1.   
    SH020316  SH020377         1.   
    SH020316  SH020378         1.   
    SH020316  SH020382         1.   
    SH020316  SH020383         1.   
    SH020316  TRSH0302         1.   
    SH020416  SH020416        10.   
    SH020416  SH020418         1.   
    SH020416  SH020419         1.   
    SH020416  SH020420         1.   
    SH020416  SH020421         1.   
    SH020416  SH020422         1.   
    SH020416  SH020423         1.   
    SH020416  SH020426         1.   
    SH020416  SH020429         1.   
    SH020416  SH020430         1.   
    SH020416  SH020432         1.   
    SH020416  SH020433         1.   
    SH020416  SH020434         1.   
    SH020416  SH020435         1.   
    SH020416  SH020437         1.   
    SH020416  SH020438         1.   
    SH020416  SH020440         1.   
    SH020416  SH020443         1.   
    SH020416  SH020445         1.   
    SH020416  SH020446         1.   
    SH020416  SH020452         1.   
    SH020416  SH020453         1.   
    SH020416  SH020455         1.   
    SH020416  SH020458         1.   
    SH020416  SH020459         1.   
    SH020416  SH020460         1.   
    SH020416  SH020464         1.   
    SH020416  SH020471         1.   
    SH020416  SH020473         1.   
    SH020416  SH020477         1.   
    SH020416  SH020478         1.   
    SH020416  SH020480         1.   
    SH020416  SH020482         1.   
    SH020416  SH020483         1.   
    SH020416  TRSH0402         1.   
    SH020516  SH020516        10.   
    SH020516  SH020519         1.   
    SH020516  SH020520         1.   
    SH020516  SH020521         1.   
    SH020516  SH020528         1.   
    SH020516  SH020533         1.   
    SH020516  SH020534         1.   
    SH020516  SH020537         1.   
    SH020516  SH020538         1.   
    SH020516  SH020540         1.   
    SH020516  SH020543         1.   
    SH020516  SH020545         1.   
    SH020516  SH020546         1.   
    SH020516  SH020549         1.   
    SH020516  SH020551         1.   
    SH020516  SH020552         1.   
    SH020516  SH020553         1.   
    SH020516  SH020555         1.   
    SH020516  SH020556         1.   
    SH020516  SH020557         1.   
    SH020516  SH020558         1.   
    SH020516  SH020559         1.   
    SH020516  SH020560         1.   
    SH020516  SH020563         1.   
    SH020516  SH020564         1.   
    SH020516  SH020571         1.   
    SH020516  SH020573         1.   
    SH020516  SH020577         1.   
    SH020516  SH020578         1.   
    SH020516  SH020582         1.   
    SH020516  SH020583         1.   
    SH020516  TRSH0502         1.   
    SH020117  SH020117        10.   
    SH020117  SH020119         1.   
    SH020117  SH020120         1.   
    SH020117  SH020121         1.   
    SH020117  SH020124         1.   
    SH020117  SH020128         1.   
    SH020117  SH020131         1.   
    SH020117  SH020133         1.   
    SH020117  SH020134         1.   
    SH020117  SH020137         1.   
    SH020117  SH020138         1.   
    SH020117  SH020139         1.   
    SH020117  SH020140         1.   
    SH020117  SH020142         1.   
    SH020117  SH020143         1.   
    SH020117  SH020145         1.   
    SH020117  SH020146         1.   
    SH020117  SH020147         1.   
    SH020117  SH020148         1.   
    SH020117  SH020149         1.   
    SH020117  SH020150         1.   
    SH020117  SH020151         1.   
    SH020117  SH020152         1.   
    SH020117  SH020153         1.   
    SH020117  SH020154         1.   
    SH020117  SH020155         1.   
    SH020117  SH020156         1.   
    SH020117  SH020157         1.   
    SH020117  SH020158         1.   
    SH020117  SH020159         1.   
    SH020117  SH020160         1.   
    SH020117  SH020163         1.   
    SH020117  SH020164         1.   
    SH020117  SH020171         1.   
    SH020117  SH020173         1.   
    SH020117  SH020177         1.   
    SH020117  SH020178         1.   
    SH020117  SH020182         1.   
    SH020117  SH020183         1.   
    SH020117  TRSH0102         1.   
    SH020418  SH020418        10.   
    SH020418  SH020419         1.   
    SH020418  SH020420         1.   
    SH020418  SH020421         1.   
    SH020418  SH020422         1.   
    SH020418  SH020423         1.   
    SH020418  SH020426         1.   
    SH020418  SH020429         1.   
    SH020418  SH020430         1.   
    SH020418  SH020432         1.   
    SH020418  SH020433         1.   
    SH020418  SH020434         1.   
    SH020418  SH020435         1.   
    SH020418  SH020437         1.   
    SH020418  SH020438         1.   
    SH020418  SH020440         1.   
    SH020418  SH020443         1.   
    SH020418  SH020445         1.   
    SH020418  SH020446         1.   
    SH020418  SH020452         1.   
    SH020418  SH020453         1.   
    SH020418  SH020455         1.   
    SH020418  SH020458         1.   
    SH020418  SH020459         1.   
    SH020418  SH020460         1.   
    SH020418  SH020464         1.   
    SH020418  SH020471         1.   
    SH020418  SH020473         1.   
    SH020418  SH020477         1.   
    SH020418  SH020478         1.   
    SH020418  SH020480         1.   
    SH020418  SH020482         1.   
    SH020418  SH020483         1.   
    SH020418  TRSH0402         1.   
    SH020119  SH020119        10.   
    SH020119  SH020120         1.   
    SH020119  SH020121         1.   
    SH020119  SH020124         1.   
    SH020119  SH020128         1.   
    SH020119  SH020131         1.   
    SH020119  SH020133         1.   
    SH020119  SH020134         1.   
    SH020119  SH020137         1.   
    SH020119  SH020138         1.   
    SH020119  SH020139         1.   
    SH020119  SH020140         1.   
    SH020119  SH020142         1.   
    SH020119  SH020143         1.   
    SH020119  SH020145         1.   
    SH020119  SH020146         1.   
    SH020119  SH020147         1.   
    SH020119  SH020148         1.   
    SH020119  SH020149         1.   
    SH020119  SH020150         1.   
    SH020119  SH020151         1.   
    SH020119  SH020152         1.   
    SH020119  SH020153         1.   
    SH020119  SH020154         1.   
    SH020119  SH020155         1.   
    SH020119  SH020156         1.   
    SH020119  SH020157         1.   
    SH020119  SH020158         1.   
    SH020119  SH020159         1.   
    SH020119  SH020160         1.   
    SH020119  SH020163         1.   
    SH020119  SH020164         1.   
    SH020119  SH020171         1.   
    SH020119  SH020173         1.   
    SH020119  SH020177         1.   
    SH020119  SH020178         1.   
    SH020119  SH020182         1.   
    SH020119  SH020183         1.   
    SH020119  TRSH0102         1.   
    SH020219  SH020219        10.   
    SH020219  SH020220         1.   
    SH020219  SH020221         1.   
    SH020219  SH020225         1.   
    SH020219  SH020233         1.   
    SH020219  SH020234         1.   
    SH020219  SH020237         1.   
    SH020219  SH020238         1.   
    SH020219  SH020240         1.   
    SH020219  SH020243         1.   
    SH020219  SH020245         1.   
    SH020219  SH020246         1.   
    SH020219  SH020252         1.   
    SH020219  SH020253         1.   
    SH020219  SH020255         1.   
    SH020219  SH020258         1.   
    SH020219  SH020259         1.   
    SH020219  SH020260         1.   
    SH020219  SH020264         1.   
    SH020219  SH020265         1.   
    SH020219  SH020266         1.   
    SH020219  SH020267         1.   
    SH020219  SH020268         1.   
    SH020219  SH020269         1.   
    SH020219  SH020272         1.   
    SH020219  SH020273         1.   
    SH020219  SH020274         1.   
    SH020219  SH020275         1.   
    SH020219  SH020276         1.   
    SH020219  SH020277         1.   
    SH020219  SH020278         1.   
    SH020219  SH020279         1.   
    SH020219  SH020282         1.   
    SH020219  SH020283         1.   
    SH020219  SH020284         1.   
    SH020219  TRSH0202         1.   
    SH020319  SH020319        10.   
    SH020319  SH020320         1.   
    SH020319  SH020321         1.   
    SH020319  SH020333         1.   
    SH020319  SH020334         1.   
    SH020319  SH020337         1.   
    SH020319  SH020338         1.   
    SH020319  SH020340         1.   
    SH020319  SH020343         1.   
    SH020319  SH020345         1.   
    SH020319  SH020346         1.   
    SH020319  SH020352         1.   
    SH020319  SH020353         1.   
    SH020319  SH020355         1.   
    SH020319  SH020358         1.   
    SH020319  SH020359         1.   
    SH020319  SH020360         1.   
    SH020319  SH020364         1.   
    SH020319  SH020371         1.   
    SH020319  SH020373         1.   
    SH020319  SH020377         1.   
    SH020319  SH020378         1.   
    SH020319  SH020382         1.   
    SH020319  SH020383         1.   
    SH020319  TRSH0302         1.   
    SH020419  SH020419        10.   
    SH020419  SH020420         1.   
    SH020419  SH020421         1.   
    SH020419  SH020422         1.   
    SH020419  SH020423         1.   
    SH020419  SH020426         1.   
    SH020419  SH020429         1.   
    SH020419  SH020430         1.   
    SH020419  SH020432         1.   
    SH020419  SH020433         1.   
    SH020419  SH020434         1.   
    SH020419  SH020435         1.   
    SH020419  SH020437         1.   
    SH020419  SH020438         1.   
    SH020419  SH020440         1.   
    SH020419  SH020443         1.   
    SH020419  SH020445         1.   
    SH020419  SH020446         1.   
    SH020419  SH020452         1.   
    SH020419  SH020453         1.   
    SH020419  SH020455         1.   
    SH020419  SH020458         1.   
    SH020419  SH020459         1.   
    SH020419  SH020460         1.   
    SH020419  SH020464         1.   
    SH020419  SH020471         1.   
    SH020419  SH020473         1.   
    SH020419  SH020477         1.   
    SH020419  SH020478         1.   
    SH020419  SH020480         1.   
    SH020419  SH020482         1.   
    SH020419  SH020483         1.   
    SH020419  TRSH0402         1.   
    SH020519  SH020519        10.   
    SH020519  SH020520         1.   
    SH020519  SH020521         1.   
    SH020519  SH020528         1.   
    SH020519  SH020533         1.   
    SH020519  SH020534         1.   
    SH020519  SH020537         1.   
    SH020519  SH020538         1.   
    SH020519  SH020540         1.   
    SH020519  SH020543         1.   
    SH020519  SH020545         1.   
    SH020519  SH020546         1.   
    SH020519  SH020549         1.   
    SH020519  SH020551         1.   
    SH020519  SH020552         1.   
    SH020519  SH020553         1.   
    SH020519  SH020555         1.   
    SH020519  SH020556         1.   
    SH020519  SH020557         1.   
    SH020519  SH020558         1.   
    SH020519  SH020559         1.   
    SH020519  SH020560         1.   
    SH020519  SH020563         1.   
    SH020519  SH020564         1.   
    SH020519  SH020571         1.   
    SH020519  SH020573         1.   
    SH020519  SH020577         1.   
    SH020519  SH020578         1.   
    SH020519  SH020582         1.   
    SH020519  SH020583         1.   
    SH020519  TRSH0502         1.   
    SH020120  SH020120        10.   
    SH020120  SH020121         1.   
    SH020120  SH020124         1.   
    SH020120  SH020128         1.   
    SH020120  SH020131         1.   
    SH020120  SH020133         1.   
    SH020120  SH020134         1.   
    SH020120  SH020137         1.   
    SH020120  SH020138         1.   
    SH020120  SH020139         1.   
    SH020120  SH020140         1.   
    SH020120  SH020142         1.   
    SH020120  SH020143         1.   
    SH020120  SH020145         1.   
    SH020120  SH020146         1.   
    SH020120  SH020147         1.   
    SH020120  SH020148         1.   
    SH020120  SH020149         1.   
    SH020120  SH020150         1.   
    SH020120  SH020151         1.   
    SH020120  SH020152         1.   
    SH020120  SH020153         1.   
    SH020120  SH020154         1.   
    SH020120  SH020155         1.   
    SH020120  SH020156         1.   
    SH020120  SH020157         1.   
    SH020120  SH020158         1.   
    SH020120  SH020159         1.   
    SH020120  SH020160         1.   
    SH020120  SH020163         1.   
    SH020120  SH020164         1.   
    SH020120  SH020171         1.   
    SH020120  SH020173         1.   
    SH020120  SH020177         1.   
    SH020120  SH020178         1.   
    SH020120  SH020182         1.   
    SH020120  SH020183         1.   
    SH020120  TRSH0102         1.   
    SH020220  SH020220        10.   
    SH020220  SH020221         1.   
    SH020220  SH020225         1.   
    SH020220  SH020233         1.   
    SH020220  SH020234         1.   
    SH020220  SH020237         1.   
    SH020220  SH020238         1.   
    SH020220  SH020240         1.   
    SH020220  SH020243         1.   
    SH020220  SH020245         1.   
    SH020220  SH020246         1.   
    SH020220  SH020252         1.   
    SH020220  SH020253         1.   
    SH020220  SH020255         1.   
    SH020220  SH020258         1.   
    SH020220  SH020259         1.   
    SH020220  SH020260         1.   
    SH020220  SH020264         1.   
    SH020220  SH020265         1.   
    SH020220  SH020266         1.   
    SH020220  SH020267         1.   
    SH020220  SH020268         1.   
    SH020220  SH020269         1.   
    SH020220  SH020272         1.   
    SH020220  SH020273         1.   
    SH020220  SH020274         1.   
    SH020220  SH020275         1.   
    SH020220  SH020276         1.   
    SH020220  SH020277         1.   
    SH020220  SH020278         1.   
    SH020220  SH020279         1.   
    SH020220  SH020282         1.   
    SH020220  SH020283         1.   
    SH020220  SH020284         1.   
    SH020220  TRSH0202         1.   
    SH020320  SH020320        10.   
    SH020320  SH020321         1.   
    SH020320  SH020333         1.   
    SH020320  SH020334         1.   
    SH020320  SH020337         1.   
    SH020320  SH020338         1.   
    SH020320  SH020340         1.   
    SH020320  SH020343         1.   
    SH020320  SH020345         1.   
    SH020320  SH020346         1.   
    SH020320  SH020352         1.   
    SH020320  SH020353         1.   
    SH020320  SH020355         1.   
    SH020320  SH020358         1.   
    SH020320  SH020359         1.   
    SH020320  SH020360         1.   
    SH020320  SH020364         1.   
    SH020320  SH020371         1.   
    SH020320  SH020373         1.   
    SH020320  SH020377         1.   
    SH020320  SH020378         1.   
    SH020320  SH020382         1.   
    SH020320  SH020383         1.   
    SH020320  TRSH0302         1.   
    SH020420  SH020420        10.   
    SH020420  SH020421         1.   
    SH020420  SH020422         1.   
    SH020420  SH020423         1.   
    SH020420  SH020426         1.   
    SH020420  SH020429         1.   
    SH020420  SH020430         1.   
    SH020420  SH020432         1.   
    SH020420  SH020433         1.   
    SH020420  SH020434         1.   
    SH020420  SH020435         1.   
    SH020420  SH020437         1.   
    SH020420  SH020438         1.   
    SH020420  SH020440         1.   
    SH020420  SH020443         1.   
    SH020420  SH020445         1.   
    SH020420  SH020446         1.   
    SH020420  SH020452         1.   
    SH020420  SH020453         1.   
    SH020420  SH020455         1.   
    SH020420  SH020458         1.   
    SH020420  SH020459         1.   
    SH020420  SH020460         1.   
    SH020420  SH020464         1.   
    SH020420  SH020471         1.   
    SH020420  SH020473         1.   
    SH020420  SH020477         1.   
    SH020420  SH020478         1.   
    SH020420  SH020480         1.   
    SH020420  SH020482         1.   
    SH020420  SH020483         1.   
    SH020420  TRSH0402         1.   
    SH020520  SH020520        10.   
    SH020520  SH020521         1.   
    SH020520  SH020528         1.   
    SH020520  SH020533         1.   
    SH020520  SH020534         1.   
    SH020520  SH020537         1.   
    SH020520  SH020538         1.   
    SH020520  SH020540         1.   
    SH020520  SH020543         1.   
    SH020520  SH020545         1.   
    SH020520  SH020546         1.   
    SH020520  SH020549         1.   
    SH020520  SH020551         1.   
    SH020520  SH020552         1.   
    SH020520  SH020553         1.   
    SH020520  SH020555         1.   
    SH020520  SH020556         1.   
    SH020520  SH020557         1.   
    SH020520  SH020558         1.   
    SH020520  SH020559         1.   
    SH020520  SH020560         1.   
    SH020520  SH020563         1.   
    SH020520  SH020564         1.   
    SH020520  SH020571         1.   
    SH020520  SH020573         1.   
    SH020520  SH020577         1.   
    SH020520  SH020578         1.   
    SH020520  SH020582         1.   
    SH020520  SH020583         1.   
    SH020520  TRSH0502         1.   
    SH020121  SH020121        10.   
    SH020121  SH020124         1.   
    SH020121  SH020128         1.   
    SH020121  SH020131         1.   
    SH020121  SH020133         1.   
    SH020121  SH020134         1.   
    SH020121  SH020137         1.   
    SH020121  SH020138         1.   
    SH020121  SH020139         1.   
    SH020121  SH020140         1.   
    SH020121  SH020142         1.   
    SH020121  SH020143         1.   
    SH020121  SH020145         1.   
    SH020121  SH020146         1.   
    SH020121  SH020147         1.   
    SH020121  SH020148         1.   
    SH020121  SH020149         1.   
    SH020121  SH020150         1.   
    SH020121  SH020151         1.   
    SH020121  SH020152         1.   
    SH020121  SH020153         1.   
    SH020121  SH020154         1.   
    SH020121  SH020155         1.   
    SH020121  SH020156         1.   
    SH020121  SH020157         1.   
    SH020121  SH020158         1.   
    SH020121  SH020159         1.   
    SH020121  SH020160         1.   
    SH020121  SH020163         1.   
    SH020121  SH020164         1.   
    SH020121  SH020171         1.   
    SH020121  SH020173         1.   
    SH020121  SH020177         1.   
    SH020121  SH020178         1.   
    SH020121  SH020182         1.   
    SH020121  SH020183         1.   
    SH020121  TRSH0102         1.   
    SH020221  SH020221        10.   
    SH020221  SH020225         1.   
    SH020221  SH020233         1.   
    SH020221  SH020234         1.   
    SH020221  SH020237         1.   
    SH020221  SH020238         1.   
    SH020221  SH020240         1.   
    SH020221  SH020243         1.   
    SH020221  SH020245         1.   
    SH020221  SH020246         1.   
    SH020221  SH020252         1.   
    SH020221  SH020253         1.   
    SH020221  SH020255         1.   
    SH020221  SH020258         1.   
    SH020221  SH020259         1.   
    SH020221  SH020260         1.   
    SH020221  SH020264         1.   
    SH020221  SH020265         1.   
    SH020221  SH020266         1.   
    SH020221  SH020267         1.   
    SH020221  SH020268         1.   
    SH020221  SH020269         1.   
    SH020221  SH020272         1.   
    SH020221  SH020273         1.   
    SH020221  SH020274         1.   
    SH020221  SH020275         1.   
    SH020221  SH020276         1.   
    SH020221  SH020277         1.   
    SH020221  SH020278         1.   
    SH020221  SH020279         1.   
    SH020221  SH020282         1.   
    SH020221  SH020283         1.   
    SH020221  SH020284         1.   
    SH020221  TRSH0202         1.   
    SH020321  SH020321        10.   
    SH020321  SH020333         1.   
    SH020321  SH020334         1.   
    SH020321  SH020337         1.   
    SH020321  SH020338         1.   
    SH020321  SH020340         1.   
    SH020321  SH020343         1.   
    SH020321  SH020345         1.   
    SH020321  SH020346         1.   
    SH020321  SH020352         1.   
    SH020321  SH020353         1.   
    SH020321  SH020355         1.   
    SH020321  SH020358         1.   
    SH020321  SH020359         1.   
    SH020321  SH020360         1.   
    SH020321  SH020364         1.   
    SH020321  SH020371         1.   
    SH020321  SH020373         1.   
    SH020321  SH020377         1.   
    SH020321  SH020378         1.   
    SH020321  SH020382         1.   
    SH020321  SH020383         1.   
    SH020321  TRSH0302         1.   
    SH020421  SH020421        10.   
    SH020421  SH020422         1.   
    SH020421  SH020423         1.   
    SH020421  SH020426         1.   
    SH020421  SH020429         1.   
    SH020421  SH020430         1.   
    SH020421  SH020432         1.   
    SH020421  SH020433         1.   
    SH020421  SH020434         1.   
    SH020421  SH020435         1.   
    SH020421  SH020437         1.   
    SH020421  SH020438         1.   
    SH020421  SH020440         1.   
    SH020421  SH020443         1.   
    SH020421  SH020445         1.   
    SH020421  SH020446         1.   
    SH020421  SH020452         1.   
    SH020421  SH020453         1.   
    SH020421  SH020455         1.   
    SH020421  SH020458         1.   
    SH020421  SH020459         1.   
    SH020421  SH020460         1.   
    SH020421  SH020464         1.   
    SH020421  SH020471         1.   
    SH020421  SH020473         1.   
    SH020421  SH020477         1.   
    SH020421  SH020478         1.   
    SH020421  SH020480         1.   
    SH020421  SH020482         1.   
    SH020421  SH020483         1.   
    SH020421  TRSH0402         1.   
    SH020521  SH020521        10.   
    SH020521  SH020528         1.   
    SH020521  SH020533         1.   
    SH020521  SH020534         1.   
    SH020521  SH020537         1.   
    SH020521  SH020538         1.   
    SH020521  SH020540         1.   
    SH020521  SH020543         1.   
    SH020521  SH020545         1.   
    SH020521  SH020546         1.   
    SH020521  SH020549         1.   
    SH020521  SH020551         1.   
    SH020521  SH020552         1.   
    SH020521  SH020553         1.   
    SH020521  SH020555         1.   
    SH020521  SH020556         1.   
    SH020521  SH020557         1.   
    SH020521  SH020558         1.   
    SH020521  SH020559         1.   
    SH020521  SH020560         1.   
    SH020521  SH020563         1.   
    SH020521  SH020564         1.   
    SH020521  SH020571         1.   
    SH020521  SH020573         1.   
    SH020521  SH020577         1.   
    SH020521  SH020578         1.   
    SH020521  SH020582         1.   
    SH020521  SH020583         1.   
    SH020521  TRSH0502         1.   
    SH020422  SH020422        10.   
    SH020422  SH020423         1.   
    SH020422  SH020426         1.   
    SH020422  SH020429         1.   
    SH020422  SH020430         1.   
    SH020422  SH020432         1.   
    SH020422  SH020433         1.   
    SH020422  SH020434         1.   
    SH020422  SH020435         1.   
    SH020422  SH020437         1.   
    SH020422  SH020438         1.   
    SH020422  SH020440         1.   
    SH020422  SH020443         1.   
    SH020422  SH020445         1.   
    SH020422  SH020446         1.   
    SH020422  SH020452         1.   
    SH020422  SH020453         1.   
    SH020422  SH020455         1.   
    SH020422  SH020458         1.   
    SH020422  SH020459         1.   
    SH020422  SH020460         1.   
    SH020422  SH020464         1.   
    SH020422  SH020471         1.   
    SH020422  SH020473         1.   
    SH020422  SH020477         1.   
    SH020422  SH020478         1.   
    SH020422  SH020480         1.   
    SH020422  SH020482         1.   
    SH020422  SH020483         1.   
    SH020422  TRSH0402         1.   
    SH020423  SH020423        10.   
    SH020423  SH020426         1.   
    SH020423  SH020429         1.   
    SH020423  SH020430         1.   
    SH020423  SH020432         1.   
    SH020423  SH020433         1.   
    SH020423  SH020434         1.   
    SH020423  SH020435         1.   
    SH020423  SH020437         1.   
    SH020423  SH020438         1.   
    SH020423  SH020440         1.   
    SH020423  SH020443         1.   
    SH020423  SH020445         1.   
    SH020423  SH020446         1.   
    SH020423  SH020452         1.   
    SH020423  SH020453         1.   
    SH020423  SH020455         1.   
    SH020423  SH020458         1.   
    SH020423  SH020459         1.   
    SH020423  SH020460         1.   
    SH020423  SH020464         1.   
    SH020423  SH020471         1.   
    SH020423  SH020473         1.   
    SH020423  SH020477         1.   
    SH020423  SH020478         1.   
    SH020423  SH020480         1.   
    SH020423  SH020482         1.   
    SH020423  SH020483         1.   
    SH020423  TRSH0402         1.   
    SH020124  SH020124        10.   
    SH020124  SH020128         1.   
    SH020124  SH020131         1.   
    SH020124  SH020133         1.   
    SH020124  SH020134         1.   
    SH020124  SH020137         1.   
    SH020124  SH020138         1.   
    SH020124  SH020139         1.   
    SH020124  SH020140         1.   
    SH020124  SH020142         1.   
    SH020124  SH020143         1.   
    SH020124  SH020145         1.   
    SH020124  SH020146         1.   
    SH020124  SH020147         1.   
    SH020124  SH020148         1.   
    SH020124  SH020149         1.   
    SH020124  SH020150         1.   
    SH020124  SH020151         1.   
    SH020124  SH020152         1.   
    SH020124  SH020153         1.   
    SH020124  SH020154         1.   
    SH020124  SH020155         1.   
    SH020124  SH020156         1.   
    SH020124  SH020157         1.   
    SH020124  SH020158         1.   
    SH020124  SH020159         1.   
    SH020124  SH020160         1.   
    SH020124  SH020163         1.   
    SH020124  SH020164         1.   
    SH020124  SH020171         1.   
    SH020124  SH020173         1.   
    SH020124  SH020177         1.   
    SH020124  SH020178         1.   
    SH020124  SH020182         1.   
    SH020124  SH020183         1.   
    SH020124  TRSH0102         1.   
    SH020225  SH020225        10.   
    SH020225  SH020233         1.   
    SH020225  SH020234         1.   
    SH020225  SH020237         1.   
    SH020225  SH020238         1.   
    SH020225  SH020240         1.   
    SH020225  SH020243         1.   
    SH020225  SH020245         1.   
    SH020225  SH020246         1.   
    SH020225  SH020252         1.   
    SH020225  SH020253         1.   
    SH020225  SH020255         1.   
    SH020225  SH020258         1.   
    SH020225  SH020259         1.   
    SH020225  SH020260         1.   
    SH020225  SH020264         1.   
    SH020225  SH020265         1.   
    SH020225  SH020266         1.   
    SH020225  SH020267         1.   
    SH020225  SH020268         1.   
    SH020225  SH020269         1.   
    SH020225  SH020272         1.   
    SH020225  SH020273         1.   
    SH020225  SH020274         1.   
    SH020225  SH020275         1.   
    SH020225  SH020276         1.   
    SH020225  SH020277         1.   
    SH020225  SH020278         1.   
    SH020225  SH020279         1.   
    SH020225  SH020282         1.   
    SH020225  SH020283         1.   
    SH020225  SH020284         1.   
    SH020225  TRSH0202         1.   
    SH020426  SH020426        10.   
    SH020426  SH020429         1.   
    SH020426  SH020430         1.   
    SH020426  SH020432         1.   
    SH020426  SH020433         1.   
    SH020426  SH020434         1.   
    SH020426  SH020435         1.   
    SH020426  SH020437         1.   
    SH020426  SH020438         1.   
    SH020426  SH020440         1.   
    SH020426  SH020443         1.   
    SH020426  SH020445         1.   
    SH020426  SH020446         1.   
    SH020426  SH020452         1.   
    SH020426  SH020453         1.   
    SH020426  SH020455         1.   
    SH020426  SH020458         1.   
    SH020426  SH020459         1.   
    SH020426  SH020460         1.   
    SH020426  SH020464         1.   
    SH020426  SH020471         1.   
    SH020426  SH020473         1.   
    SH020426  SH020477         1.   
    SH020426  SH020478         1.   
    SH020426  SH020480         1.   
    SH020426  SH020482         1.   
    SH020426  SH020483         1.   
    SH020426  TRSH0402         1.   
    SH020128  SH020128        10.   
    SH020128  SH020131         1.   
    SH020128  SH020133         1.   
    SH020128  SH020134         1.   
    SH020128  SH020137         1.   
    SH020128  SH020138         1.   
    SH020128  SH020139         1.   
    SH020128  SH020140         1.   
    SH020128  SH020142         1.   
    SH020128  SH020143         1.   
    SH020128  SH020145         1.   
    SH020128  SH020146         1.   
    SH020128  SH020147         1.   
    SH020128  SH020148         1.   
    SH020128  SH020149         1.   
    SH020128  SH020150         1.   
    SH020128  SH020151         1.   
    SH020128  SH020152         1.   
    SH020128  SH020153         1.   
    SH020128  SH020154         1.   
    SH020128  SH020155         1.   
    SH020128  SH020156         1.   
    SH020128  SH020157         1.   
    SH020128  SH020158         1.   
    SH020128  SH020159         1.   
    SH020128  SH020160         1.   
    SH020128  SH020163         1.   
    SH020128  SH020164         1.   
    SH020128  SH020171         1.   
    SH020128  SH020173         1.   
    SH020128  SH020177         1.   
    SH020128  SH020178         1.   
    SH020128  SH020182         1.   
    SH020128  SH020183         1.   
    SH020128  TRSH0102         1.   
    SH020528  SH020528        10.   
    SH020528  SH020533         1.   
    SH020528  SH020534         1.   
    SH020528  SH020537         1.   
    SH020528  SH020538         1.   
    SH020528  SH020540         1.   
    SH020528  SH020543         1.   
    SH020528  SH020545         1.   
    SH020528  SH020546         1.   
    SH020528  SH020549         1.   
    SH020528  SH020551         1.   
    SH020528  SH020552         1.   
    SH020528  SH020553         1.   
    SH020528  SH020555         1.   
    SH020528  SH020556         1.   
    SH020528  SH020557         1.   
    SH020528  SH020558         1.   
    SH020528  SH020559         1.   
    SH020528  SH020560         1.   
    SH020528  SH020563         1.   
    SH020528  SH020564         1.   
    SH020528  SH020571         1.   
    SH020528  SH020573         1.   
    SH020528  SH020577         1.   
    SH020528  SH020578         1.   
    SH020528  SH020582         1.   
    SH020528  SH020583         1.   
    SH020528  TRSH0502         1.   
    SH020429  SH020429        10.   
    SH020429  SH020430         1.   
    SH020429  SH020432         1.   
    SH020429  SH020433         1.   
    SH020429  SH020434         1.   
    SH020429  SH020435         1.   
    SH020429  SH020437         1.   
    SH020429  SH020438         1.   
    SH020429  SH020440         1.   
    SH020429  SH020443         1.   
    SH020429  SH020445         1.   
    SH020429  SH020446         1.   
    SH020429  SH020452         1.   
    SH020429  SH020453         1.   
    SH020429  SH020455         1.   
    SH020429  SH020458         1.   
    SH020429  SH020459         1.   
    SH020429  SH020460         1.   
    SH020429  SH020464         1.   
    SH020429  SH020471         1.   
    SH020429  SH020473         1.   
    SH020429  SH020477         1.   
    SH020429  SH020478         1.   
    SH020429  SH020480         1.   
    SH020429  SH020482         1.   
    SH020429  SH020483         1.   
    SH020429  TRSH0402         1.   
    SH020430  SH020430        10.   
    SH020430  SH020432         1.   
    SH020430  SH020433         1.   
    SH020430  SH020434         1.   
    SH020430  SH020435         1.   
    SH020430  SH020437         1.   
    SH020430  SH020438         1.   
    SH020430  SH020440         1.   
    SH020430  SH020443         1.   
    SH020430  SH020445         1.   
    SH020430  SH020446         1.   
    SH020430  SH020452         1.   
    SH020430  SH020453         1.   
    SH020430  SH020455         1.   
    SH020430  SH020458         1.   
    SH020430  SH020459         1.   
    SH020430  SH020460         1.   
    SH020430  SH020464         1.   
    SH020430  SH020471         1.   
    SH020430  SH020473         1.   
    SH020430  SH020477         1.   
    SH020430  SH020478         1.   
    SH020430  SH020480         1.   
    SH020430  SH020482         1.   
    SH020430  SH020483         1.   
    SH020430  TRSH0402         1.   
    SH020131  SH020131        10.   
    SH020131  SH020133         1.   
    SH020131  SH020134         1.   
    SH020131  SH020137         1.   
    SH020131  SH020138         1.   
    SH020131  SH020139         1.   
    SH020131  SH020140         1.   
    SH020131  SH020142         1.   
    SH020131  SH020143         1.   
    SH020131  SH020145         1.   
    SH020131  SH020146         1.   
    SH020131  SH020147         1.   
    SH020131  SH020148         1.   
    SH020131  SH020149         1.   
    SH020131  SH020150         1.   
    SH020131  SH020151         1.   
    SH020131  SH020152         1.   
    SH020131  SH020153         1.   
    SH020131  SH020154         1.   
    SH020131  SH020155         1.   
    SH020131  SH020156         1.   
    SH020131  SH020157         1.   
    SH020131  SH020158         1.   
    SH020131  SH020159         1.   
    SH020131  SH020160         1.   
    SH020131  SH020163         1.   
    SH020131  SH020164         1.   
    SH020131  SH020171         1.   
    SH020131  SH020173         1.   
    SH020131  SH020177         1.   
    SH020131  SH020178         1.   
    SH020131  SH020182         1.   
    SH020131  SH020183         1.   
    SH020131  TRSH0102         1.   
    SH020432  SH020432        10.   
    SH020432  SH020433         1.   
    SH020432  SH020434         1.   
    SH020432  SH020435         1.   
    SH020432  SH020437         1.   
    SH020432  SH020438         1.   
    SH020432  SH020440         1.   
    SH020432  SH020443         1.   
    SH020432  SH020445         1.   
    SH020432  SH020446         1.   
    SH020432  SH020452         1.   
    SH020432  SH020453         1.   
    SH020432  SH020455         1.   
    SH020432  SH020458         1.   
    SH020432  SH020459         1.   
    SH020432  SH020460         1.   
    SH020432  SH020464         1.   
    SH020432  SH020471         1.   
    SH020432  SH020473         1.   
    SH020432  SH020477         1.   
    SH020432  SH020478         1.   
    SH020432  SH020480         1.   
    SH020432  SH020482         1.   
    SH020432  SH020483         1.   
    SH020432  TRSH0402         1.   
    SH020133  SH020133        10.   
    SH020133  SH020134         1.   
    SH020133  SH020137         1.   
    SH020133  SH020138         1.   
    SH020133  SH020139         1.   
    SH020133  SH020140         1.   
    SH020133  SH020142         1.   
    SH020133  SH020143         1.   
    SH020133  SH020145         1.   
    SH020133  SH020146         1.   
    SH020133  SH020147         1.   
    SH020133  SH020148         1.   
    SH020133  SH020149         1.   
    SH020133  SH020150         1.   
    SH020133  SH020151         1.   
    SH020133  SH020152         1.   
    SH020133  SH020153         1.   
    SH020133  SH020154         1.   
    SH020133  SH020155         1.   
    SH020133  SH020156         1.   
    SH020133  SH020157         1.   
    SH020133  SH020158         1.   
    SH020133  SH020159         1.   
    SH020133  SH020160         1.   
    SH020133  SH020163         1.   
    SH020133  SH020164         1.   
    SH020133  SH020171         1.   
    SH020133  SH020173         1.   
    SH020133  SH020177         1.   
    SH020133  SH020178         1.   
    SH020133  SH020182         1.   
    SH020133  SH020183         1.   
    SH020133  TRSH0102         1.   
    SH020233  SH020233        10.   
    SH020233  SH020234         1.   
    SH020233  SH020237         1.   
    SH020233  SH020238         1.   
    SH020233  SH020240         1.   
    SH020233  SH020243         1.   
    SH020233  SH020245         1.   
    SH020233  SH020246         1.   
    SH020233  SH020252         1.   
    SH020233  SH020253         1.   
    SH020233  SH020255         1.   
    SH020233  SH020258         1.   
    SH020233  SH020259         1.   
    SH020233  SH020260         1.   
    SH020233  SH020264         1.   
    SH020233  SH020265         1.   
    SH020233  SH020266         1.   
    SH020233  SH020267         1.   
    SH020233  SH020268         1.   
    SH020233  SH020269         1.   
    SH020233  SH020272         1.   
    SH020233  SH020273         1.   
    SH020233  SH020274         1.   
    SH020233  SH020275         1.   
    SH020233  SH020276         1.   
    SH020233  SH020277         1.   
    SH020233  SH020278         1.   
    SH020233  SH020279         1.   
    SH020233  SH020282         1.   
    SH020233  SH020283         1.   
    SH020233  SH020284         1.   
    SH020233  TRSH0202         1.   
    SH020333  SH020333        10.   
    SH020333  SH020334         1.   
    SH020333  SH020337         1.   
    SH020333  SH020338         1.   
    SH020333  SH020340         1.   
    SH020333  SH020343         1.   
    SH020333  SH020345         1.   
    SH020333  SH020346         1.   
    SH020333  SH020352         1.   
    SH020333  SH020353         1.   
    SH020333  SH020355         1.   
    SH020333  SH020358         1.   
    SH020333  SH020359         1.   
    SH020333  SH020360         1.   
    SH020333  SH020364         1.   
    SH020333  SH020371         1.   
    SH020333  SH020373         1.   
    SH020333  SH020377         1.   
    SH020333  SH020378         1.   
    SH020333  SH020382         1.   
    SH020333  SH020383         1.   
    SH020333  TRSH0302         1.   
    SH020433  SH020433        10.   
    SH020433  SH020434         1.   
    SH020433  SH020435         1.   
    SH020433  SH020437         1.   
    SH020433  SH020438         1.   
    SH020433  SH020440         1.   
    SH020433  SH020443         1.   
    SH020433  SH020445         1.   
    SH020433  SH020446         1.   
    SH020433  SH020452         1.   
    SH020433  SH020453         1.   
    SH020433  SH020455         1.   
    SH020433  SH020458         1.   
    SH020433  SH020459         1.   
    SH020433  SH020460         1.   
    SH020433  SH020464         1.   
    SH020433  SH020471         1.   
    SH020433  SH020473         1.   
    SH020433  SH020477         1.   
    SH020433  SH020478         1.   
    SH020433  SH020480         1.   
    SH020433  SH020482         1.   
    SH020433  SH020483         1.   
    SH020433  TRSH0402         1.   
    SH020533  SH020533        10.   
    SH020533  SH020534         1.   
    SH020533  SH020537         1.   
    SH020533  SH020538         1.   
    SH020533  SH020540         1.   
    SH020533  SH020543         1.   
    SH020533  SH020545         1.   
    SH020533  SH020546         1.   
    SH020533  SH020549         1.   
    SH020533  SH020551         1.   
    SH020533  SH020552         1.   
    SH020533  SH020553         1.   
    SH020533  SH020555         1.   
    SH020533  SH020556         1.   
    SH020533  SH020557         1.   
    SH020533  SH020558         1.   
    SH020533  SH020559         1.   
    SH020533  SH020560         1.   
    SH020533  SH020563         1.   
    SH020533  SH020564         1.   
    SH020533  SH020571         1.   
    SH020533  SH020573         1.   
    SH020533  SH020577         1.   
    SH020533  SH020578         1.   
    SH020533  SH020582         1.   
    SH020533  SH020583         1.   
    SH020533  TRSH0502         1.   
    SH020134  SH020134        10.   
    SH020134  SH020137         1.   
    SH020134  SH020138         1.   
    SH020134  SH020139         1.   
    SH020134  SH020140         1.   
    SH020134  SH020142         1.   
    SH020134  SH020143         1.   
    SH020134  SH020145         1.   
    SH020134  SH020146         1.   
    SH020134  SH020147         1.   
    SH020134  SH020148         1.   
    SH020134  SH020149         1.   
    SH020134  SH020150         1.   
    SH020134  SH020151         1.   
    SH020134  SH020152         1.   
    SH020134  SH020153         1.   
    SH020134  SH020154         1.   
    SH020134  SH020155         1.   
    SH020134  SH020156         1.   
    SH020134  SH020157         1.   
    SH020134  SH020158         1.   
    SH020134  SH020159         1.   
    SH020134  SH020160         1.   
    SH020134  SH020163         1.   
    SH020134  SH020164         1.   
    SH020134  SH020171         1.   
    SH020134  SH020173         1.   
    SH020134  SH020177         1.   
    SH020134  SH020178         1.   
    SH020134  SH020182         1.   
    SH020134  SH020183         1.   
    SH020134  TRSH0102         1.   
    SH020234  SH020234        10.   
    SH020234  SH020237         1.   
    SH020234  SH020238         1.   
    SH020234  SH020240         1.   
    SH020234  SH020243         1.   
    SH020234  SH020245         1.   
    SH020234  SH020246         1.   
    SH020234  SH020252         1.   
    SH020234  SH020253         1.   
    SH020234  SH020255         1.   
    SH020234  SH020258         1.   
    SH020234  SH020259         1.   
    SH020234  SH020260         1.   
    SH020234  SH020264         1.   
    SH020234  SH020265         1.   
    SH020234  SH020266         1.   
    SH020234  SH020267         1.   
    SH020234  SH020268         1.   
    SH020234  SH020269         1.   
    SH020234  SH020272         1.   
    SH020234  SH020273         1.   
    SH020234  SH020274         1.   
    SH020234  SH020275         1.   
    SH020234  SH020276         1.   
    SH020234  SH020277         1.   
    SH020234  SH020278         1.   
    SH020234  SH020279         1.   
    SH020234  SH020282         1.   
    SH020234  SH020283         1.   
    SH020234  SH020284         1.   
    SH020234  TRSH0202         1.   
    SH020334  SH020334        10.   
    SH020334  SH020337         1.   
    SH020334  SH020338         1.   
    SH020334  SH020340         1.   
    SH020334  SH020343         1.   
    SH020334  SH020345         1.   
    SH020334  SH020346         1.   
    SH020334  SH020352         1.   
    SH020334  SH020353         1.   
    SH020334  SH020355         1.   
    SH020334  SH020358         1.   
    SH020334  SH020359         1.   
    SH020334  SH020360         1.   
    SH020334  SH020364         1.   
    SH020334  SH020371         1.   
    SH020334  SH020373         1.   
    SH020334  SH020377         1.   
    SH020334  SH020378         1.   
    SH020334  SH020382         1.   
    SH020334  SH020383         1.   
    SH020334  TRSH0302         1.   
    SH020434  SH020434        10.   
    SH020434  SH020435         1.   
    SH020434  SH020437         1.   
    SH020434  SH020438         1.   
    SH020434  SH020440         1.   
    SH020434  SH020443         1.   
    SH020434  SH020445         1.   
    SH020434  SH020446         1.   
    SH020434  SH020452         1.   
    SH020434  SH020453         1.   
    SH020434  SH020455         1.   
    SH020434  SH020458         1.   
    SH020434  SH020459         1.   
    SH020434  SH020460         1.   
    SH020434  SH020464         1.   
    SH020434  SH020471         1.   
    SH020434  SH020473         1.   
    SH020434  SH020477         1.   
    SH020434  SH020478         1.   
    SH020434  SH020480         1.   
    SH020434  SH020482         1.   
    SH020434  SH020483         1.   
    SH020434  TRSH0402         1.   
    SH020534  SH020534        10.   
    SH020534  SH020537         1.   
    SH020534  SH020538         1.   
    SH020534  SH020540         1.   
    SH020534  SH020543         1.   
    SH020534  SH020545         1.   
    SH020534  SH020546         1.   
    SH020534  SH020549         1.   
    SH020534  SH020551         1.   
    SH020534  SH020552         1.   
    SH020534  SH020553         1.   
    SH020534  SH020555         1.   
    SH020534  SH020556         1.   
    SH020534  SH020557         1.   
    SH020534  SH020558         1.   
    SH020534  SH020559         1.   
    SH020534  SH020560         1.   
    SH020534  SH020563         1.   
    SH020534  SH020564         1.   
    SH020534  SH020571         1.   
    SH020534  SH020573         1.   
    SH020534  SH020577         1.   
    SH020534  SH020578         1.   
    SH020534  SH020582         1.   
    SH020534  SH020583         1.   
    SH020534  TRSH0502         1.   
    SH020435  SH020435        10.   
    SH020435  SH020437         1.   
    SH020435  SH020438         1.   
    SH020435  SH020440         1.   
    SH020435  SH020443         1.   
    SH020435  SH020445         1.   
    SH020435  SH020446         1.   
    SH020435  SH020452         1.   
    SH020435  SH020453         1.   
    SH020435  SH020455         1.   
    SH020435  SH020458         1.   
    SH020435  SH020459         1.   
    SH020435  SH020460         1.   
    SH020435  SH020464         1.   
    SH020435  SH020471         1.   
    SH020435  SH020473         1.   
    SH020435  SH020477         1.   
    SH020435  SH020478         1.   
    SH020435  SH020480         1.   
    SH020435  SH020482         1.   
    SH020435  SH020483         1.   
    SH020435  TRSH0402         1.   
    SH020137  SH020137        10.   
    SH020137  SH020138         1.   
    SH020137  SH020139         1.   
    SH020137  SH020140         1.   
    SH020137  SH020142         1.   
    SH020137  SH020143         1.   
    SH020137  SH020145         1.   
    SH020137  SH020146         1.   
    SH020137  SH020147         1.   
    SH020137  SH020148         1.   
    SH020137  SH020149         1.   
    SH020137  SH020150         1.   
    SH020137  SH020151         1.   
    SH020137  SH020152         1.   
    SH020137  SH020153         1.   
    SH020137  SH020154         1.   
    SH020137  SH020155         1.   
    SH020137  SH020156         1.   
    SH020137  SH020157         1.   
    SH020137  SH020158         1.   
    SH020137  SH020159         1.   
    SH020137  SH020160         1.   
    SH020137  SH020163         1.   
    SH020137  SH020164         1.   
    SH020137  SH020171         1.   
    SH020137  SH020173         1.   
    SH020137  SH020177         1.   
    SH020137  SH020178         1.   
    SH020137  SH020182         1.   
    SH020137  SH020183         1.   
    SH020137  TRSH0102         1.   
    SH020237  SH020237        10.   
    SH020237  SH020238         1.   
    SH020237  SH020240         1.   
    SH020237  SH020243         1.   
    SH020237  SH020245         1.   
    SH020237  SH020246         1.   
    SH020237  SH020252         1.   
    SH020237  SH020253         1.   
    SH020237  SH020255         1.   
    SH020237  SH020258         1.   
    SH020237  SH020259         1.   
    SH020237  SH020260         1.   
    SH020237  SH020264         1.   
    SH020237  SH020265         1.   
    SH020237  SH020266         1.   
    SH020237  SH020267         1.   
    SH020237  SH020268         1.   
    SH020237  SH020269         1.   
    SH020237  SH020272         1.   
    SH020237  SH020273         1.   
    SH020237  SH020274         1.   
    SH020237  SH020275         1.   
    SH020237  SH020276         1.   
    SH020237  SH020277         1.   
    SH020237  SH020278         1.   
    SH020237  SH020279         1.   
    SH020237  SH020282         1.   
    SH020237  SH020283         1.   
    SH020237  SH020284         1.   
    SH020237  TRSH0202         1.   
    SH020337  SH020337        10.   
    SH020337  SH020338         1.   
    SH020337  SH020340         1.   
    SH020337  SH020343         1.   
    SH020337  SH020345         1.   
    SH020337  SH020346         1.   
    SH020337  SH020352         1.   
    SH020337  SH020353         1.   
    SH020337  SH020355         1.   
    SH020337  SH020358         1.   
    SH020337  SH020359         1.   
    SH020337  SH020360         1.   
    SH020337  SH020364         1.   
    SH020337  SH020371         1.   
    SH020337  SH020373         1.   
    SH020337  SH020377         1.   
    SH020337  SH020378         1.   
    SH020337  SH020382         1.   
    SH020337  SH020383         1.   
    SH020337  TRSH0302         1.   
    SH020437  SH020437        10.   
    SH020437  SH020438         1.   
    SH020437  SH020440         1.   
    SH020437  SH020443         1.   
    SH020437  SH020445         1.   
    SH020437  SH020446         1.   
    SH020437  SH020452         1.   
    SH020437  SH020453         1.   
    SH020437  SH020455         1.   
    SH020437  SH020458         1.   
    SH020437  SH020459         1.   
    SH020437  SH020460         1.   
    SH020437  SH020464         1.   
    SH020437  SH020471         1.   
    SH020437  SH020473         1.   
    SH020437  SH020477         1.   
    SH020437  SH020478         1.   
    SH020437  SH020480         1.   
    SH020437  SH020482         1.   
    SH020437  SH020483         1.   
    SH020437  TRSH0402         1.   
    SH020537  SH020537        10.   
    SH020537  SH020538         1.   
    SH020537  SH020540         1.   
    SH020537  SH020543         1.   
    SH020537  SH020545         1.   
    SH020537  SH020546         1.   
    SH020537  SH020549         1.   
    SH020537  SH020551         1.   
    SH020537  SH020552         1.   
    SH020537  SH020553         1.   
    SH020537  SH020555         1.   
    SH020537  SH020556         1.   
    SH020537  SH020557         1.   
    SH020537  SH020558         1.   
    SH020537  SH020559         1.   
    SH020537  SH020560         1.   
    SH020537  SH020563         1.   
    SH020537  SH020564         1.   
    SH020537  SH020571         1.   
    SH020537  SH020573         1.   
    SH020537  SH020577         1.   
    SH020537  SH020578         1.   
    SH020537  SH020582         1.   
    SH020537  SH020583         1.   
    SH020537  TRSH0502         1.   
    SH020138  SH020138        10.   
    SH020138  SH020139         1.   
    SH020138  SH020140         1.   
    SH020138  SH020142         1.   
    SH020138  SH020143         1.   
    SH020138  SH020145         1.   
    SH020138  SH020146         1.   
    SH020138  SH020147         1.   
    SH020138  SH020148         1.   
    SH020138  SH020149         1.   
    SH020138  SH020150         1.   
    SH020138  SH020151         1.   
    SH020138  SH020152         1.   
    SH020138  SH020153         1.   
    SH020138  SH020154         1.   
    SH020138  SH020155         1.   
    SH020138  SH020156         1.   
    SH020138  SH020157         1.   
    SH020138  SH020158         1.   
    SH020138  SH020159         1.   
    SH020138  SH020160         1.   
    SH020138  SH020163         1.   
    SH020138  SH020164         1.   
    SH020138  SH020171         1.   
    SH020138  SH020173         1.   
    SH020138  SH020177         1.   
    SH020138  SH020178         1.   
    SH020138  SH020182         1.   
    SH020138  SH020183         1.   
    SH020138  TRSH0102         1.   
    SH020238  SH020238        10.   
    SH020238  SH020240         1.   
    SH020238  SH020243         1.   
    SH020238  SH020245         1.   
    SH020238  SH020246         1.   
    SH020238  SH020252         1.   
    SH020238  SH020253         1.   
    SH020238  SH020255         1.   
    SH020238  SH020258         1.   
    SH020238  SH020259         1.   
    SH020238  SH020260         1.   
    SH020238  SH020264         1.   
    SH020238  SH020265         1.   
    SH020238  SH020266         1.   
    SH020238  SH020267         1.   
    SH020238  SH020268         1.   
    SH020238  SH020269         1.   
    SH020238  SH020272         1.   
    SH020238  SH020273         1.   
    SH020238  SH020274         1.   
    SH020238  SH020275         1.   
    SH020238  SH020276         1.   
    SH020238  SH020277         1.   
    SH020238  SH020278         1.   
    SH020238  SH020279         1.   
    SH020238  SH020282         1.   
    SH020238  SH020283         1.   
    SH020238  SH020284         1.   
    SH020238  TRSH0202         1.   
    SH020338  SH020338        10.   
    SH020338  SH020340         1.   
    SH020338  SH020343         1.   
    SH020338  SH020345         1.   
    SH020338  SH020346         1.   
    SH020338  SH020352         1.   
    SH020338  SH020353         1.   
    SH020338  SH020355         1.   
    SH020338  SH020358         1.   
    SH020338  SH020359         1.   
    SH020338  SH020360         1.   
    SH020338  SH020364         1.   
    SH020338  SH020371         1.   
    SH020338  SH020373         1.   
    SH020338  SH020377         1.   
    SH020338  SH020378         1.   
    SH020338  SH020382         1.   
    SH020338  SH020383         1.   
    SH020338  TRSH0302         1.   
    SH020438  SH020438        10.   
    SH020438  SH020440         1.   
    SH020438  SH020443         1.   
    SH020438  SH020445         1.   
    SH020438  SH020446         1.   
    SH020438  SH020452         1.   
    SH020438  SH020453         1.   
    SH020438  SH020455         1.   
    SH020438  SH020458         1.   
    SH020438  SH020459         1.   
    SH020438  SH020460         1.   
    SH020438  SH020464         1.   
    SH020438  SH020471         1.   
    SH020438  SH020473         1.   
    SH020438  SH020477         1.   
    SH020438  SH020478         1.   
    SH020438  SH020480         1.   
    SH020438  SH020482         1.   
    SH020438  SH020483         1.   
    SH020438  TRSH0402         1.   
    SH020538  SH020538        10.   
    SH020538  SH020540         1.   
    SH020538  SH020543         1.   
    SH020538  SH020545         1.   
    SH020538  SH020546         1.   
    SH020538  SH020549         1.   
    SH020538  SH020551         1.   
    SH020538  SH020552         1.   
    SH020538  SH020553         1.   
    SH020538  SH020555         1.   
    SH020538  SH020556         1.   
    SH020538  SH020557         1.   
    SH020538  SH020558         1.   
    SH020538  SH020559         1.   
    SH020538  SH020560         1.   
    SH020538  SH020563         1.   
    SH020538  SH020564         1.   
    SH020538  SH020571         1.   
    SH020538  SH020573         1.   
    SH020538  SH020577         1.   
    SH020538  SH020578         1.   
    SH020538  SH020582         1.   
    SH020538  SH020583         1.   
    SH020538  TRSH0502         1.   
    SH020139  SH020139        10.   
    SH020139  SH020140         1.   
    SH020139  SH020142         1.   
    SH020139  SH020143         1.   
    SH020139  SH020145         1.   
    SH020139  SH020146         1.   
    SH020139  SH020147         1.   
    SH020139  SH020148         1.   
    SH020139  SH020149         1.   
    SH020139  SH020150         1.   
    SH020139  SH020151         1.   
    SH020139  SH020152         1.   
    SH020139  SH020153         1.   
    SH020139  SH020154         1.   
    SH020139  SH020155         1.   
    SH020139  SH020156         1.   
    SH020139  SH020157         1.   
    SH020139  SH020158         1.   
    SH020139  SH020159         1.   
    SH020139  SH020160         1.   
    SH020139  SH020163         1.   
    SH020139  SH020164         1.   
    SH020139  SH020171         1.   
    SH020139  SH020173         1.   
    SH020139  SH020177         1.   
    SH020139  SH020178         1.   
    SH020139  SH020182         1.   
    SH020139  SH020183         1.   
    SH020139  TRSH0102         1.   
    SH020140  SH020140        10.   
    SH020140  SH020142         1.   
    SH020140  SH020143         1.   
    SH020140  SH020145         1.   
    SH020140  SH020146         1.   
    SH020140  SH020147         1.   
    SH020140  SH020148         1.   
    SH020140  SH020149         1.   
    SH020140  SH020150         1.   
    SH020140  SH020151         1.   
    SH020140  SH020152         1.   
    SH020140  SH020153         1.   
    SH020140  SH020154         1.   
    SH020140  SH020155         1.   
    SH020140  SH020156         1.   
    SH020140  SH020157         1.   
    SH020140  SH020158         1.   
    SH020140  SH020159         1.   
    SH020140  SH020160         1.   
    SH020140  SH020163         1.   
    SH020140  SH020164         1.   
    SH020140  SH020171         1.   
    SH020140  SH020173         1.   
    SH020140  SH020177         1.   
    SH020140  SH020178         1.   
    SH020140  SH020182         1.   
    SH020140  SH020183         1.   
    SH020140  TRSH0102         1.   
    SH020240  SH020240        10.   
    SH020240  SH020243         1.   
    SH020240  SH020245         1.   
    SH020240  SH020246         1.   
    SH020240  SH020252         1.   
    SH020240  SH020253         1.   
    SH020240  SH020255         1.   
    SH020240  SH020258         1.   
    SH020240  SH020259         1.   
    SH020240  SH020260         1.   
    SH020240  SH020264         1.   
    SH020240  SH020265         1.   
    SH020240  SH020266         1.   
    SH020240  SH020267         1.   
    SH020240  SH020268         1.   
    SH020240  SH020269         1.   
    SH020240  SH020272         1.   
    SH020240  SH020273         1.   
    SH020240  SH020274         1.   
    SH020240  SH020275         1.   
    SH020240  SH020276         1.   
    SH020240  SH020277         1.   
    SH020240  SH020278         1.   
    SH020240  SH020279         1.   
    SH020240  SH020282         1.   
    SH020240  SH020283         1.   
    SH020240  SH020284         1.   
    SH020240  TRSH0202         1.   
    SH020340  SH020340        10.   
    SH020340  SH020343         1.   
    SH020340  SH020345         1.   
    SH020340  SH020346         1.   
    SH020340  SH020352         1.   
    SH020340  SH020353         1.   
    SH020340  SH020355         1.   
    SH020340  SH020358         1.   
    SH020340  SH020359         1.   
    SH020340  SH020360         1.   
    SH020340  SH020364         1.   
    SH020340  SH020371         1.   
    SH020340  SH020373         1.   
    SH020340  SH020377         1.   
    SH020340  SH020378         1.   
    SH020340  SH020382         1.   
    SH020340  SH020383         1.   
    SH020340  TRSH0302         1.   
    SH020440  SH020440        10.   
    SH020440  SH020443         1.   
    SH020440  SH020445         1.   
    SH020440  SH020446         1.   
    SH020440  SH020452         1.   
    SH020440  SH020453         1.   
    SH020440  SH020455         1.   
    SH020440  SH020458         1.   
    SH020440  SH020459         1.   
    SH020440  SH020460         1.   
    SH020440  SH020464         1.   
    SH020440  SH020471         1.   
    SH020440  SH020473         1.   
    SH020440  SH020477         1.   
    SH020440  SH020478         1.   
    SH020440  SH020480         1.   
    SH020440  SH020482         1.   
    SH020440  SH020483         1.   
    SH020440  TRSH0402         1.   
    SH020540  SH020540        10.   
    SH020540  SH020543         1.   
    SH020540  SH020545         1.   
    SH020540  SH020546         1.   
    SH020540  SH020549         1.   
    SH020540  SH020551         1.   
    SH020540  SH020552         1.   
    SH020540  SH020553         1.   
    SH020540  SH020555         1.   
    SH020540  SH020556         1.   
    SH020540  SH020557         1.   
    SH020540  SH020558         1.   
    SH020540  SH020559         1.   
    SH020540  SH020560         1.   
    SH020540  SH020563         1.   
    SH020540  SH020564         1.   
    SH020540  SH020571         1.   
    SH020540  SH020573         1.   
    SH020540  SH020577         1.   
    SH020540  SH020578         1.   
    SH020540  SH020582         1.   
    SH020540  SH020583         1.   
    SH020540  TRSH0502         1.   
    SH020142  SH020142        10.   
    SH020142  SH020143         1.   
    SH020142  SH020145         1.   
    SH020142  SH020146         1.   
    SH020142  SH020147         1.   
    SH020142  SH020148         1.   
    SH020142  SH020149         1.   
    SH020142  SH020150         1.   
    SH020142  SH020151         1.   
    SH020142  SH020152         1.   
    SH020142  SH020153         1.   
    SH020142  SH020154         1.   
    SH020142  SH020155         1.   
    SH020142  SH020156         1.   
    SH020142  SH020157         1.   
    SH020142  SH020158         1.   
    SH020142  SH020159         1.   
    SH020142  SH020160         1.   
    SH020142  SH020163         1.   
    SH020142  SH020164         1.   
    SH020142  SH020171         1.   
    SH020142  SH020173         1.   
    SH020142  SH020177         1.   
    SH020142  SH020178         1.   
    SH020142  SH020182         1.   
    SH020142  SH020183         1.   
    SH020142  TRSH0102         1.   
    SH020143  SH020143        10.   
    SH020143  SH020145         1.   
    SH020143  SH020146         1.   
    SH020143  SH020147         1.   
    SH020143  SH020148         1.   
    SH020143  SH020149         1.   
    SH020143  SH020150         1.   
    SH020143  SH020151         1.   
    SH020143  SH020152         1.   
    SH020143  SH020153         1.   
    SH020143  SH020154         1.   
    SH020143  SH020155         1.   
    SH020143  SH020156         1.   
    SH020143  SH020157         1.   
    SH020143  SH020158         1.   
    SH020143  SH020159         1.   
    SH020143  SH020160         1.   
    SH020143  SH020163         1.   
    SH020143  SH020164         1.   
    SH020143  SH020171         1.   
    SH020143  SH020173         1.   
    SH020143  SH020177         1.   
    SH020143  SH020178         1.   
    SH020143  SH020182         1.   
    SH020143  SH020183         1.   
    SH020143  TRSH0102         1.   
    SH020243  SH020243        10.   
    SH020243  SH020245         1.   
    SH020243  SH020246         1.   
    SH020243  SH020252         1.   
    SH020243  SH020253         1.   
    SH020243  SH020255         1.   
    SH020243  SH020258         1.   
    SH020243  SH020259         1.   
    SH020243  SH020260         1.   
    SH020243  SH020264         1.   
    SH020243  SH020265         1.   
    SH020243  SH020266         1.   
    SH020243  SH020267         1.   
    SH020243  SH020268         1.   
    SH020243  SH020269         1.   
    SH020243  SH020272         1.   
    SH020243  SH020273         1.   
    SH020243  SH020274         1.   
    SH020243  SH020275         1.   
    SH020243  SH020276         1.   
    SH020243  SH020277         1.   
    SH020243  SH020278         1.   
    SH020243  SH020279         1.   
    SH020243  SH020282         1.   
    SH020243  SH020283         1.   
    SH020243  SH020284         1.   
    SH020243  TRSH0202         1.   
    SH020343  SH020343        10.   
    SH020343  SH020345         1.   
    SH020343  SH020346         1.   
    SH020343  SH020352         1.   
    SH020343  SH020353         1.   
    SH020343  SH020355         1.   
    SH020343  SH020358         1.   
    SH020343  SH020359         1.   
    SH020343  SH020360         1.   
    SH020343  SH020364         1.   
    SH020343  SH020371         1.   
    SH020343  SH020373         1.   
    SH020343  SH020377         1.   
    SH020343  SH020378         1.   
    SH020343  SH020382         1.   
    SH020343  SH020383         1.   
    SH020343  TRSH0302         1.   
    SH020443  SH020443        10.   
    SH020443  SH020445         1.   
    SH020443  SH020446         1.   
    SH020443  SH020452         1.   
    SH020443  SH020453         1.   
    SH020443  SH020455         1.   
    SH020443  SH020458         1.   
    SH020443  SH020459         1.   
    SH020443  SH020460         1.   
    SH020443  SH020464         1.   
    SH020443  SH020471         1.   
    SH020443  SH020473         1.   
    SH020443  SH020477         1.   
    SH020443  SH020478         1.   
    SH020443  SH020480         1.   
    SH020443  SH020482         1.   
    SH020443  SH020483         1.   
    SH020443  TRSH0402         1.   
    SH020543  SH020543        10.   
    SH020543  SH020545         1.   
    SH020543  SH020546         1.   
    SH020543  SH020549         1.   
    SH020543  SH020551         1.   
    SH020543  SH020552         1.   
    SH020543  SH020553         1.   
    SH020543  SH020555         1.   
    SH020543  SH020556         1.   
    SH020543  SH020557         1.   
    SH020543  SH020558         1.   
    SH020543  SH020559         1.   
    SH020543  SH020560         1.   
    SH020543  SH020563         1.   
    SH020543  SH020564         1.   
    SH020543  SH020571         1.   
    SH020543  SH020573         1.   
    SH020543  SH020577         1.   
    SH020543  SH020578         1.   
    SH020543  SH020582         1.   
    SH020543  SH020583         1.   
    SH020543  TRSH0502         1.   
    SH020145  SH020145        10.   
    SH020145  SH020146         1.   
    SH020145  SH020147         1.   
    SH020145  SH020148         1.   
    SH020145  SH020149         1.   
    SH020145  SH020150         1.   
    SH020145  SH020151         1.   
    SH020145  SH020152         1.   
    SH020145  SH020153         1.   
    SH020145  SH020154         1.   
    SH020145  SH020155         1.   
    SH020145  SH020156         1.   
    SH020145  SH020157         1.   
    SH020145  SH020158         1.   
    SH020145  SH020159         1.   
    SH020145  SH020160         1.   
    SH020145  SH020163         1.   
    SH020145  SH020164         1.   
    SH020145  SH020171         1.   
    SH020145  SH020173         1.   
    SH020145  SH020177         1.   
    SH020145  SH020178         1.   
    SH020145  SH020182         1.   
    SH020145  SH020183         1.   
    SH020145  TRSH0102         1.   
    SH020245  SH020245        10.   
    SH020245  SH020246         1.   
    SH020245  SH020252         1.   
    SH020245  SH020253         1.   
    SH020245  SH020255         1.   
    SH020245  SH020258         1.   
    SH020245  SH020259         1.   
    SH020245  SH020260         1.   
    SH020245  SH020264         1.   
    SH020245  SH020265         1.   
    SH020245  SH020266         1.   
    SH020245  SH020267         1.   
    SH020245  SH020268         1.   
    SH020245  SH020269         1.   
    SH020245  SH020272         1.   
    SH020245  SH020273         1.   
    SH020245  SH020274         1.   
    SH020245  SH020275         1.   
    SH020245  SH020276         1.   
    SH020245  SH020277         1.   
    SH020245  SH020278         1.   
    SH020245  SH020279         1.   
    SH020245  SH020282         1.   
    SH020245  SH020283         1.   
    SH020245  SH020284         1.   
    SH020245  TRSH0202         1.   
    SH020345  SH020345        10.   
    SH020345  SH020346         1.   
    SH020345  SH020352         1.   
    SH020345  SH020353         1.   
    SH020345  SH020355         1.   
    SH020345  SH020358         1.   
    SH020345  SH020359         1.   
    SH020345  SH020360         1.   
    SH020345  SH020364         1.   
    SH020345  SH020371         1.   
    SH020345  SH020373         1.   
    SH020345  SH020377         1.   
    SH020345  SH020378         1.   
    SH020345  SH020382         1.   
    SH020345  SH020383         1.   
    SH020345  TRSH0302         1.   
    SH020445  SH020445        10.   
    SH020445  SH020446         1.   
    SH020445  SH020452         1.   
    SH020445  SH020453         1.   
    SH020445  SH020455         1.   
    SH020445  SH020458         1.   
    SH020445  SH020459         1.   
    SH020445  SH020460         1.   
    SH020445  SH020464         1.   
    SH020445  SH020471         1.   
    SH020445  SH020473         1.   
    SH020445  SH020477         1.   
    SH020445  SH020478         1.   
    SH020445  SH020480         1.   
    SH020445  SH020482         1.   
    SH020445  SH020483         1.   
    SH020445  TRSH0402         1.   
    SH020545  SH020545        10.   
    SH020545  SH020546         1.   
    SH020545  SH020549         1.   
    SH020545  SH020551         1.   
    SH020545  SH020552         1.   
    SH020545  SH020553         1.   
    SH020545  SH020555         1.   
    SH020545  SH020556         1.   
    SH020545  SH020557         1.   
    SH020545  SH020558         1.   
    SH020545  SH020559         1.   
    SH020545  SH020560         1.   
    SH020545  SH020563         1.   
    SH020545  SH020564         1.   
    SH020545  SH020571         1.   
    SH020545  SH020573         1.   
    SH020545  SH020577         1.   
    SH020545  SH020578         1.   
    SH020545  SH020582         1.   
    SH020545  SH020583         1.   
    SH020545  TRSH0502         1.   
    SH020146  SH020146        10.   
    SH020146  SH020147         1.   
    SH020146  SH020148         1.   
    SH020146  SH020149         1.   
    SH020146  SH020150         1.   
    SH020146  SH020151         1.   
    SH020146  SH020152         1.   
    SH020146  SH020153         1.   
    SH020146  SH020154         1.   
    SH020146  SH020155         1.   
    SH020146  SH020156         1.   
    SH020146  SH020157         1.   
    SH020146  SH020158         1.   
    SH020146  SH020159         1.   
    SH020146  SH020160         1.   
    SH020146  SH020163         1.   
    SH020146  SH020164         1.   
    SH020146  SH020171         1.   
    SH020146  SH020173         1.   
    SH020146  SH020177         1.   
    SH020146  SH020178         1.   
    SH020146  SH020182         1.   
    SH020146  SH020183         1.   
    SH020146  TRSH0102         1.   
    SH020246  SH020246        10.   
    SH020246  SH020252         1.   
    SH020246  SH020253         1.   
    SH020246  SH020255         1.   
    SH020246  SH020258         1.   
    SH020246  SH020259         1.   
    SH020246  SH020260         1.   
    SH020246  SH020264         1.   
    SH020246  SH020265         1.   
    SH020246  SH020266         1.   
    SH020246  SH020267         1.   
    SH020246  SH020268         1.   
    SH020246  SH020269         1.   
    SH020246  SH020272         1.   
    SH020246  SH020273         1.   
    SH020246  SH020274         1.   
    SH020246  SH020275         1.   
    SH020246  SH020276         1.   
    SH020246  SH020277         1.   
    SH020246  SH020278         1.   
    SH020246  SH020279         1.   
    SH020246  SH020282         1.   
    SH020246  SH020283         1.   
    SH020246  SH020284         1.   
    SH020246  TRSH0202         1.   
    SH020346  SH020346        10.   
    SH020346  SH020352         1.   
    SH020346  SH020353         1.   
    SH020346  SH020355         1.   
    SH020346  SH020358         1.   
    SH020346  SH020359         1.   
    SH020346  SH020360         1.   
    SH020346  SH020364         1.   
    SH020346  SH020371         1.   
    SH020346  SH020373         1.   
    SH020346  SH020377         1.   
    SH020346  SH020378         1.   
    SH020346  SH020382         1.   
    SH020346  SH020383         1.   
    SH020346  TRSH0302         1.   
    SH020446  SH020446        10.   
    SH020446  SH020452         1.   
    SH020446  SH020453         1.   
    SH020446  SH020455         1.   
    SH020446  SH020458         1.   
    SH020446  SH020459         1.   
    SH020446  SH020460         1.   
    SH020446  SH020464         1.   
    SH020446  SH020471         1.   
    SH020446  SH020473         1.   
    SH020446  SH020477         1.   
    SH020446  SH020478         1.   
    SH020446  SH020480         1.   
    SH020446  SH020482         1.   
    SH020446  SH020483         1.   
    SH020446  TRSH0402         1.   
    SH020546  SH020546        10.   
    SH020546  SH020549         1.   
    SH020546  SH020551         1.   
    SH020546  SH020552         1.   
    SH020546  SH020553         1.   
    SH020546  SH020555         1.   
    SH020546  SH020556         1.   
    SH020546  SH020557         1.   
    SH020546  SH020558         1.   
    SH020546  SH020559         1.   
    SH020546  SH020560         1.   
    SH020546  SH020563         1.   
    SH020546  SH020564         1.   
    SH020546  SH020571         1.   
    SH020546  SH020573         1.   
    SH020546  SH020577         1.   
    SH020546  SH020578         1.   
    SH020546  SH020582         1.   
    SH020546  SH020583         1.   
    SH020546  TRSH0502         1.   
    SH020147  SH020147        10.   
    SH020147  SH020148         1.   
    SH020147  SH020149         1.   
    SH020147  SH020150         1.   
    SH020147  SH020151         1.   
    SH020147  SH020152         1.   
    SH020147  SH020153         1.   
    SH020147  SH020154         1.   
    SH020147  SH020155         1.   
    SH020147  SH020156         1.   
    SH020147  SH020157         1.   
    SH020147  SH020158         1.   
    SH020147  SH020159         1.   
    SH020147  SH020160         1.   
    SH020147  SH020163         1.   
    SH020147  SH020164         1.   
    SH020147  SH020171         1.   
    SH020147  SH020173         1.   
    SH020147  SH020177         1.   
    SH020147  SH020178         1.   
    SH020147  SH020182         1.   
    SH020147  SH020183         1.   
    SH020147  TRSH0102         1.   
    SH020148  SH020148        10.   
    SH020148  SH020149         1.   
    SH020148  SH020150         1.   
    SH020148  SH020151         1.   
    SH020148  SH020152         1.   
    SH020148  SH020153         1.   
    SH020148  SH020154         1.   
    SH020148  SH020155         1.   
    SH020148  SH020156         1.   
    SH020148  SH020157         1.   
    SH020148  SH020158         1.   
    SH020148  SH020159         1.   
    SH020148  SH020160         1.   
    SH020148  SH020163         1.   
    SH020148  SH020164         1.   
    SH020148  SH020171         1.   
    SH020148  SH020173         1.   
    SH020148  SH020177         1.   
    SH020148  SH020178         1.   
    SH020148  SH020182         1.   
    SH020148  SH020183         1.   
    SH020148  TRSH0102         1.   
    SH020149  SH020149        10.   
    SH020149  SH020150         1.   
    SH020149  SH020151         1.   
    SH020149  SH020152         1.   
    SH020149  SH020153         1.   
    SH020149  SH020154         1.   
    SH020149  SH020155         1.   
    SH020149  SH020156         1.   
    SH020149  SH020157         1.   
    SH020149  SH020158         1.   
    SH020149  SH020159         1.   
    SH020149  SH020160         1.   
    SH020149  SH020163         1.   
    SH020149  SH020164         1.   
    SH020149  SH020171         1.   
    SH020149  SH020173         1.   
    SH020149  SH020177         1.   
    SH020149  SH020178         1.   
    SH020149  SH020182         1.   
    SH020149  SH020183         1.   
    SH020149  TRSH0102         1.   
    SH020549  SH020549        10.   
    SH020549  SH020551         1.   
    SH020549  SH020552         1.   
    SH020549  SH020553         1.   
    SH020549  SH020555         1.   
    SH020549  SH020556         1.   
    SH020549  SH020557         1.   
    SH020549  SH020558         1.   
    SH020549  SH020559         1.   
    SH020549  SH020560         1.   
    SH020549  SH020563         1.   
    SH020549  SH020564         1.   
    SH020549  SH020571         1.   
    SH020549  SH020573         1.   
    SH020549  SH020577         1.   
    SH020549  SH020578         1.   
    SH020549  SH020582         1.   
    SH020549  SH020583         1.   
    SH020549  TRSH0502         1.   
    SH020150  SH020150        10.   
    SH020150  SH020151         1.   
    SH020150  SH020152         1.   
    SH020150  SH020153         1.   
    SH020150  SH020154         1.   
    SH020150  SH020155         1.   
    SH020150  SH020156         1.   
    SH020150  SH020157         1.   
    SH020150  SH020158         1.   
    SH020150  SH020159         1.   
    SH020150  SH020160         1.   
    SH020150  SH020163         1.   
    SH020150  SH020164         1.   
    SH020150  SH020171         1.   
    SH020150  SH020173         1.   
    SH020150  SH020177         1.   
    SH020150  SH020178         1.   
    SH020150  SH020182         1.   
    SH020150  SH020183         1.   
    SH020150  TRSH0102         1.   
    SH020151  SH020151        10.   
    SH020151  SH020152         1.   
    SH020151  SH020153         1.   
    SH020151  SH020154         1.   
    SH020151  SH020155         1.   
    SH020151  SH020156         1.   
    SH020151  SH020157         1.   
    SH020151  SH020158         1.   
    SH020151  SH020159         1.   
    SH020151  SH020160         1.   
    SH020151  SH020163         1.   
    SH020151  SH020164         1.   
    SH020151  SH020171         1.   
    SH020151  SH020173         1.   
    SH020151  SH020177         1.   
    SH020151  SH020178         1.   
    SH020151  SH020182         1.   
    SH020151  SH020183         1.   
    SH020151  TRSH0102         1.   
    SH020551  SH020551        10.   
    SH020551  SH020552         1.   
    SH020551  SH020553         1.   
    SH020551  SH020555         1.   
    SH020551  SH020556         1.   
    SH020551  SH020557         1.   
    SH020551  SH020558         1.   
    SH020551  SH020559         1.   
    SH020551  SH020560         1.   
    SH020551  SH020563         1.   
    SH020551  SH020564         1.   
    SH020551  SH020571         1.   
    SH020551  SH020573         1.   
    SH020551  SH020577         1.   
    SH020551  SH020578         1.   
    SH020551  SH020582         1.   
    SH020551  SH020583         1.   
    SH020551  TRSH0502         1.   
    SH020152  SH020152        10.   
    SH020152  SH020153         1.   
    SH020152  SH020154         1.   
    SH020152  SH020155         1.   
    SH020152  SH020156         1.   
    SH020152  SH020157         1.   
    SH020152  SH020158         1.   
    SH020152  SH020159         1.   
    SH020152  SH020160         1.   
    SH020152  SH020163         1.   
    SH020152  SH020164         1.   
    SH020152  SH020171         1.   
    SH020152  SH020173         1.   
    SH020152  SH020177         1.   
    SH020152  SH020178         1.   
    SH020152  SH020182         1.   
    SH020152  SH020183         1.   
    SH020152  TRSH0102         1.   
    SH020252  SH020252        10.   
    SH020252  SH020253         1.   
    SH020252  SH020255         1.   
    SH020252  SH020258         1.   
    SH020252  SH020259         1.   
    SH020252  SH020260         1.   
    SH020252  SH020264         1.   
    SH020252  SH020265         1.   
    SH020252  SH020266         1.   
    SH020252  SH020267         1.   
    SH020252  SH020268         1.   
    SH020252  SH020269         1.   
    SH020252  SH020272         1.   
    SH020252  SH020273         1.   
    SH020252  SH020274         1.   
    SH020252  SH020275         1.   
    SH020252  SH020276         1.   
    SH020252  SH020277         1.   
    SH020252  SH020278         1.   
    SH020252  SH020279         1.   
    SH020252  SH020282         1.   
    SH020252  SH020283         1.   
    SH020252  SH020284         1.   
    SH020252  TRSH0202         1.   
    SH020352  SH020352        10.   
    SH020352  SH020353         1.   
    SH020352  SH020355         1.   
    SH020352  SH020358         1.   
    SH020352  SH020359         1.   
    SH020352  SH020360         1.   
    SH020352  SH020364         1.   
    SH020352  SH020371         1.   
    SH020352  SH020373         1.   
    SH020352  SH020377         1.   
    SH020352  SH020378         1.   
    SH020352  SH020382         1.   
    SH020352  SH020383         1.   
    SH020352  TRSH0302         1.   
    SH020452  SH020452        10.   
    SH020452  SH020453         1.   
    SH020452  SH020455         1.   
    SH020452  SH020458         1.   
    SH020452  SH020459         1.   
    SH020452  SH020460         1.   
    SH020452  SH020464         1.   
    SH020452  SH020471         1.   
    SH020452  SH020473         1.   
    SH020452  SH020477         1.   
    SH020452  SH020478         1.   
    SH020452  SH020480         1.   
    SH020452  SH020482         1.   
    SH020452  SH020483         1.   
    SH020452  TRSH0402         1.   
    SH020552  SH020552        10.   
    SH020552  SH020553         1.   
    SH020552  SH020555         1.   
    SH020552  SH020556         1.   
    SH020552  SH020557         1.   
    SH020552  SH020558         1.   
    SH020552  SH020559         1.   
    SH020552  SH020560         1.   
    SH020552  SH020563         1.   
    SH020552  SH020564         1.   
    SH020552  SH020571         1.   
    SH020552  SH020573         1.   
    SH020552  SH020577         1.   
    SH020552  SH020578         1.   
    SH020552  SH020582         1.   
    SH020552  SH020583         1.   
    SH020552  TRSH0502         1.   
    SH020153  SH020153        10.   
    SH020153  SH020154         1.   
    SH020153  SH020155         1.   
    SH020153  SH020156         1.   
    SH020153  SH020157         1.   
    SH020153  SH020158         1.   
    SH020153  SH020159         1.   
    SH020153  SH020160         1.   
    SH020153  SH020163         1.   
    SH020153  SH020164         1.   
    SH020153  SH020171         1.   
    SH020153  SH020173         1.   
    SH020153  SH020177         1.   
    SH020153  SH020178         1.   
    SH020153  SH020182         1.   
    SH020153  SH020183         1.   
    SH020153  TRSH0102         1.   
    SH020253  SH020253        10.   
    SH020253  SH020255         1.   
    SH020253  SH020258         1.   
    SH020253  SH020259         1.   
    SH020253  SH020260         1.   
    SH020253  SH020264         1.   
    SH020253  SH020265         1.   
    SH020253  SH020266         1.   
    SH020253  SH020267         1.   
    SH020253  SH020268         1.   
    SH020253  SH020269         1.   
    SH020253  SH020272         1.   
    SH020253  SH020273         1.   
    SH020253  SH020274         1.   
    SH020253  SH020275         1.   
    SH020253  SH020276         1.   
    SH020253  SH020277         1.   
    SH020253  SH020278         1.   
    SH020253  SH020279         1.   
    SH020253  SH020282         1.   
    SH020253  SH020283         1.   
    SH020253  SH020284         1.   
    SH020253  TRSH0202         1.   
    SH020353  SH020353        10.   
    SH020353  SH020355         1.   
    SH020353  SH020358         1.   
    SH020353  SH020359         1.   
    SH020353  SH020360         1.   
    SH020353  SH020364         1.   
    SH020353  SH020371         1.   
    SH020353  SH020373         1.   
    SH020353  SH020377         1.   
    SH020353  SH020378         1.   
    SH020353  SH020382         1.   
    SH020353  SH020383         1.   
    SH020353  TRSH0302         1.   
    SH020453  SH020453        10.   
    SH020453  SH020455         1.   
    SH020453  SH020458         1.   
    SH020453  SH020459         1.   
    SH020453  SH020460         1.   
    SH020453  SH020464         1.   
    SH020453  SH020471         1.   
    SH020453  SH020473         1.   
    SH020453  SH020477         1.   
    SH020453  SH020478         1.   
    SH020453  SH020480         1.   
    SH020453  SH020482         1.   
    SH020453  SH020483         1.   
    SH020453  TRSH0402         1.   
    SH020553  SH020553        10.   
    SH020553  SH020555         1.   
    SH020553  SH020556         1.   
    SH020553  SH020557         1.   
    SH020553  SH020558         1.   
    SH020553  SH020559         1.   
    SH020553  SH020560         1.   
    SH020553  SH020563         1.   
    SH020553  SH020564         1.   
    SH020553  SH020571         1.   
    SH020553  SH020573         1.   
    SH020553  SH020577         1.   
    SH020553  SH020578         1.   
    SH020553  SH020582         1.   
    SH020553  SH020583         1.   
    SH020553  TRSH0502         1.   
    SH020154  SH020154        10.   
    SH020154  SH020155         1.   
    SH020154  SH020156         1.   
    SH020154  SH020157         1.   
    SH020154  SH020158         1.   
    SH020154  SH020159         1.   
    SH020154  SH020160         1.   
    SH020154  SH020163         1.   
    SH020154  SH020164         1.   
    SH020154  SH020171         1.   
    SH020154  SH020173         1.   
    SH020154  SH020177         1.   
    SH020154  SH020178         1.   
    SH020154  SH020182         1.   
    SH020154  SH020183         1.   
    SH020154  TRSH0102         1.   
    SH020155  SH020155        10.   
    SH020155  SH020156         1.   
    SH020155  SH020157         1.   
    SH020155  SH020158         1.   
    SH020155  SH020159         1.   
    SH020155  SH020160         1.   
    SH020155  SH020163         1.   
    SH020155  SH020164         1.   
    SH020155  SH020171         1.   
    SH020155  SH020173         1.   
    SH020155  SH020177         1.   
    SH020155  SH020178         1.   
    SH020155  SH020182         1.   
    SH020155  SH020183         1.   
    SH020155  TRSH0102         1.   
    SH020255  SH020255        10.   
    SH020255  SH020258         1.   
    SH020255  SH020259         1.   
    SH020255  SH020260         1.   
    SH020255  SH020264         1.   
    SH020255  SH020265         1.   
    SH020255  SH020266         1.   
    SH020255  SH020267         1.   
    SH020255  SH020268         1.   
    SH020255  SH020269         1.   
    SH020255  SH020272         1.   
    SH020255  SH020273         1.   
    SH020255  SH020274         1.   
    SH020255  SH020275         1.   
    SH020255  SH020276         1.   
    SH020255  SH020277         1.   
    SH020255  SH020278         1.   
    SH020255  SH020279         1.   
    SH020255  SH020282         1.   
    SH020255  SH020283         1.   
    SH020255  SH020284         1.   
    SH020255  TRSH0202         1.   
    SH020355  SH020355        10.   
    SH020355  SH020358         1.   
    SH020355  SH020359         1.   
    SH020355  SH020360         1.   
    SH020355  SH020364         1.   
    SH020355  SH020371         1.   
    SH020355  SH020373         1.   
    SH020355  SH020377         1.   
    SH020355  SH020378         1.   
    SH020355  SH020382         1.   
    SH020355  SH020383         1.   
    SH020355  TRSH0302         1.   
    SH020455  SH020455        10.   
    SH020455  SH020458         1.   
    SH020455  SH020459         1.   
    SH020455  SH020460         1.   
    SH020455  SH020464         1.   
    SH020455  SH020471         1.   
    SH020455  SH020473         1.   
    SH020455  SH020477         1.   
    SH020455  SH020478         1.   
    SH020455  SH020480         1.   
    SH020455  SH020482         1.   
    SH020455  SH020483         1.   
    SH020455  TRSH0402         1.   
    SH020555  SH020555        10.   
    SH020555  SH020556         1.   
    SH020555  SH020557         1.   
    SH020555  SH020558         1.   
    SH020555  SH020559         1.   
    SH020555  SH020560         1.   
    SH020555  SH020563         1.   
    SH020555  SH020564         1.   
    SH020555  SH020571         1.   
    SH020555  SH020573         1.   
    SH020555  SH020577         1.   
    SH020555  SH020578         1.   
    SH020555  SH020582         1.   
    SH020555  SH020583         1.   
    SH020555  TRSH0502         1.   
    SH020156  SH020156        10.   
    SH020156  SH020157         1.   
    SH020156  SH020158         1.   
    SH020156  SH020159         1.   
    SH020156  SH020160         1.   
    SH020156  SH020163         1.   
    SH020156  SH020164         1.   
    SH020156  SH020171         1.   
    SH020156  SH020173         1.   
    SH020156  SH020177         1.   
    SH020156  SH020178         1.   
    SH020156  SH020182         1.   
    SH020156  SH020183         1.   
    SH020156  TRSH0102         1.   
    SH020556  SH020556        10.   
    SH020556  SH020557         1.   
    SH020556  SH020558         1.   
    SH020556  SH020559         1.   
    SH020556  SH020560         1.   
    SH020556  SH020563         1.   
    SH020556  SH020564         1.   
    SH020556  SH020571         1.   
    SH020556  SH020573         1.   
    SH020556  SH020577         1.   
    SH020556  SH020578         1.   
    SH020556  SH020582         1.   
    SH020556  SH020583         1.   
    SH020556  TRSH0502         1.   
    SH020157  SH020157        10.   
    SH020157  SH020158         1.   
    SH020157  SH020159         1.   
    SH020157  SH020160         1.   
    SH020157  SH020163         1.   
    SH020157  SH020164         1.   
    SH020157  SH020171         1.   
    SH020157  SH020173         1.   
    SH020157  SH020177         1.   
    SH020157  SH020178         1.   
    SH020157  SH020182         1.   
    SH020157  SH020183         1.   
    SH020157  TRSH0102         1.   
    SH020557  SH020557        10.   
    SH020557  SH020558         1.   
    SH020557  SH020559         1.   
    SH020557  SH020560         1.   
    SH020557  SH020563         1.   
    SH020557  SH020564         1.   
    SH020557  SH020571         1.   
    SH020557  SH020573         1.   
    SH020557  SH020577         1.   
    SH020557  SH020578         1.   
    SH020557  SH020582         1.   
    SH020557  SH020583         1.   
    SH020557  TRSH0502         1.   
    SH020158  SH020158        10.   
    SH020158  SH020159         1.   
    SH020158  SH020160         1.   
    SH020158  SH020163         1.   
    SH020158  SH020164         1.   
    SH020158  SH020171         1.   
    SH020158  SH020173         1.   
    SH020158  SH020177         1.   
    SH020158  SH020178         1.   
    SH020158  SH020182         1.   
    SH020158  SH020183         1.   
    SH020158  TRSH0102         1.   
    SH020258  SH020258        10.   
    SH020258  SH020259         1.   
    SH020258  SH020260         1.   
    SH020258  SH020264         1.   
    SH020258  SH020265         1.   
    SH020258  SH020266         1.   
    SH020258  SH020267         1.   
    SH020258  SH020268         1.   
    SH020258  SH020269         1.   
    SH020258  SH020272         1.   
    SH020258  SH020273         1.   
    SH020258  SH020274         1.   
    SH020258  SH020275         1.   
    SH020258  SH020276         1.   
    SH020258  SH020277         1.   
    SH020258  SH020278         1.   
    SH020258  SH020279         1.   
    SH020258  SH020282         1.   
    SH020258  SH020283         1.   
    SH020258  SH020284         1.   
    SH020258  TRSH0202         1.   
    SH020358  SH020358        10.   
    SH020358  SH020359         1.   
    SH020358  SH020360         1.   
    SH020358  SH020364         1.   
    SH020358  SH020371         1.   
    SH020358  SH020373         1.   
    SH020358  SH020377         1.   
    SH020358  SH020378         1.   
    SH020358  SH020382         1.   
    SH020358  SH020383         1.   
    SH020358  TRSH0302         1.   
    SH020458  SH020458        10.   
    SH020458  SH020459         1.   
    SH020458  SH020460         1.   
    SH020458  SH020464         1.   
    SH020458  SH020471         1.   
    SH020458  SH020473         1.   
    SH020458  SH020477         1.   
    SH020458  SH020478         1.   
    SH020458  SH020480         1.   
    SH020458  SH020482         1.   
    SH020458  SH020483         1.   
    SH020458  TRSH0402         1.   
    SH020558  SH020558        10.   
    SH020558  SH020559         1.   
    SH020558  SH020560         1.   
    SH020558  SH020563         1.   
    SH020558  SH020564         1.   
    SH020558  SH020571         1.   
    SH020558  SH020573         1.   
    SH020558  SH020577         1.   
    SH020558  SH020578         1.   
    SH020558  SH020582         1.   
    SH020558  SH020583         1.   
    SH020558  TRSH0502         1.   
    SH020159  SH020159        10.   
    SH020159  SH020160         1.   
    SH020159  SH020163         1.   
    SH020159  SH020164         1.   
    SH020159  SH020171         1.   
    SH020159  SH020173         1.   
    SH020159  SH020177         1.   
    SH020159  SH020178         1.   
    SH020159  SH020182         1.   
    SH020159  SH020183         1.   
    SH020159  TRSH0102         1.   
    SH020259  SH020259        10.   
    SH020259  SH020260         1.   
    SH020259  SH020264         1.   
    SH020259  SH020265         1.   
    SH020259  SH020266         1.   
    SH020259  SH020267         1.   
    SH020259  SH020268         1.   
    SH020259  SH020269         1.   
    SH020259  SH020272         1.   
    SH020259  SH020273         1.   
    SH020259  SH020274         1.   
    SH020259  SH020275         1.   
    SH020259  SH020276         1.   
    SH020259  SH020277         1.   
    SH020259  SH020278         1.   
    SH020259  SH020279         1.   
    SH020259  SH020282         1.   
    SH020259  SH020283         1.   
    SH020259  SH020284         1.   
    SH020259  TRSH0202         1.   
    SH020359  SH020359        10.   
    SH020359  SH020360         1.   
    SH020359  SH020364         1.   
    SH020359  SH020371         1.   
    SH020359  SH020373         1.   
    SH020359  SH020377         1.   
    SH020359  SH020378         1.   
    SH020359  SH020382         1.   
    SH020359  SH020383         1.   
    SH020359  TRSH0302         1.   
    SH020459  SH020459        10.   
    SH020459  SH020460         1.   
    SH020459  SH020464         1.   
    SH020459  SH020471         1.   
    SH020459  SH020473         1.   
    SH020459  SH020477         1.   
    SH020459  SH020478         1.   
    SH020459  SH020480         1.   
    SH020459  SH020482         1.   
    SH020459  SH020483         1.   
    SH020459  TRSH0402         1.   
    SH020559  SH020559        10.   
    SH020559  SH020560         1.   
    SH020559  SH020563         1.   
    SH020559  SH020564         1.   
    SH020559  SH020571         1.   
    SH020559  SH020573         1.   
    SH020559  SH020577         1.   
    SH020559  SH020578         1.   
    SH020559  SH020582         1.   
    SH020559  SH020583         1.   
    SH020559  TRSH0502         1.   
    SH020160  SH020160        10.   
    SH020160  SH020163         1.   
    SH020160  SH020164         1.   
    SH020160  SH020171         1.   
    SH020160  SH020173         1.   
    SH020160  SH020177         1.   
    SH020160  SH020178         1.   
    SH020160  SH020182         1.   
    SH020160  SH020183         1.   
    SH020160  TRSH0102         1.   
    SH020260  SH020260        10.   
    SH020260  SH020264         1.   
    SH020260  SH020265         1.   
    SH020260  SH020266         1.   
    SH020260  SH020267         1.   
    SH020260  SH020268         1.   
    SH020260  SH020269         1.   
    SH020260  SH020272         1.   
    SH020260  SH020273         1.   
    SH020260  SH020274         1.   
    SH020260  SH020275         1.   
    SH020260  SH020276         1.   
    SH020260  SH020277         1.   
    SH020260  SH020278         1.   
    SH020260  SH020279         1.   
    SH020260  SH020282         1.   
    SH020260  SH020283         1.   
    SH020260  SH020284         1.   
    SH020260  TRSH0202         1.   
    SH020360  SH020360        10.   
    SH020360  SH020364         1.   
    SH020360  SH020371         1.   
    SH020360  SH020373         1.   
    SH020360  SH020377         1.   
    SH020360  SH020378         1.   
    SH020360  SH020382         1.   
    SH020360  SH020383         1.   
    SH020360  TRSH0302         1.   
    SH020460  SH020460        10.   
    SH020460  SH020464         1.   
    SH020460  SH020471         1.   
    SH020460  SH020473         1.   
    SH020460  SH020477         1.   
    SH020460  SH020478         1.   
    SH020460  SH020480         1.   
    SH020460  SH020482         1.   
    SH020460  SH020483         1.   
    SH020460  TRSH0402         1.   
    SH020560  SH020560        10.   
    SH020560  SH020563         1.   
    SH020560  SH020564         1.   
    SH020560  SH020571         1.   
    SH020560  SH020573         1.   
    SH020560  SH020577         1.   
    SH020560  SH020578         1.   
    SH020560  SH020582         1.   
    SH020560  SH020583         1.   
    SH020560  TRSH0502         1.   
    SH020163  SH020163        10.   
    SH020163  SH020164         1.   
    SH020163  SH020171         1.   
    SH020163  SH020173         1.   
    SH020163  SH020177         1.   
    SH020163  SH020178         1.   
    SH020163  SH020182         1.   
    SH020163  SH020183         1.   
    SH020163  TRSH0102         1.   
    SH020563  SH020563        10.   
    SH020563  SH020564         1.   
    SH020563  SH020571         1.   
    SH020563  SH020573         1.   
    SH020563  SH020577         1.   
    SH020563  SH020578         1.   
    SH020563  SH020582         1.   
    SH020563  SH020583         1.   
    SH020563  TRSH0502         1.   
    SH020164  SH020164        10.   
    SH020164  SH020171         1.   
    SH020164  SH020173         1.   
    SH020164  SH020177         1.   
    SH020164  SH020178         1.   
    SH020164  SH020182         1.   
    SH020164  SH020183         1.   
    SH020164  TRSH0102         1.   
    SH020264  SH020264        10.   
    SH020264  SH020265         1.   
    SH020264  SH020266         1.   
    SH020264  SH020267         1.   
    SH020264  SH020268         1.   
    SH020264  SH020269         1.   
    SH020264  SH020272         1.   
    SH020264  SH020273         1.   
    SH020264  SH020274         1.   
    SH020264  SH020275         1.   
    SH020264  SH020276         1.   
    SH020264  SH020277         1.   
    SH020264  SH020278         1.   
    SH020264  SH020279         1.   
    SH020264  SH020282         1.   
    SH020264  SH020283         1.   
    SH020264  SH020284         1.   
    SH020264  TRSH0202         1.   
    SH020364  SH020364        10.   
    SH020364  SH020371         1.   
    SH020364  SH020373         1.   
    SH020364  SH020377         1.   
    SH020364  SH020378         1.   
    SH020364  SH020382         1.   
    SH020364  SH020383         1.   
    SH020364  TRSH0302         1.   
    SH020464  SH020464        10.   
    SH020464  SH020471         1.   
    SH020464  SH020473         1.   
    SH020464  SH020477         1.   
    SH020464  SH020478         1.   
    SH020464  SH020480         1.   
    SH020464  SH020482         1.   
    SH020464  SH020483         1.   
    SH020464  TRSH0402         1.   
    SH020564  SH020564        10.   
    SH020564  SH020571         1.   
    SH020564  SH020573         1.   
    SH020564  SH020577         1.   
    SH020564  SH020578         1.   
    SH020564  SH020582         1.   
    SH020564  SH020583         1.   
    SH020564  TRSH0502         1.   
    SH020265  SH020265        10.   
    SH020265  SH020266         1.   
    SH020265  SH020267         1.   
    SH020265  SH020268         1.   
    SH020265  SH020269         1.   
    SH020265  SH020272         1.   
    SH020265  SH020273         1.   
    SH020265  SH020274         1.   
    SH020265  SH020275         1.   
    SH020265  SH020276         1.   
    SH020265  SH020277         1.   
    SH020265  SH020278         1.   
    SH020265  SH020279         1.   
    SH020265  SH020282         1.   
    SH020265  SH020283         1.   
    SH020265  SH020284         1.   
    SH020265  TRSH0202         1.   
    SH020266  SH020266        10.   
    SH020266  SH020267         1.   
    SH020266  SH020268         1.   
    SH020266  SH020269         1.   
    SH020266  SH020272         1.   
    SH020266  SH020273         1.   
    SH020266  SH020274         1.   
    SH020266  SH020275         1.   
    SH020266  SH020276         1.   
    SH020266  SH020277         1.   
    SH020266  SH020278         1.   
    SH020266  SH020279         1.   
    SH020266  SH020282         1.   
    SH020266  SH020283         1.   
    SH020266  SH020284         1.   
    SH020266  TRSH0202         1.   
    SH020267  SH020267        10.   
    SH020267  SH020268         1.   
    SH020267  SH020269         1.   
    SH020267  SH020272         1.   
    SH020267  SH020273         1.   
    SH020267  SH020274         1.   
    SH020267  SH020275         1.   
    SH020267  SH020276         1.   
    SH020267  SH020277         1.   
    SH020267  SH020278         1.   
    SH020267  SH020279         1.   
    SH020267  SH020282         1.   
    SH020267  SH020283         1.   
    SH020267  SH020284         1.   
    SH020267  TRSH0202         1.   
    SH020268  SH020268        10.   
    SH020268  SH020269         1.   
    SH020268  SH020272         1.   
    SH020268  SH020273         1.   
    SH020268  SH020274         1.   
    SH020268  SH020275         1.   
    SH020268  SH020276         1.   
    SH020268  SH020277         1.   
    SH020268  SH020278         1.   
    SH020268  SH020279         1.   
    SH020268  SH020282         1.   
    SH020268  SH020283         1.   
    SH020268  SH020284         1.   
    SH020268  TRSH0202         1.   
    SH020269  SH020269        10.   
    SH020269  SH020272         1.   
    SH020269  SH020273         1.   
    SH020269  SH020274         1.   
    SH020269  SH020275         1.   
    SH020269  SH020276         1.   
    SH020269  SH020277         1.   
    SH020269  SH020278         1.   
    SH020269  SH020279         1.   
    SH020269  SH020282         1.   
    SH020269  SH020283         1.   
    SH020269  SH020284         1.   
    SH020269  TRSH0202         1.   
    SH020171  SH020171        10.   
    SH020171  SH020173         1.   
    SH020171  SH020177         1.   
    SH020171  SH020178         1.   
    SH020171  SH020182         1.   
    SH020171  SH020183         1.   
    SH020171  TRSH0102         1.   
    SH020371  SH020371        10.   
    SH020371  SH020373         1.   
    SH020371  SH020377         1.   
    SH020371  SH020378         1.   
    SH020371  SH020382         1.   
    SH020371  SH020383         1.   
    SH020371  TRSH0302         1.   
    SH020471  SH020471        10.   
    SH020471  SH020473         1.   
    SH020471  SH020477         1.   
    SH020471  SH020478         1.   
    SH020471  SH020480         1.   
    SH020471  SH020482         1.   
    SH020471  SH020483         1.   
    SH020471  TRSH0402         1.   
    SH020571  SH020571        10.   
    SH020571  SH020573         1.   
    SH020571  SH020577         1.   
    SH020571  SH020578         1.   
    SH020571  SH020582         1.   
    SH020571  SH020583         1.   
    SH020571  TRSH0502         1.   
    SH020272  SH020272        10.   
    SH020272  SH020273         1.   
    SH020272  SH020274         1.   
    SH020272  SH020275         1.   
    SH020272  SH020276         1.   
    SH020272  SH020277         1.   
    SH020272  SH020278         1.   
    SH020272  SH020279         1.   
    SH020272  SH020282         1.   
    SH020272  SH020283         1.   
    SH020272  SH020284         1.   
    SH020272  TRSH0202         1.   
    SH020173  SH020173        10.   
    SH020173  SH020177         1.   
    SH020173  SH020178         1.   
    SH020173  SH020182         1.   
    SH020173  SH020183         1.   
    SH020173  TRSH0102         1.   
    SH020273  SH020273        10.   
    SH020273  SH020274         1.   
    SH020273  SH020275         1.   
    SH020273  SH020276         1.   
    SH020273  SH020277         1.   
    SH020273  SH020278         1.   
    SH020273  SH020279         1.   
    SH020273  SH020282         1.   
    SH020273  SH020283         1.   
    SH020273  SH020284         1.   
    SH020273  TRSH0202         1.   
    SH020373  SH020373        10.   
    SH020373  SH020377         1.   
    SH020373  SH020378         1.   
    SH020373  SH020382         1.   
    SH020373  SH020383         1.   
    SH020373  TRSH0302         1.   
    SH020473  SH020473        10.   
    SH020473  SH020477         1.   
    SH020473  SH020478         1.   
    SH020473  SH020480         1.   
    SH020473  SH020482         1.   
    SH020473  SH020483         1.   
    SH020473  TRSH0402         1.   
    SH020573  SH020573        10.   
    SH020573  SH020577         1.   
    SH020573  SH020578         1.   
    SH020573  SH020582         1.   
    SH020573  SH020583         1.   
    SH020573  TRSH0502         1.   
    SH020274  SH020274        10.   
    SH020274  SH020275         1.   
    SH020274  SH020276         1.   
    SH020274  SH020277         1.   
    SH020274  SH020278         1.   
    SH020274  SH020279         1.   
    SH020274  SH020282         1.   
    SH020274  SH020283         1.   
    SH020274  SH020284         1.   
    SH020274  TRSH0202         1.   
    SH020275  SH020275        10.   
    SH020275  SH020276         1.   
    SH020275  SH020277         1.   
    SH020275  SH020278         1.   
    SH020275  SH020279         1.   
    SH020275  SH020282         1.   
    SH020275  SH020283         1.   
    SH020275  SH020284         1.   
    SH020275  TRSH0202         1.   
    SH020276  SH020276        10.   
    SH020276  SH020277         1.   
    SH020276  SH020278         1.   
    SH020276  SH020279         1.   
    SH020276  SH020282         1.   
    SH020276  SH020283         1.   
    SH020276  SH020284         1.   
    SH020276  TRSH0202         1.   
    SH020177  SH020177        10.   
    SH020177  SH020178         1.   
    SH020177  SH020182         1.   
    SH020177  SH020183         1.   
    SH020177  TRSH0102         1.   
    SH020277  SH020277        10.   
    SH020277  SH020278         1.   
    SH020277  SH020279         1.   
    SH020277  SH020282         1.   
    SH020277  SH020283         1.   
    SH020277  SH020284         1.   
    SH020277  TRSH0202         1.   
    SH020377  SH020377        10.   
    SH020377  SH020378         1.   
    SH020377  SH020382         1.   
    SH020377  SH020383         1.   
    SH020377  TRSH0302         1.   
    SH020477  SH020477        10.   
    SH020477  SH020478         1.   
    SH020477  SH020480         1.   
    SH020477  SH020482         1.   
    SH020477  SH020483         1.   
    SH020477  TRSH0402         1.   
    SH020577  SH020577        10.   
    SH020577  SH020578         1.   
    SH020577  SH020582         1.   
    SH020577  SH020583         1.   
    SH020577  TRSH0502         1.   
    SH020178  SH020178        10.   
    SH020178  SH020182         1.   
    SH020178  SH020183         1.   
    SH020178  TRSH0102         1.   
    SH020278  SH020278        10.   
    SH020278  SH020279         1.   
    SH020278  SH020282         1.   
    SH020278  SH020283         1.   
    SH020278  SH020284         1.   
    SH020278  TRSH0202         1.   
    SH020378  SH020378        10.   
    SH020378  SH020382         1.   
    SH020378  SH020383         1.   
    SH020378  TRSH0302         1.   
    SH020478  SH020478        10.   
    SH020478  SH020480         1.   
    SH020478  SH020482         1.   
    SH020478  SH020483         1.   
    SH020478  TRSH0402         1.   
    SH020578  SH020578        10.   
    SH020578  SH020582         1.   
    SH020578  SH020583         1.   
    SH020578  TRSH0502         1.   
    SH020279  SH020279        10.   
    SH020279  SH020282         1.   
    SH020279  SH020283         1.   
    SH020279  SH020284         1.   
    SH020279  TRSH0202         1.   
    SH020480  SH020480        10.   
    SH020480  SH020482         1.   
    SH020480  SH020483         1.   
    SH020480  TRSH0402         1.   
    SH020182  SH020182        10.   
    SH020182  SH020183         1.   
    SH020182  TRSH0102         1.   
    SH020282  SH020282        10.   
    SH020282  SH020283         1.   
    SH020282  SH020284         1.   
    SH020282  TRSH0202         1.   
    SH020382  SH020382        10.   
    SH020382  SH020383         1.   
    SH020382  TRSH0302         1.   
    SH020482  SH020482        10.   
    SH020482  SH020483         1.   
    SH020482  TRSH0402         1.   
    SH020582  SH020582        10.   
    SH020582  SH020583         1.   
    SH020582  TRSH0502         1.   
    SH020183  SH020183        10.   
    SH020183  TRSH0102         1.   
    SH020283  SH020283        10.   
    SH020283  SH020284         1.   
    SH020283  TRSH0202         1.   
    SH020383  SH020383        10.   
    SH020383  TRSH0302         1.   
    SH020483  SH020483        10.   
    SH020483  TRSH0402         1.   
    SH020583  SH020583        10.   
    SH020583  TRSH0502         1.   
    SH020284  SH020284        10.   
    SH020284  TRSH0202         1.   
    TRSH0101  TRSH0101        10.   
    TRSH0102  TRSH0102        10.   
    TRSH0201  TRSH0201        10.   
    TRSH0202  TRSH0202        10.   
    TRSH0301  TRSH0301        10.   
    TRSH0302  TRSH0302        10.   
    TRSH0401  TRSH0401        10.   
    TRSH0402  TRSH0402        10.   
    TRSH0501  TRSH0501        10.   
    TRSH0502  TRSH0502        10.   
    TRSH0601  TRSH0601        10.   
    TRSH0701  TRSH0701        10.   
    TRSH0801  TRSH0801        10.   
ENDATA
