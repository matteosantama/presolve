NAME          TAME      
ROWS
  N OBJ.FUNC
  E R------1
COLUMNS
    C------1  R------1  0.100000e+01
    C------2  R------1  0.100000e+01
RHS
    RHS       R------1  0.100000e+01
RANGES
BOUNDS
QUADOBJ
    C------1  C------1  0.200000e+01
    C------1  C------2  -.200000e+01
    C------2  C------2  0.200000e+01
ENDATA
