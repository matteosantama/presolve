NAME          HS21
ROWS
  N OBJ.FUNC
  G R------1
COLUMNS
    C------1  R------1  0.100000e+02
    C------2  R------1  -.100000e+01
RHS
    RHS       OBJ.FUNC  0.100000e+03
    RHS       R------1  0.100000e+02
RANGES
BOUNDS
 LO BOUNDS    C------1  0.200000e+01
 UP BOUNDS    C------1  0.500000e+02
 LO BOUNDS    C------2  -.500000e+02
 UP BOUNDS    C------2  0.500000e+02
QUADOBJ
    C------1  C------1  0.200000e-01
    C------2  C------2  0.200000e+01
ENDATA
