NAME          ETAMACRO
ROWS
 N  OPTIMALG
 E  COSTEN00
 E  COSTEN05
 E  COSTEN10
 E  COSTEN15
 E  COSTEN20
 E  COSTEN25
 E  COSTEN30
 E  COSTEN35
 E  COSTEN40
 E  COSTEN45
 E  COSTEN50
 E  COSTEN55
 E  COSTEN60
 E  COSTEN65
 E  COSTEN70
 E  COSTEN75
 E  CAPCUM05
 E  CAPCUM10
 E  CAPCUM15
 E  CAPCUM20
 E  CAPCUM25
 E  CAPCUM30
 E  CAPCUM35
 E  CAPCUM40
 E  CAPCUM45
 E  CAPCUM50
 E  CAPCUM55
 E  CAPCUM60
 E  CAPCUM65
 E  CAPCUM70
 E  CAPCUM75
 E  TERMINVR
 E  CPHYDR00
 E  CPHYDR05
 E  CPHYDR10
 E  CPHYDR15
 E  CPHYDR20
 E  CPHYDR25
 E  CPHYDR30
 E  CPHYDR35
 E  CPHYDR40
 E  CPHYDR45
 E  CPHYDR50
 E  CPHYDR55
 E  CPHYDR60
 E  CPHYDR65
 E  CPHYDR70
 E  CPHYDR75
 E  CPCOLL00
 E  CPCOLL05
 E  CPCOLL10
 E  CPCOLL15
 E  CPCOLL20
 E  CPCOLL25
 E  CPCOLL30
 E  CPCOLL35
 E  CPCOLL40
 E  CPCOLL45
 E  CPCOLL50
 E  CPCOLL55
 E  CPCOLL60
 E  CPCOLL65
 E  CPCOLL70
 E  CPCOLL75
 E  CPCOLH00
 E  CPCOLH05
 E  CPCOLH10
 E  CPCOLH15
 E  CPCOLH20
 E  CPCOLH25
 E  CPCOLH30
 E  CPCOLH35
 E  CPCOLH40
 E  CPCOLH45
 E  CPCOLH50
 E  CPCOLH55
 E  CPCOLH60
 E  CPCOLH65
 E  CPCOLH70
 E  CPCOLH75
 E  CPLWRA00
 E  CPLWRA05
 E  CPLWRA10
 E  CPLWRA15
 E  CPLWRA20
 E  CPLWRA25
 E  CPLWRA30
 E  CPLWRA35
 E  CPLWRA40
 E  CPLWRA45
 E  CPLWRA50
 E  CPLWRA55
 E  CPLWRA60
 E  CPLWRA65
 E  CPLWRA70
 E  CPLWRA75
 E  CPLWRB00
 E  CPLWRB05
 E  CPLWRB10
 E  CPLWRB15
 E  CPLWRB20
 E  CPLWRB25
 E  CPLWRB30
 E  CPLWRB35
 E  CPLWRB40
 E  CPLWRB45
 E  CPLWRB50
 E  CPLWRB55
 E  CPLWRB60
 E  CPLWRB65
 E  CPLWRB70
 E  CPLWRB75
 E  CPLWRC00
 E  CPLWRC05
 E  CPLWRC10
 E  CPLWRC15
 E  CPLWRC20
 E  CPLWRC25
 E  CPLWRC30
 E  CPLWRC35
 E  CPLWRC40
 E  CPLWRC45
 E  CPLWRC50
 E  CPLWRC55
 E  CPLWRC60
 E  CPLWRC65
 E  CPLWRC70
 E  CPLWRC75
 E  CPFBRX00
 E  CPFBRX05
 E  CPFBRX10
 E  CPFBRX15
 E  CPFBRX20
 E  CPFBRX25
 E  CPFBRX30
 E  CPFBRX35
 E  CPFBRX40
 E  CPFBRX45
 E  CPFBRX50
 E  CPFBRX55
 E  CPFBRX60
 E  CPFBRX65
 E  CPFBRX70
 E  CPFBRX75
 E  CPSOLE00
 E  CPSOLE05
 E  CPSOLE10
 E  CPSOLE15
 E  CPSOLE20
 E  CPSOLE25
 E  CPSOLE30
 E  CPSOLE35
 E  CPSOLE40
 E  CPSOLE45
 E  CPSOLE50
 E  CPSOLE55
 E  CPSOLE60
 E  CPSOLE65
 E  CPSOLE70
 E  CPSOLE75
 E  CPPETG00
 E  CPPETG05
 E  CPPETG10
 E  CPPETG15
 E  CPPETG20
 E  CPPETG25
 E  CPPETG30
 E  CPPETG35
 E  CPPETG40
 E  CPPETG45
 E  CPPETG50
 E  CPPETG55
 E  CPPETG60
 E  CPPETG65
 E  CPPETG70
 E  CPPETG75
 E  CPSYNF00
 E  CPSYNF05
 E  CPSYNF10
 E  CPSYNF15
 E  CPSYNF20
 E  CPSYNF25
 E  CPSYNF30
 E  CPSYNF35
 E  CPSYNF40
 E  CPSYNF45
 E  CPSYNF50
 E  CPSYNF55
 E  CPSYNF60
 E  CPSYNF65
 E  CPSYNF70
 E  CPSYNF75
 E  CPSHAL00
 E  CPSHAL05
 E  CPSHAL10
 E  CPSHAL15
 E  CPSHAL20
 E  CPSHAL25
 E  CPSHAL30
 E  CPSHAL35
 E  CPSHAL40
 E  CPSHAL45
 E  CPSHAL50
 E  CPSHAL55
 E  CPSHAL60
 E  CPSHAL65
 E  CPSHAL70
 E  CPSHAL75
 E  CPNAES00
 E  CPNAES05
 E  CPNAES10
 E  CPNAES15
 E  CPNAES20
 E  CPNAES25
 E  CPNAES30
 E  CPNAES35
 E  CPNAES40
 E  CPNAES45
 E  CPNAES50
 E  CPNAES55
 E  CPNAES60
 E  CPNAES65
 E  CPNAES70
 E  CPNAES75
 E  CPCLDU00
 E  CPCLDU05
 E  CPCLDU10
 E  CPCLDU15
 E  CPCLDU20
 E  CPCLDU25
 E  CPCLDU30
 E  CPCLDU35
 E  CPCLDU40
 E  CPCLDU45
 E  CPCLDU50
 E  CPCLDU55
 E  CPCLDU60
 E  CPCLDU65
 E  CPCLDU70
 E  CPCLDU75
 E  CPPGAI00
 E  CPPGAI05
 E  CPPGAI10
 E  CPPGAI15
 E  CPPGAI20
 E  CPPGAI25
 E  CPPGAI30
 E  CPPGAI35
 E  CPPGAI40
 E  CPPGAI45
 E  CPPGAI50
 E  CPPGAI55
 E  CPPGAI60
 E  CPPGAI65
 E  CPPGAI70
 E  CPPGAI75
 G  RQELEC00
 G  RQELEC05
 G  RQELEC10
 G  RQELEC15
 G  RQELEC20
 G  RQELEC25
 G  RQELEC30
 G  RQELEC35
 G  RQELEC40
 G  RQELEC45
 G  RQELEC50
 G  RQELEC55
 G  RQELEC60
 G  RQELEC65
 G  RQELEC70
 G  RQELEC75
 G  RQNELE00
 G  RQNELE05
 G  RQNELE10
 G  RQNELE15
 G  RQNELE20
 G  RQNELE25
 G  RQNELE30
 G  RQNELE35
 G  RQNELE40
 G  RQNELE45
 G  RQNELE50
 G  RQNELE55
 G  RQNELE60
 G  RQNELE65
 G  RQNELE70
 G  RQNELE75
 G  RQPETG00
 G  RQPETG05
 G  RQPETG10
 G  RQPETG15
 G  RQPETG20
 G  RQPETG25
 G  RQPETG30
 G  RQPETG35
 G  RQPETG40
 G  RQPETG45
 G  RQPETG50
 G  RQPETG55
 G  RQPETG60
 G  RQPETG65
 G  RQPETG70
 G  RQPETG75
 G  RQCOAL00
 G  RQCOAL05
 G  RQCOAL10
 G  RQCOAL15
 G  RQCOAL20
 G  RQCOAL25
 G  RQCOAL30
 G  RQCOAL35
 G  RQCOAL40
 G  RQCOAL45
 G  RQCOAL50
 G  RQCOAL55
 G  RQCOAL60
 G  RQCOAL65
 G  RQCOAL70
 G  RQCOAL75
 G  RQNATU00
 G  RQNATU05
 G  RQNATU10
 G  RQNATU15
 G  RQNATU20
 G  RQNATU25
 G  RQNATU30
 G  RQNATU35
 G  RQNATU40
 G  RQNATU45
 G  RQNATU50
 G  RQNATU55
 G  RQNATU60
 G  RQNATU65
 G  RQNATU70
 G  RQNATU75
 L  AVPETG01
 L  AVPETG02
 L  AVPETG03
 L  AVPETG04
 L  AVCOAL01
 L  AVNATU01
 L  AVNATU02
 L  AVNATU03
 E  SMPLUT00
 E  SMPLUT05
 E  SMPLUT10
 E  SMPLUT15
 E  SMPLUT20
 E  SMPLUT25
 E  SMPLUT30
 E  SMPLUT35
 E  SMPLUT40
 E  SMPLUT45
 E  SMPLUT50
 E  SMPLUT55
 E  SMPLUT60
 E  SMPLUT65
 E  SMPLUT70
 E  SMPLUT75
 L  CLTOTL00
 L  CLTOTL05
 L  CLTOTL10
 L  CLTOTL15
 L  CLTOTL20
 L  CLTOTL25
 L  CLTOTL30
 L  CLTOTL35
 L  CLTOTL40
 L  CLTOTL45
 L  CLTOTL50
 L  CLTOTL55
 L  CLTOTL60
 L  CLTOTL65
 L  CLTOTL70
 L  CLTOTL75
 L  CLDLOC00
 L  CLDLOC05
 L  CLDLOC10
 L  CLDLOC15
 L  CLDLOC20
 L  CLDLOC25
 L  CLDLOC30
 L  CLDLOC35
 L  CLDLOC40
 L  CLDLOC45
 L  CLDLOC50
 L  CLDLOC55
 L  CLDLOC60
 L  CLDLOC65
 L  CLDLOC70
 L  CLDLOC75
 L  CLDMIN05
 L  CLDMIN10
 L  CLDMIN15
 L  CLDMIN20
 L  CLDMIN25
 L  CLDMIN30
 L  CLDMIN35
 L  CLDMIN40
COLUMNS
    KAPSTK00  CAPCUM05       -.81537   OPTIMALG     -104.5461
    KAPSTK05  CAPCUM05            1.   CAPCUM10       -.81537
    KAPSTK05  OPTIMALG     -60.56045
    KAPSTK10  CAPCUM10            1.   CAPCUM15       -.81537
    KAPSTK10  OPTIMALG     -29.82791
    KAPSTK15  CAPCUM15            1.   CAPCUM20       -.81537
    KAPSTK15  OPTIMALG     -15.59659
    KAPSTK20  CAPCUM20            1.   CAPCUM25       -.81537
    KAPSTK20  OPTIMALG     -8.176666
    KAPSTK25  CAPCUM25            1.   CAPCUM30       -.81537
    KAPSTK25  OPTIMALG     -4.472406
    KAPSTK30  CAPCUM30            1.   CAPCUM35       -.81537
    KAPSTK30  OPTIMALG     -2.317474
    KAPSTK35  CAPCUM35            1.   CAPCUM40       -.81537
    KAPSTK35  OPTIMALG     -1.338065
    KAPSTK40  CAPCUM40            1.   CAPCUM45       -.81537
    KAPSTK40  OPTIMALG     -.7491833
    KAPSTK45  CAPCUM45            1.   CAPCUM50       -.81537
    KAPSTK45  OPTIMALG     -.4393485
    KAPSTK50  CAPCUM50            1.   CAPCUM55       -.81537
    KAPSTK50  OPTIMALG      -.254652
    KAPSTK55  CAPCUM55            1.   CAPCUM60       -.81537
    KAPSTK55  OPTIMALG     -.1394811
    KAPSTK60  CAPCUM60            1.   CAPCUM65       -.81537
    KAPSTK60  OPTIMALG     -.0780368
    KAPSTK65  CAPCUM65            1.   CAPCUM70       -.81537
    KAPSTK65  OPTIMALG    -.04377537
    KAPSTK70  CAPCUM70            1.   CAPCUM75       -.81537
    KAPSTK70  OPTIMALG    -.02500909
    KAPSTK75  CAPCUM75            1.   TERMINVR          -.06
    KAPSTK75  OPTIMALG    -.03763857
    DMELEC00  RQELEC00           -1.   OPTIMALG     -29.16897
    DMELEC05  RQELEC05           -1.   OPTIMALG     -9.069968
    DMELEC10  RQELEC10           -1.   OPTIMALG     -4.733381
    DMELEC15  RQELEC15           -1.   OPTIMALG      -2.57794
    DMELEC20  RQELEC20           -1.   OPTIMALG     -1.579128
    DMELEC25  RQELEC25           -1.   OPTIMALG     -.8243589
    DMELEC30  RQELEC30           -1.   OPTIMALG      -.631751
    DMELEC35  RQELEC35           -1.   OPTIMALG     -.3725165
    DMELEC40  RQELEC40           -1.   OPTIMALG     -.2635078
    DMELEC45  RQELEC45           -1.   OPTIMALG     -.1540412
    DMELEC50  RQELEC50           -1.   OPTIMALG    -.07771059
    DMELEC55  RQELEC55           -1.   OPTIMALG     -.0464996
    DMELEC60  RQELEC60           -1.   OPTIMALG    -.02785415
    DMELEC65  RQELEC65           -1.   OPTIMALG    -.01691288
    DMELEC70  RQELEC70           -1.   OPTIMALG   -.008335737
    DMELEC75  RQELEC75           -1.   OPTIMALG    -.01174766
    DMNELE00  RQNELE00         -100.   OPTIMALG     -298.6542
    DMNELE05  RQNELE05         -100.   OPTIMALG     -96.14105
    DMNELE10  RQNELE10         -100.   OPTIMALG     -55.56762
    DMNELE15  RQNELE15         -100.   OPTIMALG     -35.50668
    DMNELE20  RQNELE20         -100.   OPTIMALG     -22.72739
    DMNELE25  RQNELE25         -100.   OPTIMALG     -14.82636
    DMNELE30  RQNELE30         -100.   OPTIMALG     -14.66947
    DMNELE35  RQNELE35         -100.   OPTIMALG     -9.545957
    DMNELE40  RQNELE40         -100.   OPTIMALG     -5.839098
    DMNELE45  RQNELE45         -100.   OPTIMALG     -2.843908
    DMNELE50  RQNELE50         -100.   OPTIMALG     -1.164393
    DMNELE55  RQNELE55         -100.   OPTIMALG     -.6352673
    DMNELE60  RQNELE60         -100.   OPTIMALG     -.3563501
    DMNELE65  RQNELE65         -100.   OPTIMALG     -.2003427
    DMNELE70  RQNELE70         -100.   OPTIMALG     -.1122633
    DMNELE75  RQNELE75         -100.   OPTIMALG     -.1696787
    INVEST00  CAPCUM05           -2.   OPTIMALG      779.5896
    INVEST05  CAPCUM05           -3.   CAPCUM10           -2.
    INVEST05  OPTIMALG      414.3375
    INVEST10  CAPCUM10           -3.   CAPCUM15           -2.
    INVEST10  OPTIMALG       212.174
    INVEST15  CAPCUM15           -3.   CAPCUM20           -2.
    INVEST15  OPTIMALG      112.2154
    INVEST20  CAPCUM20           -3.   CAPCUM25           -2.
    INVEST20  OPTIMALG      60.18409
    INVEST25  CAPCUM25           -3.   CAPCUM30           -2.
    INVEST25  OPTIMALG      32.75725
    INVEST30  CAPCUM30           -3.   CAPCUM35           -2.
    INVEST30  OPTIMALG      18.03486
    INVEST35  CAPCUM35           -3.   CAPCUM40           -2.
    INVEST35  OPTIMALG      10.30981
    INVEST40  CAPCUM40           -3.   CAPCUM45           -2.
    INVEST40  OPTIMALG      5.883518
    INVEST45  CAPCUM45           -3.   CAPCUM50           -2.
    INVEST45  OPTIMALG       3.38162
    INVEST50  CAPCUM50           -3.   CAPCUM55           -2.
    INVEST50  OPTIMALG      1.906215
    INVEST55  CAPCUM55           -3.   CAPCUM60           -2.
    INVEST55  OPTIMALG      1.058779
    INVEST60  CAPCUM60           -3.   CAPCUM65           -2.
    INVEST60  OPTIMALG      .5939169
    INVEST65  CAPCUM65           -3.   CAPCUM70           -2.
    INVEST65  OPTIMALG      .3339045
    INVEST70  CAPCUM70           -3.   CAPCUM75           -2.
    INVEST70  OPTIMALG      .1871056
    INVEST75  CAPCUM75           -3.   TERMINVR            1.
    INVEST75  OPTIMALG      .2827978
    ENCOST00  COSTEN00        -1000.   OPTIMALG      779.5896
    ENCOST05  COSTEN05        -1000.   OPTIMALG      414.3375
    ENCOST10  COSTEN10        -1000.   OPTIMALG       212.174
    ENCOST15  COSTEN15        -1000.   OPTIMALG      112.2154
    ENCOST20  COSTEN20        -1000.   OPTIMALG      60.18409
    ENCOST25  COSTEN25        -1000.   OPTIMALG      32.75725
    ENCOST30  COSTEN30        -1000.   OPTIMALG      18.03486
    ENCOST35  COSTEN35        -1000.   OPTIMALG      10.30981
    ENCOST40  COSTEN40        -1000.   OPTIMALG      5.883518
    ENCOST45  COSTEN45        -1000.   OPTIMALG       3.38162
    ENCOST50  COSTEN50        -1000.   OPTIMALG      1.906215
    ENCOST55  COSTEN55        -1000.   OPTIMALG      1.058779
    ENCOST60  COSTEN60        -1000.   OPTIMALG      .5939169
    ENCOST65  COSTEN65        -1000.   OPTIMALG      .3339045
    ENCOST70  COSTEN70        -1000.   OPTIMALG      .1871056
    ENCOST75  COSTEN75        -1000.   OPTIMALG      .2827978
    PCHYDR00  COSTEN00           22.   CPHYDR00            1.
    PCHYDR00  CPHYDR05           -1.   RQELEC00            1.
    PCHYDR05  COSTEN05           22.   CPHYDR05            1.
    PCHYDR05  CPHYDR10           -1.   RQELEC05            1.
    PCHYDR10  COSTEN10           22.   CPHYDR10            1.
    PCHYDR10  CPHYDR15           -1.   RQELEC10            1.
    PCHYDR15  COSTEN15           22.   CPHYDR15            1.
    PCHYDR15  CPHYDR20           -1.   RQELEC15            1.
    PCHYDR20  COSTEN20           22.   CPHYDR20            1.
    PCHYDR20  CPHYDR25           -1.   RQELEC20            1.
    PCHYDR25  COSTEN25           22.   CPHYDR25            1.
    PCHYDR25  CPHYDR30           -1.   RQELEC25            1.
    PCHYDR30  COSTEN30           22.   CPHYDR30            1.
    PCHYDR30  CPHYDR35           -1.   RQELEC30            1.
    PCHYDR35  COSTEN35           22.   CPHYDR35            1.
    PCHYDR35  CPHYDR40           -1.   RQELEC35            1.
    PCHYDR40  COSTEN40           22.   CPHYDR40            1.
    PCHYDR40  CPHYDR45           -1.   RQELEC40            1.
    PCHYDR45  COSTEN45           22.   CPHYDR45            1.
    PCHYDR45  CPHYDR50           -1.   RQELEC45            1.
    PCHYDR50  COSTEN50           22.   CPHYDR50            1.
    PCHYDR50  CPHYDR55           -1.   RQELEC50            1.
    PCHYDR55  COSTEN55           22.   CPHYDR55            1.
    PCHYDR55  CPHYDR60           -1.   RQELEC55            1.
    PCHYDR60  COSTEN60           22.   CPHYDR60            1.
    PCHYDR60  CPHYDR65           -1.   RQELEC60            1.
    PCHYDR65  COSTEN65           22.   CPHYDR65            1.
    PCHYDR65  CPHYDR70           -1.   RQELEC65            1.
    PCHYDR70  COSTEN70           22.   CPHYDR70            1.
    PCHYDR70  CPHYDR75           -1.   RQELEC70            1.
    PCHYDR75  COSTEN75           22.   CPHYDR75            1.
    PCHYDR75  RQELEC75            1.
    PCRFOS00  COSTEN00            2.   RQELEC00            1.
    PCRFOS00  RQPETG00          -4.2   RQCOAL00          -5.8
    PCRFOS00  CLTOTL00           5.8
    PCRFOS05  COSTEN05            2.   RQELEC05            1.
    PCRFOS05  RQPETG05          -4.2   RQCOAL05          -5.8
    PCRFOS05  CLTOTL05           5.8
    PCRFOS10  COSTEN10            2.   RQELEC10            1.
    PCRFOS10  RQPETG10          -4.2   RQCOAL10          -5.8
    PCRFOS10  CLTOTL10           5.8
    PCRFOS15  COSTEN15            2.   RQELEC15            1.
    PCRFOS15  RQPETG15          -4.2   RQCOAL15          -5.8
    PCRFOS15  CLTOTL15           5.8
    PCRFOS20  COSTEN20            2.   RQELEC20            1.
    PCRFOS20  RQPETG20          -4.2   RQCOAL20          -5.8
    PCRFOS20  CLTOTL20           5.8
    PCRFOS25  COSTEN25            2.   RQELEC25            1.
    PCRFOS25  RQPETG25          -4.2   RQCOAL25          -5.8
    PCRFOS25  CLTOTL25           5.8
    PCRFOS30  COSTEN30            2.   RQELEC30            1.
    PCRFOS30  RQPETG30          -4.2   RQCOAL30          -5.8
    PCRFOS30  CLTOTL30           5.8
    PCRFOS35  COSTEN35            2.   RQELEC35            1.
    PCRFOS35  RQPETG35          -4.2   RQCOAL35          -5.8
    PCRFOS35  CLTOTL35           5.8
    PCRFOS40  COSTEN40            2.   RQELEC40            1.
    PCRFOS40  RQPETG40          -4.2   RQCOAL40          -5.8
    PCRFOS40  CLTOTL40           5.8
    PCRFOS45  COSTEN45            2.   RQELEC45            1.
    PCRFOS45  RQPETG45          -4.2   RQCOAL45          -5.8
    PCRFOS45  CLTOTL45           5.8
    PCRFOS50  COSTEN50            2.   RQELEC50            1.
    PCRFOS50  RQPETG50          -4.2   RQCOAL50          -5.8
    PCRFOS50  CLTOTL50           5.8
    PCRFOS55  COSTEN55            2.   RQELEC55            1.
    PCRFOS55  RQPETG55          -4.2   RQCOAL55          -5.8
    PCRFOS55  CLTOTL55           5.8
    PCRFOS60  COSTEN60            2.   RQELEC60            1.
    PCRFOS60  RQPETG60          -4.2   RQCOAL60          -5.8
    PCRFOS60  CLTOTL60           5.8
    PCRFOS65  COSTEN65            2.   RQELEC65            1.
    PCRFOS65  RQPETG65          -4.2   RQCOAL65          -5.8
    PCRFOS65  CLTOTL65           5.8
    PCRFOS70  COSTEN70            2.   RQELEC70            1.
    PCRFOS70  RQPETG70          -4.2   RQCOAL70          -5.8
    PCRFOS70  CLTOTL70           5.8
    PCRFOS75  COSTEN75            2.   RQELEC75            1.
    PCRFOS75  RQPETG75          -4.2   RQCOAL75          -5.8
    PCRFOS75  CLTOTL75           5.8
    PCCOLL00  COSTEN00          13.6   CPCOLL00            1.
    PCCOLL00  CPCOLL05           -1.   RQELEC00            1.
    PCCOLL00  RQCOAL00          -10.   CLTOTL00           10.
    PCCOLL05  COSTEN05          13.6   CPCOLL05            1.
    PCCOLL05  CPCOLL10           -1.   RQELEC05            1.
    PCCOLL05  RQCOAL05          -10.   CLTOTL05           10.
    PCCOLL10  COSTEN10          13.6   CPCOLL10            1.
    PCCOLL10  CPCOLL15           -1.   RQELEC10            1.
    PCCOLL10  RQCOAL10          -10.   CLTOTL10           10.
    PCCOLL15  COSTEN15          13.6   CPCOLL15            1.
    PCCOLL15  CPCOLL20           -1.   RQELEC15            1.
    PCCOLL15  RQCOAL15          -10.   CLTOTL15           10.
    PCCOLL20  COSTEN20          13.6   CPCOLL20            1.
    PCCOLL20  CPCOLL25           -1.   RQELEC20            1.
    PCCOLL20  RQCOAL20          -10.   CLTOTL20           10.
    PCCOLL25  COSTEN25          13.6   CPCOLL25            1.
    PCCOLL25  CPCOLL30           -1.   RQELEC25            1.
    PCCOLL25  RQCOAL25          -10.   CLTOTL25           10.
    PCCOLL30  COSTEN30          13.6   CPCOLL30            1.
    PCCOLL30  CPCOLL35           -1.   RQELEC30            1.
    PCCOLL30  RQCOAL30          -10.   CLTOTL30           10.
    PCCOLL35  COSTEN35          13.6   CPCOLL35            1.
    PCCOLL35  CPCOLL40           -1.   RQELEC35            1.
    PCCOLL35  RQCOAL35          -10.   CLTOTL35           10.
    PCCOLL40  COSTEN40          13.6   CPCOLL40            1.
    PCCOLL40  CPCOLL45           -1.   RQELEC40            1.
    PCCOLL40  RQCOAL40          -10.   CLTOTL40           10.
    PCCOLL45  COSTEN45          13.6   CPCOLL45            1.
    PCCOLL45  CPCOLL50           -1.   RQELEC45            1.
    PCCOLL45  RQCOAL45          -10.   CLTOTL45           10.
    PCCOLL50  COSTEN50          13.6   CPCOLL50            1.
    PCCOLL50  CPCOLL55           -1.   RQELEC50            1.
    PCCOLL50  RQCOAL50          -10.   CLTOTL50           10.
    PCCOLL55  COSTEN55          13.6   CPCOLL55            1.
    PCCOLL55  CPCOLL60           -1.   RQELEC55            1.
    PCCOLL55  RQCOAL55          -10.   CLTOTL55           10.
    PCCOLL60  COSTEN60          13.6   CPCOLL60            1.
    PCCOLL60  CPCOLL65           -1.   RQELEC60            1.
    PCCOLL60  RQCOAL60          -10.   CLTOTL60           10.
    PCCOLL65  COSTEN65          13.6   CPCOLL65            1.
    PCCOLL65  CPCOLL70           -1.   RQELEC65            1.
    PCCOLL65  RQCOAL65          -10.   CLTOTL65           10.
    PCCOLL70  COSTEN70          13.6   CPCOLL70            1.
    PCCOLL70  CPCOLL75           -1.   RQELEC70            1.
    PCCOLL70  RQCOAL70          -10.   CLTOTL70           10.
    PCCOLL75  COSTEN75          13.6   CPCOLL75            1.
    PCCOLL75  RQELEC75            1.   RQCOAL75          -10.
    PCCOLL75  CLTOTL75           10.
    PCCOLH00  COSTEN00      17.60001   CPCOLH00            1.
    PCCOLH00  CPCOLH05           -1.   RQELEC00            1.
    PCCOLH00  RQCOAL00          -10.   CLTOTL00           10.
    PCCOLH05  COSTEN05      17.60001   CPCOLH05            1.
    PCCOLH05  CPCOLH10           -1.   RQELEC05            1.
    PCCOLH05  RQCOAL05          -10.   CLTOTL05           10.
    PCCOLH10  COSTEN10      17.60001   CPCOLH10            1.
    PCCOLH10  CPCOLH15           -1.   RQELEC10            1.
    PCCOLH10  RQCOAL10          -10.   CLTOTL10           10.
    PCCOLH15  COSTEN15      17.60001   CPCOLH15            1.
    PCCOLH15  CPCOLH20           -1.   RQELEC15            1.
    PCCOLH15  RQCOAL15          -10.   CLTOTL15           10.
    PCCOLH20  COSTEN20      17.60001   CPCOLH20            1.
    PCCOLH20  CPCOLH25           -1.   RQELEC20            1.
    PCCOLH20  RQCOAL20          -10.   CLTOTL20           10.
    PCCOLH25  COSTEN25      17.60001   CPCOLH25            1.
    PCCOLH25  CPCOLH30           -1.   RQELEC25            1.
    PCCOLH25  RQCOAL25          -10.   CLTOTL25           10.
    PCCOLH30  COSTEN30      17.60001   CPCOLH30            1.
    PCCOLH30  CPCOLH35           -1.   RQELEC30            1.
    PCCOLH30  RQCOAL30          -10.   CLTOTL30           10.
    PCCOLH35  COSTEN35      17.60001   CPCOLH35            1.
    PCCOLH35  CPCOLH40           -1.   RQELEC35            1.
    PCCOLH35  RQCOAL35          -10.   CLTOTL35           10.
    PCCOLH40  COSTEN40      17.60001   CPCOLH40            1.
    PCCOLH40  CPCOLH45           -1.   RQELEC40            1.
    PCCOLH40  RQCOAL40          -10.   CLTOTL40           10.
    PCCOLH45  COSTEN45      17.60001   CPCOLH45            1.
    PCCOLH45  CPCOLH50           -1.   RQELEC45            1.
    PCCOLH45  RQCOAL45          -10.   CLTOTL45           10.
    PCCOLH50  COSTEN50      17.60001   CPCOLH50            1.
    PCCOLH50  CPCOLH55           -1.   RQELEC50            1.
    PCCOLH50  RQCOAL50          -10.   CLTOTL50           10.
    PCCOLH55  COSTEN55      17.60001   CPCOLH55            1.
    PCCOLH55  CPCOLH60           -1.   RQELEC55            1.
    PCCOLH55  RQCOAL55          -10.   CLTOTL55           10.
    PCCOLH60  COSTEN60      17.60001   CPCOLH60            1.
    PCCOLH60  CPCOLH65           -1.   RQELEC60            1.
    PCCOLH60  RQCOAL60          -10.   CLTOTL60           10.
    PCCOLH65  COSTEN65      17.60001   CPCOLH65            1.
    PCCOLH65  CPCOLH70           -1.   RQELEC65            1.
    PCCOLH65  RQCOAL65          -10.   CLTOTL65           10.
    PCCOLH70  COSTEN70      17.60001   CPCOLH70            1.
    PCCOLH70  CPCOLH75           -1.   RQELEC70            1.
    PCCOLH70  RQCOAL70          -10.   CLTOTL70           10.
    PCCOLH75  COSTEN75      17.60001   CPCOLH75            1.
    PCCOLH75  RQELEC75            1.   RQCOAL75          -10.
    PCCOLH75  CLTOTL75           10.
    PCLWRA00  COSTEN00          19.8   CPLWRA00            1.
    PCLWRA00  CPLWRA05           -1.   RQELEC00            1.
    PCLWRA00  RQNATU00         -.029
    PCLWRA05  COSTEN05          19.8   CPLWRA05            1.
    PCLWRA05  CPLWRA10           -1.   RQELEC05            1.
    PCLWRA05  RQNATU05         -.029
    PCLWRA10  COSTEN10          19.8   CPLWRA10            1.
    PCLWRA10  CPLWRA15           -1.   RQELEC10            1.
    PCLWRA10  RQNATU10         -.029
    PCLWRA15  COSTEN15          19.8   CPLWRA15            1.
    PCLWRA15  CPLWRA20           -1.   RQELEC15            1.
    PCLWRA15  RQNATU15         -.029
    PCLWRA20  COSTEN20          19.8   CPLWRA20            1.
    PCLWRA20  CPLWRA25           -1.   RQELEC20            1.
    PCLWRA20  RQNATU20         -.029
    PCLWRA25  COSTEN25          19.8   CPLWRA25            1.
    PCLWRA25  CPLWRA30           -1.   RQELEC25            1.
    PCLWRA25  RQNATU25         -.029
    PCLWRA30  COSTEN30          19.8   CPLWRA30            1.
    PCLWRA30  CPLWRA35           -1.   RQELEC30            1.
    PCLWRA30  RQNATU30         -.029
    PCLWRA35  COSTEN35          19.8   CPLWRA35            1.
    PCLWRA35  CPLWRA40           -1.   RQELEC35            1.
    PCLWRA35  RQNATU35         -.029
    PCLWRA40  COSTEN40          19.8   CPLWRA40            1.
    PCLWRA40  CPLWRA45           -1.   RQELEC40            1.
    PCLWRA40  RQNATU40         -.029
    PCLWRA45  COSTEN45          19.8   CPLWRA45            1.
    PCLWRA45  CPLWRA50           -1.   RQELEC45            1.
    PCLWRA45  RQNATU45         -.029
    PCLWRA50  COSTEN50          19.8   CPLWRA50            1.
    PCLWRA50  CPLWRA55           -1.   RQELEC50            1.
    PCLWRA50  RQNATU50         -.029
    PCLWRA55  COSTEN55          19.8   CPLWRA55            1.
    PCLWRA55  CPLWRA60           -1.   RQELEC55            1.
    PCLWRA55  RQNATU55         -.029
    PCLWRA60  COSTEN60          19.8   CPLWRA60            1.
    PCLWRA60  CPLWRA65           -1.   RQELEC60            1.
    PCLWRA60  RQNATU60         -.029
    PCLWRA65  COSTEN65          19.8   CPLWRA65            1.
    PCLWRA65  CPLWRA70           -1.   RQELEC65            1.
    PCLWRA65  RQNATU65         -.029
    PCLWRA70  COSTEN70          19.8   CPLWRA70            1.
    PCLWRA70  CPLWRA75           -1.   RQELEC70            1.
    PCLWRA70  RQNATU70         -.029
    PCLWRA75  COSTEN75          19.8   CPLWRA75            1.
    PCLWRA75  RQELEC75            1.   RQNATU75         -.029
    PCLWRB00  COSTEN00      20.10001   CPLWRB00            1.
    PCLWRB00  CPLWRB05           -1.   RQELEC00            1.
    PCLWRB00  RQNATU00        -.0227   SMPLUT05         -.027
    PCLWRB05  COSTEN05      20.10001   CPLWRB05            1.
    PCLWRB05  CPLWRB10           -1.   RQELEC05            1.
    PCLWRB05  RQNATU05        -.0227   SMPLUT10         -.027
    PCLWRB10  COSTEN10      20.10001   CPLWRB10            1.
    PCLWRB10  CPLWRB15           -1.   RQELEC10            1.
    PCLWRB10  RQNATU10        -.0227   SMPLUT15         -.027
    PCLWRB15  COSTEN15      20.10001   CPLWRB15            1.
    PCLWRB15  CPLWRB20           -1.   RQELEC15            1.
    PCLWRB15  RQNATU15        -.0227   SMPLUT20         -.027
    PCLWRB20  COSTEN20      20.10001   CPLWRB20            1.
    PCLWRB20  CPLWRB25           -1.   RQELEC20            1.
    PCLWRB20  RQNATU20        -.0227   SMPLUT25         -.027
    PCLWRB25  COSTEN25      20.10001   CPLWRB25            1.
    PCLWRB25  CPLWRB30           -1.   RQELEC25            1.
    PCLWRB25  RQNATU25        -.0227   SMPLUT30         -.027
    PCLWRB30  COSTEN30      20.10001   CPLWRB30            1.
    PCLWRB30  CPLWRB35           -1.   RQELEC30            1.
    PCLWRB30  RQNATU30        -.0227   SMPLUT35         -.027
    PCLWRB35  COSTEN35      20.10001   CPLWRB35            1.
    PCLWRB35  CPLWRB40           -1.   RQELEC35            1.
    PCLWRB35  RQNATU35        -.0227   SMPLUT40         -.027
    PCLWRB40  COSTEN40      20.10001   CPLWRB40            1.
    PCLWRB40  CPLWRB45           -1.   RQELEC40            1.
    PCLWRB40  RQNATU40        -.0227   SMPLUT45         -.027
    PCLWRB45  COSTEN45      20.10001   CPLWRB45            1.
    PCLWRB45  CPLWRB50           -1.   RQELEC45            1.
    PCLWRB45  RQNATU45        -.0227   SMPLUT50         -.027
    PCLWRB50  COSTEN50      20.10001   CPLWRB50            1.
    PCLWRB50  CPLWRB55           -1.   RQELEC50            1.
    PCLWRB50  RQNATU50        -.0227   SMPLUT55         -.027
    PCLWRB55  COSTEN55      20.10001   CPLWRB55            1.
    PCLWRB55  CPLWRB60           -1.   RQELEC55            1.
    PCLWRB55  RQNATU55        -.0227   SMPLUT60         -.027
    PCLWRB60  COSTEN60      20.10001   CPLWRB60            1.
    PCLWRB60  CPLWRB65           -1.   RQELEC60            1.
    PCLWRB60  RQNATU60        -.0227   SMPLUT65         -.027
    PCLWRB65  COSTEN65      20.10001   CPLWRB65            1.
    PCLWRB65  CPLWRB70           -1.   RQELEC65            1.
    PCLWRB65  RQNATU65        -.0227   SMPLUT70         -.027
    PCLWRB70  COSTEN70      20.10001   CPLWRB70            1.
    PCLWRB70  CPLWRB75           -1.   RQELEC70            1.
    PCLWRB70  RQNATU70        -.0227   SMPLUT75         -.027
    PCLWRB75  COSTEN75      20.10001   CPLWRB75            1.
    PCLWRB75  RQELEC75            1.   RQNATU75        -.0227
    PCLWRC00  COSTEN00          20.3   CPLWRC00            1.
    PCLWRC00  CPLWRC05           -1.   RQELEC00            1.
    PCLWRC00  RQNATU00         -.019
    PCLWRC05  COSTEN05          20.3   CPLWRC05            1.
    PCLWRC05  CPLWRC10           -1.   RQELEC05            1.
    PCLWRC05  RQNATU05         -.019
    PCLWRC10  COSTEN10          20.3   CPLWRC10            1.
    PCLWRC10  CPLWRC15           -1.   RQELEC10            1.
    PCLWRC10  RQNATU10         -.019
    PCLWRC15  COSTEN15          20.3   CPLWRC15            1.
    PCLWRC15  CPLWRC20           -1.   RQELEC15            1.
    PCLWRC15  RQNATU15         -.019
    PCLWRC20  COSTEN20          20.3   CPLWRC20            1.
    PCLWRC20  CPLWRC25           -1.   RQELEC20            1.
    PCLWRC20  RQNATU20         -.019
    PCLWRC25  COSTEN25          20.3   CPLWRC25            1.
    PCLWRC25  CPLWRC30           -1.   RQELEC25            1.
    PCLWRC25  RQNATU25         -.019
    PCLWRC30  COSTEN30          20.3   CPLWRC30            1.
    PCLWRC30  CPLWRC35           -1.   RQELEC30            1.
    PCLWRC30  RQNATU30         -.019
    PCLWRC35  COSTEN35          20.3   CPLWRC35            1.
    PCLWRC35  CPLWRC40           -1.   RQELEC35            1.
    PCLWRC35  RQNATU35         -.019
    PCLWRC40  COSTEN40          20.3   CPLWRC40            1.
    PCLWRC40  CPLWRC45           -1.   RQELEC40            1.
    PCLWRC40  RQNATU40         -.019
    PCLWRC45  COSTEN45          20.3   CPLWRC45            1.
    PCLWRC45  CPLWRC50           -1.   RQELEC45            1.
    PCLWRC45  RQNATU45         -.019
    PCLWRC50  COSTEN50          20.3   CPLWRC50            1.
    PCLWRC50  CPLWRC55           -1.   RQELEC50            1.
    PCLWRC50  RQNATU50         -.019
    PCLWRC55  COSTEN55          20.3   CPLWRC55            1.
    PCLWRC55  CPLWRC60           -1.   RQELEC55            1.
    PCLWRC55  RQNATU55         -.019
    PCLWRC60  COSTEN60          20.3   CPLWRC60            1.
    PCLWRC60  CPLWRC65           -1.   RQELEC60            1.
    PCLWRC60  RQNATU60         -.019
    PCLWRC65  COSTEN65          20.3   CPLWRC65            1.
    PCLWRC65  CPLWRC70           -1.   RQELEC65            1.
    PCLWRC65  RQNATU65         -.019
    PCLWRC70  COSTEN70          20.3   CPLWRC70            1.
    PCLWRC70  CPLWRC75           -1.   RQELEC70            1.
    PCLWRC70  RQNATU70         -.019
    PCLWRC75  COSTEN75          20.3   CPLWRC75            1.
    PCLWRC75  RQELEC75            1.   RQNATU75         -.019
    PCFBRX00  COSTEN00      25.10001   CPFBRX00            1.
    PCFBRX00  CPFBRX05           -1.   RQELEC00            1.
    PCFBRX00  SMPLUT05         -.053
    PCFBRX05  COSTEN05      25.10001   CPFBRX05            1.
    PCFBRX05  CPFBRX10           -1.   RQELEC05            1.
    PCFBRX05  SMPLUT10         -.053
    PCFBRX10  COSTEN10      25.10001   CPFBRX10            1.
    PCFBRX10  CPFBRX15           -1.   RQELEC10            1.
    PCFBRX10  SMPLUT15         -.053
    PCFBRX15  COSTEN15      25.10001   CPFBRX15            1.
    PCFBRX15  CPFBRX20           -1.   RQELEC15            1.
    PCFBRX15  SMPLUT20         -.053
    PCFBRX20  COSTEN20      25.10001   CPFBRX20            1.
    PCFBRX20  CPFBRX25           -1.   RQELEC20            1.
    PCFBRX20  SMPLUT25         -.053
    PCFBRX25  COSTEN25      25.10001   CPFBRX25            1.
    PCFBRX25  CPFBRX30           -1.   RQELEC25            1.
    PCFBRX25  SMPLUT30         -.053
    PCFBRX30  COSTEN30      25.10001   CPFBRX30            1.
    PCFBRX30  CPFBRX35           -1.   RQELEC30            1.
    PCFBRX30  SMPLUT35         -.053
    PCFBRX35  COSTEN35      25.10001   CPFBRX35            1.
    PCFBRX35  CPFBRX40           -1.   RQELEC35            1.
    PCFBRX35  SMPLUT40         -.053
    PCFBRX40  COSTEN40      25.10001   CPFBRX40            1.
    PCFBRX40  CPFBRX45           -1.   RQELEC40            1.
    PCFBRX40  SMPLUT45         -.053
    PCFBRX45  COSTEN45      25.10001   CPFBRX45            1.
    PCFBRX45  CPFBRX50           -1.   RQELEC45            1.
    PCFBRX45  SMPLUT50         -.053
    PCFBRX50  COSTEN50      25.10001   CPFBRX50            1.
    PCFBRX50  CPFBRX55           -1.   RQELEC50            1.
    PCFBRX50  SMPLUT55         -.053
    PCFBRX55  COSTEN55      25.10001   CPFBRX55            1.
    PCFBRX55  CPFBRX60           -1.   RQELEC55            1.
    PCFBRX55  SMPLUT60         -.053
    PCFBRX60  COSTEN60      25.10001   CPFBRX60            1.
    PCFBRX60  CPFBRX65           -1.   RQELEC60            1.
    PCFBRX60  SMPLUT65         -.053
    PCFBRX65  COSTEN65      25.10001   CPFBRX65            1.
    PCFBRX65  CPFBRX70           -1.   RQELEC65            1.
    PCFBRX65  SMPLUT70         -.053
    PCFBRX70  COSTEN70      25.10001   CPFBRX70            1.
    PCFBRX70  CPFBRX75           -1.   RQELEC70            1.
    PCFBRX70  SMPLUT75         -.053
    PCFBRX75  COSTEN75      25.10001   CPFBRX75            1.
    PCFBRX75  RQELEC75            1.
    PCSOLE00  COSTEN00          54.8   CPSOLE00            1.
    PCSOLE00  CPSOLE05           -1.   RQELEC00            1.
    PCSOLE05  COSTEN05          54.8   CPSOLE05            1.
    PCSOLE05  CPSOLE10           -1.   RQELEC05            1.
    PCSOLE10  COSTEN10          54.8   CPSOLE10            1.
    PCSOLE10  CPSOLE15           -1.   RQELEC10            1.
    PCSOLE15  COSTEN15          54.8   CPSOLE15            1.
    PCSOLE15  CPSOLE20           -1.   RQELEC15            1.
    PCSOLE20  COSTEN20          54.8   CPSOLE20            1.
    PCSOLE20  CPSOLE25           -1.   RQELEC20            1.
    PCSOLE25  COSTEN25          54.8   CPSOLE25            1.
    PCSOLE25  CPSOLE30           -1.   RQELEC25            1.
    PCSOLE30  COSTEN30          54.8   CPSOLE30            1.
    PCSOLE30  CPSOLE35           -1.   RQELEC30            1.
    PCSOLE35  COSTEN35          54.8   CPSOLE35            1.
    PCSOLE35  CPSOLE40           -1.   RQELEC35            1.
    PCSOLE40  COSTEN40          54.8   CPSOLE40            1.
    PCSOLE40  CPSOLE45           -1.   RQELEC40            1.
    PCSOLE45  COSTEN45          54.8   CPSOLE45            1.
    PCSOLE45  CPSOLE50           -1.   RQELEC45            1.
    PCSOLE50  COSTEN50          54.8   CPSOLE50            1.
    PCSOLE50  CPSOLE55           -1.   RQELEC50            1.
    PCSOLE55  COSTEN55          54.8   CPSOLE55            1.
    PCSOLE55  CPSOLE60           -1.   RQELEC55            1.
    PCSOLE60  COSTEN60          54.8   CPSOLE60            1.
    PCSOLE60  CPSOLE65           -1.   RQELEC60            1.
    PCSOLE65  COSTEN65          54.8   CPSOLE65            1.
    PCSOLE65  CPSOLE70           -1.   RQELEC65            1.
    PCSOLE70  COSTEN70          54.8   CPSOLE70            1.
    PCSOLE70  CPSOLE75           -1.   RQELEC70            1.
    PCSOLE75  COSTEN75          54.8   CPSOLE75            1.
    PCSOLE75  RQELEC75            1.
    PCPETG00  CPPETG00            .2   RQNELE00            1.
    PCPETG00  RQPETG00           -1.
    PCPETG05  CPPETG05            .2   RQNELE05            1.
    PCPETG05  RQPETG05           -1.
    PCPETG10  CPPETG10            .2   RQNELE10            1.
    PCPETG10  RQPETG10           -1.
    PCPETG15  CPPETG15            .2   RQNELE15            1.
    PCPETG15  RQPETG15           -1.
    PCPETG20  CPPETG20            .2   RQNELE20            1.
    PCPETG20  RQPETG20           -1.
    PCPETG25  CPPETG25            .2   RQNELE25            1.
    PCPETG25  RQPETG25           -1.
    PCPETG30  CPPETG30            .2   RQNELE30            1.
    PCPETG30  RQPETG30           -1.
    PCPETG35  CPPETG35            .2   RQNELE35            1.
    PCPETG35  RQPETG35           -1.
    PCPETG40  CPPETG40            .2   RQNELE40            1.
    PCPETG40  RQPETG40           -1.
    PCPETG45  CPPETG45            .2   RQNELE45            1.
    PCPETG45  RQPETG45           -1.
    PCPETG50  CPPETG50            .2   RQNELE50            1.
    PCPETG50  RQPETG50           -1.
    PCPETG55  CPPETG55            .2   RQNELE55            1.
    PCPETG55  RQPETG55           -1.
    PCPETG60  CPPETG60            .2   RQNELE60            1.
    PCPETG60  RQPETG60           -1.
    PCPETG65  CPPETG65            .2   RQNELE65            1.
    PCPETG65  RQPETG65           -1.
    PCPETG70  CPPETG70            .2   RQNELE70            1.
    PCPETG70  RQPETG70           -1.
    PCPETG75  CPPETG75            .2   RQNELE75            1.
    PCPETG75  RQPETG75           -1.
    PCSYNF00  COSTEN00           2.8   CPSYNF00            1.
    PCSYNF00  CPSYNF05           -1.   RQNELE00            1.
    PCSYNF00  RQCOAL00          -1.5   CLTOTL00           1.5
    PCSYNF05  COSTEN05           2.8   CPSYNF05            1.
    PCSYNF05  CPSYNF10           -1.   RQNELE05            1.
    PCSYNF05  RQCOAL05          -1.5   CLTOTL05           1.5
    PCSYNF10  COSTEN10           2.8   CPSYNF10            1.
    PCSYNF10  CPSYNF15           -1.   RQNELE10            1.
    PCSYNF10  RQCOAL10          -1.5   CLTOTL10           1.5
    PCSYNF15  COSTEN15           2.8   CPSYNF15            1.
    PCSYNF15  CPSYNF20           -1.   RQNELE15            1.
    PCSYNF15  RQCOAL15          -1.5   CLTOTL15           1.5
    PCSYNF20  COSTEN20           2.8   CPSYNF20            1.
    PCSYNF20  CPSYNF25           -1.   RQNELE20            1.
    PCSYNF20  RQCOAL20          -1.5   CLTOTL20           1.5
    PCSYNF25  COSTEN25           2.8   CPSYNF25            1.
    PCSYNF25  CPSYNF30           -1.   RQNELE25            1.
    PCSYNF25  RQCOAL25          -1.5   CLTOTL25           1.5
    PCSYNF30  COSTEN30           2.8   CPSYNF30            1.
    PCSYNF30  CPSYNF35           -1.   RQNELE30            1.
    PCSYNF30  RQCOAL30          -1.5   CLTOTL30           1.5
    PCSYNF35  COSTEN35           2.8   CPSYNF35            1.
    PCSYNF35  CPSYNF40           -1.   RQNELE35            1.
    PCSYNF35  RQCOAL35          -1.5   CLTOTL35           1.5
    PCSYNF40  COSTEN40           2.8   CPSYNF40            1.
    PCSYNF40  CPSYNF45           -1.   RQNELE40            1.
    PCSYNF40  RQCOAL40          -1.5   CLTOTL40           1.5
    PCSYNF45  COSTEN45           2.8   CPSYNF45            1.
    PCSYNF45  CPSYNF50           -1.   RQNELE45            1.
    PCSYNF45  RQCOAL45          -1.5   CLTOTL45           1.5
    PCSYNF50  COSTEN50           2.8   CPSYNF50            1.
    PCSYNF50  CPSYNF55           -1.   RQNELE50            1.
    PCSYNF50  RQCOAL50          -1.5   CLTOTL50           1.5
    PCSYNF55  COSTEN55           2.8   CPSYNF55            1.
    PCSYNF55  CPSYNF60           -1.   RQNELE55            1.
    PCSYNF55  RQCOAL55          -1.5   CLTOTL55           1.5
    PCSYNF60  COSTEN60           2.8   CPSYNF60            1.
    PCSYNF60  CPSYNF65           -1.   RQNELE60            1.
    PCSYNF60  RQCOAL60          -1.5   CLTOTL60           1.5
    PCSYNF65  COSTEN65           2.8   CPSYNF65            1.
    PCSYNF65  CPSYNF70           -1.   RQNELE65            1.
    PCSYNF65  RQCOAL65          -1.5   CLTOTL65           1.5
    PCSYNF70  COSTEN70           2.8   CPSYNF70            1.
    PCSYNF70  CPSYNF75           -1.   RQNELE70            1.
    PCSYNF70  RQCOAL70          -1.5   CLTOTL70           1.5
    PCSYNF75  COSTEN75           2.8   CPSYNF75            1.
    PCSYNF75  RQNELE75            1.   RQCOAL75          -1.5
    PCSYNF75  CLTOTL75           1.5
    PCSHAL00  COSTEN00            4.   CPSHAL00            1.
    PCSHAL00  CPSHAL05           -1.   RQNELE00            1.
    PCSHAL05  COSTEN05            4.   CPSHAL05            1.
    PCSHAL05  CPSHAL10           -1.   RQNELE05            1.
    PCSHAL10  COSTEN10            4.   CPSHAL10            1.
    PCSHAL10  CPSHAL15           -1.   RQNELE10            1.
    PCSHAL15  COSTEN15            4.   CPSHAL15            1.
    PCSHAL15  CPSHAL20           -1.   RQNELE15            1.
    PCSHAL20  COSTEN20            4.   CPSHAL20            1.
    PCSHAL20  CPSHAL25           -1.   RQNELE20            1.
    PCSHAL25  COSTEN25            4.   CPSHAL25            1.
    PCSHAL25  CPSHAL30           -1.   RQNELE25            1.
    PCSHAL30  COSTEN30            4.   CPSHAL30            1.
    PCSHAL30  CPSHAL35           -1.   RQNELE30            1.
    PCSHAL35  COSTEN35            4.   CPSHAL35            1.
    PCSHAL35  CPSHAL40           -1.   RQNELE35            1.
    PCSHAL40  COSTEN40            4.   CPSHAL40            1.
    PCSHAL40  CPSHAL45           -1.   RQNELE40            1.
    PCSHAL45  COSTEN45            4.   CPSHAL45            1.
    PCSHAL45  CPSHAL50           -1.   RQNELE45            1.
    PCSHAL50  COSTEN50            4.   CPSHAL50            1.
    PCSHAL50  CPSHAL55           -1.   RQNELE50            1.
    PCSHAL55  COSTEN55            4.   CPSHAL55            1.
    PCSHAL55  CPSHAL60           -1.   RQNELE55            1.
    PCSHAL60  COSTEN60            4.   CPSHAL60            1.
    PCSHAL60  CPSHAL65           -1.   RQNELE60            1.
    PCSHAL65  COSTEN65            4.   CPSHAL65            1.
    PCSHAL65  CPSHAL70           -1.   RQNELE65            1.
    PCSHAL70  COSTEN70            4.   CPSHAL70            1.
    PCSHAL70  CPSHAL75           -1.   RQNELE70            1.
    PCSHAL75  COSTEN75            4.   CPSHAL75            1.
    PCSHAL75  RQNELE75            1.
    PCNAES00  COSTEN00            6.   CPNAES00            1.
    PCNAES00  CPNAES05           -1.   RQNELE00            1.
    PCNAES05  COSTEN05            6.   CPNAES05            1.
    PCNAES05  CPNAES10           -1.   RQNELE05            1.
    PCNAES10  COSTEN10            6.   CPNAES10            1.
    PCNAES10  CPNAES15           -1.   RQNELE10            1.
    PCNAES15  COSTEN15            6.   CPNAES15            1.
    PCNAES15  CPNAES20           -1.   RQNELE15            1.
    PCNAES20  COSTEN20            6.   CPNAES20            1.
    PCNAES20  CPNAES25           -1.   RQNELE20            1.
    PCNAES25  COSTEN25            6.   CPNAES25            1.
    PCNAES25  CPNAES30           -1.   RQNELE25            1.
    PCNAES30  COSTEN30            6.   CPNAES30            1.
    PCNAES30  CPNAES35           -1.   RQNELE30            1.
    PCNAES35  COSTEN35            6.   CPNAES35            1.
    PCNAES35  CPNAES40           -1.   RQNELE35            1.
    PCNAES40  COSTEN40            6.   CPNAES40            1.
    PCNAES40  CPNAES45           -1.   RQNELE40            1.
    PCNAES45  COSTEN45            6.   CPNAES45            1.
    PCNAES45  CPNAES50           -1.   RQNELE45            1.
    PCNAES50  COSTEN50            6.   CPNAES50            1.
    PCNAES50  CPNAES55           -1.   RQNELE50            1.
    PCNAES55  COSTEN55            6.   CPNAES55            1.
    PCNAES55  CPNAES60           -1.   RQNELE55            1.
    PCNAES60  COSTEN60            6.   CPNAES60            1.
    PCNAES60  CPNAES65           -1.   RQNELE60            1.
    PCNAES65  COSTEN65            6.   CPNAES65            1.
    PCNAES65  CPNAES70           -1.   RQNELE65            1.
    PCNAES70  COSTEN70            6.   CPNAES70            1.
    PCNAES70  CPNAES75           -1.   RQNELE70            1.
    PCNAES75  COSTEN75            6.   CPNAES75            1.
    PCNAES75  RQNELE75            1.
    PCCLDU00  COSTEN00            1.   CPCLDU00            1.
    PCCLDU00  CPCLDU05           -1.   RQNELE00            1.
    PCCLDU00  RQCOAL00           -1.   CLTOTL00            1.
    PCCLDU05  COSTEN05            1.   CPCLDU05            1.
    PCCLDU05  CPCLDU10           -1.   RQNELE05            1.
    PCCLDU05  RQCOAL05           -1.   CLTOTL05            1.
    PCCLDU10  COSTEN10            1.   CPCLDU10            1.
    PCCLDU10  CPCLDU15           -1.   RQNELE10            1.
    PCCLDU10  RQCOAL10           -1.   CLTOTL10            1.
    PCCLDU15  COSTEN15            1.   CPCLDU15            1.
    PCCLDU15  CPCLDU20           -1.   RQNELE15            1.
    PCCLDU15  RQCOAL15           -1.   CLTOTL15            1.
    PCCLDU20  COSTEN20            1.   CPCLDU20            1.
    PCCLDU20  CPCLDU25           -1.   RQNELE20            1.
    PCCLDU20  RQCOAL20           -1.   CLTOTL20            1.
    PCCLDU25  COSTEN25            1.   CPCLDU25            1.
    PCCLDU25  CPCLDU30           -1.   RQNELE25            1.
    PCCLDU25  RQCOAL25           -1.   CLTOTL25            1.
    PCCLDU30  COSTEN30            1.   CPCLDU30            1.
    PCCLDU30  CPCLDU35           -1.   RQNELE30            1.
    PCCLDU30  RQCOAL30           -1.   CLTOTL30            1.
    PCCLDU35  COSTEN35            1.   CPCLDU35            1.
    PCCLDU35  CPCLDU40           -1.   RQNELE35            1.
    PCCLDU35  RQCOAL35           -1.   CLTOTL35            1.
    PCCLDU40  COSTEN40            1.   CPCLDU40            1.
    PCCLDU40  CPCLDU45           -1.   RQNELE40            1.
    PCCLDU40  RQCOAL40           -1.   CLTOTL40            1.
    PCCLDU45  COSTEN45            1.   CPCLDU45            1.
    PCCLDU45  CPCLDU50           -1.   RQNELE45            1.
    PCCLDU45  RQCOAL45           -1.   CLTOTL45            1.
    PCCLDU50  COSTEN50            1.   CPCLDU50            1.
    PCCLDU50  CPCLDU55           -1.   RQNELE50            1.
    PCCLDU50  RQCOAL50           -1.   CLTOTL50            1.
    PCCLDU55  COSTEN55            1.   CPCLDU55            1.
    PCCLDU55  CPCLDU60           -1.   RQNELE55            1.
    PCCLDU55  RQCOAL55           -1.   CLTOTL55            1.
    PCCLDU60  COSTEN60            1.   CPCLDU60            1.
    PCCLDU60  CPCLDU65           -1.   RQNELE60            1.
    PCCLDU60  RQCOAL60           -1.   CLTOTL60            1.
    PCCLDU65  COSTEN65            1.   CPCLDU65            1.
    PCCLDU65  CPCLDU70           -1.   RQNELE65            1.
    PCCLDU65  RQCOAL65           -1.   CLTOTL65            1.
    PCCLDU70  COSTEN70            1.   CPCLDU70            1.
    PCCLDU70  CPCLDU75           -1.   RQNELE70            1.
    PCCLDU70  RQCOAL70           -1.   CLTOTL70            1.
    PCCLDU75  COSTEN75            1.   CPCLDU75            1.
    PCCLDU75  RQNELE75            1.   RQCOAL75           -1.
    PCCLDU75  CLTOTL75            1.
    PCPGAI00  COSTEN00            2.   CPPGAI00            1.
    PCPGAI00  CPPGAI05           -1.   RQNELE00            1.
    PCPGAI05  COSTEN05          2.21   CPPGAI05            1.
    PCPGAI05  CPPGAI10           -1.   RQNELE05            1.
    PCPGAI10  COSTEN10          2.44   CPPGAI10            1.
    PCPGAI10  CPPGAI15           -1.   RQNELE10            1.
    PCPGAI15  COSTEN15          2.69   CPPGAI15            1.
    PCPGAI15  CPPGAI20           -1.   RQNELE15            1.
    PCPGAI20  COSTEN20          2.97   CPPGAI20            1.
    PCPGAI20  CPPGAI25           -1.   RQNELE20            1.
    PCPGAI25  COSTEN25          3.28   CPPGAI25            1.
    PCPGAI25  CPPGAI30           -1.   RQNELE25            1.
    PCPGAI30  COSTEN30          3.62   CPPGAI30            1.
    PCPGAI30  CPPGAI35           -1.   RQNELE30            1.
    PCPGAI35  COSTEN35            4.   CPPGAI35            1.
    PCPGAI35  CPPGAI40           -1.   RQNELE35            1.
    PCPGAI40  COSTEN40          4.42   CPPGAI40            1.
    PCPGAI40  CPPGAI45           -1.   RQNELE40            1.
    PCPGAI45  COSTEN45          4.88   CPPGAI45            1.
    PCPGAI45  CPPGAI50           -1.   RQNELE45            1.
    PCPGAI50  COSTEN50          5.38   CPPGAI50            1.
    PCPGAI50  CPPGAI55           -1.   RQNELE50            1.
    PCPGAI55  COSTEN55          5.94   CPPGAI55            1.
    PCPGAI55  CPPGAI60           -1.   RQNELE55            1.
    PCPGAI60  COSTEN60          6.56   CPPGAI60            1.
    PCPGAI60  CPPGAI65           -1.   RQNELE60            1.
    PCPGAI65  COSTEN65          7.25   CPPGAI65            1.
    PCPGAI65  CPPGAI70           -1.   RQNELE65            1.
    PCPGAI70  COSTEN70            8.   CPPGAI70            1.
    PCPGAI70  CPPGAI75           -1.   RQNELE70            1.
    PCPGAI75  COSTEN75          8.83   CPPGAI75            1.
    PCPGAI75  RQNELE75            1.
    DPHYDR00  CPHYDR00           -5.   CPHYDR30            5.
    DPHYDR00  CLDLOC00           -1.
    DPHYDR05  CPHYDR05           -5.   CPHYDR35            5.
    DPHYDR05  CLDLOC05           -1.   CLDMIN05            .4
    DPHYDR10  CPHYDR10           -5.   CPHYDR40            5.
    DPHYDR10  CLDLOC10           -1.   CLDMIN10            .4
    DPHYDR15  CPHYDR15           -5.   CPHYDR45            5.
    DPHYDR15  CLDLOC15           -1.   CLDMIN15            .4
    DPHYDR20  CPHYDR20           -5.   CPHYDR50            5.
    DPHYDR20  CLDLOC20           -1.   CLDMIN20            .4
    DPHYDR25  CPHYDR25           -5.   CPHYDR55            5.
    DPHYDR25  CLDLOC25           -1.   CLDMIN25            .4
    DPHYDR30  CPHYDR30           -5.   CPHYDR60            5.
    DPHYDR30  CLDLOC30           -1.   CLDMIN30            .3
    DPHYDR35  CPHYDR35           -5.   CPHYDR65            5.
    DPHYDR35  CLDLOC35           -1.   CLDMIN35            .2
    DPHYDR40  CPHYDR40           -5.   CPHYDR70            5.
    DPHYDR40  CLDLOC40           -1.   CLDMIN40            .1
    DPHYDR45  CPHYDR45           -5.   CPHYDR75            5.
    DPHYDR45  CLDLOC45           -1.
    DPHYDR50  CPHYDR50           -5.   CLDLOC50           -1.
    DPHYDR55  CPHYDR55           -5.   CLDLOC55           -1.
    DPHYDR60  CPHYDR60           -5.   CLDLOC60           -1.
    DPHYDR65  CPHYDR65           -5.   CLDLOC65           -1.
    DPHYDR70  CPHYDR70           -5.   CLDLOC70           -1.
    DPHYDR75  CPHYDR75           -5.   CLDLOC75           -1.
    DPCOLL00  CPCOLL00           -5.   CPCOLL30            5.
    DPCOLL00  CLDLOC00            1.
    DPCOLL05  CPCOLL05           -5.   CPCOLL35            5.
    DPCOLL05  CLDLOC05            1.   CLDMIN05           -.6
    DPCOLL10  CPCOLL10           -5.   CPCOLL40            5.
    DPCOLL10  CLDLOC10            1.   CLDMIN10           -.6
    DPCOLL15  CPCOLL15           -5.   CPCOLL45            5.
    DPCOLL15  CLDLOC15            1.   CLDMIN15           -.6
    DPCOLL20  CPCOLL20           -5.   CPCOLL50            5.
    DPCOLL20  CLDLOC20            1.   CLDMIN20           -.6
    DPCOLL25  CPCOLL25           -5.   CPCOLL55            5.
    DPCOLL25  CLDLOC25            1.   CLDMIN25           -.6
    DPCOLL30  CPCOLL30           -5.   CPCOLL60            5.
    DPCOLL30  CLDLOC30            1.   CLDMIN30           -.7
    DPCOLL35  CPCOLL35           -5.   CPCOLL65            5.
    DPCOLL35  CLDLOC35            1.   CLDMIN35           -.8
    DPCOLL40  CPCOLL40           -5.   CPCOLL70            5.
    DPCOLL40  CLDLOC40            1.   CLDMIN40           -.9
    DPCOLL45  CPCOLL45           -5.   CPCOLL75            5.
    DPCOLL45  CLDLOC45            1.
    DPCOLL50  CPCOLL50           -5.   CLDLOC50            1.
    DPCOLL55  CPCOLL55           -5.   CLDLOC55            1.
    DPCOLL60  CPCOLL60           -5.   CLDLOC60            1.
    DPCOLL65  CPCOLL65           -5.   CLDLOC65            1.
    DPCOLL70  CPCOLL70           -5.   CLDLOC70            1.
    DPCOLL75  CPCOLL75           -5.   CLDLOC75            1.
    DPCOLH00  CPCOLH00           -5.   CPCOLH30            5.
    DPCOLH00  CLDLOC00           -1.
    DPCOLH05  CPCOLH05           -5.   CPCOLH35            5.
    DPCOLH05  CLDLOC05           -1.   CLDMIN05           -.6
    DPCOLH10  CPCOLH10           -5.   CPCOLH40            5.
    DPCOLH10  CLDLOC10           -1.   CLDMIN10           -.6
    DPCOLH15  CPCOLH15           -5.   CPCOLH45            5.
    DPCOLH15  CLDLOC15           -1.   CLDMIN15           -.6
    DPCOLH20  CPCOLH20           -5.   CPCOLH50            5.
    DPCOLH20  CLDLOC20           -1.   CLDMIN20           -.6
    DPCOLH25  CPCOLH25           -5.   CPCOLH55            5.
    DPCOLH25  CLDLOC25           -1.   CLDMIN25           -.6
    DPCOLH30  CPCOLH30           -5.   CPCOLH60            5.
    DPCOLH30  CLDLOC30           -1.   CLDMIN30           -.7
    DPCOLH35  CPCOLH35           -5.   CPCOLH65            5.
    DPCOLH35  CLDLOC35           -1.   CLDMIN35           -.8
    DPCOLH40  CPCOLH40           -5.   CPCOLH70            5.
    DPCOLH40  CLDLOC40           -1.   CLDMIN40           -.9
    DPCOLH45  CPCOLH45           -5.   CPCOLH75            5.
    DPCOLH45  CLDLOC45           -1.
    DPCOLH50  CPCOLH50           -5.   CLDLOC50           -1.
    DPCOLH55  CPCOLH55           -5.   CLDLOC55           -1.
    DPCOLH60  CPCOLH60           -5.   CLDLOC60           -1.
    DPCOLH65  CPCOLH65           -5.   CLDLOC65           -1.
    DPCOLH70  CPCOLH70           -5.   CLDLOC70           -1.
    DPCOLH75  CPCOLH75           -5.   CLDLOC75           -1.
    DPLWRA00  CPLWRA00           -5.   CPLWRA30            5.
    DPLWRA00  RQNATU30         .0806   CLDLOC00           -1.
    DPLWRA05  CPLWRA05           -5.   CPLWRA35            5.
    DPLWRA05  RQNATU00        -.0806   RQNATU35         .0806
    DPLWRA05  CLDLOC05           -1.   CLDMIN05            .4
    DPLWRA10  CPLWRA10           -5.   CPLWRA40            5.
    DPLWRA10  RQNATU05        -.0806   RQNATU40         .0806
    DPLWRA10  CLDLOC10           -1.   CLDMIN10            .4
    DPLWRA15  CPLWRA15           -5.   CPLWRA45            5.
    DPLWRA15  RQNATU10        -.0806   RQNATU45         .0806
    DPLWRA15  CLDLOC15           -1.   CLDMIN15            .4
    DPLWRA20  CPLWRA20           -5.   CPLWRA50            5.
    DPLWRA20  RQNATU15        -.0806   RQNATU50         .0806
    DPLWRA20  CLDLOC20           -1.   CLDMIN20            .4
    DPLWRA25  CPLWRA25           -5.   CPLWRA55            5.
    DPLWRA25  RQNATU20        -.0806   RQNATU55         .0806
    DPLWRA25  CLDLOC25           -1.   CLDMIN25            .4
    DPLWRA30  CPLWRA30           -5.   CPLWRA60            5.
    DPLWRA30  RQNATU25        -.0806   RQNATU60         .0806
    DPLWRA30  CLDLOC30           -1.   CLDMIN30            .3
    DPLWRA35  CPLWRA35           -5.   CPLWRA65            5.
    DPLWRA35  RQNATU30        -.0806   RQNATU65         .0806
    DPLWRA35  CLDLOC35           -1.   CLDMIN35            .2
    DPLWRA40  CPLWRA40           -5.   CPLWRA70            5.
    DPLWRA40  RQNATU35        -.0806   RQNATU70         .0806
    DPLWRA40  CLDLOC40           -1.   CLDMIN40            .1
    DPLWRA45  CPLWRA45           -5.   CPLWRA75            5.
    DPLWRA45  RQNATU40        -.0806   RQNATU75         .0806
    DPLWRA45  CLDLOC45           -1.
    DPLWRA50  CPLWRA50           -5.   RQNATU45        -.0806
    DPLWRA50  CLDLOC50           -1.
    DPLWRA55  CPLWRA55           -5.   RQNATU50        -.0806
    DPLWRA55  CLDLOC55           -1.
    DPLWRA60  CPLWRA60           -5.   RQNATU55        -.0806
    DPLWRA60  CLDLOC60           -1.
    DPLWRA65  CPLWRA65           -5.   RQNATU60        -.0806
    DPLWRA65  CLDLOC65           -1.
    DPLWRA70  CPLWRA70           -5.   RQNATU65        -.0806
    DPLWRA70  CLDLOC70           -1.
    DPLWRA75  CPLWRA75           -5.   RQNATU70        -.0806
    DPLWRA75  CLDLOC75           -1.
    DPLWRB00  CPLWRB00           -5.   CPLWRB30            5.
    DPLWRB00  RQNATU30         .0806   CLDLOC00           -1.
    DPLWRB05  CPLWRB05           -5.   CPLWRB35            5.
    DPLWRB05  RQNATU00        -.0806   RQNATU35         .0806
    DPLWRB05  CLDLOC05           -1.   CLDMIN05            .4
    DPLWRB10  CPLWRB10           -5.   CPLWRB40            5.
    DPLWRB10  RQNATU05        -.0806   RQNATU40         .0806
    DPLWRB10  CLDLOC10           -1.   CLDMIN10            .4
    DPLWRB15  CPLWRB15           -5.   CPLWRB45            5.
    DPLWRB15  RQNATU10        -.0806   RQNATU45         .0806
    DPLWRB15  CLDLOC15           -1.   CLDMIN15            .4
    DPLWRB20  CPLWRB20           -5.   CPLWRB50            5.
    DPLWRB20  RQNATU15        -.0806   RQNATU50         .0806
    DPLWRB20  CLDLOC20           -1.   CLDMIN20            .4
    DPLWRB25  CPLWRB25           -5.   CPLWRB55            5.
    DPLWRB25  RQNATU20        -.0806   RQNATU55         .0806
    DPLWRB25  CLDLOC25           -1.   CLDMIN25            .4
    DPLWRB30  CPLWRB30           -5.   CPLWRB60            5.
    DPLWRB30  RQNATU25        -.0806   RQNATU60         .0806
    DPLWRB30  CLDLOC30           -1.   CLDMIN30            .3
    DPLWRB35  CPLWRB35           -5.   CPLWRB65            5.
    DPLWRB35  RQNATU30        -.0806   RQNATU65         .0806
    DPLWRB35  CLDLOC35           -1.   CLDMIN35            .2
    DPLWRB40  CPLWRB40           -5.   CPLWRB70            5.
    DPLWRB40  RQNATU35        -.0806   RQNATU70         .0806
    DPLWRB40  CLDLOC40           -1.   CLDMIN40            .1
    DPLWRB45  CPLWRB45           -5.   CPLWRB75            5.
    DPLWRB45  RQNATU40        -.0806   RQNATU75         .0806
    DPLWRB45  CLDLOC45           -1.
    DPLWRB50  CPLWRB50           -5.   RQNATU45        -.0806
    DPLWRB50  CLDLOC50           -1.
    DPLWRB55  CPLWRB55           -5.   RQNATU50        -.0806
    DPLWRB55  CLDLOC55           -1.
    DPLWRB60  CPLWRB60           -5.   RQNATU55        -.0806
    DPLWRB60  CLDLOC60           -1.
    DPLWRB65  CPLWRB65           -5.   RQNATU60        -.0806
    DPLWRB65  CLDLOC65           -1.
    DPLWRB70  CPLWRB70           -5.   RQNATU65        -.0806
    DPLWRB70  CLDLOC70           -1.
    DPLWRB75  CPLWRB75           -5.   RQNATU70        -.0806
    DPLWRB75  CLDLOC75           -1.
    DPLWRC00  CPLWRC00           -5.   CPLWRC30            5.
    DPLWRC00  RQNATU30         .0806   CLDLOC00           -1.
    DPLWRC05  CPLWRC05           -5.   CPLWRC35            5.
    DPLWRC05  RQNATU00        -.0806   RQNATU35         .0806
    DPLWRC05  CLDLOC05           -1.   CLDMIN05            .4
    DPLWRC10  CPLWRC10           -5.   CPLWRC40            5.
    DPLWRC10  RQNATU05        -.0806   RQNATU40         .0806
    DPLWRC10  CLDLOC10           -1.   CLDMIN10            .4
    DPLWRC15  CPLWRC15           -5.   CPLWRC45            5.
    DPLWRC15  RQNATU10        -.0806   RQNATU45         .0806
    DPLWRC15  CLDLOC15           -1.   CLDMIN15            .4
    DPLWRC20  CPLWRC20           -5.   CPLWRC50            5.
    DPLWRC20  RQNATU15        -.0806   RQNATU50         .0806
    DPLWRC20  CLDLOC20           -1.   CLDMIN20            .4
    DPLWRC25  CPLWRC25           -5.   CPLWRC55            5.
    DPLWRC25  RQNATU20        -.0806   RQNATU55         .0806
    DPLWRC25  CLDLOC25           -1.   CLDMIN25            .4
    DPLWRC30  CPLWRC30           -5.   CPLWRC60            5.
    DPLWRC30  RQNATU25        -.0806   RQNATU60         .0806
    DPLWRC30  CLDLOC30           -1.   CLDMIN30            .3
    DPLWRC35  CPLWRC35           -5.   CPLWRC65            5.
    DPLWRC35  RQNATU30        -.0806   RQNATU65         .0806
    DPLWRC35  CLDLOC35           -1.   CLDMIN35            .2
    DPLWRC40  CPLWRC40           -5.   CPLWRC70            5.
    DPLWRC40  RQNATU35        -.0806   RQNATU70         .0806
    DPLWRC40  CLDLOC40           -1.   CLDMIN40            .1
    DPLWRC45  CPLWRC45           -5.   CPLWRC75            5.
    DPLWRC45  RQNATU40        -.0806   RQNATU75         .0806
    DPLWRC45  CLDLOC45           -1.
    DPLWRC50  CPLWRC50           -5.   RQNATU45        -.0806
    DPLWRC50  CLDLOC50           -1.
    DPLWRC55  CPLWRC55           -5.   RQNATU50        -.0806
    DPLWRC55  CLDLOC55           -1.
    DPLWRC60  CPLWRC60           -5.   RQNATU55        -.0806
    DPLWRC60  CLDLOC60           -1.
    DPLWRC65  CPLWRC65           -5.   RQNATU60        -.0806
    DPLWRC65  CLDLOC65           -1.
    DPLWRC70  CPLWRC70           -5.   RQNATU65        -.0806
    DPLWRC70  CLDLOC70           -1.
    DPLWRC75  CPLWRC75           -5.   RQNATU70        -.0806
    DPLWRC75  CLDLOC75           -1.
    DPFBRX00  CPFBRX00           -5.   CPFBRX30            5.
    DPFBRX00  SMPLUT00         1.054   SMPLUT30        -1.054
    DPFBRX00  CLDLOC00           -1.
    DPFBRX05  CPFBRX05           -5.   CPFBRX35            5.
    DPFBRX05  SMPLUT05         1.054   SMPLUT35        -1.054
    DPFBRX05  CLDLOC05           -1.   CLDMIN05            .4
    DPFBRX10  CPFBRX10           -5.   CPFBRX40            5.
    DPFBRX10  SMPLUT10         1.054   SMPLUT40        -1.054
    DPFBRX10  CLDLOC10           -1.   CLDMIN10            .4
    DPFBRX15  CPFBRX15           -5.   CPFBRX45            5.
    DPFBRX15  SMPLUT15         1.054   SMPLUT45        -1.054
    DPFBRX15  CLDLOC15           -1.   CLDMIN15            .4
    DPFBRX20  CPFBRX20           -5.   CPFBRX50            5.
    DPFBRX20  SMPLUT20         1.054   SMPLUT50        -1.054
    DPFBRX20  CLDLOC20           -1.   CLDMIN20            .4
    DPFBRX25  CPFBRX25           -5.   CPFBRX55            5.
    DPFBRX25  SMPLUT25         1.054   SMPLUT55        -1.054
    DPFBRX25  CLDLOC25           -1.   CLDMIN25            .4
    DPFBRX30  CPFBRX30           -5.   CPFBRX60            5.
    DPFBRX30  SMPLUT30         1.054   SMPLUT60        -1.054
    DPFBRX30  CLDLOC30           -1.   CLDMIN30            .3
    DPFBRX35  CPFBRX35           -5.   CPFBRX65            5.
    DPFBRX35  SMPLUT35         1.054   SMPLUT65        -1.054
    DPFBRX35  CLDLOC35           -1.   CLDMIN35            .2
    DPFBRX40  CPFBRX40           -5.   CPFBRX70            5.
    DPFBRX40  SMPLUT40         1.054   SMPLUT70        -1.054
    DPFBRX40  CLDLOC40           -1.   CLDMIN40            .1
    DPFBRX45  CPFBRX45           -5.   CPFBRX75            5.
    DPFBRX45  SMPLUT45         1.054   SMPLUT75        -1.054
    DPFBRX45  CLDLOC45           -1.
    DPFBRX50  CPFBRX50           -5.   SMPLUT50         1.054
    DPFBRX50  CLDLOC50           -1.
    DPFBRX55  CPFBRX55           -5.   SMPLUT55         1.054
    DPFBRX55  CLDLOC55           -1.
    DPFBRX60  CPFBRX60           -5.   SMPLUT60         1.054
    DPFBRX60  CLDLOC60           -1.
    DPFBRX65  CPFBRX65           -5.   SMPLUT65         1.054
    DPFBRX65  CLDLOC65           -1.
    DPFBRX70  CPFBRX70           -5.   SMPLUT70         1.054
    DPFBRX70  CLDLOC70           -1.
    DPFBRX75  CPFBRX75           -5.   SMPLUT75         1.054
    DPFBRX75  CLDLOC75           -1.
    DPSOLE00  CPSOLE00           -5.   CPSOLE30            5.
    DPSOLE00  CLDLOC00           -1.
    DPSOLE05  CPSOLE05           -5.   CPSOLE35            5.
    DPSOLE05  CLDLOC05           -1.   CLDMIN05            .4
    DPSOLE10  CPSOLE10           -5.   CPSOLE40            5.
    DPSOLE10  CLDLOC10           -1.   CLDMIN10            .4
    DPSOLE15  CPSOLE15           -5.   CPSOLE45            5.
    DPSOLE15  CLDLOC15           -1.   CLDMIN15            .4
    DPSOLE20  CPSOLE20           -5.   CPSOLE50            5.
    DPSOLE20  CLDLOC20           -1.   CLDMIN20            .4
    DPSOLE25  CPSOLE25           -5.   CPSOLE55            5.
    DPSOLE25  CLDLOC25           -1.   CLDMIN25            .4
    DPSOLE30  CPSOLE30           -5.   CPSOLE60            5.
    DPSOLE30  CLDLOC30           -1.   CLDMIN30            .3
    DPSOLE35  CPSOLE35           -5.   CPSOLE65            5.
    DPSOLE35  CLDLOC35           -1.   CLDMIN35            .2
    DPSOLE40  CPSOLE40           -5.   CPSOLE70            5.
    DPSOLE40  CLDLOC40           -1.   CLDMIN40            .1
    DPSOLE45  CPSOLE45           -5.   CPSOLE75            5.
    DPSOLE45  CLDLOC45           -1.
    DPSOLE50  CPSOLE50           -5.   CLDLOC50           -1.
    DPSOLE55  CPSOLE55           -5.   CLDLOC55           -1.
    DPSOLE60  CPSOLE60           -5.   CLDLOC60           -1.
    DPSOLE65  CPSOLE65           -5.   CLDLOC65           -1.
    DPSOLE70  CPSOLE70           -5.   CLDLOC70           -1.
    DPSOLE75  CPSOLE75           -5.   CLDLOC75           -1.
    DPPETG00  CPPETG00           -1.   CPPETG05           -1.
    DPPETG00  CPPETG10       -.77378   CPPETG15       -.59874
    DPPETG00  CPPETG20       -.46329   CPPETG25       -.35849
    DPPETG00  CPPETG30       -.27739   CPPETG35       -.21464
    DPPETG05  CPPETG05           -1.   CPPETG10           -1.
    DPPETG05  CPPETG15       -.77378   CPPETG20       -.59874
    DPPETG05  CPPETG25       -.46329   CPPETG30       -.35849
    DPPETG05  CPPETG35       -.27739   CPPETG40       -.21464
    DPPETG10  CPPETG10           -1.   CPPETG15           -1.
    DPPETG10  CPPETG20       -.77378   CPPETG25       -.59874
    DPPETG10  CPPETG30       -.46329   CPPETG35       -.35849
    DPPETG10  CPPETG40       -.27739   CPPETG45       -.21464
    DPPETG15  CPPETG15           -1.   CPPETG20           -1.
    DPPETG15  CPPETG25       -.77378   CPPETG30       -.59874
    DPPETG15  CPPETG35       -.46329   CPPETG40       -.35849
    DPPETG15  CPPETG45       -.27739   CPPETG50       -.21464
    DPPETG20  CPPETG20           -1.   CPPETG25           -1.
    DPPETG20  CPPETG30       -.77378   CPPETG35       -.59874
    DPPETG20  CPPETG40       -.46329   CPPETG45       -.35849
    DPPETG20  CPPETG50       -.27739   CPPETG55       -.21464
    DPPETG25  CPPETG25           -1.   CPPETG30           -1.
    DPPETG25  CPPETG35       -.77378   CPPETG40       -.59874
    DPPETG25  CPPETG45       -.46329   CPPETG50       -.35849
    DPPETG25  CPPETG55       -.27739   CPPETG60       -.21464
    DPPETG30  CPPETG30           -1.   CPPETG35           -1.
    DPPETG30  CPPETG40       -.77378   CPPETG45       -.59874
    DPPETG30  CPPETG50       -.46329   CPPETG55       -.35849
    DPPETG30  CPPETG60       -.27739   CPPETG65       -.21464
    DPPETG35  CPPETG35           -1.   CPPETG40           -1.
    DPPETG35  CPPETG45       -.77378   CPPETG50       -.59874
    DPPETG35  CPPETG55       -.46329   CPPETG60       -.35849
    DPPETG35  CPPETG65       -.27739   CPPETG70       -.21464
    DPPETG40  CPPETG40           -1.   CPPETG45           -1.
    DPPETG40  CPPETG50       -.77378   CPPETG55       -.59874
    DPPETG40  CPPETG60       -.46329   CPPETG65       -.35849
    DPPETG40  CPPETG70       -.27739   CPPETG75       -.21464
    DPPETG45  CPPETG45           -1.   CPPETG50           -1.
    DPPETG45  CPPETG55       -.77378   CPPETG60       -.59874
    DPPETG45  CPPETG65       -.46329   CPPETG70       -.35849
    DPPETG45  CPPETG75       -.27739
    DPPETG50  CPPETG50           -1.   CPPETG55           -1.
    DPPETG50  CPPETG60       -.77378   CPPETG65       -.59874
    DPPETG50  CPPETG70       -.46329   CPPETG75       -.35849
    DPPETG55  CPPETG55           -1.   CPPETG60           -1.
    DPPETG55  CPPETG65       -.77378   CPPETG70       -.59874
    DPPETG55  CPPETG75       -.46329
    DPPETG60  CPPETG60           -1.   CPPETG65           -1.
    DPPETG60  CPPETG70       -.77378   CPPETG75       -.59874
    DPPETG65  CPPETG65           -1.   CPPETG70           -1.
    DPPETG65  CPPETG75       -.77378
    DPPETG70  CPPETG70           -1.   CPPETG75           -1.
    DPPETG75  CPPETG75           -1.
    DPSYNF00  CPSYNF00           -5.   CPSYNF30            5.
    DPSYNF05  CPSYNF05           -5.   CPSYNF35            5.
    DPSYNF10  CPSYNF10           -5.   CPSYNF40            5.
    DPSYNF15  CPSYNF15           -5.   CPSYNF45            5.
    DPSYNF20  CPSYNF20           -5.   CPSYNF50            5.
    DPSYNF25  CPSYNF25           -5.   CPSYNF55            5.
    DPSYNF30  CPSYNF30           -5.   CPSYNF60            5.
    DPSYNF35  CPSYNF35           -5.   CPSYNF65            5.
    DPSYNF40  CPSYNF40           -5.   CPSYNF70            5.
    DPSYNF45  CPSYNF45           -5.   CPSYNF75            5.
    DPSYNF50  CPSYNF50           -5.
    DPSYNF55  CPSYNF55           -5.
    DPSYNF60  CPSYNF60           -5.
    DPSYNF65  CPSYNF65           -5.
    DPSYNF70  CPSYNF70           -5.
    DPSYNF75  CPSYNF75           -5.
    DPSHAL00  CPSHAL00           -5.   CPSHAL30            5.
    DPSHAL05  CPSHAL05           -5.   CPSHAL35            5.
    DPSHAL10  CPSHAL10           -5.   CPSHAL40            5.
    DPSHAL15  CPSHAL15           -5.   CPSHAL45            5.
    DPSHAL20  CPSHAL20           -5.   CPSHAL50            5.
    DPSHAL25  CPSHAL25           -5.   CPSHAL55            5.
    DPSHAL30  CPSHAL30           -5.   CPSHAL60            5.
    DPSHAL35  CPSHAL35           -5.   CPSHAL65            5.
    DPSHAL40  CPSHAL40           -5.   CPSHAL70            5.
    DPSHAL45  CPSHAL45           -5.   CPSHAL75            5.
    DPSHAL50  CPSHAL50           -5.
    DPSHAL55  CPSHAL55           -5.
    DPSHAL60  CPSHAL60           -5.
    DPSHAL65  CPSHAL65           -5.
    DPSHAL70  CPSHAL70           -5.
    DPSHAL75  CPSHAL75           -5.
    DPNAES00  CPNAES00           -5.   CPNAES30            5.
    DPNAES05  CPNAES05           -5.   CPNAES35            5.
    DPNAES10  CPNAES10           -5.   CPNAES40            5.
    DPNAES15  CPNAES15           -5.   CPNAES45            5.
    DPNAES20  CPNAES20           -5.   CPNAES50            5.
    DPNAES25  CPNAES25           -5.   CPNAES55            5.
    DPNAES30  CPNAES30           -5.   CPNAES60            5.
    DPNAES35  CPNAES35           -5.   CPNAES65            5.
    DPNAES40  CPNAES40           -5.   CPNAES70            5.
    DPNAES45  CPNAES45           -5.   CPNAES75            5.
    DPNAES50  CPNAES50           -5.
    DPNAES55  CPNAES55           -5.
    DPNAES60  CPNAES60           -5.
    DPNAES65  CPNAES65           -5.
    DPNAES70  CPNAES70           -5.
    DPNAES75  CPNAES75           -5.
    DPCLDU00  CPCLDU00           -5.   CPCLDU30            5.
    DPCLDU05  CPCLDU05           -5.   CPCLDU35            5.
    DPCLDU10  CPCLDU10           -5.   CPCLDU40            5.
    DPCLDU15  CPCLDU15           -5.   CPCLDU45            5.
    DPCLDU20  CPCLDU20           -5.   CPCLDU50            5.
    DPCLDU25  CPCLDU25           -5.   CPCLDU55            5.
    DPCLDU30  CPCLDU30           -5.   CPCLDU60            5.
    DPCLDU35  CPCLDU35           -5.   CPCLDU65            5.
    DPCLDU40  CPCLDU40           -5.   CPCLDU70            5.
    DPCLDU45  CPCLDU45           -5.   CPCLDU75            5.
    DPCLDU50  CPCLDU50           -5.
    DPCLDU55  CPCLDU55           -5.
    DPCLDU60  CPCLDU60           -5.
    DPCLDU65  CPCLDU65           -5.
    DPCLDU70  CPCLDU70           -5.
    DPCLDU75  CPCLDU75           -5.
    DPPGAI00  CPPGAI00           -5.   CPPGAI30            5.
    DPPGAI05  CPPGAI05           -5.   CPPGAI35            5.
    DPPGAI10  CPPGAI10           -5.   CPPGAI40            5.
    DPPGAI15  CPPGAI15           -5.   CPPGAI45            5.
    DPPGAI20  CPPGAI20           -5.   CPPGAI50            5.
    DPPGAI25  CPPGAI25           -5.   CPPGAI55            5.
    DPPGAI30  CPPGAI30           -5.   CPPGAI60            5.
    DPPGAI35  CPPGAI35           -5.   CPPGAI65            5.
    DPPGAI40  CPPGAI40           -5.   CPPGAI70            5.
    DPPGAI45  CPPGAI45           -5.   CPPGAI75            5.
    DPPGAI50  CPPGAI50           -5.
    DPPGAI55  CPPGAI55           -5.
    DPPGAI60  CPPGAI60           -5.
    DPPGAI65  CPPGAI65           -5.
    DPPGAI70  CPPGAI70           -5.
    DPPGAI75  CPPGAI75           -5.
    QPETG100  COSTEN00            2.   RQPETG00            1.
    QPETG100  AVPETG01            5.
    QPETG105  COSTEN05            2.   RQPETG05            1.
    QPETG105  AVPETG01            5.
    QPETG110  COSTEN10            2.   RQPETG10            1.
    QPETG110  AVPETG01            5.
    QPETG115  COSTEN15            2.   RQPETG15            1.
    QPETG115  AVPETG01            5.
    QPETG120  COSTEN20            2.   RQPETG20            1.
    QPETG120  AVPETG01            5.
    QPETG125  COSTEN25            2.   RQPETG25            1.
    QPETG125  AVPETG01            5.
    QPETG130  COSTEN30            2.   RQPETG30            1.
    QPETG130  AVPETG01            5.
    QPETG135  COSTEN35            2.   RQPETG35            1.
    QPETG135  AVPETG01            5.
    QPETG140  COSTEN40            2.   RQPETG40            1.
    QPETG140  AVPETG01            5.
    QPETG145  COSTEN45            2.   RQPETG45            1.
    QPETG145  AVPETG01            5.
    QPETG150  COSTEN50            2.   RQPETG50            1.
    QPETG150  AVPETG01            5.
    QPETG155  COSTEN55            2.   RQPETG55            1.
    QPETG155  AVPETG01            5.
    QPETG160  COSTEN60            2.   RQPETG60            1.
    QPETG160  AVPETG01            5.
    QPETG165  COSTEN65            2.   RQPETG65            1.
    QPETG165  AVPETG01            5.
    QPETG170  COSTEN70            2.   RQPETG70            1.
    QPETG170  AVPETG01            5.
    QPETG175  COSTEN75            2.   RQPETG75            1.
    QPETG175  AVPETG01            5.
    QPETG200  COSTEN00           2.5   RQPETG00            1.
    QPETG200  AVPETG02            5.
    QPETG205  COSTEN05           2.5   RQPETG05            1.
    QPETG205  AVPETG02            5.
    QPETG210  COSTEN10           2.5   RQPETG10            1.
    QPETG210  AVPETG02            5.
    QPETG215  COSTEN15           2.5   RQPETG15            1.
    QPETG215  AVPETG02            5.
    QPETG220  COSTEN20           2.5   RQPETG20            1.
    QPETG220  AVPETG02            5.
    QPETG225  COSTEN25           2.5   RQPETG25            1.
    QPETG225  AVPETG02            5.
    QPETG230  COSTEN30           2.5   RQPETG30            1.
    QPETG230  AVPETG02            5.
    QPETG235  COSTEN35           2.5   RQPETG35            1.
    QPETG235  AVPETG02            5.
    QPETG240  COSTEN40           2.5   RQPETG40            1.
    QPETG240  AVPETG02            5.
    QPETG245  COSTEN45           2.5   RQPETG45            1.
    QPETG245  AVPETG02            5.
    QPETG250  COSTEN50           2.5   RQPETG50            1.
    QPETG250  AVPETG02            5.
    QPETG255  COSTEN55           2.5   RQPETG55            1.
    QPETG255  AVPETG02            5.
    QPETG260  COSTEN60           2.5   RQPETG60            1.
    QPETG260  AVPETG02            5.
    QPETG265  COSTEN65           2.5   RQPETG65            1.
    QPETG265  AVPETG02            5.
    QPETG270  COSTEN70           2.5   RQPETG70            1.
    QPETG270  AVPETG02            5.
    QPETG275  COSTEN75           2.5   RQPETG75            1.
    QPETG275  AVPETG02            5.
    QPETG300  COSTEN00           3.5   RQPETG00            1.
    QPETG300  AVPETG03            5.
    QPETG305  COSTEN05           3.5   RQPETG05            1.
    QPETG305  AVPETG03            5.
    QPETG310  COSTEN10           3.5   RQPETG10            1.
    QPETG310  AVPETG03            5.
    QPETG315  COSTEN15           3.5   RQPETG15            1.
    QPETG315  AVPETG03            5.
    QPETG320  COSTEN20           3.5   RQPETG20            1.
    QPETG320  AVPETG03            5.
    QPETG325  COSTEN25           3.5   RQPETG25            1.
    QPETG325  AVPETG03            5.
    QPETG330  COSTEN30           3.5   RQPETG30            1.
    QPETG330  AVPETG03            5.
    QPETG335  COSTEN35           3.5   RQPETG35            1.
    QPETG335  AVPETG03            5.
    QPETG340  COSTEN40           3.5   RQPETG40            1.
    QPETG340  AVPETG03            5.
    QPETG345  COSTEN45           3.5   RQPETG45            1.
    QPETG345  AVPETG03            5.
    QPETG350  COSTEN50           3.5   RQPETG50            1.
    QPETG350  AVPETG03            5.
    QPETG355  COSTEN55           3.5   RQPETG55            1.
    QPETG355  AVPETG03            5.
    QPETG360  COSTEN60           3.5   RQPETG60            1.
    QPETG360  AVPETG03            5.
    QPETG365  COSTEN65           3.5   RQPETG65            1.
    QPETG365  AVPETG03            5.
    QPETG370  COSTEN70           3.5   RQPETG70            1.
    QPETG370  AVPETG03            5.
    QPETG375  COSTEN75           3.5   RQPETG75            1.
    QPETG375  AVPETG03            5.
    QPETG400  COSTEN00            5.   RQPETG00            1.
    QPETG400  AVPETG04            5.
    QPETG405  COSTEN05            5.   RQPETG05            1.
    QPETG405  AVPETG04            5.
    QPETG410  COSTEN10            5.   RQPETG10            1.
    QPETG410  AVPETG04            5.
    QPETG415  COSTEN15            5.   RQPETG15            1.
    QPETG415  AVPETG04            5.
    QPETG420  COSTEN20            5.   RQPETG20            1.
    QPETG420  AVPETG04            5.
    QPETG425  COSTEN25            5.   RQPETG25            1.
    QPETG425  AVPETG04            5.
    QPETG430  COSTEN30            5.   RQPETG30            1.
    QPETG430  AVPETG04            5.
    QPETG435  COSTEN35            5.   RQPETG35            1.
    QPETG435  AVPETG04            5.
    QPETG440  COSTEN40            5.   RQPETG40            1.
    QPETG440  AVPETG04            5.
    QPETG445  COSTEN45            5.   RQPETG45            1.
    QPETG445  AVPETG04            5.
    QPETG450  COSTEN50            5.   RQPETG50            1.
    QPETG450  AVPETG04            5.
    QPETG455  COSTEN55            5.   RQPETG55            1.
    QPETG455  AVPETG04            5.
    QPETG460  COSTEN60            5.   RQPETG60            1.
    QPETG460  AVPETG04            5.
    QPETG465  COSTEN65            5.   RQPETG65            1.
    QPETG465  AVPETG04            5.
    QPETG470  COSTEN70            5.   RQPETG70            1.
    QPETG470  AVPETG04            5.
    QPETG475  COSTEN75            5.   RQPETG75            1.
    QPETG475  AVPETG04            5.
    QCOAL100  COSTEN00            .8   RQCOAL00            1.
    QCOAL100  AVCOAL01            5.
    QCOAL105  COSTEN05            .8   RQCOAL05            1.
    QCOAL105  AVCOAL01            5.
    QCOAL110  COSTEN10            .8   RQCOAL10            1.
    QCOAL110  AVCOAL01            5.
    QCOAL115  COSTEN15            .8   RQCOAL15            1.
    QCOAL115  AVCOAL01            5.
    QCOAL120  COSTEN20            .8   RQCOAL20            1.
    QCOAL120  AVCOAL01            5.
    QCOAL125  COSTEN25            .8   RQCOAL25            1.
    QCOAL125  AVCOAL01            5.
    QCOAL130  COSTEN30            .8   RQCOAL30            1.
    QCOAL130  AVCOAL01            5.
    QCOAL135  COSTEN35            .8   RQCOAL35            1.
    QCOAL135  AVCOAL01            5.
    QCOAL140  COSTEN40            .8   RQCOAL40            1.
    QCOAL140  AVCOAL01            5.
    QCOAL145  COSTEN45            .8   RQCOAL45            1.
    QCOAL145  AVCOAL01            5.
    QCOAL150  COSTEN50            .8   RQCOAL50            1.
    QCOAL150  AVCOAL01            5.
    QCOAL155  COSTEN55            .8   RQCOAL55            1.
    QCOAL155  AVCOAL01            5.
    QCOAL160  COSTEN60            .8   RQCOAL60            1.
    QCOAL160  AVCOAL01            5.
    QCOAL165  COSTEN65            .8   RQCOAL65            1.
    QCOAL165  AVCOAL01            5.
    QCOAL170  COSTEN70            .8   RQCOAL70            1.
    QCOAL170  AVCOAL01            5.
    QCOAL175  COSTEN75            .8   RQCOAL75            1.
    QCOAL175  AVCOAL01            5.
    QNATU100  COSTEN00           60.   RQNATU00            1.
    QNATU100  AVNATU01            5.
    QNATU105  COSTEN05           60.   RQNATU05            1.
    QNATU105  AVNATU01            5.
    QNATU110  COSTEN10           60.   RQNATU10            1.
    QNATU110  AVNATU01            5.
    QNATU115  COSTEN15           60.   RQNATU15            1.
    QNATU115  AVNATU01            5.
    QNATU120  COSTEN20           60.   RQNATU20            1.
    QNATU120  AVNATU01            5.
    QNATU125  COSTEN25           60.   RQNATU25            1.
    QNATU125  AVNATU01            5.
    QNATU130  COSTEN30           60.   RQNATU30            1.
    QNATU130  AVNATU01            5.
    QNATU135  COSTEN35           60.   RQNATU35            1.
    QNATU135  AVNATU01            5.
    QNATU140  COSTEN40           60.   RQNATU40            1.
    QNATU140  AVNATU01            5.
    QNATU145  COSTEN45           60.   RQNATU45            1.
    QNATU145  AVNATU01            5.
    QNATU150  COSTEN50           60.   RQNATU50            1.
    QNATU150  AVNATU01            5.
    QNATU155  COSTEN55           60.   RQNATU55            1.
    QNATU155  AVNATU01            5.
    QNATU160  COSTEN60           60.   RQNATU60            1.
    QNATU160  AVNATU01            5.
    QNATU165  COSTEN65           60.   RQNATU65            1.
    QNATU165  AVNATU01            5.
    QNATU170  COSTEN70           60.   RQNATU70            1.
    QNATU170  AVNATU01            5.
    QNATU175  COSTEN75           60.   RQNATU75            1.
    QNATU175  AVNATU01            5.
    QNATU200  COSTEN00          300.   RQNATU00            1.
    QNATU200  AVNATU02            5.
    QNATU205  COSTEN05          300.   RQNATU05            1.
    QNATU205  AVNATU02            5.
    QNATU210  COSTEN10          300.   RQNATU10            1.
    QNATU210  AVNATU02            5.
    QNATU215  COSTEN15          300.   RQNATU15            1.
    QNATU215  AVNATU02            5.
    QNATU220  COSTEN20          300.   RQNATU20            1.
    QNATU220  AVNATU02            5.
    QNATU225  COSTEN25          300.   RQNATU25            1.
    QNATU225  AVNATU02            5.
    QNATU230  COSTEN30          300.   RQNATU30            1.
    QNATU230  AVNATU02            5.
    QNATU235  COSTEN35          300.   RQNATU35            1.
    QNATU235  AVNATU02            5.
    QNATU240  COSTEN40          300.   RQNATU40            1.
    QNATU240  AVNATU02            5.
    QNATU245  COSTEN45          300.   RQNATU45            1.
    QNATU245  AVNATU02            5.
    QNATU250  COSTEN50          300.   RQNATU50            1.
    QNATU250  AVNATU02            5.
    QNATU255  COSTEN55          300.   RQNATU55            1.
    QNATU255  AVNATU02            5.
    QNATU260  COSTEN60          300.   RQNATU60            1.
    QNATU260  AVNATU02            5.
    QNATU265  COSTEN65          300.   RQNATU65            1.
    QNATU265  AVNATU02            5.
    QNATU270  COSTEN70          300.   RQNATU70            1.
    QNATU270  AVNATU02            5.
    QNATU275  COSTEN75          300.   RQNATU75            1.
    QNATU275  AVNATU02            5.
    QNATU300  COSTEN00         2000.   RQNATU00            1.
    QNATU300  AVNATU03            5.
    QNATU305  COSTEN05         2000.   RQNATU05            1.
    QNATU305  AVNATU03            5.
    QNATU310  COSTEN10         2000.   RQNATU10            1.
    QNATU310  AVNATU03            5.
    QNATU315  COSTEN15         2000.   RQNATU15            1.
    QNATU315  AVNATU03            5.
    QNATU320  COSTEN20         2000.   RQNATU20            1.
    QNATU320  AVNATU03            5.
    QNATU325  COSTEN25         2000.   RQNATU25            1.
    QNATU325  AVNATU03            5.
    QNATU330  COSTEN30         2000.   RQNATU30            1.
    QNATU330  AVNATU03            5.
    QNATU335  COSTEN35         2000.   RQNATU35            1.
    QNATU335  AVNATU03            5.
    QNATU340  COSTEN40         2000.   RQNATU40            1.
    QNATU340  AVNATU03            5.
    QNATU345  COSTEN45         2000.   RQNATU45            1.
    QNATU345  AVNATU03            5.
    QNATU350  COSTEN50         2000.   RQNATU50            1.
    QNATU350  AVNATU03            5.
    QNATU355  COSTEN55         2000.   RQNATU55            1.
    QNATU355  AVNATU03            5.
    QNATU360  COSTEN60         2000.   RQNATU60            1.
    QNATU360  AVNATU03            5.
    QNATU365  COSTEN65         2000.   RQNATU65            1.
    QNATU365  AVNATU03            5.
    QNATU370  COSTEN70         2000.   RQNATU70            1.
    QNATU370  AVNATU03            5.
    QNATU375  COSTEN75         2000.   RQNATU75            1.
    QNATU375  AVNATU03            5.
    CSPLUT00  SMPLUT00            .2   SMPLUT05          -.19
    CSPLUT05  SMPLUT05            .2   SMPLUT10          -.19
    CSPLUT10  SMPLUT10            .2   SMPLUT15          -.19
    CSPLUT15  SMPLUT15            .2   SMPLUT20          -.19
    CSPLUT20  SMPLUT20            .2   SMPLUT25          -.19
    CSPLUT25  SMPLUT25            .2   SMPLUT30          -.19
    CSPLUT30  SMPLUT30            .2   SMPLUT35          -.19
    CSPLUT35  SMPLUT35            .2   SMPLUT40          -.19
    CSPLUT40  SMPLUT40            .2   SMPLUT45          -.19
    CSPLUT45  SMPLUT45            .2   SMPLUT50          -.19
    CSPLUT50  SMPLUT50            .2   SMPLUT55          -.19
    CSPLUT55  SMPLUT55            .2   SMPLUT60          -.19
    CSPLUT60  SMPLUT60            .2   SMPLUT65          -.19
    CSPLUT65  SMPLUT65            .2   SMPLUT70          -.19
    CSPLUT70  SMPLUT70            .2   SMPLUT75          -.19
    CSPLUT75  SMPLUT75            .2
RHS
    RHS00001  AVPETG01         1000.   AVPETG02          500.
    RHS00001  AVPETG03          500.   AVPETG04          400.
    RHS00001  AVCOAL01        10000.   AVNATU01           2.6
    RHS00001  AVNATU02           1.1   AVNATU03      96.29999
    RHS00001  CLTOTL00      17.25999   CLTOTL05      22.07001
    RHS00001  CLTOTL10         27.12   CLTOTL15           32.
    RHS00001  CLTOTL20         36.36   CLTOTL25           40.
    RHS00001  CLTOTL30         42.86   CLTOTL35           45.
    RHS00001  CLTOTL40         46.55   CLTOTL45      47.64999
    RHS00001  CLTOTL50         48.41   CLTOTL55      48.92999
    RHS00001  CLTOTL60         49.28   CLTOTL65         49.52
    RHS00001  CLTOTL70      49.67999   CLTOTL75         49.78
BOUNDS
 FX BOUNDS01  DMELEC00          1.98
 LO BOUNDS01  DMELEC05          1.98
 LO BOUNDS01  DMELEC10          1.98
 LO BOUNDS01  DMELEC15          1.98
 LO BOUNDS01  DMELEC20          1.98
 LO BOUNDS01  DMELEC25          1.98
 LO BOUNDS01  DMELEC30          1.98
 LO BOUNDS01  DMELEC35          1.98
 LO BOUNDS01  DMELEC40          1.98
 LO BOUNDS01  DMELEC45          1.98
 LO BOUNDS01  DMELEC50          1.98
 LO BOUNDS01  DMELEC55          1.98
 LO BOUNDS01  DMELEC60          1.98
 LO BOUNDS01  DMELEC65          1.98
 LO BOUNDS01  DMELEC70          1.98
 LO BOUNDS01  DMELEC75          1.98
 FX BOUNDS01  DMNELE00          .508
 LO BOUNDS01  DMNELE05          .508
 LO BOUNDS01  DMNELE10          .508
 LO BOUNDS01  DMNELE15          .508
 LO BOUNDS01  DMNELE20          .508
 LO BOUNDS01  DMNELE25          .508
 LO BOUNDS01  DMNELE30          .508
 LO BOUNDS01  DMNELE35          .508
 LO BOUNDS01  DMNELE40          .508
 LO BOUNDS01  DMNELE45          .508
 LO BOUNDS01  DMNELE50          .508
 LO BOUNDS01  DMNELE55          .508
 LO BOUNDS01  DMNELE60          .508
 LO BOUNDS01  DMNELE65          .508
 LO BOUNDS01  DMNELE70          .508
 LO BOUNDS01  DMNELE75          .508
 FX BOUNDS01  PCHYDR00          .305
 FX BOUNDS01  PCHYDR05          .345
 FX BOUNDS01  PCHYDR10           .39
 FX BOUNDS01  PCHYDR15          .442
 FX BOUNDS01  PCHYDR20            .5
 FX BOUNDS01  PCHYDR25          .565
 FX BOUNDS01  PCHYDR30           .64
 FX BOUNDS01  PCHYDR35          .724
 FX BOUNDS01  PCHYDR40          .819
 FX BOUNDS01  PCHYDR45          .927
 FX BOUNDS01  PCHYDR50         1.048
 FX BOUNDS01  PCHYDR55         1.186
 FX BOUNDS01  PCHYDR60         1.342
 FX BOUNDS01  PCHYDR65         1.518
 FX BOUNDS01  PCHYDR70         1.718
 FX BOUNDS01  PCHYDR75         1.944
 FX BOUNDS01  PCRFOS00         1.535
 FX BOUNDS01  PCRFOS05         1.279
 FX BOUNDS01  PCRFOS10         1.023
 FX BOUNDS01  PCRFOS15          .768
 FX BOUNDS01  PCRFOS20          .512
 FX BOUNDS01  PCRFOS25          .256
 FX BOUNDS01  PCRFOS30            0.
 FX BOUNDS01  PCRFOS35            0.
 FX BOUNDS01  PCRFOS40            0.
 FX BOUNDS01  PCRFOS45            0.
 FX BOUNDS01  PCRFOS50            0.
 FX BOUNDS01  PCRFOS55            0.
 FX BOUNDS01  PCRFOS60            0.
 FX BOUNDS01  PCRFOS65            0.
 FX BOUNDS01  PCRFOS70            0.
 FX BOUNDS01  PCRFOS75            0.
 FX BOUNDS01  PCLWRA00          .155
 FX BOUNDS01  PCLWRB00            0.
 FX BOUNDS01  PCLWRB05            0.
 FX BOUNDS01  PCLWRB10            0.
 UP BOUNDS01  PCLWRB15          .285
 UP BOUNDS01  PCLWRB20           .57
 FX BOUNDS01  PCLWRC00            0.
 FX BOUNDS01  PCLWRC05            0.
 FX BOUNDS01  PCLWRC10            0.
 UP BOUNDS01  PCLWRC15          .285
 UP BOUNDS01  PCLWRC20           .57
 FX BOUNDS01  PCFBRX00            0.
 FX BOUNDS01  PCFBRX05            0.
 FX BOUNDS01  PCFBRX10            0.
 FX BOUNDS01  PCFBRX15            0.
 FX BOUNDS01  PCFBRX20            0.
 UP BOUNDS01  PCFBRX25          .034
 UP BOUNDS01  PCFBRX30          .184
 UP BOUNDS01  PCFBRX35          .682
 UP BOUNDS01  PCFBRX40         1.698
 UP BOUNDS01  PCFBRX45         2.734
 UP BOUNDS01  PCFBRX50         4.403
 UP BOUNDS01  PCFBRX55         7.091
 UP BOUNDS01  PCFBRX60         11.42
 UP BOUNDS01  PCFBRX65      18.39301
 UP BOUNDS01  PCFBRX70      29.62199
 UP BOUNDS01  PCFBRX75      47.70599
 FX BOUNDS01  PCSOLE00            0.
 FX BOUNDS01  PCSOLE05            0.
 FX BOUNDS01  PCSOLE10            0.
 FX BOUNDS01  PCSOLE15            0.
 FX BOUNDS01  PCSOLE20            0.
 UP BOUNDS01  PCSOLE25          .034
 UP BOUNDS01  PCSOLE30          .184
 UP BOUNDS01  PCSOLE35          .682
 UP BOUNDS01  PCSOLE40         1.698
 UP BOUNDS01  PCSOLE45         2.734
 UP BOUNDS01  PCSOLE50         4.403
 UP BOUNDS01  PCSOLE55         7.091
 UP BOUNDS01  PCSOLE60         11.42
 UP BOUNDS01  PCSOLE65      18.39301
 UP BOUNDS01  PCSOLE70      29.62199
 UP BOUNDS01  PCSOLE75      47.70599
 FX BOUNDS01  PCSYNF00            0.
 FX BOUNDS01  PCSYNF05            0.
 FX BOUNDS01  PCSYNF10            0.
 UP BOUNDS01  PCSYNF15            .5
 UP BOUNDS01  PCSYNF20          2.69
 UP BOUNDS01  PCSYNF25          9.98
 UP BOUNDS01  PCSYNF30         24.84
 UP BOUNDS01  PCSYNF35      40.00999
 UP BOUNDS01  PCSYNF40         64.44
 UP BOUNDS01  PCSYNF45        103.78
 FX BOUNDS01  PCSHAL00            0.
 FX BOUNDS01  PCSHAL05            0.
 FX BOUNDS01  PCSHAL10            0.
 FX BOUNDS01  PCSHAL15            0.
 UP BOUNDS01  PCSHAL20            .5
 UP BOUNDS01  PCSHAL25            2.
 UP BOUNDS01  PCSHAL30          3.71
 UP BOUNDS01  PCSHAL35            6.
 UP BOUNDS01  PCSHAL40          8.29
 UP BOUNDS01  PCSHAL45           10.
 UP BOUNDS01  PCSHAL50         11.01
 UP BOUNDS01  PCSHAL55         11.54
 UP BOUNDS01  PCSHAL60         11.79
 UP BOUNDS01  PCSHAL65          11.9
 UP BOUNDS01  PCSHAL70         11.96
 UP BOUNDS01  PCSHAL75         11.99
 FX BOUNDS01  PCNAES00            0.
 FX BOUNDS01  PCNAES05            0.
 FX BOUNDS01  PCNAES10            0.
 FX BOUNDS01  PCNAES15            0.
 FX BOUNDS01  PCNAES20            0.
 UP BOUNDS01  PCNAES25            .5
 UP BOUNDS01  PCNAES30          2.69
 UP BOUNDS01  PCNAES35          9.98
 UP BOUNDS01  PCNAES40         24.84
 UP BOUNDS01  PCNAES45      40.00999
 UP BOUNDS01  PCNAES50         64.44
 UP BOUNDS01  PCNAES55        103.78
 UP BOUNDS01  PCCLDU00           4.5
 UP BOUNDS01  PCCLDU05          4.97
 UP BOUNDS01  PCCLDU10          5.49
 UP BOUNDS01  PCCLDU15          6.06
 UP BOUNDS01  PCCLDU20          6.69
 UP BOUNDS01  PCCLDU25          7.38
 UP BOUNDS01  PCCLDU30          8.15
 UP BOUNDS01  PCCLDU35            9.
 UP BOUNDS01  PCCLDU40          9.94
 UP BOUNDS01  PCCLDU45         10.97
 UP BOUNDS01  PCCLDU50         12.11
 UP BOUNDS01  PCCLDU55         13.37
 UP BOUNDS01  PCCLDU60         14.76
 UP BOUNDS01  PCCLDU65          16.3
 UP BOUNDS01  PCCLDU70           18.
 UP BOUNDS01  PCCLDU75         19.87
 FX BOUNDS01  PCPGAI00            0.
 FX BOUNDS01  PCPGAI05            0.
 FX BOUNDS01  PCPGAI10            0.
 FX BOUNDS01  PCPGAI15            0.
 FX BOUNDS01  PCPGAI20            0.
 FX BOUNDS01  PCPGAI25            0.
 FX BOUNDS01  PCPGAI30            0.
 FX BOUNDS01  PCPGAI35            0.
 FX BOUNDS01  PCPGAI40            0.
 FX BOUNDS01  PCPGAI45            0.
 FX BOUNDS01  PCPGAI50            0.
 FX BOUNDS01  PCPGAI55            0.
 FX BOUNDS01  PCPGAI60            0.
 FX BOUNDS01  PCPGAI65            0.
 FX BOUNDS01  PCPGAI70            0.
 FX BOUNDS01  PCPGAI75            0.
 UP BOUNDS01  DPLWRB20        .05757
 UP BOUNDS01  DPLWRC20        .05757
 UP BOUNDS01  DPFBRX30         .0303
 UP BOUNDS01  DPFBRX35         .1006
 UP BOUNDS01  DPFBRX40        .20523
 UP BOUNDS01  DPFBRX45        .20927
 UP BOUNDS01  DPFBRX50        .33714
 UP BOUNDS01  DPSOLE30         .0303
 UP BOUNDS01  DPSOLE35         .1006
 UP BOUNDS01  DPSOLE40        .20523
 UP BOUNDS01  DPSOLE45        .20927
 UP BOUNDS01  DPSOLE50        .33714
 UP BOUNDS01  DPSYNF20        .44238
 UP BOUNDS01  DPSYNF25       1.47258
 UP BOUNDS01  DPSYNF30       3.00172
 UP BOUNDS01  DPSYNF35       3.06434
 UP BOUNDS01  DPSYNF40       4.93486
 UP BOUNDS01  DPSHAL25          .303
 UP BOUNDS01  DPSHAL30        .34542
 UP BOUNDS01  DPSHAL35        .46258
 UP BOUNDS01  DPSHAL40        .46258
 UP BOUNDS01  DPSHAL45        .34542
 UP BOUNDS01  DPNAES30        .44238
 UP BOUNDS01  DPNAES35       1.47258
 UP BOUNDS01  DPNAES40       3.00172
 UP BOUNDS01  DPNAES45       3.06434
 UP BOUNDS01  DPNAES50       4.93486
 UP BOUNDS01  DPCLDU05        .09494
 UP BOUNDS01  DPCLDU10        .10504
 UP BOUNDS01  DPCLDU15        .11514
 UP BOUNDS01  DPCLDU20        .12726
 UP BOUNDS01  DPCLDU25        .13938
 UP BOUNDS01  DPPGAI10          1.01
 UP BOUNDS01  DPPGAI15          1.01
 UP BOUNDS01  DPPGAI20          1.01
 UP BOUNDS01  DPPGAI25          1.01
 FX BOUNDS01  DPPGAI30            0.
 FX BOUNDS01  KAPSTK00          3.75
 LO BOUNDS01  KAPSTK05       4.14458
 LO BOUNDS01  KAPSTK10       4.57595
 LO BOUNDS01  KAPSTK15       5.05222
 LO BOUNDS01  KAPSTK20       5.57806
 LO BOUNDS01  KAPSTK25       6.15864
 LO BOUNDS01  KAPSTK30       6.79963
 LO BOUNDS01  KAPSTK35       7.50735
 LO BOUNDS01  KAPSTK40       8.28872
 LO BOUNDS01  KAPSTK45       9.15142
 LO BOUNDS01  KAPSTK50      10.10391
 LO BOUNDS01  KAPSTK55      11.15553
 LO BOUNDS01  KAPSTK60      12.31661
 LO BOUNDS01  KAPSTK65      13.59854
 LO BOUNDS01  KAPSTK70      15.01389
 LO BOUNDS01  KAPSTK75      16.57655
 FX BOUNDS01  INVEST00            .2
 UP BOUNDS01  INVEST05        .74697
 UP BOUNDS01  INVEST10        .83092
 UP BOUNDS01  INVEST15         .9124
 UP BOUNDS01  INVEST20        .98246
 UP BOUNDS01  INVEST25       1.04542
 UP BOUNDS01  INVEST30       1.09623
 UP BOUNDS01  INVEST35       1.13946
 UP BOUNDS01  INVEST40       1.17309
 UP BOUNDS01  INVEST45       1.20102
 UP BOUNDS01  INVEST50       1.22384
 UP BOUNDS01  INVEST55       1.24227
 UP BOUNDS01  INVEST60       1.25699
 UP BOUNDS01  INVEST65       1.26869
 UP BOUNDS01  INVEST70       1.27796
 UP BOUNDS01  INVEST75        1.2853
 UP BOUNDS01  ENCOST00        .64701
 UP BOUNDS01  ENCOST05        .74697
 UP BOUNDS01  ENCOST10        .83092
 UP BOUNDS01  ENCOST15         .9124
 UP BOUNDS01  ENCOST20        .98246
 UP BOUNDS01  ENCOST25       1.04542
 UP BOUNDS01  ENCOST30       1.09623
 UP BOUNDS01  ENCOST35       1.13946
 UP BOUNDS01  ENCOST40       1.17309
 UP BOUNDS01  ENCOST45       1.20102
 UP BOUNDS01  ENCOST50       1.22384
 UP BOUNDS01  ENCOST55       1.24227
 UP BOUNDS01  ENCOST60       1.25699
 UP BOUNDS01  ENCOST65       1.26869
 UP BOUNDS01  ENCOST70       1.27796
 UP BOUNDS01  ENCOST75        1.2853
QUADOBJ
    KAPSTK00  KAPSTK00        10.   
    KAPSTK00  KAPSTK05         1.   
    KAPSTK00  INVEST00         1.   
    KAPSTK00  INVEST05         1.   
    KAPSTK05  KAPSTK05        20.   
    KAPSTK05  KAPSTK10         1.   
    KAPSTK05  INVEST00         1.   
    KAPSTK05  INVEST05         2.   
    KAPSTK05  INVEST10         1.   
    KAPSTK10  KAPSTK10        20.   
    KAPSTK10  KAPSTK15         1.   
    KAPSTK10  INVEST05         1.   
    KAPSTK10  INVEST10         2.   
    KAPSTK10  INVEST15         1.   
    KAPSTK15  KAPSTK15        20.   
    KAPSTK15  KAPSTK20         1.   
    KAPSTK15  INVEST10         1.   
    KAPSTK15  INVEST15         2.   
    KAPSTK15  INVEST20         1.   
    KAPSTK20  KAPSTK20        10.   
    KAPSTK20  INVEST15         1.   
    KAPSTK20  INVEST20         1.   
    INVEST00  INVEST00        10.   
    INVEST00  INVEST05         1.   
    INVEST05  INVEST05        20.   
    INVEST05  INVEST10         1.   
    INVEST10  INVEST10        20.   
    INVEST10  INVEST15         1.   
    INVEST15  INVEST15        20.   
    INVEST15  INVEST20         1.   
    INVEST20  INVEST20        10.   
    ENCOST00  ENCOST00        10.   
    ENCOST00  PCHYDR00         1.   
    ENCOST00  PCRFOS00         1.   
    ENCOST00  PCCOLL00         1.   
    ENCOST00  PCCOLH00         1.   
    ENCOST00  PCLWRA00         1.   
    ENCOST00  PCLWRB00         1.   
    ENCOST00  PCLWRC00         1.   
    ENCOST00  PCFBRX00         1.   
    ENCOST00  PCSOLE00         1.   
    ENCOST00  PCSYNF00         1.   
    ENCOST00  PCSHAL00         1.   
    ENCOST00  PCNAES00         1.   
    ENCOST00  PCCLDU00         1.   
    ENCOST00  PCPGAI00         1.   
    ENCOST00  QPETG100         1.   
    ENCOST00  QPETG200         1.   
    ENCOST00  QPETG300         1.   
    ENCOST00  QPETG400         1.   
    ENCOST00  QCOAL100         1.   
    ENCOST00  QNATU100         1.   
    ENCOST00  QNATU200         1.   
    ENCOST00  QNATU300         1.   
    ENCOST05  ENCOST05        10.   
    ENCOST05  PCHYDR05         1.   
    ENCOST05  PCRFOS05         1.   
    ENCOST05  PCCOLL05         1.   
    ENCOST05  PCCOLH05         1.   
    ENCOST05  PCLWRA05         1.   
    ENCOST05  PCLWRB05         1.   
    ENCOST05  PCLWRC05         1.   
    ENCOST05  PCFBRX05         1.   
    ENCOST05  PCSOLE05         1.   
    ENCOST05  PCSYNF05         1.   
    ENCOST05  PCSHAL05         1.   
    ENCOST05  PCNAES05         1.   
    ENCOST05  PCCLDU05         1.   
    ENCOST05  PCPGAI05         1.   
    ENCOST05  QPETG105         1.   
    ENCOST05  QPETG205         1.   
    ENCOST05  QPETG305         1.   
    ENCOST05  QPETG405         1.   
    ENCOST05  QCOAL105         1.   
    ENCOST05  QNATU105         1.   
    ENCOST05  QNATU205         1.   
    ENCOST05  QNATU305         1.   
    ENCOST10  ENCOST10        10.   
    ENCOST10  PCHYDR10         1.   
    ENCOST10  PCRFOS10         1.   
    ENCOST10  PCCOLL10         1.   
    ENCOST10  PCCOLH10         1.   
    ENCOST10  PCLWRA10         1.   
    ENCOST10  PCLWRB10         1.   
    ENCOST10  PCLWRC10         1.   
    ENCOST10  PCFBRX10         1.   
    ENCOST10  PCSOLE10         1.   
    ENCOST10  PCSYNF10         1.   
    ENCOST10  PCSHAL10         1.   
    ENCOST10  PCNAES10         1.   
    ENCOST10  PCCLDU10         1.   
    ENCOST10  PCPGAI10         1.   
    ENCOST10  QPETG110         1.   
    ENCOST10  QPETG210         1.   
    ENCOST10  QPETG310         1.   
    ENCOST10  QPETG410         1.   
    ENCOST10  QCOAL110         1.   
    ENCOST10  QNATU110         1.   
    ENCOST10  QNATU210         1.   
    ENCOST10  QNATU310         1.   
    ENCOST15  ENCOST15        10.   
    ENCOST15  PCHYDR15         1.   
    ENCOST15  PCRFOS15         1.   
    ENCOST15  PCCOLL15         1.   
    ENCOST15  PCCOLH15         1.   
    ENCOST15  PCLWRA15         1.   
    ENCOST15  PCLWRB15         1.   
    ENCOST15  PCLWRC15         1.   
    ENCOST15  PCFBRX15         1.   
    ENCOST15  PCSOLE15         1.   
    ENCOST15  PCSYNF15         1.   
    ENCOST15  PCSHAL15         1.   
    ENCOST15  PCNAES15         1.   
    ENCOST15  PCCLDU15         1.   
    ENCOST15  PCPGAI15         1.   
    ENCOST15  QPETG115         1.   
    ENCOST15  QPETG215         1.   
    ENCOST15  QPETG315         1.   
    ENCOST15  QPETG415         1.   
    ENCOST15  QCOAL115         1.   
    ENCOST15  QNATU115         1.   
    ENCOST15  QNATU215         1.   
    ENCOST15  QNATU315         1.   
    ENCOST20  ENCOST20        10.   
    ENCOST20  PCHYDR20         1.   
    ENCOST20  PCRFOS20         1.   
    ENCOST20  PCCOLL20         1.   
    ENCOST20  PCCOLH20         1.   
    ENCOST20  PCLWRA20         1.   
    ENCOST20  PCLWRB20         1.   
    ENCOST20  PCLWRC20         1.   
    ENCOST20  PCFBRX20         1.   
    ENCOST20  PCSOLE20         1.   
    ENCOST20  PCSYNF20         1.   
    ENCOST20  PCSHAL20         1.   
    ENCOST20  PCNAES20         1.   
    ENCOST20  PCCLDU20         1.   
    ENCOST20  PCPGAI20         1.   
    ENCOST20  QPETG120         1.   
    ENCOST20  QPETG220         1.   
    ENCOST20  QPETG320         1.   
    ENCOST20  QPETG420         1.   
    ENCOST20  QCOAL120         1.   
    ENCOST20  QNATU120         1.   
    ENCOST20  QNATU220         1.   
    ENCOST20  QNATU320         1.   
    ENCOST25  ENCOST25        10.   
    ENCOST25  PCHYDR25         1.   
    ENCOST25  PCRFOS25         1.   
    ENCOST25  PCCOLL25         1.   
    ENCOST25  PCCOLH25         1.   
    ENCOST25  PCLWRA25         1.   
    ENCOST25  PCLWRB25         1.   
    ENCOST25  PCLWRC25         1.   
    ENCOST25  PCFBRX25         1.   
    ENCOST25  PCSOLE25         1.   
    ENCOST25  PCSYNF25         1.   
    ENCOST25  PCSHAL25         1.   
    ENCOST25  PCNAES25         1.   
    ENCOST25  PCCLDU25         1.   
    ENCOST25  PCPGAI25         1.   
    ENCOST25  QPETG125         1.   
    ENCOST25  QPETG225         1.   
    ENCOST25  QPETG325         1.   
    ENCOST25  QPETG425         1.   
    ENCOST25  QCOAL125         1.   
    ENCOST25  QNATU125         1.   
    ENCOST25  QNATU225         1.   
    ENCOST25  QNATU325         1.   
    ENCOST30  ENCOST30        10.   
    ENCOST30  PCHYDR30         1.   
    ENCOST30  PCRFOS30         1.   
    ENCOST30  PCCOLL30         1.   
    ENCOST30  PCCOLH30         1.   
    ENCOST30  PCLWRA30         1.   
    ENCOST30  PCLWRB30         1.   
    ENCOST30  PCLWRC30         1.   
    ENCOST30  PCFBRX30         1.   
    ENCOST30  PCSOLE30         1.   
    ENCOST30  PCSYNF30         1.   
    ENCOST30  PCSHAL30         1.   
    ENCOST30  PCNAES30         1.   
    ENCOST30  PCCLDU30         1.   
    ENCOST30  PCPGAI30         1.   
    ENCOST30  QPETG130         1.   
    ENCOST30  QPETG230         1.   
    ENCOST30  QPETG330         1.   
    ENCOST30  QPETG430         1.   
    ENCOST30  QCOAL130         1.   
    ENCOST30  QNATU130         1.   
    ENCOST30  QNATU230         1.   
    ENCOST30  QNATU330         1.   
    ENCOST35  ENCOST35        10.   
    ENCOST35  PCHYDR35         1.   
    ENCOST35  PCRFOS35         1.   
    ENCOST35  PCCOLL35         1.   
    ENCOST35  PCCOLH35         1.   
    ENCOST35  PCLWRA35         1.   
    ENCOST35  PCLWRB35         1.   
    ENCOST35  PCLWRC35         1.   
    ENCOST35  PCFBRX35         1.   
    ENCOST35  PCSOLE35         1.   
    ENCOST35  PCSYNF35         1.   
    ENCOST35  PCSHAL35         1.   
    ENCOST35  PCNAES35         1.   
    ENCOST35  PCCLDU35         1.   
    ENCOST35  PCPGAI35         1.   
    ENCOST35  QPETG135         1.   
    ENCOST35  QPETG235         1.   
    ENCOST35  QPETG335         1.   
    ENCOST35  QPETG435         1.   
    ENCOST35  QCOAL135         1.   
    ENCOST35  QNATU135         1.   
    ENCOST35  QNATU235         1.   
    ENCOST35  QNATU335         1.   
    ENCOST40  ENCOST40        10.   
    ENCOST40  PCHYDR40         1.   
    ENCOST40  PCRFOS40         1.   
    ENCOST40  PCCOLL40         1.   
    ENCOST40  PCCOLH40         1.   
    ENCOST40  PCLWRA40         1.   
    ENCOST40  PCLWRB40         1.   
    ENCOST40  PCLWRC40         1.   
    ENCOST40  PCFBRX40         1.   
    ENCOST40  PCSOLE40         1.   
    ENCOST40  PCSYNF40         1.   
    ENCOST40  PCSHAL40         1.   
    ENCOST40  PCNAES40         1.   
    ENCOST40  PCCLDU40         1.   
    ENCOST40  PCPGAI40         1.   
    ENCOST40  QPETG140         1.   
    ENCOST40  QPETG240         1.   
    ENCOST40  QPETG340         1.   
    ENCOST40  QPETG440         1.   
    ENCOST40  QCOAL140         1.   
    ENCOST40  QNATU140         1.   
    ENCOST40  QNATU240         1.   
    ENCOST40  QNATU340         1.   
    ENCOST45  ENCOST45        10.   
    ENCOST45  PCHYDR45         1.   
    ENCOST45  PCRFOS45         1.   
    ENCOST45  PCCOLL45         1.   
    ENCOST45  PCCOLH45         1.   
    ENCOST45  PCLWRA45         1.   
    ENCOST45  PCLWRB45         1.   
    ENCOST45  PCLWRC45         1.   
    ENCOST45  PCFBRX45         1.   
    ENCOST45  PCSOLE45         1.   
    ENCOST45  PCSYNF45         1.   
    ENCOST45  PCSHAL45         1.   
    ENCOST45  PCNAES45         1.   
    ENCOST45  PCCLDU45         1.   
    ENCOST45  PCPGAI45         1.   
    ENCOST45  QPETG145         1.   
    ENCOST45  QPETG245         1.   
    ENCOST45  QPETG345         1.   
    ENCOST45  QPETG445         1.   
    ENCOST45  QCOAL145         1.   
    ENCOST45  QNATU145         1.   
    ENCOST45  QNATU245         1.   
    ENCOST45  QNATU345         1.   
    ENCOST50  ENCOST50        10.   
    ENCOST50  PCHYDR50         1.   
    ENCOST50  PCRFOS50         1.   
    ENCOST50  PCCOLL50         1.   
    ENCOST50  PCCOLH50         1.   
    ENCOST50  PCLWRA50         1.   
    ENCOST50  PCLWRB50         1.   
    ENCOST50  PCLWRC50         1.   
    ENCOST50  PCFBRX50         1.   
    ENCOST50  PCSOLE50         1.   
    ENCOST50  PCSYNF50         1.   
    ENCOST50  PCSHAL50         1.   
    ENCOST50  PCNAES50         1.   
    ENCOST50  PCCLDU50         1.   
    ENCOST50  PCPGAI50         1.   
    ENCOST50  QPETG150         1.   
    ENCOST50  QPETG250         1.   
    ENCOST50  QPETG350         1.   
    ENCOST50  QPETG450         1.   
    ENCOST50  QCOAL150         1.   
    ENCOST50  QNATU150         1.   
    ENCOST50  QNATU250         1.   
    ENCOST50  QNATU350         1.   
    ENCOST55  ENCOST55        10.   
    ENCOST55  PCHYDR55         1.   
    ENCOST55  PCRFOS55         1.   
    ENCOST55  PCCOLL55         1.   
    ENCOST55  PCCOLH55         1.   
    ENCOST55  PCLWRA55         1.   
    ENCOST55  PCLWRB55         1.   
    ENCOST55  PCLWRC55         1.   
    ENCOST55  PCFBRX55         1.   
    ENCOST55  PCSOLE55         1.   
    ENCOST55  PCSYNF55         1.   
    ENCOST55  PCSHAL55         1.   
    ENCOST55  PCNAES55         1.   
    ENCOST55  PCCLDU55         1.   
    ENCOST55  PCPGAI55         1.   
    ENCOST55  QPETG155         1.   
    ENCOST55  QPETG255         1.   
    ENCOST55  QPETG355         1.   
    ENCOST55  QPETG455         1.   
    ENCOST55  QCOAL155         1.   
    ENCOST55  QNATU155         1.   
    ENCOST55  QNATU255         1.   
    ENCOST55  QNATU355         1.   
    ENCOST60  ENCOST60        10.   
    ENCOST60  PCHYDR60         1.   
    ENCOST60  PCRFOS60         1.   
    ENCOST60  PCCOLL60         1.   
    ENCOST60  PCCOLH60         1.   
    ENCOST60  PCLWRA60         1.   
    ENCOST60  PCLWRB60         1.   
    ENCOST60  PCLWRC60         1.   
    ENCOST60  PCFBRX60         1.   
    ENCOST60  PCSOLE60         1.   
    ENCOST60  PCSYNF60         1.   
    ENCOST60  PCSHAL60         1.   
    ENCOST60  PCNAES60         1.   
    ENCOST60  PCCLDU60         1.   
    ENCOST60  PCPGAI60         1.   
    ENCOST60  QPETG160         1.   
    ENCOST60  QPETG260         1.   
    ENCOST60  QPETG360         1.   
    ENCOST60  QPETG460         1.   
    ENCOST60  QCOAL160         1.   
    ENCOST60  QNATU160         1.   
    ENCOST60  QNATU260         1.   
    ENCOST60  QNATU360         1.   
    ENCOST65  ENCOST65        10.   
    ENCOST65  PCHYDR65         1.   
    ENCOST65  PCRFOS65         1.   
    ENCOST65  PCCOLL65         1.   
    ENCOST65  PCCOLH65         1.   
    ENCOST65  PCLWRA65         1.   
    ENCOST65  PCLWRB65         1.   
    ENCOST65  PCLWRC65         1.   
    ENCOST65  PCFBRX65         1.   
    ENCOST65  PCSOLE65         1.   
    ENCOST65  PCSYNF65         1.   
    ENCOST65  PCSHAL65         1.   
    ENCOST65  PCNAES65         1.   
    ENCOST65  PCCLDU65         1.   
    ENCOST65  PCPGAI65         1.   
    ENCOST65  QPETG165         1.   
    ENCOST65  QPETG265         1.   
    ENCOST65  QPETG365         1.   
    ENCOST65  QPETG465         1.   
    ENCOST65  QCOAL165         1.   
    ENCOST65  QNATU165         1.   
    ENCOST65  QNATU265         1.   
    ENCOST65  QNATU365         1.   
    ENCOST70  ENCOST70        10.   
    ENCOST70  PCHYDR70         1.   
    ENCOST70  PCRFOS70         1.   
    ENCOST70  PCCOLL70         1.   
    ENCOST70  PCCOLH70         1.   
    ENCOST70  PCLWRA70         1.   
    ENCOST70  PCLWRB70         1.   
    ENCOST70  PCLWRC70         1.   
    ENCOST70  PCFBRX70         1.   
    ENCOST70  PCSOLE70         1.   
    ENCOST70  PCSYNF70         1.   
    ENCOST70  PCSHAL70         1.   
    ENCOST70  PCNAES70         1.   
    ENCOST70  PCCLDU70         1.   
    ENCOST70  PCPGAI70         1.   
    ENCOST70  QPETG170         1.   
    ENCOST70  QPETG270         1.   
    ENCOST70  QPETG370         1.   
    ENCOST70  QPETG470         1.   
    ENCOST70  QCOAL170         1.   
    ENCOST70  QNATU170         1.   
    ENCOST70  QNATU270         1.   
    ENCOST70  QNATU370         1.   
    ENCOST75  ENCOST75        10.   
    ENCOST75  PCHYDR75         1.   
    ENCOST75  PCRFOS75         1.   
    ENCOST75  PCCOLL75         1.   
    ENCOST75  PCCOLH75         1.   
    ENCOST75  PCLWRA75         1.   
    ENCOST75  PCLWRB75         1.   
    ENCOST75  PCLWRC75         1.   
    ENCOST75  PCFBRX75         1.   
    ENCOST75  PCSOLE75         1.   
    ENCOST75  PCSYNF75         1.   
    ENCOST75  PCSHAL75         1.   
    ENCOST75  PCNAES75         1.   
    ENCOST75  PCCLDU75         1.   
    ENCOST75  PCPGAI75         1.   
    ENCOST75  QPETG175         1.   
    ENCOST75  QPETG275         1.   
    ENCOST75  QPETG375         1.   
    ENCOST75  QPETG475         1.   
    ENCOST75  QCOAL175         1.   
    ENCOST75  QNATU175         1.   
    ENCOST75  QNATU275         1.   
    ENCOST75  QNATU375         1.   
    PCHYDR00  PCHYDR00        10.   
    PCHYDR00  PCRFOS00         1.   
    PCHYDR00  PCCOLL00         1.   
    PCHYDR00  PCCOLH00         1.   
    PCHYDR00  PCLWRA00         1.   
    PCHYDR00  PCLWRB00         1.   
    PCHYDR00  PCLWRC00         1.   
    PCHYDR00  PCFBRX00         1.   
    PCHYDR00  PCSOLE00         1.   
    PCHYDR00  PCSYNF00         1.   
    PCHYDR00  PCSHAL00         1.   
    PCHYDR00  PCNAES00         1.   
    PCHYDR00  PCCLDU00         1.   
    PCHYDR00  PCPGAI00         1.   
    PCHYDR00  QPETG100         1.   
    PCHYDR00  QPETG200         1.   
    PCHYDR00  QPETG300         1.   
    PCHYDR00  QPETG400         1.   
    PCHYDR00  QCOAL100         1.   
    PCHYDR00  QNATU100         1.   
    PCHYDR00  QNATU200         1.   
    PCHYDR00  QNATU300         1.   
    PCHYDR05  PCHYDR05        10.   
    PCHYDR05  PCRFOS05         1.   
    PCHYDR05  PCCOLL05         1.   
    PCHYDR05  PCCOLH05         1.   
    PCHYDR05  PCLWRA05         1.   
    PCHYDR05  PCLWRB05         1.   
    PCHYDR05  PCLWRC05         1.   
    PCHYDR05  PCFBRX05         1.   
    PCHYDR05  PCSOLE05         1.   
    PCHYDR05  PCSYNF05         1.   
    PCHYDR05  PCSHAL05         1.   
    PCHYDR05  PCNAES05         1.   
    PCHYDR05  PCCLDU05         1.   
    PCHYDR05  PCPGAI05         1.   
    PCHYDR05  QPETG105         1.   
    PCHYDR05  QPETG205         1.   
    PCHYDR05  QPETG305         1.   
    PCHYDR05  QPETG405         1.   
    PCHYDR05  QCOAL105         1.   
    PCHYDR05  QNATU105         1.   
    PCHYDR05  QNATU205         1.   
    PCHYDR05  QNATU305         1.   
    PCHYDR10  PCHYDR10        10.   
    PCHYDR10  PCRFOS10         1.   
    PCHYDR10  PCCOLL10         1.   
    PCHYDR10  PCCOLH10         1.   
    PCHYDR10  PCLWRA10         1.   
    PCHYDR10  PCLWRB10         1.   
    PCHYDR10  PCLWRC10         1.   
    PCHYDR10  PCFBRX10         1.   
    PCHYDR10  PCSOLE10         1.   
    PCHYDR10  PCSYNF10         1.   
    PCHYDR10  PCSHAL10         1.   
    PCHYDR10  PCNAES10         1.   
    PCHYDR10  PCCLDU10         1.   
    PCHYDR10  PCPGAI10         1.   
    PCHYDR10  QPETG110         1.   
    PCHYDR10  QPETG210         1.   
    PCHYDR10  QPETG310         1.   
    PCHYDR10  QPETG410         1.   
    PCHYDR10  QCOAL110         1.   
    PCHYDR10  QNATU110         1.   
    PCHYDR10  QNATU210         1.   
    PCHYDR10  QNATU310         1.   
    PCHYDR15  PCHYDR15        10.   
    PCHYDR15  PCRFOS15         1.   
    PCHYDR15  PCCOLL15         1.   
    PCHYDR15  PCCOLH15         1.   
    PCHYDR15  PCLWRA15         1.   
    PCHYDR15  PCLWRB15         1.   
    PCHYDR15  PCLWRC15         1.   
    PCHYDR15  PCFBRX15         1.   
    PCHYDR15  PCSOLE15         1.   
    PCHYDR15  PCSYNF15         1.   
    PCHYDR15  PCSHAL15         1.   
    PCHYDR15  PCNAES15         1.   
    PCHYDR15  PCCLDU15         1.   
    PCHYDR15  PCPGAI15         1.   
    PCHYDR15  QPETG115         1.   
    PCHYDR15  QPETG215         1.   
    PCHYDR15  QPETG315         1.   
    PCHYDR15  QPETG415         1.   
    PCHYDR15  QCOAL115         1.   
    PCHYDR15  QNATU115         1.   
    PCHYDR15  QNATU215         1.   
    PCHYDR15  QNATU315         1.   
    PCHYDR20  PCHYDR20        10.   
    PCHYDR20  PCRFOS20         1.   
    PCHYDR20  PCCOLL20         1.   
    PCHYDR20  PCCOLH20         1.   
    PCHYDR20  PCLWRA20         1.   
    PCHYDR20  PCLWRB20         1.   
    PCHYDR20  PCLWRC20         1.   
    PCHYDR20  PCFBRX20         1.   
    PCHYDR20  PCSOLE20         1.   
    PCHYDR20  PCSYNF20         1.   
    PCHYDR20  PCSHAL20         1.   
    PCHYDR20  PCNAES20         1.   
    PCHYDR20  PCCLDU20         1.   
    PCHYDR20  PCPGAI20         1.   
    PCHYDR20  QPETG120         1.   
    PCHYDR20  QPETG220         1.   
    PCHYDR20  QPETG320         1.   
    PCHYDR20  QPETG420         1.   
    PCHYDR20  QCOAL120         1.   
    PCHYDR20  QNATU120         1.   
    PCHYDR20  QNATU220         1.   
    PCHYDR20  QNATU320         1.   
    PCHYDR25  PCHYDR25        10.   
    PCHYDR25  PCRFOS25         1.   
    PCHYDR25  PCCOLL25         1.   
    PCHYDR25  PCCOLH25         1.   
    PCHYDR25  PCLWRA25         1.   
    PCHYDR25  PCLWRB25         1.   
    PCHYDR25  PCLWRC25         1.   
    PCHYDR25  PCFBRX25         1.   
    PCHYDR25  PCSOLE25         1.   
    PCHYDR25  PCSYNF25         1.   
    PCHYDR25  PCSHAL25         1.   
    PCHYDR25  PCNAES25         1.   
    PCHYDR25  PCCLDU25         1.   
    PCHYDR25  PCPGAI25         1.   
    PCHYDR25  QPETG125         1.   
    PCHYDR25  QPETG225         1.   
    PCHYDR25  QPETG325         1.   
    PCHYDR25  QPETG425         1.   
    PCHYDR25  QCOAL125         1.   
    PCHYDR25  QNATU125         1.   
    PCHYDR25  QNATU225         1.   
    PCHYDR25  QNATU325         1.   
    PCHYDR30  PCHYDR30        10.   
    PCHYDR30  PCRFOS30         1.   
    PCHYDR30  PCCOLL30         1.   
    PCHYDR30  PCCOLH30         1.   
    PCHYDR30  PCLWRA30         1.   
    PCHYDR30  PCLWRB30         1.   
    PCHYDR30  PCLWRC30         1.   
    PCHYDR30  PCFBRX30         1.   
    PCHYDR30  PCSOLE30         1.   
    PCHYDR30  PCSYNF30         1.   
    PCHYDR30  PCSHAL30         1.   
    PCHYDR30  PCNAES30         1.   
    PCHYDR30  PCCLDU30         1.   
    PCHYDR30  PCPGAI30         1.   
    PCHYDR30  QPETG130         1.   
    PCHYDR30  QPETG230         1.   
    PCHYDR30  QPETG330         1.   
    PCHYDR30  QPETG430         1.   
    PCHYDR30  QCOAL130         1.   
    PCHYDR30  QNATU130         1.   
    PCHYDR30  QNATU230         1.   
    PCHYDR30  QNATU330         1.   
    PCHYDR35  PCHYDR35        10.   
    PCHYDR35  PCRFOS35         1.   
    PCHYDR35  PCCOLL35         1.   
    PCHYDR35  PCCOLH35         1.   
    PCHYDR35  PCLWRA35         1.   
    PCHYDR35  PCLWRB35         1.   
    PCHYDR35  PCLWRC35         1.   
    PCHYDR35  PCFBRX35         1.   
    PCHYDR35  PCSOLE35         1.   
    PCHYDR35  PCSYNF35         1.   
    PCHYDR35  PCSHAL35         1.   
    PCHYDR35  PCNAES35         1.   
    PCHYDR35  PCCLDU35         1.   
    PCHYDR35  PCPGAI35         1.   
    PCHYDR35  QPETG135         1.   
    PCHYDR35  QPETG235         1.   
    PCHYDR35  QPETG335         1.   
    PCHYDR35  QPETG435         1.   
    PCHYDR35  QCOAL135         1.   
    PCHYDR35  QNATU135         1.   
    PCHYDR35  QNATU235         1.   
    PCHYDR35  QNATU335         1.   
    PCHYDR40  PCHYDR40        10.   
    PCHYDR40  PCRFOS40         1.   
    PCHYDR40  PCCOLL40         1.   
    PCHYDR40  PCCOLH40         1.   
    PCHYDR40  PCLWRA40         1.   
    PCHYDR40  PCLWRB40         1.   
    PCHYDR40  PCLWRC40         1.   
    PCHYDR40  PCFBRX40         1.   
    PCHYDR40  PCSOLE40         1.   
    PCHYDR40  PCSYNF40         1.   
    PCHYDR40  PCSHAL40         1.   
    PCHYDR40  PCNAES40         1.   
    PCHYDR40  PCCLDU40         1.   
    PCHYDR40  PCPGAI40         1.   
    PCHYDR40  QPETG140         1.   
    PCHYDR40  QPETG240         1.   
    PCHYDR40  QPETG340         1.   
    PCHYDR40  QPETG440         1.   
    PCHYDR40  QCOAL140         1.   
    PCHYDR40  QNATU140         1.   
    PCHYDR40  QNATU240         1.   
    PCHYDR40  QNATU340         1.   
    PCHYDR45  PCHYDR45        10.   
    PCHYDR45  PCRFOS45         1.   
    PCHYDR45  PCCOLL45         1.   
    PCHYDR45  PCCOLH45         1.   
    PCHYDR45  PCLWRA45         1.   
    PCHYDR45  PCLWRB45         1.   
    PCHYDR45  PCLWRC45         1.   
    PCHYDR45  PCFBRX45         1.   
    PCHYDR45  PCSOLE45         1.   
    PCHYDR45  PCSYNF45         1.   
    PCHYDR45  PCSHAL45         1.   
    PCHYDR45  PCNAES45         1.   
    PCHYDR45  PCCLDU45         1.   
    PCHYDR45  PCPGAI45         1.   
    PCHYDR45  QPETG145         1.   
    PCHYDR45  QPETG245         1.   
    PCHYDR45  QPETG345         1.   
    PCHYDR45  QPETG445         1.   
    PCHYDR45  QCOAL145         1.   
    PCHYDR45  QNATU145         1.   
    PCHYDR45  QNATU245         1.   
    PCHYDR45  QNATU345         1.   
    PCHYDR50  PCHYDR50        10.   
    PCHYDR50  PCRFOS50         1.   
    PCHYDR50  PCCOLL50         1.   
    PCHYDR50  PCCOLH50         1.   
    PCHYDR50  PCLWRA50         1.   
    PCHYDR50  PCLWRB50         1.   
    PCHYDR50  PCLWRC50         1.   
    PCHYDR50  PCFBRX50         1.   
    PCHYDR50  PCSOLE50         1.   
    PCHYDR50  PCSYNF50         1.   
    PCHYDR50  PCSHAL50         1.   
    PCHYDR50  PCNAES50         1.   
    PCHYDR50  PCCLDU50         1.   
    PCHYDR50  PCPGAI50         1.   
    PCHYDR50  QPETG150         1.   
    PCHYDR50  QPETG250         1.   
    PCHYDR50  QPETG350         1.   
    PCHYDR50  QPETG450         1.   
    PCHYDR50  QCOAL150         1.   
    PCHYDR50  QNATU150         1.   
    PCHYDR50  QNATU250         1.   
    PCHYDR50  QNATU350         1.   
    PCHYDR55  PCHYDR55        10.   
    PCHYDR55  PCRFOS55         1.   
    PCHYDR55  PCCOLL55         1.   
    PCHYDR55  PCCOLH55         1.   
    PCHYDR55  PCLWRA55         1.   
    PCHYDR55  PCLWRB55         1.   
    PCHYDR55  PCLWRC55         1.   
    PCHYDR55  PCFBRX55         1.   
    PCHYDR55  PCSOLE55         1.   
    PCHYDR55  PCSYNF55         1.   
    PCHYDR55  PCSHAL55         1.   
    PCHYDR55  PCNAES55         1.   
    PCHYDR55  PCCLDU55         1.   
    PCHYDR55  PCPGAI55         1.   
    PCHYDR55  QPETG155         1.   
    PCHYDR55  QPETG255         1.   
    PCHYDR55  QPETG355         1.   
    PCHYDR55  QPETG455         1.   
    PCHYDR55  QCOAL155         1.   
    PCHYDR55  QNATU155         1.   
    PCHYDR55  QNATU255         1.   
    PCHYDR55  QNATU355         1.   
    PCHYDR60  PCHYDR60        10.   
    PCHYDR60  PCRFOS60         1.   
    PCHYDR60  PCCOLL60         1.   
    PCHYDR60  PCCOLH60         1.   
    PCHYDR60  PCLWRA60         1.   
    PCHYDR60  PCLWRB60         1.   
    PCHYDR60  PCLWRC60         1.   
    PCHYDR60  PCFBRX60         1.   
    PCHYDR60  PCSOLE60         1.   
    PCHYDR60  PCSYNF60         1.   
    PCHYDR60  PCSHAL60         1.   
    PCHYDR60  PCNAES60         1.   
    PCHYDR60  PCCLDU60         1.   
    PCHYDR60  PCPGAI60         1.   
    PCHYDR60  QPETG160         1.   
    PCHYDR60  QPETG260         1.   
    PCHYDR60  QPETG360         1.   
    PCHYDR60  QPETG460         1.   
    PCHYDR60  QCOAL160         1.   
    PCHYDR60  QNATU160         1.   
    PCHYDR60  QNATU260         1.   
    PCHYDR60  QNATU360         1.   
    PCHYDR65  PCHYDR65        10.   
    PCHYDR65  PCRFOS65         1.   
    PCHYDR65  PCCOLL65         1.   
    PCHYDR65  PCCOLH65         1.   
    PCHYDR65  PCLWRA65         1.   
    PCHYDR65  PCLWRB65         1.   
    PCHYDR65  PCLWRC65         1.   
    PCHYDR65  PCFBRX65         1.   
    PCHYDR65  PCSOLE65         1.   
    PCHYDR65  PCSYNF65         1.   
    PCHYDR65  PCSHAL65         1.   
    PCHYDR65  PCNAES65         1.   
    PCHYDR65  PCCLDU65         1.   
    PCHYDR65  PCPGAI65         1.   
    PCHYDR65  QPETG165         1.   
    PCHYDR65  QPETG265         1.   
    PCHYDR65  QPETG365         1.   
    PCHYDR65  QPETG465         1.   
    PCHYDR65  QCOAL165         1.   
    PCHYDR65  QNATU165         1.   
    PCHYDR65  QNATU265         1.   
    PCHYDR65  QNATU365         1.   
    PCHYDR70  PCHYDR70        10.   
    PCHYDR70  PCRFOS70         1.   
    PCHYDR70  PCCOLL70         1.   
    PCHYDR70  PCCOLH70         1.   
    PCHYDR70  PCLWRA70         1.   
    PCHYDR70  PCLWRB70         1.   
    PCHYDR70  PCLWRC70         1.   
    PCHYDR70  PCFBRX70         1.   
    PCHYDR70  PCSOLE70         1.   
    PCHYDR70  PCSYNF70         1.   
    PCHYDR70  PCSHAL70         1.   
    PCHYDR70  PCNAES70         1.   
    PCHYDR70  PCCLDU70         1.   
    PCHYDR70  PCPGAI70         1.   
    PCHYDR70  QPETG170         1.   
    PCHYDR70  QPETG270         1.   
    PCHYDR70  QPETG370         1.   
    PCHYDR70  QPETG470         1.   
    PCHYDR70  QCOAL170         1.   
    PCHYDR70  QNATU170         1.   
    PCHYDR70  QNATU270         1.   
    PCHYDR70  QNATU370         1.   
    PCHYDR75  PCHYDR75        10.   
    PCHYDR75  PCRFOS75         1.   
    PCHYDR75  PCCOLL75         1.   
    PCHYDR75  PCCOLH75         1.   
    PCHYDR75  PCLWRA75         1.   
    PCHYDR75  PCLWRB75         1.   
    PCHYDR75  PCLWRC75         1.   
    PCHYDR75  PCFBRX75         1.   
    PCHYDR75  PCSOLE75         1.   
    PCHYDR75  PCSYNF75         1.   
    PCHYDR75  PCSHAL75         1.   
    PCHYDR75  PCNAES75         1.   
    PCHYDR75  PCCLDU75         1.   
    PCHYDR75  PCPGAI75         1.   
    PCHYDR75  QPETG175         1.   
    PCHYDR75  QPETG275         1.   
    PCHYDR75  QPETG375         1.   
    PCHYDR75  QPETG475         1.   
    PCHYDR75  QCOAL175         1.   
    PCHYDR75  QNATU175         1.   
    PCHYDR75  QNATU275         1.   
    PCHYDR75  QNATU375         1.   
    PCRFOS00  PCRFOS00        10.   
    PCRFOS00  PCCOLL00         1.   
    PCRFOS00  PCCOLH00         1.   
    PCRFOS00  PCLWRA00         1.   
    PCRFOS00  PCLWRB00         1.   
    PCRFOS00  PCLWRC00         1.   
    PCRFOS00  PCFBRX00         1.   
    PCRFOS00  PCSOLE00         1.   
    PCRFOS00  PCSYNF00         1.   
    PCRFOS00  PCSHAL00         1.   
    PCRFOS00  PCNAES00         1.   
    PCRFOS00  PCCLDU00         1.   
    PCRFOS00  PCPGAI00         1.   
    PCRFOS00  QPETG100         1.   
    PCRFOS00  QPETG200         1.   
    PCRFOS00  QPETG300         1.   
    PCRFOS00  QPETG400         1.   
    PCRFOS00  QCOAL100         1.   
    PCRFOS00  QNATU100         1.   
    PCRFOS00  QNATU200         1.   
    PCRFOS00  QNATU300         1.   
    PCRFOS05  PCRFOS05        10.   
    PCRFOS05  PCCOLL05         1.   
    PCRFOS05  PCCOLH05         1.   
    PCRFOS05  PCLWRA05         1.   
    PCRFOS05  PCLWRB05         1.   
    PCRFOS05  PCLWRC05         1.   
    PCRFOS05  PCFBRX05         1.   
    PCRFOS05  PCSOLE05         1.   
    PCRFOS05  PCSYNF05         1.   
    PCRFOS05  PCSHAL05         1.   
    PCRFOS05  PCNAES05         1.   
    PCRFOS05  PCCLDU05         1.   
    PCRFOS05  PCPGAI05         1.   
    PCRFOS05  QPETG105         1.   
    PCRFOS05  QPETG205         1.   
    PCRFOS05  QPETG305         1.   
    PCRFOS05  QPETG405         1.   
    PCRFOS05  QCOAL105         1.   
    PCRFOS05  QNATU105         1.   
    PCRFOS05  QNATU205         1.   
    PCRFOS05  QNATU305         1.   
    PCRFOS10  PCRFOS10        10.   
    PCRFOS10  PCCOLL10         1.   
    PCRFOS10  PCCOLH10         1.   
    PCRFOS10  PCLWRA10         1.   
    PCRFOS10  PCLWRB10         1.   
    PCRFOS10  PCLWRC10         1.   
    PCRFOS10  PCFBRX10         1.   
    PCRFOS10  PCSOLE10         1.   
    PCRFOS10  PCSYNF10         1.   
    PCRFOS10  PCSHAL10         1.   
    PCRFOS10  PCNAES10         1.   
    PCRFOS10  PCCLDU10         1.   
    PCRFOS10  PCPGAI10         1.   
    PCRFOS10  QPETG110         1.   
    PCRFOS10  QPETG210         1.   
    PCRFOS10  QPETG310         1.   
    PCRFOS10  QPETG410         1.   
    PCRFOS10  QCOAL110         1.   
    PCRFOS10  QNATU110         1.   
    PCRFOS10  QNATU210         1.   
    PCRFOS10  QNATU310         1.   
    PCRFOS15  PCRFOS15        10.   
    PCRFOS15  PCCOLL15         1.   
    PCRFOS15  PCCOLH15         1.   
    PCRFOS15  PCLWRA15         1.   
    PCRFOS15  PCLWRB15         1.   
    PCRFOS15  PCLWRC15         1.   
    PCRFOS15  PCFBRX15         1.   
    PCRFOS15  PCSOLE15         1.   
    PCRFOS15  PCSYNF15         1.   
    PCRFOS15  PCSHAL15         1.   
    PCRFOS15  PCNAES15         1.   
    PCRFOS15  PCCLDU15         1.   
    PCRFOS15  PCPGAI15         1.   
    PCRFOS15  QPETG115         1.   
    PCRFOS15  QPETG215         1.   
    PCRFOS15  QPETG315         1.   
    PCRFOS15  QPETG415         1.   
    PCRFOS15  QCOAL115         1.   
    PCRFOS15  QNATU115         1.   
    PCRFOS15  QNATU215         1.   
    PCRFOS15  QNATU315         1.   
    PCRFOS20  PCRFOS20        10.   
    PCRFOS20  PCCOLL20         1.   
    PCRFOS20  PCCOLH20         1.   
    PCRFOS20  PCLWRA20         1.   
    PCRFOS20  PCLWRB20         1.   
    PCRFOS20  PCLWRC20         1.   
    PCRFOS20  PCFBRX20         1.   
    PCRFOS20  PCSOLE20         1.   
    PCRFOS20  PCSYNF20         1.   
    PCRFOS20  PCSHAL20         1.   
    PCRFOS20  PCNAES20         1.   
    PCRFOS20  PCCLDU20         1.   
    PCRFOS20  PCPGAI20         1.   
    PCRFOS20  QPETG120         1.   
    PCRFOS20  QPETG220         1.   
    PCRFOS20  QPETG320         1.   
    PCRFOS20  QPETG420         1.   
    PCRFOS20  QCOAL120         1.   
    PCRFOS20  QNATU120         1.   
    PCRFOS20  QNATU220         1.   
    PCRFOS20  QNATU320         1.   
    PCRFOS25  PCRFOS25        10.   
    PCRFOS25  PCCOLL25         1.   
    PCRFOS25  PCCOLH25         1.   
    PCRFOS25  PCLWRA25         1.   
    PCRFOS25  PCLWRB25         1.   
    PCRFOS25  PCLWRC25         1.   
    PCRFOS25  PCFBRX25         1.   
    PCRFOS25  PCSOLE25         1.   
    PCRFOS25  PCSYNF25         1.   
    PCRFOS25  PCSHAL25         1.   
    PCRFOS25  PCNAES25         1.   
    PCRFOS25  PCCLDU25         1.   
    PCRFOS25  PCPGAI25         1.   
    PCRFOS25  QPETG125         1.   
    PCRFOS25  QPETG225         1.   
    PCRFOS25  QPETG325         1.   
    PCRFOS25  QPETG425         1.   
    PCRFOS25  QCOAL125         1.   
    PCRFOS25  QNATU125         1.   
    PCRFOS25  QNATU225         1.   
    PCRFOS25  QNATU325         1.   
    PCRFOS30  PCRFOS30        10.   
    PCRFOS30  PCCOLL30         1.   
    PCRFOS30  PCCOLH30         1.   
    PCRFOS30  PCLWRA30         1.   
    PCRFOS30  PCLWRB30         1.   
    PCRFOS30  PCLWRC30         1.   
    PCRFOS30  PCFBRX30         1.   
    PCRFOS30  PCSOLE30         1.   
    PCRFOS30  PCSYNF30         1.   
    PCRFOS30  PCSHAL30         1.   
    PCRFOS30  PCNAES30         1.   
    PCRFOS30  PCCLDU30         1.   
    PCRFOS30  PCPGAI30         1.   
    PCRFOS30  QPETG130         1.   
    PCRFOS30  QPETG230         1.   
    PCRFOS30  QPETG330         1.   
    PCRFOS30  QPETG430         1.   
    PCRFOS30  QCOAL130         1.   
    PCRFOS30  QNATU130         1.   
    PCRFOS30  QNATU230         1.   
    PCRFOS30  QNATU330         1.   
    PCRFOS35  PCRFOS35        10.   
    PCRFOS35  PCCOLL35         1.   
    PCRFOS35  PCCOLH35         1.   
    PCRFOS35  PCLWRA35         1.   
    PCRFOS35  PCLWRB35         1.   
    PCRFOS35  PCLWRC35         1.   
    PCRFOS35  PCFBRX35         1.   
    PCRFOS35  PCSOLE35         1.   
    PCRFOS35  PCSYNF35         1.   
    PCRFOS35  PCSHAL35         1.   
    PCRFOS35  PCNAES35         1.   
    PCRFOS35  PCCLDU35         1.   
    PCRFOS35  PCPGAI35         1.   
    PCRFOS35  QPETG135         1.   
    PCRFOS35  QPETG235         1.   
    PCRFOS35  QPETG335         1.   
    PCRFOS35  QPETG435         1.   
    PCRFOS35  QCOAL135         1.   
    PCRFOS35  QNATU135         1.   
    PCRFOS35  QNATU235         1.   
    PCRFOS35  QNATU335         1.   
    PCRFOS40  PCRFOS40        10.   
    PCRFOS40  PCCOLL40         1.   
    PCRFOS40  PCCOLH40         1.   
    PCRFOS40  PCLWRA40         1.   
    PCRFOS40  PCLWRB40         1.   
    PCRFOS40  PCLWRC40         1.   
    PCRFOS40  PCFBRX40         1.   
    PCRFOS40  PCSOLE40         1.   
    PCRFOS40  PCSYNF40         1.   
    PCRFOS40  PCSHAL40         1.   
    PCRFOS40  PCNAES40         1.   
    PCRFOS40  PCCLDU40         1.   
    PCRFOS40  PCPGAI40         1.   
    PCRFOS40  QPETG140         1.   
    PCRFOS40  QPETG240         1.   
    PCRFOS40  QPETG340         1.   
    PCRFOS40  QPETG440         1.   
    PCRFOS40  QCOAL140         1.   
    PCRFOS40  QNATU140         1.   
    PCRFOS40  QNATU240         1.   
    PCRFOS40  QNATU340         1.   
    PCRFOS45  PCRFOS45        10.   
    PCRFOS45  PCCOLL45         1.   
    PCRFOS45  PCCOLH45         1.   
    PCRFOS45  PCLWRA45         1.   
    PCRFOS45  PCLWRB45         1.   
    PCRFOS45  PCLWRC45         1.   
    PCRFOS45  PCFBRX45         1.   
    PCRFOS45  PCSOLE45         1.   
    PCRFOS45  PCSYNF45         1.   
    PCRFOS45  PCSHAL45         1.   
    PCRFOS45  PCNAES45         1.   
    PCRFOS45  PCCLDU45         1.   
    PCRFOS45  PCPGAI45         1.   
    PCRFOS45  QPETG145         1.   
    PCRFOS45  QPETG245         1.   
    PCRFOS45  QPETG345         1.   
    PCRFOS45  QPETG445         1.   
    PCRFOS45  QCOAL145         1.   
    PCRFOS45  QNATU145         1.   
    PCRFOS45  QNATU245         1.   
    PCRFOS45  QNATU345         1.   
    PCRFOS50  PCRFOS50        10.   
    PCRFOS50  PCCOLL50         1.   
    PCRFOS50  PCCOLH50         1.   
    PCRFOS50  PCLWRA50         1.   
    PCRFOS50  PCLWRB50         1.   
    PCRFOS50  PCLWRC50         1.   
    PCRFOS50  PCFBRX50         1.   
    PCRFOS50  PCSOLE50         1.   
    PCRFOS50  PCSYNF50         1.   
    PCRFOS50  PCSHAL50         1.   
    PCRFOS50  PCNAES50         1.   
    PCRFOS50  PCCLDU50         1.   
    PCRFOS50  PCPGAI50         1.   
    PCRFOS50  QPETG150         1.   
    PCRFOS50  QPETG250         1.   
    PCRFOS50  QPETG350         1.   
    PCRFOS50  QPETG450         1.   
    PCRFOS50  QCOAL150         1.   
    PCRFOS50  QNATU150         1.   
    PCRFOS50  QNATU250         1.   
    PCRFOS50  QNATU350         1.   
    PCRFOS55  PCRFOS55        10.   
    PCRFOS55  PCCOLL55         1.   
    PCRFOS55  PCCOLH55         1.   
    PCRFOS55  PCLWRA55         1.   
    PCRFOS55  PCLWRB55         1.   
    PCRFOS55  PCLWRC55         1.   
    PCRFOS55  PCFBRX55         1.   
    PCRFOS55  PCSOLE55         1.   
    PCRFOS55  PCSYNF55         1.   
    PCRFOS55  PCSHAL55         1.   
    PCRFOS55  PCNAES55         1.   
    PCRFOS55  PCCLDU55         1.   
    PCRFOS55  PCPGAI55         1.   
    PCRFOS55  QPETG155         1.   
    PCRFOS55  QPETG255         1.   
    PCRFOS55  QPETG355         1.   
    PCRFOS55  QPETG455         1.   
    PCRFOS55  QCOAL155         1.   
    PCRFOS55  QNATU155         1.   
    PCRFOS55  QNATU255         1.   
    PCRFOS55  QNATU355         1.   
    PCRFOS60  PCRFOS60        10.   
    PCRFOS60  PCCOLL60         1.   
    PCRFOS60  PCCOLH60         1.   
    PCRFOS60  PCLWRA60         1.   
    PCRFOS60  PCLWRB60         1.   
    PCRFOS60  PCLWRC60         1.   
    PCRFOS60  PCFBRX60         1.   
    PCRFOS60  PCSOLE60         1.   
    PCRFOS60  PCSYNF60         1.   
    PCRFOS60  PCSHAL60         1.   
    PCRFOS60  PCNAES60         1.   
    PCRFOS60  PCCLDU60         1.   
    PCRFOS60  PCPGAI60         1.   
    PCRFOS60  QPETG160         1.   
    PCRFOS60  QPETG260         1.   
    PCRFOS60  QPETG360         1.   
    PCRFOS60  QPETG460         1.   
    PCRFOS60  QCOAL160         1.   
    PCRFOS60  QNATU160         1.   
    PCRFOS60  QNATU260         1.   
    PCRFOS60  QNATU360         1.   
    PCRFOS65  PCRFOS65        10.   
    PCRFOS65  PCCOLL65         1.   
    PCRFOS65  PCCOLH65         1.   
    PCRFOS65  PCLWRA65         1.   
    PCRFOS65  PCLWRB65         1.   
    PCRFOS65  PCLWRC65         1.   
    PCRFOS65  PCFBRX65         1.   
    PCRFOS65  PCSOLE65         1.   
    PCRFOS65  PCSYNF65         1.   
    PCRFOS65  PCSHAL65         1.   
    PCRFOS65  PCNAES65         1.   
    PCRFOS65  PCCLDU65         1.   
    PCRFOS65  PCPGAI65         1.   
    PCRFOS65  QPETG165         1.   
    PCRFOS65  QPETG265         1.   
    PCRFOS65  QPETG365         1.   
    PCRFOS65  QPETG465         1.   
    PCRFOS65  QCOAL165         1.   
    PCRFOS65  QNATU165         1.   
    PCRFOS65  QNATU265         1.   
    PCRFOS65  QNATU365         1.   
    PCRFOS70  PCRFOS70        10.   
    PCRFOS70  PCCOLL70         1.   
    PCRFOS70  PCCOLH70         1.   
    PCRFOS70  PCLWRA70         1.   
    PCRFOS70  PCLWRB70         1.   
    PCRFOS70  PCLWRC70         1.   
    PCRFOS70  PCFBRX70         1.   
    PCRFOS70  PCSOLE70         1.   
    PCRFOS70  PCSYNF70         1.   
    PCRFOS70  PCSHAL70         1.   
    PCRFOS70  PCNAES70         1.   
    PCRFOS70  PCCLDU70         1.   
    PCRFOS70  PCPGAI70         1.   
    PCRFOS70  QPETG170         1.   
    PCRFOS70  QPETG270         1.   
    PCRFOS70  QPETG370         1.   
    PCRFOS70  QPETG470         1.   
    PCRFOS70  QCOAL170         1.   
    PCRFOS70  QNATU170         1.   
    PCRFOS70  QNATU270         1.   
    PCRFOS70  QNATU370         1.   
    PCRFOS75  PCRFOS75        10.   
    PCRFOS75  PCCOLL75         1.   
    PCRFOS75  PCCOLH75         1.   
    PCRFOS75  PCLWRA75         1.   
    PCRFOS75  PCLWRB75         1.   
    PCRFOS75  PCLWRC75         1.   
    PCRFOS75  PCFBRX75         1.   
    PCRFOS75  PCSOLE75         1.   
    PCRFOS75  PCSYNF75         1.   
    PCRFOS75  PCSHAL75         1.   
    PCRFOS75  PCNAES75         1.   
    PCRFOS75  PCCLDU75         1.   
    PCRFOS75  PCPGAI75         1.   
    PCRFOS75  QPETG175         1.   
    PCRFOS75  QPETG275         1.   
    PCRFOS75  QPETG375         1.   
    PCRFOS75  QPETG475         1.   
    PCRFOS75  QCOAL175         1.   
    PCRFOS75  QNATU175         1.   
    PCRFOS75  QNATU275         1.   
    PCRFOS75  QNATU375         1.   
    PCCOLL00  PCCOLL00        10.   
    PCCOLL00  PCCOLH00         1.   
    PCCOLL00  PCLWRA00         1.   
    PCCOLL00  PCLWRB00         1.   
    PCCOLL00  PCLWRC00         1.   
    PCCOLL00  PCFBRX00         1.   
    PCCOLL00  PCSOLE00         1.   
    PCCOLL00  PCSYNF00         1.   
    PCCOLL00  PCSHAL00         1.   
    PCCOLL00  PCNAES00         1.   
    PCCOLL00  PCCLDU00         1.   
    PCCOLL00  PCPGAI00         1.   
    PCCOLL00  QPETG100         1.   
    PCCOLL00  QPETG200         1.   
    PCCOLL00  QPETG300         1.   
    PCCOLL00  QPETG400         1.   
    PCCOLL00  QCOAL100         1.   
    PCCOLL00  QNATU100         1.   
    PCCOLL00  QNATU200         1.   
    PCCOLL00  QNATU300         1.   
    PCCOLL05  PCCOLL05        10.   
    PCCOLL05  PCCOLH05         1.   
    PCCOLL05  PCLWRA05         1.   
    PCCOLL05  PCLWRB05         1.   
    PCCOLL05  PCLWRC05         1.   
    PCCOLL05  PCFBRX05         1.   
    PCCOLL05  PCSOLE05         1.   
    PCCOLL05  PCSYNF05         1.   
    PCCOLL05  PCSHAL05         1.   
    PCCOLL05  PCNAES05         1.   
    PCCOLL05  PCCLDU05         1.   
    PCCOLL05  PCPGAI05         1.   
    PCCOLL05  QPETG105         1.   
    PCCOLL05  QPETG205         1.   
    PCCOLL05  QPETG305         1.   
    PCCOLL05  QPETG405         1.   
    PCCOLL05  QCOAL105         1.   
    PCCOLL05  QNATU105         1.   
    PCCOLL05  QNATU205         1.   
    PCCOLL05  QNATU305         1.   
    PCCOLL10  PCCOLL10        10.   
    PCCOLL10  PCCOLH10         1.   
    PCCOLL10  PCLWRA10         1.   
    PCCOLL10  PCLWRB10         1.   
    PCCOLL10  PCLWRC10         1.   
    PCCOLL10  PCFBRX10         1.   
    PCCOLL10  PCSOLE10         1.   
    PCCOLL10  PCSYNF10         1.   
    PCCOLL10  PCSHAL10         1.   
    PCCOLL10  PCNAES10         1.   
    PCCOLL10  PCCLDU10         1.   
    PCCOLL10  PCPGAI10         1.   
    PCCOLL10  QPETG110         1.   
    PCCOLL10  QPETG210         1.   
    PCCOLL10  QPETG310         1.   
    PCCOLL10  QPETG410         1.   
    PCCOLL10  QCOAL110         1.   
    PCCOLL10  QNATU110         1.   
    PCCOLL10  QNATU210         1.   
    PCCOLL10  QNATU310         1.   
    PCCOLL15  PCCOLL15        10.   
    PCCOLL15  PCCOLH15         1.   
    PCCOLL15  PCLWRA15         1.   
    PCCOLL15  PCLWRB15         1.   
    PCCOLL15  PCLWRC15         1.   
    PCCOLL15  PCFBRX15         1.   
    PCCOLL15  PCSOLE15         1.   
    PCCOLL15  PCSYNF15         1.   
    PCCOLL15  PCSHAL15         1.   
    PCCOLL15  PCNAES15         1.   
    PCCOLL15  PCCLDU15         1.   
    PCCOLL15  PCPGAI15         1.   
    PCCOLL15  QPETG115         1.   
    PCCOLL15  QPETG215         1.   
    PCCOLL15  QPETG315         1.   
    PCCOLL15  QPETG415         1.   
    PCCOLL15  QCOAL115         1.   
    PCCOLL15  QNATU115         1.   
    PCCOLL15  QNATU215         1.   
    PCCOLL15  QNATU315         1.   
    PCCOLL20  PCCOLL20        10.   
    PCCOLL20  PCCOLH20         1.   
    PCCOLL20  PCLWRA20         1.   
    PCCOLL20  PCLWRB20         1.   
    PCCOLL20  PCLWRC20         1.   
    PCCOLL20  PCFBRX20         1.   
    PCCOLL20  PCSOLE20         1.   
    PCCOLL20  PCSYNF20         1.   
    PCCOLL20  PCSHAL20         1.   
    PCCOLL20  PCNAES20         1.   
    PCCOLL20  PCCLDU20         1.   
    PCCOLL20  PCPGAI20         1.   
    PCCOLL20  QPETG120         1.   
    PCCOLL20  QPETG220         1.   
    PCCOLL20  QPETG320         1.   
    PCCOLL20  QPETG420         1.   
    PCCOLL20  QCOAL120         1.   
    PCCOLL20  QNATU120         1.   
    PCCOLL20  QNATU220         1.   
    PCCOLL20  QNATU320         1.   
    PCCOLL25  PCCOLL25        10.   
    PCCOLL25  PCCOLH25         1.   
    PCCOLL25  PCLWRA25         1.   
    PCCOLL25  PCLWRB25         1.   
    PCCOLL25  PCLWRC25         1.   
    PCCOLL25  PCFBRX25         1.   
    PCCOLL25  PCSOLE25         1.   
    PCCOLL25  PCSYNF25         1.   
    PCCOLL25  PCSHAL25         1.   
    PCCOLL25  PCNAES25         1.   
    PCCOLL25  PCCLDU25         1.   
    PCCOLL25  PCPGAI25         1.   
    PCCOLL25  QPETG125         1.   
    PCCOLL25  QPETG225         1.   
    PCCOLL25  QPETG325         1.   
    PCCOLL25  QPETG425         1.   
    PCCOLL25  QCOAL125         1.   
    PCCOLL25  QNATU125         1.   
    PCCOLL25  QNATU225         1.   
    PCCOLL25  QNATU325         1.   
    PCCOLL30  PCCOLL30        10.   
    PCCOLL30  PCCOLH30         1.   
    PCCOLL30  PCLWRA30         1.   
    PCCOLL30  PCLWRB30         1.   
    PCCOLL30  PCLWRC30         1.   
    PCCOLL30  PCFBRX30         1.   
    PCCOLL30  PCSOLE30         1.   
    PCCOLL30  PCSYNF30         1.   
    PCCOLL30  PCSHAL30         1.   
    PCCOLL30  PCNAES30         1.   
    PCCOLL30  PCCLDU30         1.   
    PCCOLL30  PCPGAI30         1.   
    PCCOLL30  QPETG130         1.   
    PCCOLL30  QPETG230         1.   
    PCCOLL30  QPETG330         1.   
    PCCOLL30  QPETG430         1.   
    PCCOLL30  QCOAL130         1.   
    PCCOLL30  QNATU130         1.   
    PCCOLL30  QNATU230         1.   
    PCCOLL30  QNATU330         1.   
    PCCOLL35  PCCOLL35        10.   
    PCCOLL35  PCCOLH35         1.   
    PCCOLL35  PCLWRA35         1.   
    PCCOLL35  PCLWRB35         1.   
    PCCOLL35  PCLWRC35         1.   
    PCCOLL35  PCFBRX35         1.   
    PCCOLL35  PCSOLE35         1.   
    PCCOLL35  PCSYNF35         1.   
    PCCOLL35  PCSHAL35         1.   
    PCCOLL35  PCNAES35         1.   
    PCCOLL35  PCCLDU35         1.   
    PCCOLL35  PCPGAI35         1.   
    PCCOLL35  QPETG135         1.   
    PCCOLL35  QPETG235         1.   
    PCCOLL35  QPETG335         1.   
    PCCOLL35  QPETG435         1.   
    PCCOLL35  QCOAL135         1.   
    PCCOLL35  QNATU135         1.   
    PCCOLL35  QNATU235         1.   
    PCCOLL35  QNATU335         1.   
    PCCOLL40  PCCOLL40        10.   
    PCCOLL40  PCCOLH40         1.   
    PCCOLL40  PCLWRA40         1.   
    PCCOLL40  PCLWRB40         1.   
    PCCOLL40  PCLWRC40         1.   
    PCCOLL40  PCFBRX40         1.   
    PCCOLL40  PCSOLE40         1.   
    PCCOLL40  PCSYNF40         1.   
    PCCOLL40  PCSHAL40         1.   
    PCCOLL40  PCNAES40         1.   
    PCCOLL40  PCCLDU40         1.   
    PCCOLL40  PCPGAI40         1.   
    PCCOLL40  QPETG140         1.   
    PCCOLL40  QPETG240         1.   
    PCCOLL40  QPETG340         1.   
    PCCOLL40  QPETG440         1.   
    PCCOLL40  QCOAL140         1.   
    PCCOLL40  QNATU140         1.   
    PCCOLL40  QNATU240         1.   
    PCCOLL40  QNATU340         1.   
    PCCOLL45  PCCOLL45        10.   
    PCCOLL45  PCCOLH45         1.   
    PCCOLL45  PCLWRA45         1.   
    PCCOLL45  PCLWRB45         1.   
    PCCOLL45  PCLWRC45         1.   
    PCCOLL45  PCFBRX45         1.   
    PCCOLL45  PCSOLE45         1.   
    PCCOLL45  PCSYNF45         1.   
    PCCOLL45  PCSHAL45         1.   
    PCCOLL45  PCNAES45         1.   
    PCCOLL45  PCCLDU45         1.   
    PCCOLL45  PCPGAI45         1.   
    PCCOLL45  QPETG145         1.   
    PCCOLL45  QPETG245         1.   
    PCCOLL45  QPETG345         1.   
    PCCOLL45  QPETG445         1.   
    PCCOLL45  QCOAL145         1.   
    PCCOLL45  QNATU145         1.   
    PCCOLL45  QNATU245         1.   
    PCCOLL45  QNATU345         1.   
    PCCOLL50  PCCOLL50        10.   
    PCCOLL50  PCCOLH50         1.   
    PCCOLL50  PCLWRA50         1.   
    PCCOLL50  PCLWRB50         1.   
    PCCOLL50  PCLWRC50         1.   
    PCCOLL50  PCFBRX50         1.   
    PCCOLL50  PCSOLE50         1.   
    PCCOLL50  PCSYNF50         1.   
    PCCOLL50  PCSHAL50         1.   
    PCCOLL50  PCNAES50         1.   
    PCCOLL50  PCCLDU50         1.   
    PCCOLL50  PCPGAI50         1.   
    PCCOLL50  QPETG150         1.   
    PCCOLL50  QPETG250         1.   
    PCCOLL50  QPETG350         1.   
    PCCOLL50  QPETG450         1.   
    PCCOLL50  QCOAL150         1.   
    PCCOLL50  QNATU150         1.   
    PCCOLL50  QNATU250         1.   
    PCCOLL50  QNATU350         1.   
    PCCOLL55  PCCOLL55        10.   
    PCCOLL55  PCCOLH55         1.   
    PCCOLL55  PCLWRA55         1.   
    PCCOLL55  PCLWRB55         1.   
    PCCOLL55  PCLWRC55         1.   
    PCCOLL55  PCFBRX55         1.   
    PCCOLL55  PCSOLE55         1.   
    PCCOLL55  PCSYNF55         1.   
    PCCOLL55  PCSHAL55         1.   
    PCCOLL55  PCNAES55         1.   
    PCCOLL55  PCCLDU55         1.   
    PCCOLL55  PCPGAI55         1.   
    PCCOLL55  QPETG155         1.   
    PCCOLL55  QPETG255         1.   
    PCCOLL55  QPETG355         1.   
    PCCOLL55  QPETG455         1.   
    PCCOLL55  QCOAL155         1.   
    PCCOLL55  QNATU155         1.   
    PCCOLL55  QNATU255         1.   
    PCCOLL55  QNATU355         1.   
    PCCOLL60  PCCOLL60        10.   
    PCCOLL60  PCCOLH60         1.   
    PCCOLL60  PCLWRA60         1.   
    PCCOLL60  PCLWRB60         1.   
    PCCOLL60  PCLWRC60         1.   
    PCCOLL60  PCFBRX60         1.   
    PCCOLL60  PCSOLE60         1.   
    PCCOLL60  PCSYNF60         1.   
    PCCOLL60  PCSHAL60         1.   
    PCCOLL60  PCNAES60         1.   
    PCCOLL60  PCCLDU60         1.   
    PCCOLL60  PCPGAI60         1.   
    PCCOLL60  QPETG160         1.   
    PCCOLL60  QPETG260         1.   
    PCCOLL60  QPETG360         1.   
    PCCOLL60  QPETG460         1.   
    PCCOLL60  QCOAL160         1.   
    PCCOLL60  QNATU160         1.   
    PCCOLL60  QNATU260         1.   
    PCCOLL60  QNATU360         1.   
    PCCOLL65  PCCOLL65        10.   
    PCCOLL65  PCCOLH65         1.   
    PCCOLL65  PCLWRA65         1.   
    PCCOLL65  PCLWRB65         1.   
    PCCOLL65  PCLWRC65         1.   
    PCCOLL65  PCFBRX65         1.   
    PCCOLL65  PCSOLE65         1.   
    PCCOLL65  PCSYNF65         1.   
    PCCOLL65  PCSHAL65         1.   
    PCCOLL65  PCNAES65         1.   
    PCCOLL65  PCCLDU65         1.   
    PCCOLL65  PCPGAI65         1.   
    PCCOLL65  QPETG165         1.   
    PCCOLL65  QPETG265         1.   
    PCCOLL65  QPETG365         1.   
    PCCOLL65  QPETG465         1.   
    PCCOLL65  QCOAL165         1.   
    PCCOLL65  QNATU165         1.   
    PCCOLL65  QNATU265         1.   
    PCCOLL65  QNATU365         1.   
    PCCOLL70  PCCOLL70        10.   
    PCCOLL70  PCCOLH70         1.   
    PCCOLL70  PCLWRA70         1.   
    PCCOLL70  PCLWRB70         1.   
    PCCOLL70  PCLWRC70         1.   
    PCCOLL70  PCFBRX70         1.   
    PCCOLL70  PCSOLE70         1.   
    PCCOLL70  PCSYNF70         1.   
    PCCOLL70  PCSHAL70         1.   
    PCCOLL70  PCNAES70         1.   
    PCCOLL70  PCCLDU70         1.   
    PCCOLL70  PCPGAI70         1.   
    PCCOLL70  QPETG170         1.   
    PCCOLL70  QPETG270         1.   
    PCCOLL70  QPETG370         1.   
    PCCOLL70  QPETG470         1.   
    PCCOLL70  QCOAL170         1.   
    PCCOLL70  QNATU170         1.   
    PCCOLL70  QNATU270         1.   
    PCCOLL70  QNATU370         1.   
    PCCOLL75  PCCOLL75        10.   
    PCCOLL75  PCCOLH75         1.   
    PCCOLL75  PCLWRA75         1.   
    PCCOLL75  PCLWRB75         1.   
    PCCOLL75  PCLWRC75         1.   
    PCCOLL75  PCFBRX75         1.   
    PCCOLL75  PCSOLE75         1.   
    PCCOLL75  PCSYNF75         1.   
    PCCOLL75  PCSHAL75         1.   
    PCCOLL75  PCNAES75         1.   
    PCCOLL75  PCCLDU75         1.   
    PCCOLL75  PCPGAI75         1.   
    PCCOLL75  QPETG175         1.   
    PCCOLL75  QPETG275         1.   
    PCCOLL75  QPETG375         1.   
    PCCOLL75  QPETG475         1.   
    PCCOLL75  QCOAL175         1.   
    PCCOLL75  QNATU175         1.   
    PCCOLL75  QNATU275         1.   
    PCCOLL75  QNATU375         1.   
    PCCOLH00  PCCOLH00        10.   
    PCCOLH00  PCLWRA00         1.   
    PCCOLH00  PCLWRB00         1.   
    PCCOLH00  PCLWRC00         1.   
    PCCOLH00  PCFBRX00         1.   
    PCCOLH00  PCSOLE00         1.   
    PCCOLH00  PCSYNF00         1.   
    PCCOLH00  PCSHAL00         1.   
    PCCOLH00  PCNAES00         1.   
    PCCOLH00  PCCLDU00         1.   
    PCCOLH00  PCPGAI00         1.   
    PCCOLH00  QPETG100         1.   
    PCCOLH00  QPETG200         1.   
    PCCOLH00  QPETG300         1.   
    PCCOLH00  QPETG400         1.   
    PCCOLH00  QCOAL100         1.   
    PCCOLH00  QNATU100         1.   
    PCCOLH00  QNATU200         1.   
    PCCOLH00  QNATU300         1.   
    PCCOLH05  PCCOLH05        10.   
    PCCOLH05  PCLWRA05         1.   
    PCCOLH05  PCLWRB05         1.   
    PCCOLH05  PCLWRC05         1.   
    PCCOLH05  PCFBRX05         1.   
    PCCOLH05  PCSOLE05         1.   
    PCCOLH05  PCSYNF05         1.   
    PCCOLH05  PCSHAL05         1.   
    PCCOLH05  PCNAES05         1.   
    PCCOLH05  PCCLDU05         1.   
    PCCOLH05  PCPGAI05         1.   
    PCCOLH05  QPETG105         1.   
    PCCOLH05  QPETG205         1.   
    PCCOLH05  QPETG305         1.   
    PCCOLH05  QPETG405         1.   
    PCCOLH05  QCOAL105         1.   
    PCCOLH05  QNATU105         1.   
    PCCOLH05  QNATU205         1.   
    PCCOLH05  QNATU305         1.   
    PCCOLH10  PCCOLH10        10.   
    PCCOLH10  PCLWRA10         1.   
    PCCOLH10  PCLWRB10         1.   
    PCCOLH10  PCLWRC10         1.   
    PCCOLH10  PCFBRX10         1.   
    PCCOLH10  PCSOLE10         1.   
    PCCOLH10  PCSYNF10         1.   
    PCCOLH10  PCSHAL10         1.   
    PCCOLH10  PCNAES10         1.   
    PCCOLH10  PCCLDU10         1.   
    PCCOLH10  PCPGAI10         1.   
    PCCOLH10  QPETG110         1.   
    PCCOLH10  QPETG210         1.   
    PCCOLH10  QPETG310         1.   
    PCCOLH10  QPETG410         1.   
    PCCOLH10  QCOAL110         1.   
    PCCOLH10  QNATU110         1.   
    PCCOLH10  QNATU210         1.   
    PCCOLH10  QNATU310         1.   
    PCCOLH15  PCCOLH15        10.   
    PCCOLH15  PCLWRA15         1.   
    PCCOLH15  PCLWRB15         1.   
    PCCOLH15  PCLWRC15         1.   
    PCCOLH15  PCFBRX15         1.   
    PCCOLH15  PCSOLE15         1.   
    PCCOLH15  PCSYNF15         1.   
    PCCOLH15  PCSHAL15         1.   
    PCCOLH15  PCNAES15         1.   
    PCCOLH15  PCCLDU15         1.   
    PCCOLH15  PCPGAI15         1.   
    PCCOLH15  QPETG115         1.   
    PCCOLH15  QPETG215         1.   
    PCCOLH15  QPETG315         1.   
    PCCOLH15  QPETG415         1.   
    PCCOLH15  QCOAL115         1.   
    PCCOLH15  QNATU115         1.   
    PCCOLH15  QNATU215         1.   
    PCCOLH15  QNATU315         1.   
    PCCOLH20  PCCOLH20        10.   
    PCCOLH20  PCLWRA20         1.   
    PCCOLH20  PCLWRB20         1.   
    PCCOLH20  PCLWRC20         1.   
    PCCOLH20  PCFBRX20         1.   
    PCCOLH20  PCSOLE20         1.   
    PCCOLH20  PCSYNF20         1.   
    PCCOLH20  PCSHAL20         1.   
    PCCOLH20  PCNAES20         1.   
    PCCOLH20  PCCLDU20         1.   
    PCCOLH20  PCPGAI20         1.   
    PCCOLH20  QPETG120         1.   
    PCCOLH20  QPETG220         1.   
    PCCOLH20  QPETG320         1.   
    PCCOLH20  QPETG420         1.   
    PCCOLH20  QCOAL120         1.   
    PCCOLH20  QNATU120         1.   
    PCCOLH20  QNATU220         1.   
    PCCOLH20  QNATU320         1.   
    PCCOLH25  PCCOLH25        10.   
    PCCOLH25  PCLWRA25         1.   
    PCCOLH25  PCLWRB25         1.   
    PCCOLH25  PCLWRC25         1.   
    PCCOLH25  PCFBRX25         1.   
    PCCOLH25  PCSOLE25         1.   
    PCCOLH25  PCSYNF25         1.   
    PCCOLH25  PCSHAL25         1.   
    PCCOLH25  PCNAES25         1.   
    PCCOLH25  PCCLDU25         1.   
    PCCOLH25  PCPGAI25         1.   
    PCCOLH25  QPETG125         1.   
    PCCOLH25  QPETG225         1.   
    PCCOLH25  QPETG325         1.   
    PCCOLH25  QPETG425         1.   
    PCCOLH25  QCOAL125         1.   
    PCCOLH25  QNATU125         1.   
    PCCOLH25  QNATU225         1.   
    PCCOLH25  QNATU325         1.   
    PCCOLH30  PCCOLH30        10.   
    PCCOLH30  PCLWRA30         1.   
    PCCOLH30  PCLWRB30         1.   
    PCCOLH30  PCLWRC30         1.   
    PCCOLH30  PCFBRX30         1.   
    PCCOLH30  PCSOLE30         1.   
    PCCOLH30  PCSYNF30         1.   
    PCCOLH30  PCSHAL30         1.   
    PCCOLH30  PCNAES30         1.   
    PCCOLH30  PCCLDU30         1.   
    PCCOLH30  PCPGAI30         1.   
    PCCOLH30  QPETG130         1.   
    PCCOLH30  QPETG230         1.   
    PCCOLH30  QPETG330         1.   
    PCCOLH30  QPETG430         1.   
    PCCOLH30  QCOAL130         1.   
    PCCOLH30  QNATU130         1.   
    PCCOLH30  QNATU230         1.   
    PCCOLH30  QNATU330         1.   
    PCCOLH35  PCCOLH35        10.   
    PCCOLH35  PCLWRA35         1.   
    PCCOLH35  PCLWRB35         1.   
    PCCOLH35  PCLWRC35         1.   
    PCCOLH35  PCFBRX35         1.   
    PCCOLH35  PCSOLE35         1.   
    PCCOLH35  PCSYNF35         1.   
    PCCOLH35  PCSHAL35         1.   
    PCCOLH35  PCNAES35         1.   
    PCCOLH35  PCCLDU35         1.   
    PCCOLH35  PCPGAI35         1.   
    PCCOLH35  QPETG135         1.   
    PCCOLH35  QPETG235         1.   
    PCCOLH35  QPETG335         1.   
    PCCOLH35  QPETG435         1.   
    PCCOLH35  QCOAL135         1.   
    PCCOLH35  QNATU135         1.   
    PCCOLH35  QNATU235         1.   
    PCCOLH35  QNATU335         1.   
    PCCOLH40  PCCOLH40        10.   
    PCCOLH40  PCLWRA40         1.   
    PCCOLH40  PCLWRB40         1.   
    PCCOLH40  PCLWRC40         1.   
    PCCOLH40  PCFBRX40         1.   
    PCCOLH40  PCSOLE40         1.   
    PCCOLH40  PCSYNF40         1.   
    PCCOLH40  PCSHAL40         1.   
    PCCOLH40  PCNAES40         1.   
    PCCOLH40  PCCLDU40         1.   
    PCCOLH40  PCPGAI40         1.   
    PCCOLH40  QPETG140         1.   
    PCCOLH40  QPETG240         1.   
    PCCOLH40  QPETG340         1.   
    PCCOLH40  QPETG440         1.   
    PCCOLH40  QCOAL140         1.   
    PCCOLH40  QNATU140         1.   
    PCCOLH40  QNATU240         1.   
    PCCOLH40  QNATU340         1.   
    PCCOLH45  PCCOLH45        10.   
    PCCOLH45  PCLWRA45         1.   
    PCCOLH45  PCLWRB45         1.   
    PCCOLH45  PCLWRC45         1.   
    PCCOLH45  PCFBRX45         1.   
    PCCOLH45  PCSOLE45         1.   
    PCCOLH45  PCSYNF45         1.   
    PCCOLH45  PCSHAL45         1.   
    PCCOLH45  PCNAES45         1.   
    PCCOLH45  PCCLDU45         1.   
    PCCOLH45  PCPGAI45         1.   
    PCCOLH45  QPETG145         1.   
    PCCOLH45  QPETG245         1.   
    PCCOLH45  QPETG345         1.   
    PCCOLH45  QPETG445         1.   
    PCCOLH45  QCOAL145         1.   
    PCCOLH45  QNATU145         1.   
    PCCOLH45  QNATU245         1.   
    PCCOLH45  QNATU345         1.   
    PCCOLH50  PCCOLH50        10.   
    PCCOLH50  PCLWRA50         1.   
    PCCOLH50  PCLWRB50         1.   
    PCCOLH50  PCLWRC50         1.   
    PCCOLH50  PCFBRX50         1.   
    PCCOLH50  PCSOLE50         1.   
    PCCOLH50  PCSYNF50         1.   
    PCCOLH50  PCSHAL50         1.   
    PCCOLH50  PCNAES50         1.   
    PCCOLH50  PCCLDU50         1.   
    PCCOLH50  PCPGAI50         1.   
    PCCOLH50  QPETG150         1.   
    PCCOLH50  QPETG250         1.   
    PCCOLH50  QPETG350         1.   
    PCCOLH50  QPETG450         1.   
    PCCOLH50  QCOAL150         1.   
    PCCOLH50  QNATU150         1.   
    PCCOLH50  QNATU250         1.   
    PCCOLH50  QNATU350         1.   
    PCCOLH55  PCCOLH55        10.   
    PCCOLH55  PCLWRA55         1.   
    PCCOLH55  PCLWRB55         1.   
    PCCOLH55  PCLWRC55         1.   
    PCCOLH55  PCFBRX55         1.   
    PCCOLH55  PCSOLE55         1.   
    PCCOLH55  PCSYNF55         1.   
    PCCOLH55  PCSHAL55         1.   
    PCCOLH55  PCNAES55         1.   
    PCCOLH55  PCCLDU55         1.   
    PCCOLH55  PCPGAI55         1.   
    PCCOLH55  QPETG155         1.   
    PCCOLH55  QPETG255         1.   
    PCCOLH55  QPETG355         1.   
    PCCOLH55  QPETG455         1.   
    PCCOLH55  QCOAL155         1.   
    PCCOLH55  QNATU155         1.   
    PCCOLH55  QNATU255         1.   
    PCCOLH55  QNATU355         1.   
    PCCOLH60  PCCOLH60        10.   
    PCCOLH60  PCLWRA60         1.   
    PCCOLH60  PCLWRB60         1.   
    PCCOLH60  PCLWRC60         1.   
    PCCOLH60  PCFBRX60         1.   
    PCCOLH60  PCSOLE60         1.   
    PCCOLH60  PCSYNF60         1.   
    PCCOLH60  PCSHAL60         1.   
    PCCOLH60  PCNAES60         1.   
    PCCOLH60  PCCLDU60         1.   
    PCCOLH60  PCPGAI60         1.   
    PCCOLH60  QPETG160         1.   
    PCCOLH60  QPETG260         1.   
    PCCOLH60  QPETG360         1.   
    PCCOLH60  QPETG460         1.   
    PCCOLH60  QCOAL160         1.   
    PCCOLH60  QNATU160         1.   
    PCCOLH60  QNATU260         1.   
    PCCOLH60  QNATU360         1.   
    PCCOLH65  PCCOLH65        10.   
    PCCOLH65  PCLWRA65         1.   
    PCCOLH65  PCLWRB65         1.   
    PCCOLH65  PCLWRC65         1.   
    PCCOLH65  PCFBRX65         1.   
    PCCOLH65  PCSOLE65         1.   
    PCCOLH65  PCSYNF65         1.   
    PCCOLH65  PCSHAL65         1.   
    PCCOLH65  PCNAES65         1.   
    PCCOLH65  PCCLDU65         1.   
    PCCOLH65  PCPGAI65         1.   
    PCCOLH65  QPETG165         1.   
    PCCOLH65  QPETG265         1.   
    PCCOLH65  QPETG365         1.   
    PCCOLH65  QPETG465         1.   
    PCCOLH65  QCOAL165         1.   
    PCCOLH65  QNATU165         1.   
    PCCOLH65  QNATU265         1.   
    PCCOLH65  QNATU365         1.   
    PCCOLH70  PCCOLH70        10.   
    PCCOLH70  PCLWRA70         1.   
    PCCOLH70  PCLWRB70         1.   
    PCCOLH70  PCLWRC70         1.   
    PCCOLH70  PCFBRX70         1.   
    PCCOLH70  PCSOLE70         1.   
    PCCOLH70  PCSYNF70         1.   
    PCCOLH70  PCSHAL70         1.   
    PCCOLH70  PCNAES70         1.   
    PCCOLH70  PCCLDU70         1.   
    PCCOLH70  PCPGAI70         1.   
    PCCOLH70  QPETG170         1.   
    PCCOLH70  QPETG270         1.   
    PCCOLH70  QPETG370         1.   
    PCCOLH70  QPETG470         1.   
    PCCOLH70  QCOAL170         1.   
    PCCOLH70  QNATU170         1.   
    PCCOLH70  QNATU270         1.   
    PCCOLH70  QNATU370         1.   
    PCCOLH75  PCCOLH75        10.   
    PCCOLH75  PCLWRA75         1.   
    PCCOLH75  PCLWRB75         1.   
    PCCOLH75  PCLWRC75         1.   
    PCCOLH75  PCFBRX75         1.   
    PCCOLH75  PCSOLE75         1.   
    PCCOLH75  PCSYNF75         1.   
    PCCOLH75  PCSHAL75         1.   
    PCCOLH75  PCNAES75         1.   
    PCCOLH75  PCCLDU75         1.   
    PCCOLH75  PCPGAI75         1.   
    PCCOLH75  QPETG175         1.   
    PCCOLH75  QPETG275         1.   
    PCCOLH75  QPETG375         1.   
    PCCOLH75  QPETG475         1.   
    PCCOLH75  QCOAL175         1.   
    PCCOLH75  QNATU175         1.   
    PCCOLH75  QNATU275         1.   
    PCCOLH75  QNATU375         1.   
    PCLWRA00  PCLWRA00        10.   
    PCLWRA00  PCLWRB00         1.   
    PCLWRA00  PCLWRC00         1.   
    PCLWRA00  PCFBRX00         1.   
    PCLWRA00  PCSOLE00         1.   
    PCLWRA00  PCSYNF00         1.   
    PCLWRA00  PCSHAL00         1.   
    PCLWRA00  PCNAES00         1.   
    PCLWRA00  PCCLDU00         1.   
    PCLWRA00  PCPGAI00         1.   
    PCLWRA00  QPETG100         1.   
    PCLWRA00  QPETG200         1.   
    PCLWRA00  QPETG300         1.   
    PCLWRA00  QPETG400         1.   
    PCLWRA00  QCOAL100         1.   
    PCLWRA00  QNATU100         1.   
    PCLWRA00  QNATU200         1.   
    PCLWRA00  QNATU300         1.   
    PCLWRA05  PCLWRA05        10.   
    PCLWRA05  PCLWRB05         1.   
    PCLWRA05  PCLWRC05         1.   
    PCLWRA05  PCFBRX05         1.   
    PCLWRA05  PCSOLE05         1.   
    PCLWRA05  PCSYNF05         1.   
    PCLWRA05  PCSHAL05         1.   
    PCLWRA05  PCNAES05         1.   
    PCLWRA05  PCCLDU05         1.   
    PCLWRA05  PCPGAI05         1.   
    PCLWRA05  QPETG105         1.   
    PCLWRA05  QPETG205         1.   
    PCLWRA05  QPETG305         1.   
    PCLWRA05  QPETG405         1.   
    PCLWRA05  QCOAL105         1.   
    PCLWRA05  QNATU105         1.   
    PCLWRA05  QNATU205         1.   
    PCLWRA05  QNATU305         1.   
    PCLWRA10  PCLWRA10        10.   
    PCLWRA10  PCLWRB10         1.   
    PCLWRA10  PCLWRC10         1.   
    PCLWRA10  PCFBRX10         1.   
    PCLWRA10  PCSOLE10         1.   
    PCLWRA10  PCSYNF10         1.   
    PCLWRA10  PCSHAL10         1.   
    PCLWRA10  PCNAES10         1.   
    PCLWRA10  PCCLDU10         1.   
    PCLWRA10  PCPGAI10         1.   
    PCLWRA10  QPETG110         1.   
    PCLWRA10  QPETG210         1.   
    PCLWRA10  QPETG310         1.   
    PCLWRA10  QPETG410         1.   
    PCLWRA10  QCOAL110         1.   
    PCLWRA10  QNATU110         1.   
    PCLWRA10  QNATU210         1.   
    PCLWRA10  QNATU310         1.   
    PCLWRA15  PCLWRA15        10.   
    PCLWRA15  PCLWRB15         1.   
    PCLWRA15  PCLWRC15         1.   
    PCLWRA15  PCFBRX15         1.   
    PCLWRA15  PCSOLE15         1.   
    PCLWRA15  PCSYNF15         1.   
    PCLWRA15  PCSHAL15         1.   
    PCLWRA15  PCNAES15         1.   
    PCLWRA15  PCCLDU15         1.   
    PCLWRA15  PCPGAI15         1.   
    PCLWRA15  QPETG115         1.   
    PCLWRA15  QPETG215         1.   
    PCLWRA15  QPETG315         1.   
    PCLWRA15  QPETG415         1.   
    PCLWRA15  QCOAL115         1.   
    PCLWRA15  QNATU115         1.   
    PCLWRA15  QNATU215         1.   
    PCLWRA15  QNATU315         1.   
    PCLWRA20  PCLWRA20        10.   
    PCLWRA20  PCLWRB20         1.   
    PCLWRA20  PCLWRC20         1.   
    PCLWRA20  PCFBRX20         1.   
    PCLWRA20  PCSOLE20         1.   
    PCLWRA20  PCSYNF20         1.   
    PCLWRA20  PCSHAL20         1.   
    PCLWRA20  PCNAES20         1.   
    PCLWRA20  PCCLDU20         1.   
    PCLWRA20  PCPGAI20         1.   
    PCLWRA20  QPETG120         1.   
    PCLWRA20  QPETG220         1.   
    PCLWRA20  QPETG320         1.   
    PCLWRA20  QPETG420         1.   
    PCLWRA20  QCOAL120         1.   
    PCLWRA20  QNATU120         1.   
    PCLWRA20  QNATU220         1.   
    PCLWRA20  QNATU320         1.   
    PCLWRA25  PCLWRA25        10.   
    PCLWRA25  PCLWRB25         1.   
    PCLWRA25  PCLWRC25         1.   
    PCLWRA25  PCFBRX25         1.   
    PCLWRA25  PCSOLE25         1.   
    PCLWRA25  PCSYNF25         1.   
    PCLWRA25  PCSHAL25         1.   
    PCLWRA25  PCNAES25         1.   
    PCLWRA25  PCCLDU25         1.   
    PCLWRA25  PCPGAI25         1.   
    PCLWRA25  QPETG125         1.   
    PCLWRA25  QPETG225         1.   
    PCLWRA25  QPETG325         1.   
    PCLWRA25  QPETG425         1.   
    PCLWRA25  QCOAL125         1.   
    PCLWRA25  QNATU125         1.   
    PCLWRA25  QNATU225         1.   
    PCLWRA25  QNATU325         1.   
    PCLWRA30  PCLWRA30        10.   
    PCLWRA30  PCLWRB30         1.   
    PCLWRA30  PCLWRC30         1.   
    PCLWRA30  PCFBRX30         1.   
    PCLWRA30  PCSOLE30         1.   
    PCLWRA30  PCSYNF30         1.   
    PCLWRA30  PCSHAL30         1.   
    PCLWRA30  PCNAES30         1.   
    PCLWRA30  PCCLDU30         1.   
    PCLWRA30  PCPGAI30         1.   
    PCLWRA30  QPETG130         1.   
    PCLWRA30  QPETG230         1.   
    PCLWRA30  QPETG330         1.   
    PCLWRA30  QPETG430         1.   
    PCLWRA30  QCOAL130         1.   
    PCLWRA30  QNATU130         1.   
    PCLWRA30  QNATU230         1.   
    PCLWRA30  QNATU330         1.   
    PCLWRA35  PCLWRA35        10.   
    PCLWRA35  PCLWRB35         1.   
    PCLWRA35  PCLWRC35         1.   
    PCLWRA35  PCFBRX35         1.   
    PCLWRA35  PCSOLE35         1.   
    PCLWRA35  PCSYNF35         1.   
    PCLWRA35  PCSHAL35         1.   
    PCLWRA35  PCNAES35         1.   
    PCLWRA35  PCCLDU35         1.   
    PCLWRA35  PCPGAI35         1.   
    PCLWRA35  QPETG135         1.   
    PCLWRA35  QPETG235         1.   
    PCLWRA35  QPETG335         1.   
    PCLWRA35  QPETG435         1.   
    PCLWRA35  QCOAL135         1.   
    PCLWRA35  QNATU135         1.   
    PCLWRA35  QNATU235         1.   
    PCLWRA35  QNATU335         1.   
    PCLWRA40  PCLWRA40        10.   
    PCLWRA40  PCLWRB40         1.   
    PCLWRA40  PCLWRC40         1.   
    PCLWRA40  PCFBRX40         1.   
    PCLWRA40  PCSOLE40         1.   
    PCLWRA40  PCSYNF40         1.   
    PCLWRA40  PCSHAL40         1.   
    PCLWRA40  PCNAES40         1.   
    PCLWRA40  PCCLDU40         1.   
    PCLWRA40  PCPGAI40         1.   
    PCLWRA40  QPETG140         1.   
    PCLWRA40  QPETG240         1.   
    PCLWRA40  QPETG340         1.   
    PCLWRA40  QPETG440         1.   
    PCLWRA40  QCOAL140         1.   
    PCLWRA40  QNATU140         1.   
    PCLWRA40  QNATU240         1.   
    PCLWRA40  QNATU340         1.   
    PCLWRA45  PCLWRA45        10.   
    PCLWRA45  PCLWRB45         1.   
    PCLWRA45  PCLWRC45         1.   
    PCLWRA45  PCFBRX45         1.   
    PCLWRA45  PCSOLE45         1.   
    PCLWRA45  PCSYNF45         1.   
    PCLWRA45  PCSHAL45         1.   
    PCLWRA45  PCNAES45         1.   
    PCLWRA45  PCCLDU45         1.   
    PCLWRA45  PCPGAI45         1.   
    PCLWRA45  QPETG145         1.   
    PCLWRA45  QPETG245         1.   
    PCLWRA45  QPETG345         1.   
    PCLWRA45  QPETG445         1.   
    PCLWRA45  QCOAL145         1.   
    PCLWRA45  QNATU145         1.   
    PCLWRA45  QNATU245         1.   
    PCLWRA45  QNATU345         1.   
    PCLWRA50  PCLWRA50        10.   
    PCLWRA50  PCLWRB50         1.   
    PCLWRA50  PCLWRC50         1.   
    PCLWRA50  PCFBRX50         1.   
    PCLWRA50  PCSOLE50         1.   
    PCLWRA50  PCSYNF50         1.   
    PCLWRA50  PCSHAL50         1.   
    PCLWRA50  PCNAES50         1.   
    PCLWRA50  PCCLDU50         1.   
    PCLWRA50  PCPGAI50         1.   
    PCLWRA50  QPETG150         1.   
    PCLWRA50  QPETG250         1.   
    PCLWRA50  QPETG350         1.   
    PCLWRA50  QPETG450         1.   
    PCLWRA50  QCOAL150         1.   
    PCLWRA50  QNATU150         1.   
    PCLWRA50  QNATU250         1.   
    PCLWRA50  QNATU350         1.   
    PCLWRA55  PCLWRA55        10.   
    PCLWRA55  PCLWRB55         1.   
    PCLWRA55  PCLWRC55         1.   
    PCLWRA55  PCFBRX55         1.   
    PCLWRA55  PCSOLE55         1.   
    PCLWRA55  PCSYNF55         1.   
    PCLWRA55  PCSHAL55         1.   
    PCLWRA55  PCNAES55         1.   
    PCLWRA55  PCCLDU55         1.   
    PCLWRA55  PCPGAI55         1.   
    PCLWRA55  QPETG155         1.   
    PCLWRA55  QPETG255         1.   
    PCLWRA55  QPETG355         1.   
    PCLWRA55  QPETG455         1.   
    PCLWRA55  QCOAL155         1.   
    PCLWRA55  QNATU155         1.   
    PCLWRA55  QNATU255         1.   
    PCLWRA55  QNATU355         1.   
    PCLWRA60  PCLWRA60        10.   
    PCLWRA60  PCLWRB60         1.   
    PCLWRA60  PCLWRC60         1.   
    PCLWRA60  PCFBRX60         1.   
    PCLWRA60  PCSOLE60         1.   
    PCLWRA60  PCSYNF60         1.   
    PCLWRA60  PCSHAL60         1.   
    PCLWRA60  PCNAES60         1.   
    PCLWRA60  PCCLDU60         1.   
    PCLWRA60  PCPGAI60         1.   
    PCLWRA60  QPETG160         1.   
    PCLWRA60  QPETG260         1.   
    PCLWRA60  QPETG360         1.   
    PCLWRA60  QPETG460         1.   
    PCLWRA60  QCOAL160         1.   
    PCLWRA60  QNATU160         1.   
    PCLWRA60  QNATU260         1.   
    PCLWRA60  QNATU360         1.   
    PCLWRA65  PCLWRA65        10.   
    PCLWRA65  PCLWRB65         1.   
    PCLWRA65  PCLWRC65         1.   
    PCLWRA65  PCFBRX65         1.   
    PCLWRA65  PCSOLE65         1.   
    PCLWRA65  PCSYNF65         1.   
    PCLWRA65  PCSHAL65         1.   
    PCLWRA65  PCNAES65         1.   
    PCLWRA65  PCCLDU65         1.   
    PCLWRA65  PCPGAI65         1.   
    PCLWRA65  QPETG165         1.   
    PCLWRA65  QPETG265         1.   
    PCLWRA65  QPETG365         1.   
    PCLWRA65  QPETG465         1.   
    PCLWRA65  QCOAL165         1.   
    PCLWRA65  QNATU165         1.   
    PCLWRA65  QNATU265         1.   
    PCLWRA65  QNATU365         1.   
    PCLWRA70  PCLWRA70        10.   
    PCLWRA70  PCLWRB70         1.   
    PCLWRA70  PCLWRC70         1.   
    PCLWRA70  PCFBRX70         1.   
    PCLWRA70  PCSOLE70         1.   
    PCLWRA70  PCSYNF70         1.   
    PCLWRA70  PCSHAL70         1.   
    PCLWRA70  PCNAES70         1.   
    PCLWRA70  PCCLDU70         1.   
    PCLWRA70  PCPGAI70         1.   
    PCLWRA70  QPETG170         1.   
    PCLWRA70  QPETG270         1.   
    PCLWRA70  QPETG370         1.   
    PCLWRA70  QPETG470         1.   
    PCLWRA70  QCOAL170         1.   
    PCLWRA70  QNATU170         1.   
    PCLWRA70  QNATU270         1.   
    PCLWRA70  QNATU370         1.   
    PCLWRA75  PCLWRA75        10.   
    PCLWRA75  PCLWRB75         1.   
    PCLWRA75  PCLWRC75         1.   
    PCLWRA75  PCFBRX75         1.   
    PCLWRA75  PCSOLE75         1.   
    PCLWRA75  PCSYNF75         1.   
    PCLWRA75  PCSHAL75         1.   
    PCLWRA75  PCNAES75         1.   
    PCLWRA75  PCCLDU75         1.   
    PCLWRA75  PCPGAI75         1.   
    PCLWRA75  QPETG175         1.   
    PCLWRA75  QPETG275         1.   
    PCLWRA75  QPETG375         1.   
    PCLWRA75  QPETG475         1.   
    PCLWRA75  QCOAL175         1.   
    PCLWRA75  QNATU175         1.   
    PCLWRA75  QNATU275         1.   
    PCLWRA75  QNATU375         1.   
    PCLWRB00  PCLWRB00        10.   
    PCLWRB00  PCLWRC00         1.   
    PCLWRB00  PCFBRX00         1.   
    PCLWRB00  PCSOLE00         1.   
    PCLWRB00  PCSYNF00         1.   
    PCLWRB00  PCSHAL00         1.   
    PCLWRB00  PCNAES00         1.   
    PCLWRB00  PCCLDU00         1.   
    PCLWRB00  PCPGAI00         1.   
    PCLWRB00  QPETG100         1.   
    PCLWRB00  QPETG200         1.   
    PCLWRB00  QPETG300         1.   
    PCLWRB00  QPETG400         1.   
    PCLWRB00  QCOAL100         1.   
    PCLWRB00  QNATU100         1.   
    PCLWRB00  QNATU200         1.   
    PCLWRB00  QNATU300         1.   
    PCLWRB05  PCLWRB05        10.   
    PCLWRB05  PCLWRC05         1.   
    PCLWRB05  PCFBRX05         1.   
    PCLWRB05  PCSOLE05         1.   
    PCLWRB05  PCSYNF05         1.   
    PCLWRB05  PCSHAL05         1.   
    PCLWRB05  PCNAES05         1.   
    PCLWRB05  PCCLDU05         1.   
    PCLWRB05  PCPGAI05         1.   
    PCLWRB05  QPETG105         1.   
    PCLWRB05  QPETG205         1.   
    PCLWRB05  QPETG305         1.   
    PCLWRB05  QPETG405         1.   
    PCLWRB05  QCOAL105         1.   
    PCLWRB05  QNATU105         1.   
    PCLWRB05  QNATU205         1.   
    PCLWRB05  QNATU305         1.   
    PCLWRB10  PCLWRB10        10.   
    PCLWRB10  PCLWRC10         1.   
    PCLWRB10  PCFBRX10         1.   
    PCLWRB10  PCSOLE10         1.   
    PCLWRB10  PCSYNF10         1.   
    PCLWRB10  PCSHAL10         1.   
    PCLWRB10  PCNAES10         1.   
    PCLWRB10  PCCLDU10         1.   
    PCLWRB10  PCPGAI10         1.   
    PCLWRB10  QPETG110         1.   
    PCLWRB10  QPETG210         1.   
    PCLWRB10  QPETG310         1.   
    PCLWRB10  QPETG410         1.   
    PCLWRB10  QCOAL110         1.   
    PCLWRB10  QNATU110         1.   
    PCLWRB10  QNATU210         1.   
    PCLWRB10  QNATU310         1.   
    PCLWRB15  PCLWRB15        10.   
    PCLWRB15  PCLWRC15         1.   
    PCLWRB15  PCFBRX15         1.   
    PCLWRB15  PCSOLE15         1.   
    PCLWRB15  PCSYNF15         1.   
    PCLWRB15  PCSHAL15         1.   
    PCLWRB15  PCNAES15         1.   
    PCLWRB15  PCCLDU15         1.   
    PCLWRB15  PCPGAI15         1.   
    PCLWRB15  QPETG115         1.   
    PCLWRB15  QPETG215         1.   
    PCLWRB15  QPETG315         1.   
    PCLWRB15  QPETG415         1.   
    PCLWRB15  QCOAL115         1.   
    PCLWRB15  QNATU115         1.   
    PCLWRB15  QNATU215         1.   
    PCLWRB15  QNATU315         1.   
    PCLWRB20  PCLWRB20        10.   
    PCLWRB20  PCLWRC20         1.   
    PCLWRB20  PCFBRX20         1.   
    PCLWRB20  PCSOLE20         1.   
    PCLWRB20  PCSYNF20         1.   
    PCLWRB20  PCSHAL20         1.   
    PCLWRB20  PCNAES20         1.   
    PCLWRB20  PCCLDU20         1.   
    PCLWRB20  PCPGAI20         1.   
    PCLWRB20  QPETG120         1.   
    PCLWRB20  QPETG220         1.   
    PCLWRB20  QPETG320         1.   
    PCLWRB20  QPETG420         1.   
    PCLWRB20  QCOAL120         1.   
    PCLWRB20  QNATU120         1.   
    PCLWRB20  QNATU220         1.   
    PCLWRB20  QNATU320         1.   
    PCLWRB25  PCLWRB25        10.   
    PCLWRB25  PCLWRC25         1.   
    PCLWRB25  PCFBRX25         1.   
    PCLWRB25  PCSOLE25         1.   
    PCLWRB25  PCSYNF25         1.   
    PCLWRB25  PCSHAL25         1.   
    PCLWRB25  PCNAES25         1.   
    PCLWRB25  PCCLDU25         1.   
    PCLWRB25  PCPGAI25         1.   
    PCLWRB25  QPETG125         1.   
    PCLWRB25  QPETG225         1.   
    PCLWRB25  QPETG325         1.   
    PCLWRB25  QPETG425         1.   
    PCLWRB25  QCOAL125         1.   
    PCLWRB25  QNATU125         1.   
    PCLWRB25  QNATU225         1.   
    PCLWRB25  QNATU325         1.   
    PCLWRB30  PCLWRB30        10.   
    PCLWRB30  PCLWRC30         1.   
    PCLWRB30  PCFBRX30         1.   
    PCLWRB30  PCSOLE30         1.   
    PCLWRB30  PCSYNF30         1.   
    PCLWRB30  PCSHAL30         1.   
    PCLWRB30  PCNAES30         1.   
    PCLWRB30  PCCLDU30         1.   
    PCLWRB30  PCPGAI30         1.   
    PCLWRB30  QPETG130         1.   
    PCLWRB30  QPETG230         1.   
    PCLWRB30  QPETG330         1.   
    PCLWRB30  QPETG430         1.   
    PCLWRB30  QCOAL130         1.   
    PCLWRB30  QNATU130         1.   
    PCLWRB30  QNATU230         1.   
    PCLWRB30  QNATU330         1.   
    PCLWRB35  PCLWRB35        10.   
    PCLWRB35  PCLWRC35         1.   
    PCLWRB35  PCFBRX35         1.   
    PCLWRB35  PCSOLE35         1.   
    PCLWRB35  PCSYNF35         1.   
    PCLWRB35  PCSHAL35         1.   
    PCLWRB35  PCNAES35         1.   
    PCLWRB35  PCCLDU35         1.   
    PCLWRB35  PCPGAI35         1.   
    PCLWRB35  QPETG135         1.   
    PCLWRB35  QPETG235         1.   
    PCLWRB35  QPETG335         1.   
    PCLWRB35  QPETG435         1.   
    PCLWRB35  QCOAL135         1.   
    PCLWRB35  QNATU135         1.   
    PCLWRB35  QNATU235         1.   
    PCLWRB35  QNATU335         1.   
    PCLWRB40  PCLWRB40        10.   
    PCLWRB40  PCLWRC40         1.   
    PCLWRB40  PCFBRX40         1.   
    PCLWRB40  PCSOLE40         1.   
    PCLWRB40  PCSYNF40         1.   
    PCLWRB40  PCSHAL40         1.   
    PCLWRB40  PCNAES40         1.   
    PCLWRB40  PCCLDU40         1.   
    PCLWRB40  PCPGAI40         1.   
    PCLWRB40  QPETG140         1.   
    PCLWRB40  QPETG240         1.   
    PCLWRB40  QPETG340         1.   
    PCLWRB40  QPETG440         1.   
    PCLWRB40  QCOAL140         1.   
    PCLWRB40  QNATU140         1.   
    PCLWRB40  QNATU240         1.   
    PCLWRB40  QNATU340         1.   
    PCLWRB45  PCLWRB45        10.   
    PCLWRB45  PCLWRC45         1.   
    PCLWRB45  PCFBRX45         1.   
    PCLWRB45  PCSOLE45         1.   
    PCLWRB45  PCSYNF45         1.   
    PCLWRB45  PCSHAL45         1.   
    PCLWRB45  PCNAES45         1.   
    PCLWRB45  PCCLDU45         1.   
    PCLWRB45  PCPGAI45         1.   
    PCLWRB45  QPETG145         1.   
    PCLWRB45  QPETG245         1.   
    PCLWRB45  QPETG345         1.   
    PCLWRB45  QPETG445         1.   
    PCLWRB45  QCOAL145         1.   
    PCLWRB45  QNATU145         1.   
    PCLWRB45  QNATU245         1.   
    PCLWRB45  QNATU345         1.   
    PCLWRB50  PCLWRB50        10.   
    PCLWRB50  PCLWRC50         1.   
    PCLWRB50  PCFBRX50         1.   
    PCLWRB50  PCSOLE50         1.   
    PCLWRB50  PCSYNF50         1.   
    PCLWRB50  PCSHAL50         1.   
    PCLWRB50  PCNAES50         1.   
    PCLWRB50  PCCLDU50         1.   
    PCLWRB50  PCPGAI50         1.   
    PCLWRB50  QPETG150         1.   
    PCLWRB50  QPETG250         1.   
    PCLWRB50  QPETG350         1.   
    PCLWRB50  QPETG450         1.   
    PCLWRB50  QCOAL150         1.   
    PCLWRB50  QNATU150         1.   
    PCLWRB50  QNATU250         1.   
    PCLWRB50  QNATU350         1.   
    PCLWRB55  PCLWRB55        10.   
    PCLWRB55  PCLWRC55         1.   
    PCLWRB55  PCFBRX55         1.   
    PCLWRB55  PCSOLE55         1.   
    PCLWRB55  PCSYNF55         1.   
    PCLWRB55  PCSHAL55         1.   
    PCLWRB55  PCNAES55         1.   
    PCLWRB55  PCCLDU55         1.   
    PCLWRB55  PCPGAI55         1.   
    PCLWRB55  QPETG155         1.   
    PCLWRB55  QPETG255         1.   
    PCLWRB55  QPETG355         1.   
    PCLWRB55  QPETG455         1.   
    PCLWRB55  QCOAL155         1.   
    PCLWRB55  QNATU155         1.   
    PCLWRB55  QNATU255         1.   
    PCLWRB55  QNATU355         1.   
    PCLWRB60  PCLWRB60        10.   
    PCLWRB60  PCLWRC60         1.   
    PCLWRB60  PCFBRX60         1.   
    PCLWRB60  PCSOLE60         1.   
    PCLWRB60  PCSYNF60         1.   
    PCLWRB60  PCSHAL60         1.   
    PCLWRB60  PCNAES60         1.   
    PCLWRB60  PCCLDU60         1.   
    PCLWRB60  PCPGAI60         1.   
    PCLWRB60  QPETG160         1.   
    PCLWRB60  QPETG260         1.   
    PCLWRB60  QPETG360         1.   
    PCLWRB60  QPETG460         1.   
    PCLWRB60  QCOAL160         1.   
    PCLWRB60  QNATU160         1.   
    PCLWRB60  QNATU260         1.   
    PCLWRB60  QNATU360         1.   
    PCLWRB65  PCLWRB65        10.   
    PCLWRB65  PCLWRC65         1.   
    PCLWRB65  PCFBRX65         1.   
    PCLWRB65  PCSOLE65         1.   
    PCLWRB65  PCSYNF65         1.   
    PCLWRB65  PCSHAL65         1.   
    PCLWRB65  PCNAES65         1.   
    PCLWRB65  PCCLDU65         1.   
    PCLWRB65  PCPGAI65         1.   
    PCLWRB65  QPETG165         1.   
    PCLWRB65  QPETG265         1.   
    PCLWRB65  QPETG365         1.   
    PCLWRB65  QPETG465         1.   
    PCLWRB65  QCOAL165         1.   
    PCLWRB65  QNATU165         1.   
    PCLWRB65  QNATU265         1.   
    PCLWRB65  QNATU365         1.   
    PCLWRB70  PCLWRB70        10.   
    PCLWRB70  PCLWRC70         1.   
    PCLWRB70  PCFBRX70         1.   
    PCLWRB70  PCSOLE70         1.   
    PCLWRB70  PCSYNF70         1.   
    PCLWRB70  PCSHAL70         1.   
    PCLWRB70  PCNAES70         1.   
    PCLWRB70  PCCLDU70         1.   
    PCLWRB70  PCPGAI70         1.   
    PCLWRB70  QPETG170         1.   
    PCLWRB70  QPETG270         1.   
    PCLWRB70  QPETG370         1.   
    PCLWRB70  QPETG470         1.   
    PCLWRB70  QCOAL170         1.   
    PCLWRB70  QNATU170         1.   
    PCLWRB70  QNATU270         1.   
    PCLWRB70  QNATU370         1.   
    PCLWRB75  PCLWRB75        10.   
    PCLWRB75  PCLWRC75         1.   
    PCLWRB75  PCFBRX75         1.   
    PCLWRB75  PCSOLE75         1.   
    PCLWRB75  PCSYNF75         1.   
    PCLWRB75  PCSHAL75         1.   
    PCLWRB75  PCNAES75         1.   
    PCLWRB75  PCCLDU75         1.   
    PCLWRB75  PCPGAI75         1.   
    PCLWRB75  QPETG175         1.   
    PCLWRB75  QPETG275         1.   
    PCLWRB75  QPETG375         1.   
    PCLWRB75  QPETG475         1.   
    PCLWRB75  QCOAL175         1.   
    PCLWRB75  QNATU175         1.   
    PCLWRB75  QNATU275         1.   
    PCLWRB75  QNATU375         1.   
    PCLWRC00  PCLWRC00        10.   
    PCLWRC00  PCFBRX00         1.   
    PCLWRC00  PCSOLE00         1.   
    PCLWRC00  PCSYNF00         1.   
    PCLWRC00  PCSHAL00         1.   
    PCLWRC00  PCNAES00         1.   
    PCLWRC00  PCCLDU00         1.   
    PCLWRC00  PCPGAI00         1.   
    PCLWRC00  QPETG100         1.   
    PCLWRC00  QPETG200         1.   
    PCLWRC00  QPETG300         1.   
    PCLWRC00  QPETG400         1.   
    PCLWRC00  QCOAL100         1.   
    PCLWRC00  QNATU100         1.   
    PCLWRC00  QNATU200         1.   
    PCLWRC00  QNATU300         1.   
    PCLWRC05  PCLWRC05        10.   
    PCLWRC05  PCFBRX05         1.   
    PCLWRC05  PCSOLE05         1.   
    PCLWRC05  PCSYNF05         1.   
    PCLWRC05  PCSHAL05         1.   
    PCLWRC05  PCNAES05         1.   
    PCLWRC05  PCCLDU05         1.   
    PCLWRC05  PCPGAI05         1.   
    PCLWRC05  QPETG105         1.   
    PCLWRC05  QPETG205         1.   
    PCLWRC05  QPETG305         1.   
    PCLWRC05  QPETG405         1.   
    PCLWRC05  QCOAL105         1.   
    PCLWRC05  QNATU105         1.   
    PCLWRC05  QNATU205         1.   
    PCLWRC05  QNATU305         1.   
    PCLWRC10  PCLWRC10        10.   
    PCLWRC10  PCFBRX10         1.   
    PCLWRC10  PCSOLE10         1.   
    PCLWRC10  PCSYNF10         1.   
    PCLWRC10  PCSHAL10         1.   
    PCLWRC10  PCNAES10         1.   
    PCLWRC10  PCCLDU10         1.   
    PCLWRC10  PCPGAI10         1.   
    PCLWRC10  QPETG110         1.   
    PCLWRC10  QPETG210         1.   
    PCLWRC10  QPETG310         1.   
    PCLWRC10  QPETG410         1.   
    PCLWRC10  QCOAL110         1.   
    PCLWRC10  QNATU110         1.   
    PCLWRC10  QNATU210         1.   
    PCLWRC10  QNATU310         1.   
    PCLWRC15  PCLWRC15        10.   
    PCLWRC15  PCFBRX15         1.   
    PCLWRC15  PCSOLE15         1.   
    PCLWRC15  PCSYNF15         1.   
    PCLWRC15  PCSHAL15         1.   
    PCLWRC15  PCNAES15         1.   
    PCLWRC15  PCCLDU15         1.   
    PCLWRC15  PCPGAI15         1.   
    PCLWRC15  QPETG115         1.   
    PCLWRC15  QPETG215         1.   
    PCLWRC15  QPETG315         1.   
    PCLWRC15  QPETG415         1.   
    PCLWRC15  QCOAL115         1.   
    PCLWRC15  QNATU115         1.   
    PCLWRC15  QNATU215         1.   
    PCLWRC15  QNATU315         1.   
    PCLWRC20  PCLWRC20        10.   
    PCLWRC20  PCFBRX20         1.   
    PCLWRC20  PCSOLE20         1.   
    PCLWRC20  PCSYNF20         1.   
    PCLWRC20  PCSHAL20         1.   
    PCLWRC20  PCNAES20         1.   
    PCLWRC20  PCCLDU20         1.   
    PCLWRC20  PCPGAI20         1.   
    PCLWRC20  QPETG120         1.   
    PCLWRC20  QPETG220         1.   
    PCLWRC20  QPETG320         1.   
    PCLWRC20  QPETG420         1.   
    PCLWRC20  QCOAL120         1.   
    PCLWRC20  QNATU120         1.   
    PCLWRC20  QNATU220         1.   
    PCLWRC20  QNATU320         1.   
    PCLWRC25  PCLWRC25        10.   
    PCLWRC25  PCFBRX25         1.   
    PCLWRC25  PCSOLE25         1.   
    PCLWRC25  PCSYNF25         1.   
    PCLWRC25  PCSHAL25         1.   
    PCLWRC25  PCNAES25         1.   
    PCLWRC25  PCCLDU25         1.   
    PCLWRC25  PCPGAI25         1.   
    PCLWRC25  QPETG125         1.   
    PCLWRC25  QPETG225         1.   
    PCLWRC25  QPETG325         1.   
    PCLWRC25  QPETG425         1.   
    PCLWRC25  QCOAL125         1.   
    PCLWRC25  QNATU125         1.   
    PCLWRC25  QNATU225         1.   
    PCLWRC25  QNATU325         1.   
    PCLWRC30  PCLWRC30        10.   
    PCLWRC30  PCFBRX30         1.   
    PCLWRC30  PCSOLE30         1.   
    PCLWRC30  PCSYNF30         1.   
    PCLWRC30  PCSHAL30         1.   
    PCLWRC30  PCNAES30         1.   
    PCLWRC30  PCCLDU30         1.   
    PCLWRC30  PCPGAI30         1.   
    PCLWRC30  QPETG130         1.   
    PCLWRC30  QPETG230         1.   
    PCLWRC30  QPETG330         1.   
    PCLWRC30  QPETG430         1.   
    PCLWRC30  QCOAL130         1.   
    PCLWRC30  QNATU130         1.   
    PCLWRC30  QNATU230         1.   
    PCLWRC30  QNATU330         1.   
    PCLWRC35  PCLWRC35        10.   
    PCLWRC35  PCFBRX35         1.   
    PCLWRC35  PCSOLE35         1.   
    PCLWRC35  PCSYNF35         1.   
    PCLWRC35  PCSHAL35         1.   
    PCLWRC35  PCNAES35         1.   
    PCLWRC35  PCCLDU35         1.   
    PCLWRC35  PCPGAI35         1.   
    PCLWRC35  QPETG135         1.   
    PCLWRC35  QPETG235         1.   
    PCLWRC35  QPETG335         1.   
    PCLWRC35  QPETG435         1.   
    PCLWRC35  QCOAL135         1.   
    PCLWRC35  QNATU135         1.   
    PCLWRC35  QNATU235         1.   
    PCLWRC35  QNATU335         1.   
    PCLWRC40  PCLWRC40        10.   
    PCLWRC40  PCFBRX40         1.   
    PCLWRC40  PCSOLE40         1.   
    PCLWRC40  PCSYNF40         1.   
    PCLWRC40  PCSHAL40         1.   
    PCLWRC40  PCNAES40         1.   
    PCLWRC40  PCCLDU40         1.   
    PCLWRC40  PCPGAI40         1.   
    PCLWRC40  QPETG140         1.   
    PCLWRC40  QPETG240         1.   
    PCLWRC40  QPETG340         1.   
    PCLWRC40  QPETG440         1.   
    PCLWRC40  QCOAL140         1.   
    PCLWRC40  QNATU140         1.   
    PCLWRC40  QNATU240         1.   
    PCLWRC40  QNATU340         1.   
    PCLWRC45  PCLWRC45        10.   
    PCLWRC45  PCFBRX45         1.   
    PCLWRC45  PCSOLE45         1.   
    PCLWRC45  PCSYNF45         1.   
    PCLWRC45  PCSHAL45         1.   
    PCLWRC45  PCNAES45         1.   
    PCLWRC45  PCCLDU45         1.   
    PCLWRC45  PCPGAI45         1.   
    PCLWRC45  QPETG145         1.   
    PCLWRC45  QPETG245         1.   
    PCLWRC45  QPETG345         1.   
    PCLWRC45  QPETG445         1.   
    PCLWRC45  QCOAL145         1.   
    PCLWRC45  QNATU145         1.   
    PCLWRC45  QNATU245         1.   
    PCLWRC45  QNATU345         1.   
    PCLWRC50  PCLWRC50        10.   
    PCLWRC50  PCFBRX50         1.   
    PCLWRC50  PCSOLE50         1.   
    PCLWRC50  PCSYNF50         1.   
    PCLWRC50  PCSHAL50         1.   
    PCLWRC50  PCNAES50         1.   
    PCLWRC50  PCCLDU50         1.   
    PCLWRC50  PCPGAI50         1.   
    PCLWRC50  QPETG150         1.   
    PCLWRC50  QPETG250         1.   
    PCLWRC50  QPETG350         1.   
    PCLWRC50  QPETG450         1.   
    PCLWRC50  QCOAL150         1.   
    PCLWRC50  QNATU150         1.   
    PCLWRC50  QNATU250         1.   
    PCLWRC50  QNATU350         1.   
    PCLWRC55  PCLWRC55        10.   
    PCLWRC55  PCFBRX55         1.   
    PCLWRC55  PCSOLE55         1.   
    PCLWRC55  PCSYNF55         1.   
    PCLWRC55  PCSHAL55         1.   
    PCLWRC55  PCNAES55         1.   
    PCLWRC55  PCCLDU55         1.   
    PCLWRC55  PCPGAI55         1.   
    PCLWRC55  QPETG155         1.   
    PCLWRC55  QPETG255         1.   
    PCLWRC55  QPETG355         1.   
    PCLWRC55  QPETG455         1.   
    PCLWRC55  QCOAL155         1.   
    PCLWRC55  QNATU155         1.   
    PCLWRC55  QNATU255         1.   
    PCLWRC55  QNATU355         1.   
    PCLWRC60  PCLWRC60        10.   
    PCLWRC60  PCFBRX60         1.   
    PCLWRC60  PCSOLE60         1.   
    PCLWRC60  PCSYNF60         1.   
    PCLWRC60  PCSHAL60         1.   
    PCLWRC60  PCNAES60         1.   
    PCLWRC60  PCCLDU60         1.   
    PCLWRC60  PCPGAI60         1.   
    PCLWRC60  QPETG160         1.   
    PCLWRC60  QPETG260         1.   
    PCLWRC60  QPETG360         1.   
    PCLWRC60  QPETG460         1.   
    PCLWRC60  QCOAL160         1.   
    PCLWRC60  QNATU160         1.   
    PCLWRC60  QNATU260         1.   
    PCLWRC60  QNATU360         1.   
    PCLWRC65  PCLWRC65        10.   
    PCLWRC65  PCFBRX65         1.   
    PCLWRC65  PCSOLE65         1.   
    PCLWRC65  PCSYNF65         1.   
    PCLWRC65  PCSHAL65         1.   
    PCLWRC65  PCNAES65         1.   
    PCLWRC65  PCCLDU65         1.   
    PCLWRC65  PCPGAI65         1.   
    PCLWRC65  QPETG165         1.   
    PCLWRC65  QPETG265         1.   
    PCLWRC65  QPETG365         1.   
    PCLWRC65  QPETG465         1.   
    PCLWRC65  QCOAL165         1.   
    PCLWRC65  QNATU165         1.   
    PCLWRC65  QNATU265         1.   
    PCLWRC65  QNATU365         1.   
    PCLWRC70  PCLWRC70        10.   
    PCLWRC70  PCFBRX70         1.   
    PCLWRC70  PCSOLE70         1.   
    PCLWRC70  PCSYNF70         1.   
    PCLWRC70  PCSHAL70         1.   
    PCLWRC70  PCNAES70         1.   
    PCLWRC70  PCCLDU70         1.   
    PCLWRC70  PCPGAI70         1.   
    PCLWRC70  QPETG170         1.   
    PCLWRC70  QPETG270         1.   
    PCLWRC70  QPETG370         1.   
    PCLWRC70  QPETG470         1.   
    PCLWRC70  QCOAL170         1.   
    PCLWRC70  QNATU170         1.   
    PCLWRC70  QNATU270         1.   
    PCLWRC70  QNATU370         1.   
    PCLWRC75  PCLWRC75        10.   
    PCLWRC75  PCFBRX75         1.   
    PCLWRC75  PCSOLE75         1.   
    PCLWRC75  PCSYNF75         1.   
    PCLWRC75  PCSHAL75         1.   
    PCLWRC75  PCNAES75         1.   
    PCLWRC75  PCCLDU75         1.   
    PCLWRC75  PCPGAI75         1.   
    PCLWRC75  QPETG175         1.   
    PCLWRC75  QPETG275         1.   
    PCLWRC75  QPETG375         1.   
    PCLWRC75  QPETG475         1.   
    PCLWRC75  QCOAL175         1.   
    PCLWRC75  QNATU175         1.   
    PCLWRC75  QNATU275         1.   
    PCLWRC75  QNATU375         1.   
    PCFBRX00  PCFBRX00        10.   
    PCFBRX00  PCSOLE00         1.   
    PCFBRX00  PCSYNF00         1.   
    PCFBRX00  PCSHAL00         1.   
    PCFBRX00  PCNAES00         1.   
    PCFBRX00  PCCLDU00         1.   
    PCFBRX00  PCPGAI00         1.   
    PCFBRX00  QPETG100         1.   
    PCFBRX00  QPETG200         1.   
    PCFBRX00  QPETG300         1.   
    PCFBRX00  QPETG400         1.   
    PCFBRX00  QCOAL100         1.   
    PCFBRX00  QNATU100         1.   
    PCFBRX00  QNATU200         1.   
    PCFBRX00  QNATU300         1.   
    PCFBRX05  PCFBRX05        10.   
    PCFBRX05  PCSOLE05         1.   
    PCFBRX05  PCSYNF05         1.   
    PCFBRX05  PCSHAL05         1.   
    PCFBRX05  PCNAES05         1.   
    PCFBRX05  PCCLDU05         1.   
    PCFBRX05  PCPGAI05         1.   
    PCFBRX05  QPETG105         1.   
    PCFBRX05  QPETG205         1.   
    PCFBRX05  QPETG305         1.   
    PCFBRX05  QPETG405         1.   
    PCFBRX05  QCOAL105         1.   
    PCFBRX05  QNATU105         1.   
    PCFBRX05  QNATU205         1.   
    PCFBRX05  QNATU305         1.   
    PCFBRX10  PCFBRX10        10.   
    PCFBRX10  PCSOLE10         1.   
    PCFBRX10  PCSYNF10         1.   
    PCFBRX10  PCSHAL10         1.   
    PCFBRX10  PCNAES10         1.   
    PCFBRX10  PCCLDU10         1.   
    PCFBRX10  PCPGAI10         1.   
    PCFBRX10  QPETG110         1.   
    PCFBRX10  QPETG210         1.   
    PCFBRX10  QPETG310         1.   
    PCFBRX10  QPETG410         1.   
    PCFBRX10  QCOAL110         1.   
    PCFBRX10  QNATU110         1.   
    PCFBRX10  QNATU210         1.   
    PCFBRX10  QNATU310         1.   
    PCFBRX15  PCFBRX15        10.   
    PCFBRX15  PCSOLE15         1.   
    PCFBRX15  PCSYNF15         1.   
    PCFBRX15  PCSHAL15         1.   
    PCFBRX15  PCNAES15         1.   
    PCFBRX15  PCCLDU15         1.   
    PCFBRX15  PCPGAI15         1.   
    PCFBRX15  QPETG115         1.   
    PCFBRX15  QPETG215         1.   
    PCFBRX15  QPETG315         1.   
    PCFBRX15  QPETG415         1.   
    PCFBRX15  QCOAL115         1.   
    PCFBRX15  QNATU115         1.   
    PCFBRX15  QNATU215         1.   
    PCFBRX15  QNATU315         1.   
    PCFBRX20  PCFBRX20        10.   
    PCFBRX20  PCSOLE20         1.   
    PCFBRX20  PCSYNF20         1.   
    PCFBRX20  PCSHAL20         1.   
    PCFBRX20  PCNAES20         1.   
    PCFBRX20  PCCLDU20         1.   
    PCFBRX20  PCPGAI20         1.   
    PCFBRX20  QPETG120         1.   
    PCFBRX20  QPETG220         1.   
    PCFBRX20  QPETG320         1.   
    PCFBRX20  QPETG420         1.   
    PCFBRX20  QCOAL120         1.   
    PCFBRX20  QNATU120         1.   
    PCFBRX20  QNATU220         1.   
    PCFBRX20  QNATU320         1.   
    PCFBRX25  PCFBRX25        10.   
    PCFBRX25  PCSOLE25         1.   
    PCFBRX25  PCSYNF25         1.   
    PCFBRX25  PCSHAL25         1.   
    PCFBRX25  PCNAES25         1.   
    PCFBRX25  PCCLDU25         1.   
    PCFBRX25  PCPGAI25         1.   
    PCFBRX25  QPETG125         1.   
    PCFBRX25  QPETG225         1.   
    PCFBRX25  QPETG325         1.   
    PCFBRX25  QPETG425         1.   
    PCFBRX25  QCOAL125         1.   
    PCFBRX25  QNATU125         1.   
    PCFBRX25  QNATU225         1.   
    PCFBRX25  QNATU325         1.   
    PCFBRX30  PCFBRX30        10.   
    PCFBRX30  PCSOLE30         1.   
    PCFBRX30  PCSYNF30         1.   
    PCFBRX30  PCSHAL30         1.   
    PCFBRX30  PCNAES30         1.   
    PCFBRX30  PCCLDU30         1.   
    PCFBRX30  PCPGAI30         1.   
    PCFBRX30  QPETG130         1.   
    PCFBRX30  QPETG230         1.   
    PCFBRX30  QPETG330         1.   
    PCFBRX30  QPETG430         1.   
    PCFBRX30  QCOAL130         1.   
    PCFBRX30  QNATU130         1.   
    PCFBRX30  QNATU230         1.   
    PCFBRX30  QNATU330         1.   
    PCFBRX35  PCFBRX35        10.   
    PCFBRX35  PCSOLE35         1.   
    PCFBRX35  PCSYNF35         1.   
    PCFBRX35  PCSHAL35         1.   
    PCFBRX35  PCNAES35         1.   
    PCFBRX35  PCCLDU35         1.   
    PCFBRX35  PCPGAI35         1.   
    PCFBRX35  QPETG135         1.   
    PCFBRX35  QPETG235         1.   
    PCFBRX35  QPETG335         1.   
    PCFBRX35  QPETG435         1.   
    PCFBRX35  QCOAL135         1.   
    PCFBRX35  QNATU135         1.   
    PCFBRX35  QNATU235         1.   
    PCFBRX35  QNATU335         1.   
    PCFBRX40  PCFBRX40        10.   
    PCFBRX40  PCSOLE40         1.   
    PCFBRX40  PCSYNF40         1.   
    PCFBRX40  PCSHAL40         1.   
    PCFBRX40  PCNAES40         1.   
    PCFBRX40  PCCLDU40         1.   
    PCFBRX40  PCPGAI40         1.   
    PCFBRX40  QPETG140         1.   
    PCFBRX40  QPETG240         1.   
    PCFBRX40  QPETG340         1.   
    PCFBRX40  QPETG440         1.   
    PCFBRX40  QCOAL140         1.   
    PCFBRX40  QNATU140         1.   
    PCFBRX40  QNATU240         1.   
    PCFBRX40  QNATU340         1.   
    PCFBRX45  PCFBRX45        10.   
    PCFBRX45  PCSOLE45         1.   
    PCFBRX45  PCSYNF45         1.   
    PCFBRX45  PCSHAL45         1.   
    PCFBRX45  PCNAES45         1.   
    PCFBRX45  PCCLDU45         1.   
    PCFBRX45  PCPGAI45         1.   
    PCFBRX45  QPETG145         1.   
    PCFBRX45  QPETG245         1.   
    PCFBRX45  QPETG345         1.   
    PCFBRX45  QPETG445         1.   
    PCFBRX45  QCOAL145         1.   
    PCFBRX45  QNATU145         1.   
    PCFBRX45  QNATU245         1.   
    PCFBRX45  QNATU345         1.   
    PCFBRX50  PCFBRX50        10.   
    PCFBRX50  PCSOLE50         1.   
    PCFBRX50  PCSYNF50         1.   
    PCFBRX50  PCSHAL50         1.   
    PCFBRX50  PCNAES50         1.   
    PCFBRX50  PCCLDU50         1.   
    PCFBRX50  PCPGAI50         1.   
    PCFBRX50  QPETG150         1.   
    PCFBRX50  QPETG250         1.   
    PCFBRX50  QPETG350         1.   
    PCFBRX50  QPETG450         1.   
    PCFBRX50  QCOAL150         1.   
    PCFBRX50  QNATU150         1.   
    PCFBRX50  QNATU250         1.   
    PCFBRX50  QNATU350         1.   
    PCFBRX55  PCFBRX55        10.   
    PCFBRX55  PCSOLE55         1.   
    PCFBRX55  PCSYNF55         1.   
    PCFBRX55  PCSHAL55         1.   
    PCFBRX55  PCNAES55         1.   
    PCFBRX55  PCCLDU55         1.   
    PCFBRX55  PCPGAI55         1.   
    PCFBRX55  QPETG155         1.   
    PCFBRX55  QPETG255         1.   
    PCFBRX55  QPETG355         1.   
    PCFBRX55  QPETG455         1.   
    PCFBRX55  QCOAL155         1.   
    PCFBRX55  QNATU155         1.   
    PCFBRX55  QNATU255         1.   
    PCFBRX55  QNATU355         1.   
    PCFBRX60  PCFBRX60        10.   
    PCFBRX60  PCSOLE60         1.   
    PCFBRX60  PCSYNF60         1.   
    PCFBRX60  PCSHAL60         1.   
    PCFBRX60  PCNAES60         1.   
    PCFBRX60  PCCLDU60         1.   
    PCFBRX60  PCPGAI60         1.   
    PCFBRX60  QPETG160         1.   
    PCFBRX60  QPETG260         1.   
    PCFBRX60  QPETG360         1.   
    PCFBRX60  QPETG460         1.   
    PCFBRX60  QCOAL160         1.   
    PCFBRX60  QNATU160         1.   
    PCFBRX60  QNATU260         1.   
    PCFBRX60  QNATU360         1.   
    PCFBRX65  PCFBRX65        10.   
    PCFBRX65  PCSOLE65         1.   
    PCFBRX65  PCSYNF65         1.   
    PCFBRX65  PCSHAL65         1.   
    PCFBRX65  PCNAES65         1.   
    PCFBRX65  PCCLDU65         1.   
    PCFBRX65  PCPGAI65         1.   
    PCFBRX65  QPETG165         1.   
    PCFBRX65  QPETG265         1.   
    PCFBRX65  QPETG365         1.   
    PCFBRX65  QPETG465         1.   
    PCFBRX65  QCOAL165         1.   
    PCFBRX65  QNATU165         1.   
    PCFBRX65  QNATU265         1.   
    PCFBRX65  QNATU365         1.   
    PCFBRX70  PCFBRX70        10.   
    PCFBRX70  PCSOLE70         1.   
    PCFBRX70  PCSYNF70         1.   
    PCFBRX70  PCSHAL70         1.   
    PCFBRX70  PCNAES70         1.   
    PCFBRX70  PCCLDU70         1.   
    PCFBRX70  PCPGAI70         1.   
    PCFBRX70  QPETG170         1.   
    PCFBRX70  QPETG270         1.   
    PCFBRX70  QPETG370         1.   
    PCFBRX70  QPETG470         1.   
    PCFBRX70  QCOAL170         1.   
    PCFBRX70  QNATU170         1.   
    PCFBRX70  QNATU270         1.   
    PCFBRX70  QNATU370         1.   
    PCFBRX75  PCFBRX75        10.   
    PCFBRX75  PCSOLE75         1.   
    PCFBRX75  PCSYNF75         1.   
    PCFBRX75  PCSHAL75         1.   
    PCFBRX75  PCNAES75         1.   
    PCFBRX75  PCCLDU75         1.   
    PCFBRX75  PCPGAI75         1.   
    PCFBRX75  QPETG175         1.   
    PCFBRX75  QPETG275         1.   
    PCFBRX75  QPETG375         1.   
    PCFBRX75  QPETG475         1.   
    PCFBRX75  QCOAL175         1.   
    PCFBRX75  QNATU175         1.   
    PCFBRX75  QNATU275         1.   
    PCFBRX75  QNATU375         1.   
    PCSOLE00  PCSOLE00        10.   
    PCSOLE00  PCSYNF00         1.   
    PCSOLE00  PCSHAL00         1.   
    PCSOLE00  PCNAES00         1.   
    PCSOLE00  PCCLDU00         1.   
    PCSOLE00  PCPGAI00         1.   
    PCSOLE00  QPETG100         1.   
    PCSOLE00  QPETG200         1.   
    PCSOLE00  QPETG300         1.   
    PCSOLE00  QPETG400         1.   
    PCSOLE00  QCOAL100         1.   
    PCSOLE00  QNATU100         1.   
    PCSOLE00  QNATU200         1.   
    PCSOLE00  QNATU300         1.   
    PCSOLE05  PCSOLE05        10.   
    PCSOLE05  PCSYNF05         1.   
    PCSOLE05  PCSHAL05         1.   
    PCSOLE05  PCNAES05         1.   
    PCSOLE05  PCCLDU05         1.   
    PCSOLE05  PCPGAI05         1.   
    PCSOLE05  QPETG105         1.   
    PCSOLE05  QPETG205         1.   
    PCSOLE05  QPETG305         1.   
    PCSOLE05  QPETG405         1.   
    PCSOLE05  QCOAL105         1.   
    PCSOLE05  QNATU105         1.   
    PCSOLE05  QNATU205         1.   
    PCSOLE05  QNATU305         1.   
    PCSOLE10  PCSOLE10        10.   
    PCSOLE10  PCSYNF10         1.   
    PCSOLE10  PCSHAL10         1.   
    PCSOLE10  PCNAES10         1.   
    PCSOLE10  PCCLDU10         1.   
    PCSOLE10  PCPGAI10         1.   
    PCSOLE10  QPETG110         1.   
    PCSOLE10  QPETG210         1.   
    PCSOLE10  QPETG310         1.   
    PCSOLE10  QPETG410         1.   
    PCSOLE10  QCOAL110         1.   
    PCSOLE10  QNATU110         1.   
    PCSOLE10  QNATU210         1.   
    PCSOLE10  QNATU310         1.   
    PCSOLE15  PCSOLE15        10.   
    PCSOLE15  PCSYNF15         1.   
    PCSOLE15  PCSHAL15         1.   
    PCSOLE15  PCNAES15         1.   
    PCSOLE15  PCCLDU15         1.   
    PCSOLE15  PCPGAI15         1.   
    PCSOLE15  QPETG115         1.   
    PCSOLE15  QPETG215         1.   
    PCSOLE15  QPETG315         1.   
    PCSOLE15  QPETG415         1.   
    PCSOLE15  QCOAL115         1.   
    PCSOLE15  QNATU115         1.   
    PCSOLE15  QNATU215         1.   
    PCSOLE15  QNATU315         1.   
    PCSOLE20  PCSOLE20        10.   
    PCSOLE20  PCSYNF20         1.   
    PCSOLE20  PCSHAL20         1.   
    PCSOLE20  PCNAES20         1.   
    PCSOLE20  PCCLDU20         1.   
    PCSOLE20  PCPGAI20         1.   
    PCSOLE20  QPETG120         1.   
    PCSOLE20  QPETG220         1.   
    PCSOLE20  QPETG320         1.   
    PCSOLE20  QPETG420         1.   
    PCSOLE20  QCOAL120         1.   
    PCSOLE20  QNATU120         1.   
    PCSOLE20  QNATU220         1.   
    PCSOLE20  QNATU320         1.   
    PCSOLE25  PCSOLE25        10.   
    PCSOLE25  PCSYNF25         1.   
    PCSOLE25  PCSHAL25         1.   
    PCSOLE25  PCNAES25         1.   
    PCSOLE25  PCCLDU25         1.   
    PCSOLE25  PCPGAI25         1.   
    PCSOLE25  QPETG125         1.   
    PCSOLE25  QPETG225         1.   
    PCSOLE25  QPETG325         1.   
    PCSOLE25  QPETG425         1.   
    PCSOLE25  QCOAL125         1.   
    PCSOLE25  QNATU125         1.   
    PCSOLE25  QNATU225         1.   
    PCSOLE25  QNATU325         1.   
    PCSOLE30  PCSOLE30        10.   
    PCSOLE30  PCSYNF30         1.   
    PCSOLE30  PCSHAL30         1.   
    PCSOLE30  PCNAES30         1.   
    PCSOLE30  PCCLDU30         1.   
    PCSOLE30  PCPGAI30         1.   
    PCSOLE30  QPETG130         1.   
    PCSOLE30  QPETG230         1.   
    PCSOLE30  QPETG330         1.   
    PCSOLE30  QPETG430         1.   
    PCSOLE30  QCOAL130         1.   
    PCSOLE30  QNATU130         1.   
    PCSOLE30  QNATU230         1.   
    PCSOLE30  QNATU330         1.   
    PCSOLE35  PCSOLE35        10.   
    PCSOLE35  PCSYNF35         1.   
    PCSOLE35  PCSHAL35         1.   
    PCSOLE35  PCNAES35         1.   
    PCSOLE35  PCCLDU35         1.   
    PCSOLE35  PCPGAI35         1.   
    PCSOLE35  QPETG135         1.   
    PCSOLE35  QPETG235         1.   
    PCSOLE35  QPETG335         1.   
    PCSOLE35  QPETG435         1.   
    PCSOLE35  QCOAL135         1.   
    PCSOLE35  QNATU135         1.   
    PCSOLE35  QNATU235         1.   
    PCSOLE35  QNATU335         1.   
    PCSOLE40  PCSOLE40        10.   
    PCSOLE40  PCSYNF40         1.   
    PCSOLE40  PCSHAL40         1.   
    PCSOLE40  PCNAES40         1.   
    PCSOLE40  PCCLDU40         1.   
    PCSOLE40  PCPGAI40         1.   
    PCSOLE40  QPETG140         1.   
    PCSOLE40  QPETG240         1.   
    PCSOLE40  QPETG340         1.   
    PCSOLE40  QPETG440         1.   
    PCSOLE40  QCOAL140         1.   
    PCSOLE40  QNATU140         1.   
    PCSOLE40  QNATU240         1.   
    PCSOLE40  QNATU340         1.   
    PCSOLE45  PCSOLE45        10.   
    PCSOLE45  PCSYNF45         1.   
    PCSOLE45  PCSHAL45         1.   
    PCSOLE45  PCNAES45         1.   
    PCSOLE45  PCCLDU45         1.   
    PCSOLE45  PCPGAI45         1.   
    PCSOLE45  QPETG145         1.   
    PCSOLE45  QPETG245         1.   
    PCSOLE45  QPETG345         1.   
    PCSOLE45  QPETG445         1.   
    PCSOLE45  QCOAL145         1.   
    PCSOLE45  QNATU145         1.   
    PCSOLE45  QNATU245         1.   
    PCSOLE45  QNATU345         1.   
    PCSOLE50  PCSOLE50        10.   
    PCSOLE50  PCSYNF50         1.   
    PCSOLE50  PCSHAL50         1.   
    PCSOLE50  PCNAES50         1.   
    PCSOLE50  PCCLDU50         1.   
    PCSOLE50  PCPGAI50         1.   
    PCSOLE50  QPETG150         1.   
    PCSOLE50  QPETG250         1.   
    PCSOLE50  QPETG350         1.   
    PCSOLE50  QPETG450         1.   
    PCSOLE50  QCOAL150         1.   
    PCSOLE50  QNATU150         1.   
    PCSOLE50  QNATU250         1.   
    PCSOLE50  QNATU350         1.   
    PCSOLE55  PCSOLE55        10.   
    PCSOLE55  PCSYNF55         1.   
    PCSOLE55  PCSHAL55         1.   
    PCSOLE55  PCNAES55         1.   
    PCSOLE55  PCCLDU55         1.   
    PCSOLE55  PCPGAI55         1.   
    PCSOLE55  QPETG155         1.   
    PCSOLE55  QPETG255         1.   
    PCSOLE55  QPETG355         1.   
    PCSOLE55  QPETG455         1.   
    PCSOLE55  QCOAL155         1.   
    PCSOLE55  QNATU155         1.   
    PCSOLE55  QNATU255         1.   
    PCSOLE55  QNATU355         1.   
    PCSOLE60  PCSOLE60        10.   
    PCSOLE60  PCSYNF60         1.   
    PCSOLE60  PCSHAL60         1.   
    PCSOLE60  PCNAES60         1.   
    PCSOLE60  PCCLDU60         1.   
    PCSOLE60  PCPGAI60         1.   
    PCSOLE60  QPETG160         1.   
    PCSOLE60  QPETG260         1.   
    PCSOLE60  QPETG360         1.   
    PCSOLE60  QPETG460         1.   
    PCSOLE60  QCOAL160         1.   
    PCSOLE60  QNATU160         1.   
    PCSOLE60  QNATU260         1.   
    PCSOLE60  QNATU360         1.   
    PCSOLE65  PCSOLE65        10.   
    PCSOLE65  PCSYNF65         1.   
    PCSOLE65  PCSHAL65         1.   
    PCSOLE65  PCNAES65         1.   
    PCSOLE65  PCCLDU65         1.   
    PCSOLE65  PCPGAI65         1.   
    PCSOLE65  QPETG165         1.   
    PCSOLE65  QPETG265         1.   
    PCSOLE65  QPETG365         1.   
    PCSOLE65  QPETG465         1.   
    PCSOLE65  QCOAL165         1.   
    PCSOLE65  QNATU165         1.   
    PCSOLE65  QNATU265         1.   
    PCSOLE65  QNATU365         1.   
    PCSOLE70  PCSOLE70        10.   
    PCSOLE70  PCSYNF70         1.   
    PCSOLE70  PCSHAL70         1.   
    PCSOLE70  PCNAES70         1.   
    PCSOLE70  PCCLDU70         1.   
    PCSOLE70  PCPGAI70         1.   
    PCSOLE70  QPETG170         1.   
    PCSOLE70  QPETG270         1.   
    PCSOLE70  QPETG370         1.   
    PCSOLE70  QPETG470         1.   
    PCSOLE70  QCOAL170         1.   
    PCSOLE70  QNATU170         1.   
    PCSOLE70  QNATU270         1.   
    PCSOLE70  QNATU370         1.   
    PCSOLE75  PCSOLE75        10.   
    PCSOLE75  PCSYNF75         1.   
    PCSOLE75  PCSHAL75         1.   
    PCSOLE75  PCNAES75         1.   
    PCSOLE75  PCCLDU75         1.   
    PCSOLE75  PCPGAI75         1.   
    PCSOLE75  QPETG175         1.   
    PCSOLE75  QPETG275         1.   
    PCSOLE75  QPETG375         1.   
    PCSOLE75  QPETG475         1.   
    PCSOLE75  QCOAL175         1.   
    PCSOLE75  QNATU175         1.   
    PCSOLE75  QNATU275         1.   
    PCSOLE75  QNATU375         1.   
    PCSYNF00  PCSYNF00        10.   
    PCSYNF00  PCSHAL00         1.   
    PCSYNF00  PCNAES00         1.   
    PCSYNF00  PCCLDU00         1.   
    PCSYNF00  PCPGAI00         1.   
    PCSYNF00  QPETG100         1.   
    PCSYNF00  QPETG200         1.   
    PCSYNF00  QPETG300         1.   
    PCSYNF00  QPETG400         1.   
    PCSYNF00  QCOAL100         1.   
    PCSYNF00  QNATU100         1.   
    PCSYNF00  QNATU200         1.   
    PCSYNF00  QNATU300         1.   
    PCSYNF05  PCSYNF05        10.   
    PCSYNF05  PCSHAL05         1.   
    PCSYNF05  PCNAES05         1.   
    PCSYNF05  PCCLDU05         1.   
    PCSYNF05  PCPGAI05         1.   
    PCSYNF05  QPETG105         1.   
    PCSYNF05  QPETG205         1.   
    PCSYNF05  QPETG305         1.   
    PCSYNF05  QPETG405         1.   
    PCSYNF05  QCOAL105         1.   
    PCSYNF05  QNATU105         1.   
    PCSYNF05  QNATU205         1.   
    PCSYNF05  QNATU305         1.   
    PCSYNF10  PCSYNF10        10.   
    PCSYNF10  PCSHAL10         1.   
    PCSYNF10  PCNAES10         1.   
    PCSYNF10  PCCLDU10         1.   
    PCSYNF10  PCPGAI10         1.   
    PCSYNF10  QPETG110         1.   
    PCSYNF10  QPETG210         1.   
    PCSYNF10  QPETG310         1.   
    PCSYNF10  QPETG410         1.   
    PCSYNF10  QCOAL110         1.   
    PCSYNF10  QNATU110         1.   
    PCSYNF10  QNATU210         1.   
    PCSYNF10  QNATU310         1.   
    PCSYNF15  PCSYNF15        10.   
    PCSYNF15  PCSHAL15         1.   
    PCSYNF15  PCNAES15         1.   
    PCSYNF15  PCCLDU15         1.   
    PCSYNF15  PCPGAI15         1.   
    PCSYNF15  QPETG115         1.   
    PCSYNF15  QPETG215         1.   
    PCSYNF15  QPETG315         1.   
    PCSYNF15  QPETG415         1.   
    PCSYNF15  QCOAL115         1.   
    PCSYNF15  QNATU115         1.   
    PCSYNF15  QNATU215         1.   
    PCSYNF15  QNATU315         1.   
    PCSYNF20  PCSYNF20        10.   
    PCSYNF20  PCSHAL20         1.   
    PCSYNF20  PCNAES20         1.   
    PCSYNF20  PCCLDU20         1.   
    PCSYNF20  PCPGAI20         1.   
    PCSYNF20  QPETG120         1.   
    PCSYNF20  QPETG220         1.   
    PCSYNF20  QPETG320         1.   
    PCSYNF20  QPETG420         1.   
    PCSYNF20  QCOAL120         1.   
    PCSYNF20  QNATU120         1.   
    PCSYNF20  QNATU220         1.   
    PCSYNF20  QNATU320         1.   
    PCSYNF25  PCSYNF25        10.   
    PCSYNF25  PCSHAL25         1.   
    PCSYNF25  PCNAES25         1.   
    PCSYNF25  PCCLDU25         1.   
    PCSYNF25  PCPGAI25         1.   
    PCSYNF25  QPETG125         1.   
    PCSYNF25  QPETG225         1.   
    PCSYNF25  QPETG325         1.   
    PCSYNF25  QPETG425         1.   
    PCSYNF25  QCOAL125         1.   
    PCSYNF25  QNATU125         1.   
    PCSYNF25  QNATU225         1.   
    PCSYNF25  QNATU325         1.   
    PCSYNF30  PCSYNF30        10.   
    PCSYNF30  PCSHAL30         1.   
    PCSYNF30  PCNAES30         1.   
    PCSYNF30  PCCLDU30         1.   
    PCSYNF30  PCPGAI30         1.   
    PCSYNF30  QPETG130         1.   
    PCSYNF30  QPETG230         1.   
    PCSYNF30  QPETG330         1.   
    PCSYNF30  QPETG430         1.   
    PCSYNF30  QCOAL130         1.   
    PCSYNF30  QNATU130         1.   
    PCSYNF30  QNATU230         1.   
    PCSYNF30  QNATU330         1.   
    PCSYNF35  PCSYNF35        10.   
    PCSYNF35  PCSHAL35         1.   
    PCSYNF35  PCNAES35         1.   
    PCSYNF35  PCCLDU35         1.   
    PCSYNF35  PCPGAI35         1.   
    PCSYNF35  QPETG135         1.   
    PCSYNF35  QPETG235         1.   
    PCSYNF35  QPETG335         1.   
    PCSYNF35  QPETG435         1.   
    PCSYNF35  QCOAL135         1.   
    PCSYNF35  QNATU135         1.   
    PCSYNF35  QNATU235         1.   
    PCSYNF35  QNATU335         1.   
    PCSYNF40  PCSYNF40        10.   
    PCSYNF40  PCSHAL40         1.   
    PCSYNF40  PCNAES40         1.   
    PCSYNF40  PCCLDU40         1.   
    PCSYNF40  PCPGAI40         1.   
    PCSYNF40  QPETG140         1.   
    PCSYNF40  QPETG240         1.   
    PCSYNF40  QPETG340         1.   
    PCSYNF40  QPETG440         1.   
    PCSYNF40  QCOAL140         1.   
    PCSYNF40  QNATU140         1.   
    PCSYNF40  QNATU240         1.   
    PCSYNF40  QNATU340         1.   
    PCSYNF45  PCSYNF45        10.   
    PCSYNF45  PCSHAL45         1.   
    PCSYNF45  PCNAES45         1.   
    PCSYNF45  PCCLDU45         1.   
    PCSYNF45  PCPGAI45         1.   
    PCSYNF45  QPETG145         1.   
    PCSYNF45  QPETG245         1.   
    PCSYNF45  QPETG345         1.   
    PCSYNF45  QPETG445         1.   
    PCSYNF45  QCOAL145         1.   
    PCSYNF45  QNATU145         1.   
    PCSYNF45  QNATU245         1.   
    PCSYNF45  QNATU345         1.   
    PCSYNF50  PCSYNF50        10.   
    PCSYNF50  PCSHAL50         1.   
    PCSYNF50  PCNAES50         1.   
    PCSYNF50  PCCLDU50         1.   
    PCSYNF50  PCPGAI50         1.   
    PCSYNF50  QPETG150         1.   
    PCSYNF50  QPETG250         1.   
    PCSYNF50  QPETG350         1.   
    PCSYNF50  QPETG450         1.   
    PCSYNF50  QCOAL150         1.   
    PCSYNF50  QNATU150         1.   
    PCSYNF50  QNATU250         1.   
    PCSYNF50  QNATU350         1.   
    PCSYNF55  PCSYNF55        10.   
    PCSYNF55  PCSHAL55         1.   
    PCSYNF55  PCNAES55         1.   
    PCSYNF55  PCCLDU55         1.   
    PCSYNF55  PCPGAI55         1.   
    PCSYNF55  QPETG155         1.   
    PCSYNF55  QPETG255         1.   
    PCSYNF55  QPETG355         1.   
    PCSYNF55  QPETG455         1.   
    PCSYNF55  QCOAL155         1.   
    PCSYNF55  QNATU155         1.   
    PCSYNF55  QNATU255         1.   
    PCSYNF55  QNATU355         1.   
    PCSYNF60  PCSYNF60        10.   
    PCSYNF60  PCSHAL60         1.   
    PCSYNF60  PCNAES60         1.   
    PCSYNF60  PCCLDU60         1.   
    PCSYNF60  PCPGAI60         1.   
    PCSYNF60  QPETG160         1.   
    PCSYNF60  QPETG260         1.   
    PCSYNF60  QPETG360         1.   
    PCSYNF60  QPETG460         1.   
    PCSYNF60  QCOAL160         1.   
    PCSYNF60  QNATU160         1.   
    PCSYNF60  QNATU260         1.   
    PCSYNF60  QNATU360         1.   
    PCSYNF65  PCSYNF65        10.   
    PCSYNF65  PCSHAL65         1.   
    PCSYNF65  PCNAES65         1.   
    PCSYNF65  PCCLDU65         1.   
    PCSYNF65  PCPGAI65         1.   
    PCSYNF65  QPETG165         1.   
    PCSYNF65  QPETG265         1.   
    PCSYNF65  QPETG365         1.   
    PCSYNF65  QPETG465         1.   
    PCSYNF65  QCOAL165         1.   
    PCSYNF65  QNATU165         1.   
    PCSYNF65  QNATU265         1.   
    PCSYNF65  QNATU365         1.   
    PCSYNF70  PCSYNF70        10.   
    PCSYNF70  PCSHAL70         1.   
    PCSYNF70  PCNAES70         1.   
    PCSYNF70  PCCLDU70         1.   
    PCSYNF70  PCPGAI70         1.   
    PCSYNF70  QPETG170         1.   
    PCSYNF70  QPETG270         1.   
    PCSYNF70  QPETG370         1.   
    PCSYNF70  QPETG470         1.   
    PCSYNF70  QCOAL170         1.   
    PCSYNF70  QNATU170         1.   
    PCSYNF70  QNATU270         1.   
    PCSYNF70  QNATU370         1.   
    PCSYNF75  PCSYNF75        10.   
    PCSYNF75  PCSHAL75         1.   
    PCSYNF75  PCNAES75         1.   
    PCSYNF75  PCCLDU75         1.   
    PCSYNF75  PCPGAI75         1.   
    PCSYNF75  QPETG175         1.   
    PCSYNF75  QPETG275         1.   
    PCSYNF75  QPETG375         1.   
    PCSYNF75  QPETG475         1.   
    PCSYNF75  QCOAL175         1.   
    PCSYNF75  QNATU175         1.   
    PCSYNF75  QNATU275         1.   
    PCSYNF75  QNATU375         1.   
    PCSHAL00  PCSHAL00        10.   
    PCSHAL00  PCNAES00         1.   
    PCSHAL00  PCCLDU00         1.   
    PCSHAL00  PCPGAI00         1.   
    PCSHAL00  QPETG100         1.   
    PCSHAL00  QPETG200         1.   
    PCSHAL00  QPETG300         1.   
    PCSHAL00  QPETG400         1.   
    PCSHAL00  QCOAL100         1.   
    PCSHAL00  QNATU100         1.   
    PCSHAL00  QNATU200         1.   
    PCSHAL00  QNATU300         1.   
    PCSHAL05  PCSHAL05        10.   
    PCSHAL05  PCNAES05         1.   
    PCSHAL05  PCCLDU05         1.   
    PCSHAL05  PCPGAI05         1.   
    PCSHAL05  QPETG105         1.   
    PCSHAL05  QPETG205         1.   
    PCSHAL05  QPETG305         1.   
    PCSHAL05  QPETG405         1.   
    PCSHAL05  QCOAL105         1.   
    PCSHAL05  QNATU105         1.   
    PCSHAL05  QNATU205         1.   
    PCSHAL05  QNATU305         1.   
    PCSHAL10  PCSHAL10        10.   
    PCSHAL10  PCNAES10         1.   
    PCSHAL10  PCCLDU10         1.   
    PCSHAL10  PCPGAI10         1.   
    PCSHAL10  QPETG110         1.   
    PCSHAL10  QPETG210         1.   
    PCSHAL10  QPETG310         1.   
    PCSHAL10  QPETG410         1.   
    PCSHAL10  QCOAL110         1.   
    PCSHAL10  QNATU110         1.   
    PCSHAL10  QNATU210         1.   
    PCSHAL10  QNATU310         1.   
    PCSHAL15  PCSHAL15        10.   
    PCSHAL15  PCNAES15         1.   
    PCSHAL15  PCCLDU15         1.   
    PCSHAL15  PCPGAI15         1.   
    PCSHAL15  QPETG115         1.   
    PCSHAL15  QPETG215         1.   
    PCSHAL15  QPETG315         1.   
    PCSHAL15  QPETG415         1.   
    PCSHAL15  QCOAL115         1.   
    PCSHAL15  QNATU115         1.   
    PCSHAL15  QNATU215         1.   
    PCSHAL15  QNATU315         1.   
    PCSHAL20  PCSHAL20        10.   
    PCSHAL20  PCNAES20         1.   
    PCSHAL20  PCCLDU20         1.   
    PCSHAL20  PCPGAI20         1.   
    PCSHAL20  QPETG120         1.   
    PCSHAL20  QPETG220         1.   
    PCSHAL20  QPETG320         1.   
    PCSHAL20  QPETG420         1.   
    PCSHAL20  QCOAL120         1.   
    PCSHAL20  QNATU120         1.   
    PCSHAL20  QNATU220         1.   
    PCSHAL20  QNATU320         1.   
    PCSHAL25  PCSHAL25        10.   
    PCSHAL25  PCNAES25         1.   
    PCSHAL25  PCCLDU25         1.   
    PCSHAL25  PCPGAI25         1.   
    PCSHAL25  QPETG125         1.   
    PCSHAL25  QPETG225         1.   
    PCSHAL25  QPETG325         1.   
    PCSHAL25  QPETG425         1.   
    PCSHAL25  QCOAL125         1.   
    PCSHAL25  QNATU125         1.   
    PCSHAL25  QNATU225         1.   
    PCSHAL25  QNATU325         1.   
    PCSHAL30  PCSHAL30        10.   
    PCSHAL30  PCNAES30         1.   
    PCSHAL30  PCCLDU30         1.   
    PCSHAL30  PCPGAI30         1.   
    PCSHAL30  QPETG130         1.   
    PCSHAL30  QPETG230         1.   
    PCSHAL30  QPETG330         1.   
    PCSHAL30  QPETG430         1.   
    PCSHAL30  QCOAL130         1.   
    PCSHAL30  QNATU130         1.   
    PCSHAL30  QNATU230         1.   
    PCSHAL30  QNATU330         1.   
    PCSHAL35  PCSHAL35        10.   
    PCSHAL35  PCNAES35         1.   
    PCSHAL35  PCCLDU35         1.   
    PCSHAL35  PCPGAI35         1.   
    PCSHAL35  QPETG135         1.   
    PCSHAL35  QPETG235         1.   
    PCSHAL35  QPETG335         1.   
    PCSHAL35  QPETG435         1.   
    PCSHAL35  QCOAL135         1.   
    PCSHAL35  QNATU135         1.   
    PCSHAL35  QNATU235         1.   
    PCSHAL35  QNATU335         1.   
    PCSHAL40  PCSHAL40        10.   
    PCSHAL40  PCNAES40         1.   
    PCSHAL40  PCCLDU40         1.   
    PCSHAL40  PCPGAI40         1.   
    PCSHAL40  QPETG140         1.   
    PCSHAL40  QPETG240         1.   
    PCSHAL40  QPETG340         1.   
    PCSHAL40  QPETG440         1.   
    PCSHAL40  QCOAL140         1.   
    PCSHAL40  QNATU140         1.   
    PCSHAL40  QNATU240         1.   
    PCSHAL40  QNATU340         1.   
    PCSHAL45  PCSHAL45        10.   
    PCSHAL45  PCNAES45         1.   
    PCSHAL45  PCCLDU45         1.   
    PCSHAL45  PCPGAI45         1.   
    PCSHAL45  QPETG145         1.   
    PCSHAL45  QPETG245         1.   
    PCSHAL45  QPETG345         1.   
    PCSHAL45  QPETG445         1.   
    PCSHAL45  QCOAL145         1.   
    PCSHAL45  QNATU145         1.   
    PCSHAL45  QNATU245         1.   
    PCSHAL45  QNATU345         1.   
    PCSHAL50  PCSHAL50        10.   
    PCSHAL50  PCNAES50         1.   
    PCSHAL50  PCCLDU50         1.   
    PCSHAL50  PCPGAI50         1.   
    PCSHAL50  QPETG150         1.   
    PCSHAL50  QPETG250         1.   
    PCSHAL50  QPETG350         1.   
    PCSHAL50  QPETG450         1.   
    PCSHAL50  QCOAL150         1.   
    PCSHAL50  QNATU150         1.   
    PCSHAL50  QNATU250         1.   
    PCSHAL50  QNATU350         1.   
    PCSHAL55  PCSHAL55        10.   
    PCSHAL55  PCNAES55         1.   
    PCSHAL55  PCCLDU55         1.   
    PCSHAL55  PCPGAI55         1.   
    PCSHAL55  QPETG155         1.   
    PCSHAL55  QPETG255         1.   
    PCSHAL55  QPETG355         1.   
    PCSHAL55  QPETG455         1.   
    PCSHAL55  QCOAL155         1.   
    PCSHAL55  QNATU155         1.   
    PCSHAL55  QNATU255         1.   
    PCSHAL55  QNATU355         1.   
    PCSHAL60  PCSHAL60        10.   
    PCSHAL60  PCNAES60         1.   
    PCSHAL60  PCCLDU60         1.   
    PCSHAL60  PCPGAI60         1.   
    PCSHAL60  QPETG160         1.   
    PCSHAL60  QPETG260         1.   
    PCSHAL60  QPETG360         1.   
    PCSHAL60  QPETG460         1.   
    PCSHAL60  QCOAL160         1.   
    PCSHAL60  QNATU160         1.   
    PCSHAL60  QNATU260         1.   
    PCSHAL60  QNATU360         1.   
    PCSHAL65  PCSHAL65        10.   
    PCSHAL65  PCNAES65         1.   
    PCSHAL65  PCCLDU65         1.   
    PCSHAL65  PCPGAI65         1.   
    PCSHAL65  QPETG165         1.   
    PCSHAL65  QPETG265         1.   
    PCSHAL65  QPETG365         1.   
    PCSHAL65  QPETG465         1.   
    PCSHAL65  QCOAL165         1.   
    PCSHAL65  QNATU165         1.   
    PCSHAL65  QNATU265         1.   
    PCSHAL65  QNATU365         1.   
    PCSHAL70  PCSHAL70        10.   
    PCSHAL70  PCNAES70         1.   
    PCSHAL70  PCCLDU70         1.   
    PCSHAL70  PCPGAI70         1.   
    PCSHAL70  QPETG170         1.   
    PCSHAL70  QPETG270         1.   
    PCSHAL70  QPETG370         1.   
    PCSHAL70  QPETG470         1.   
    PCSHAL70  QCOAL170         1.   
    PCSHAL70  QNATU170         1.   
    PCSHAL70  QNATU270         1.   
    PCSHAL70  QNATU370         1.   
    PCSHAL75  PCSHAL75        10.   
    PCSHAL75  PCNAES75         1.   
    PCSHAL75  PCCLDU75         1.   
    PCSHAL75  PCPGAI75         1.   
    PCSHAL75  QPETG175         1.   
    PCSHAL75  QPETG275         1.   
    PCSHAL75  QPETG375         1.   
    PCSHAL75  QPETG475         1.   
    PCSHAL75  QCOAL175         1.   
    PCSHAL75  QNATU175         1.   
    PCSHAL75  QNATU275         1.   
    PCSHAL75  QNATU375         1.   
    PCNAES00  PCNAES00        10.   
    PCNAES00  PCCLDU00         1.   
    PCNAES00  PCPGAI00         1.   
    PCNAES00  QPETG100         1.   
    PCNAES00  QPETG200         1.   
    PCNAES00  QPETG300         1.   
    PCNAES00  QPETG400         1.   
    PCNAES00  QCOAL100         1.   
    PCNAES00  QNATU100         1.   
    PCNAES00  QNATU200         1.   
    PCNAES00  QNATU300         1.   
    PCNAES05  PCNAES05        10.   
    PCNAES05  PCCLDU05         1.   
    PCNAES05  PCPGAI05         1.   
    PCNAES05  QPETG105         1.   
    PCNAES05  QPETG205         1.   
    PCNAES05  QPETG305         1.   
    PCNAES05  QPETG405         1.   
    PCNAES05  QCOAL105         1.   
    PCNAES05  QNATU105         1.   
    PCNAES05  QNATU205         1.   
    PCNAES05  QNATU305         1.   
    PCNAES10  PCNAES10        10.   
    PCNAES10  PCCLDU10         1.   
    PCNAES10  PCPGAI10         1.   
    PCNAES10  QPETG110         1.   
    PCNAES10  QPETG210         1.   
    PCNAES10  QPETG310         1.   
    PCNAES10  QPETG410         1.   
    PCNAES10  QCOAL110         1.   
    PCNAES10  QNATU110         1.   
    PCNAES10  QNATU210         1.   
    PCNAES10  QNATU310         1.   
    PCNAES15  PCNAES15        10.   
    PCNAES15  PCCLDU15         1.   
    PCNAES15  PCPGAI15         1.   
    PCNAES15  QPETG115         1.   
    PCNAES15  QPETG215         1.   
    PCNAES15  QPETG315         1.   
    PCNAES15  QPETG415         1.   
    PCNAES15  QCOAL115         1.   
    PCNAES15  QNATU115         1.   
    PCNAES15  QNATU215         1.   
    PCNAES15  QNATU315         1.   
    PCNAES20  PCNAES20        10.   
    PCNAES20  PCCLDU20         1.   
    PCNAES20  PCPGAI20         1.   
    PCNAES20  QPETG120         1.   
    PCNAES20  QPETG220         1.   
    PCNAES20  QPETG320         1.   
    PCNAES20  QPETG420         1.   
    PCNAES20  QCOAL120         1.   
    PCNAES20  QNATU120         1.   
    PCNAES20  QNATU220         1.   
    PCNAES20  QNATU320         1.   
    PCNAES25  PCNAES25        10.   
    PCNAES25  PCCLDU25         1.   
    PCNAES25  PCPGAI25         1.   
    PCNAES25  QPETG125         1.   
    PCNAES25  QPETG225         1.   
    PCNAES25  QPETG325         1.   
    PCNAES25  QPETG425         1.   
    PCNAES25  QCOAL125         1.   
    PCNAES25  QNATU125         1.   
    PCNAES25  QNATU225         1.   
    PCNAES25  QNATU325         1.   
    PCNAES30  PCNAES30        10.   
    PCNAES30  PCCLDU30         1.   
    PCNAES30  PCPGAI30         1.   
    PCNAES30  QPETG130         1.   
    PCNAES30  QPETG230         1.   
    PCNAES30  QPETG330         1.   
    PCNAES30  QPETG430         1.   
    PCNAES30  QCOAL130         1.   
    PCNAES30  QNATU130         1.   
    PCNAES30  QNATU230         1.   
    PCNAES30  QNATU330         1.   
    PCNAES35  PCNAES35        10.   
    PCNAES35  PCCLDU35         1.   
    PCNAES35  PCPGAI35         1.   
    PCNAES35  QPETG135         1.   
    PCNAES35  QPETG235         1.   
    PCNAES35  QPETG335         1.   
    PCNAES35  QPETG435         1.   
    PCNAES35  QCOAL135         1.   
    PCNAES35  QNATU135         1.   
    PCNAES35  QNATU235         1.   
    PCNAES35  QNATU335         1.   
    PCNAES40  PCNAES40        10.   
    PCNAES40  PCCLDU40         1.   
    PCNAES40  PCPGAI40         1.   
    PCNAES40  QPETG140         1.   
    PCNAES40  QPETG240         1.   
    PCNAES40  QPETG340         1.   
    PCNAES40  QPETG440         1.   
    PCNAES40  QCOAL140         1.   
    PCNAES40  QNATU140         1.   
    PCNAES40  QNATU240         1.   
    PCNAES40  QNATU340         1.   
    PCNAES45  PCNAES45        10.   
    PCNAES45  PCCLDU45         1.   
    PCNAES45  PCPGAI45         1.   
    PCNAES45  QPETG145         1.   
    PCNAES45  QPETG245         1.   
    PCNAES45  QPETG345         1.   
    PCNAES45  QPETG445         1.   
    PCNAES45  QCOAL145         1.   
    PCNAES45  QNATU145         1.   
    PCNAES45  QNATU245         1.   
    PCNAES45  QNATU345         1.   
    PCNAES50  PCNAES50        10.   
    PCNAES50  PCCLDU50         1.   
    PCNAES50  PCPGAI50         1.   
    PCNAES50  QPETG150         1.   
    PCNAES50  QPETG250         1.   
    PCNAES50  QPETG350         1.   
    PCNAES50  QPETG450         1.   
    PCNAES50  QCOAL150         1.   
    PCNAES50  QNATU150         1.   
    PCNAES50  QNATU250         1.   
    PCNAES50  QNATU350         1.   
    PCNAES55  PCNAES55        10.   
    PCNAES55  PCCLDU55         1.   
    PCNAES55  PCPGAI55         1.   
    PCNAES55  QPETG155         1.   
    PCNAES55  QPETG255         1.   
    PCNAES55  QPETG355         1.   
    PCNAES55  QPETG455         1.   
    PCNAES55  QCOAL155         1.   
    PCNAES55  QNATU155         1.   
    PCNAES55  QNATU255         1.   
    PCNAES55  QNATU355         1.   
    PCNAES60  PCNAES60        10.   
    PCNAES60  PCCLDU60         1.   
    PCNAES60  PCPGAI60         1.   
    PCNAES60  QPETG160         1.   
    PCNAES60  QPETG260         1.   
    PCNAES60  QPETG360         1.   
    PCNAES60  QPETG460         1.   
    PCNAES60  QCOAL160         1.   
    PCNAES60  QNATU160         1.   
    PCNAES60  QNATU260         1.   
    PCNAES60  QNATU360         1.   
    PCNAES65  PCNAES65        10.   
    PCNAES65  PCCLDU65         1.   
    PCNAES65  PCPGAI65         1.   
    PCNAES65  QPETG165         1.   
    PCNAES65  QPETG265         1.   
    PCNAES65  QPETG365         1.   
    PCNAES65  QPETG465         1.   
    PCNAES65  QCOAL165         1.   
    PCNAES65  QNATU165         1.   
    PCNAES65  QNATU265         1.   
    PCNAES65  QNATU365         1.   
    PCNAES70  PCNAES70        10.   
    PCNAES70  PCCLDU70         1.   
    PCNAES70  PCPGAI70         1.   
    PCNAES70  QPETG170         1.   
    PCNAES70  QPETG270         1.   
    PCNAES70  QPETG370         1.   
    PCNAES70  QPETG470         1.   
    PCNAES70  QCOAL170         1.   
    PCNAES70  QNATU170         1.   
    PCNAES70  QNATU270         1.   
    PCNAES70  QNATU370         1.   
    PCNAES75  PCNAES75        10.   
    PCNAES75  PCCLDU75         1.   
    PCNAES75  PCPGAI75         1.   
    PCNAES75  QPETG175         1.   
    PCNAES75  QPETG275         1.   
    PCNAES75  QPETG375         1.   
    PCNAES75  QPETG475         1.   
    PCNAES75  QCOAL175         1.   
    PCNAES75  QNATU175         1.   
    PCNAES75  QNATU275         1.   
    PCNAES75  QNATU375         1.   
    PCCLDU00  PCCLDU00        10.   
    PCCLDU00  PCPGAI00         1.   
    PCCLDU00  QPETG100         1.   
    PCCLDU00  QPETG200         1.   
    PCCLDU00  QPETG300         1.   
    PCCLDU00  QPETG400         1.   
    PCCLDU00  QCOAL100         1.   
    PCCLDU00  QNATU100         1.   
    PCCLDU00  QNATU200         1.   
    PCCLDU00  QNATU300         1.   
    PCCLDU05  PCCLDU05        10.   
    PCCLDU05  PCPGAI05         1.   
    PCCLDU05  QPETG105         1.   
    PCCLDU05  QPETG205         1.   
    PCCLDU05  QPETG305         1.   
    PCCLDU05  QPETG405         1.   
    PCCLDU05  QCOAL105         1.   
    PCCLDU05  QNATU105         1.   
    PCCLDU05  QNATU205         1.   
    PCCLDU05  QNATU305         1.   
    PCCLDU10  PCCLDU10        10.   
    PCCLDU10  PCPGAI10         1.   
    PCCLDU10  QPETG110         1.   
    PCCLDU10  QPETG210         1.   
    PCCLDU10  QPETG310         1.   
    PCCLDU10  QPETG410         1.   
    PCCLDU10  QCOAL110         1.   
    PCCLDU10  QNATU110         1.   
    PCCLDU10  QNATU210         1.   
    PCCLDU10  QNATU310         1.   
    PCCLDU15  PCCLDU15        10.   
    PCCLDU15  PCPGAI15         1.   
    PCCLDU15  QPETG115         1.   
    PCCLDU15  QPETG215         1.   
    PCCLDU15  QPETG315         1.   
    PCCLDU15  QPETG415         1.   
    PCCLDU15  QCOAL115         1.   
    PCCLDU15  QNATU115         1.   
    PCCLDU15  QNATU215         1.   
    PCCLDU15  QNATU315         1.   
    PCCLDU20  PCCLDU20        10.   
    PCCLDU20  PCPGAI20         1.   
    PCCLDU20  QPETG120         1.   
    PCCLDU20  QPETG220         1.   
    PCCLDU20  QPETG320         1.   
    PCCLDU20  QPETG420         1.   
    PCCLDU20  QCOAL120         1.   
    PCCLDU20  QNATU120         1.   
    PCCLDU20  QNATU220         1.   
    PCCLDU20  QNATU320         1.   
    PCCLDU25  PCCLDU25        10.   
    PCCLDU25  PCPGAI25         1.   
    PCCLDU25  QPETG125         1.   
    PCCLDU25  QPETG225         1.   
    PCCLDU25  QPETG325         1.   
    PCCLDU25  QPETG425         1.   
    PCCLDU25  QCOAL125         1.   
    PCCLDU25  QNATU125         1.   
    PCCLDU25  QNATU225         1.   
    PCCLDU25  QNATU325         1.   
    PCCLDU30  PCCLDU30        10.   
    PCCLDU30  PCPGAI30         1.   
    PCCLDU30  QPETG130         1.   
    PCCLDU30  QPETG230         1.   
    PCCLDU30  QPETG330         1.   
    PCCLDU30  QPETG430         1.   
    PCCLDU30  QCOAL130         1.   
    PCCLDU30  QNATU130         1.   
    PCCLDU30  QNATU230         1.   
    PCCLDU30  QNATU330         1.   
    PCCLDU35  PCCLDU35        10.   
    PCCLDU35  PCPGAI35         1.   
    PCCLDU35  QPETG135         1.   
    PCCLDU35  QPETG235         1.   
    PCCLDU35  QPETG335         1.   
    PCCLDU35  QPETG435         1.   
    PCCLDU35  QCOAL135         1.   
    PCCLDU35  QNATU135         1.   
    PCCLDU35  QNATU235         1.   
    PCCLDU35  QNATU335         1.   
    PCCLDU40  PCCLDU40        10.   
    PCCLDU40  PCPGAI40         1.   
    PCCLDU40  QPETG140         1.   
    PCCLDU40  QPETG240         1.   
    PCCLDU40  QPETG340         1.   
    PCCLDU40  QPETG440         1.   
    PCCLDU40  QCOAL140         1.   
    PCCLDU40  QNATU140         1.   
    PCCLDU40  QNATU240         1.   
    PCCLDU40  QNATU340         1.   
    PCCLDU45  PCCLDU45        10.   
    PCCLDU45  PCPGAI45         1.   
    PCCLDU45  QPETG145         1.   
    PCCLDU45  QPETG245         1.   
    PCCLDU45  QPETG345         1.   
    PCCLDU45  QPETG445         1.   
    PCCLDU45  QCOAL145         1.   
    PCCLDU45  QNATU145         1.   
    PCCLDU45  QNATU245         1.   
    PCCLDU45  QNATU345         1.   
    PCCLDU50  PCCLDU50        10.   
    PCCLDU50  PCPGAI50         1.   
    PCCLDU50  QPETG150         1.   
    PCCLDU50  QPETG250         1.   
    PCCLDU50  QPETG350         1.   
    PCCLDU50  QPETG450         1.   
    PCCLDU50  QCOAL150         1.   
    PCCLDU50  QNATU150         1.   
    PCCLDU50  QNATU250         1.   
    PCCLDU50  QNATU350         1.   
    PCCLDU55  PCCLDU55        10.   
    PCCLDU55  PCPGAI55         1.   
    PCCLDU55  QPETG155         1.   
    PCCLDU55  QPETG255         1.   
    PCCLDU55  QPETG355         1.   
    PCCLDU55  QPETG455         1.   
    PCCLDU55  QCOAL155         1.   
    PCCLDU55  QNATU155         1.   
    PCCLDU55  QNATU255         1.   
    PCCLDU55  QNATU355         1.   
    PCCLDU60  PCCLDU60        10.   
    PCCLDU60  PCPGAI60         1.   
    PCCLDU60  QPETG160         1.   
    PCCLDU60  QPETG260         1.   
    PCCLDU60  QPETG360         1.   
    PCCLDU60  QPETG460         1.   
    PCCLDU60  QCOAL160         1.   
    PCCLDU60  QNATU160         1.   
    PCCLDU60  QNATU260         1.   
    PCCLDU60  QNATU360         1.   
    PCCLDU65  PCCLDU65        10.   
    PCCLDU65  PCPGAI65         1.   
    PCCLDU65  QPETG165         1.   
    PCCLDU65  QPETG265         1.   
    PCCLDU65  QPETG365         1.   
    PCCLDU65  QPETG465         1.   
    PCCLDU65  QCOAL165         1.   
    PCCLDU65  QNATU165         1.   
    PCCLDU65  QNATU265         1.   
    PCCLDU65  QNATU365         1.   
    PCCLDU70  PCCLDU70        10.   
    PCCLDU70  PCPGAI70         1.   
    PCCLDU70  QPETG170         1.   
    PCCLDU70  QPETG270         1.   
    PCCLDU70  QPETG370         1.   
    PCCLDU70  QPETG470         1.   
    PCCLDU70  QCOAL170         1.   
    PCCLDU70  QNATU170         1.   
    PCCLDU70  QNATU270         1.   
    PCCLDU70  QNATU370         1.   
    PCCLDU75  PCCLDU75        10.   
    PCCLDU75  PCPGAI75         1.   
    PCCLDU75  QPETG175         1.   
    PCCLDU75  QPETG275         1.   
    PCCLDU75  QPETG375         1.   
    PCCLDU75  QPETG475         1.   
    PCCLDU75  QCOAL175         1.   
    PCCLDU75  QNATU175         1.   
    PCCLDU75  QNATU275         1.   
    PCCLDU75  QNATU375         1.   
    PCPGAI00  PCPGAI00        10.   
    PCPGAI00  QPETG100         1.   
    PCPGAI00  QPETG200         1.   
    PCPGAI00  QPETG300         1.   
    PCPGAI00  QPETG400         1.   
    PCPGAI00  QCOAL100         1.   
    PCPGAI00  QNATU100         1.   
    PCPGAI00  QNATU200         1.   
    PCPGAI00  QNATU300         1.   
    PCPGAI05  PCPGAI05        10.   
    PCPGAI05  QPETG105         1.   
    PCPGAI05  QPETG205         1.   
    PCPGAI05  QPETG305         1.   
    PCPGAI05  QPETG405         1.   
    PCPGAI05  QCOAL105         1.   
    PCPGAI05  QNATU105         1.   
    PCPGAI05  QNATU205         1.   
    PCPGAI05  QNATU305         1.   
    PCPGAI10  PCPGAI10        10.   
    PCPGAI10  QPETG110         1.   
    PCPGAI10  QPETG210         1.   
    PCPGAI10  QPETG310         1.   
    PCPGAI10  QPETG410         1.   
    PCPGAI10  QCOAL110         1.   
    PCPGAI10  QNATU110         1.   
    PCPGAI10  QNATU210         1.   
    PCPGAI10  QNATU310         1.   
    PCPGAI15  PCPGAI15        10.   
    PCPGAI15  QPETG115         1.   
    PCPGAI15  QPETG215         1.   
    PCPGAI15  QPETG315         1.   
    PCPGAI15  QPETG415         1.   
    PCPGAI15  QCOAL115         1.   
    PCPGAI15  QNATU115         1.   
    PCPGAI15  QNATU215         1.   
    PCPGAI15  QNATU315         1.   
    PCPGAI20  PCPGAI20        10.   
    PCPGAI20  QPETG120         1.   
    PCPGAI20  QPETG220         1.   
    PCPGAI20  QPETG320         1.   
    PCPGAI20  QPETG420         1.   
    PCPGAI20  QCOAL120         1.   
    PCPGAI20  QNATU120         1.   
    PCPGAI20  QNATU220         1.   
    PCPGAI20  QNATU320         1.   
    PCPGAI25  PCPGAI25        10.   
    PCPGAI25  QPETG125         1.   
    PCPGAI25  QPETG225         1.   
    PCPGAI25  QPETG325         1.   
    PCPGAI25  QPETG425         1.   
    PCPGAI25  QCOAL125         1.   
    PCPGAI25  QNATU125         1.   
    PCPGAI25  QNATU225         1.   
    PCPGAI25  QNATU325         1.   
    PCPGAI30  PCPGAI30        10.   
    PCPGAI30  QPETG130         1.   
    PCPGAI30  QPETG230         1.   
    PCPGAI30  QPETG330         1.   
    PCPGAI30  QPETG430         1.   
    PCPGAI30  QCOAL130         1.   
    PCPGAI30  QNATU130         1.   
    PCPGAI30  QNATU230         1.   
    PCPGAI30  QNATU330         1.   
    PCPGAI35  PCPGAI35        10.   
    PCPGAI35  QPETG135         1.   
    PCPGAI35  QPETG235         1.   
    PCPGAI35  QPETG335         1.   
    PCPGAI35  QPETG435         1.   
    PCPGAI35  QCOAL135         1.   
    PCPGAI35  QNATU135         1.   
    PCPGAI35  QNATU235         1.   
    PCPGAI35  QNATU335         1.   
    PCPGAI40  PCPGAI40        10.   
    PCPGAI40  QPETG140         1.   
    PCPGAI40  QPETG240         1.   
    PCPGAI40  QPETG340         1.   
    PCPGAI40  QPETG440         1.   
    PCPGAI40  QCOAL140         1.   
    PCPGAI40  QNATU140         1.   
    PCPGAI40  QNATU240         1.   
    PCPGAI40  QNATU340         1.   
    PCPGAI45  PCPGAI45        10.   
    PCPGAI45  QPETG145         1.   
    PCPGAI45  QPETG245         1.   
    PCPGAI45  QPETG345         1.   
    PCPGAI45  QPETG445         1.   
    PCPGAI45  QCOAL145         1.   
    PCPGAI45  QNATU145         1.   
    PCPGAI45  QNATU245         1.   
    PCPGAI45  QNATU345         1.   
    PCPGAI50  PCPGAI50        10.   
    PCPGAI50  QPETG150         1.   
    PCPGAI50  QPETG250         1.   
    PCPGAI50  QPETG350         1.   
    PCPGAI50  QPETG450         1.   
    PCPGAI50  QCOAL150         1.   
    PCPGAI50  QNATU150         1.   
    PCPGAI50  QNATU250         1.   
    PCPGAI50  QNATU350         1.   
    PCPGAI55  PCPGAI55        10.   
    PCPGAI55  QPETG155         1.   
    PCPGAI55  QPETG255         1.   
    PCPGAI55  QPETG355         1.   
    PCPGAI55  QPETG455         1.   
    PCPGAI55  QCOAL155         1.   
    PCPGAI55  QNATU155         1.   
    PCPGAI55  QNATU255         1.   
    PCPGAI55  QNATU355         1.   
    PCPGAI60  PCPGAI60        10.   
    PCPGAI60  QPETG160         1.   
    PCPGAI60  QPETG260         1.   
    PCPGAI60  QPETG360         1.   
    PCPGAI60  QPETG460         1.   
    PCPGAI60  QCOAL160         1.   
    PCPGAI60  QNATU160         1.   
    PCPGAI60  QNATU260         1.   
    PCPGAI60  QNATU360         1.   
    PCPGAI65  PCPGAI65        10.   
    PCPGAI65  QPETG165         1.   
    PCPGAI65  QPETG265         1.   
    PCPGAI65  QPETG365         1.   
    PCPGAI65  QPETG465         1.   
    PCPGAI65  QCOAL165         1.   
    PCPGAI65  QNATU165         1.   
    PCPGAI65  QNATU265         1.   
    PCPGAI65  QNATU365         1.   
    PCPGAI70  PCPGAI70        10.   
    PCPGAI70  QPETG170         1.   
    PCPGAI70  QPETG270         1.   
    PCPGAI70  QPETG370         1.   
    PCPGAI70  QPETG470         1.   
    PCPGAI70  QCOAL170         1.   
    PCPGAI70  QNATU170         1.   
    PCPGAI70  QNATU270         1.   
    PCPGAI70  QNATU370         1.   
    PCPGAI75  PCPGAI75        10.   
    PCPGAI75  QPETG175         1.   
    PCPGAI75  QPETG275         1.   
    PCPGAI75  QPETG375         1.   
    PCPGAI75  QPETG475         1.   
    PCPGAI75  QCOAL175         1.   
    PCPGAI75  QNATU175         1.   
    PCPGAI75  QNATU275         1.   
    PCPGAI75  QNATU375         1.   
    QPETG100  QPETG100        10.   
    QPETG100  QPETG200         1.   
    QPETG100  QPETG300         1.   
    QPETG100  QPETG400         1.   
    QPETG100  QCOAL100         1.   
    QPETG100  QNATU100         1.   
    QPETG100  QNATU200         1.   
    QPETG100  QNATU300         1.   
    QPETG105  QPETG105        10.   
    QPETG105  QPETG205         1.   
    QPETG105  QPETG305         1.   
    QPETG105  QPETG405         1.   
    QPETG105  QCOAL105         1.   
    QPETG105  QNATU105         1.   
    QPETG105  QNATU205         1.   
    QPETG105  QNATU305         1.   
    QPETG110  QPETG110        10.   
    QPETG110  QPETG210         1.   
    QPETG110  QPETG310         1.   
    QPETG110  QPETG410         1.   
    QPETG110  QCOAL110         1.   
    QPETG110  QNATU110         1.   
    QPETG110  QNATU210         1.   
    QPETG110  QNATU310         1.   
    QPETG115  QPETG115        10.   
    QPETG115  QPETG215         1.   
    QPETG115  QPETG315         1.   
    QPETG115  QPETG415         1.   
    QPETG115  QCOAL115         1.   
    QPETG115  QNATU115         1.   
    QPETG115  QNATU215         1.   
    QPETG115  QNATU315         1.   
    QPETG120  QPETG120        10.   
    QPETG120  QPETG220         1.   
    QPETG120  QPETG320         1.   
    QPETG120  QPETG420         1.   
    QPETG120  QCOAL120         1.   
    QPETG120  QNATU120         1.   
    QPETG120  QNATU220         1.   
    QPETG120  QNATU320         1.   
    QPETG125  QPETG125        10.   
    QPETG125  QPETG225         1.   
    QPETG125  QPETG325         1.   
    QPETG125  QPETG425         1.   
    QPETG125  QCOAL125         1.   
    QPETG125  QNATU125         1.   
    QPETG125  QNATU225         1.   
    QPETG125  QNATU325         1.   
    QPETG130  QPETG130        10.   
    QPETG130  QPETG230         1.   
    QPETG130  QPETG330         1.   
    QPETG130  QPETG430         1.   
    QPETG130  QCOAL130         1.   
    QPETG130  QNATU130         1.   
    QPETG130  QNATU230         1.   
    QPETG130  QNATU330         1.   
    QPETG135  QPETG135        10.   
    QPETG135  QPETG235         1.   
    QPETG135  QPETG335         1.   
    QPETG135  QPETG435         1.   
    QPETG135  QCOAL135         1.   
    QPETG135  QNATU135         1.   
    QPETG135  QNATU235         1.   
    QPETG135  QNATU335         1.   
    QPETG140  QPETG140        10.   
    QPETG140  QPETG240         1.   
    QPETG140  QPETG340         1.   
    QPETG140  QPETG440         1.   
    QPETG140  QCOAL140         1.   
    QPETG140  QNATU140         1.   
    QPETG140  QNATU240         1.   
    QPETG140  QNATU340         1.   
    QPETG145  QPETG145        10.   
    QPETG145  QPETG245         1.   
    QPETG145  QPETG345         1.   
    QPETG145  QPETG445         1.   
    QPETG145  QCOAL145         1.   
    QPETG145  QNATU145         1.   
    QPETG145  QNATU245         1.   
    QPETG145  QNATU345         1.   
    QPETG150  QPETG150        10.   
    QPETG150  QPETG250         1.   
    QPETG150  QPETG350         1.   
    QPETG150  QPETG450         1.   
    QPETG150  QCOAL150         1.   
    QPETG150  QNATU150         1.   
    QPETG150  QNATU250         1.   
    QPETG150  QNATU350         1.   
    QPETG155  QPETG155        10.   
    QPETG155  QPETG255         1.   
    QPETG155  QPETG355         1.   
    QPETG155  QPETG455         1.   
    QPETG155  QCOAL155         1.   
    QPETG155  QNATU155         1.   
    QPETG155  QNATU255         1.   
    QPETG155  QNATU355         1.   
    QPETG160  QPETG160        10.   
    QPETG160  QPETG260         1.   
    QPETG160  QPETG360         1.   
    QPETG160  QPETG460         1.   
    QPETG160  QCOAL160         1.   
    QPETG160  QNATU160         1.   
    QPETG160  QNATU260         1.   
    QPETG160  QNATU360         1.   
    QPETG165  QPETG165        10.   
    QPETG165  QPETG265         1.   
    QPETG165  QPETG365         1.   
    QPETG165  QPETG465         1.   
    QPETG165  QCOAL165         1.   
    QPETG165  QNATU165         1.   
    QPETG165  QNATU265         1.   
    QPETG165  QNATU365         1.   
    QPETG170  QPETG170        10.   
    QPETG170  QPETG270         1.   
    QPETG170  QPETG370         1.   
    QPETG170  QPETG470         1.   
    QPETG170  QCOAL170         1.   
    QPETG170  QNATU170         1.   
    QPETG170  QNATU270         1.   
    QPETG170  QNATU370         1.   
    QPETG175  QPETG175        10.   
    QPETG175  QPETG275         1.   
    QPETG175  QPETG375         1.   
    QPETG175  QPETG475         1.   
    QPETG175  QCOAL175         1.   
    QPETG175  QNATU175         1.   
    QPETG175  QNATU275         1.   
    QPETG175  QNATU375         1.   
    QPETG200  QPETG200        10.   
    QPETG200  QPETG300         1.   
    QPETG200  QPETG400         1.   
    QPETG200  QCOAL100         1.   
    QPETG200  QNATU100         1.   
    QPETG200  QNATU200         1.   
    QPETG200  QNATU300         1.   
    QPETG205  QPETG205        10.   
    QPETG205  QPETG305         1.   
    QPETG205  QPETG405         1.   
    QPETG205  QCOAL105         1.   
    QPETG205  QNATU105         1.   
    QPETG205  QNATU205         1.   
    QPETG205  QNATU305         1.   
    QPETG210  QPETG210        10.   
    QPETG210  QPETG310         1.   
    QPETG210  QPETG410         1.   
    QPETG210  QCOAL110         1.   
    QPETG210  QNATU110         1.   
    QPETG210  QNATU210         1.   
    QPETG210  QNATU310         1.   
    QPETG215  QPETG215        10.   
    QPETG215  QPETG315         1.   
    QPETG215  QPETG415         1.   
    QPETG215  QCOAL115         1.   
    QPETG215  QNATU115         1.   
    QPETG215  QNATU215         1.   
    QPETG215  QNATU315         1.   
    QPETG220  QPETG220        10.   
    QPETG220  QPETG320         1.   
    QPETG220  QPETG420         1.   
    QPETG220  QCOAL120         1.   
    QPETG220  QNATU120         1.   
    QPETG220  QNATU220         1.   
    QPETG220  QNATU320         1.   
    QPETG225  QPETG225        10.   
    QPETG225  QPETG325         1.   
    QPETG225  QPETG425         1.   
    QPETG225  QCOAL125         1.   
    QPETG225  QNATU125         1.   
    QPETG225  QNATU225         1.   
    QPETG225  QNATU325         1.   
    QPETG230  QPETG230        10.   
    QPETG230  QPETG330         1.   
    QPETG230  QPETG430         1.   
    QPETG230  QCOAL130         1.   
    QPETG230  QNATU130         1.   
    QPETG230  QNATU230         1.   
    QPETG230  QNATU330         1.   
    QPETG235  QPETG235        10.   
    QPETG235  QPETG335         1.   
    QPETG235  QPETG435         1.   
    QPETG235  QCOAL135         1.   
    QPETG235  QNATU135         1.   
    QPETG235  QNATU235         1.   
    QPETG235  QNATU335         1.   
    QPETG240  QPETG240        10.   
    QPETG240  QPETG340         1.   
    QPETG240  QPETG440         1.   
    QPETG240  QCOAL140         1.   
    QPETG240  QNATU140         1.   
    QPETG240  QNATU240         1.   
    QPETG240  QNATU340         1.   
    QPETG245  QPETG245        10.   
    QPETG245  QPETG345         1.   
    QPETG245  QPETG445         1.   
    QPETG245  QCOAL145         1.   
    QPETG245  QNATU145         1.   
    QPETG245  QNATU245         1.   
    QPETG245  QNATU345         1.   
    QPETG250  QPETG250        10.   
    QPETG250  QPETG350         1.   
    QPETG250  QPETG450         1.   
    QPETG250  QCOAL150         1.   
    QPETG250  QNATU150         1.   
    QPETG250  QNATU250         1.   
    QPETG250  QNATU350         1.   
    QPETG255  QPETG255        10.   
    QPETG255  QPETG355         1.   
    QPETG255  QPETG455         1.   
    QPETG255  QCOAL155         1.   
    QPETG255  QNATU155         1.   
    QPETG255  QNATU255         1.   
    QPETG255  QNATU355         1.   
    QPETG260  QPETG260        10.   
    QPETG260  QPETG360         1.   
    QPETG260  QPETG460         1.   
    QPETG260  QCOAL160         1.   
    QPETG260  QNATU160         1.   
    QPETG260  QNATU260         1.   
    QPETG260  QNATU360         1.   
    QPETG265  QPETG265        10.   
    QPETG265  QPETG365         1.   
    QPETG265  QPETG465         1.   
    QPETG265  QCOAL165         1.   
    QPETG265  QNATU165         1.   
    QPETG265  QNATU265         1.   
    QPETG265  QNATU365         1.   
    QPETG270  QPETG270        10.   
    QPETG270  QPETG370         1.   
    QPETG270  QPETG470         1.   
    QPETG270  QCOAL170         1.   
    QPETG270  QNATU170         1.   
    QPETG270  QNATU270         1.   
    QPETG270  QNATU370         1.   
    QPETG275  QPETG275        10.   
    QPETG275  QPETG375         1.   
    QPETG275  QPETG475         1.   
    QPETG275  QCOAL175         1.   
    QPETG275  QNATU175         1.   
    QPETG275  QNATU275         1.   
    QPETG275  QNATU375         1.   
    QPETG300  QPETG300        10.   
    QPETG300  QPETG400         1.   
    QPETG300  QCOAL100         1.   
    QPETG300  QNATU100         1.   
    QPETG300  QNATU200         1.   
    QPETG300  QNATU300         1.   
    QPETG305  QPETG305        10.   
    QPETG305  QPETG405         1.   
    QPETG305  QCOAL105         1.   
    QPETG305  QNATU105         1.   
    QPETG305  QNATU205         1.   
    QPETG305  QNATU305         1.   
    QPETG310  QPETG310        10.   
    QPETG310  QPETG410         1.   
    QPETG310  QCOAL110         1.   
    QPETG310  QNATU110         1.   
    QPETG310  QNATU210         1.   
    QPETG310  QNATU310         1.   
    QPETG315  QPETG315        10.   
    QPETG315  QPETG415         1.   
    QPETG315  QCOAL115         1.   
    QPETG315  QNATU115         1.   
    QPETG315  QNATU215         1.   
    QPETG315  QNATU315         1.   
    QPETG320  QPETG320        10.   
    QPETG320  QPETG420         1.   
    QPETG320  QCOAL120         1.   
    QPETG320  QNATU120         1.   
    QPETG320  QNATU220         1.   
    QPETG320  QNATU320         1.   
    QPETG325  QPETG325        10.   
    QPETG325  QPETG425         1.   
    QPETG325  QCOAL125         1.   
    QPETG325  QNATU125         1.   
    QPETG325  QNATU225         1.   
    QPETG325  QNATU325         1.   
    QPETG330  QPETG330        10.   
    QPETG330  QPETG430         1.   
    QPETG330  QCOAL130         1.   
    QPETG330  QNATU130         1.   
    QPETG330  QNATU230         1.   
    QPETG330  QNATU330         1.   
    QPETG335  QPETG335        10.   
    QPETG335  QPETG435         1.   
    QPETG335  QCOAL135         1.   
    QPETG335  QNATU135         1.   
    QPETG335  QNATU235         1.   
    QPETG335  QNATU335         1.   
    QPETG340  QPETG340        10.   
    QPETG340  QPETG440         1.   
    QPETG340  QCOAL140         1.   
    QPETG340  QNATU140         1.   
    QPETG340  QNATU240         1.   
    QPETG340  QNATU340         1.   
    QPETG345  QPETG345        10.   
    QPETG345  QPETG445         1.   
    QPETG345  QCOAL145         1.   
    QPETG345  QNATU145         1.   
    QPETG345  QNATU245         1.   
    QPETG345  QNATU345         1.   
    QPETG350  QPETG350        10.   
    QPETG350  QPETG450         1.   
    QPETG350  QCOAL150         1.   
    QPETG350  QNATU150         1.   
    QPETG350  QNATU250         1.   
    QPETG350  QNATU350         1.   
    QPETG355  QPETG355        10.   
    QPETG355  QPETG455         1.   
    QPETG355  QCOAL155         1.   
    QPETG355  QNATU155         1.   
    QPETG355  QNATU255         1.   
    QPETG355  QNATU355         1.   
    QPETG360  QPETG360        10.   
    QPETG360  QPETG460         1.   
    QPETG360  QCOAL160         1.   
    QPETG360  QNATU160         1.   
    QPETG360  QNATU260         1.   
    QPETG360  QNATU360         1.   
    QPETG365  QPETG365        10.   
    QPETG365  QPETG465         1.   
    QPETG365  QCOAL165         1.   
    QPETG365  QNATU165         1.   
    QPETG365  QNATU265         1.   
    QPETG365  QNATU365         1.   
    QPETG370  QPETG370        10.   
    QPETG370  QPETG470         1.   
    QPETG370  QCOAL170         1.   
    QPETG370  QNATU170         1.   
    QPETG370  QNATU270         1.   
    QPETG370  QNATU370         1.   
    QPETG375  QPETG375        10.   
    QPETG375  QPETG475         1.   
    QPETG375  QCOAL175         1.   
    QPETG375  QNATU175         1.   
    QPETG375  QNATU275         1.   
    QPETG375  QNATU375         1.   
    QPETG400  QPETG400        10.   
    QPETG400  QCOAL100         1.   
    QPETG400  QNATU100         1.   
    QPETG400  QNATU200         1.   
    QPETG400  QNATU300         1.   
    QPETG405  QPETG405        10.   
    QPETG405  QCOAL105         1.   
    QPETG405  QNATU105         1.   
    QPETG405  QNATU205         1.   
    QPETG405  QNATU305         1.   
    QPETG410  QPETG410        10.   
    QPETG410  QCOAL110         1.   
    QPETG410  QNATU110         1.   
    QPETG410  QNATU210         1.   
    QPETG410  QNATU310         1.   
    QPETG415  QPETG415        10.   
    QPETG415  QCOAL115         1.   
    QPETG415  QNATU115         1.   
    QPETG415  QNATU215         1.   
    QPETG415  QNATU315         1.   
    QPETG420  QPETG420        10.   
    QPETG420  QCOAL120         1.   
    QPETG420  QNATU120         1.   
    QPETG420  QNATU220         1.   
    QPETG420  QNATU320         1.   
    QPETG425  QPETG425        10.   
    QPETG425  QCOAL125         1.   
    QPETG425  QNATU125         1.   
    QPETG425  QNATU225         1.   
    QPETG425  QNATU325         1.   
    QPETG430  QPETG430        10.   
    QPETG430  QCOAL130         1.   
    QPETG430  QNATU130         1.   
    QPETG430  QNATU230         1.   
    QPETG430  QNATU330         1.   
    QPETG435  QPETG435        10.   
    QPETG435  QCOAL135         1.   
    QPETG435  QNATU135         1.   
    QPETG435  QNATU235         1.   
    QPETG435  QNATU335         1.   
    QPETG440  QPETG440        10.   
    QPETG440  QCOAL140         1.   
    QPETG440  QNATU140         1.   
    QPETG440  QNATU240         1.   
    QPETG440  QNATU340         1.   
    QPETG445  QPETG445        10.   
    QPETG445  QCOAL145         1.   
    QPETG445  QNATU145         1.   
    QPETG445  QNATU245         1.   
    QPETG445  QNATU345         1.   
    QPETG450  QPETG450        10.   
    QPETG450  QCOAL150         1.   
    QPETG450  QNATU150         1.   
    QPETG450  QNATU250         1.   
    QPETG450  QNATU350         1.   
    QPETG455  QPETG455        10.   
    QPETG455  QCOAL155         1.   
    QPETG455  QNATU155         1.   
    QPETG455  QNATU255         1.   
    QPETG455  QNATU355         1.   
    QPETG460  QPETG460        10.   
    QPETG460  QCOAL160         1.   
    QPETG460  QNATU160         1.   
    QPETG460  QNATU260         1.   
    QPETG460  QNATU360         1.   
    QPETG465  QPETG465        10.   
    QPETG465  QCOAL165         1.   
    QPETG465  QNATU165         1.   
    QPETG465  QNATU265         1.   
    QPETG465  QNATU365         1.   
    QPETG470  QPETG470        10.   
    QPETG470  QCOAL170         1.   
    QPETG470  QNATU170         1.   
    QPETG470  QNATU270         1.   
    QPETG470  QNATU370         1.   
    QPETG475  QPETG475        10.   
    QPETG475  QCOAL175         1.   
    QPETG475  QNATU175         1.   
    QPETG475  QNATU275         1.   
    QPETG475  QNATU375         1.   
    QCOAL100  QCOAL100        10.   
    QCOAL100  QNATU100         1.   
    QCOAL100  QNATU200         1.   
    QCOAL100  QNATU300         1.   
    QCOAL105  QCOAL105        10.   
    QCOAL105  QNATU105         1.   
    QCOAL105  QNATU205         1.   
    QCOAL105  QNATU305         1.   
    QCOAL110  QCOAL110        10.   
    QCOAL110  QNATU110         1.   
    QCOAL110  QNATU210         1.   
    QCOAL110  QNATU310         1.   
    QCOAL115  QCOAL115        10.   
    QCOAL115  QNATU115         1.   
    QCOAL115  QNATU215         1.   
    QCOAL115  QNATU315         1.   
    QCOAL120  QCOAL120        10.   
    QCOAL120  QNATU120         1.   
    QCOAL120  QNATU220         1.   
    QCOAL120  QNATU320         1.   
    QCOAL125  QCOAL125        10.   
    QCOAL125  QNATU125         1.   
    QCOAL125  QNATU225         1.   
    QCOAL125  QNATU325         1.   
    QCOAL130  QCOAL130        10.   
    QCOAL130  QNATU130         1.   
    QCOAL130  QNATU230         1.   
    QCOAL130  QNATU330         1.   
    QCOAL135  QCOAL135        10.   
    QCOAL135  QNATU135         1.   
    QCOAL135  QNATU235         1.   
    QCOAL135  QNATU335         1.   
    QCOAL140  QCOAL140        10.   
    QCOAL140  QNATU140         1.   
    QCOAL140  QNATU240         1.   
    QCOAL140  QNATU340         1.   
    QCOAL145  QCOAL145        10.   
    QCOAL145  QNATU145         1.   
    QCOAL145  QNATU245         1.   
    QCOAL145  QNATU345         1.   
    QCOAL150  QCOAL150        10.   
    QCOAL150  QNATU150         1.   
    QCOAL150  QNATU250         1.   
    QCOAL150  QNATU350         1.   
    QCOAL155  QCOAL155        10.   
    QCOAL155  QNATU155         1.   
    QCOAL155  QNATU255         1.   
    QCOAL155  QNATU355         1.   
    QCOAL160  QCOAL160        10.   
    QCOAL160  QNATU160         1.   
    QCOAL160  QNATU260         1.   
    QCOAL160  QNATU360         1.   
    QCOAL165  QCOAL165        10.   
    QCOAL165  QNATU165         1.   
    QCOAL165  QNATU265         1.   
    QCOAL165  QNATU365         1.   
    QCOAL170  QCOAL170        10.   
    QCOAL170  QNATU170         1.   
    QCOAL170  QNATU270         1.   
    QCOAL170  QNATU370         1.   
    QCOAL175  QCOAL175        10.   
    QCOAL175  QNATU175         1.   
    QCOAL175  QNATU275         1.   
    QCOAL175  QNATU375         1.   
    QNATU100  QNATU100        10.   
    QNATU100  QNATU200         1.   
    QNATU100  QNATU300         1.   
    QNATU105  QNATU105        10.   
    QNATU105  QNATU205         1.   
    QNATU105  QNATU305         1.   
    QNATU110  QNATU110        10.   
    QNATU110  QNATU210         1.   
    QNATU110  QNATU310         1.   
    QNATU115  QNATU115        10.   
    QNATU115  QNATU215         1.   
    QNATU115  QNATU315         1.   
    QNATU120  QNATU120        10.   
    QNATU120  QNATU220         1.   
    QNATU120  QNATU320         1.   
    QNATU125  QNATU125        10.   
    QNATU125  QNATU225         1.   
    QNATU125  QNATU325         1.   
    QNATU130  QNATU130        10.   
    QNATU130  QNATU230         1.   
    QNATU130  QNATU330         1.   
    QNATU135  QNATU135        10.   
    QNATU135  QNATU235         1.   
    QNATU135  QNATU335         1.   
    QNATU140  QNATU140        10.   
    QNATU140  QNATU240         1.   
    QNATU140  QNATU340         1.   
    QNATU145  QNATU145        10.   
    QNATU145  QNATU245         1.   
    QNATU145  QNATU345         1.   
    QNATU150  QNATU150        10.   
    QNATU150  QNATU250         1.   
    QNATU150  QNATU350         1.   
    QNATU155  QNATU155        10.   
    QNATU155  QNATU255         1.   
    QNATU155  QNATU355         1.   
    QNATU160  QNATU160        10.   
    QNATU160  QNATU260         1.   
    QNATU160  QNATU360         1.   
    QNATU165  QNATU165        10.   
    QNATU165  QNATU265         1.   
    QNATU165  QNATU365         1.   
    QNATU170  QNATU170        10.   
    QNATU170  QNATU270         1.   
    QNATU170  QNATU370         1.   
    QNATU175  QNATU175        10.   
    QNATU175  QNATU275         1.   
    QNATU175  QNATU375         1.   
    QNATU200  QNATU200        10.   
    QNATU200  QNATU300         1.   
    QNATU205  QNATU205        10.   
    QNATU205  QNATU305         1.   
    QNATU210  QNATU210        10.   
    QNATU210  QNATU310         1.   
    QNATU215  QNATU215        10.   
    QNATU215  QNATU315         1.   
    QNATU220  QNATU220        10.   
    QNATU220  QNATU320         1.   
    QNATU225  QNATU225        10.   
    QNATU225  QNATU325         1.   
    QNATU230  QNATU230        10.   
    QNATU230  QNATU330         1.   
    QNATU235  QNATU235        10.   
    QNATU235  QNATU335         1.   
    QNATU240  QNATU240        10.   
    QNATU240  QNATU340         1.   
    QNATU245  QNATU245        10.   
    QNATU245  QNATU345         1.   
    QNATU250  QNATU250        10.   
    QNATU250  QNATU350         1.   
    QNATU255  QNATU255        10.   
    QNATU255  QNATU355         1.   
    QNATU260  QNATU260        10.   
    QNATU260  QNATU360         1.   
    QNATU265  QNATU265        10.   
    QNATU265  QNATU365         1.   
    QNATU270  QNATU270        10.   
    QNATU270  QNATU370         1.   
    QNATU275  QNATU275        10.   
    QNATU275  QNATU375         1.   
    QNATU300  QNATU300        10.   
    QNATU305  QNATU305        10.   
    QNATU310  QNATU310        10.   
    QNATU315  QNATU315        10.   
    QNATU320  QNATU320        10.   
    QNATU325  QNATU325        10.   
    QNATU330  QNATU330        10.   
    QNATU335  QNATU335        10.   
    QNATU340  QNATU340        10.   
    QNATU345  QNATU345        10.   
    QNATU350  QNATU350        10.   
    QNATU355  QNATU355        10.   
    QNATU360  QNATU360        10.   
    QNATU365  QNATU365        10.   
    QNATU370  QNATU370        10.   
    QNATU375  QNATU375        10.   
ENDATA
