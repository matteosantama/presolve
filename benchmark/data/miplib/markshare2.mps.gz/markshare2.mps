* MIPLIB 2017 benchmark v2; LP relaxation (integrality removed).
* Source: https://miplib.zib.de/downloads/benchmark.zip ; retrieved 2026-09-21
* Instance: markshare2 ; Gleixner et al. (2021), doi:10.1007/s12532-020-00194-3
* Bounds and coefficients preserved; rows/variables renamed; objective minimized.
* Original compressed SHA256: 8b1ea0bee5d89f3247cfbf6fd5fbd1234ea48e1d7081a8b7fbd827602b4b8914
NAME markshare2
ROWS
 N OBJ
 E R0
 E R1
 E R2
 E R3
 E R4
 E R5
 E R6
COLUMNS
    X0                   OBJ 1
    X0                   R0 1
    X1                   OBJ -1
    X1                   R0 1
    X2                   OBJ 1
    X2                   R1 1
    X3                   OBJ -1
    X3                   R1 1
    X4                   OBJ 1
    X4                   R2 1
    X5                   OBJ -1
    X5                   R2 1
    X6                   OBJ 1
    X6                   R3 1
    X7                   OBJ -1
    X7                   R3 1
    X8                   OBJ 1
    X8                   R4 1
    X9                   OBJ -1
    X9                   R4 1
    X10                  OBJ 1
    X10                  R5 1
    X11                  OBJ -1
    X11                  R5 1
    X12                  OBJ 1
    X12                  R6 1
    X13                  OBJ -1
    X13                  R6 1
    X14                  OBJ 0
    X14                  R0 74
    X14                  R1 20
    X14                  R2 85
    X14                  R3 13
    X14                  R4 35
    X14                  R5 86
    X14                  R6 41
    X15                  OBJ 0
    X15                  R0 49
    X15                  R1 7
    X15                  R2 47
    X15                  R3 71
    X15                  R4 61
    X15                  R5 8
    X15                  R6 64
    X16                  OBJ 0
    X16                  R0 12
    X16                  R1 68
    X16                  R2 67
    X16                  R3 78
    X16                  R4 66
    X16                  R5 44
    X16                  R6 82
    X17                  OBJ 0
    X17                  R0 93
    X17                  R1 69
    X17                  R2 59
    X17                  R3 84
    X17                  R4 78
    X17                  R5 96
    X17                  R6 24
    X18                  OBJ 0
    X18                  R0 56
    X18                  R1 95
    X18                  R2 84
    X18                  R3 56
    X18                  R4 46
    X18                  R5 64
    X18                  R6 48
    X19                  OBJ 0
    X19                  R0 16
    X19                  R1 64
    X19                  R2 59
    X19                  R3 66
    X19                  R4 89
    X19                  R5 65
    X19                  R6 41
    X20                  OBJ 0
    X20                  R0 39
    X20                  R1 76
    X20                  R2 19
    X20                  R3 8
    X20                  R4 61
    X20                  R5 68
    X20                  R6 29
    X21                  OBJ 0
    X21                  R0 77
    X21                  R1 12
    X21                  R2 8
    X21                  R3 68
    X21                  R4 25
    X21                  R5 53
    X21                  R6 93
    X22                  OBJ 0
    X22                  R0 56
    X22                  R1 45
    X22                  R2 50
    X22                  R3 48
    X22                  R4 55
    X22                  R5 19
    X22                  R6 64
    X23                  OBJ 0
    X23                  R0 73
    X23                  R1 43
    X23                  R2 66
    X23                  R3 28
    X23                  R4 16
    X23                  R5 33
    X23                  R6 39
    X24                  OBJ 0
    X24                  R0 1
    X24                  R1 83
    X24                  R2 5
    X24                  R3 33
    X24                  R4 81
    X24                  R5 28
    X24                  R6 92
    X25                  OBJ 0
    X25                  R0 3
    X25                  R1 15
    X25                  R2 51
    X25                  R3 34
    X25                  R4 35
    X25                  R5 42
    X25                  R6 86
    X26                  OBJ 0
    X26                  R0 68
    X26                  R1 90
    X26                  R2 51
    X26                  R3 8
    X26                  R4 96
    X26                  R5 72
    X26                  R6 64
    X27                  OBJ 0
    X27                  R0 61
    X27                  R1 10
    X27                  R2 64
    X27                  R3 99
    X27                  R4 23
    X27                  R5 39
    X27                  R6 45
    X28                  OBJ 0
    X28                  R0 8
    X28                  R1 96
    X28                  R2 64
    X28                  R3 80
    X28                  R4 83
    X28                  R5 5
    X28                  R6 87
    X29                  OBJ 0
    X29                  R0 55
    X29                  R1 98
    X29                  R2 53
    X29                  R3 74
    X29                  R4 39
    X29                  R5 77
    X29                  R6 34
    X30                  OBJ 0
    X30                  R0 18
    X30                  R1 53
    X30                  R2 61
    X30                  R3 2
    X30                  R4 14
    X30                  R5 37
    X30                  R6 39
    X31                  OBJ 0
    X31                  R0 21
    X31                  R1 1
    X31                  R2 45
    X31                  R3 10
    X31                  R4 53
    X31                  R5 89
    X31                  R6 88
    X32                  OBJ 0
    X32                  R0 57
    X32                  R1 2
    X32                  R2 3
    X32                  R3 96
    X32                  R4 23
    X32                  R5 7
    X32                  R6 99
    X33                  OBJ 0
    X33                  R0 98
    X33                  R1 58
    X33                  R2 76
    X33                  R3 41
    X33                  R4 23
    X33                  R5 78
    X33                  R6 63
    X34                  OBJ 0
    X34                  R0 58
    X34                  R1 24
    X34                  R2 17
    X34                  R3 98
    X34                  R4 93
    X34                  R5 10
    X34                  R6 85
    X35                  OBJ 0
    X35                  R0 57
    X35                  R1 90
    X35                  R2 54
    X35                  R3 74
    X35                  R4 38
    X35                  R5 78
    X35                  R6 48
    X36                  OBJ 0
    X36                  R0 46
    X36                  R1 29
    X36                  R2 13
    X36                  R3 39
    X36                  R4 15
    X36                  R5 10
    X36                  R6 83
    X37                  OBJ 0
    X37                  R0 72
    X37                  R1 57
    X37                  R2 89
    X37                  R3 91
    X37                  R4 20
    X37                  R5 96
    X37                  R6 88
    X38                  OBJ 0
    X38                  R0 6
    X38                  R1 19
    X38                  R2 68
    X38                  R3 85
    X38                  R4 19
    X38                  R5 55
    X38                  R6 85
    X39                  OBJ 0
    X39                  R0 16
    X39                  R1 73
    X39                  R2 57
    X39                  R3 95
    X39                  R4 28
    X39                  R5 1
    X39                  R6 5
    X40                  OBJ 0
    X40                  R0 76
    X40                  R1 89
    X40                  R2 4
    X40                  R3 96
    X40                  R4 79
    X40                  R5 64
    X40                  R6 14
    X41                  OBJ 0
    X41                  R0 21
    X41                  R1 31
    X41                  R2 24
    X41                  R3 1
    X41                  R4 51
    X41                  R5 61
    X41                  R6 31
    X42                  OBJ 0
    X42                  R0 78
    X42                  R1 12
    X42                  R2 96
    X42                  R3 80
    X42                  R4 24
    X42                  R5 63
    X42                  R6 12
    X43                  OBJ 0
    X43                  R0 18
    X43                  R1 34
    X43                  R2 81
    X43                  R3 90
    X43                  R4 6
    X43                  R5 90
    X43                  R6 93
    X44                  OBJ 0
    X44                  R0 11
    X44                  R1 67
    X44                  R2 36
    X44                  R3 97
    X44                  R4 3
    X44                  R5 22
    X44                  R6 55
    X45                  OBJ 0
    X45                  R0 58
    X45                  R1 48
    X45                  R2 54
    X45                  R3 36
    X45                  R4 47
    X45                  R5 78
    X45                  R6 1
    X46                  OBJ 0
    X46                  R0 59
    X46                  R1 11
    X46                  R2 3
    X46                  R3 7
    X46                  R4 61
    X46                  R5 92
    X46                  R6 2
    X47                  OBJ 0
    X47                  R0 25
    X47                  R1 22
    X47                  R2 82
    X47                  R3 69
    X47                  R4 60
    X47                  R5 25
    X47                  R6 22
    X48                  OBJ 0
    X48                  R0 32
    X48                  R1 36
    X48                  R2 33
    X48                  R3 9
    X48                  R4 71
    X48                  R5 24
    X48                  R6 93
    X49                  OBJ 0
    X49                  R0 14
    X49                  R1 78
    X49                  R2 88
    X49                  R3 9
    X49                  R4 63
    X49                  R5 65
    X49                  R6 49
    X50                  OBJ 0
    X50                  R0 16
    X50                  R1 75
    X50                  R2 1
    X50                  R3 93
    X50                  R4 26
    X50                  R5 6
    X50                  R6 35
    X51                  OBJ 0
    X51                  R0 3
    X51                  R1 52
    X51                  R2 29
    X51                  R3 94
    X51                  R4 66
    X51                  R5 68
    X51                  R6 25
    X52                  OBJ 0
    X52                  R0 60
    X52                  R1 95
    X52                  R2 4
    X52                  R3 44
    X52                  R4 71
    X52                  R5 66
    X52                  R6 39
    X53                  OBJ 0
    X53                  R0 12
    X53                  R1 57
    X53                  R2 48
    X53                  R3 36
    X53                  R4 63
    X53                  R5 66
    X53                  R6 1
    X54                  OBJ 0
    X54                  R0 7
    X54                  R1 62
    X54                  R2 51
    X54                  R3 71
    X54                  R4 56
    X54                  R5 1
    X54                  R6 77
    X55                  OBJ 0
    X55                  R0 42
    X55                  R1 94
    X55                  R2 14
    X55                  R3 37
    X55                  R4 32
    X55                  R5 67
    X55                  R6 43
    X56                  OBJ 0
    X56                  R0 98
    X56                  R1 10
    X56                  R2 86
    X56                  R3 72
    X56                  R4 39
    X56                  R5 78
    X56                  R6 7
    X57                  OBJ 0
    X57                  R0 34
    X57                  R1 42
    X57                  R2 64
    X57                  R3 38
    X57                  R4 31
    X57                  R5 21
    X57                  R6 42
    X58                  OBJ 0
    X58                  R0 33
    X58                  R1 89
    X58                  R2 73
    X58                  R3 74
    X58                  R4 64
    X58                  R5 47
    X58                  R6 36
    X59                  OBJ 0
    X59                  R0 16
    X59                  R1 11
    X59                  R2 78
    X59                  R3 89
    X59                  R4 89
    X59                  R5 17
    X59                  R6 63
    X60                  OBJ 0
    X60                  R0 97
    X60                  R1 77
    X60                  R2 45
    X60                  R3 37
    X60                  R4 62
    X60                  R5 89
    X60                  R6 5
    X61                  OBJ 0
    X61                  R0 63
    X61                  R1 85
    X61                  R2 65
    X61                  R3 24
    X61                  R4 68
    X61                  R5 77
    X61                  R6 8
    X62                  OBJ 0
    X62                  R0 66
    X62                  R1 30
    X62                  R2 30
    X62                  R3 88
    X62                  R4 59
    X62                  R5 88
    X62                  R6 43
    X63                  OBJ 0
    X63                  R0 28
    X63                  R1 82
    X63                  R2 52
    X63                  R3 77
    X63                  R4 71
    X63                  R5 54
    X63                  R6 18
    X64                  OBJ 0
    X64                  R0 57
    X64                  R1 20
    X64                  R2 6
    X64                  R3 61
    X64                  R4 48
    X64                  R5 10
    X64                  R6 60
    X65                  OBJ 0
    X65                  R0 19
    X65                  R1 52
    X65                  R2 78
    X65                  R3 80
    X65                  R4 76
    X65                  R5 87
    X65                  R6 47
    X66                  OBJ 0
    X66                  R0 74
    X66                  R1 78
    X66                  R2 9
    X66                  R3 2
    X66                  R4 96
    X66                  R5 88
    X66                  R6 47
    X67                  OBJ 0
    X67                  R0 44
    X67                  R1 6
    X67                  R2 19
    X67                  R3 60
    X67                  R4 74
    X67                  R5 80
    X67                  R6 46
    X68                  OBJ 0
    X68                  R0 45
    X68                  R1 57
    X68                  R2 87
    X68                  R3 87
    X68                  R4 61
    X68                  R5 76
    X68                  R6 45
    X69                  OBJ 0
    X69                  R0 49
    X69                  R1 65
    X69                  R2 73
    X69                  R3 80
    X69                  R4 21
    X69                  R5 9
    X69                  R6 38
    X70                  OBJ 0
    X70                  R0 76
    X70                  R1 79
    X70                  R2 10
    X70                  R3 74
    X70                  R4 46
    X70                  R5 83
    X70                  R6 9
    X71                  OBJ 0
    X71                  R0 74
    X71                  R1 83
    X71                  R2 87
    X71                  R3 42
    X71                  R4 18
    X71                  R5 95
    X71                  R6 37
    X72                  OBJ 0
    X72                  R0 9
    X72                  R1 16
    X72                  R2 33
    X72                  R3 2
    X72                  R4 23
    X72                  R5 86
    X72                  R6 8
    X73                  OBJ 0
    X73                  R0 44
    X73                  R1 67
    X73                  R2 1
    X73                  R3 37
    X73                  R4 24
    X73                  R5 24
    X73                  R6 82
RHS
    RHS                  OBJ -0
    RHS                  R0 1324
    RHS                  R1 1554
    RHS                  R2 1429
    RHS                  R3 1686
    RHS                  R4 1482
    RHS                  R5 1613
    RHS                  R6 1424
BOUNDS
 	FR BND X0
 	LO BND X0 0
 	FX BND X1 0
 	FR BND X2
 	LO BND X2 0
 	FX BND X3 0
 	FR BND X4
 	LO BND X4 0
 	FX BND X5 0
 	FR BND X6
 	LO BND X6 0
 	FX BND X7 0
 	FR BND X8
 	LO BND X8 0
 	FX BND X9 0
 	FR BND X10
 	LO BND X10 0
 	FX BND X11 0
 	FR BND X12
 	LO BND X12 0
 	FX BND X13 0
 	FR BND X14
 	LO BND X14 0
 	UP BND X14 1
 	FR BND X15
 	LO BND X15 0
 	UP BND X15 1
 	FR BND X16
 	LO BND X16 0
 	UP BND X16 1
 	FR BND X17
 	LO BND X17 0
 	UP BND X17 1
 	FR BND X18
 	LO BND X18 0
 	UP BND X18 1
 	FR BND X19
 	LO BND X19 0
 	UP BND X19 1
 	FR BND X20
 	LO BND X20 0
 	UP BND X20 1
 	FR BND X21
 	LO BND X21 0
 	UP BND X21 1
 	FR BND X22
 	LO BND X22 0
 	UP BND X22 1
 	FR BND X23
 	LO BND X23 0
 	UP BND X23 1
 	FR BND X24
 	LO BND X24 0
 	UP BND X24 1
 	FR BND X25
 	LO BND X25 0
 	UP BND X25 1
 	FR BND X26
 	LO BND X26 0
 	UP BND X26 1
 	FR BND X27
 	LO BND X27 0
 	UP BND X27 1
 	FR BND X28
 	LO BND X28 0
 	UP BND X28 1
 	FR BND X29
 	LO BND X29 0
 	UP BND X29 1
 	FR BND X30
 	LO BND X30 0
 	UP BND X30 1
 	FR BND X31
 	LO BND X31 0
 	UP BND X31 1
 	FR BND X32
 	LO BND X32 0
 	UP BND X32 1
 	FR BND X33
 	LO BND X33 0
 	UP BND X33 1
 	FR BND X34
 	LO BND X34 0
 	UP BND X34 1
 	FR BND X35
 	LO BND X35 0
 	UP BND X35 1
 	FR BND X36
 	LO BND X36 0
 	UP BND X36 1
 	FR BND X37
 	LO BND X37 0
 	UP BND X37 1
 	FR BND X38
 	LO BND X38 0
 	UP BND X38 1
 	FR BND X39
 	LO BND X39 0
 	UP BND X39 1
 	FR BND X40
 	LO BND X40 0
 	UP BND X40 1
 	FR BND X41
 	LO BND X41 0
 	UP BND X41 1
 	FR BND X42
 	LO BND X42 0
 	UP BND X42 1
 	FR BND X43
 	LO BND X43 0
 	UP BND X43 1
 	FR BND X44
 	LO BND X44 0
 	UP BND X44 1
 	FR BND X45
 	LO BND X45 0
 	UP BND X45 1
 	FR BND X46
 	LO BND X46 0
 	UP BND X46 1
 	FR BND X47
 	LO BND X47 0
 	UP BND X47 1
 	FR BND X48
 	LO BND X48 0
 	UP BND X48 1
 	FR BND X49
 	LO BND X49 0
 	UP BND X49 1
 	FR BND X50
 	LO BND X50 0
 	UP BND X50 1
 	FR BND X51
 	LO BND X51 0
 	UP BND X51 1
 	FR BND X52
 	LO BND X52 0
 	UP BND X52 1
 	FR BND X53
 	LO BND X53 0
 	UP BND X53 1
 	FR BND X54
 	LO BND X54 0
 	UP BND X54 1
 	FR BND X55
 	LO BND X55 0
 	UP BND X55 1
 	FR BND X56
 	LO BND X56 0
 	UP BND X56 1
 	FR BND X57
 	LO BND X57 0
 	UP BND X57 1
 	FR BND X58
 	LO BND X58 0
 	UP BND X58 1
 	FR BND X59
 	LO BND X59 0
 	UP BND X59 1
 	FR BND X60
 	LO BND X60 0
 	UP BND X60 1
 	FR BND X61
 	LO BND X61 0
 	UP BND X61 1
 	FR BND X62
 	LO BND X62 0
 	UP BND X62 1
 	FR BND X63
 	LO BND X63 0
 	UP BND X63 1
 	FR BND X64
 	LO BND X64 0
 	UP BND X64 1
 	FR BND X65
 	LO BND X65 0
 	UP BND X65 1
 	FR BND X66
 	LO BND X66 0
 	UP BND X66 1
 	FR BND X67
 	LO BND X67 0
 	UP BND X67 1
 	FR BND X68
 	LO BND X68 0
 	UP BND X68 1
 	FR BND X69
 	LO BND X69 0
 	UP BND X69 1
 	FR BND X70
 	LO BND X70 0
 	UP BND X70 1
 	FR BND X71
 	LO BND X71 0
 	UP BND X71 1
 	FR BND X72
 	LO BND X72 0
 	UP BND X72 1
 	FR BND X73
 	LO BND X73 0
 	UP BND X73 1
ENDATA
