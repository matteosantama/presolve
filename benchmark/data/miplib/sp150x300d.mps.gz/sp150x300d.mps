* MIPLIB 2017 benchmark v2; LP relaxation (integrality removed).
* Source: https://miplib.zib.de/downloads/benchmark.zip ; retrieved 2026-09-21
* Instance: sp150x300d ; Gleixner et al. (2021), doi:10.1007/s12532-020-00194-3
* Bounds and coefficients preserved; rows/variables renamed; objective minimized.
* Original compressed SHA256: 47051527397e27d1a62d0462ded35042d5eb5f4c4a3b5e3257c82279b97f1e42
NAME sp150x300d
ROWS
 N OBJ
 E R0
 E R1
 E R2
 E R3
 E R4
 E R5
 E R6
 E R7
 E R8
 E R9
 E R10
 E R11
 E R12
 E R13
 E R14
 E R15
 E R16
 E R17
 E R18
 E R19
 E R20
 E R21
 E R22
 E R23
 E R24
 E R25
 E R26
 E R27
 E R28
 E R29
 E R30
 E R31
 E R32
 E R33
 E R34
 E R35
 E R36
 E R37
 E R38
 E R39
 E R40
 E R41
 E R42
 E R43
 E R44
 E R45
 E R46
 E R47
 E R48
 E R49
 E R50
 E R51
 E R52
 E R53
 E R54
 E R55
 E R56
 E R57
 E R58
 E R59
 E R60
 E R61
 E R62
 E R63
 E R64
 E R65
 E R66
 E R67
 E R68
 E R69
 E R70
 E R71
 E R72
 E R73
 E R74
 E R75
 E R76
 E R77
 E R78
 E R79
 E R80
 E R81
 E R82
 E R83
 E R84
 E R85
 E R86
 E R87
 E R88
 E R89
 E R90
 E R91
 E R92
 E R93
 E R94
 E R95
 E R96
 E R97
 E R98
 E R99
 E R100
 E R101
 E R102
 E R103
 E R104
 E R105
 E R106
 E R107
 E R108
 E R109
 E R110
 E R111
 E R112
 E R113
 E R114
 E R115
 E R116
 E R117
 E R118
 E R119
 E R120
 E R121
 E R122
 E R123
 E R124
 E R125
 E R126
 E R127
 E R128
 E R129
 E R130
 E R131
 E R132
 E R133
 E R134
 E R135
 E R136
 E R137
 E R138
 E R139
 E R140
 E R141
 E R142
 E R143
 E R144
 E R145
 E R146
 E R147
 E R148
 E R149
 L R150
 L R151
 L R152
 L R153
 L R154
 L R155
 L R156
 L R157
 L R158
 L R159
 L R160
 L R161
 L R162
 L R163
 L R164
 L R165
 L R166
 L R167
 L R168
 L R169
 L R170
 L R171
 L R172
 L R173
 L R174
 L R175
 L R176
 L R177
 L R178
 L R179
 L R180
 L R181
 L R182
 L R183
 L R184
 L R185
 L R186
 L R187
 L R188
 L R189
 L R190
 L R191
 L R192
 L R193
 L R194
 L R195
 L R196
 L R197
 L R198
 L R199
 L R200
 L R201
 L R202
 L R203
 L R204
 L R205
 L R206
 L R207
 L R208
 L R209
 L R210
 L R211
 L R212
 L R213
 L R214
 L R215
 L R216
 L R217
 L R218
 L R219
 L R220
 L R221
 L R222
 L R223
 L R224
 L R225
 L R226
 L R227
 L R228
 L R229
 L R230
 L R231
 L R232
 L R233
 L R234
 L R235
 L R236
 L R237
 L R238
 L R239
 L R240
 L R241
 L R242
 L R243
 L R244
 L R245
 L R246
 L R247
 L R248
 L R249
 L R250
 L R251
 L R252
 L R253
 L R254
 L R255
 L R256
 L R257
 L R258
 L R259
 L R260
 L R261
 L R262
 L R263
 L R264
 L R265
 L R266
 L R267
 L R268
 L R269
 L R270
 L R271
 L R272
 L R273
 L R274
 L R275
 L R276
 L R277
 L R278
 L R279
 L R280
 L R281
 L R282
 L R283
 L R284
 L R285
 L R286
 L R287
 L R288
 L R289
 L R290
 L R291
 L R292
 L R293
 L R294
 L R295
 L R296
 L R297
 L R298
 L R299
 L R300
 L R301
 L R302
 L R303
 L R304
 L R305
 L R306
 L R307
 L R308
 L R309
 L R310
 L R311
 L R312
 L R313
 L R314
 L R315
 L R316
 L R317
 L R318
 L R319
 L R320
 L R321
 L R322
 L R323
 L R324
 L R325
 L R326
 L R327
 L R328
 L R329
 L R330
 L R331
 L R332
 L R333
 L R334
 L R335
 L R336
 L R337
 L R338
 L R339
 L R340
 L R341
 L R342
 L R343
 L R344
 L R345
 L R346
 L R347
 L R348
 L R349
 L R350
 L R351
 L R352
 L R353
 L R354
 L R355
 L R356
 L R357
 L R358
 L R359
 L R360
 L R361
 L R362
 L R363
 L R364
 L R365
 L R366
 L R367
 L R368
 L R369
 L R370
 L R371
 L R372
 L R373
 L R374
 L R375
 L R376
 L R377
 L R378
 L R379
 L R380
 L R381
 L R382
 L R383
 L R384
 L R385
 L R386
 L R387
 L R388
 L R389
 L R390
 L R391
 L R392
 L R393
 L R394
 L R395
 L R396
 L R397
 L R398
 L R399
 L R400
 L R401
 L R402
 L R403
 L R404
 L R405
 L R406
 L R407
 L R408
 L R409
 L R410
 L R411
 L R412
 L R413
 L R414
 L R415
 L R416
 L R417
 L R418
 L R419
 L R420
 L R421
 L R422
 L R423
 L R424
 L R425
 L R426
 L R427
 L R428
 L R429
 L R430
 L R431
 L R432
 L R433
 L R434
 L R435
 L R436
 L R437
 L R438
 L R439
 L R440
 L R441
 L R442
 L R443
 L R444
 L R445
 L R446
 L R447
 L R448
 L R449
COLUMNS
    X0                   OBJ 0
    X0                   R1 -1
    X0                   R5 1
    X0                   R150 1
    X1                   OBJ 0
    X1                   R4 1
    X1                   R5 -1
    X1                   R151 1
    X2                   OBJ 0
    X2                   R5 -1
    X2                   R6 1
    X2                   R152 1
    X3                   OBJ 0
    X3                   R4 1
    X3                   R6 -1
    X3                   R153 1
    X4                   OBJ 0
    X4                   R1 -1
    X4                   R7 1
    X4                   R154 1
    X5                   OBJ 0
    X5                   R4 1
    X5                   R7 -1
    X5                   R155 1
    X6                   OBJ 0
    X6                   R1 -1
    X6                   R4 1
    X6                   R156 1
    X7                   OBJ 0
    X7                   R1 -1
    X7                   R8 1
    X7                   R157 1
    X8                   OBJ 0
    X8                   R4 1
    X8                   R8 -1
    X8                   R158 1
    X9                   OBJ 0
    X9                   R4 -1
    X9                   R11 1
    X9                   R159 1
    X10                  OBJ 0
    X10                  R10 1
    X10                  R11 -1
    X10                  R160 1
    X11                  OBJ 0
    X11                  R4 -1
    X11                  R10 1
    X11                  R161 1
    X12                  OBJ 0
    X12                  R9 1
    X12                  R10 -1
    X12                  R162 1
    X13                  OBJ 0
    X13                  R9 1
    X13                  R10 -1
    X13                  R163 1
    X14                  OBJ 0
    X14                  R9 1
    X14                  R10 -1
    X14                  R164 1
    X15                  OBJ 0
    X15                  R9 -1
    X15                  R12 1
    X15                  R165 1
    X16                  OBJ 0
    X16                  R3 1
    X16                  R12 -1
    X16                  R166 1
    X17                  OBJ 0
    X17                  R3 1
    X17                  R9 -1
    X17                  R167 1
    X18                  OBJ 0
    X18                  R3 1
    X18                  R9 -1
    X18                  R168 1
    X19                  OBJ 0
    X19                  R3 -1
    X19                  R14 1
    X19                  R169 1
    X20                  OBJ 0
    X20                  R13 1
    X20                  R14 -1
    X20                  R170 1
    X21                  OBJ 0
    X21                  R3 -1
    X21                  R13 1
    X21                  R171 1
    X22                  OBJ 0
    X22                  R3 -1
    X22                  R15 1
    X22                  R172 1
    X23                  OBJ 0
    X23                  R13 1
    X23                  R15 -1
    X23                  R173 1
    X24                  OBJ 0
    X24                  R2 1
    X24                  R13 -1
    X24                  R174 1
    X25                  OBJ 0
    X25                  R2 1
    X25                  R13 -1
    X25                  R175 1
    X26                  OBJ 0
    X26                  R13 -1
    X26                  R16 1
    X26                  R176 1
    X27                  OBJ 0
    X27                  R2 1
    X27                  R16 -1
    X27                  R177 1
    X28                  OBJ 0
    X28                  R3 -1
    X28                  R18 1
    X28                  R178 1
    X29                  OBJ 0
    X29                  R17 1
    X29                  R18 -1
    X29                  R179 1
    X30                  OBJ 0
    X30                  R2 1
    X30                  R17 -1
    X30                  R180 1
    X31                  OBJ 0
    X31                  R17 -1
    X31                  R19 1
    X31                  R181 1
    X32                  OBJ 0
    X32                  R2 1
    X32                  R19 -1
    X32                  R182 1
    X33                  OBJ 0
    X33                  R3 -1
    X33                  R20 1
    X33                  R183 1
    X34                  OBJ 0
    X34                  R2 1
    X34                  R20 -1
    X34                  R184 1
    X35                  OBJ 0
    X35                  R2 1
    X35                  R3 -1
    X35                  R185 1
    X36                  OBJ 0
    X36                  R3 -1
    X36                  R21 1
    X36                  R186 1
    X37                  OBJ 0
    X37                  R2 1
    X37                  R21 -1
    X37                  R187 1
    X38                  OBJ 0
    X38                  R1 -1
    X38                  R23 1
    X38                  R188 1
    X39                  OBJ 0
    X39                  R1 -1
    X39                  R23 1
    X39                  R189 1
    X40                  OBJ 0
    X40                  R23 -1
    X40                  R24 1
    X40                  R190 1
    X41                  OBJ 0
    X41                  R22 1
    X41                  R24 -1
    X41                  R191 1
    X42                  OBJ 0
    X42                  R1 -1
    X42                  R25 1
    X42                  R192 1
    X43                  OBJ 0
    X43                  R1 -1
    X43                  R25 1
    X43                  R193 1
    X44                  OBJ 0
    X44                  R22 1
    X44                  R25 -1
    X44                  R194 1
    X45                  OBJ 0
    X45                  R25 -1
    X45                  R26 1
    X45                  R195 1
    X46                  OBJ 0
    X46                  R22 1
    X46                  R26 -1
    X46                  R196 1
    X47                  OBJ 0
    X47                  R1 -1
    X47                  R27 1
    X47                  R197 1
    X48                  OBJ 0
    X48                  R1 -1
    X48                  R27 1
    X48                  R198 1
    X49                  OBJ 0
    X49                  R27 -1
    X49                  R28 1
    X49                  R199 1
    X50                  OBJ 0
    X50                  R22 1
    X50                  R28 -1
    X50                  R200 1
    X51                  OBJ 0
    X51                  R22 1
    X51                  R27 -1
    X51                  R201 1
    X52                  OBJ 0
    X52                  R1 -1
    X52                  R29 1
    X52                  R202 1
    X53                  OBJ 0
    X53                  R1 -1
    X53                  R29 1
    X53                  R203 1
    X54                  OBJ 0
    X54                  R29 -1
    X54                  R30 1
    X54                  R204 1
    X55                  OBJ 0
    X55                  R22 1
    X55                  R30 -1
    X55                  R205 1
    X56                  OBJ 0
    X56                  R22 -1
    X56                  R32 1
    X56                  R206 1
    X57                  OBJ 0
    X57                  R22 -1
    X57                  R32 1
    X57                  R207 1
    X58                  OBJ 0
    X58                  R22 -1
    X58                  R33 1
    X58                  R208 1
    X59                  OBJ 0
    X59                  R32 1
    X59                  R33 -1
    X59                  R209 1
    X60                  OBJ 0
    X60                  R32 -1
    X60                  R34 1
    X60                  R210 1
    X61                  OBJ 0
    X61                  R31 1
    X61                  R34 -1
    X61                  R211 1
    X62                  OBJ 0
    X62                  R31 1
    X62                  R32 -1
    X62                  R212 1
    X63                  OBJ 0
    X63                  R32 -1
    X63                  R35 1
    X63                  R213 1
    X64                  OBJ 0
    X64                  R31 1
    X64                  R35 -1
    X64                  R214 1
    X65                  OBJ 0
    X65                  R31 -1
    X65                  R37 1
    X65                  R215 1
    X66                  OBJ 0
    X66                  R36 1
    X66                  R37 -1
    X66                  R216 1
    X67                  OBJ 0
    X67                  R31 -1
    X67                  R36 1
    X67                  R217 1
    X68                  OBJ 0
    X68                  R31 -1
    X68                  R36 1
    X68                  R218 1
    X69                  OBJ 0
    X69                  R36 -1
    X69                  R39 1
    X69                  R219 1
    X70                  OBJ 0
    X70                  R38 1
    X70                  R39 -1
    X70                  R220 1
    X71                  OBJ 0
    X71                  R36 -1
    X71                  R38 1
    X71                  R221 1
    X72                  OBJ 0
    X72                  R2 1
    X72                  R38 -1
    X72                  R222 1
    X73                  OBJ 0
    X73                  R2 1
    X73                  R38 -1
    X73                  R223 1
    X74                  OBJ 0
    X74                  R2 1
    X74                  R38 -1
    X74                  R224 1
    X75                  OBJ 0
    X75                  R1 -1
    X75                  R41 1
    X75                  R225 1
    X76                  OBJ 0
    X76                  R1 -1
    X76                  R41 1
    X76                  R226 1
    X77                  OBJ 0
    X77                  R1 -1
    X77                  R42 1
    X77                  R227 1
    X78                  OBJ 0
    X78                  R41 1
    X78                  R42 -1
    X78                  R228 1
    X79                  OBJ 0
    X79                  R41 -1
    X79                  R43 1
    X79                  R229 1
    X80                  OBJ 0
    X80                  R41 -1
    X80                  R43 1
    X80                  R230 1
    X81                  OBJ 0
    X81                  R43 -1
    X81                  R44 1
    X81                  R231 1
    X82                  OBJ 0
    X82                  R40 1
    X82                  R44 -1
    X82                  R232 1
    X83                  OBJ 0
    X83                  R40 1
    X83                  R43 -1
    X83                  R233 1
    X84                  OBJ 0
    X84                  R40 -1
    X84                  R46 1
    X84                  R234 1
    X85                  OBJ 0
    X85                  R40 -1
    X85                  R46 1
    X85                  R235 1
    X86                  OBJ 0
    X86                  R46 -1
    X86                  R47 1
    X86                  R236 1
    X87                  OBJ 0
    X87                  R45 1
    X87                  R47 -1
    X87                  R237 1
    X88                  OBJ 0
    X88                  R45 1
    X88                  R46 -1
    X88                  R238 1
    X89                  OBJ 0
    X89                  R2 1
    X89                  R45 -1
    X89                  R239 1
    X90                  OBJ 0
    X90                  R2 1
    X90                  R45 -1
    X90                  R240 1
    X91                  OBJ 0
    X91                  R45 -1
    X91                  R48 1
    X91                  R241 1
    X92                  OBJ 0
    X92                  R2 1
    X92                  R48 -1
    X92                  R242 1
    X93                  OBJ 0
    X93                  R1 -1
    X93                  R50 1
    X93                  R243 1
    X94                  OBJ 0
    X94                  R1 -1
    X94                  R51 1
    X94                  R244 1
    X95                  OBJ 0
    X95                  R50 1
    X95                  R51 -1
    X95                  R245 1
    X96                  OBJ 0
    X96                  R50 -1
    X96                  R52 1
    X96                  R246 1
    X97                  OBJ 0
    X97                  R49 1
    X97                  R52 -1
    X97                  R247 1
    X98                  OBJ 0
    X98                  R49 1
    X98                  R50 -1
    X98                  R248 1
    X99                  OBJ 0
    X99                  R1 -1
    X99                  R49 1
    X99                  R249 1
    X100                 OBJ 0
    X100                 R1 -1
    X100                 R53 1
    X100                 R250 1
    X101                 OBJ 0
    X101                 R49 1
    X101                 R53 -1
    X101                 R251 1
    X102                 OBJ 0
    X102                 R1 -1
    X102                 R54 1
    X102                 R252 1
    X103                 OBJ 0
    X103                 R49 1
    X103                 R54 -1
    X103                 R253 1
    X104                 OBJ 0
    X104                 R49 -1
    X104                 R55 1
    X104                 R254 1
    X105                 OBJ 0
    X105                 R49 -1
    X105                 R56 1
    X105                 R255 1
    X106                 OBJ 0
    X106                 R55 1
    X106                 R56 -1
    X106                 R256 1
    X107                 OBJ 0
    X107                 R49 -1
    X107                 R57 1
    X107                 R257 1
    X108                 OBJ 0
    X108                 R55 1
    X108                 R57 -1
    X108                 R258 1
    X109                 OBJ 0
    X109                 R2 1
    X109                 R55 -1
    X109                 R259 1
    X110                 OBJ 0
    X110                 R2 1
    X110                 R55 -1
    X110                 R260 1
    X111                 OBJ 0
    X111                 R55 -1
    X111                 R58 1
    X111                 R261 1
    X112                 OBJ 0
    X112                 R2 1
    X112                 R58 -1
    X112                 R262 1
    X113                 OBJ 0
    X113                 R1 -1
    X113                 R61 1
    X113                 R263 1
    X114                 OBJ 0
    X114                 R1 -1
    X114                 R61 1
    X114                 R264 1
    X115                 OBJ 0
    X115                 R61 -1
    X115                 R62 1
    X115                 R265 1
    X116                 OBJ 0
    X116                 R60 1
    X116                 R62 -1
    X116                 R266 1
    X117                 OBJ 0
    X117                 R1 -1
    X117                 R63 1
    X117                 R267 1
    X118                 OBJ 0
    X118                 R60 1
    X118                 R63 -1
    X118                 R268 1
    X119                 OBJ 0
    X119                 R1 -1
    X119                 R60 1
    X119                 R269 1
    X120                 OBJ 0
    X120                 R1 -1
    X120                 R64 1
    X120                 R270 1
    X121                 OBJ 0
    X121                 R60 1
    X121                 R64 -1
    X121                 R271 1
    X122                 OBJ 0
    X122                 R60 -1
    X122                 R67 1
    X122                 R272 1
    X123                 OBJ 0
    X123                 R66 1
    X123                 R67 -1
    X123                 R273 1
    X124                 OBJ 0
    X124                 R60 -1
    X124                 R66 1
    X124                 R274 1
    X125                 OBJ 0
    X125                 R60 -1
    X125                 R66 1
    X125                 R275 1
    X126                 OBJ 0
    X126                 R65 1
    X126                 R66 -1
    X126                 R276 1
    X127                 OBJ 0
    X127                 R65 1
    X127                 R66 -1
    X127                 R277 1
    X128                 OBJ 0
    X128                 R65 -1
    X128                 R68 1
    X128                 R278 1
    X129                 OBJ 0
    X129                 R59 1
    X129                 R68 -1
    X129                 R279 1
    X130                 OBJ 0
    X130                 R59 1
    X130                 R65 -1
    X130                 R280 1
    X131                 OBJ 0
    X131                 R59 1
    X131                 R65 -1
    X131                 R281 1
    X132                 OBJ 0
    X132                 R59 -1
    X132                 R69 1
    X132                 R282 1
    X133                 OBJ 0
    X133                 R59 -1
    X133                 R70 1
    X133                 R283 1
    X134                 OBJ 0
    X134                 R69 1
    X134                 R70 -1
    X134                 R284 1
    X135                 OBJ 0
    X135                 R59 -1
    X135                 R71 1
    X135                 R285 1
    X136                 OBJ 0
    X136                 R59 -1
    X136                 R71 1
    X136                 R286 1
    X137                 OBJ 0
    X137                 R69 1
    X137                 R71 -1
    X137                 R287 1
    X138                 OBJ 0
    X138                 R71 -1
    X138                 R72 1
    X138                 R288 1
    X139                 OBJ 0
    X139                 R69 1
    X139                 R72 -1
    X139                 R289 1
    X140                 OBJ 0
    X140                 R69 -1
    X140                 R73 1
    X140                 R290 1
    X141                 OBJ 0
    X141                 R69 -1
    X141                 R73 1
    X141                 R291 1
    X142                 OBJ 0
    X142                 R69 -1
    X142                 R73 1
    X142                 R292 1
    X143                 OBJ 0
    X143                 R69 -1
    X143                 R74 1
    X143                 R293 1
    X144                 OBJ 0
    X144                 R73 1
    X144                 R74 -1
    X144                 R294 1
    X145                 OBJ 0
    X145                 R73 -1
    X145                 R75 1
    X145                 R295 1
    X146                 OBJ 0
    X146                 R2 1
    X146                 R75 -1
    X146                 R296 1
    X147                 OBJ 0
    X147                 R2 1
    X147                 R73 -1
    X147                 R297 1
    X148                 OBJ 0
    X148                 R73 -1
    X148                 R76 1
    X148                 R298 1
    X149                 OBJ 0
    X149                 R2 1
    X149                 R76 -1
    X149                 R299 1
    X150                 OBJ 0
    X150                 R2 -1
    X150                 R78 1
    X150                 R300 1
    X151                 OBJ 0
    X151                 R77 1
    X151                 R78 -1
    X151                 R301 1
    X152                 OBJ 0
    X152                 R78 -1
    X152                 R79 1
    X152                 R302 1
    X153                 OBJ 0
    X153                 R77 1
    X153                 R79 -1
    X153                 R303 1
    X154                 OBJ 0
    X154                 R2 -1
    X154                 R81 1
    X154                 R304 1
    X155                 OBJ 0
    X155                 R80 1
    X155                 R81 -1
    X155                 R305 1
    X156                 OBJ 0
    X156                 R2 -1
    X156                 R80 1
    X156                 R306 1
    X157                 OBJ 0
    X157                 R77 1
    X157                 R80 -1
    X157                 R307 1
    X158                 OBJ 0
    X158                 R80 -1
    X158                 R82 1
    X158                 R308 1
    X159                 OBJ 0
    X159                 R77 1
    X159                 R82 -1
    X159                 R309 1
    X160                 OBJ 0
    X160                 R2 -1
    X160                 R83 1
    X160                 R310 1
    X161                 OBJ 0
    X161                 R2 -1
    X161                 R83 1
    X161                 R311 1
    X162                 OBJ 0
    X162                 R2 -1
    X162                 R84 1
    X162                 R312 1
    X163                 OBJ 0
    X163                 R83 1
    X163                 R84 -1
    X163                 R313 1
    X164                 OBJ 0
    X164                 R77 1
    X164                 R83 -1
    X164                 R314 1
    X165                 OBJ 0
    X165                 R83 -1
    X165                 R85 1
    X165                 R315 1
    X166                 OBJ 0
    X166                 R77 1
    X166                 R85 -1
    X166                 R316 1
    X167                 OBJ 0
    X167                 R83 -1
    X167                 R86 1
    X167                 R317 1
    X168                 OBJ 0
    X168                 R77 1
    X168                 R86 -1
    X168                 R318 1
    X169                 OBJ 0
    X169                 R77 -1
    X169                 R89 1
    X169                 R319 1
    X170                 OBJ 0
    X170                 R88 1
    X170                 R89 -1
    X170                 R320 1
    X171                 OBJ 0
    X171                 R77 -1
    X171                 R88 1
    X171                 R321 1
    X172                 OBJ 0
    X172                 R87 1
    X172                 R88 -1
    X172                 R322 1
    X173                 OBJ 0
    X173                 R87 1
    X173                 R88 -1
    X173                 R323 1
    X174                 OBJ 0
    X174                 R77 -1
    X174                 R90 1
    X174                 R324 1
    X175                 OBJ 0
    X175                 R90 -1
    X175                 R91 1
    X175                 R325 1
    X176                 OBJ 0
    X176                 R87 1
    X176                 R91 -1
    X176                 R326 1
    X177                 OBJ 0
    X177                 R87 1
    X177                 R90 -1
    X177                 R327 1
    X178                 OBJ 0
    X178                 R87 -1
    X178                 R92 1
    X178                 R328 1
    X179                 OBJ 0
    X179                 R87 -1
    X179                 R92 1
    X179                 R329 1
    X180                 OBJ 0
    X180                 R87 -1
    X180                 R93 1
    X180                 R330 1
    X181                 OBJ 0
    X181                 R92 1
    X181                 R93 -1
    X181                 R331 1
    X182                 OBJ 0
    X182                 R92 -1
    X182                 R94 1
    X182                 R332 1
    X183                 OBJ 0
    X183                 R92 -1
    X183                 R94 1
    X183                 R333 1
    X184                 OBJ 0
    X184                 R92 -1
    X184                 R94 1
    X184                 R334 1
    X185                 OBJ 0
    X185                 R0 1
    X185                 R94 -1
    X185                 R335 1
    X186                 OBJ 0
    X186                 R94 -1
    X186                 R95 1
    X186                 R336 1
    X187                 OBJ 0
    X187                 R0 1
    X187                 R95 -1
    X187                 R337 1
    X188                 OBJ 0
    X188                 R2 -1
    X188                 R97 1
    X188                 R338 1
    X189                 OBJ 0
    X189                 R2 -1
    X189                 R97 1
    X189                 R339 1
    X190                 OBJ 0
    X190                 R96 1
    X190                 R97 -1
    X190                 R340 1
    X191                 OBJ 0
    X191                 R97 -1
    X191                 R98 1
    X191                 R341 1
    X192                 OBJ 0
    X192                 R96 1
    X192                 R98 -1
    X192                 R342 1
    X193                 OBJ 0
    X193                 R2 -1
    X193                 R99 1
    X193                 R343 1
    X194                 OBJ 0
    X194                 R96 1
    X194                 R99 -1
    X194                 R344 1
    X195                 OBJ 0
    X195                 R2 -1
    X195                 R96 1
    X195                 R345 1
    X196                 OBJ 0
    X196                 R2 -1
    X196                 R100 1
    X196                 R346 1
    X197                 OBJ 0
    X197                 R96 1
    X197                 R100 -1
    X197                 R347 1
    X198                 OBJ 0
    X198                 R2 -1
    X198                 R102 1
    X198                 R348 1
    X199                 OBJ 0
    X199                 R101 1
    X199                 R102 -1
    X199                 R349 1
    X200                 OBJ 0
    X200                 R2 -1
    X200                 R101 1
    X200                 R350 1
    X201                 OBJ 0
    X201                 R2 -1
    X201                 R103 1
    X201                 R351 1
    X202                 OBJ 0
    X202                 R101 1
    X202                 R103 -1
    X202                 R352 1
    X203                 OBJ 0
    X203                 R101 -1
    X203                 R104 1
    X203                 R353 1
    X204                 OBJ 0
    X204                 R101 -1
    X204                 R104 1
    X204                 R354 1
    X205                 OBJ 0
    X205                 R96 1
    X205                 R104 -1
    X205                 R355 1
    X206                 OBJ 0
    X206                 R104 -1
    X206                 R105 1
    X206                 R356 1
    X207                 OBJ 0
    X207                 R96 1
    X207                 R105 -1
    X207                 R357 1
    X208                 OBJ 0
    X208                 R96 -1
    X208                 R107 1
    X208                 R358 1
    X209                 OBJ 0
    X209                 R106 1
    X209                 R107 -1
    X209                 R359 1
    X210                 OBJ 0
    X210                 R96 -1
    X210                 R106 1
    X210                 R360 1
    X211                 OBJ 0
    X211                 R96 -1
    X211                 R108 1
    X211                 R361 1
    X212                 OBJ 0
    X212                 R106 1
    X212                 R108 -1
    X212                 R362 1
    X213                 OBJ 0
    X213                 R106 -1
    X213                 R109 1
    X213                 R363 1
    X214                 OBJ 0
    X214                 R0 1
    X214                 R109 -1
    X214                 R364 1
    X215                 OBJ 0
    X215                 R0 1
    X215                 R106 -1
    X215                 R365 1
    X216                 OBJ 0
    X216                 R0 1
    X216                 R106 -1
    X216                 R366 1
    X217                 OBJ 0
    X217                 R96 -1
    X217                 R110 1
    X217                 R367 1
    X218                 OBJ 0
    X218                 R96 -1
    X218                 R110 1
    X218                 R368 1
    X219                 OBJ 0
    X219                 R96 -1
    X219                 R111 1
    X219                 R369 1
    X220                 OBJ 0
    X220                 R110 1
    X220                 R111 -1
    X220                 R370 1
    X221                 OBJ 0
    X221                 R110 -1
    X221                 R112 1
    X221                 R371 1
    X222                 OBJ 0
    X222                 R0 1
    X222                 R112 -1
    X222                 R372 1
    X223                 OBJ 0
    X223                 R0 1
    X223                 R110 -1
    X223                 R373 1
    X224                 OBJ 0
    X224                 R110 -1
    X224                 R113 1
    X224                 R374 1
    X225                 OBJ 0
    X225                 R0 1
    X225                 R113 -1
    X225                 R375 1
    X226                 OBJ 0
    X226                 R2 -1
    X226                 R115 1
    X226                 R376 1
    X227                 OBJ 0
    X227                 R2 -1
    X227                 R116 1
    X227                 R377 1
    X228                 OBJ 0
    X228                 R115 1
    X228                 R116 -1
    X228                 R378 1
    X229                 OBJ 0
    X229                 R2 -1
    X229                 R115 1
    X229                 R379 1
    X230                 OBJ 0
    X230                 R2 -1
    X230                 R117 1
    X230                 R380 1
    X231                 OBJ 0
    X231                 R2 -1
    X231                 R117 1
    X231                 R381 1
    X232                 OBJ 0
    X232                 R117 -1
    X232                 R118 1
    X232                 R382 1
    X233                 OBJ 0
    X233                 R115 1
    X233                 R118 -1
    X233                 R383 1
    X234                 OBJ 0
    X234                 R115 -1
    X234                 R121 1
    X234                 R384 1
    X235                 OBJ 0
    X235                 R120 1
    X235                 R121 -1
    X235                 R385 1
    X236                 OBJ 0
    X236                 R115 -1
    X236                 R120 1
    X236                 R386 1
    X237                 OBJ 0
    X237                 R119 1
    X237                 R120 -1
    X237                 R387 1
    X238                 OBJ 0
    X238                 R119 1
    X238                 R120 -1
    X238                 R388 1
    X239                 OBJ 0
    X239                 R119 1
    X239                 R120 -1
    X239                 R389 1
    X240                 OBJ 0
    X240                 R119 -1
    X240                 R122 1
    X240                 R390 1
    X241                 OBJ 0
    X241                 R114 1
    X241                 R122 -1
    X241                 R391 1
    X242                 OBJ 0
    X242                 R114 1
    X242                 R119 -1
    X242                 R392 1
    X243                 OBJ 0
    X243                 R114 1
    X243                 R119 -1
    X243                 R393 1
    X244                 OBJ 0
    X244                 R114 -1
    X244                 R124 1
    X244                 R394 1
    X245                 OBJ 0
    X245                 R123 1
    X245                 R124 -1
    X245                 R395 1
    X246                 OBJ 0
    X246                 R114 -1
    X246                 R123 1
    X246                 R396 1
    X247                 OBJ 0
    X247                 R114 -1
    X247                 R125 1
    X247                 R397 1
    X248                 OBJ 0
    X248                 R123 1
    X248                 R125 -1
    X248                 R398 1
    X249                 OBJ 0
    X249                 R0 1
    X249                 R123 -1
    X249                 R399 1
    X250                 OBJ 0
    X250                 R0 1
    X250                 R123 -1
    X250                 R400 1
    X251                 OBJ 0
    X251                 R123 -1
    X251                 R126 1
    X251                 R401 1
    X252                 OBJ 0
    X252                 R0 1
    X252                 R126 -1
    X252                 R402 1
    X253                 OBJ 0
    X253                 R114 -1
    X253                 R128 1
    X253                 R403 1
    X254                 OBJ 0
    X254                 R127 1
    X254                 R128 -1
    X254                 R404 1
    X255                 OBJ 0
    X255                 R0 1
    X255                 R127 -1
    X255                 R405 1
    X256                 OBJ 0
    X256                 R127 -1
    X256                 R129 1
    X256                 R406 1
    X257                 OBJ 0
    X257                 R0 1
    X257                 R129 -1
    X257                 R407 1
    X258                 OBJ 0
    X258                 R114 -1
    X258                 R130 1
    X258                 R408 1
    X259                 OBJ 0
    X259                 R0 1
    X259                 R130 -1
    X259                 R409 1
    X260                 OBJ 0
    X260                 R0 1
    X260                 R114 -1
    X260                 R410 1
    X261                 OBJ 0
    X261                 R114 -1
    X261                 R131 1
    X261                 R411 1
    X262                 OBJ 0
    X262                 R0 1
    X262                 R131 -1
    X262                 R412 1
    X263                 OBJ 0
    X263                 R2 -1
    X263                 R133 1
    X263                 R413 1
    X264                 OBJ 0
    X264                 R2 -1
    X264                 R133 1
    X264                 R414 1
    X265                 OBJ 0
    X265                 R133 -1
    X265                 R134 1
    X265                 R415 1
    X266                 OBJ 0
    X266                 R132 1
    X266                 R134 -1
    X266                 R416 1
    X267                 OBJ 0
    X267                 R2 -1
    X267                 R135 1
    X267                 R417 1
    X268                 OBJ 0
    X268                 R2 -1
    X268                 R135 1
    X268                 R418 1
    X269                 OBJ 0
    X269                 R132 1
    X269                 R135 -1
    X269                 R419 1
    X270                 OBJ 0
    X270                 R135 -1
    X270                 R136 1
    X270                 R420 1
    X271                 OBJ 0
    X271                 R132 1
    X271                 R136 -1
    X271                 R421 1
    X272                 OBJ 0
    X272                 R2 -1
    X272                 R137 1
    X272                 R422 1
    X273                 OBJ 0
    X273                 R2 -1
    X273                 R137 1
    X273                 R423 1
    X274                 OBJ 0
    X274                 R137 -1
    X274                 R138 1
    X274                 R424 1
    X275                 OBJ 0
    X275                 R132 1
    X275                 R138 -1
    X275                 R425 1
    X276                 OBJ 0
    X276                 R132 1
    X276                 R137 -1
    X276                 R426 1
    X277                 OBJ 0
    X277                 R2 -1
    X277                 R139 1
    X277                 R427 1
    X278                 OBJ 0
    X278                 R2 -1
    X278                 R139 1
    X278                 R428 1
    X279                 OBJ 0
    X279                 R139 -1
    X279                 R140 1
    X279                 R429 1
    X280                 OBJ 0
    X280                 R132 1
    X280                 R140 -1
    X280                 R430 1
    X281                 OBJ 0
    X281                 R132 -1
    X281                 R142 1
    X281                 R431 1
    X282                 OBJ 0
    X282                 R132 -1
    X282                 R142 1
    X282                 R432 1
    X283                 OBJ 0
    X283                 R132 -1
    X283                 R143 1
    X283                 R433 1
    X284                 OBJ 0
    X284                 R142 1
    X284                 R143 -1
    X284                 R434 1
    X285                 OBJ 0
    X285                 R142 -1
    X285                 R144 1
    X285                 R435 1
    X286                 OBJ 0
    X286                 R141 1
    X286                 R144 -1
    X286                 R436 1
    X287                 OBJ 0
    X287                 R141 1
    X287                 R142 -1
    X287                 R437 1
    X288                 OBJ 0
    X288                 R142 -1
    X288                 R145 1
    X288                 R438 1
    X289                 OBJ 0
    X289                 R141 1
    X289                 R145 -1
    X289                 R439 1
    X290                 OBJ 0
    X290                 R141 -1
    X290                 R147 1
    X290                 R440 1
    X291                 OBJ 0
    X291                 R146 1
    X291                 R147 -1
    X291                 R441 1
    X292                 OBJ 0
    X292                 R141 -1
    X292                 R146 1
    X292                 R442 1
    X293                 OBJ 0
    X293                 R141 -1
    X293                 R146 1
    X293                 R443 1
    X294                 OBJ 0
    X294                 R146 -1
    X294                 R149 1
    X294                 R444 1
    X295                 OBJ 0
    X295                 R148 1
    X295                 R149 -1
    X295                 R445 1
    X296                 OBJ 0
    X296                 R146 -1
    X296                 R148 1
    X296                 R446 1
    X297                 OBJ 0
    X297                 R0 1
    X297                 R148 -1
    X297                 R447 1
    X298                 OBJ 0
    X298                 R0 1
    X298                 R148 -1
    X298                 R448 1
    X299                 OBJ 0
    X299                 R0 1
    X299                 R148 -1
    X299                 R449 1
    X300                 OBJ 1
    X300                 R150 -3049
    X301                 OBJ 1
    X301                 R151 -3049
    X302                 OBJ 1
    X302                 R152 -3049
    X303                 OBJ 1
    X303                 R153 -3049
    X304                 OBJ 1
    X304                 R154 -3049
    X305                 OBJ 1
    X305                 R155 -3049
    X306                 OBJ 1
    X306                 R156 -3049
    X307                 OBJ 1
    X307                 R157 -3049
    X308                 OBJ 1
    X308                 R158 -3049
    X309                 OBJ 1
    X309                 R159 -3049
    X310                 OBJ 1
    X310                 R160 -3049
    X311                 OBJ 1
    X311                 R161 -3049
    X312                 OBJ 1
    X312                 R162 -3049
    X313                 OBJ 1
    X313                 R163 -3049
    X314                 OBJ 1
    X314                 R164 -3049
    X315                 OBJ 1
    X315                 R165 -3049
    X316                 OBJ 1
    X316                 R166 -3049
    X317                 OBJ 1
    X317                 R167 -3049
    X318                 OBJ 1
    X318                 R168 -3049
    X319                 OBJ 1
    X319                 R169 -3049
    X320                 OBJ 1
    X320                 R170 -3049
    X321                 OBJ 1
    X321                 R171 -3049
    X322                 OBJ 1
    X322                 R172 -3049
    X323                 OBJ 1
    X323                 R173 -3049
    X324                 OBJ 1
    X324                 R174 -3049
    X325                 OBJ 1
    X325                 R175 -3049
    X326                 OBJ 1
    X326                 R176 -3049
    X327                 OBJ 1
    X327                 R177 -3049
    X328                 OBJ 1
    X328                 R178 -3049
    X329                 OBJ 1
    X329                 R179 -3049
    X330                 OBJ 1
    X330                 R180 -3049
    X331                 OBJ 1
    X331                 R181 -3049
    X332                 OBJ 1
    X332                 R182 -3049
    X333                 OBJ 1
    X333                 R183 -3049
    X334                 OBJ 1
    X334                 R184 -3049
    X335                 OBJ 1
    X335                 R185 -3049
    X336                 OBJ 1
    X336                 R186 -3049
    X337                 OBJ 1
    X337                 R187 -3049
    X338                 OBJ 1
    X338                 R188 -3049
    X339                 OBJ 1
    X339                 R189 -3049
    X340                 OBJ 1
    X340                 R190 -3049
    X341                 OBJ 1
    X341                 R191 -3049
    X342                 OBJ 1
    X342                 R192 -3049
    X343                 OBJ 1
    X343                 R193 -3049
    X344                 OBJ 1
    X344                 R194 -3049
    X345                 OBJ 1
    X345                 R195 -3049
    X346                 OBJ 1
    X346                 R196 -3049
    X347                 OBJ 1
    X347                 R197 -3049
    X348                 OBJ 1
    X348                 R198 -3049
    X349                 OBJ 1
    X349                 R199 -3049
    X350                 OBJ 1
    X350                 R200 -3049
    X351                 OBJ 1
    X351                 R201 -3049
    X352                 OBJ 1
    X352                 R202 -3049
    X353                 OBJ 1
    X353                 R203 -3049
    X354                 OBJ 1
    X354                 R204 -3049
    X355                 OBJ 1
    X355                 R205 -3049
    X356                 OBJ 1
    X356                 R206 -3049
    X357                 OBJ 1
    X357                 R207 -3049
    X358                 OBJ 1
    X358                 R208 -3049
    X359                 OBJ 1
    X359                 R209 -3049
    X360                 OBJ 1
    X360                 R210 -3049
    X361                 OBJ 1
    X361                 R211 -3049
    X362                 OBJ 1
    X362                 R212 -3049
    X363                 OBJ 1
    X363                 R213 -3049
    X364                 OBJ 1
    X364                 R214 -3049
    X365                 OBJ 1
    X365                 R215 -3049
    X366                 OBJ 1
    X366                 R216 -3049
    X367                 OBJ 1
    X367                 R217 -3049
    X368                 OBJ 1
    X368                 R218 -3049
    X369                 OBJ 1
    X369                 R219 -3049
    X370                 OBJ 1
    X370                 R220 -3049
    X371                 OBJ 1
    X371                 R221 -3049
    X372                 OBJ 1
    X372                 R222 -3049
    X373                 OBJ 1
    X373                 R223 -3049
    X374                 OBJ 1
    X374                 R224 -3049
    X375                 OBJ 1
    X375                 R225 -3049
    X376                 OBJ 1
    X376                 R226 -3049
    X377                 OBJ 1
    X377                 R227 -3049
    X378                 OBJ 1
    X378                 R228 -3049
    X379                 OBJ 1
    X379                 R229 -3049
    X380                 OBJ 1
    X380                 R230 -3049
    X381                 OBJ 1
    X381                 R231 -3049
    X382                 OBJ 1
    X382                 R232 -3049
    X383                 OBJ 1
    X383                 R233 -3049
    X384                 OBJ 1
    X384                 R234 -3049
    X385                 OBJ 1
    X385                 R235 -3049
    X386                 OBJ 1
    X386                 R236 -3049
    X387                 OBJ 1
    X387                 R237 -3049
    X388                 OBJ 1
    X388                 R238 -3049
    X389                 OBJ 1
    X389                 R239 -3049
    X390                 OBJ 1
    X390                 R240 -3049
    X391                 OBJ 1
    X391                 R241 -3049
    X392                 OBJ 1
    X392                 R242 -3049
    X393                 OBJ 1
    X393                 R243 -3049
    X394                 OBJ 1
    X394                 R244 -3049
    X395                 OBJ 1
    X395                 R245 -3049
    X396                 OBJ 1
    X396                 R246 -3049
    X397                 OBJ 1
    X397                 R247 -3049
    X398                 OBJ 1
    X398                 R248 -3049
    X399                 OBJ 1
    X399                 R249 -3049
    X400                 OBJ 1
    X400                 R250 -3049
    X401                 OBJ 1
    X401                 R251 -3049
    X402                 OBJ 1
    X402                 R252 -3049
    X403                 OBJ 1
    X403                 R253 -3049
    X404                 OBJ 1
    X404                 R254 -3049
    X405                 OBJ 1
    X405                 R255 -3049
    X406                 OBJ 1
    X406                 R256 -3049
    X407                 OBJ 1
    X407                 R257 -3049
    X408                 OBJ 1
    X408                 R258 -3049
    X409                 OBJ 1
    X409                 R259 -3049
    X410                 OBJ 1
    X410                 R260 -3049
    X411                 OBJ 1
    X411                 R261 -3049
    X412                 OBJ 1
    X412                 R262 -3049
    X413                 OBJ 1
    X413                 R263 -3049
    X414                 OBJ 1
    X414                 R264 -3049
    X415                 OBJ 1
    X415                 R265 -3049
    X416                 OBJ 1
    X416                 R266 -3049
    X417                 OBJ 1
    X417                 R267 -3049
    X418                 OBJ 1
    X418                 R268 -3049
    X419                 OBJ 1
    X419                 R269 -3049
    X420                 OBJ 1
    X420                 R270 -3049
    X421                 OBJ 1
    X421                 R271 -3049
    X422                 OBJ 1
    X422                 R272 -3049
    X423                 OBJ 1
    X423                 R273 -3049
    X424                 OBJ 1
    X424                 R274 -3049
    X425                 OBJ 1
    X425                 R275 -3049
    X426                 OBJ 1
    X426                 R276 -3049
    X427                 OBJ 1
    X427                 R277 -3049
    X428                 OBJ 1
    X428                 R278 -3049
    X429                 OBJ 1
    X429                 R279 -3049
    X430                 OBJ 1
    X430                 R280 -3049
    X431                 OBJ 1
    X431                 R281 -3049
    X432                 OBJ 1
    X432                 R282 -3049
    X433                 OBJ 1
    X433                 R283 -3049
    X434                 OBJ 1
    X434                 R284 -3049
    X435                 OBJ 1
    X435                 R285 -3049
    X436                 OBJ 1
    X436                 R286 -3049
    X437                 OBJ 1
    X437                 R287 -3049
    X438                 OBJ 1
    X438                 R288 -3049
    X439                 OBJ 1
    X439                 R289 -3049
    X440                 OBJ 1
    X440                 R290 -3049
    X441                 OBJ 1
    X441                 R291 -3049
    X442                 OBJ 1
    X442                 R292 -3049
    X443                 OBJ 1
    X443                 R293 -3049
    X444                 OBJ 1
    X444                 R294 -3049
    X445                 OBJ 1
    X445                 R295 -3049
    X446                 OBJ 1
    X446                 R296 -3049
    X447                 OBJ 1
    X447                 R297 -3049
    X448                 OBJ 1
    X448                 R298 -3049
    X449                 OBJ 1
    X449                 R299 -3049
    X450                 OBJ 1
    X450                 R300 -3049
    X451                 OBJ 1
    X451                 R301 -3049
    X452                 OBJ 1
    X452                 R302 -3049
    X453                 OBJ 1
    X453                 R303 -3049
    X454                 OBJ 1
    X454                 R304 -3049
    X455                 OBJ 1
    X455                 R305 -3049
    X456                 OBJ 1
    X456                 R306 -3049
    X457                 OBJ 1
    X457                 R307 -3049
    X458                 OBJ 1
    X458                 R308 -3049
    X459                 OBJ 1
    X459                 R309 -3049
    X460                 OBJ 1
    X460                 R310 -3049
    X461                 OBJ 1
    X461                 R311 -3049
    X462                 OBJ 1
    X462                 R312 -3049
    X463                 OBJ 1
    X463                 R313 -3049
    X464                 OBJ 1
    X464                 R314 -3049
    X465                 OBJ 1
    X465                 R315 -3049
    X466                 OBJ 1
    X466                 R316 -3049
    X467                 OBJ 1
    X467                 R317 -3049
    X468                 OBJ 1
    X468                 R318 -3049
    X469                 OBJ 1
    X469                 R319 -3049
    X470                 OBJ 1
    X470                 R320 -3049
    X471                 OBJ 1
    X471                 R321 -3049
    X472                 OBJ 1
    X472                 R322 -3049
    X473                 OBJ 1
    X473                 R323 -3049
    X474                 OBJ 1
    X474                 R324 -3049
    X475                 OBJ 1
    X475                 R325 -3049
    X476                 OBJ 1
    X476                 R326 -3049
    X477                 OBJ 1
    X477                 R327 -3049
    X478                 OBJ 1
    X478                 R328 -3049
    X479                 OBJ 1
    X479                 R329 -3049
    X480                 OBJ 1
    X480                 R330 -3049
    X481                 OBJ 1
    X481                 R331 -3049
    X482                 OBJ 1
    X482                 R332 -3049
    X483                 OBJ 1
    X483                 R333 -3049
    X484                 OBJ 1
    X484                 R334 -3049
    X485                 OBJ 1
    X485                 R335 -3049
    X486                 OBJ 1
    X486                 R336 -3049
    X487                 OBJ 1
    X487                 R337 -3049
    X488                 OBJ 1
    X488                 R338 -3049
    X489                 OBJ 1
    X489                 R339 -3049
    X490                 OBJ 1
    X490                 R340 -3049
    X491                 OBJ 1
    X491                 R341 -3049
    X492                 OBJ 1
    X492                 R342 -3049
    X493                 OBJ 1
    X493                 R343 -3049
    X494                 OBJ 1
    X494                 R344 -3049
    X495                 OBJ 1
    X495                 R345 -3049
    X496                 OBJ 1
    X496                 R346 -3049
    X497                 OBJ 1
    X497                 R347 -3049
    X498                 OBJ 1
    X498                 R348 -3049
    X499                 OBJ 1
    X499                 R349 -3049
    X500                 OBJ 1
    X500                 R350 -3049
    X501                 OBJ 1
    X501                 R351 -3049
    X502                 OBJ 1
    X502                 R352 -3049
    X503                 OBJ 1
    X503                 R353 -3049
    X504                 OBJ 1
    X504                 R354 -3049
    X505                 OBJ 1
    X505                 R355 -3049
    X506                 OBJ 1
    X506                 R356 -3049
    X507                 OBJ 1
    X507                 R357 -3049
    X508                 OBJ 1
    X508                 R358 -3049
    X509                 OBJ 1
    X509                 R359 -3049
    X510                 OBJ 1
    X510                 R360 -3049
    X511                 OBJ 1
    X511                 R361 -3049
    X512                 OBJ 1
    X512                 R362 -3049
    X513                 OBJ 1
    X513                 R363 -3049
    X514                 OBJ 1
    X514                 R364 -3049
    X515                 OBJ 1
    X515                 R365 -3049
    X516                 OBJ 1
    X516                 R366 -3049
    X517                 OBJ 1
    X517                 R367 -3049
    X518                 OBJ 1
    X518                 R368 -3049
    X519                 OBJ 1
    X519                 R369 -3049
    X520                 OBJ 1
    X520                 R370 -3049
    X521                 OBJ 1
    X521                 R371 -3049
    X522                 OBJ 1
    X522                 R372 -3049
    X523                 OBJ 1
    X523                 R373 -3049
    X524                 OBJ 1
    X524                 R374 -3049
    X525                 OBJ 1
    X525                 R375 -3049
    X526                 OBJ 1
    X526                 R376 -3049
    X527                 OBJ 1
    X527                 R377 -3049
    X528                 OBJ 1
    X528                 R378 -3049
    X529                 OBJ 1
    X529                 R379 -3049
    X530                 OBJ 1
    X530                 R380 -3049
    X531                 OBJ 1
    X531                 R381 -3049
    X532                 OBJ 1
    X532                 R382 -3049
    X533                 OBJ 1
    X533                 R383 -3049
    X534                 OBJ 1
    X534                 R384 -3049
    X535                 OBJ 1
    X535                 R385 -3049
    X536                 OBJ 1
    X536                 R386 -3049
    X537                 OBJ 1
    X537                 R387 -3049
    X538                 OBJ 1
    X538                 R388 -3049
    X539                 OBJ 1
    X539                 R389 -3049
    X540                 OBJ 1
    X540                 R390 -3049
    X541                 OBJ 1
    X541                 R391 -3049
    X542                 OBJ 1
    X542                 R392 -3049
    X543                 OBJ 1
    X543                 R393 -3049
    X544                 OBJ 1
    X544                 R394 -3049
    X545                 OBJ 1
    X545                 R395 -3049
    X546                 OBJ 1
    X546                 R396 -3049
    X547                 OBJ 1
    X547                 R397 -3049
    X548                 OBJ 1
    X548                 R398 -3049
    X549                 OBJ 1
    X549                 R399 -3049
    X550                 OBJ 1
    X550                 R400 -3049
    X551                 OBJ 1
    X551                 R401 -3049
    X552                 OBJ 1
    X552                 R402 -3049
    X553                 OBJ 1
    X553                 R403 -3049
    X554                 OBJ 1
    X554                 R404 -3049
    X555                 OBJ 1
    X555                 R405 -3049
    X556                 OBJ 1
    X556                 R406 -3049
    X557                 OBJ 1
    X557                 R407 -3049
    X558                 OBJ 1
    X558                 R408 -3049
    X559                 OBJ 1
    X559                 R409 -3049
    X560                 OBJ 1
    X560                 R410 -3049
    X561                 OBJ 1
    X561                 R411 -3049
    X562                 OBJ 1
    X562                 R412 -3049
    X563                 OBJ 1
    X563                 R413 -3049
    X564                 OBJ 1
    X564                 R414 -3049
    X565                 OBJ 1
    X565                 R415 -3049
    X566                 OBJ 1
    X566                 R416 -3049
    X567                 OBJ 1
    X567                 R417 -3049
    X568                 OBJ 1
    X568                 R418 -3049
    X569                 OBJ 1
    X569                 R419 -3049
    X570                 OBJ 1
    X570                 R420 -3049
    X571                 OBJ 1
    X571                 R421 -3049
    X572                 OBJ 1
    X572                 R422 -3049
    X573                 OBJ 1
    X573                 R423 -3049
    X574                 OBJ 1
    X574                 R424 -3049
    X575                 OBJ 1
    X575                 R425 -3049
    X576                 OBJ 1
    X576                 R426 -3049
    X577                 OBJ 1
    X577                 R427 -3049
    X578                 OBJ 1
    X578                 R428 -3049
    X579                 OBJ 1
    X579                 R429 -3049
    X580                 OBJ 1
    X580                 R430 -3049
    X581                 OBJ 1
    X581                 R431 -3049
    X582                 OBJ 1
    X582                 R432 -3049
    X583                 OBJ 1
    X583                 R433 -3049
    X584                 OBJ 1
    X584                 R434 -3049
    X585                 OBJ 1
    X585                 R435 -3049
    X586                 OBJ 1
    X586                 R436 -3049
    X587                 OBJ 1
    X587                 R437 -3049
    X588                 OBJ 1
    X588                 R438 -3049
    X589                 OBJ 1
    X589                 R439 -3049
    X590                 OBJ 1
    X590                 R440 -3049
    X591                 OBJ 1
    X591                 R441 -3049
    X592                 OBJ 1
    X592                 R442 -3049
    X593                 OBJ 1
    X593                 R443 -3049
    X594                 OBJ 1
    X594                 R444 -3049
    X595                 OBJ 1
    X595                 R445 -3049
    X596                 OBJ 1
    X596                 R446 -3049
    X597                 OBJ 1
    X597                 R447 -3049
    X598                 OBJ 1
    X598                 R448 -3049
    X599                 OBJ 1
    X599                 R449 -3049
RHS
    RHS                  OBJ -0
    RHS                  R0 1914
    RHS                  R1 -1348
    RHS                  R2 543
    RHS                  R3 138
    RHS                  R4 42
    RHS                  R5 33
    RHS                  R6 3
    RHS                  R7 -2
    RHS                  R8 1
    RHS                  R9 0
    RHS                  R10 0
    RHS                  R11 0
    RHS                  R12 0
    RHS                  R13 2
    RHS                  R14 -50
    RHS                  R15 0
    RHS                  R16 1
    RHS                  R17 0
    RHS                  R18 0
    RHS                  R19 0
    RHS                  R20 -20
    RHS                  R21 0
    RHS                  R22 50
    RHS                  R23 -6
    RHS                  R24 0
    RHS                  R25 0
    RHS                  R26 0
    RHS                  R27 0
    RHS                  R28 0
    RHS                  R29 -495
    RHS                  R30 1
    RHS                  R31 0
    RHS                  R32 1
    RHS                  R33 0
    RHS                  R34 0
    RHS                  R35 0
    RHS                  R36 0
    RHS                  R37 0
    RHS                  R38 1
    RHS                  R39 -82
    RHS                  R40 0
    RHS                  R41 0
    RHS                  R42 -1
    RHS                  R43 -1
    RHS                  R44 0
    RHS                  R45 0
    RHS                  R46 0
    RHS                  R47 0
    RHS                  R48 0
    RHS                  R49 0
    RHS                  R50 0
    RHS                  R51 0
    RHS                  R52 0
    RHS                  R53 0
    RHS                  R54 0
    RHS                  R55 0
    RHS                  R56 0
    RHS                  R57 -5
    RHS                  R58 0
    RHS                  R59 0
    RHS                  R60 0
    RHS                  R61 0
    RHS                  R62 0
    RHS                  R63 -1
    RHS                  R64 0
    RHS                  R65 0
    RHS                  R66 0
    RHS                  R67 0
    RHS                  R68 0
    RHS                  R69 0
    RHS                  R70 0
    RHS                  R71 0
    RHS                  R72 0
    RHS                  R73 86
    RHS                  R74 -464
    RHS                  R75 1
    RHS                  R76 2
    RHS                  R77 44
    RHS                  R78 2
    RHS                  R79 -121
    RHS                  R80 1
    RHS                  R81 0
    RHS                  R82 0
    RHS                  R83 0
    RHS                  R84 0
    RHS                  R85 0
    RHS                  R86 0
    RHS                  R87 11
    RHS                  R88 0
    RHS                  R89 0
    RHS                  R90 0
    RHS                  R91 0
    RHS                  R92 0
    RHS                  R93 0
    RHS                  R94 0
    RHS                  R95 0
    RHS                  R96 1
    RHS                  R97 0
    RHS                  R98 0
    RHS                  R99 0
    RHS                  R100 -8
    RHS                  R101 0
    RHS                  R102 0
    RHS                  R103 0
    RHS                  R104 0
    RHS                  R105 0
    RHS                  R106 -22
    RHS                  R107 1
    RHS                  R108 0
    RHS                  R109 1
    RHS                  R110 0
    RHS                  R111 1
    RHS                  R112 0
    RHS                  R113 0
    RHS                  R114 85
    RHS                  R115 0
    RHS                  R116 0
    RHS                  R117 0
    RHS                  R118 0
    RHS                  R119 -272
    RHS                  R120 0
    RHS                  R121 0
    RHS                  R122 25
    RHS                  R123 11
    RHS                  R124 2
    RHS                  R125 0
    RHS                  R126 0
    RHS                  R127 0
    RHS                  R128 0
    RHS                  R129 0
    RHS                  R130 0
    RHS                  R131 0
    RHS                  R132 33
    RHS                  R133 0
    RHS                  R134 0
    RHS                  R135 -1
    RHS                  R136 1
    RHS                  R137 0
    RHS                  R138 0
    RHS                  R139 -150
    RHS                  R140 7
    RHS                  R141 2
    RHS                  R142 2
    RHS                  R143 0
    RHS                  R144 0
    RHS                  R145 0
    RHS                  R146 0
    RHS                  R147 0
    RHS                  R148 0
    RHS                  R149 0
    RHS                  R150 0
    RHS                  R151 0
    RHS                  R152 0
    RHS                  R153 0
    RHS                  R154 0
    RHS                  R155 0
    RHS                  R156 0
    RHS                  R157 0
    RHS                  R158 0
    RHS                  R159 0
    RHS                  R160 0
    RHS                  R161 0
    RHS                  R162 0
    RHS                  R163 0
    RHS                  R164 0
    RHS                  R165 0
    RHS                  R166 0
    RHS                  R167 0
    RHS                  R168 0
    RHS                  R169 0
    RHS                  R170 0
    RHS                  R171 0
    RHS                  R172 0
    RHS                  R173 0
    RHS                  R174 0
    RHS                  R175 0
    RHS                  R176 0
    RHS                  R177 0
    RHS                  R178 0
    RHS                  R179 0
    RHS                  R180 0
    RHS                  R181 0
    RHS                  R182 0
    RHS                  R183 0
    RHS                  R184 0
    RHS                  R185 0
    RHS                  R186 0
    RHS                  R187 0
    RHS                  R188 0
    RHS                  R189 0
    RHS                  R190 0
    RHS                  R191 0
    RHS                  R192 0
    RHS                  R193 0
    RHS                  R194 0
    RHS                  R195 0
    RHS                  R196 0
    RHS                  R197 0
    RHS                  R198 0
    RHS                  R199 0
    RHS                  R200 0
    RHS                  R201 0
    RHS                  R202 0
    RHS                  R203 0
    RHS                  R204 0
    RHS                  R205 0
    RHS                  R206 0
    RHS                  R207 0
    RHS                  R208 0
    RHS                  R209 0
    RHS                  R210 0
    RHS                  R211 0
    RHS                  R212 0
    RHS                  R213 0
    RHS                  R214 0
    RHS                  R215 0
    RHS                  R216 0
    RHS                  R217 0
    RHS                  R218 0
    RHS                  R219 0
    RHS                  R220 0
    RHS                  R221 0
    RHS                  R222 0
    RHS                  R223 0
    RHS                  R224 0
    RHS                  R225 0
    RHS                  R226 0
    RHS                  R227 0
    RHS                  R228 0
    RHS                  R229 0
    RHS                  R230 0
    RHS                  R231 0
    RHS                  R232 0
    RHS                  R233 0
    RHS                  R234 0
    RHS                  R235 0
    RHS                  R236 0
    RHS                  R237 0
    RHS                  R238 0
    RHS                  R239 0
    RHS                  R240 0
    RHS                  R241 0
    RHS                  R242 0
    RHS                  R243 0
    RHS                  R244 0
    RHS                  R245 0
    RHS                  R246 0
    RHS                  R247 0
    RHS                  R248 0
    RHS                  R249 0
    RHS                  R250 0
    RHS                  R251 0
    RHS                  R252 0
    RHS                  R253 0
    RHS                  R254 0
    RHS                  R255 0
    RHS                  R256 0
    RHS                  R257 0
    RHS                  R258 0
    RHS                  R259 0
    RHS                  R260 0
    RHS                  R261 0
    RHS                  R262 0
    RHS                  R263 0
    RHS                  R264 0
    RHS                  R265 0
    RHS                  R266 0
    RHS                  R267 0
    RHS                  R268 0
    RHS                  R269 0
    RHS                  R270 0
    RHS                  R271 0
    RHS                  R272 0
    RHS                  R273 0
    RHS                  R274 0
    RHS                  R275 0
    RHS                  R276 0
    RHS                  R277 0
    RHS                  R278 0
    RHS                  R279 0
    RHS                  R280 0
    RHS                  R281 0
    RHS                  R282 0
    RHS                  R283 0
    RHS                  R284 0
    RHS                  R285 0
    RHS                  R286 0
    RHS                  R287 0
    RHS                  R288 0
    RHS                  R289 0
    RHS                  R290 0
    RHS                  R291 0
    RHS                  R292 0
    RHS                  R293 0
    RHS                  R294 0
    RHS                  R295 0
    RHS                  R296 0
    RHS                  R297 0
    RHS                  R298 0
    RHS                  R299 0
    RHS                  R300 0
    RHS                  R301 0
    RHS                  R302 0
    RHS                  R303 0
    RHS                  R304 0
    RHS                  R305 0
    RHS                  R306 0
    RHS                  R307 0
    RHS                  R308 0
    RHS                  R309 0
    RHS                  R310 0
    RHS                  R311 0
    RHS                  R312 0
    RHS                  R313 0
    RHS                  R314 0
    RHS                  R315 0
    RHS                  R316 0
    RHS                  R317 0
    RHS                  R318 0
    RHS                  R319 0
    RHS                  R320 0
    RHS                  R321 0
    RHS                  R322 0
    RHS                  R323 0
    RHS                  R324 0
    RHS                  R325 0
    RHS                  R326 0
    RHS                  R327 0
    RHS                  R328 0
    RHS                  R329 0
    RHS                  R330 0
    RHS                  R331 0
    RHS                  R332 0
    RHS                  R333 0
    RHS                  R334 0
    RHS                  R335 0
    RHS                  R336 0
    RHS                  R337 0
    RHS                  R338 0
    RHS                  R339 0
    RHS                  R340 0
    RHS                  R341 0
    RHS                  R342 0
    RHS                  R343 0
    RHS                  R344 0
    RHS                  R345 0
    RHS                  R346 0
    RHS                  R347 0
    RHS                  R348 0
    RHS                  R349 0
    RHS                  R350 0
    RHS                  R351 0
    RHS                  R352 0
    RHS                  R353 0
    RHS                  R354 0
    RHS                  R355 0
    RHS                  R356 0
    RHS                  R357 0
    RHS                  R358 0
    RHS                  R359 0
    RHS                  R360 0
    RHS                  R361 0
    RHS                  R362 0
    RHS                  R363 0
    RHS                  R364 0
    RHS                  R365 0
    RHS                  R366 0
    RHS                  R367 0
    RHS                  R368 0
    RHS                  R369 0
    RHS                  R370 0
    RHS                  R371 0
    RHS                  R372 0
    RHS                  R373 0
    RHS                  R374 0
    RHS                  R375 0
    RHS                  R376 0
    RHS                  R377 0
    RHS                  R378 0
    RHS                  R379 0
    RHS                  R380 0
    RHS                  R381 0
    RHS                  R382 0
    RHS                  R383 0
    RHS                  R384 0
    RHS                  R385 0
    RHS                  R386 0
    RHS                  R387 0
    RHS                  R388 0
    RHS                  R389 0
    RHS                  R390 0
    RHS                  R391 0
    RHS                  R392 0
    RHS                  R393 0
    RHS                  R394 0
    RHS                  R395 0
    RHS                  R396 0
    RHS                  R397 0
    RHS                  R398 0
    RHS                  R399 0
    RHS                  R400 0
    RHS                  R401 0
    RHS                  R402 0
    RHS                  R403 0
    RHS                  R404 0
    RHS                  R405 0
    RHS                  R406 0
    RHS                  R407 0
    RHS                  R408 0
    RHS                  R409 0
    RHS                  R410 0
    RHS                  R411 0
    RHS                  R412 0
    RHS                  R413 0
    RHS                  R414 0
    RHS                  R415 0
    RHS                  R416 0
    RHS                  R417 0
    RHS                  R418 0
    RHS                  R419 0
    RHS                  R420 0
    RHS                  R421 0
    RHS                  R422 0
    RHS                  R423 0
    RHS                  R424 0
    RHS                  R425 0
    RHS                  R426 0
    RHS                  R427 0
    RHS                  R428 0
    RHS                  R429 0
    RHS                  R430 0
    RHS                  R431 0
    RHS                  R432 0
    RHS                  R433 0
    RHS                  R434 0
    RHS                  R435 0
    RHS                  R436 0
    RHS                  R437 0
    RHS                  R438 0
    RHS                  R439 0
    RHS                  R440 0
    RHS                  R441 0
    RHS                  R442 0
    RHS                  R443 0
    RHS                  R444 0
    RHS                  R445 0
    RHS                  R446 0
    RHS                  R447 0
    RHS                  R448 0
    RHS                  R449 0
BOUNDS
 	FR BND X0
 	LO BND X0 0
 	UP BND X0 3049
 	FR BND X1
 	LO BND X1 0
 	UP BND X1 3049
 	FR BND X2
 	LO BND X2 0
 	UP BND X2 3049
 	FR BND X3
 	LO BND X3 0
 	UP BND X3 3049
 	FR BND X4
 	LO BND X4 0
 	UP BND X4 3049
 	FR BND X5
 	LO BND X5 0
 	UP BND X5 3049
 	FR BND X6
 	LO BND X6 0
 	UP BND X6 3049
 	FR BND X7
 	LO BND X7 0
 	UP BND X7 3049
 	FR BND X8
 	LO BND X8 0
 	UP BND X8 3049
 	FR BND X9
 	LO BND X9 0
 	UP BND X9 3049
 	FR BND X10
 	LO BND X10 0
 	UP BND X10 3049
 	FR BND X11
 	LO BND X11 0
 	UP BND X11 3049
 	FR BND X12
 	LO BND X12 0
 	UP BND X12 3049
 	FR BND X13
 	LO BND X13 0
 	UP BND X13 3049
 	FR BND X14
 	LO BND X14 0
 	UP BND X14 3049
 	FR BND X15
 	LO BND X15 0
 	UP BND X15 3049
 	FR BND X16
 	LO BND X16 0
 	UP BND X16 3049
 	FR BND X17
 	LO BND X17 0
 	UP BND X17 3049
 	FR BND X18
 	LO BND X18 0
 	UP BND X18 3049
 	FR BND X19
 	LO BND X19 0
 	UP BND X19 3049
 	FR BND X20
 	LO BND X20 0
 	UP BND X20 3049
 	FR BND X21
 	LO BND X21 0
 	UP BND X21 3049
 	FR BND X22
 	LO BND X22 0
 	UP BND X22 3049
 	FR BND X23
 	LO BND X23 0
 	UP BND X23 3049
 	FR BND X24
 	LO BND X24 0
 	UP BND X24 3049
 	FR BND X25
 	LO BND X25 0
 	UP BND X25 3049
 	FR BND X26
 	LO BND X26 0
 	UP BND X26 3049
 	FR BND X27
 	LO BND X27 0
 	UP BND X27 3049
 	FR BND X28
 	LO BND X28 0
 	UP BND X28 3049
 	FR BND X29
 	LO BND X29 0
 	UP BND X29 3049
 	FR BND X30
 	LO BND X30 0
 	UP BND X30 3049
 	FR BND X31
 	LO BND X31 0
 	UP BND X31 3049
 	FR BND X32
 	LO BND X32 0
 	UP BND X32 3049
 	FR BND X33
 	LO BND X33 0
 	UP BND X33 3049
 	FR BND X34
 	LO BND X34 0
 	UP BND X34 3049
 	FR BND X35
 	LO BND X35 0
 	UP BND X35 3049
 	FR BND X36
 	LO BND X36 0
 	UP BND X36 3049
 	FR BND X37
 	LO BND X37 0
 	UP BND X37 3049
 	FR BND X38
 	LO BND X38 0
 	UP BND X38 3049
 	FR BND X39
 	LO BND X39 0
 	UP BND X39 3049
 	FR BND X40
 	LO BND X40 0
 	UP BND X40 3049
 	FR BND X41
 	LO BND X41 0
 	UP BND X41 3049
 	FR BND X42
 	LO BND X42 0
 	UP BND X42 3049
 	FR BND X43
 	LO BND X43 0
 	UP BND X43 3049
 	FR BND X44
 	LO BND X44 0
 	UP BND X44 3049
 	FR BND X45
 	LO BND X45 0
 	UP BND X45 3049
 	FR BND X46
 	LO BND X46 0
 	UP BND X46 3049
 	FR BND X47
 	LO BND X47 0
 	UP BND X47 3049
 	FR BND X48
 	LO BND X48 0
 	UP BND X48 3049
 	FR BND X49
 	LO BND X49 0
 	UP BND X49 3049
 	FR BND X50
 	LO BND X50 0
 	UP BND X50 3049
 	FR BND X51
 	LO BND X51 0
 	UP BND X51 3049
 	FR BND X52
 	LO BND X52 0
 	UP BND X52 3049
 	FR BND X53
 	LO BND X53 0
 	UP BND X53 3049
 	FR BND X54
 	LO BND X54 0
 	UP BND X54 3049
 	FR BND X55
 	LO BND X55 0
 	UP BND X55 3049
 	FR BND X56
 	LO BND X56 0
 	UP BND X56 3049
 	FR BND X57
 	LO BND X57 0
 	UP BND X57 3049
 	FR BND X58
 	LO BND X58 0
 	UP BND X58 3049
 	FR BND X59
 	LO BND X59 0
 	UP BND X59 3049
 	FR BND X60
 	LO BND X60 0
 	UP BND X60 3049
 	FR BND X61
 	LO BND X61 0
 	UP BND X61 3049
 	FR BND X62
 	LO BND X62 0
 	UP BND X62 3049
 	FR BND X63
 	LO BND X63 0
 	UP BND X63 3049
 	FR BND X64
 	LO BND X64 0
 	UP BND X64 3049
 	FR BND X65
 	LO BND X65 0
 	UP BND X65 3049
 	FR BND X66
 	LO BND X66 0
 	UP BND X66 3049
 	FR BND X67
 	LO BND X67 0
 	UP BND X67 3049
 	FR BND X68
 	LO BND X68 0
 	UP BND X68 3049
 	FR BND X69
 	LO BND X69 0
 	UP BND X69 3049
 	FR BND X70
 	LO BND X70 0
 	UP BND X70 3049
 	FR BND X71
 	LO BND X71 0
 	UP BND X71 3049
 	FR BND X72
 	LO BND X72 0
 	UP BND X72 3049
 	FR BND X73
 	LO BND X73 0
 	UP BND X73 3049
 	FR BND X74
 	LO BND X74 0
 	UP BND X74 3049
 	FR BND X75
 	LO BND X75 0
 	UP BND X75 3049
 	FR BND X76
 	LO BND X76 0
 	UP BND X76 3049
 	FR BND X77
 	LO BND X77 0
 	UP BND X77 3049
 	FR BND X78
 	LO BND X78 0
 	UP BND X78 3049
 	FR BND X79
 	LO BND X79 0
 	UP BND X79 3049
 	FR BND X80
 	LO BND X80 0
 	UP BND X80 3049
 	FR BND X81
 	LO BND X81 0
 	UP BND X81 3049
 	FR BND X82
 	LO BND X82 0
 	UP BND X82 3049
 	FR BND X83
 	LO BND X83 0
 	UP BND X83 3049
 	FR BND X84
 	LO BND X84 0
 	UP BND X84 3049
 	FR BND X85
 	LO BND X85 0
 	UP BND X85 3049
 	FR BND X86
 	LO BND X86 0
 	UP BND X86 3049
 	FR BND X87
 	LO BND X87 0
 	UP BND X87 3049
 	FR BND X88
 	LO BND X88 0
 	UP BND X88 3049
 	FR BND X89
 	LO BND X89 0
 	UP BND X89 3049
 	FR BND X90
 	LO BND X90 0
 	UP BND X90 3049
 	FR BND X91
 	LO BND X91 0
 	UP BND X91 3049
 	FR BND X92
 	LO BND X92 0
 	UP BND X92 3049
 	FR BND X93
 	LO BND X93 0
 	UP BND X93 3049
 	FR BND X94
 	LO BND X94 0
 	UP BND X94 3049
 	FR BND X95
 	LO BND X95 0
 	UP BND X95 3049
 	FR BND X96
 	LO BND X96 0
 	UP BND X96 3049
 	FR BND X97
 	LO BND X97 0
 	UP BND X97 3049
 	FR BND X98
 	LO BND X98 0
 	UP BND X98 3049
 	FR BND X99
 	LO BND X99 0
 	UP BND X99 3049
 	FR BND X100
 	LO BND X100 0
 	UP BND X100 3049
 	FR BND X101
 	LO BND X101 0
 	UP BND X101 3049
 	FR BND X102
 	LO BND X102 0
 	UP BND X102 3049
 	FR BND X103
 	LO BND X103 0
 	UP BND X103 3049
 	FR BND X104
 	LO BND X104 0
 	UP BND X104 3049
 	FR BND X105
 	LO BND X105 0
 	UP BND X105 3049
 	FR BND X106
 	LO BND X106 0
 	UP BND X106 3049
 	FR BND X107
 	LO BND X107 0
 	UP BND X107 3049
 	FR BND X108
 	LO BND X108 0
 	UP BND X108 3049
 	FR BND X109
 	LO BND X109 0
 	UP BND X109 3049
 	FR BND X110
 	LO BND X110 0
 	UP BND X110 3049
 	FR BND X111
 	LO BND X111 0
 	UP BND X111 3049
 	FR BND X112
 	LO BND X112 0
 	UP BND X112 3049
 	FR BND X113
 	LO BND X113 0
 	UP BND X113 3049
 	FR BND X114
 	LO BND X114 0
 	UP BND X114 3049
 	FR BND X115
 	LO BND X115 0
 	UP BND X115 3049
 	FR BND X116
 	LO BND X116 0
 	UP BND X116 3049
 	FR BND X117
 	LO BND X117 0
 	UP BND X117 3049
 	FR BND X118
 	LO BND X118 0
 	UP BND X118 3049
 	FR BND X119
 	LO BND X119 0
 	UP BND X119 3049
 	FR BND X120
 	LO BND X120 0
 	UP BND X120 3049
 	FR BND X121
 	LO BND X121 0
 	UP BND X121 3049
 	FR BND X122
 	LO BND X122 0
 	UP BND X122 3049
 	FR BND X123
 	LO BND X123 0
 	UP BND X123 3049
 	FR BND X124
 	LO BND X124 0
 	UP BND X124 3049
 	FR BND X125
 	LO BND X125 0
 	UP BND X125 3049
 	FR BND X126
 	LO BND X126 0
 	UP BND X126 3049
 	FR BND X127
 	LO BND X127 0
 	UP BND X127 3049
 	FR BND X128
 	LO BND X128 0
 	UP BND X128 3049
 	FR BND X129
 	LO BND X129 0
 	UP BND X129 3049
 	FR BND X130
 	LO BND X130 0
 	UP BND X130 3049
 	FR BND X131
 	LO BND X131 0
 	UP BND X131 3049
 	FR BND X132
 	LO BND X132 0
 	UP BND X132 3049
 	FR BND X133
 	LO BND X133 0
 	UP BND X133 3049
 	FR BND X134
 	LO BND X134 0
 	UP BND X134 3049
 	FR BND X135
 	LO BND X135 0
 	UP BND X135 3049
 	FR BND X136
 	LO BND X136 0
 	UP BND X136 3049
 	FR BND X137
 	LO BND X137 0
 	UP BND X137 3049
 	FR BND X138
 	LO BND X138 0
 	UP BND X138 3049
 	FR BND X139
 	LO BND X139 0
 	UP BND X139 3049
 	FR BND X140
 	LO BND X140 0
 	UP BND X140 3049
 	FR BND X141
 	LO BND X141 0
 	UP BND X141 3049
 	FR BND X142
 	LO BND X142 0
 	UP BND X142 3049
 	FR BND X143
 	LO BND X143 0
 	UP BND X143 3049
 	FR BND X144
 	LO BND X144 0
 	UP BND X144 3049
 	FR BND X145
 	LO BND X145 0
 	UP BND X145 3049
 	FR BND X146
 	LO BND X146 0
 	UP BND X146 3049
 	FR BND X147
 	LO BND X147 0
 	UP BND X147 3049
 	FR BND X148
 	LO BND X148 0
 	UP BND X148 3049
 	FR BND X149
 	LO BND X149 0
 	UP BND X149 3049
 	FR BND X150
 	LO BND X150 0
 	UP BND X150 3049
 	FR BND X151
 	LO BND X151 0
 	UP BND X151 3049
 	FR BND X152
 	LO BND X152 0
 	UP BND X152 3049
 	FR BND X153
 	LO BND X153 0
 	UP BND X153 3049
 	FR BND X154
 	LO BND X154 0
 	UP BND X154 3049
 	FR BND X155
 	LO BND X155 0
 	UP BND X155 3049
 	FR BND X156
 	LO BND X156 0
 	UP BND X156 3049
 	FR BND X157
 	LO BND X157 0
 	UP BND X157 3049
 	FR BND X158
 	LO BND X158 0
 	UP BND X158 3049
 	FR BND X159
 	LO BND X159 0
 	UP BND X159 3049
 	FR BND X160
 	LO BND X160 0
 	UP BND X160 3049
 	FR BND X161
 	LO BND X161 0
 	UP BND X161 3049
 	FR BND X162
 	LO BND X162 0
 	UP BND X162 3049
 	FR BND X163
 	LO BND X163 0
 	UP BND X163 3049
 	FR BND X164
 	LO BND X164 0
 	UP BND X164 3049
 	FR BND X165
 	LO BND X165 0
 	UP BND X165 3049
 	FR BND X166
 	LO BND X166 0
 	UP BND X166 3049
 	FR BND X167
 	LO BND X167 0
 	UP BND X167 3049
 	FR BND X168
 	LO BND X168 0
 	UP BND X168 3049
 	FR BND X169
 	LO BND X169 0
 	UP BND X169 3049
 	FR BND X170
 	LO BND X170 0
 	UP BND X170 3049
 	FR BND X171
 	LO BND X171 0
 	UP BND X171 3049
 	FR BND X172
 	LO BND X172 0
 	UP BND X172 3049
 	FR BND X173
 	LO BND X173 0
 	UP BND X173 3049
 	FR BND X174
 	LO BND X174 0
 	UP BND X174 3049
 	FR BND X175
 	LO BND X175 0
 	UP BND X175 3049
 	FR BND X176
 	LO BND X176 0
 	UP BND X176 3049
 	FR BND X177
 	LO BND X177 0
 	UP BND X177 3049
 	FR BND X178
 	LO BND X178 0
 	UP BND X178 3049
 	FR BND X179
 	LO BND X179 0
 	UP BND X179 3049
 	FR BND X180
 	LO BND X180 0
 	UP BND X180 3049
 	FR BND X181
 	LO BND X181 0
 	UP BND X181 3049
 	FR BND X182
 	LO BND X182 0
 	UP BND X182 3049
 	FR BND X183
 	LO BND X183 0
 	UP BND X183 3049
 	FR BND X184
 	LO BND X184 0
 	UP BND X184 3049
 	FR BND X185
 	LO BND X185 0
 	UP BND X185 3049
 	FR BND X186
 	LO BND X186 0
 	UP BND X186 3049
 	FR BND X187
 	LO BND X187 0
 	UP BND X187 3049
 	FR BND X188
 	LO BND X188 0
 	UP BND X188 3049
 	FR BND X189
 	LO BND X189 0
 	UP BND X189 3049
 	FR BND X190
 	LO BND X190 0
 	UP BND X190 3049
 	FR BND X191
 	LO BND X191 0
 	UP BND X191 3049
 	FR BND X192
 	LO BND X192 0
 	UP BND X192 3049
 	FR BND X193
 	LO BND X193 0
 	UP BND X193 3049
 	FR BND X194
 	LO BND X194 0
 	UP BND X194 3049
 	FR BND X195
 	LO BND X195 0
 	UP BND X195 3049
 	FR BND X196
 	LO BND X196 0
 	UP BND X196 3049
 	FR BND X197
 	LO BND X197 0
 	UP BND X197 3049
 	FR BND X198
 	LO BND X198 0
 	UP BND X198 3049
 	FR BND X199
 	LO BND X199 0
 	UP BND X199 3049
 	FR BND X200
 	LO BND X200 0
 	UP BND X200 3049
 	FR BND X201
 	LO BND X201 0
 	UP BND X201 3049
 	FR BND X202
 	LO BND X202 0
 	UP BND X202 3049
 	FR BND X203
 	LO BND X203 0
 	UP BND X203 3049
 	FR BND X204
 	LO BND X204 0
 	UP BND X204 3049
 	FR BND X205
 	LO BND X205 0
 	UP BND X205 3049
 	FR BND X206
 	LO BND X206 0
 	UP BND X206 3049
 	FR BND X207
 	LO BND X207 0
 	UP BND X207 3049
 	FR BND X208
 	LO BND X208 0
 	UP BND X208 3049
 	FR BND X209
 	LO BND X209 0
 	UP BND X209 3049
 	FR BND X210
 	LO BND X210 0
 	UP BND X210 3049
 	FR BND X211
 	LO BND X211 0
 	UP BND X211 3049
 	FR BND X212
 	LO BND X212 0
 	UP BND X212 3049
 	FR BND X213
 	LO BND X213 0
 	UP BND X213 3049
 	FR BND X214
 	LO BND X214 0
 	UP BND X214 3049
 	FR BND X215
 	LO BND X215 0
 	UP BND X215 3049
 	FR BND X216
 	LO BND X216 0
 	UP BND X216 3049
 	FR BND X217
 	LO BND X217 0
 	UP BND X217 3049
 	FR BND X218
 	LO BND X218 0
 	UP BND X218 3049
 	FR BND X219
 	LO BND X219 0
 	UP BND X219 3049
 	FR BND X220
 	LO BND X220 0
 	UP BND X220 3049
 	FR BND X221
 	LO BND X221 0
 	UP BND X221 3049
 	FR BND X222
 	LO BND X222 0
 	UP BND X222 3049
 	FR BND X223
 	LO BND X223 0
 	UP BND X223 3049
 	FR BND X224
 	LO BND X224 0
 	UP BND X224 3049
 	FR BND X225
 	LO BND X225 0
 	UP BND X225 3049
 	FR BND X226
 	LO BND X226 0
 	UP BND X226 3049
 	FR BND X227
 	LO BND X227 0
 	UP BND X227 3049
 	FR BND X228
 	LO BND X228 0
 	UP BND X228 3049
 	FR BND X229
 	LO BND X229 0
 	UP BND X229 3049
 	FR BND X230
 	LO BND X230 0
 	UP BND X230 3049
 	FR BND X231
 	LO BND X231 0
 	UP BND X231 3049
 	FR BND X232
 	LO BND X232 0
 	UP BND X232 3049
 	FR BND X233
 	LO BND X233 0
 	UP BND X233 3049
 	FR BND X234
 	LO BND X234 0
 	UP BND X234 3049
 	FR BND X235
 	LO BND X235 0
 	UP BND X235 3049
 	FR BND X236
 	LO BND X236 0
 	UP BND X236 3049
 	FR BND X237
 	LO BND X237 0
 	UP BND X237 3049
 	FR BND X238
 	LO BND X238 0
 	UP BND X238 3049
 	FR BND X239
 	LO BND X239 0
 	UP BND X239 3049
 	FR BND X240
 	LO BND X240 0
 	UP BND X240 3049
 	FR BND X241
 	LO BND X241 0
 	UP BND X241 3049
 	FR BND X242
 	LO BND X242 0
 	UP BND X242 3049
 	FR BND X243
 	LO BND X243 0
 	UP BND X243 3049
 	FR BND X244
 	LO BND X244 0
 	UP BND X244 3049
 	FR BND X245
 	LO BND X245 0
 	UP BND X245 3049
 	FR BND X246
 	LO BND X246 0
 	UP BND X246 3049
 	FR BND X247
 	LO BND X247 0
 	UP BND X247 3049
 	FR BND X248
 	LO BND X248 0
 	UP BND X248 3049
 	FR BND X249
 	LO BND X249 0
 	UP BND X249 3049
 	FR BND X250
 	LO BND X250 0
 	UP BND X250 3049
 	FR BND X251
 	LO BND X251 0
 	UP BND X251 3049
 	FR BND X252
 	LO BND X252 0
 	UP BND X252 3049
 	FR BND X253
 	LO BND X253 0
 	UP BND X253 3049
 	FR BND X254
 	LO BND X254 0
 	UP BND X254 3049
 	FR BND X255
 	LO BND X255 0
 	UP BND X255 3049
 	FR BND X256
 	LO BND X256 0
 	UP BND X256 3049
 	FR BND X257
 	LO BND X257 0
 	UP BND X257 3049
 	FR BND X258
 	LO BND X258 0
 	UP BND X258 3049
 	FR BND X259
 	LO BND X259 0
 	UP BND X259 3049
 	FR BND X260
 	LO BND X260 0
 	UP BND X260 3049
 	FR BND X261
 	LO BND X261 0
 	UP BND X261 3049
 	FR BND X262
 	LO BND X262 0
 	UP BND X262 3049
 	FR BND X263
 	LO BND X263 0
 	UP BND X263 3049
 	FR BND X264
 	LO BND X264 0
 	UP BND X264 3049
 	FR BND X265
 	LO BND X265 0
 	UP BND X265 3049
 	FR BND X266
 	LO BND X266 0
 	UP BND X266 3049
 	FR BND X267
 	LO BND X267 0
 	UP BND X267 3049
 	FR BND X268
 	LO BND X268 0
 	UP BND X268 3049
 	FR BND X269
 	LO BND X269 0
 	UP BND X269 3049
 	FR BND X270
 	LO BND X270 0
 	UP BND X270 3049
 	FR BND X271
 	LO BND X271 0
 	UP BND X271 3049
 	FR BND X272
 	LO BND X272 0
 	UP BND X272 3049
 	FR BND X273
 	LO BND X273 0
 	UP BND X273 3049
 	FR BND X274
 	LO BND X274 0
 	UP BND X274 3049
 	FR BND X275
 	LO BND X275 0
 	UP BND X275 3049
 	FR BND X276
 	LO BND X276 0
 	UP BND X276 3049
 	FR BND X277
 	LO BND X277 0
 	UP BND X277 3049
 	FR BND X278
 	LO BND X278 0
 	UP BND X278 3049
 	FR BND X279
 	LO BND X279 0
 	UP BND X279 3049
 	FR BND X280
 	LO BND X280 0
 	UP BND X280 3049
 	FR BND X281
 	LO BND X281 0
 	UP BND X281 3049
 	FR BND X282
 	LO BND X282 0
 	UP BND X282 3049
 	FR BND X283
 	LO BND X283 0
 	UP BND X283 3049
 	FR BND X284
 	LO BND X284 0
 	UP BND X284 3049
 	FR BND X285
 	LO BND X285 0
 	UP BND X285 3049
 	FR BND X286
 	LO BND X286 0
 	UP BND X286 3049
 	FR BND X287
 	LO BND X287 0
 	UP BND X287 3049
 	FR BND X288
 	LO BND X288 0
 	UP BND X288 3049
 	FR BND X289
 	LO BND X289 0
 	UP BND X289 3049
 	FR BND X290
 	LO BND X290 0
 	UP BND X290 3049
 	FR BND X291
 	LO BND X291 0
 	UP BND X291 3049
 	FR BND X292
 	LO BND X292 0
 	UP BND X292 3049
 	FR BND X293
 	LO BND X293 0
 	UP BND X293 3049
 	FR BND X294
 	LO BND X294 0
 	UP BND X294 3049
 	FR BND X295
 	LO BND X295 0
 	UP BND X295 3049
 	FR BND X296
 	LO BND X296 0
 	UP BND X296 3049
 	FR BND X297
 	LO BND X297 0
 	UP BND X297 3049
 	FR BND X298
 	LO BND X298 0
 	UP BND X298 3049
 	FR BND X299
 	LO BND X299 0
 	UP BND X299 3049
 	FR BND X300
 	LO BND X300 0
 	UP BND X300 1
 	FR BND X301
 	LO BND X301 0
 	UP BND X301 1
 	FR BND X302
 	LO BND X302 0
 	UP BND X302 1
 	FR BND X303
 	LO BND X303 0
 	UP BND X303 1
 	FR BND X304
 	LO BND X304 0
 	UP BND X304 1
 	FR BND X305
 	LO BND X305 0
 	UP BND X305 1
 	FR BND X306
 	LO BND X306 0
 	UP BND X306 1
 	FR BND X307
 	LO BND X307 0
 	UP BND X307 1
 	FR BND X308
 	LO BND X308 0
 	UP BND X308 1
 	FR BND X309
 	LO BND X309 0
 	UP BND X309 1
 	FR BND X310
 	LO BND X310 0
 	UP BND X310 1
 	FR BND X311
 	LO BND X311 0
 	UP BND X311 1
 	FR BND X312
 	LO BND X312 0
 	UP BND X312 1
 	FR BND X313
 	LO BND X313 0
 	UP BND X313 1
 	FR BND X314
 	LO BND X314 0
 	UP BND X314 1
 	FR BND X315
 	LO BND X315 0
 	UP BND X315 1
 	FR BND X316
 	LO BND X316 0
 	UP BND X316 1
 	FR BND X317
 	LO BND X317 0
 	UP BND X317 1
 	FR BND X318
 	LO BND X318 0
 	UP BND X318 1
 	FR BND X319
 	LO BND X319 0
 	UP BND X319 1
 	FR BND X320
 	LO BND X320 0
 	UP BND X320 1
 	FR BND X321
 	LO BND X321 0
 	UP BND X321 1
 	FR BND X322
 	LO BND X322 0
 	UP BND X322 1
 	FR BND X323
 	LO BND X323 0
 	UP BND X323 1
 	FR BND X324
 	LO BND X324 0
 	UP BND X324 1
 	FR BND X325
 	LO BND X325 0
 	UP BND X325 1
 	FR BND X326
 	LO BND X326 0
 	UP BND X326 1
 	FR BND X327
 	LO BND X327 0
 	UP BND X327 1
 	FR BND X328
 	LO BND X328 0
 	UP BND X328 1
 	FR BND X329
 	LO BND X329 0
 	UP BND X329 1
 	FR BND X330
 	LO BND X330 0
 	UP BND X330 1
 	FR BND X331
 	LO BND X331 0
 	UP BND X331 1
 	FR BND X332
 	LO BND X332 0
 	UP BND X332 1
 	FR BND X333
 	LO BND X333 0
 	UP BND X333 1
 	FR BND X334
 	LO BND X334 0
 	UP BND X334 1
 	FR BND X335
 	LO BND X335 0
 	UP BND X335 1
 	FR BND X336
 	LO BND X336 0
 	UP BND X336 1
 	FR BND X337
 	LO BND X337 0
 	UP BND X337 1
 	FR BND X338
 	LO BND X338 0
 	UP BND X338 1
 	FR BND X339
 	LO BND X339 0
 	UP BND X339 1
 	FR BND X340
 	LO BND X340 0
 	UP BND X340 1
 	FR BND X341
 	LO BND X341 0
 	UP BND X341 1
 	FR BND X342
 	LO BND X342 0
 	UP BND X342 1
 	FR BND X343
 	LO BND X343 0
 	UP BND X343 1
 	FR BND X344
 	LO BND X344 0
 	UP BND X344 1
 	FR BND X345
 	LO BND X345 0
 	UP BND X345 1
 	FR BND X346
 	LO BND X346 0
 	UP BND X346 1
 	FR BND X347
 	LO BND X347 0
 	UP BND X347 1
 	FR BND X348
 	LO BND X348 0
 	UP BND X348 1
 	FR BND X349
 	LO BND X349 0
 	UP BND X349 1
 	FR BND X350
 	LO BND X350 0
 	UP BND X350 1
 	FR BND X351
 	LO BND X351 0
 	UP BND X351 1
 	FR BND X352
 	LO BND X352 0
 	UP BND X352 1
 	FR BND X353
 	LO BND X353 0
 	UP BND X353 1
 	FR BND X354
 	LO BND X354 0
 	UP BND X354 1
 	FR BND X355
 	LO BND X355 0
 	UP BND X355 1
 	FR BND X356
 	LO BND X356 0
 	UP BND X356 1
 	FR BND X357
 	LO BND X357 0
 	UP BND X357 1
 	FR BND X358
 	LO BND X358 0
 	UP BND X358 1
 	FR BND X359
 	LO BND X359 0
 	UP BND X359 1
 	FR BND X360
 	LO BND X360 0
 	UP BND X360 1
 	FR BND X361
 	LO BND X361 0
 	UP BND X361 1
 	FR BND X362
 	LO BND X362 0
 	UP BND X362 1
 	FR BND X363
 	LO BND X363 0
 	UP BND X363 1
 	FR BND X364
 	LO BND X364 0
 	UP BND X364 1
 	FR BND X365
 	LO BND X365 0
 	UP BND X365 1
 	FR BND X366
 	LO BND X366 0
 	UP BND X366 1
 	FR BND X367
 	LO BND X367 0
 	UP BND X367 1
 	FR BND X368
 	LO BND X368 0
 	UP BND X368 1
 	FR BND X369
 	LO BND X369 0
 	UP BND X369 1
 	FR BND X370
 	LO BND X370 0
 	UP BND X370 1
 	FR BND X371
 	LO BND X371 0
 	UP BND X371 1
 	FR BND X372
 	LO BND X372 0
 	UP BND X372 1
 	FR BND X373
 	LO BND X373 0
 	UP BND X373 1
 	FR BND X374
 	LO BND X374 0
 	UP BND X374 1
 	FR BND X375
 	LO BND X375 0
 	UP BND X375 1
 	FR BND X376
 	LO BND X376 0
 	UP BND X376 1
 	FR BND X377
 	LO BND X377 0
 	UP BND X377 1
 	FR BND X378
 	LO BND X378 0
 	UP BND X378 1
 	FR BND X379
 	LO BND X379 0
 	UP BND X379 1
 	FR BND X380
 	LO BND X380 0
 	UP BND X380 1
 	FR BND X381
 	LO BND X381 0
 	UP BND X381 1
 	FR BND X382
 	LO BND X382 0
 	UP BND X382 1
 	FR BND X383
 	LO BND X383 0
 	UP BND X383 1
 	FR BND X384
 	LO BND X384 0
 	UP BND X384 1
 	FR BND X385
 	LO BND X385 0
 	UP BND X385 1
 	FR BND X386
 	LO BND X386 0
 	UP BND X386 1
 	FR BND X387
 	LO BND X387 0
 	UP BND X387 1
 	FR BND X388
 	LO BND X388 0
 	UP BND X388 1
 	FR BND X389
 	LO BND X389 0
 	UP BND X389 1
 	FR BND X390
 	LO BND X390 0
 	UP BND X390 1
 	FR BND X391
 	LO BND X391 0
 	UP BND X391 1
 	FR BND X392
 	LO BND X392 0
 	UP BND X392 1
 	FR BND X393
 	LO BND X393 0
 	UP BND X393 1
 	FR BND X394
 	LO BND X394 0
 	UP BND X394 1
 	FR BND X395
 	LO BND X395 0
 	UP BND X395 1
 	FR BND X396
 	LO BND X396 0
 	UP BND X396 1
 	FR BND X397
 	LO BND X397 0
 	UP BND X397 1
 	FR BND X398
 	LO BND X398 0
 	UP BND X398 1
 	FR BND X399
 	LO BND X399 0
 	UP BND X399 1
 	FR BND X400
 	LO BND X400 0
 	UP BND X400 1
 	FR BND X401
 	LO BND X401 0
 	UP BND X401 1
 	FR BND X402
 	LO BND X402 0
 	UP BND X402 1
 	FR BND X403
 	LO BND X403 0
 	UP BND X403 1
 	FR BND X404
 	LO BND X404 0
 	UP BND X404 1
 	FR BND X405
 	LO BND X405 0
 	UP BND X405 1
 	FR BND X406
 	LO BND X406 0
 	UP BND X406 1
 	FR BND X407
 	LO BND X407 0
 	UP BND X407 1
 	FR BND X408
 	LO BND X408 0
 	UP BND X408 1
 	FR BND X409
 	LO BND X409 0
 	UP BND X409 1
 	FR BND X410
 	LO BND X410 0
 	UP BND X410 1
 	FR BND X411
 	LO BND X411 0
 	UP BND X411 1
 	FR BND X412
 	LO BND X412 0
 	UP BND X412 1
 	FR BND X413
 	LO BND X413 0
 	UP BND X413 1
 	FR BND X414
 	LO BND X414 0
 	UP BND X414 1
 	FR BND X415
 	LO BND X415 0
 	UP BND X415 1
 	FR BND X416
 	LO BND X416 0
 	UP BND X416 1
 	FR BND X417
 	LO BND X417 0
 	UP BND X417 1
 	FR BND X418
 	LO BND X418 0
 	UP BND X418 1
 	FR BND X419
 	LO BND X419 0
 	UP BND X419 1
 	FR BND X420
 	LO BND X420 0
 	UP BND X420 1
 	FR BND X421
 	LO BND X421 0
 	UP BND X421 1
 	FR BND X422
 	LO BND X422 0
 	UP BND X422 1
 	FR BND X423
 	LO BND X423 0
 	UP BND X423 1
 	FR BND X424
 	LO BND X424 0
 	UP BND X424 1
 	FR BND X425
 	LO BND X425 0
 	UP BND X425 1
 	FR BND X426
 	LO BND X426 0
 	UP BND X426 1
 	FR BND X427
 	LO BND X427 0
 	UP BND X427 1
 	FR BND X428
 	LO BND X428 0
 	UP BND X428 1
 	FR BND X429
 	LO BND X429 0
 	UP BND X429 1
 	FR BND X430
 	LO BND X430 0
 	UP BND X430 1
 	FR BND X431
 	LO BND X431 0
 	UP BND X431 1
 	FR BND X432
 	LO BND X432 0
 	UP BND X432 1
 	FR BND X433
 	LO BND X433 0
 	UP BND X433 1
 	FR BND X434
 	LO BND X434 0
 	UP BND X434 1
 	FR BND X435
 	LO BND X435 0
 	UP BND X435 1
 	FR BND X436
 	LO BND X436 0
 	UP BND X436 1
 	FR BND X437
 	LO BND X437 0
 	UP BND X437 1
 	FR BND X438
 	LO BND X438 0
 	UP BND X438 1
 	FR BND X439
 	LO BND X439 0
 	UP BND X439 1
 	FR BND X440
 	LO BND X440 0
 	UP BND X440 1
 	FR BND X441
 	LO BND X441 0
 	UP BND X441 1
 	FR BND X442
 	LO BND X442 0
 	UP BND X442 1
 	FR BND X443
 	LO BND X443 0
 	UP BND X443 1
 	FR BND X444
 	LO BND X444 0
 	UP BND X444 1
 	FR BND X445
 	LO BND X445 0
 	UP BND X445 1
 	FR BND X446
 	LO BND X446 0
 	UP BND X446 1
 	FR BND X447
 	LO BND X447 0
 	UP BND X447 1
 	FR BND X448
 	LO BND X448 0
 	UP BND X448 1
 	FR BND X449
 	LO BND X449 0
 	UP BND X449 1
 	FR BND X450
 	LO BND X450 0
 	UP BND X450 1
 	FR BND X451
 	LO BND X451 0
 	UP BND X451 1
 	FR BND X452
 	LO BND X452 0
 	UP BND X452 1
 	FR BND X453
 	LO BND X453 0
 	UP BND X453 1
 	FR BND X454
 	LO BND X454 0
 	UP BND X454 1
 	FR BND X455
 	LO BND X455 0
 	UP BND X455 1
 	FR BND X456
 	LO BND X456 0
 	UP BND X456 1
 	FR BND X457
 	LO BND X457 0
 	UP BND X457 1
 	FR BND X458
 	LO BND X458 0
 	UP BND X458 1
 	FR BND X459
 	LO BND X459 0
 	UP BND X459 1
 	FR BND X460
 	LO BND X460 0
 	UP BND X460 1
 	FR BND X461
 	LO BND X461 0
 	UP BND X461 1
 	FR BND X462
 	LO BND X462 0
 	UP BND X462 1
 	FR BND X463
 	LO BND X463 0
 	UP BND X463 1
 	FR BND X464
 	LO BND X464 0
 	UP BND X464 1
 	FR BND X465
 	LO BND X465 0
 	UP BND X465 1
 	FR BND X466
 	LO BND X466 0
 	UP BND X466 1
 	FR BND X467
 	LO BND X467 0
 	UP BND X467 1
 	FR BND X468
 	LO BND X468 0
 	UP BND X468 1
 	FR BND X469
 	LO BND X469 0
 	UP BND X469 1
 	FR BND X470
 	LO BND X470 0
 	UP BND X470 1
 	FR BND X471
 	LO BND X471 0
 	UP BND X471 1
 	FR BND X472
 	LO BND X472 0
 	UP BND X472 1
 	FR BND X473
 	LO BND X473 0
 	UP BND X473 1
 	FR BND X474
 	LO BND X474 0
 	UP BND X474 1
 	FR BND X475
 	LO BND X475 0
 	UP BND X475 1
 	FR BND X476
 	LO BND X476 0
 	UP BND X476 1
 	FR BND X477
 	LO BND X477 0
 	UP BND X477 1
 	FR BND X478
 	LO BND X478 0
 	UP BND X478 1
 	FR BND X479
 	LO BND X479 0
 	UP BND X479 1
 	FR BND X480
 	LO BND X480 0
 	UP BND X480 1
 	FR BND X481
 	LO BND X481 0
 	UP BND X481 1
 	FR BND X482
 	LO BND X482 0
 	UP BND X482 1
 	FR BND X483
 	LO BND X483 0
 	UP BND X483 1
 	FR BND X484
 	LO BND X484 0
 	UP BND X484 1
 	FR BND X485
 	LO BND X485 0
 	UP BND X485 1
 	FR BND X486
 	LO BND X486 0
 	UP BND X486 1
 	FR BND X487
 	LO BND X487 0
 	UP BND X487 1
 	FR BND X488
 	LO BND X488 0
 	UP BND X488 1
 	FR BND X489
 	LO BND X489 0
 	UP BND X489 1
 	FR BND X490
 	LO BND X490 0
 	UP BND X490 1
 	FR BND X491
 	LO BND X491 0
 	UP BND X491 1
 	FR BND X492
 	LO BND X492 0
 	UP BND X492 1
 	FR BND X493
 	LO BND X493 0
 	UP BND X493 1
 	FR BND X494
 	LO BND X494 0
 	UP BND X494 1
 	FR BND X495
 	LO BND X495 0
 	UP BND X495 1
 	FR BND X496
 	LO BND X496 0
 	UP BND X496 1
 	FR BND X497
 	LO BND X497 0
 	UP BND X497 1
 	FR BND X498
 	LO BND X498 0
 	UP BND X498 1
 	FR BND X499
 	LO BND X499 0
 	UP BND X499 1
 	FR BND X500
 	LO BND X500 0
 	UP BND X500 1
 	FR BND X501
 	LO BND X501 0
 	UP BND X501 1
 	FR BND X502
 	LO BND X502 0
 	UP BND X502 1
 	FR BND X503
 	LO BND X503 0
 	UP BND X503 1
 	FR BND X504
 	LO BND X504 0
 	UP BND X504 1
 	FR BND X505
 	LO BND X505 0
 	UP BND X505 1
 	FR BND X506
 	LO BND X506 0
 	UP BND X506 1
 	FR BND X507
 	LO BND X507 0
 	UP BND X507 1
 	FR BND X508
 	LO BND X508 0
 	UP BND X508 1
 	FR BND X509
 	LO BND X509 0
 	UP BND X509 1
 	FR BND X510
 	LO BND X510 0
 	UP BND X510 1
 	FR BND X511
 	LO BND X511 0
 	UP BND X511 1
 	FR BND X512
 	LO BND X512 0
 	UP BND X512 1
 	FR BND X513
 	LO BND X513 0
 	UP BND X513 1
 	FR BND X514
 	LO BND X514 0
 	UP BND X514 1
 	FR BND X515
 	LO BND X515 0
 	UP BND X515 1
 	FR BND X516
 	LO BND X516 0
 	UP BND X516 1
 	FR BND X517
 	LO BND X517 0
 	UP BND X517 1
 	FR BND X518
 	LO BND X518 0
 	UP BND X518 1
 	FR BND X519
 	LO BND X519 0
 	UP BND X519 1
 	FR BND X520
 	LO BND X520 0
 	UP BND X520 1
 	FR BND X521
 	LO BND X521 0
 	UP BND X521 1
 	FR BND X522
 	LO BND X522 0
 	UP BND X522 1
 	FR BND X523
 	LO BND X523 0
 	UP BND X523 1
 	FR BND X524
 	LO BND X524 0
 	UP BND X524 1
 	FR BND X525
 	LO BND X525 0
 	UP BND X525 1
 	FR BND X526
 	LO BND X526 0
 	UP BND X526 1
 	FR BND X527
 	LO BND X527 0
 	UP BND X527 1
 	FR BND X528
 	LO BND X528 0
 	UP BND X528 1
 	FR BND X529
 	LO BND X529 0
 	UP BND X529 1
 	FR BND X530
 	LO BND X530 0
 	UP BND X530 1
 	FR BND X531
 	LO BND X531 0
 	UP BND X531 1
 	FR BND X532
 	LO BND X532 0
 	UP BND X532 1
 	FR BND X533
 	LO BND X533 0
 	UP BND X533 1
 	FR BND X534
 	LO BND X534 0
 	UP BND X534 1
 	FR BND X535
 	LO BND X535 0
 	UP BND X535 1
 	FR BND X536
 	LO BND X536 0
 	UP BND X536 1
 	FR BND X537
 	LO BND X537 0
 	UP BND X537 1
 	FR BND X538
 	LO BND X538 0
 	UP BND X538 1
 	FR BND X539
 	LO BND X539 0
 	UP BND X539 1
 	FR BND X540
 	LO BND X540 0
 	UP BND X540 1
 	FR BND X541
 	LO BND X541 0
 	UP BND X541 1
 	FR BND X542
 	LO BND X542 0
 	UP BND X542 1
 	FR BND X543
 	LO BND X543 0
 	UP BND X543 1
 	FR BND X544
 	LO BND X544 0
 	UP BND X544 1
 	FR BND X545
 	LO BND X545 0
 	UP BND X545 1
 	FR BND X546
 	LO BND X546 0
 	UP BND X546 1
 	FR BND X547
 	LO BND X547 0
 	UP BND X547 1
 	FR BND X548
 	LO BND X548 0
 	UP BND X548 1
 	FR BND X549
 	LO BND X549 0
 	UP BND X549 1
 	FR BND X550
 	LO BND X550 0
 	UP BND X550 1
 	FR BND X551
 	LO BND X551 0
 	UP BND X551 1
 	FR BND X552
 	LO BND X552 0
 	UP BND X552 1
 	FR BND X553
 	LO BND X553 0
 	UP BND X553 1
 	FR BND X554
 	LO BND X554 0
 	UP BND X554 1
 	FR BND X555
 	LO BND X555 0
 	UP BND X555 1
 	FR BND X556
 	LO BND X556 0
 	UP BND X556 1
 	FR BND X557
 	LO BND X557 0
 	UP BND X557 1
 	FR BND X558
 	LO BND X558 0
 	UP BND X558 1
 	FR BND X559
 	LO BND X559 0
 	UP BND X559 1
 	FR BND X560
 	LO BND X560 0
 	UP BND X560 1
 	FR BND X561
 	LO BND X561 0
 	UP BND X561 1
 	FR BND X562
 	LO BND X562 0
 	UP BND X562 1
 	FR BND X563
 	LO BND X563 0
 	UP BND X563 1
 	FR BND X564
 	LO BND X564 0
 	UP BND X564 1
 	FR BND X565
 	LO BND X565 0
 	UP BND X565 1
 	FR BND X566
 	LO BND X566 0
 	UP BND X566 1
 	FR BND X567
 	LO BND X567 0
 	UP BND X567 1
 	FR BND X568
 	LO BND X568 0
 	UP BND X568 1
 	FR BND X569
 	LO BND X569 0
 	UP BND X569 1
 	FR BND X570
 	LO BND X570 0
 	UP BND X570 1
 	FR BND X571
 	LO BND X571 0
 	UP BND X571 1
 	FR BND X572
 	LO BND X572 0
 	UP BND X572 1
 	FR BND X573
 	LO BND X573 0
 	UP BND X573 1
 	FR BND X574
 	LO BND X574 0
 	UP BND X574 1
 	FR BND X575
 	LO BND X575 0
 	UP BND X575 1
 	FR BND X576
 	LO BND X576 0
 	UP BND X576 1
 	FR BND X577
 	LO BND X577 0
 	UP BND X577 1
 	FR BND X578
 	LO BND X578 0
 	UP BND X578 1
 	FR BND X579
 	LO BND X579 0
 	UP BND X579 1
 	FR BND X580
 	LO BND X580 0
 	UP BND X580 1
 	FR BND X581
 	LO BND X581 0
 	UP BND X581 1
 	FR BND X582
 	LO BND X582 0
 	UP BND X582 1
 	FR BND X583
 	LO BND X583 0
 	UP BND X583 1
 	FR BND X584
 	LO BND X584 0
 	UP BND X584 1
 	FR BND X585
 	LO BND X585 0
 	UP BND X585 1
 	FR BND X586
 	LO BND X586 0
 	UP BND X586 1
 	FR BND X587
 	LO BND X587 0
 	UP BND X587 1
 	FR BND X588
 	LO BND X588 0
 	UP BND X588 1
 	FR BND X589
 	LO BND X589 0
 	UP BND X589 1
 	FR BND X590
 	LO BND X590 0
 	UP BND X590 1
 	FR BND X591
 	LO BND X591 0
 	UP BND X591 1
 	FR BND X592
 	LO BND X592 0
 	UP BND X592 1
 	FR BND X593
 	LO BND X593 0
 	UP BND X593 1
 	FR BND X594
 	LO BND X594 0
 	UP BND X594 1
 	FR BND X595
 	LO BND X595 0
 	UP BND X595 1
 	FR BND X596
 	LO BND X596 0
 	UP BND X596 1
 	FR BND X597
 	LO BND X597 0
 	UP BND X597 1
 	FR BND X598
 	LO BND X598 0
 	UP BND X598 1
 	FR BND X599
 	LO BND X599 0
 	UP BND X599 1
ENDATA
