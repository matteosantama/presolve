* MIPLIB 2017 benchmark v2; LP relaxation (integrality removed).
* Source: https://miplib.zib.de/downloads/benchmark.zip ; retrieved 2026-09-21
* Instance: neos17 ; Gleixner et al. (2021), doi:10.1007/s12532-020-00194-3
* Bounds and coefficients preserved; rows/variables renamed; objective minimized.
* Original compressed SHA256: 1d50d129c3cbee9e409399314e5a77626811a46c301a2cf2fa2a2e64f65a8ba9
NAME neos17
ROWS
 N OBJ
 L R0
 L R1
 L R2
 L R3
 L R4
 L R5
 L R6
 L R7
 L R8
 L R9
 L R10
 L R11
 L R12
 L R13
 L R14
 L R15
 L R16
 L R17
 L R18
 L R19
 L R20
 G R21
 L R22
 L R23
 L R24
 L R25
 L R26
 G R27
 L R28
 L R29
 L R30
 L R31
 L R32
 L R33
 L R34
 L R35
 L R36
 L R37
 L R38
 L R39
 L R40
 L R41
 L R42
 G R43
 L R44
 L R45
 G R46
 L R47
 L R48
 L R49
 L R50
 L R51
 L R52
 L R53
 L R54
 L R55
 L R56
 G R57
 L R58
 L R59
 L R60
 L R61
 L R62
 L R63
 L R64
 L R65
 L R66
 L R67
 L R68
 L R69
 L R70
 L R71
 L R72
 L R73
 L R74
 G R75
 L R76
 L R77
 L R78
 G R79
 L R80
 L R81
 L R82
 L R83
 G R84
 L R85
 L R86
 L R87
 L R88
 L R89
 L R90
 L R91
 L R92
 L R93
 L R94
 L R95
 L R96
 L R97
 L R98
 G R99
 L R100
 L R101
 G R102
 L R103
 L R104
 L R105
 G R106
 L R107
 L R108
 L R109
 L R110
 L R111
 L R112
 L R113
 L R114
 L R115
 G R116
 L R117
 L R118
 L R119
 G R120
 G R121
 L R122
 L R123
 G R124
 L R125
 L R126
 L R127
 L R128
 L R129
 L R130
 L R131
 L R132
 L R133
 L R134
 L R135
 L R136
 L R137
 L R138
 L R139
 L R140
 L R141
 L R142
 L R143
 L R144
 L R145
 L R146
 L R147
 L R148
 L R149
 L R150
 L R151
 L R152
 L R153
 L R154
 L R155
 L R156
 L R157
 L R158
 L R159
 L R160
 L R161
 L R162
 L R163
 L R164
 L R165
 L R166
 L R167
 L R168
 L R169
 L R170
 L R171
 L R172
 L R173
 L R174
 L R175
 L R176
 L R177
 L R178
 L R179
 L R180
 L R181
 L R182
 G R183
 L R184
 L R185
 L R186
 L R187
 L R188
 L R189
 L R190
 L R191
 L R192
 L R193
 L R194
 L R195
 L R196
 L R197
 L R198
 L R199
 L R200
 L R201
 L R202
 L R203
 L R204
 L R205
 L R206
 L R207
 L R208
 L R209
 G R210
 L R211
 L R212
 L R213
 L R214
 L R215
 L R216
 L R217
 L R218
 L R219
 L R220
 L R221
 L R222
 L R223
 L R224
 L R225
 G R226
 G R227
 L R228
 L R229
 L R230
 L R231
 L R232
 L R233
 L R234
 L R235
 L R236
 L R237
 L R238
 G R239
 L R240
 L R241
 L R242
 L R243
 L R244
 L R245
 L R246
 L R247
 L R248
 L R249
 L R250
 L R251
 L R252
 G R253
 L R254
 L R255
 G R256
 L R257
 L R258
 L R259
 L R260
 L R261
 L R262
 L R263
 L R264
 L R265
 L R266
 L R267
 L R268
 L R269
 L R270
 L R271
 L R272
 L R273
 L R274
 L R275
 L R276
 L R277
 L R278
 L R279
 L R280
 L R281
 L R282
 L R283
 L R284
 L R285
 L R286
 L R287
 L R288
 L R289
 L R290
 L R291
 L R292
 L R293
 L R294
 L R295
 L R296
 L R297
 L R298
 L R299
 L R300
 L R301
 L R302
 L R303
 L R304
 L R305
 L R306
 L R307
 L R308
 L R309
 L R310
 L R311
 L R312
 L R313
 L R314
 L R315
 L R316
 L R317
 L R318
 L R319
 L R320
 L R321
 L R322
 L R323
 G R324
 L R325
 L R326
 L R327
 L R328
 L R329
 L R330
 L R331
 L R332
 L R333
 G R334
 G R335
 L R336
 L R337
 G R338
 L R339
 L R340
 L R341
 L R342
 L R343
 L R344
 L R345
 L R346
 L R347
 L R348
 L R349
 L R350
 L R351
 L R352
 L R353
 L R354
 L R355
 L R356
 L R357
 L R358
 L R359
 L R360
 L R361
 L R362
 L R363
 L R364
 L R365
 L R366
 L R367
 L R368
 L R369
 L R370
 L R371
 L R372
 L R373
 L R374
 L R375
 L R376
 L R377
 L R378
 L R379
 L R380
 L R381
 L R382
 L R383
 L R384
 L R385
 L R386
 L R387
 L R388
 L R389
 L R390
 L R391
 L R392
 L R393
 L R394
 G R395
 L R396
 L R397
 L R398
 L R399
 G R400
 L R401
 L R402
 G R403
 L R404
 L R405
 L R406
 L R407
 L R408
 L R409
 L R410
 L R411
 L R412
 L R413
 L R414
 L R415
 L R416
 L R417
 G R418
 L R419
 L R420
 L R421
 L R422
 L R423
 L R424
 L R425
 L R426
 L R427
 G R428
 L R429
 L R430
 L R431
 L R432
 L R433
 L R434
 L R435
 G R436
 L R437
 L R438
 L R439
 L R440
 L R441
 L R442
 L R443
 L R444
 L R445
 L R446
 L R447
 L R448
 L R449
 L R450
 L R451
 L R452
 L R453
 L R454
 L R455
 L R456
 L R457
 L R458
 L R459
 L R460
 L R461
 L R462
 L R463
 L R464
 L R465
 L R466
 L R467
 L R468
 L R469
 L R470
 L R471
 L R472
 L R473
 G R474
 L R475
 L R476
 L R477
 L R478
 L R479
 G R480
 L R481
 L R482
 L R483
 G R484
 E R485
COLUMNS
    X0                   OBJ 0
    X0                   R20 1
    X0                   R34 1
    X0                   R47 1
    X0                   R51 1
    X0                   R54 1
    X0                   R64 1
    X0                   R67 1
    X0                   R68 1
    X0                   R76 1
    X0                   R82 1
    X0                   R106 1
    X0                   R111 1
    X0                   R120 1
    X0                   R130 1
    X0                   R177 1
    X0                   R178 1
    X0                   R179 1
    X0                   R191 1
    X0                   R196 1
    X0                   R200 1
    X0                   R206 1
    X0                   R208 1
    X0                   R224 1
    X0                   R230 1
    X0                   R233 1
    X0                   R234 1
    X0                   R244 1
    X0                   R246 1
    X0                   R250 1
    X0                   R253 1
    X0                   R267 1
    X0                   R270 1
    X0                   R274 1
    X0                   R278 1
    X0                   R290 1
    X0                   R292 1
    X0                   R301 1
    X0                   R302 1
    X0                   R305 1
    X0                   R308 1
    X0                   R310 1
    X0                   R317 1
    X0                   R322 1
    X0                   R345 1
    X0                   R350 1
    X0                   R351 1
    X0                   R353 1
    X0                   R363 1
    X0                   R366 1
    X0                   R368 1
    X0                   R370 1
    X0                   R376 1
    X0                   R378 1
    X0                   R384 1
    X0                   R387 1
    X0                   R405 1
    X0                   R416 1
    X0                   R418 1
    X0                   R420 1
    X0                   R428 1
    X0                   R440 1
    X0                   R478 1
    X0                   R480 1
    X0                   R485 1
    X1                   OBJ 0
    X1                   R2 1
    X1                   R3 1
    X1                   R4 1
    X1                   R6 1
    X1                   R10 1
    X1                   R11 1
    X1                   R14 1
    X1                   R17 1
    X1                   R19 1
    X1                   R20 1
    X1                   R22 1
    X1                   R25 1
    X1                   R26 1
    X1                   R27 1
    X1                   R29 1
    X1                   R32 1
    X1                   R33 1
    X1                   R37 1
    X1                   R38 1
    X1                   R40 1
    X1                   R47 1
    X1                   R48 1
    X1                   R52 1
    X1                   R56 1
    X1                   R58 1
    X1                   R60 1
    X1                   R62 1
    X1                   R64 1
    X1                   R67 1
    X1                   R71 1
    X1                   R72 1
    X1                   R77 1
    X1                   R78 1
    X1                   R81 1
    X1                   R82 1
    X1                   R83 1
    X1                   R84 1
    X1                   R86 1
    X1                   R87 1
    X1                   R89 1
    X1                   R98 1
    X1                   R101 1
    X1                   R105 1
    X1                   R107 1
    X1                   R108 1
    X1                   R109 1
    X1                   R113 1
    X1                   R117 1
    X1                   R119 1
    X1                   R122 1
    X1                   R123 1
    X1                   R125 1
    X1                   R127 1
    X1                   R130 1
    X1                   R131 1
    X1                   R133 1
    X1                   R134 1
    X1                   R138 1
    X1                   R139 1
    X1                   R141 1
    X1                   R143 1
    X1                   R144 1
    X1                   R146 1
    X1                   R147 1
    X1                   R150 1
    X1                   R151 1
    X1                   R156 1
    X1                   R157 1
    X1                   R163 1
    X1                   R164 1
    X1                   R171 1
    X1                   R172 1
    X1                   R181 1
    X1                   R183 1
    X1                   R184 1
    X1                   R185 1
    X1                   R190 1
    X1                   R192 1
    X1                   R194 1
    X1                   R195 1
    X1                   R198 1
    X1                   R200 1
    X1                   R204 1
    X1                   R205 1
    X1                   R206 1
    X1                   R208 1
    X1                   R211 1
    X1                   R212 1
    X1                   R215 1
    X1                   R219 1
    X1                   R221 1
    X1                   R222 1
    X1                   R224 1
    X1                   R225 1
    X1                   R229 1
    X1                   R233 1
    X1                   R235 1
    X1                   R238 1
    X1                   R240 1
    X1                   R244 1
    X1                   R247 1
    X1                   R248 1
    X1                   R255 1
    X1                   R258 1
    X1                   R259 1
    X1                   R260 1
    X1                   R263 1
    X1                   R264 1
    X1                   R266 1
    X1                   R276 1
    X1                   R277 1
    X1                   R278 1
    X1                   R279 1
    X1                   R284 1
    X1                   R287 1
    X1                   R288 1
    X1                   R289 1
    X1                   R291 1
    X1                   R298 1
    X1                   R301 1
    X1                   R307 1
    X1                   R310 1
    X1                   R312 1
    X1                   R315 1
    X1                   R317 1
    X1                   R318 1
    X1                   R319 1
    X1                   R320 1
    X1                   R321 1
    X1                   R322 1
    X1                   R328 1
    X1                   R329 1
    X1                   R331 1
    X1                   R342 1
    X1                   R343 1
    X1                   R352 1
    X1                   R353 1
    X1                   R354 1
    X1                   R355 1
    X1                   R358 1
    X1                   R361 1
    X1                   R362 1
    X1                   R365 1
    X1                   R367 1
    X1                   R368 1
    X1                   R370 1
    X1                   R374 1
    X1                   R376 1
    X1                   R377 1
    X1                   R379 1
    X1                   R381 1
    X1                   R384 1
    X1                   R386 1
    X1                   R388 1
    X1                   R390 1
    X1                   R391 1
    X1                   R393 1
    X1                   R396 1
    X1                   R397 1
    X1                   R399 1
    X1                   R400 1
    X1                   R401 1
    X1                   R404 1
    X1                   R405 1
    X1                   R406 1
    X1                   R407 1
    X1                   R416 1
    X1                   R422 1
    X1                   R424 1
    X1                   R425 1
    X1                   R427 1
    X1                   R432 1
    X1                   R435 1
    X1                   R437 1
    X1                   R438 1
    X1                   R439 1
    X1                   R441 1
    X1                   R447 1
    X1                   R450 1
    X1                   R455 1
    X1                   R456 1
    X1                   R457 1
    X1                   R459 1
    X1                   R461 1
    X1                   R463 1
    X1                   R466 1
    X1                   R467 1
    X1                   R469 1
    X1                   R473 1
    X1                   R475 1
    X1                   R477 1
    X1                   R479 1
    X1                   R483 1
    X1                   R485 1
    X2                   OBJ 0
    X2                   R4 1
    X2                   R40 1
    X2                   R50 1
    X2                   R63 1
    X2                   R96 1
    X2                   R144 1
    X2                   R183 1
    X2                   R202 1
    X2                   R216 1
    X2                   R236 1
    X2                   R306 1
    X2                   R316 1
    X2                   R360 1
    X2                   R399 1
    X2                   R408 1
    X2                   R418 1
    X2                   R462 1
    X2                   R485 1
    X3                   OBJ 0
    X3                   R47 1
    X3                   R54 1
    X3                   R87 1
    X3                   R112 1
    X3                   R113 1
    X3                   R169 1
    X3                   R208 1
    X3                   R209 1
    X3                   R211 1
    X3                   R214 1
    X3                   R231 1
    X3                   R240 1
    X3                   R253 1
    X3                   R256 1
    X3                   R284 1
    X3                   R324 1
    X3                   R333 1
    X3                   R429 1
    X3                   R433 1
    X3                   R459 1
    X3                   R460 1
    X3                   R485 1
    X4                   OBJ 0
    X4                   R16 1
    X4                   R45 1
    X4                   R141 1
    X4                   R147 1
    X4                   R151 1
    X4                   R181 1
    X4                   R226 1
    X4                   R257 1
    X4                   R267 1
    X4                   R295 1
    X4                   R297 1
    X4                   R356 1
    X4                   R364 1
    X4                   R439 1
    X4                   R462 1
    X4                   R474 1
    X4                   R485 1
    X5                   OBJ 0
    X5                   R12 1
    X5                   R17 1
    X5                   R46 1
    X5                   R55 1
    X5                   R59 1
    X5                   R73 1
    X5                   R76 1
    X5                   R78 1
    X5                   R79 1
    X5                   R91 1
    X5                   R93 1
    X5                   R100 1
    X5                   R106 1
    X5                   R110 1
    X5                   R114 1
    X5                   R117 1
    X5                   R119 1
    X5                   R131 1
    X5                   R147 1
    X5                   R151 1
    X5                   R168 1
    X5                   R176 1
    X5                   R180 1
    X5                   R182 1
    X5                   R186 1
    X5                   R200 1
    X5                   R203 1
    X5                   R226 1
    X5                   R229 1
    X5                   R251 1
    X5                   R254 1
    X5                   R260 1
    X5                   R281 1
    X5                   R286 1
    X5                   R287 1
    X5                   R288 1
    X5                   R289 1
    X5                   R291 1
    X5                   R293 1
    X5                   R297 1
    X5                   R315 1
    X5                   R340 1
    X5                   R343 1
    X5                   R344 1
    X5                   R346 1
    X5                   R357 1
    X5                   R369 1
    X5                   R373 1
    X5                   R376 1
    X5                   R396 1
    X5                   R402 1
    X5                   R403 1
    X5                   R406 1
    X5                   R417 1
    X5                   R421 1
    X5                   R445 1
    X5                   R448 1
    X5                   R451 1
    X5                   R452 1
    X5                   R455 1
    X5                   R457 1
    X5                   R458 1
    X5                   R470 1
    X5                   R479 1
    X5                   R482 1
    X5                   R485 1
    X6                   OBJ 0
    X6                   R17 1
    X6                   R24 1
    X6                   R59 1
    X6                   R72 1
    X6                   R118 1
    X6                   R130 1
    X6                   R132 1
    X6                   R137 1
    X6                   R183 1
    X6                   R195 1
    X6                   R224 1
    X6                   R228 1
    X6                   R253 1
    X6                   R286 1
    X6                   R307 1
    X6                   R309 1
    X6                   R334 1
    X6                   R357 1
    X6                   R360 1
    X6                   R361 1
    X6                   R414 1
    X6                   R421 1
    X6                   R456 1
    X6                   R463 1
    X6                   R485 1
    X7                   OBJ 0
    X7                   R9 1
    X7                   R10 1
    X7                   R44 1
    X7                   R56 1
    X7                   R83 1
    X7                   R106 1
    X7                   R125 1
    X7                   R141 1
    X7                   R148 1
    X7                   R213 1
    X7                   R255 1
    X7                   R257 1
    X7                   R296 1
    X7                   R320 1
    X7                   R325 1
    X7                   R332 1
    X7                   R358 1
    X7                   R364 1
    X7                   R365 1
    X7                   R373 1
    X7                   R383 1
    X7                   R399 1
    X7                   R408 1
    X7                   R421 1
    X7                   R423 1
    X7                   R431 1
    X7                   R436 1
    X7                   R446 1
    X7                   R447 1
    X7                   R465 1
    X7                   R484 1
    X7                   R485 1
    X8                   OBJ 0
    X8                   R0 1
    X8                   R2 1
    X8                   R7 1
    X8                   R26 1
    X8                   R53 1
    X8                   R59 1
    X8                   R73 1
    X8                   R76 1
    X8                   R80 1
    X8                   R86 1
    X8                   R96 1
    X8                   R97 1
    X8                   R106 1
    X8                   R117 1
    X8                   R136 1
    X8                   R141 1
    X8                   R144 1
    X8                   R145 1
    X8                   R148 1
    X8                   R150 1
    X8                   R155 1
    X8                   R158 1
    X8                   R166 1
    X8                   R177 1
    X8                   R183 1
    X8                   R188 1
    X8                   R208 1
    X8                   R220 1
    X8                   R224 1
    X8                   R236 1
    X8                   R246 1
    X8                   R250 1
    X8                   R251 1
    X8                   R253 1
    X8                   R261 1
    X8                   R265 1
    X8                   R268 1
    X8                   R269 1
    X8                   R332 1
    X8                   R356 1
    X8                   R367 1
    X8                   R376 1
    X8                   R395 1
    X8                   R400 1
    X8                   R425 1
    X8                   R427 1
    X8                   R432 1
    X8                   R440 1
    X8                   R443 1
    X8                   R454 1
    X8                   R476 1
    X8                   R481 1
    X8                   R485 1
    X9                   OBJ 0
    X9                   R1 1
    X9                   R5 1
    X9                   R24 1
    X9                   R37 1
    X9                   R40 1
    X9                   R59 1
    X9                   R79 1
    X9                   R103 1
    X9                   R107 1
    X9                   R114 1
    X9                   R133 1
    X9                   R140 1
    X9                   R142 1
    X9                   R143 1
    X9                   R150 1
    X9                   R167 1
    X9                   R170 1
    X9                   R174 1
    X9                   R185 1
    X9                   R186 1
    X9                   R191 1
    X9                   R193 1
    X9                   R202 1
    X9                   R210 1
    X9                   R216 1
    X9                   R220 1
    X9                   R229 1
    X9                   R232 1
    X9                   R234 1
    X9                   R259 1
    X9                   R262 1
    X9                   R263 1
    X9                   R268 1
    X9                   R272 1
    X9                   R277 1
    X9                   R281 1
    X9                   R286 1
    X9                   R299 1
    X9                   R311 1
    X9                   R313 1
    X9                   R315 1
    X9                   R316 1
    X9                   R324 1
    X9                   R325 1
    X9                   R326 1
    X9                   R333 1
    X9                   R334 1
    X9                   R336 1
    X9                   R346 1
    X9                   R360 1
    X9                   R361 1
    X9                   R364 1
    X9                   R366 1
    X9                   R376 1
    X9                   R387 1
    X9                   R390 1
    X9                   R395 1
    X9                   R396 1
    X9                   R398 1
    X9                   R408 1
    X9                   R417 1
    X9                   R426 1
    X9                   R432 1
    X9                   R435 1
    X9                   R444 1
    X9                   R448 1
    X9                   R452 1
    X9                   R455 1
    X9                   R461 1
    X9                   R464 1
    X9                   R469 1
    X9                   R471 1
    X9                   R473 1
    X9                   R479 1
    X9                   R485 1
    X10                  OBJ 0
    X10                  R1 1
    X10                  R11 1
    X10                  R18 1
    X10                  R43 1
    X10                  R51 1
    X10                  R65 1
    X10                  R72 1
    X10                  R78 1
    X10                  R82 1
    X10                  R89 1
    X10                  R98 1
    X10                  R103 1
    X10                  R109 1
    X10                  R115 1
    X10                  R123 1
    X10                  R124 1
    X10                  R136 1
    X10                  R147 1
    X10                  R149 1
    X10                  R156 1
    X10                  R157 1
    X10                  R163 1
    X10                  R168 1
    X10                  R170 1
    X10                  R179 1
    X10                  R190 1
    X10                  R199 1
    X10                  R203 1
    X10                  R205 1
    X10                  R207 1
    X10                  R216 1
    X10                  R221 1
    X10                  R273 1
    X10                  R275 1
    X10                  R292 1
    X10                  R301 1
    X10                  R302 1
    X10                  R303 1
    X10                  R304 1
    X10                  R308 1
    X10                  R323 1
    X10                  R333 1
    X10                  R335 1
    X10                  R337 1
    X10                  R338 1
    X10                  R343 1
    X10                  R348 1
    X10                  R353 1
    X10                  R370 1
    X10                  R371 1
    X10                  R379 1
    X10                  R387 1
    X10                  R388 1
    X10                  R389 1
    X10                  R391 1
    X10                  R392 1
    X10                  R405 1
    X10                  R410 1
    X10                  R419 1
    X10                  R435 1
    X10                  R440 1
    X10                  R449 1
    X10                  R463 1
    X10                  R475 1
    X10                  R480 1
    X10                  R485 1
    X11                  OBJ 0
    X11                  R116 1
    X11                  R120 1
    X11                  R150 1
    X11                  R194 1
    X11                  R209 1
    X11                  R227 1
    X11                  R245 1
    X11                  R258 1
    X11                  R262 1
    X11                  R278 1
    X11                  R318 1
    X11                  R321 1
    X11                  R354 1
    X11                  R391 1
    X11                  R407 1
    X11                  R412 1
    X11                  R416 1
    X11                  R430 1
    X11                  R437 1
    X11                  R449 1
    X11                  R483 1
    X11                  R485 1
    X12                  OBJ 0
    X12                  R3 1
    X12                  R4 1
    X12                  R10 1
    X12                  R11 1
    X12                  R17 1
    X12                  R23 1
    X12                  R24 1
    X12                  R25 1
    X12                  R30 1
    X12                  R49 1
    X12                  R64 1
    X12                  R69 1
    X12                  R76 1
    X12                  R81 1
    X12                  R88 1
    X12                  R93 1
    X12                  R95 1
    X12                  R100 1
    X12                  R107 1
    X12                  R114 1
    X12                  R121 1
    X12                  R124 1
    X12                  R130 1
    X12                  R134 1
    X12                  R136 1
    X12                  R138 1
    X12                  R143 1
    X12                  R147 1
    X12                  R149 1
    X12                  R151 1
    X12                  R153 1
    X12                  R161 1
    X12                  R165 1
    X12                  R175 1
    X12                  R179 1
    X12                  R182 1
    X12                  R184 1
    X12                  R186 1
    X12                  R198 1
    X12                  R199 1
    X12                  R203 1
    X12                  R205 1
    X12                  R215 1
    X12                  R216 1
    X12                  R218 1
    X12                  R220 1
    X12                  R225 1
    X12                  R226 1
    X12                  R227 1
    X12                  R229 1
    X12                  R235 1
    X12                  R239 1
    X12                  R241 1
    X12                  R252 1
    X12                  R263 1
    X12                  R269 1
    X12                  R273 1
    X12                  R279 1
    X12                  R280 1
    X12                  R284 1
    X12                  R285 1
    X12                  R294 1
    X12                  R300 1
    X12                  R304 1
    X12                  R311 1
    X12                  R317 1
    X12                  R318 1
    X12                  R323 1
    X12                  R326 1
    X12                  R327 1
    X12                  R329 1
    X12                  R340 1
    X12                  R347 1
    X12                  R349 1
    X12                  R355 1
    X12                  R357 1
    X12                  R359 1
    X12                  R363 1
    X12                  R374 1
    X12                  R386 1
    X12                  R398 1
    X12                  R399 1
    X12                  R400 1
    X12                  R402 1
    X12                  R406 1
    X12                  R410 1
    X12                  R415 1
    X12                  R446 1
    X12                  R455 1
    X12                  R463 1
    X12                  R465 1
    X12                  R466 1
    X12                  R477 1
    X12                  R480 1
    X12                  R485 1
    X13                  OBJ 0
    X13                  R16 1
    X13                  R19 1
    X13                  R39 1
    X13                  R52 1
    X13                  R61 1
    X13                  R66 1
    X13                  R81 1
    X13                  R84 1
    X13                  R85 1
    X13                  R99 1
    X13                  R107 1
    X13                  R120 1
    X13                  R125 1
    X13                  R141 1
    X13                  R147 1
    X13                  R164 1
    X13                  R165 1
    X13                  R196 1
    X13                  R217 1
    X13                  R219 1
    X13                  R224 1
    X13                  R267 1
    X13                  R276 1
    X13                  R291 1
    X13                  R314 1
    X13                  R315 1
    X13                  R316 1
    X13                  R319 1
    X13                  R323 1
    X13                  R327 1
    X13                  R329 1
    X13                  R335 1
    X13                  R345 1
    X13                  R348 1
    X13                  R355 1
    X13                  R357 1
    X13                  R362 1
    X13                  R364 1
    X13                  R368 1
    X13                  R374 1
    X13                  R383 1
    X13                  R384 1
    X13                  R393 1
    X13                  R399 1
    X13                  R401 1
    X13                  R411 1
    X13                  R435 1
    X13                  R445 1
    X13                  R451 1
    X13                  R457 1
    X13                  R461 1
    X13                  R472 1
    X13                  R484 1
    X13                  R485 1
    X14                  OBJ 0
    X14                  R11 1
    X14                  R16 1
    X14                  R17 1
    X14                  R30 1
    X14                  R44 1
    X14                  R47 1
    X14                  R53 1
    X14                  R54 1
    X14                  R58 1
    X14                  R61 1
    X14                  R62 1
    X14                  R65 1
    X14                  R66 1
    X14                  R69 1
    X14                  R70 1
    X14                  R73 1
    X14                  R75 1
    X14                  R80 1
    X14                  R90 1
    X14                  R101 1
    X14                  R104 1
    X14                  R117 1
    X14                  R126 1
    X14                  R132 1
    X14                  R133 1
    X14                  R145 1
    X14                  R147 1
    X14                  R153 1
    X14                  R157 1
    X14                  R159 1
    X14                  R167 1
    X14                  R172 1
    X14                  R180 1
    X14                  R181 1
    X14                  R182 1
    X14                  R184 1
    X14                  R196 1
    X14                  R197 1
    X14                  R211 1
    X14                  R212 1
    X14                  R215 1
    X14                  R216 1
    X14                  R218 1
    X14                  R221 1
    X14                  R229 1
    X14                  R237 1
    X14                  R247 1
    X14                  R253 1
    X14                  R254 1
    X14                  R262 1
    X14                  R268 1
    X14                  R271 1
    X14                  R275 1
    X14                  R277 1
    X14                  R282 1
    X14                  R285 1
    X14                  R290 1
    X14                  R299 1
    X14                  R305 1
    X14                  R306 1
    X14                  R308 1
    X14                  R314 1
    X14                  R317 1
    X14                  R329 1
    X14                  R330 1
    X14                  R331 1
    X14                  R337 1
    X14                  R338 1
    X14                  R340 1
    X14                  R342 1
    X14                  R343 1
    X14                  R344 1
    X14                  R346 1
    X14                  R350 1
    X14                  R351 1
    X14                  R353 1
    X14                  R356 1
    X14                  R363 1
    X14                  R372 1
    X14                  R375 1
    X14                  R377 1
    X14                  R380 1
    X14                  R381 1
    X14                  R382 1
    X14                  R383 1
    X14                  R388 1
    X14                  R389 1
    X14                  R390 1
    X14                  R395 1
    X14                  R397 1
    X14                  R398 1
    X14                  R400 1
    X14                  R401 1
    X14                  R403 1
    X14                  R404 1
    X14                  R405 1
    X14                  R408 1
    X14                  R409 1
    X14                  R413 1
    X14                  R417 1
    X14                  R424 1
    X14                  R428 1
    X14                  R430 1
    X14                  R433 1
    X14                  R434 1
    X14                  R435 1
    X14                  R436 1
    X14                  R437 1
    X14                  R438 1
    X14                  R440 1
    X14                  R442 1
    X14                  R445 1
    X14                  R447 1
    X14                  R450 1
    X14                  R451 1
    X14                  R453 1
    X14                  R457 1
    X14                  R458 1
    X14                  R460 1
    X14                  R463 1
    X14                  R471 1
    X14                  R474 1
    X14                  R475 1
    X14                  R476 1
    X14                  R477 1
    X14                  R479 1
    X14                  R481 1
    X14                  R483 1
    X14                  R485 1
    X15                  OBJ 0
    X15                  R0 1
    X15                  R1 1
    X15                  R13 1
    X15                  R17 1
    X15                  R20 1
    X15                  R34 1
    X15                  R40 1
    X15                  R41 1
    X15                  R51 1
    X15                  R54 1
    X15                  R55 1
    X15                  R60 1
    X15                  R63 1
    X15                  R64 1
    X15                  R67 1
    X15                  R71 1
    X15                  R73 1
    X15                  R77 1
    X15                  R78 1
    X15                  R79 1
    X15                  R80 1
    X15                  R82 1
    X15                  R86 1
    X15                  R92 1
    X15                  R107 1
    X15                  R111 1
    X15                  R112 1
    X15                  R120 1
    X15                  R122 1
    X15                  R124 1
    X15                  R127 1
    X15                  R130 1
    X15                  R135 1
    X15                  R139 1
    X15                  R144 1
    X15                  R147 1
    X15                  R152 1
    X15                  R154 1
    X15                  R159 1
    X15                  R163 1
    X15                  R174 1
    X15                  R177 1
    X15                  R179 1
    X15                  R186 1
    X15                  R188 1
    X15                  R189 1
    X15                  R191 1
    X15                  R193 1
    X15                  R195 1
    X15                  R196 1
    X15                  R200 1
    X15                  R206 1
    X15                  R219 1
    X15                  R233 1
    X15                  R236 1
    X15                  R242 1
    X15                  R244 1
    X15                  R248 1
    X15                  R250 1
    X15                  R260 1
    X15                  R266 1
    X15                  R267 1
    X15                  R270 1
    X15                  R294 1
    X15                  R298 1
    X15                  R300 1
    X15                  R301 1
    X15                  R310 1
    X15                  R315 1
    X15                  R316 1
    X15                  R318 1
    X15                  R320 1
    X15                  R323 1
    X15                  R324 1
    X15                  R330 1
    X15                  R336 1
    X15                  R341 1
    X15                  R350 1
    X15                  R353 1
    X15                  R362 1
    X15                  R371 1
    X15                  R376 1
    X15                  R379 1
    X15                  R381 1
    X15                  R382 1
    X15                  R384 1
    X15                  R399 1
    X15                  R408 1
    X15                  R416 1
    X15                  R418 1
    X15                  R419 1
    X15                  R420 1
    X15                  R426 1
    X15                  R428 1
    X15                  R430 1
    X15                  R435 1
    X15                  R436 1
    X15                  R447 1
    X15                  R451 1
    X15                  R454 1
    X15                  R461 1
    X15                  R466 1
    X15                  R468 1
    X15                  R478 1
    X15                  R479 1
    X15                  R485 1
    X16                  OBJ 0
    X16                  R54 1
    X16                  R70 1
    X16                  R90 1
    X16                  R106 1
    X16                  R112 1
    X16                  R146 1
    X16                  R187 1
    X16                  R204 1
    X16                  R231 1
    X16                  R240 1
    X16                  R249 1
    X16                  R310 1
    X16                  R321 1
    X16                  R342 1
    X16                  R353 1
    X16                  R372 1
    X16                  R394 1
    X16                  R418 1
    X16                  R422 1
    X16                  R429 1
    X16                  R485 1
    X17                  OBJ 0
    X17                  R0 1
    X17                  R1 1
    X17                  R3 1
    X17                  R11 1
    X17                  R17 1
    X17                  R31 1
    X17                  R33 1
    X17                  R35 1
    X17                  R38 1
    X17                  R48 1
    X17                  R51 1
    X17                  R64 1
    X17                  R71 1
    X17                  R88 1
    X17                  R123 1
    X17                  R128 1
    X17                  R129 1
    X17                  R139 1
    X17                  R142 1
    X17                  R147 1
    X17                  R152 1
    X17                  R160 1
    X17                  R169 1
    X17                  R171 1
    X17                  R173 1
    X17                  R175 1
    X17                  R192 1
    X17                  R197 1
    X17                  R201 1
    X17                  R206 1
    X17                  R207 1
    X17                  R212 1
    X17                  R241 1
    X17                  R247 1
    X17                  R248 1
    X17                  R249 1
    X17                  R259 1
    X17                  R268 1
    X17                  R275 1
    X17                  R276 1
    X17                  R282 1
    X17                  R291 1
    X17                  R323 1
    X17                  R331 1
    X17                  R341 1
    X17                  R355 1
    X17                  R371 1
    X17                  R374 1
    X17                  R377 1
    X17                  R380 1
    X17                  R385 1
    X17                  R386 1
    X17                  R388 1
    X17                  R393 1
    X17                  R394 1
    X17                  R397 1
    X17                  R404 1
    X17                  R411 1
    X17                  R434 1
    X17                  R435 1
    X17                  R441 1
    X17                  R447 1
    X17                  R457 1
    X17                  R458 1
    X17                  R460 1
    X17                  R464 1
    X17                  R478 1
    X17                  R479 1
    X17                  R482 1
    X17                  R485 1
    X18                  OBJ 0
    X18                  R1 1
    X18                  R4 1
    X18                  R5 1
    X18                  R7 1
    X18                  R8 1
    X18                  R10 1
    X18                  R12 1
    X18                  R13 1
    X18                  R17 1
    X18                  R24 1
    X18                  R26 1
    X18                  R32 1
    X18                  R36 1
    X18                  R38 1
    X18                  R39 1
    X18                  R40 1
    X18                  R48 1
    X18                  R50 1
    X18                  R51 1
    X18                  R53 1
    X18                  R56 1
    X18                  R59 1
    X18                  R65 1
    X18                  R67 1
    X18                  R69 1
    X18                  R70 1
    X18                  R71 1
    X18                  R74 1
    X18                  R76 1
    X18                  R80 1
    X18                  R85 1
    X18                  R86 1
    X18                  R89 1
    X18                  R93 1
    X18                  R95 1
    X18                  R96 1
    X18                  R98 1
    X18                  R104 1
    X18                  R105 1
    X18                  R107 1
    X18                  R109 1
    X18                  R110 1
    X18                  R111 1
    X18                  R112 1
    X18                  R115 1
    X18                  R121 1
    X18                  R122 1
    X18                  R123 1
    X18                  R124 1
    X18                  R125 1
    X18                  R126 1
    X18                  R127 1
    X18                  R128 1
    X18                  R133 1
    X18                  R135 1
    X18                  R136 1
    X18                  R137 1
    X18                  R138 1
    X18                  R139 1
    X18                  R141 1
    X18                  R142 1
    X18                  R143 1
    X18                  R144 1
    X18                  R147 1
    X18                  R148 1
    X18                  R149 1
    X18                  R151 1
    X18                  R153 1
    X18                  R158 1
    X18                  R159 1
    X18                  R160 1
    X18                  R164 1
    X18                  R167 1
    X18                  R170 1
    X18                  R172 1
    X18                  R173 1
    X18                  R174 1
    X18                  R175 1
    X18                  R179 1
    X18                  R180 1
    X18                  R183 1
    X18                  R185 1
    X18                  R188 1
    X18                  R191 1
    X18                  R196 1
    X18                  R201 1
    X18                  R204 1
    X18                  R205 1
    X18                  R207 1
    X18                  R208 1
    X18                  R211 1
    X18                  R213 1
    X18                  R215 1
    X18                  R216 1
    X18                  R220 1
    X18                  R221 1
    X18                  R229 1
    X18                  R230 1
    X18                  R232 1
    X18                  R234 1
    X18                  R236 1
    X18                  R239 1
    X18                  R242 1
    X18                  R243 1
    X18                  R247 1
    X18                  R249 1
    X18                  R250 1
    X18                  R255 1
    X18                  R256 1
    X18                  R257 1
    X18                  R260 1
    X18                  R262 1
    X18                  R263 1
    X18                  R264 1
    X18                  R265 1
    X18                  R267 1
    X18                  R270 1
    X18                  R272 1
    X18                  R273 1
    X18                  R274 1
    X18                  R275 1
    X18                  R276 1
    X18                  R277 1
    X18                  R279 1
    X18                  R281 1
    X18                  R283 1
    X18                  R284 1
    X18                  R285 1
    X18                  R286 1
    X18                  R288 1
    X18                  R289 1
    X18                  R290 1
    X18                  R292 1
    X18                  R295 1
    X18                  R296 1
    X18                  R299 1
    X18                  R308 1
    X18                  R312 1
    X18                  R316 1
    X18                  R317 1
    X18                  R320 1
    X18                  R324 1
    X18                  R327 1
    X18                  R329 1
    X18                  R332 1
    X18                  R334 1
    X18                  R335 1
    X18                  R336 1
    X18                  R340 1
    X18                  R344 1
    X18                  R346 1
    X18                  R347 1
    X18                  R354 1
    X18                  R357 1
    X18                  R358 1
    X18                  R359 1
    X18                  R360 1
    X18                  R364 1
    X18                  R367 1
    X18                  R372 1
    X18                  R376 1
    X18                  R380 1
    X18                  R382 1
    X18                  R389 1
    X18                  R391 1
    X18                  R392 1
    X18                  R397 1
    X18                  R398 1
    X18                  R399 1
    X18                  R400 1
    X18                  R405 1
    X18                  R407 1
    X18                  R409 1
    X18                  R411 1
    X18                  R417 1
    X18                  R421 1
    X18                  R424 1
    X18                  R428 1
    X18                  R429 1
    X18                  R431 1
    X18                  R434 1
    X18                  R435 1
    X18                  R436 1
    X18                  R438 1
    X18                  R443 1
    X18                  R446 1
    X18                  R447 1
    X18                  R450 1
    X18                  R451 1
    X18                  R455 1
    X18                  R456 1
    X18                  R457 1
    X18                  R458 1
    X18                  R459 1
    X18                  R460 1
    X18                  R461 1
    X18                  R463 1
    X18                  R464 1
    X18                  R468 1
    X18                  R469 1
    X18                  R474 1
    X18                  R476 1
    X18                  R478 1
    X18                  R479 1
    X18                  R483 1
    X18                  R484 1
    X18                  R485 1
    X19                  OBJ 0
    X19                  R19 1
    X19                  R25 1
    X19                  R42 1
    X19                  R46 1
    X19                  R119 1
    X19                  R162 1
    X19                  R210 1
    X19                  R222 1
    X19                  R238 1
    X19                  R259 1
    X19                  R282 1
    X19                  R351 1
    X19                  R352 1
    X19                  R413 1
    X19                  R415 1
    X19                  R431 1
    X19                  R438 1
    X19                  R468 1
    X19                  R485 1
    X20                  OBJ 0
    X20                  R0 1
    X20                  R1 1
    X20                  R4 1
    X20                  R5 1
    X20                  R7 1
    X20                  R8 1
    X20                  R11 1
    X20                  R13 1
    X20                  R14 1
    X20                  R18 1
    X20                  R21 1
    X20                  R24 1
    X20                  R30 1
    X20                  R31 1
    X20                  R32 1
    X20                  R36 1
    X20                  R37 1
    X20                  R38 1
    X20                  R39 1
    X20                  R40 1
    X20                  R50 1
    X20                  R51 1
    X20                  R54 1
    X20                  R56 1
    X20                  R57 1
    X20                  R59 1
    X20                  R60 1
    X20                  R61 1
    X20                  R62 1
    X20                  R63 1
    X20                  R68 1
    X20                  R73 1
    X20                  R76 1
    X20                  R79 1
    X20                  R92 1
    X20                  R96 1
    X20                  R97 1
    X20                  R98 1
    X20                  R100 1
    X20                  R103 1
    X20                  R104 1
    X20                  R107 1
    X20                  R108 1
    X20                  R110 1
    X20                  R112 1
    X20                  R114 1
    X20                  R117 1
    X20                  R118 1
    X20                  R124 1
    X20                  R125 1
    X20                  R128 1
    X20                  R132 1
    X20                  R135 1
    X20                  R138 1
    X20                  R141 1
    X20                  R143 1
    X20                  R144 1
    X20                  R146 1
    X20                  R147 1
    X20                  R149 1
    X20                  R150 1
    X20                  R151 1
    X20                  R152 1
    X20                  R153 1
    X20                  R155 1
    X20                  R156 1
    X20                  R157 1
    X20                  R159 1
    X20                  R160 1
    X20                  R161 1
    X20                  R162 1
    X20                  R164 1
    X20                  R166 1
    X20                  R167 1
    X20                  R174 1
    X20                  R175 1
    X20                  R176 1
    X20                  R177 1
    X20                  R179 1
    X20                  R183 1
    X20                  R189 1
    X20                  R193 1
    X20                  R194 1
    X20                  R195 1
    X20                  R198 1
    X20                  R202 1
    X20                  R203 1
    X20                  R206 1
    X20                  R211 1
    X20                  R216 1
    X20                  R219 1
    X20                  R220 1
    X20                  R222 1
    X20                  R223 1
    X20                  R224 1
    X20                  R226 1
    X20                  R229 1
    X20                  R230 1
    X20                  R232 1
    X20                  R235 1
    X20                  R236 1
    X20                  R239 1
    X20                  R243 1
    X20                  R244 1
    X20                  R248 1
    X20                  R249 1
    X20                  R250 1
    X20                  R251 1
    X20                  R257 1
    X20                  R260 1
    X20                  R265 1
    X20                  R268 1
    X20                  R270 1
    X20                  R271 1
    X20                  R277 1
    X20                  R280 1
    X20                  R282 1
    X20                  R285 1
    X20                  R286 1
    X20                  R287 1
    X20                  R288 1
    X20                  R289 1
    X20                  R291 1
    X20                  R297 1
    X20                  R298 1
    X20                  R304 1
    X20                  R306 1
    X20                  R310 1
    X20                  R313 1
    X20                  R315 1
    X20                  R316 1
    X20                  R317 1
    X20                  R319 1
    X20                  R320 1
    X20                  R327 1
    X20                  R329 1
    X20                  R332 1
    X20                  R333 1
    X20                  R334 1
    X20                  R338 1
    X20                  R340 1
    X20                  R343 1
    X20                  R344 1
    X20                  R349 1
    X20                  R356 1
    X20                  R357 1
    X20                  R358 1
    X20                  R359 1
    X20                  R360 1
    X20                  R361 1
    X20                  R363 1
    X20                  R365 1
    X20                  R366 1
    X20                  R367 1
    X20                  R374 1
    X20                  R376 1
    X20                  R377 1
    X20                  R387 1
    X20                  R389 1
    X20                  R390 1
    X20                  R392 1
    X20                  R393 1
    X20                  R396 1
    X20                  R397 1
    X20                  R399 1
    X20                  R400 1
    X20                  R403 1
    X20                  R404 1
    X20                  R410 1
    X20                  R415 1
    X20                  R417 1
    X20                  R419 1
    X20                  R421 1
    X20                  R423 1
    X20                  R424 1
    X20                  R425 1
    X20                  R427 1
    X20                  R428 1
    X20                  R429 1
    X20                  R432 1
    X20                  R434 1
    X20                  R435 1
    X20                  R436 1
    X20                  R441 1
    X20                  R444 1
    X20                  R446 1
    X20                  R447 1
    X20                  R455 1
    X20                  R461 1
    X20                  R464 1
    X20                  R467 1
    X20                  R469 1
    X20                  R472 1
    X20                  R476 1
    X20                  R477 1
    X20                  R478 1
    X20                  R479 1
    X20                  R481 1
    X20                  R485 1
    X21                  OBJ 0
    X21                  R4 1
    X21                  R5 1
    X21                  R6 1
    X21                  R17 1
    X21                  R24 1
    X21                  R33 1
    X21                  R56 1
    X21                  R94 1
    X21                  R97 1
    X21                  R102 1
    X21                  R107 1
    X21                  R144 1
    X21                  R150 1
    X21                  R182 1
    X21                  R189 1
    X21                  R203 1
    X21                  R210 1
    X21                  R211 1
    X21                  R216 1
    X21                  R220 1
    X21                  R234 1
    X21                  R237 1
    X21                  R251 1
    X21                  R252 1
    X21                  R261 1
    X21                  R266 1
    X21                  R268 1
    X21                  R277 1
    X21                  R280 1
    X21                  R288 1
    X21                  R294 1
    X21                  R298 1
    X21                  R312 1
    X21                  R313 1
    X21                  R326 1
    X21                  R327 1
    X21                  R328 1
    X21                  R347 1
    X21                  R357 1
    X21                  R366 1
    X21                  R385 1
    X21                  R399 1
    X21                  R412 1
    X21                  R420 1
    X21                  R428 1
    X21                  R432 1
    X21                  R442 1
    X21                  R446 1
    X21                  R455 1
    X21                  R467 1
    X21                  R470 1
    X21                  R479 1
    X21                  R485 1
    X22                  OBJ 0
    X22                  R0 1
    X22                  R5 1
    X22                  R29 1
    X22                  R36 1
    X22                  R57 1
    X22                  R59 1
    X22                  R93 1
    X22                  R162 1
    X22                  R166 1
    X22                  R228 1
    X22                  R277 1
    X22                  R322 1
    X22                  R333 1
    X22                  R334 1
    X22                  R339 1
    X22                  R369 1
    X22                  R427 1
    X22                  R453 1
    X22                  R463 1
    X22                  R485 1
    X23                  OBJ 0
    X23                  R3 1
    X23                  R4 1
    X23                  R7 1
    X23                  R13 1
    X23                  R20 1
    X23                  R24 1
    X23                  R27 1
    X23                  R28 1
    X23                  R38 1
    X23                  R40 1
    X23                  R49 1
    X23                  R52 1
    X23                  R56 1
    X23                  R79 1
    X23                  R82 1
    X23                  R86 1
    X23                  R93 1
    X23                  R94 1
    X23                  R101 1
    X23                  R107 1
    X23                  R108 1
    X23                  R109 1
    X23                  R112 1
    X23                  R113 1
    X23                  R116 1
    X23                  R117 1
    X23                  R121 1
    X23                  R122 1
    X23                  R123 1
    X23                  R129 1
    X23                  R139 1
    X23                  R141 1
    X23                  R142 1
    X23                  R143 1
    X23                  R147 1
    X23                  R151 1
    X23                  R154 1
    X23                  R160 1
    X23                  R163 1
    X23                  R166 1
    X23                  R169 1
    X23                  R173 1
    X23                  R183 1
    X23                  R191 1
    X23                  R192 1
    X23                  R200 1
    X23                  R212 1
    X23                  R213 1
    X23                  R217 1
    X23                  R220 1
    X23                  R223 1
    X23                  R225 1
    X23                  R235 1
    X23                  R237 1
    X23                  R241 1
    X23                  R243 1
    X23                  R248 1
    X23                  R257 1
    X23                  R264 1
    X23                  R278 1
    X23                  R279 1
    X23                  R283 1
    X23                  R285 1
    X23                  R289 1
    X23                  R293 1
    X23                  R303 1
    X23                  R314 1
    X23                  R317 1
    X23                  R320 1
    X23                  R326 1
    X23                  R327 1
    X23                  R328 1
    X23                  R343 1
    X23                  R349 1
    X23                  R352 1
    X23                  R357 1
    X23                  R359 1
    X23                  R372 1
    X23                  R375 1
    X23                  R376 1
    X23                  R377 1
    X23                  R378 1
    X23                  R390 1
    X23                  R397 1
    X23                  R399 1
    X23                  R400 1
    X23                  R401 1
    X23                  R406 1
    X23                  R407 1
    X23                  R409 1
    X23                  R410 1
    X23                  R414 1
    X23                  R418 1
    X23                  R425 1
    X23                  R429 1
    X23                  R437 1
    X23                  R438 1
    X23                  R439 1
    X23                  R443 1
    X23                  R445 1
    X23                  R446 1
    X23                  R447 1
    X23                  R448 1
    X23                  R450 1
    X23                  R455 1
    X23                  R458 1
    X23                  R464 1
    X23                  R475 1
    X23                  R479 1
    X23                  R485 1
    X24                  OBJ 0
    X24                  R0 1
    X24                  R1 1
    X24                  R2 1
    X24                  R3 1
    X24                  R4 1
    X24                  R5 1
    X24                  R6 1
    X24                  R7 1
    X24                  R8 1
    X24                  R9 1
    X24                  R10 1
    X24                  R11 1
    X24                  R12 1
    X24                  R13 1
    X24                  R14 1
    X24                  R15 1
    X24                  R16 1
    X24                  R17 1
    X24                  R18 1
    X24                  R19 1
    X24                  R20 1
    X24                  R21 1
    X24                  R22 1
    X24                  R23 1
    X24                  R24 1
    X24                  R25 1
    X24                  R26 1
    X24                  R27 1
    X24                  R28 1
    X24                  R29 1
    X24                  R30 1
    X24                  R31 1
    X24                  R32 1
    X24                  R33 1
    X24                  R34 1
    X24                  R35 1
    X24                  R36 1
    X24                  R37 1
    X24                  R38 1
    X24                  R39 1
    X24                  R40 1
    X24                  R41 1
    X24                  R42 1
    X24                  R43 1
    X24                  R44 1
    X24                  R45 1
    X24                  R46 1
    X24                  R47 1
    X24                  R48 1
    X24                  R49 1
    X24                  R50 1
    X24                  R51 1
    X24                  R52 1
    X24                  R53 1
    X24                  R54 1
    X24                  R55 1
    X24                  R56 1
    X24                  R57 1
    X24                  R58 1
    X24                  R59 1
    X24                  R60 1
    X24                  R61 1
    X24                  R62 1
    X24                  R63 1
    X24                  R64 1
    X24                  R65 1
    X24                  R66 1
    X24                  R67 1
    X24                  R68 1
    X24                  R69 1
    X24                  R70 1
    X24                  R71 1
    X24                  R72 1
    X24                  R73 1
    X24                  R74 1
    X24                  R75 1
    X24                  R76 1
    X24                  R77 1
    X24                  R78 1
    X24                  R79 1
    X24                  R80 1
    X24                  R81 1
    X24                  R82 1
    X24                  R83 1
    X24                  R84 1
    X24                  R85 1
    X24                  R86 1
    X24                  R87 1
    X24                  R88 1
    X24                  R89 1
    X24                  R90 1
    X24                  R91 1
    X24                  R92 1
    X24                  R93 1
    X24                  R94 1
    X24                  R95 1
    X24                  R96 1
    X24                  R97 1
    X24                  R98 1
    X24                  R99 1
    X24                  R100 1
    X24                  R101 1
    X24                  R102 1
    X24                  R103 1
    X24                  R104 1
    X24                  R105 1
    X24                  R106 1
    X24                  R107 1
    X24                  R108 1
    X24                  R109 1
    X24                  R110 1
    X24                  R111 1
    X24                  R112 1
    X24                  R113 1
    X24                  R114 1
    X24                  R115 1
    X24                  R116 1
    X24                  R117 1
    X24                  R118 1
    X24                  R119 1
    X24                  R120 1
    X24                  R121 1
    X24                  R122 1
    X24                  R123 1
    X24                  R124 1
    X24                  R125 1
    X24                  R126 1
    X24                  R127 1
    X24                  R128 1
    X24                  R129 1
    X24                  R130 1
    X24                  R131 1
    X24                  R132 1
    X24                  R133 1
    X24                  R134 1
    X24                  R135 1
    X24                  R136 1
    X24                  R137 1
    X24                  R138 1
    X24                  R139 1
    X24                  R140 1
    X24                  R141 1
    X24                  R142 1
    X24                  R143 1
    X24                  R144 1
    X24                  R145 1
    X24                  R146 1
    X24                  R147 1
    X24                  R148 1
    X24                  R149 1
    X24                  R150 1
    X24                  R151 1
    X24                  R152 1
    X24                  R153 1
    X24                  R154 1
    X24                  R155 1
    X24                  R156 1
    X24                  R157 1
    X24                  R158 1
    X24                  R159 1
    X24                  R160 1
    X24                  R161 1
    X24                  R162 1
    X24                  R163 1
    X24                  R164 1
    X24                  R165 1
    X24                  R166 1
    X24                  R167 1
    X24                  R168 1
    X24                  R169 1
    X24                  R170 1
    X24                  R171 1
    X24                  R172 1
    X24                  R173 1
    X24                  R174 1
    X24                  R175 1
    X24                  R176 1
    X24                  R177 1
    X24                  R178 1
    X24                  R179 1
    X24                  R180 1
    X24                  R181 1
    X24                  R182 1
    X24                  R183 1
    X24                  R184 1
    X24                  R185 1
    X24                  R186 1
    X24                  R187 1
    X24                  R188 1
    X24                  R189 1
    X24                  R190 1
    X24                  R191 1
    X24                  R192 1
    X24                  R193 1
    X24                  R194 1
    X24                  R195 1
    X24                  R196 1
    X24                  R197 1
    X24                  R198 1
    X24                  R199 1
    X24                  R200 1
    X24                  R201 1
    X24                  R202 1
    X24                  R203 1
    X24                  R204 1
    X24                  R205 1
    X24                  R206 1
    X24                  R207 1
    X24                  R208 1
    X24                  R209 1
    X24                  R210 1
    X24                  R211 1
    X24                  R212 1
    X24                  R213 1
    X24                  R214 1
    X24                  R215 1
    X24                  R216 1
    X24                  R217 1
    X24                  R218 1
    X24                  R219 1
    X24                  R220 1
    X24                  R221 1
    X24                  R222 1
    X24                  R223 1
    X24                  R224 1
    X24                  R225 1
    X24                  R226 1
    X24                  R227 1
    X24                  R228 1
    X24                  R229 1
    X24                  R230 1
    X24                  R231 1
    X24                  R232 1
    X24                  R233 1
    X24                  R234 1
    X24                  R235 1
    X24                  R236 1
    X24                  R237 1
    X24                  R238 1
    X24                  R239 1
    X24                  R240 1
    X24                  R241 1
    X24                  R242 1
    X24                  R243 1
    X24                  R244 1
    X24                  R245 1
    X24                  R246 1
    X24                  R247 1
    X24                  R248 1
    X24                  R249 1
    X24                  R250 1
    X24                  R251 1
    X24                  R252 1
    X24                  R253 1
    X24                  R254 1
    X24                  R255 1
    X24                  R256 1
    X24                  R257 1
    X24                  R258 1
    X24                  R259 1
    X24                  R260 1
    X24                  R261 1
    X24                  R262 1
    X24                  R263 1
    X24                  R264 1
    X24                  R265 1
    X24                  R266 1
    X24                  R267 1
    X24                  R268 1
    X24                  R269 1
    X24                  R270 1
    X24                  R271 1
    X24                  R272 1
    X24                  R273 1
    X24                  R274 1
    X24                  R275 1
    X24                  R276 1
    X24                  R277 1
    X24                  R278 1
    X24                  R279 1
    X24                  R280 1
    X24                  R281 1
    X24                  R282 1
    X24                  R283 1
    X24                  R284 1
    X24                  R285 1
    X24                  R286 1
    X24                  R287 1
    X24                  R288 1
    X24                  R289 1
    X24                  R290 1
    X24                  R291 1
    X24                  R292 1
    X24                  R293 1
    X24                  R294 1
    X24                  R295 1
    X24                  R296 1
    X24                  R297 1
    X24                  R298 1
    X24                  R299 1
    X24                  R300 1
    X24                  R301 1
    X24                  R302 1
    X24                  R303 1
    X24                  R304 1
    X24                  R305 1
    X24                  R306 1
    X24                  R307 1
    X24                  R308 1
    X24                  R309 1
    X24                  R310 1
    X24                  R311 1
    X24                  R312 1
    X24                  R313 1
    X24                  R314 1
    X24                  R315 1
    X24                  R316 1
    X24                  R317 1
    X24                  R318 1
    X24                  R319 1
    X24                  R320 1
    X24                  R321 1
    X24                  R322 1
    X24                  R323 1
    X24                  R324 1
    X24                  R325 1
    X24                  R326 1
    X24                  R327 1
    X24                  R328 1
    X24                  R329 1
    X24                  R330 1
    X24                  R331 1
    X24                  R332 1
    X24                  R333 1
    X24                  R334 1
    X24                  R335 1
    X24                  R336 1
    X24                  R337 1
    X24                  R338 1
    X24                  R339 1
    X24                  R340 1
    X24                  R341 1
    X24                  R342 1
    X24                  R343 1
    X24                  R344 1
    X24                  R345 1
    X24                  R346 1
    X24                  R347 1
    X24                  R348 1
    X24                  R349 1
    X24                  R350 1
    X24                  R351 1
    X24                  R352 1
    X24                  R353 1
    X24                  R354 1
    X24                  R355 1
    X24                  R356 1
    X24                  R357 1
    X24                  R358 1
    X24                  R359 1
    X24                  R360 1
    X24                  R361 1
    X24                  R362 1
    X24                  R363 1
    X24                  R364 1
    X24                  R365 1
    X24                  R366 1
    X24                  R367 1
    X24                  R368 1
    X24                  R369 1
    X24                  R370 1
    X24                  R371 1
    X24                  R372 1
    X24                  R373 1
    X24                  R374 1
    X24                  R375 1
    X24                  R376 1
    X24                  R377 1
    X24                  R378 1
    X24                  R379 1
    X24                  R380 1
    X24                  R381 1
    X24                  R382 1
    X24                  R383 1
    X24                  R384 1
    X24                  R385 1
    X24                  R386 1
    X24                  R387 1
    X24                  R388 1
    X24                  R389 1
    X24                  R390 1
    X24                  R391 1
    X24                  R392 1
    X24                  R393 1
    X24                  R394 1
    X24                  R395 1
    X24                  R396 1
    X24                  R397 1
    X24                  R398 1
    X24                  R399 1
    X24                  R400 1
    X24                  R401 1
    X24                  R402 1
    X24                  R403 1
    X24                  R404 1
    X24                  R405 1
    X24                  R406 1
    X24                  R407 1
    X24                  R408 1
    X24                  R409 1
    X24                  R410 1
    X24                  R411 1
    X24                  R412 1
    X24                  R413 1
    X24                  R414 1
    X24                  R415 1
    X24                  R416 1
    X24                  R417 1
    X24                  R418 1
    X24                  R419 1
    X24                  R420 1
    X24                  R421 1
    X24                  R422 1
    X24                  R423 1
    X24                  R424 1
    X24                  R425 1
    X24                  R426 1
    X24                  R427 1
    X24                  R428 1
    X24                  R429 1
    X24                  R430 1
    X24                  R431 1
    X24                  R432 1
    X24                  R433 1
    X24                  R434 1
    X24                  R435 1
    X24                  R436 1
    X24                  R437 1
    X24                  R438 1
    X24                  R439 1
    X24                  R440 1
    X24                  R441 1
    X24                  R442 1
    X24                  R443 1
    X24                  R444 1
    X24                  R445 1
    X24                  R446 1
    X24                  R447 1
    X24                  R448 1
    X24                  R449 1
    X24                  R450 1
    X24                  R451 1
    X24                  R452 1
    X24                  R453 1
    X24                  R454 1
    X24                  R455 1
    X24                  R456 1
    X24                  R457 1
    X24                  R458 1
    X24                  R459 1
    X24                  R460 1
    X24                  R461 1
    X24                  R462 1
    X24                  R463 1
    X24                  R464 1
    X24                  R465 1
    X24                  R466 1
    X24                  R467 1
    X24                  R468 1
    X24                  R469 1
    X24                  R470 1
    X24                  R471 1
    X24                  R472 1
    X24                  R473 1
    X24                  R474 1
    X24                  R475 1
    X24                  R476 1
    X24                  R477 1
    X24                  R478 1
    X24                  R479 1
    X24                  R480 1
    X24                  R481 1
    X24                  R482 1
    X24                  R483 1
    X24                  R484 1
    X24                  R485 1
    X25                  OBJ 0
    X25                  R20 -1
    X25                  R34 -1
    X25                  R47 -1
    X25                  R51 -1
    X25                  R54 -1
    X25                  R64 -1
    X25                  R67 -1
    X25                  R68 -1
    X25                  R76 -1
    X25                  R82 -1
    X25                  R106 -1
    X25                  R111 -1
    X25                  R120 -1
    X25                  R130 -1
    X25                  R177 -1
    X25                  R178 -1
    X25                  R179 -1
    X25                  R191 -1
    X25                  R196 -1
    X25                  R200 -1
    X25                  R206 -1
    X25                  R208 -1
    X25                  R224 -1
    X25                  R230 -1
    X25                  R233 -1
    X25                  R234 -1
    X25                  R244 -1
    X25                  R246 -1
    X25                  R250 -1
    X25                  R253 -1
    X25                  R267 -1
    X25                  R270 -1
    X25                  R274 -1
    X25                  R278 -1
    X25                  R290 -1
    X25                  R292 -1
    X25                  R301 -1
    X25                  R302 -1
    X25                  R305 -1
    X25                  R308 -1
    X25                  R310 -1
    X25                  R317 -1
    X25                  R322 -1
    X25                  R345 -1
    X25                  R350 -1
    X25                  R351 -1
    X25                  R353 -1
    X25                  R363 -1
    X25                  R366 -1
    X25                  R368 -1
    X25                  R370 -1
    X25                  R376 -1
    X25                  R378 -1
    X25                  R384 -1
    X25                  R387 -1
    X25                  R405 -1
    X25                  R416 -1
    X25                  R418 -1
    X25                  R420 -1
    X25                  R428 -1
    X25                  R440 -1
    X25                  R478 -1
    X25                  R480 -1
    X25                  R485 1
    X26                  OBJ 0
    X26                  R2 -1
    X26                  R3 -1
    X26                  R4 -1
    X26                  R6 -1
    X26                  R10 -1
    X26                  R11 -1
    X26                  R14 -1
    X26                  R17 -1
    X26                  R19 -1
    X26                  R20 -1
    X26                  R22 -1
    X26                  R25 -1
    X26                  R26 -1
    X26                  R27 -1
    X26                  R29 -1
    X26                  R32 -1
    X26                  R33 -1
    X26                  R37 -1
    X26                  R38 -1
    X26                  R40 -1
    X26                  R47 -1
    X26                  R48 -1
    X26                  R52 -1
    X26                  R56 -1
    X26                  R58 -1
    X26                  R60 -1
    X26                  R62 -1
    X26                  R64 -1
    X26                  R67 -1
    X26                  R71 -1
    X26                  R72 -1
    X26                  R77 -1
    X26                  R78 -1
    X26                  R81 -1
    X26                  R82 -1
    X26                  R83 -1
    X26                  R84 -1
    X26                  R86 -1
    X26                  R87 -1
    X26                  R89 -1
    X26                  R98 -1
    X26                  R101 -1
    X26                  R105 -1
    X26                  R107 -1
    X26                  R108 -1
    X26                  R109 -1
    X26                  R113 -1
    X26                  R117 -1
    X26                  R119 -1
    X26                  R122 -1
    X26                  R123 -1
    X26                  R125 -1
    X26                  R127 -1
    X26                  R130 -1
    X26                  R131 -1
    X26                  R133 -1
    X26                  R134 -1
    X26                  R138 -1
    X26                  R139 -1
    X26                  R141 -1
    X26                  R143 -1
    X26                  R144 -1
    X26                  R146 -1
    X26                  R147 -1
    X26                  R150 -1
    X26                  R151 -1
    X26                  R156 -1
    X26                  R157 -1
    X26                  R163 -1
    X26                  R164 -1
    X26                  R171 -1
    X26                  R172 -1
    X26                  R181 -1
    X26                  R183 -1
    X26                  R184 -1
    X26                  R185 -1
    X26                  R190 -1
    X26                  R192 -1
    X26                  R194 -1
    X26                  R195 -1
    X26                  R198 -1
    X26                  R200 -1
    X26                  R204 -1
    X26                  R205 -1
    X26                  R206 -1
    X26                  R208 -1
    X26                  R211 -1
    X26                  R212 -1
    X26                  R215 -1
    X26                  R219 -1
    X26                  R221 -1
    X26                  R222 -1
    X26                  R224 -1
    X26                  R225 -1
    X26                  R229 -1
    X26                  R233 -1
    X26                  R235 -1
    X26                  R238 -1
    X26                  R240 -1
    X26                  R244 -1
    X26                  R247 -1
    X26                  R248 -1
    X26                  R255 -1
    X26                  R258 -1
    X26                  R259 -1
    X26                  R260 -1
    X26                  R263 -1
    X26                  R264 -1
    X26                  R266 -1
    X26                  R276 -1
    X26                  R277 -1
    X26                  R278 -1
    X26                  R279 -1
    X26                  R284 -1
    X26                  R287 -1
    X26                  R288 -1
    X26                  R289 -1
    X26                  R291 -1
    X26                  R298 -1
    X26                  R301 -1
    X26                  R307 -1
    X26                  R310 -1
    X26                  R312 -1
    X26                  R315 -1
    X26                  R317 -1
    X26                  R318 -1
    X26                  R319 -1
    X26                  R320 -1
    X26                  R321 -1
    X26                  R322 -1
    X26                  R328 -1
    X26                  R329 -1
    X26                  R331 -1
    X26                  R342 -1
    X26                  R343 -1
    X26                  R352 -1
    X26                  R353 -1
    X26                  R354 -1
    X26                  R355 -1
    X26                  R358 -1
    X26                  R361 -1
    X26                  R362 -1
    X26                  R365 -1
    X26                  R367 -1
    X26                  R368 -1
    X26                  R370 -1
    X26                  R374 -1
    X26                  R376 -1
    X26                  R377 -1
    X26                  R379 -1
    X26                  R381 -1
    X26                  R384 -1
    X26                  R386 -1
    X26                  R388 -1
    X26                  R390 -1
    X26                  R391 -1
    X26                  R393 -1
    X26                  R396 -1
    X26                  R397 -1
    X26                  R399 -1
    X26                  R400 -1
    X26                  R401 -1
    X26                  R404 -1
    X26                  R405 -1
    X26                  R406 -1
    X26                  R407 -1
    X26                  R416 -1
    X26                  R422 -1
    X26                  R424 -1
    X26                  R425 -1
    X26                  R427 -1
    X26                  R432 -1
    X26                  R435 -1
    X26                  R437 -1
    X26                  R438 -1
    X26                  R439 -1
    X26                  R441 -1
    X26                  R447 -1
    X26                  R450 -1
    X26                  R455 -1
    X26                  R456 -1
    X26                  R457 -1
    X26                  R459 -1
    X26                  R461 -1
    X26                  R463 -1
    X26                  R466 -1
    X26                  R467 -1
    X26                  R469 -1
    X26                  R473 -1
    X26                  R475 -1
    X26                  R477 -1
    X26                  R479 -1
    X26                  R483 -1
    X26                  R485 1
    X27                  OBJ 0
    X27                  R4 -1
    X27                  R40 -1
    X27                  R50 -1
    X27                  R63 -1
    X27                  R96 -1
    X27                  R144 -1
    X27                  R183 -1
    X27                  R202 -1
    X27                  R216 -1
    X27                  R236 -1
    X27                  R306 -1
    X27                  R316 -1
    X27                  R360 -1
    X27                  R399 -1
    X27                  R408 -1
    X27                  R418 -1
    X27                  R462 -1
    X27                  R485 1
    X28                  OBJ 0
    X28                  R47 -1
    X28                  R54 -1
    X28                  R87 -1
    X28                  R112 -1
    X28                  R113 -1
    X28                  R169 -1
    X28                  R208 -1
    X28                  R209 -1
    X28                  R211 -1
    X28                  R214 -1
    X28                  R231 -1
    X28                  R240 -1
    X28                  R253 -1
    X28                  R256 -1
    X28                  R284 -1
    X28                  R324 -1
    X28                  R333 -1
    X28                  R429 -1
    X28                  R433 -1
    X28                  R459 -1
    X28                  R460 -1
    X28                  R485 1
    X29                  OBJ 0
    X29                  R16 -1
    X29                  R45 -1
    X29                  R141 -1
    X29                  R147 -1
    X29                  R151 -1
    X29                  R181 -1
    X29                  R226 -1
    X29                  R257 -1
    X29                  R267 -1
    X29                  R295 -1
    X29                  R297 -1
    X29                  R356 -1
    X29                  R364 -1
    X29                  R439 -1
    X29                  R462 -1
    X29                  R474 -1
    X29                  R485 1
    X30                  OBJ 0
    X30                  R12 -1
    X30                  R17 -1
    X30                  R46 -1
    X30                  R55 -1
    X30                  R59 -1
    X30                  R73 -1
    X30                  R76 -1
    X30                  R78 -1
    X30                  R79 -1
    X30                  R91 -1
    X30                  R93 -1
    X30                  R100 -1
    X30                  R106 -1
    X30                  R110 -1
    X30                  R114 -1
    X30                  R117 -1
    X30                  R119 -1
    X30                  R131 -1
    X30                  R147 -1
    X30                  R151 -1
    X30                  R168 -1
    X30                  R176 -1
    X30                  R180 -1
    X30                  R182 -1
    X30                  R186 -1
    X30                  R200 -1
    X30                  R203 -1
    X30                  R226 -1
    X30                  R229 -1
    X30                  R251 -1
    X30                  R254 -1
    X30                  R260 -1
    X30                  R281 -1
    X30                  R286 -1
    X30                  R287 -1
    X30                  R288 -1
    X30                  R289 -1
    X30                  R291 -1
    X30                  R293 -1
    X30                  R297 -1
    X30                  R315 -1
    X30                  R340 -1
    X30                  R343 -1
    X30                  R344 -1
    X30                  R346 -1
    X30                  R357 -1
    X30                  R369 -1
    X30                  R373 -1
    X30                  R376 -1
    X30                  R396 -1
    X30                  R402 -1
    X30                  R403 -1
    X30                  R406 -1
    X30                  R417 -1
    X30                  R421 -1
    X30                  R445 -1
    X30                  R448 -1
    X30                  R451 -1
    X30                  R452 -1
    X30                  R455 -1
    X30                  R457 -1
    X30                  R458 -1
    X30                  R470 -1
    X30                  R479 -1
    X30                  R482 -1
    X30                  R485 1
    X31                  OBJ 0
    X31                  R17 -1
    X31                  R24 -1
    X31                  R59 -1
    X31                  R72 -1
    X31                  R118 -1
    X31                  R130 -1
    X31                  R132 -1
    X31                  R137 -1
    X31                  R183 -1
    X31                  R195 -1
    X31                  R224 -1
    X31                  R228 -1
    X31                  R253 -1
    X31                  R286 -1
    X31                  R307 -1
    X31                  R309 -1
    X31                  R334 -1
    X31                  R357 -1
    X31                  R360 -1
    X31                  R361 -1
    X31                  R414 -1
    X31                  R421 -1
    X31                  R456 -1
    X31                  R463 -1
    X31                  R485 1
    X32                  OBJ 0
    X32                  R9 -1
    X32                  R10 -1
    X32                  R44 -1
    X32                  R56 -1
    X32                  R83 -1
    X32                  R106 -1
    X32                  R125 -1
    X32                  R141 -1
    X32                  R148 -1
    X32                  R213 -1
    X32                  R255 -1
    X32                  R257 -1
    X32                  R296 -1
    X32                  R320 -1
    X32                  R325 -1
    X32                  R332 -1
    X32                  R358 -1
    X32                  R364 -1
    X32                  R365 -1
    X32                  R373 -1
    X32                  R383 -1
    X32                  R399 -1
    X32                  R408 -1
    X32                  R421 -1
    X32                  R423 -1
    X32                  R431 -1
    X32                  R436 -1
    X32                  R446 -1
    X32                  R447 -1
    X32                  R465 -1
    X32                  R484 -1
    X32                  R485 1
    X33                  OBJ 0
    X33                  R0 -1
    X33                  R2 -1
    X33                  R7 -1
    X33                  R26 -1
    X33                  R53 -1
    X33                  R59 -1
    X33                  R73 -1
    X33                  R76 -1
    X33                  R80 -1
    X33                  R86 -1
    X33                  R96 -1
    X33                  R97 -1
    X33                  R106 -1
    X33                  R117 -1
    X33                  R136 -1
    X33                  R141 -1
    X33                  R144 -1
    X33                  R145 -1
    X33                  R148 -1
    X33                  R150 -1
    X33                  R155 -1
    X33                  R158 -1
    X33                  R166 -1
    X33                  R177 -1
    X33                  R183 -1
    X33                  R188 -1
    X33                  R208 -1
    X33                  R220 -1
    X33                  R224 -1
    X33                  R236 -1
    X33                  R246 -1
    X33                  R250 -1
    X33                  R251 -1
    X33                  R253 -1
    X33                  R261 -1
    X33                  R265 -1
    X33                  R268 -1
    X33                  R269 -1
    X33                  R332 -1
    X33                  R356 -1
    X33                  R367 -1
    X33                  R376 -1
    X33                  R395 -1
    X33                  R400 -1
    X33                  R425 -1
    X33                  R427 -1
    X33                  R432 -1
    X33                  R440 -1
    X33                  R443 -1
    X33                  R454 -1
    X33                  R476 -1
    X33                  R481 -1
    X33                  R485 1
    X34                  OBJ 0
    X34                  R1 -1
    X34                  R5 -1
    X34                  R24 -1
    X34                  R37 -1
    X34                  R40 -1
    X34                  R59 -1
    X34                  R79 -1
    X34                  R103 -1
    X34                  R107 -1
    X34                  R114 -1
    X34                  R133 -1
    X34                  R140 -1
    X34                  R142 -1
    X34                  R143 -1
    X34                  R150 -1
    X34                  R167 -1
    X34                  R170 -1
    X34                  R174 -1
    X34                  R185 -1
    X34                  R186 -1
    X34                  R191 -1
    X34                  R193 -1
    X34                  R202 -1
    X34                  R210 -1
    X34                  R216 -1
    X34                  R220 -1
    X34                  R229 -1
    X34                  R232 -1
    X34                  R234 -1
    X34                  R259 -1
    X34                  R262 -1
    X34                  R263 -1
    X34                  R268 -1
    X34                  R272 -1
    X34                  R277 -1
    X34                  R281 -1
    X34                  R286 -1
    X34                  R299 -1
    X34                  R311 -1
    X34                  R313 -1
    X34                  R315 -1
    X34                  R316 -1
    X34                  R324 -1
    X34                  R325 -1
    X34                  R326 -1
    X34                  R333 -1
    X34                  R334 -1
    X34                  R336 -1
    X34                  R346 -1
    X34                  R360 -1
    X34                  R361 -1
    X34                  R364 -1
    X34                  R366 -1
    X34                  R376 -1
    X34                  R387 -1
    X34                  R390 -1
    X34                  R395 -1
    X34                  R396 -1
    X34                  R398 -1
    X34                  R408 -1
    X34                  R417 -1
    X34                  R426 -1
    X34                  R432 -1
    X34                  R435 -1
    X34                  R444 -1
    X34                  R448 -1
    X34                  R452 -1
    X34                  R455 -1
    X34                  R461 -1
    X34                  R464 -1
    X34                  R469 -1
    X34                  R471 -1
    X34                  R473 -1
    X34                  R479 -1
    X34                  R485 1
    X35                  OBJ 0
    X35                  R1 -1
    X35                  R11 -1
    X35                  R18 -1
    X35                  R43 -1
    X35                  R51 -1
    X35                  R65 -1
    X35                  R72 -1
    X35                  R78 -1
    X35                  R82 -1
    X35                  R89 -1
    X35                  R98 -1
    X35                  R103 -1
    X35                  R109 -1
    X35                  R115 -1
    X35                  R123 -1
    X35                  R124 -1
    X35                  R136 -1
    X35                  R147 -1
    X35                  R149 -1
    X35                  R156 -1
    X35                  R157 -1
    X35                  R163 -1
    X35                  R168 -1
    X35                  R170 -1
    X35                  R179 -1
    X35                  R190 -1
    X35                  R199 -1
    X35                  R203 -1
    X35                  R205 -1
    X35                  R207 -1
    X35                  R216 -1
    X35                  R221 -1
    X35                  R273 -1
    X35                  R275 -1
    X35                  R292 -1
    X35                  R301 -1
    X35                  R302 -1
    X35                  R303 -1
    X35                  R304 -1
    X35                  R308 -1
    X35                  R323 -1
    X35                  R333 -1
    X35                  R335 -1
    X35                  R337 -1
    X35                  R338 -1
    X35                  R343 -1
    X35                  R348 -1
    X35                  R353 -1
    X35                  R370 -1
    X35                  R371 -1
    X35                  R379 -1
    X35                  R387 -1
    X35                  R388 -1
    X35                  R389 -1
    X35                  R391 -1
    X35                  R392 -1
    X35                  R405 -1
    X35                  R410 -1
    X35                  R419 -1
    X35                  R435 -1
    X35                  R440 -1
    X35                  R449 -1
    X35                  R463 -1
    X35                  R475 -1
    X35                  R480 -1
    X35                  R485 1
    X36                  OBJ 0
    X36                  R116 -1
    X36                  R120 -1
    X36                  R150 -1
    X36                  R194 -1
    X36                  R209 -1
    X36                  R227 -1
    X36                  R245 -1
    X36                  R258 -1
    X36                  R262 -1
    X36                  R278 -1
    X36                  R318 -1
    X36                  R321 -1
    X36                  R354 -1
    X36                  R391 -1
    X36                  R407 -1
    X36                  R412 -1
    X36                  R416 -1
    X36                  R430 -1
    X36                  R437 -1
    X36                  R449 -1
    X36                  R483 -1
    X36                  R485 1
    X37                  OBJ 0
    X37                  R3 -1
    X37                  R4 -1
    X37                  R10 -1
    X37                  R11 -1
    X37                  R17 -1
    X37                  R23 -1
    X37                  R24 -1
    X37                  R25 -1
    X37                  R30 -1
    X37                  R49 -1
    X37                  R64 -1
    X37                  R69 -1
    X37                  R76 -1
    X37                  R81 -1
    X37                  R88 -1
    X37                  R93 -1
    X37                  R95 -1
    X37                  R100 -1
    X37                  R107 -1
    X37                  R114 -1
    X37                  R121 -1
    X37                  R124 -1
    X37                  R130 -1
    X37                  R134 -1
    X37                  R136 -1
    X37                  R138 -1
    X37                  R143 -1
    X37                  R147 -1
    X37                  R149 -1
    X37                  R151 -1
    X37                  R153 -1
    X37                  R161 -1
    X37                  R165 -1
    X37                  R175 -1
    X37                  R179 -1
    X37                  R182 -1
    X37                  R184 -1
    X37                  R186 -1
    X37                  R198 -1
    X37                  R199 -1
    X37                  R203 -1
    X37                  R205 -1
    X37                  R215 -1
    X37                  R216 -1
    X37                  R218 -1
    X37                  R220 -1
    X37                  R225 -1
    X37                  R226 -1
    X37                  R227 -1
    X37                  R229 -1
    X37                  R235 -1
    X37                  R239 -1
    X37                  R241 -1
    X37                  R252 -1
    X37                  R263 -1
    X37                  R269 -1
    X37                  R273 -1
    X37                  R279 -1
    X37                  R280 -1
    X37                  R284 -1
    X37                  R285 -1
    X37                  R294 -1
    X37                  R300 -1
    X37                  R304 -1
    X37                  R311 -1
    X37                  R317 -1
    X37                  R318 -1
    X37                  R323 -1
    X37                  R326 -1
    X37                  R327 -1
    X37                  R329 -1
    X37                  R340 -1
    X37                  R347 -1
    X37                  R349 -1
    X37                  R355 -1
    X37                  R357 -1
    X37                  R359 -1
    X37                  R363 -1
    X37                  R374 -1
    X37                  R386 -1
    X37                  R398 -1
    X37                  R399 -1
    X37                  R400 -1
    X37                  R402 -1
    X37                  R406 -1
    X37                  R410 -1
    X37                  R415 -1
    X37                  R446 -1
    X37                  R455 -1
    X37                  R463 -1
    X37                  R465 -1
    X37                  R466 -1
    X37                  R477 -1
    X37                  R480 -1
    X37                  R485 1
    X38                  OBJ 0
    X38                  R16 -1
    X38                  R19 -1
    X38                  R39 -1
    X38                  R52 -1
    X38                  R61 -1
    X38                  R66 -1
    X38                  R81 -1
    X38                  R84 -1
    X38                  R85 -1
    X38                  R99 -1
    X38                  R107 -1
    X38                  R120 -1
    X38                  R125 -1
    X38                  R141 -1
    X38                  R147 -1
    X38                  R164 -1
    X38                  R165 -1
    X38                  R196 -1
    X38                  R217 -1
    X38                  R219 -1
    X38                  R224 -1
    X38                  R267 -1
    X38                  R276 -1
    X38                  R291 -1
    X38                  R314 -1
    X38                  R315 -1
    X38                  R316 -1
    X38                  R319 -1
    X38                  R323 -1
    X38                  R327 -1
    X38                  R329 -1
    X38                  R335 -1
    X38                  R345 -1
    X38                  R348 -1
    X38                  R355 -1
    X38                  R357 -1
    X38                  R362 -1
    X38                  R364 -1
    X38                  R368 -1
    X38                  R374 -1
    X38                  R383 -1
    X38                  R384 -1
    X38                  R393 -1
    X38                  R399 -1
    X38                  R401 -1
    X38                  R411 -1
    X38                  R435 -1
    X38                  R445 -1
    X38                  R451 -1
    X38                  R457 -1
    X38                  R461 -1
    X38                  R472 -1
    X38                  R484 -1
    X38                  R485 1
    X39                  OBJ 0
    X39                  R11 -1
    X39                  R16 -1
    X39                  R17 -1
    X39                  R30 -1
    X39                  R44 -1
    X39                  R47 -1
    X39                  R53 -1
    X39                  R54 -1
    X39                  R58 -1
    X39                  R61 -1
    X39                  R62 -1
    X39                  R65 -1
    X39                  R66 -1
    X39                  R69 -1
    X39                  R70 -1
    X39                  R73 -1
    X39                  R75 -1
    X39                  R80 -1
    X39                  R90 -1
    X39                  R101 -1
    X39                  R104 -1
    X39                  R117 -1
    X39                  R126 -1
    X39                  R132 -1
    X39                  R133 -1
    X39                  R145 -1
    X39                  R147 -1
    X39                  R153 -1
    X39                  R157 -1
    X39                  R159 -1
    X39                  R167 -1
    X39                  R172 -1
    X39                  R180 -1
    X39                  R181 -1
    X39                  R182 -1
    X39                  R184 -1
    X39                  R196 -1
    X39                  R197 -1
    X39                  R211 -1
    X39                  R212 -1
    X39                  R215 -1
    X39                  R216 -1
    X39                  R218 -1
    X39                  R221 -1
    X39                  R229 -1
    X39                  R237 -1
    X39                  R247 -1
    X39                  R253 -1
    X39                  R254 -1
    X39                  R262 -1
    X39                  R268 -1
    X39                  R271 -1
    X39                  R275 -1
    X39                  R277 -1
    X39                  R282 -1
    X39                  R285 -1
    X39                  R290 -1
    X39                  R299 -1
    X39                  R305 -1
    X39                  R306 -1
    X39                  R308 -1
    X39                  R314 -1
    X39                  R317 -1
    X39                  R329 -1
    X39                  R330 -1
    X39                  R331 -1
    X39                  R337 -1
    X39                  R338 -1
    X39                  R340 -1
    X39                  R342 -1
    X39                  R343 -1
    X39                  R344 -1
    X39                  R346 -1
    X39                  R350 -1
    X39                  R351 -1
    X39                  R353 -1
    X39                  R356 -1
    X39                  R363 -1
    X39                  R372 -1
    X39                  R375 -1
    X39                  R377 -1
    X39                  R380 -1
    X39                  R381 -1
    X39                  R382 -1
    X39                  R383 -1
    X39                  R388 -1
    X39                  R389 -1
    X39                  R390 -1
    X39                  R395 -1
    X39                  R397 -1
    X39                  R398 -1
    X39                  R400 -1
    X39                  R401 -1
    X39                  R403 -1
    X39                  R404 -1
    X39                  R405 -1
    X39                  R408 -1
    X39                  R409 -1
    X39                  R413 -1
    X39                  R417 -1
    X39                  R424 -1
    X39                  R428 -1
    X39                  R430 -1
    X39                  R433 -1
    X39                  R434 -1
    X39                  R435 -1
    X39                  R436 -1
    X39                  R437 -1
    X39                  R438 -1
    X39                  R440 -1
    X39                  R442 -1
    X39                  R445 -1
    X39                  R447 -1
    X39                  R450 -1
    X39                  R451 -1
    X39                  R453 -1
    X39                  R457 -1
    X39                  R458 -1
    X39                  R460 -1
    X39                  R463 -1
    X39                  R471 -1
    X39                  R474 -1
    X39                  R475 -1
    X39                  R476 -1
    X39                  R477 -1
    X39                  R479 -1
    X39                  R481 -1
    X39                  R483 -1
    X39                  R485 1
    X40                  OBJ 0
    X40                  R0 -1
    X40                  R1 -1
    X40                  R13 -1
    X40                  R17 -1
    X40                  R20 -1
    X40                  R34 -1
    X40                  R40 -1
    X40                  R41 -1
    X40                  R51 -1
    X40                  R54 -1
    X40                  R55 -1
    X40                  R60 -1
    X40                  R63 -1
    X40                  R64 -1
    X40                  R67 -1
    X40                  R71 -1
    X40                  R73 -1
    X40                  R77 -1
    X40                  R78 -1
    X40                  R79 -1
    X40                  R80 -1
    X40                  R82 -1
    X40                  R86 -1
    X40                  R92 -1
    X40                  R107 -1
    X40                  R111 -1
    X40                  R112 -1
    X40                  R120 -1
    X40                  R122 -1
    X40                  R124 -1
    X40                  R127 -1
    X40                  R130 -1
    X40                  R135 -1
    X40                  R139 -1
    X40                  R144 -1
    X40                  R147 -1
    X40                  R152 -1
    X40                  R154 -1
    X40                  R159 -1
    X40                  R163 -1
    X40                  R174 -1
    X40                  R177 -1
    X40                  R179 -1
    X40                  R186 -1
    X40                  R188 -1
    X40                  R189 -1
    X40                  R191 -1
    X40                  R193 -1
    X40                  R195 -1
    X40                  R196 -1
    X40                  R200 -1
    X40                  R206 -1
    X40                  R219 -1
    X40                  R233 -1
    X40                  R236 -1
    X40                  R242 -1
    X40                  R244 -1
    X40                  R248 -1
    X40                  R250 -1
    X40                  R260 -1
    X40                  R266 -1
    X40                  R267 -1
    X40                  R270 -1
    X40                  R294 -1
    X40                  R298 -1
    X40                  R300 -1
    X40                  R301 -1
    X40                  R310 -1
    X40                  R315 -1
    X40                  R316 -1
    X40                  R318 -1
    X40                  R320 -1
    X40                  R323 -1
    X40                  R324 -1
    X40                  R330 -1
    X40                  R336 -1
    X40                  R341 -1
    X40                  R350 -1
    X40                  R353 -1
    X40                  R362 -1
    X40                  R371 -1
    X40                  R376 -1
    X40                  R379 -1
    X40                  R381 -1
    X40                  R382 -1
    X40                  R384 -1
    X40                  R399 -1
    X40                  R408 -1
    X40                  R416 -1
    X40                  R418 -1
    X40                  R419 -1
    X40                  R420 -1
    X40                  R426 -1
    X40                  R428 -1
    X40                  R430 -1
    X40                  R435 -1
    X40                  R436 -1
    X40                  R447 -1
    X40                  R451 -1
    X40                  R454 -1
    X40                  R461 -1
    X40                  R466 -1
    X40                  R468 -1
    X40                  R478 -1
    X40                  R479 -1
    X40                  R485 1
    X41                  OBJ 0
    X41                  R54 -1
    X41                  R70 -1
    X41                  R90 -1
    X41                  R106 -1
    X41                  R112 -1
    X41                  R146 -1
    X41                  R187 -1
    X41                  R204 -1
    X41                  R231 -1
    X41                  R240 -1
    X41                  R249 -1
    X41                  R310 -1
    X41                  R321 -1
    X41                  R342 -1
    X41                  R353 -1
    X41                  R372 -1
    X41                  R394 -1
    X41                  R418 -1
    X41                  R422 -1
    X41                  R429 -1
    X41                  R485 1
    X42                  OBJ 0
    X42                  R0 -1
    X42                  R1 -1
    X42                  R3 -1
    X42                  R11 -1
    X42                  R17 -1
    X42                  R31 -1
    X42                  R33 -1
    X42                  R35 -1
    X42                  R38 -1
    X42                  R48 -1
    X42                  R51 -1
    X42                  R64 -1
    X42                  R71 -1
    X42                  R88 -1
    X42                  R123 -1
    X42                  R128 -1
    X42                  R129 -1
    X42                  R139 -1
    X42                  R142 -1
    X42                  R147 -1
    X42                  R152 -1
    X42                  R160 -1
    X42                  R169 -1
    X42                  R171 -1
    X42                  R173 -1
    X42                  R175 -1
    X42                  R192 -1
    X42                  R197 -1
    X42                  R201 -1
    X42                  R206 -1
    X42                  R207 -1
    X42                  R212 -1
    X42                  R241 -1
    X42                  R247 -1
    X42                  R248 -1
    X42                  R249 -1
    X42                  R259 -1
    X42                  R268 -1
    X42                  R275 -1
    X42                  R276 -1
    X42                  R282 -1
    X42                  R291 -1
    X42                  R323 -1
    X42                  R331 -1
    X42                  R341 -1
    X42                  R355 -1
    X42                  R371 -1
    X42                  R374 -1
    X42                  R377 -1
    X42                  R380 -1
    X42                  R385 -1
    X42                  R386 -1
    X42                  R388 -1
    X42                  R393 -1
    X42                  R394 -1
    X42                  R397 -1
    X42                  R404 -1
    X42                  R411 -1
    X42                  R434 -1
    X42                  R435 -1
    X42                  R441 -1
    X42                  R447 -1
    X42                  R457 -1
    X42                  R458 -1
    X42                  R460 -1
    X42                  R464 -1
    X42                  R478 -1
    X42                  R479 -1
    X42                  R482 -1
    X42                  R485 1
    X43                  OBJ 0
    X43                  R1 -1
    X43                  R4 -1
    X43                  R5 -1
    X43                  R7 -1
    X43                  R8 -1
    X43                  R10 -1
    X43                  R12 -1
    X43                  R13 -1
    X43                  R17 -1
    X43                  R24 -1
    X43                  R26 -1
    X43                  R32 -1
    X43                  R36 -1
    X43                  R38 -1
    X43                  R39 -1
    X43                  R40 -1
    X43                  R48 -1
    X43                  R50 -1
    X43                  R51 -1
    X43                  R53 -1
    X43                  R56 -1
    X43                  R59 -1
    X43                  R65 -1
    X43                  R67 -1
    X43                  R69 -1
    X43                  R70 -1
    X43                  R71 -1
    X43                  R74 -1
    X43                  R76 -1
    X43                  R80 -1
    X43                  R85 -1
    X43                  R86 -1
    X43                  R89 -1
    X43                  R93 -1
    X43                  R95 -1
    X43                  R96 -1
    X43                  R98 -1
    X43                  R104 -1
    X43                  R105 -1
    X43                  R107 -1
    X43                  R109 -1
    X43                  R110 -1
    X43                  R111 -1
    X43                  R112 -1
    X43                  R115 -1
    X43                  R121 -1
    X43                  R122 -1
    X43                  R123 -1
    X43                  R124 -1
    X43                  R125 -1
    X43                  R126 -1
    X43                  R127 -1
    X43                  R128 -1
    X43                  R133 -1
    X43                  R135 -1
    X43                  R136 -1
    X43                  R137 -1
    X43                  R138 -1
    X43                  R139 -1
    X43                  R141 -1
    X43                  R142 -1
    X43                  R143 -1
    X43                  R144 -1
    X43                  R147 -1
    X43                  R148 -1
    X43                  R149 -1
    X43                  R151 -1
    X43                  R153 -1
    X43                  R158 -1
    X43                  R159 -1
    X43                  R160 -1
    X43                  R164 -1
    X43                  R167 -1
    X43                  R170 -1
    X43                  R172 -1
    X43                  R173 -1
    X43                  R174 -1
    X43                  R175 -1
    X43                  R179 -1
    X43                  R180 -1
    X43                  R183 -1
    X43                  R185 -1
    X43                  R188 -1
    X43                  R191 -1
    X43                  R196 -1
    X43                  R201 -1
    X43                  R204 -1
    X43                  R205 -1
    X43                  R207 -1
    X43                  R208 -1
    X43                  R211 -1
    X43                  R213 -1
    X43                  R215 -1
    X43                  R216 -1
    X43                  R220 -1
    X43                  R221 -1
    X43                  R229 -1
    X43                  R230 -1
    X43                  R232 -1
    X43                  R234 -1
    X43                  R236 -1
    X43                  R239 -1
    X43                  R242 -1
    X43                  R243 -1
    X43                  R247 -1
    X43                  R249 -1
    X43                  R250 -1
    X43                  R255 -1
    X43                  R256 -1
    X43                  R257 -1
    X43                  R260 -1
    X43                  R262 -1
    X43                  R263 -1
    X43                  R264 -1
    X43                  R265 -1
    X43                  R267 -1
    X43                  R270 -1
    X43                  R272 -1
    X43                  R273 -1
    X43                  R274 -1
    X43                  R275 -1
    X43                  R276 -1
    X43                  R277 -1
    X43                  R279 -1
    X43                  R281 -1
    X43                  R283 -1
    X43                  R284 -1
    X43                  R285 -1
    X43                  R286 -1
    X43                  R288 -1
    X43                  R289 -1
    X43                  R290 -1
    X43                  R292 -1
    X43                  R295 -1
    X43                  R296 -1
    X43                  R299 -1
    X43                  R308 -1
    X43                  R312 -1
    X43                  R316 -1
    X43                  R317 -1
    X43                  R320 -1
    X43                  R324 -1
    X43                  R327 -1
    X43                  R329 -1
    X43                  R332 -1
    X43                  R334 -1
    X43                  R335 -1
    X43                  R336 -1
    X43                  R340 -1
    X43                  R344 -1
    X43                  R346 -1
    X43                  R347 -1
    X43                  R354 -1
    X43                  R357 -1
    X43                  R358 -1
    X43                  R359 -1
    X43                  R360 -1
    X43                  R364 -1
    X43                  R367 -1
    X43                  R372 -1
    X43                  R376 -1
    X43                  R380 -1
    X43                  R382 -1
    X43                  R389 -1
    X43                  R391 -1
    X43                  R392 -1
    X43                  R397 -1
    X43                  R398 -1
    X43                  R399 -1
    X43                  R400 -1
    X43                  R405 -1
    X43                  R407 -1
    X43                  R409 -1
    X43                  R411 -1
    X43                  R417 -1
    X43                  R421 -1
    X43                  R424 -1
    X43                  R428 -1
    X43                  R429 -1
    X43                  R431 -1
    X43                  R434 -1
    X43                  R435 -1
    X43                  R436 -1
    X43                  R438 -1
    X43                  R443 -1
    X43                  R446 -1
    X43                  R447 -1
    X43                  R450 -1
    X43                  R451 -1
    X43                  R455 -1
    X43                  R456 -1
    X43                  R457 -1
    X43                  R458 -1
    X43                  R459 -1
    X43                  R460 -1
    X43                  R461 -1
    X43                  R463 -1
    X43                  R464 -1
    X43                  R468 -1
    X43                  R469 -1
    X43                  R474 -1
    X43                  R476 -1
    X43                  R478 -1
    X43                  R479 -1
    X43                  R483 -1
    X43                  R484 -1
    X43                  R485 1
    X44                  OBJ 0
    X44                  R19 -1
    X44                  R25 -1
    X44                  R42 -1
    X44                  R46 -1
    X44                  R119 -1
    X44                  R162 -1
    X44                  R210 -1
    X44                  R222 -1
    X44                  R238 -1
    X44                  R259 -1
    X44                  R282 -1
    X44                  R351 -1
    X44                  R352 -1
    X44                  R413 -1
    X44                  R415 -1
    X44                  R431 -1
    X44                  R438 -1
    X44                  R468 -1
    X44                  R485 1
    X45                  OBJ 0
    X45                  R0 -1
    X45                  R1 -1
    X45                  R4 -1
    X45                  R5 -1
    X45                  R7 -1
    X45                  R8 -1
    X45                  R11 -1
    X45                  R13 -1
    X45                  R14 -1
    X45                  R18 -1
    X45                  R21 -1
    X45                  R24 -1
    X45                  R30 -1
    X45                  R31 -1
    X45                  R32 -1
    X45                  R36 -1
    X45                  R37 -1
    X45                  R38 -1
    X45                  R39 -1
    X45                  R40 -1
    X45                  R50 -1
    X45                  R51 -1
    X45                  R54 -1
    X45                  R56 -1
    X45                  R57 -1
    X45                  R59 -1
    X45                  R60 -1
    X45                  R61 -1
    X45                  R62 -1
    X45                  R63 -1
    X45                  R68 -1
    X45                  R73 -1
    X45                  R76 -1
    X45                  R79 -1
    X45                  R92 -1
    X45                  R96 -1
    X45                  R97 -1
    X45                  R98 -1
    X45                  R100 -1
    X45                  R103 -1
    X45                  R104 -1
    X45                  R107 -1
    X45                  R108 -1
    X45                  R110 -1
    X45                  R112 -1
    X45                  R114 -1
    X45                  R117 -1
    X45                  R118 -1
    X45                  R124 -1
    X45                  R125 -1
    X45                  R128 -1
    X45                  R132 -1
    X45                  R135 -1
    X45                  R138 -1
    X45                  R141 -1
    X45                  R143 -1
    X45                  R144 -1
    X45                  R146 -1
    X45                  R147 -1
    X45                  R149 -1
    X45                  R150 -1
    X45                  R151 -1
    X45                  R152 -1
    X45                  R153 -1
    X45                  R155 -1
    X45                  R156 -1
    X45                  R157 -1
    X45                  R159 -1
    X45                  R160 -1
    X45                  R161 -1
    X45                  R162 -1
    X45                  R164 -1
    X45                  R166 -1
    X45                  R167 -1
    X45                  R174 -1
    X45                  R175 -1
    X45                  R176 -1
    X45                  R177 -1
    X45                  R179 -1
    X45                  R183 -1
    X45                  R189 -1
    X45                  R193 -1
    X45                  R194 -1
    X45                  R195 -1
    X45                  R198 -1
    X45                  R202 -1
    X45                  R203 -1
    X45                  R206 -1
    X45                  R211 -1
    X45                  R216 -1
    X45                  R219 -1
    X45                  R220 -1
    X45                  R222 -1
    X45                  R223 -1
    X45                  R224 -1
    X45                  R226 -1
    X45                  R229 -1
    X45                  R230 -1
    X45                  R232 -1
    X45                  R235 -1
    X45                  R236 -1
    X45                  R239 -1
    X45                  R243 -1
    X45                  R244 -1
    X45                  R248 -1
    X45                  R249 -1
    X45                  R250 -1
    X45                  R251 -1
    X45                  R257 -1
    X45                  R260 -1
    X45                  R265 -1
    X45                  R268 -1
    X45                  R270 -1
    X45                  R271 -1
    X45                  R277 -1
    X45                  R280 -1
    X45                  R282 -1
    X45                  R285 -1
    X45                  R286 -1
    X45                  R287 -1
    X45                  R288 -1
    X45                  R289 -1
    X45                  R291 -1
    X45                  R297 -1
    X45                  R298 -1
    X45                  R304 -1
    X45                  R306 -1
    X45                  R310 -1
    X45                  R313 -1
    X45                  R315 -1
    X45                  R316 -1
    X45                  R317 -1
    X45                  R319 -1
    X45                  R320 -1
    X45                  R327 -1
    X45                  R329 -1
    X45                  R332 -1
    X45                  R333 -1
    X45                  R334 -1
    X45                  R338 -1
    X45                  R340 -1
    X45                  R343 -1
    X45                  R344 -1
    X45                  R349 -1
    X45                  R356 -1
    X45                  R357 -1
    X45                  R358 -1
    X45                  R359 -1
    X45                  R360 -1
    X45                  R361 -1
    X45                  R363 -1
    X45                  R365 -1
    X45                  R366 -1
    X45                  R367 -1
    X45                  R374 -1
    X45                  R376 -1
    X45                  R377 -1
    X45                  R387 -1
    X45                  R389 -1
    X45                  R390 -1
    X45                  R392 -1
    X45                  R393 -1
    X45                  R396 -1
    X45                  R397 -1
    X45                  R399 -1
    X45                  R400 -1
    X45                  R403 -1
    X45                  R404 -1
    X45                  R410 -1
    X45                  R415 -1
    X45                  R417 -1
    X45                  R419 -1
    X45                  R421 -1
    X45                  R423 -1
    X45                  R424 -1
    X45                  R425 -1
    X45                  R427 -1
    X45                  R428 -1
    X45                  R429 -1
    X45                  R432 -1
    X45                  R434 -1
    X45                  R435 -1
    X45                  R436 -1
    X45                  R441 -1
    X45                  R444 -1
    X45                  R446 -1
    X45                  R447 -1
    X45                  R455 -1
    X45                  R461 -1
    X45                  R464 -1
    X45                  R467 -1
    X45                  R469 -1
    X45                  R472 -1
    X45                  R476 -1
    X45                  R477 -1
    X45                  R478 -1
    X45                  R479 -1
    X45                  R481 -1
    X45                  R485 1
    X46                  OBJ 0
    X46                  R4 -1
    X46                  R5 -1
    X46                  R6 -1
    X46                  R17 -1
    X46                  R24 -1
    X46                  R33 -1
    X46                  R56 -1
    X46                  R94 -1
    X46                  R97 -1
    X46                  R102 -1
    X46                  R107 -1
    X46                  R144 -1
    X46                  R150 -1
    X46                  R182 -1
    X46                  R189 -1
    X46                  R203 -1
    X46                  R210 -1
    X46                  R211 -1
    X46                  R216 -1
    X46                  R220 -1
    X46                  R234 -1
    X46                  R237 -1
    X46                  R251 -1
    X46                  R252 -1
    X46                  R261 -1
    X46                  R266 -1
    X46                  R268 -1
    X46                  R277 -1
    X46                  R280 -1
    X46                  R288 -1
    X46                  R294 -1
    X46                  R298 -1
    X46                  R312 -1
    X46                  R313 -1
    X46                  R326 -1
    X46                  R327 -1
    X46                  R328 -1
    X46                  R347 -1
    X46                  R357 -1
    X46                  R366 -1
    X46                  R385 -1
    X46                  R399 -1
    X46                  R412 -1
    X46                  R420 -1
    X46                  R428 -1
    X46                  R432 -1
    X46                  R442 -1
    X46                  R446 -1
    X46                  R455 -1
    X46                  R467 -1
    X46                  R470 -1
    X46                  R479 -1
    X46                  R485 1
    X47                  OBJ 0
    X47                  R0 -1
    X47                  R5 -1
    X47                  R29 -1
    X47                  R36 -1
    X47                  R57 -1
    X47                  R59 -1
    X47                  R93 -1
    X47                  R162 -1
    X47                  R166 -1
    X47                  R228 -1
    X47                  R277 -1
    X47                  R322 -1
    X47                  R333 -1
    X47                  R334 -1
    X47                  R339 -1
    X47                  R369 -1
    X47                  R427 -1
    X47                  R453 -1
    X47                  R463 -1
    X47                  R485 1
    X48                  OBJ 0
    X48                  R3 -1
    X48                  R4 -1
    X48                  R7 -1
    X48                  R13 -1
    X48                  R20 -1
    X48                  R24 -1
    X48                  R27 -1
    X48                  R28 -1
    X48                  R38 -1
    X48                  R40 -1
    X48                  R49 -1
    X48                  R52 -1
    X48                  R56 -1
    X48                  R79 -1
    X48                  R82 -1
    X48                  R86 -1
    X48                  R93 -1
    X48                  R94 -1
    X48                  R101 -1
    X48                  R107 -1
    X48                  R108 -1
    X48                  R109 -1
    X48                  R112 -1
    X48                  R113 -1
    X48                  R116 -1
    X48                  R117 -1
    X48                  R121 -1
    X48                  R122 -1
    X48                  R123 -1
    X48                  R129 -1
    X48                  R139 -1
    X48                  R141 -1
    X48                  R142 -1
    X48                  R143 -1
    X48                  R147 -1
    X48                  R151 -1
    X48                  R154 -1
    X48                  R160 -1
    X48                  R163 -1
    X48                  R166 -1
    X48                  R169 -1
    X48                  R173 -1
    X48                  R183 -1
    X48                  R191 -1
    X48                  R192 -1
    X48                  R200 -1
    X48                  R212 -1
    X48                  R213 -1
    X48                  R217 -1
    X48                  R220 -1
    X48                  R223 -1
    X48                  R225 -1
    X48                  R235 -1
    X48                  R237 -1
    X48                  R241 -1
    X48                  R243 -1
    X48                  R248 -1
    X48                  R257 -1
    X48                  R264 -1
    X48                  R278 -1
    X48                  R279 -1
    X48                  R283 -1
    X48                  R285 -1
    X48                  R289 -1
    X48                  R293 -1
    X48                  R303 -1
    X48                  R314 -1
    X48                  R317 -1
    X48                  R320 -1
    X48                  R326 -1
    X48                  R327 -1
    X48                  R328 -1
    X48                  R343 -1
    X48                  R349 -1
    X48                  R352 -1
    X48                  R357 -1
    X48                  R359 -1
    X48                  R372 -1
    X48                  R375 -1
    X48                  R376 -1
    X48                  R377 -1
    X48                  R378 -1
    X48                  R390 -1
    X48                  R397 -1
    X48                  R399 -1
    X48                  R400 -1
    X48                  R401 -1
    X48                  R406 -1
    X48                  R407 -1
    X48                  R409 -1
    X48                  R410 -1
    X48                  R414 -1
    X48                  R418 -1
    X48                  R425 -1
    X48                  R429 -1
    X48                  R437 -1
    X48                  R438 -1
    X48                  R439 -1
    X48                  R443 -1
    X48                  R445 -1
    X48                  R446 -1
    X48                  R447 -1
    X48                  R448 -1
    X48                  R450 -1
    X48                  R455 -1
    X48                  R458 -1
    X48                  R464 -1
    X48                  R475 -1
    X48                  R479 -1
    X48                  R485 1
    X49                  OBJ 0
    X49                  R0 -1
    X49                  R1 -1
    X49                  R2 -1
    X49                  R3 -1
    X49                  R4 -1
    X49                  R5 -1
    X49                  R6 -1
    X49                  R7 -1
    X49                  R8 -1
    X49                  R9 -1
    X49                  R10 -1
    X49                  R11 -1
    X49                  R12 -1
    X49                  R13 -1
    X49                  R14 -1
    X49                  R15 -1
    X49                  R16 -1
    X49                  R17 -1
    X49                  R18 -1
    X49                  R19 -1
    X49                  R20 -1
    X49                  R21 -1
    X49                  R22 -1
    X49                  R23 -1
    X49                  R24 -1
    X49                  R25 -1
    X49                  R26 -1
    X49                  R27 -1
    X49                  R28 -1
    X49                  R29 -1
    X49                  R30 -1
    X49                  R31 -1
    X49                  R32 -1
    X49                  R33 -1
    X49                  R34 -1
    X49                  R35 -1
    X49                  R36 -1
    X49                  R37 -1
    X49                  R38 -1
    X49                  R39 -1
    X49                  R40 -1
    X49                  R41 -1
    X49                  R42 -1
    X49                  R43 -1
    X49                  R44 -1
    X49                  R45 -1
    X49                  R46 -1
    X49                  R47 -1
    X49                  R48 -1
    X49                  R49 -1
    X49                  R50 -1
    X49                  R51 -1
    X49                  R52 -1
    X49                  R53 -1
    X49                  R54 -1
    X49                  R55 -1
    X49                  R56 -1
    X49                  R57 -1
    X49                  R58 -1
    X49                  R59 -1
    X49                  R60 -1
    X49                  R61 -1
    X49                  R62 -1
    X49                  R63 -1
    X49                  R64 -1
    X49                  R65 -1
    X49                  R66 -1
    X49                  R67 -1
    X49                  R68 -1
    X49                  R69 -1
    X49                  R70 -1
    X49                  R71 -1
    X49                  R72 -1
    X49                  R73 -1
    X49                  R74 -1
    X49                  R75 -1
    X49                  R76 -1
    X49                  R77 -1
    X49                  R78 -1
    X49                  R79 -1
    X49                  R80 -1
    X49                  R81 -1
    X49                  R82 -1
    X49                  R83 -1
    X49                  R84 -1
    X49                  R85 -1
    X49                  R86 -1
    X49                  R87 -1
    X49                  R88 -1
    X49                  R89 -1
    X49                  R90 -1
    X49                  R91 -1
    X49                  R92 -1
    X49                  R93 -1
    X49                  R94 -1
    X49                  R95 -1
    X49                  R96 -1
    X49                  R97 -1
    X49                  R98 -1
    X49                  R99 -1
    X49                  R100 -1
    X49                  R101 -1
    X49                  R102 -1
    X49                  R103 -1
    X49                  R104 -1
    X49                  R105 -1
    X49                  R106 -1
    X49                  R107 -1
    X49                  R108 -1
    X49                  R109 -1
    X49                  R110 -1
    X49                  R111 -1
    X49                  R112 -1
    X49                  R113 -1
    X49                  R114 -1
    X49                  R115 -1
    X49                  R116 -1
    X49                  R117 -1
    X49                  R118 -1
    X49                  R119 -1
    X49                  R120 -1
    X49                  R121 -1
    X49                  R122 -1
    X49                  R123 -1
    X49                  R124 -1
    X49                  R125 -1
    X49                  R126 -1
    X49                  R127 -1
    X49                  R128 -1
    X49                  R129 -1
    X49                  R130 -1
    X49                  R131 -1
    X49                  R132 -1
    X49                  R133 -1
    X49                  R134 -1
    X49                  R135 -1
    X49                  R136 -1
    X49                  R137 -1
    X49                  R138 -1
    X49                  R139 -1
    X49                  R140 -1
    X49                  R141 -1
    X49                  R142 -1
    X49                  R143 -1
    X49                  R144 -1
    X49                  R145 -1
    X49                  R146 -1
    X49                  R147 -1
    X49                  R148 -1
    X49                  R149 -1
    X49                  R150 -1
    X49                  R151 -1
    X49                  R152 -1
    X49                  R153 -1
    X49                  R154 -1
    X49                  R155 -1
    X49                  R156 -1
    X49                  R157 -1
    X49                  R158 -1
    X49                  R159 -1
    X49                  R160 -1
    X49                  R161 -1
    X49                  R162 -1
    X49                  R163 -1
    X49                  R164 -1
    X49                  R165 -1
    X49                  R166 -1
    X49                  R167 -1
    X49                  R168 -1
    X49                  R169 -1
    X49                  R170 -1
    X49                  R171 -1
    X49                  R172 -1
    X49                  R173 -1
    X49                  R174 -1
    X49                  R175 -1
    X49                  R176 -1
    X49                  R177 -1
    X49                  R178 -1
    X49                  R179 -1
    X49                  R180 -1
    X49                  R181 -1
    X49                  R182 -1
    X49                  R183 -1
    X49                  R184 -1
    X49                  R185 -1
    X49                  R186 -1
    X49                  R187 -1
    X49                  R188 -1
    X49                  R189 -1
    X49                  R190 -1
    X49                  R191 -1
    X49                  R192 -1
    X49                  R193 -1
    X49                  R194 -1
    X49                  R195 -1
    X49                  R196 -1
    X49                  R197 -1
    X49                  R198 -1
    X49                  R199 -1
    X49                  R200 -1
    X49                  R201 -1
    X49                  R202 -1
    X49                  R203 -1
    X49                  R204 -1
    X49                  R205 -1
    X49                  R206 -1
    X49                  R207 -1
    X49                  R208 -1
    X49                  R209 -1
    X49                  R210 -1
    X49                  R211 -1
    X49                  R212 -1
    X49                  R213 -1
    X49                  R214 -1
    X49                  R215 -1
    X49                  R216 -1
    X49                  R217 -1
    X49                  R218 -1
    X49                  R219 -1
    X49                  R220 -1
    X49                  R221 -1
    X49                  R222 -1
    X49                  R223 -1
    X49                  R224 -1
    X49                  R225 -1
    X49                  R226 -1
    X49                  R227 -1
    X49                  R228 -1
    X49                  R229 -1
    X49                  R230 -1
    X49                  R231 -1
    X49                  R232 -1
    X49                  R233 -1
    X49                  R234 -1
    X49                  R235 -1
    X49                  R236 -1
    X49                  R237 -1
    X49                  R238 -1
    X49                  R239 -1
    X49                  R240 -1
    X49                  R241 -1
    X49                  R242 -1
    X49                  R243 -1
    X49                  R244 -1
    X49                  R245 -1
    X49                  R246 -1
    X49                  R247 -1
    X49                  R248 -1
    X49                  R249 -1
    X49                  R250 -1
    X49                  R251 -1
    X49                  R252 -1
    X49                  R253 -1
    X49                  R254 -1
    X49                  R255 -1
    X49                  R256 -1
    X49                  R257 -1
    X49                  R258 -1
    X49                  R259 -1
    X49                  R260 -1
    X49                  R261 -1
    X49                  R262 -1
    X49                  R263 -1
    X49                  R264 -1
    X49                  R265 -1
    X49                  R266 -1
    X49                  R267 -1
    X49                  R268 -1
    X49                  R269 -1
    X49                  R270 -1
    X49                  R271 -1
    X49                  R272 -1
    X49                  R273 -1
    X49                  R274 -1
    X49                  R275 -1
    X49                  R276 -1
    X49                  R277 -1
    X49                  R278 -1
    X49                  R279 -1
    X49                  R280 -1
    X49                  R281 -1
    X49                  R282 -1
    X49                  R283 -1
    X49                  R284 -1
    X49                  R285 -1
    X49                  R286 -1
    X49                  R287 -1
    X49                  R288 -1
    X49                  R289 -1
    X49                  R290 -1
    X49                  R291 -1
    X49                  R292 -1
    X49                  R293 -1
    X49                  R294 -1
    X49                  R295 -1
    X49                  R296 -1
    X49                  R297 -1
    X49                  R298 -1
    X49                  R299 -1
    X49                  R300 -1
    X49                  R301 -1
    X49                  R302 -1
    X49                  R303 -1
    X49                  R304 -1
    X49                  R305 -1
    X49                  R306 -1
    X49                  R307 -1
    X49                  R308 -1
    X49                  R309 -1
    X49                  R310 -1
    X49                  R311 -1
    X49                  R312 -1
    X49                  R313 -1
    X49                  R314 -1
    X49                  R315 -1
    X49                  R316 -1
    X49                  R317 -1
    X49                  R318 -1
    X49                  R319 -1
    X49                  R320 -1
    X49                  R321 -1
    X49                  R322 -1
    X49                  R323 -1
    X49                  R324 -1
    X49                  R325 -1
    X49                  R326 -1
    X49                  R327 -1
    X49                  R328 -1
    X49                  R329 -1
    X49                  R330 -1
    X49                  R331 -1
    X49                  R332 -1
    X49                  R333 -1
    X49                  R334 -1
    X49                  R335 -1
    X49                  R336 -1
    X49                  R337 -1
    X49                  R338 -1
    X49                  R339 -1
    X49                  R340 -1
    X49                  R341 -1
    X49                  R342 -1
    X49                  R343 -1
    X49                  R344 -1
    X49                  R345 -1
    X49                  R346 -1
    X49                  R347 -1
    X49                  R348 -1
    X49                  R349 -1
    X49                  R350 -1
    X49                  R351 -1
    X49                  R352 -1
    X49                  R353 -1
    X49                  R354 -1
    X49                  R355 -1
    X49                  R356 -1
    X49                  R357 -1
    X49                  R358 -1
    X49                  R359 -1
    X49                  R360 -1
    X49                  R361 -1
    X49                  R362 -1
    X49                  R363 -1
    X49                  R364 -1
    X49                  R365 -1
    X49                  R366 -1
    X49                  R367 -1
    X49                  R368 -1
    X49                  R369 -1
    X49                  R370 -1
    X49                  R371 -1
    X49                  R372 -1
    X49                  R373 -1
    X49                  R374 -1
    X49                  R375 -1
    X49                  R376 -1
    X49                  R377 -1
    X49                  R378 -1
    X49                  R379 -1
    X49                  R380 -1
    X49                  R381 -1
    X49                  R382 -1
    X49                  R383 -1
    X49                  R384 -1
    X49                  R385 -1
    X49                  R386 -1
    X49                  R387 -1
    X49                  R388 -1
    X49                  R389 -1
    X49                  R390 -1
    X49                  R391 -1
    X49                  R392 -1
    X49                  R393 -1
    X49                  R394 -1
    X49                  R395 -1
    X49                  R396 -1
    X49                  R397 -1
    X49                  R398 -1
    X49                  R399 -1
    X49                  R400 -1
    X49                  R401 -1
    X49                  R402 -1
    X49                  R403 -1
    X49                  R404 -1
    X49                  R405 -1
    X49                  R406 -1
    X49                  R407 -1
    X49                  R408 -1
    X49                  R409 -1
    X49                  R410 -1
    X49                  R411 -1
    X49                  R412 -1
    X49                  R413 -1
    X49                  R414 -1
    X49                  R415 -1
    X49                  R416 -1
    X49                  R417 -1
    X49                  R418 -1
    X49                  R419 -1
    X49                  R420 -1
    X49                  R421 -1
    X49                  R422 -1
    X49                  R423 -1
    X49                  R424 -1
    X49                  R425 -1
    X49                  R426 -1
    X49                  R427 -1
    X49                  R428 -1
    X49                  R429 -1
    X49                  R430 -1
    X49                  R431 -1
    X49                  R432 -1
    X49                  R433 -1
    X49                  R434 -1
    X49                  R435 -1
    X49                  R436 -1
    X49                  R437 -1
    X49                  R438 -1
    X49                  R439 -1
    X49                  R440 -1
    X49                  R441 -1
    X49                  R442 -1
    X49                  R443 -1
    X49                  R444 -1
    X49                  R445 -1
    X49                  R446 -1
    X49                  R447 -1
    X49                  R448 -1
    X49                  R449 -1
    X49                  R450 -1
    X49                  R451 -1
    X49                  R452 -1
    X49                  R453 -1
    X49                  R454 -1
    X49                  R455 -1
    X49                  R456 -1
    X49                  R457 -1
    X49                  R458 -1
    X49                  R459 -1
    X49                  R460 -1
    X49                  R461 -1
    X49                  R462 -1
    X49                  R463 -1
    X49                  R464 -1
    X49                  R465 -1
    X49                  R466 -1
    X49                  R467 -1
    X49                  R468 -1
    X49                  R469 -1
    X49                  R470 -1
    X49                  R471 -1
    X49                  R472 -1
    X49                  R473 -1
    X49                  R474 -1
    X49                  R475 -1
    X49                  R476 -1
    X49                  R477 -1
    X49                  R478 -1
    X49                  R479 -1
    X49                  R480 -1
    X49                  R481 -1
    X49                  R482 -1
    X49                  R483 -1
    X49                  R484 -1
    X49                  R485 1
    X50                  OBJ 0.00044999999999999999
    X50                  R0 -1.0009999999999999
    X51                  OBJ 0.00044999999999999999
    X51                  R1 -1.0009999999999999
    X52                  OBJ 0.00088999999999999995
    X52                  R2 -1.0009999999999999
    X53                  OBJ 0.00044999999999999999
    X53                  R3 -1.0009999999999999
    X54                  OBJ 0.00044999999999999999
    X54                  R4 -1.0009999999999999
    X55                  OBJ 0.00044999999999999999
    X55                  R5 -1.0009999999999999
    X56                  OBJ 0.00134
    X56                  R6 -1.0009999999999999
    X57                  OBJ 0.00044999999999999999
    X57                  R7 -1.0009999999999999
    X58                  OBJ 0.014250000000000001
    X58                  R8 -1.0009999999999999
    X59                  OBJ 0.0022300000000000002
    X59                  R9 -1.0009999999999999
    X60                  OBJ 0.00044999999999999999
    X60                  R10 -1.0009999999999999
    X61                  OBJ 0.00044999999999999999
    X61                  R11 -1.0009999999999999
    X62                  OBJ 0.0026700000000000001
    X62                  R12 -1.0009999999999999
    X63                  OBJ 0.00044999999999999999
    X63                  R13 -1.0009999999999999
    X64                  OBJ 0.020480000000000002
    X64                  R14 -1.0009999999999999
    X65                  OBJ 0.27015
    X65                  R15 -1.0009999999999999
    X66                  OBJ 0.00044999999999999999
    X66                  R16 -1.0009999999999999
    X67                  OBJ 0.00044999999999999999
    X67                  R17 -1.0009999999999999
    X68                  OBJ 0.0017799999999999999
    X68                  R18 -1.0009999999999999
    X69                  OBJ 0.00044999999999999999
    X69                  R19 -1.0009999999999999
    X70                  OBJ 0.00044999999999999999
    X70                  R20 -1.0009999999999999
    X71                  OBJ 0.017229999999999999
    X71                  R21 1.0009999999999999
    X72                  OBJ 0.072569999999999996
    X72                  R22 -1.0009999999999999
    X73                  OBJ 0.01336
    X73                  R23 -1.0009999999999999
    X74                  OBJ 0.00044999999999999999
    X74                  R24 -1.0009999999999999
    X75                  OBJ 0.00044999999999999999
    X75                  R25 -1.0009999999999999
    X76                  OBJ 0.00088999999999999995
    X76                  R26 -1.0009999999999999
    X77                  OBJ 0.01302
    X77                  R27 1.0009999999999999
    X78                  OBJ 0.01158
    X78                  R28 -1.0009999999999999
    X79                  OBJ 0.00044999999999999999
    X79                  R29 -1.0009999999999999
    X80                  OBJ 0.00044999999999999999
    X80                  R30 -1.0009999999999999
    X81                  OBJ 0.0048999999999999998
    X81                  R31 -1.0009999999999999
    X82                  OBJ 0.0026700000000000001
    X82                  R32 -1.0009999999999999
    X83                  OBJ 0.00044999999999999999
    X83                  R33 -1.0009999999999999
    X84                  OBJ 0.0035599999999999998
    X84                  R34 -1.0009999999999999
    X85                  OBJ 0.024930000000000001
    X85                  R35 -1.0009999999999999
    X86                  OBJ 0.00044999999999999999
    X86                  R36 -1.0009999999999999
    X87                  OBJ 0.00044999999999999999
    X87                  R37 -1.0009999999999999
    X88                  OBJ 0.00044999999999999999
    X88                  R38 -1.0009999999999999
    X89                  OBJ 0.00088999999999999995
    X89                  R39 -1.0009999999999999
    X90                  OBJ 0.00044999999999999999
    X90                  R40 -1.0009999999999999
    X91                  OBJ 0.016469999999999999
    X91                  R41 -1.0009999999999999
    X92                  OBJ 0.0022300000000000002
    X92                  R42 -1.0009999999999999
    X93                  OBJ 0.033599999999999998
    X93                  R43 1.0009999999999999
    X94                  OBJ 0.00044999999999999999
    X94                  R44 -1.0009999999999999
    X95                  OBJ 0.0017799999999999999
    X95                  R45 -1.0009999999999999
    X96                  OBJ 0.022370000000000001
    X96                  R46 1.0009999999999999
    X97                  OBJ 0.00044999999999999999
    X97                  R47 -1.0009999999999999
    X98                  OBJ 0.00134
    X98                  R48 -1.0009999999999999
    X99                  OBJ 0.00088999999999999995
    X99                  R49 -1.0009999999999999
    X100                 OBJ 0.00088999999999999995
    X100                 R50 -1.0009999999999999
    X101                 OBJ 0.00044999999999999999
    X101                 R51 -1.0009999999999999
    X102                 OBJ 0.00044999999999999999
    X102                 R52 -1.0009999999999999
    X103                 OBJ 0.00044999999999999999
    X103                 R53 -1.0009999999999999
    X104                 OBJ 0.00044999999999999999
    X104                 R54 -1.0009999999999999
    X105                 OBJ 0.00044999999999999999
    X105                 R55 -1.0009999999999999
    X106                 OBJ 0.00044999999999999999
    X106                 R56 -1.0009999999999999
    X107                 OBJ 0.02281
    X107                 R57 1.0009999999999999
    X108                 OBJ 0.0084600000000000005
    X108                 R58 -1.0009999999999999
    X109                 OBJ 0.00044999999999999999
    X109                 R59 -1.0009999999999999
    X110                 OBJ 0.0017799999999999999
    X110                 R60 -1.0009999999999999
    X111                 OBJ 0.00044999999999999999
    X111                 R61 -1.0009999999999999
    X112                 OBJ 0.0031199999999999999
    X112                 R62 -1.0009999999999999
    X113                 OBJ 0.00044999999999999999
    X113                 R63 -1.0009999999999999
    X114                 OBJ 0.00044999999999999999
    X114                 R64 -1.0009999999999999
    X115                 OBJ 0.00088999999999999995
    X115                 R65 -1.0009999999999999
    X116                 OBJ 0.0017799999999999999
    X116                 R66 -1.0009999999999999
    X117                 OBJ 0.00134
    X117                 R67 -1.0009999999999999
    X118                 OBJ 0.00088999999999999995
    X118                 R68 -1.0009999999999999
    X119                 OBJ 0.00134
    X119                 R69 -1.0009999999999999
    X120                 OBJ 0.00044999999999999999
    X120                 R70 -1.0009999999999999
    X121                 OBJ 0.00044999999999999999
    X121                 R71 -1.0009999999999999
    X122                 OBJ 0.00044999999999999999
    X122                 R72 -1.0009999999999999
    X123                 OBJ 0.00044999999999999999
    X123                 R73 -1.0009999999999999
    X124                 OBJ 0.027060000000000001
    X124                 R74 -1.0009999999999999
    X125                 OBJ 0.061859999999999998
    X125                 R75 1.0009999999999999
    X126                 OBJ 0.00044999999999999999
    X126                 R76 -1.0009999999999999
    X127                 OBJ 0.0017799999999999999
    X127                 R77 -1.0009999999999999
    X128                 OBJ 0.00044999999999999999
    X128                 R78 -1.0009999999999999
    X129                 OBJ 0.023259999999999999
    X129                 R79 1.0009999999999999
    X130                 OBJ 0.00044999999999999999
    X130                 R80 -1.0009999999999999
    X131                 OBJ 0.00044999999999999999
    X131                 R81 -1.0009999999999999
    X132                 OBJ 0.00044999999999999999
    X132                 R82 -1.0009999999999999
    X133                 OBJ 0.00134
    X133                 R83 -1.0009999999999999
    X134                 OBJ 0.020140000000000002
    X134                 R84 1.0009999999999999
    X135                 OBJ 0.0022300000000000002
    X135                 R85 -1.0009999999999999
    X136                 OBJ 0.00044999999999999999
    X136                 R86 -1.0009999999999999
    X137                 OBJ 0.0017799999999999999
    X137                 R87 -1.0009999999999999
    X138                 OBJ 0.00134
    X138                 R88 -1.0009999999999999
    X139                 OBJ 0.00044999999999999999
    X139                 R89 -1.0009999999999999
    X140                 OBJ 0.00134
    X140                 R90 -1.0009999999999999
    X141                 OBJ 0.00579
    X141                 R91 -1.0009999999999999
    X142                 OBJ 0.0031199999999999999
    X142                 R92 -1.0009999999999999
    X143                 OBJ 0.00044999999999999999
    X143                 R93 -1.0009999999999999
    X144                 OBJ 0.00044999999999999999
    X144                 R94 -1.0009999999999999
    X145                 OBJ 0.00579
    X145                 R95 -1.0009999999999999
    X146                 OBJ 0.00044999999999999999
    X146                 R96 -1.0009999999999999
    X147                 OBJ 0.00044999999999999999
    X147                 R97 -1.0009999999999999
    X148                 OBJ 0.00088999999999999995
    X148                 R98 -1.0009999999999999
    X149                 OBJ 0.015689999999999999
    X149                 R99 1.0009999999999999
    X150                 OBJ 0.00044999999999999999
    X150                 R100 -1.0009999999999999
    X151                 OBJ 0.0035599999999999998
    X151                 R101 -1.0009999999999999
    X152                 OBJ 0.021919999999999999
    X152                 R102 1.0009999999999999
    X153                 OBJ 0.00044999999999999999
    X153                 R103 -1.0009999999999999
    X154                 OBJ 0.0026700000000000001
    X154                 R104 -1.0009999999999999
    X155                 OBJ 0.0075700000000000003
    X155                 R105 -1.0009999999999999
    X156                 OBJ 0.023259999999999999
    X156                 R106 1.0009999999999999
    X157                 OBJ 0.00044999999999999999
    X157                 R107 -1.0009999999999999
    X158                 OBJ 0.0035599999999999998
    X158                 R108 -1.0009999999999999
    X159                 OBJ 0.00088999999999999995
    X159                 R109 -1.0009999999999999
    X160                 OBJ 0.00088999999999999995
    X160                 R110 -1.0009999999999999
    X161                 OBJ 0.0017799999999999999
    X161                 R111 -1.0009999999999999
    X162                 OBJ 0.00044999999999999999
    X162                 R112 -1.0009999999999999
    X163                 OBJ 0.00088999999999999995
    X163                 R113 -1.0009999999999999
    X164                 OBJ 0.00044999999999999999
    X164                 R114 -1.0009999999999999
    X165                 OBJ 0.0040099999999999997
    X165                 R115 -1.0009999999999999
    X166                 OBJ 0.023259999999999999
    X166                 R116 1.0009999999999999
    X167                 OBJ 0.00044999999999999999
    X167                 R117 -1.0009999999999999
    X168                 OBJ 0.00044999999999999999
    X168                 R118 -1.0009999999999999
    X169                 OBJ 0.00044999999999999999
    X169                 R119 -1.0009999999999999
    X170                 OBJ 0.023259999999999999
    X170                 R120 1.0009999999999999
    X171                 OBJ 0.02281
    X171                 R121 1.0009999999999999
    X172                 OBJ 0.00044999999999999999
    X172                 R122 -1.0009999999999999
    X173                 OBJ 0.00044999999999999999
    X173                 R123 -1.0009999999999999
    X174                 OBJ 0.023259999999999999
    X174                 R124 1.0009999999999999
    X175                 OBJ 0.00044999999999999999
    X175                 R125 -1.0009999999999999
    X176                 OBJ 0.0066800000000000002
    X176                 R126 -1.0009999999999999
    X177                 OBJ 0.00044999999999999999
    X177                 R127 -1.0009999999999999
    X178                 OBJ 0.0022300000000000002
    X178                 R128 -1.0009999999999999
    X179                 OBJ 0.00134
    X179                 R129 -1.0009999999999999
    X180                 OBJ 0.00044999999999999999
    X180                 R130 -1.0009999999999999
    X181                 OBJ 0.00134
    X181                 R131 -1.0009999999999999
    X182                 OBJ 0.00044999999999999999
    X182                 R132 -1.0009999999999999
    X183                 OBJ 0.00044999999999999999
    X183                 R133 -1.0009999999999999
    X184                 OBJ 0.0031199999999999999
    X184                 R134 -1.0009999999999999
    X185                 OBJ 0.0017799999999999999
    X185                 R135 -1.0009999999999999
    X186                 OBJ 0.00044999999999999999
    X186                 R136 -1.0009999999999999
    X187                 OBJ 0.00044999999999999999
    X187                 R137 -1.0009999999999999
    X188                 OBJ 0.00044999999999999999
    X188                 R138 -1.0009999999999999
    X189                 OBJ 0.00044999999999999999
    X189                 R139 -1.0009999999999999
    X190                 OBJ 0.0026700000000000001
    X190                 R140 -1.0009999999999999
    X191                 OBJ 0.00044999999999999999
    X191                 R141 -1.0009999999999999
    X192                 OBJ 0.00044999999999999999
    X192                 R142 -1.0009999999999999
    X193                 OBJ 0.00044999999999999999
    X193                 R143 -1.0009999999999999
    X194                 OBJ 0.00044999999999999999
    X194                 R144 -1.0009999999999999
    X195                 OBJ 0.00088999999999999995
    X195                 R145 -1.0009999999999999
    X196                 OBJ 0.00088999999999999995
    X196                 R146 -1.0009999999999999
    X197                 OBJ 0.00044999999999999999
    X197                 R147 -1.0009999999999999
    X198                 OBJ 0.00044999999999999999
    X198                 R148 -1.0009999999999999
    X199                 OBJ 0.00088999999999999995
    X199                 R149 -1.0009999999999999
    X200                 OBJ 0.00044999999999999999
    X200                 R150 -1.0009999999999999
    X201                 OBJ 0.00044999999999999999
    X201                 R151 -1.0009999999999999
    X202                 OBJ 0.00044999999999999999
    X202                 R152 -1.0009999999999999
    X203                 OBJ 0.0017799999999999999
    X203                 R153 -1.0009999999999999
    X204                 OBJ 0.00088999999999999995
    X204                 R154 -1.0009999999999999
    X205                 OBJ 0.0017799999999999999
    X205                 R155 -1.0009999999999999
    X206                 OBJ 0.00044999999999999999
    X206                 R156 -1.0009999999999999
    X207                 OBJ 0.00088999999999999995
    X207                 R157 -1.0009999999999999
    X208                 OBJ 0.00088999999999999995
    X208                 R158 -1.0009999999999999
    X209                 OBJ 0.00088999999999999995
    X209                 R159 -1.0009999999999999
    X210                 OBJ 0.00088999999999999995
    X210                 R160 -1.0009999999999999
    X211                 OBJ 0.0026700000000000001
    X211                 R161 -1.0009999999999999
    X212                 OBJ 0.00044999999999999999
    X212                 R162 -1.0009999999999999
    X213                 OBJ 0.00044999999999999999
    X213                 R163 -1.0009999999999999
    X214                 OBJ 0.00044999999999999999
    X214                 R164 -1.0009999999999999
    X215                 OBJ 0.00044999999999999999
    X215                 R165 -1.0009999999999999
    X216                 OBJ 0.00044999999999999999
    X216                 R166 -1.0009999999999999
    X217                 OBJ 0.00044999999999999999
    X217                 R167 -1.0009999999999999
    X218                 OBJ 0.00044999999999999999
    X218                 R168 -1.0009999999999999
    X219                 OBJ 0.00044999999999999999
    X219                 R169 -1.0009999999999999
    X220                 OBJ 0.00044999999999999999
    X220                 R170 -1.0009999999999999
    X221                 OBJ 0.0026700000000000001
    X221                 R171 -1.0009999999999999
    X222                 OBJ 0.0026700000000000001
    X222                 R172 -1.0009999999999999
    X223                 OBJ 0.00044999999999999999
    X223                 R173 -1.0009999999999999
    X224                 OBJ 0.00134
    X224                 R174 -1.0009999999999999
    X225                 OBJ 0.00044999999999999999
    X225                 R175 -1.0009999999999999
    X226                 OBJ 0.0017799999999999999
    X226                 R176 -1.0009999999999999
    X227                 OBJ 0.00044999999999999999
    X227                 R177 -1.0009999999999999
    X228                 OBJ 0.0040099999999999997
    X228                 R178 -1.0009999999999999
    X229                 OBJ 0.00044999999999999999
    X229                 R179 -1.0009999999999999
    X230                 OBJ 0.00088999999999999995
    X230                 R180 -1.0009999999999999
    X231                 OBJ 0.00044999999999999999
    X231                 R181 -1.0009999999999999
    X232                 OBJ 0.00044999999999999999
    X232                 R182 -1.0009999999999999
    X233                 OBJ 0.023259999999999999
    X233                 R183 1.0009999999999999
    X234                 OBJ 0.00088999999999999995
    X234                 R184 -1.0009999999999999
    X235                 OBJ 0.00044999999999999999
    X235                 R185 -1.0009999999999999
    X236                 OBJ 0.00044999999999999999
    X236                 R186 -1.0009999999999999
    X237                 OBJ 0.0022300000000000002
    X237                 R187 -1.0009999999999999
    X238                 OBJ 0.00044999999999999999
    X238                 R188 -1.0009999999999999
    X239                 OBJ 0.00044999999999999999
    X239                 R189 -1.0009999999999999
    X240                 OBJ 0.00088999999999999995
    X240                 R190 -1.0009999999999999
    X241                 OBJ 0.00044999999999999999
    X241                 R191 -1.0009999999999999
    X242                 OBJ 0.00088999999999999995
    X242                 R192 -1.0009999999999999
    X243                 OBJ 0.0017799999999999999
    X243                 R193 -1.0009999999999999
    X244                 OBJ 0.00044999999999999999
    X244                 R194 -1.0009999999999999
    X245                 OBJ 0.00044999999999999999
    X245                 R195 -1.0009999999999999
    X246                 OBJ 0.00044999999999999999
    X246                 R196 -1.0009999999999999
    X247                 OBJ 0.0026700000000000001
    X247                 R197 -1.0009999999999999
    X248                 OBJ 0.00088999999999999995
    X248                 R198 -1.0009999999999999
    X249                 OBJ 0.00088999999999999995
    X249                 R199 -1.0009999999999999
    X250                 OBJ 0.00044999999999999999
    X250                 R200 -1.0009999999999999
    X251                 OBJ 0.0026700000000000001
    X251                 R201 -1.0009999999999999
    X252                 OBJ 0.00044999999999999999
    X252                 R202 -1.0009999999999999
    X253                 OBJ 0.00044999999999999999
    X253                 R203 -1.0009999999999999
    X254                 OBJ 0.00044999999999999999
    X254                 R204 -1.0009999999999999
    X255                 OBJ 0.00044999999999999999
    X255                 R205 -1.0009999999999999
    X256                 OBJ 0.00044999999999999999
    X256                 R206 -1.0009999999999999
    X257                 OBJ 0.00134
    X257                 R207 -1.0009999999999999
    X258                 OBJ 0.00044999999999999999
    X258                 R208 -1.0009999999999999
    X259                 OBJ 0.00044999999999999999
    X259                 R209 -1.0009999999999999
    X260                 OBJ 0.023259999999999999
    X260                 R210 1.0009999999999999
    X261                 OBJ 0.00044999999999999999
    X261                 R211 -1.0009999999999999
    X262                 OBJ 0.00044999999999999999
    X262                 R212 -1.0009999999999999
    X263                 OBJ 0.00044999999999999999
    X263                 R213 -1.0009999999999999
    X264                 OBJ 0.0026700000000000001
    X264                 R214 -1.0009999999999999
    X265                 OBJ 0.00044999999999999999
    X265                 R215 -1.0009999999999999
    X266                 OBJ 0.00044999999999999999
    X266                 R216 -1.0009999999999999
    X267                 OBJ 0.00088999999999999995
    X267                 R217 -1.0009999999999999
    X268                 OBJ 0.0026700000000000001
    X268                 R218 -1.0009999999999999
    X269                 OBJ 0.00044999999999999999
    X269                 R219 -1.0009999999999999
    X270                 OBJ 0.00044999999999999999
    X270                 R220 -1.0009999999999999
    X271                 OBJ 0.00044999999999999999
    X271                 R221 -1.0009999999999999
    X272                 OBJ 0.00044999999999999999
    X272                 R222 -1.0009999999999999
    X273                 OBJ 0.00445
    X273                 R223 -1.0009999999999999
    X274                 OBJ 0.00044999999999999999
    X274                 R224 -1.0009999999999999
    X275                 OBJ 0.00088999999999999995
    X275                 R225 -1.0009999999999999
    X276                 OBJ 0.023259999999999999
    X276                 R226 1.0009999999999999
    X277                 OBJ 0.023259999999999999
    X277                 R227 1.0009999999999999
    X278                 OBJ 0.00044999999999999999
    X278                 R228 -1.0009999999999999
    X279                 OBJ 0.00044999999999999999
    X279                 R229 -1.0009999999999999
    X280                 OBJ 0.00044999999999999999
    X280                 R230 -1.0009999999999999
    X281                 OBJ 0.00088999999999999995
    X281                 R231 -1.0009999999999999
    X282                 OBJ 0.00088999999999999995
    X282                 R232 -1.0009999999999999
    X283                 OBJ 0.00044999999999999999
    X283                 R233 -1.0009999999999999
    X284                 OBJ 0.00044999999999999999
    X284                 R234 -1.0009999999999999
    X285                 OBJ 0.00044999999999999999
    X285                 R235 -1.0009999999999999
    X286                 OBJ 0.00044999999999999999
    X286                 R236 -1.0009999999999999
    X287                 OBJ 0.00044999999999999999
    X287                 R237 -1.0009999999999999
    X288                 OBJ 0.00088999999999999995
    X288                 R238 -1.0009999999999999
    X289                 OBJ 0.02281
    X289                 R239 1.0009999999999999
    X290                 OBJ 0.00044999999999999999
    X290                 R240 -1.0009999999999999
    X291                 OBJ 0.00044999999999999999
    X291                 R241 -1.0009999999999999
    X292                 OBJ 0.0022300000000000002
    X292                 R242 -1.0009999999999999
    X293                 OBJ 0.0017799999999999999
    X293                 R243 -1.0009999999999999
    X294                 OBJ 0.00044999999999999999
    X294                 R244 -1.0009999999999999
    X295                 OBJ 0.00134
    X295                 R245 -1.0009999999999999
    X296                 OBJ 0.00134
    X296                 R246 -1.0009999999999999
    X297                 OBJ 0.00044999999999999999
    X297                 R247 -1.0009999999999999
    X298                 OBJ 0.00044999999999999999
    X298                 R248 -1.0009999999999999
    X299                 OBJ 0.00044999999999999999
    X299                 R249 -1.0009999999999999
    X300                 OBJ 0.00044999999999999999
    X300                 R250 -1.0009999999999999
    X301                 OBJ 0.00044999999999999999
    X301                 R251 -1.0009999999999999
    X302                 OBJ 0.00088999999999999995
    X302                 R252 -1.0009999999999999
    X303                 OBJ 0.023259999999999999
    X303                 R253 1.0009999999999999
    X304                 OBJ 0.00088999999999999995
    X304                 R254 -1.0009999999999999
    X305                 OBJ 0.00088999999999999995
    X305                 R255 -1.0009999999999999
    X306                 OBJ 0.02281
    X306                 R256 1.0009999999999999
    X307                 OBJ 0.00044999999999999999
    X307                 R257 -1.0009999999999999
    X308                 OBJ 0.00134
    X308                 R258 -1.0009999999999999
    X309                 OBJ 0.00044999999999999999
    X309                 R259 -1.0009999999999999
    X310                 OBJ 0.00044999999999999999
    X310                 R260 -1.0009999999999999
    X311                 OBJ 0.00044999999999999999
    X311                 R261 -1.0009999999999999
    X312                 OBJ 0.00044999999999999999
    X312                 R262 -1.0009999999999999
    X313                 OBJ 0.00044999999999999999
    X313                 R263 -1.0009999999999999
    X314                 OBJ 0.00044999999999999999
    X314                 R264 -1.0009999999999999
    X315                 OBJ 0.00044999999999999999
    X315                 R265 -1.0009999999999999
    X316                 OBJ 0.00044999999999999999
    X316                 R266 -1.0009999999999999
    X317                 OBJ 0.00044999999999999999
    X317                 R267 -1.0009999999999999
    X318                 OBJ 0.00044999999999999999
    X318                 R268 -1.0009999999999999
    X319                 OBJ 0.00044999999999999999
    X319                 R269 -1.0009999999999999
    X320                 OBJ 0.00044999999999999999
    X320                 R270 -1.0009999999999999
    X321                 OBJ 0.00579
    X321                 R271 -1.0009999999999999
    X322                 OBJ 0.0017799999999999999
    X322                 R272 -1.0009999999999999
    X323                 OBJ 0.00088999999999999995
    X323                 R273 -1.0009999999999999
    X324                 OBJ 0.00044999999999999999
    X324                 R274 -1.0009999999999999
    X325                 OBJ 0.00044999999999999999
    X325                 R275 -1.0009999999999999
    X326                 OBJ 0.00044999999999999999
    X326                 R276 -1.0009999999999999
    X327                 OBJ 0.00044999999999999999
    X327                 R277 -1.0009999999999999
    X328                 OBJ 0.00044999999999999999
    X328                 R278 -1.0009999999999999
    X329                 OBJ 0.00044999999999999999
    X329                 R279 -1.0009999999999999
    X330                 OBJ 0.00044999999999999999
    X330                 R280 -1.0009999999999999
    X331                 OBJ 0.00044999999999999999
    X331                 R281 -1.0009999999999999
    X332                 OBJ 0.00044999999999999999
    X332                 R282 -1.0009999999999999
    X333                 OBJ 0.0017799999999999999
    X333                 R283 -1.0009999999999999
    X334                 OBJ 0.00044999999999999999
    X334                 R284 -1.0009999999999999
    X335                 OBJ 0.00044999999999999999
    X335                 R285 -1.0009999999999999
    X336                 OBJ 0.00044999999999999999
    X336                 R286 -1.0009999999999999
    X337                 OBJ 0.00044999999999999999
    X337                 R287 -1.0009999999999999
    X338                 OBJ 0.00044999999999999999
    X338                 R288 -1.0009999999999999
    X339                 OBJ 0.00044999999999999999
    X339                 R289 -1.0009999999999999
    X340                 OBJ 0.00044999999999999999
    X340                 R290 -1.0009999999999999
    X341                 OBJ 0.00044999999999999999
    X341                 R291 -1.0009999999999999
    X342                 OBJ 0.00044999999999999999
    X342                 R292 -1.0009999999999999
    X343                 OBJ 0.00088999999999999995
    X343                 R293 -1.0009999999999999
    X344                 OBJ 0.00044999999999999999
    X344                 R294 -1.0009999999999999
    X345                 OBJ 0.00044999999999999999
    X345                 R295 -1.0009999999999999
    X346                 OBJ 0.00044999999999999999
    X346                 R296 -1.0009999999999999
    X347                 OBJ 0.00044999999999999999
    X347                 R297 -1.0009999999999999
    X348                 OBJ 0.00044999999999999999
    X348                 R298 -1.0009999999999999
    X349                 OBJ 0.00044999999999999999
    X349                 R299 -1.0009999999999999
    X350                 OBJ 0.00134
    X350                 R300 -1.0009999999999999
    X351                 OBJ 0.00044999999999999999
    X351                 R301 -1.0009999999999999
    X352                 OBJ 0.00044999999999999999
    X352                 R302 -1.0009999999999999
    X353                 OBJ 0.00044999999999999999
    X353                 R303 -1.0009999999999999
    X354                 OBJ 0.00044999999999999999
    X354                 R304 -1.0009999999999999
    X355                 OBJ 0.00088999999999999995
    X355                 R305 -1.0009999999999999
    X356                 OBJ 0.00044999999999999999
    X356                 R306 -1.0009999999999999
    X357                 OBJ 0.00044999999999999999
    X357                 R307 -1.0009999999999999
    X358                 OBJ 0.00044999999999999999
    X358                 R308 -1.0009999999999999
    X359                 OBJ 0.0017799999999999999
    X359                 R309 -1.0009999999999999
    X360                 OBJ 0.00044999999999999999
    X360                 R310 -1.0009999999999999
    X361                 OBJ 0.00044999999999999999
    X361                 R311 -1.0009999999999999
    X362                 OBJ 0.00044999999999999999
    X362                 R312 -1.0009999999999999
    X363                 OBJ 0.00044999999999999999
    X363                 R313 -1.0009999999999999
    X364                 OBJ 0.00044999999999999999
    X364                 R314 -1.0009999999999999
    X365                 OBJ 0.00044999999999999999
    X365                 R315 -1.0009999999999999
    X366                 OBJ 0.00044999999999999999
    X366                 R316 -1.0009999999999999
    X367                 OBJ 0.00044999999999999999
    X367                 R317 -1.0009999999999999
    X368                 OBJ 0.00044999999999999999
    X368                 R318 -1.0009999999999999
    X369                 OBJ 0.00134
    X369                 R319 -1.0009999999999999
    X370                 OBJ 0.00044999999999999999
    X370                 R320 -1.0009999999999999
    X371                 OBJ 0.00044999999999999999
    X371                 R321 -1.0009999999999999
    X372                 OBJ 0.00044999999999999999
    X372                 R322 -1.0009999999999999
    X373                 OBJ 0.00044999999999999999
    X373                 R323 -1.0009999999999999
    X374                 OBJ 0.023259999999999999
    X374                 R324 1.0009999999999999
    X375                 OBJ 0.00088999999999999995
    X375                 R325 -1.0009999999999999
    X376                 OBJ 0.00044999999999999999
    X376                 R326 -1.0009999999999999
    X377                 OBJ 0.00044999999999999999
    X377                 R327 -1.0009999999999999
    X378                 OBJ 0.00044999999999999999
    X378                 R328 -1.0009999999999999
    X379                 OBJ 0.00044999999999999999
    X379                 R329 -1.0009999999999999
    X380                 OBJ 0.00044999999999999999
    X380                 R330 -1.0009999999999999
    X381                 OBJ 0.00044999999999999999
    X381                 R331 -1.0009999999999999
    X382                 OBJ 0.00044999999999999999
    X382                 R332 -1.0009999999999999
    X383                 OBJ 0.00044999999999999999
    X383                 R333 -1.0009999999999999
    X384                 OBJ 0.023259999999999999
    X384                 R334 1.0009999999999999
    X385                 OBJ 0.023259999999999999
    X385                 R335 1.0009999999999999
    X386                 OBJ 0.00044999999999999999
    X386                 R336 -1.0009999999999999
    X387                 OBJ 0.0022300000000000002
    X387                 R337 -1.0009999999999999
    X388                 OBJ 0.02281
    X388                 R338 1.0009999999999999
    X389                 OBJ 0.00044999999999999999
    X389                 R339 -1.0009999999999999
    X390                 OBJ 0.00044999999999999999
    X390                 R340 -1.0009999999999999
    X391                 OBJ 0.0017799999999999999
    X391                 R341 -1.0009999999999999
    X392                 OBJ 0.00044999999999999999
    X392                 R342 -1.0009999999999999
    X393                 OBJ 0.00044999999999999999
    X393                 R343 -1.0009999999999999
    X394                 OBJ 0.00044999999999999999
    X394                 R344 -1.0009999999999999
    X395                 OBJ 0.00044999999999999999
    X395                 R345 -1.0009999999999999
    X396                 OBJ 0.00044999999999999999
    X396                 R346 -1.0009999999999999
    X397                 OBJ 0.00044999999999999999
    X397                 R347 -1.0009999999999999
    X398                 OBJ 0.00044999999999999999
    X398                 R348 -1.0009999999999999
    X399                 OBJ 0.00044999999999999999
    X399                 R349 -1.0009999999999999
    X400                 OBJ 0.00044999999999999999
    X400                 R350 -1.0009999999999999
    X401                 OBJ 0.00044999999999999999
    X401                 R351 -1.0009999999999999
    X402                 OBJ 0.00044999999999999999
    X402                 R352 -1.0009999999999999
    X403                 OBJ 0.00044999999999999999
    X403                 R353 -1.0009999999999999
    X404                 OBJ 0.00044999999999999999
    X404                 R354 -1.0009999999999999
    X405                 OBJ 0.00044999999999999999
    X405                 R355 -1.0009999999999999
    X406                 OBJ 0.00044999999999999999
    X406                 R356 -1.0009999999999999
    X407                 OBJ 0.00044999999999999999
    X407                 R357 -1.0009999999999999
    X408                 OBJ 0.00044999999999999999
    X408                 R358 -1.0009999999999999
    X409                 OBJ 0.00044999999999999999
    X409                 R359 -1.0009999999999999
    X410                 OBJ 0.00044999999999999999
    X410                 R360 -1.0009999999999999
    X411                 OBJ 0.00044999999999999999
    X411                 R361 -1.0009999999999999
    X412                 OBJ 0.00044999999999999999
    X412                 R362 -1.0009999999999999
    X413                 OBJ 0.00044999999999999999
    X413                 R363 -1.0009999999999999
    X414                 OBJ 0.00044999999999999999
    X414                 R364 -1.0009999999999999
    X415                 OBJ 0.00044999999999999999
    X415                 R365 -1.0009999999999999
    X416                 OBJ 0.00044999999999999999
    X416                 R366 -1.0009999999999999
    X417                 OBJ 0.00044999999999999999
    X417                 R367 -1.0009999999999999
    X418                 OBJ 0.00044999999999999999
    X418                 R368 -1.0009999999999999
    X419                 OBJ 0.00088999999999999995
    X419                 R369 -1.0009999999999999
    X420                 OBJ 0.00044999999999999999
    X420                 R370 -1.0009999999999999
    X421                 OBJ 0.00044999999999999999
    X421                 R371 -1.0009999999999999
    X422                 OBJ 0.00044999999999999999
    X422                 R372 -1.0009999999999999
    X423                 OBJ 0.00088999999999999995
    X423                 R373 -1.0009999999999999
    X424                 OBJ 0.00044999999999999999
    X424                 R374 -1.0009999999999999
    X425                 OBJ 0.00044999999999999999
    X425                 R375 -1.0009999999999999
    X426                 OBJ 0.00044999999999999999
    X426                 R376 -1.0009999999999999
    X427                 OBJ 0.00044999999999999999
    X427                 R377 -1.0009999999999999
    X428                 OBJ 0.00044999999999999999
    X428                 R378 -1.0009999999999999
    X429                 OBJ 0.00088999999999999995
    X429                 R379 -1.0009999999999999
    X430                 OBJ 0.00088999999999999995
    X430                 R380 -1.0009999999999999
    X431                 OBJ 0.00044999999999999999
    X431                 R381 -1.0009999999999999
    X432                 OBJ 0.00044999999999999999
    X432                 R382 -1.0009999999999999
    X433                 OBJ 0.00044999999999999999
    X433                 R383 -1.0009999999999999
    X434                 OBJ 0.00044999999999999999
    X434                 R384 -1.0009999999999999
    X435                 OBJ 0.00044999999999999999
    X435                 R385 -1.0009999999999999
    X436                 OBJ 0.00044999999999999999
    X436                 R386 -1.0009999999999999
    X437                 OBJ 0.00044999999999999999
    X437                 R387 -1.0009999999999999
    X438                 OBJ 0.00044999999999999999
    X438                 R388 -1.0009999999999999
    X439                 OBJ 0.00044999999999999999
    X439                 R389 -1.0009999999999999
    X440                 OBJ 0.00044999999999999999
    X440                 R390 -1.0009999999999999
    X441                 OBJ 0.00044999999999999999
    X441                 R391 -1.0009999999999999
    X442                 OBJ 0.00088999999999999995
    X442                 R392 -1.0009999999999999
    X443                 OBJ 0.00044999999999999999
    X443                 R393 -1.0009999999999999
    X444                 OBJ 0.00044999999999999999
    X444                 R394 -1.0009999999999999
    X445                 OBJ 0.023259999999999999
    X445                 R395 1.0009999999999999
    X446                 OBJ 0.00044999999999999999
    X446                 R396 -1.0009999999999999
    X447                 OBJ 0.00044999999999999999
    X447                 R397 -1.0009999999999999
    X448                 OBJ 0.00044999999999999999
    X448                 R398 -1.0009999999999999
    X449                 OBJ 0.00044999999999999999
    X449                 R399 -1.0009999999999999
    X450                 OBJ 0.023259999999999999
    X450                 R400 1.0009999999999999
    X451                 OBJ 0.00088999999999999995
    X451                 R401 -1.0009999999999999
    X452                 OBJ 0.00044999999999999999
    X452                 R402 -1.0009999999999999
    X453                 OBJ 0.023259999999999999
    X453                 R403 1.0009999999999999
    X454                 OBJ 0.00044999999999999999
    X454                 R404 -1.0009999999999999
    X455                 OBJ 0.00044999999999999999
    X455                 R405 -1.0009999999999999
    X456                 OBJ 0.00044999999999999999
    X456                 R406 -1.0009999999999999
    X457                 OBJ 0.00044999999999999999
    X457                 R407 -1.0009999999999999
    X458                 OBJ 0.00044999999999999999
    X458                 R408 -1.0009999999999999
    X459                 OBJ 0.00044999999999999999
    X459                 R409 -1.0009999999999999
    X460                 OBJ 0.00044999999999999999
    X460                 R410 -1.0009999999999999
    X461                 OBJ 0.00044999999999999999
    X461                 R411 -1.0009999999999999
    X462                 OBJ 0.00044999999999999999
    X462                 R412 -1.0009999999999999
    X463                 OBJ 0.00044999999999999999
    X463                 R413 -1.0009999999999999
    X464                 OBJ 0.00044999999999999999
    X464                 R414 -1.0009999999999999
    X465                 OBJ 0.00044999999999999999
    X465                 R415 -1.0009999999999999
    X466                 OBJ 0.00044999999999999999
    X466                 R416 -1.0009999999999999
    X467                 OBJ 0.00044999999999999999
    X467                 R417 -1.0009999999999999
    X468                 OBJ 0.023259999999999999
    X468                 R418 1.0009999999999999
    X469                 OBJ 0.00044999999999999999
    X469                 R419 -1.0009999999999999
    X470                 OBJ 0.00044999999999999999
    X470                 R420 -1.0009999999999999
    X471                 OBJ 0.00044999999999999999
    X471                 R421 -1.0009999999999999
    X472                 OBJ 0.00044999999999999999
    X472                 R422 -1.0009999999999999
    X473                 OBJ 0.00044999999999999999
    X473                 R423 -1.0009999999999999
    X474                 OBJ 0.00088999999999999995
    X474                 R424 -1.0009999999999999
    X475                 OBJ 0.00044999999999999999
    X475                 R425 -1.0009999999999999
    X476                 OBJ 0.00044999999999999999
    X476                 R426 -1.0009999999999999
    X477                 OBJ 0.00044999999999999999
    X477                 R427 -1.0009999999999999
    X478                 OBJ 0.023259999999999999
    X478                 R428 1.0009999999999999
    X479                 OBJ 0.00044999999999999999
    X479                 R429 -1.0009999999999999
    X480                 OBJ 0.00044999999999999999
    X480                 R430 -1.0009999999999999
    X481                 OBJ 0.00044999999999999999
    X481                 R431 -1.0009999999999999
    X482                 OBJ 0.00044999999999999999
    X482                 R432 -1.0009999999999999
    X483                 OBJ 0.00044999999999999999
    X483                 R433 -1.0009999999999999
    X484                 OBJ 0.00044999999999999999
    X484                 R434 -1.0009999999999999
    X485                 OBJ 0.00044999999999999999
    X485                 R435 -1.0009999999999999
    X486                 OBJ 0.023259999999999999
    X486                 R436 1.0009999999999999
    X487                 OBJ 0.00044999999999999999
    X487                 R437 -1.0009999999999999
    X488                 OBJ 0.00044999999999999999
    X488                 R438 -1.0009999999999999
    X489                 OBJ 0.00044999999999999999
    X489                 R439 -1.0009999999999999
    X490                 OBJ 0.00044999999999999999
    X490                 R440 -1.0009999999999999
    X491                 OBJ 0.00044999999999999999
    X491                 R441 -1.0009999999999999
    X492                 OBJ 0.00044999999999999999
    X492                 R442 -1.0009999999999999
    X493                 OBJ 0.00044999999999999999
    X493                 R443 -1.0009999999999999
    X494                 OBJ 0.00088999999999999995
    X494                 R444 -1.0009999999999999
    X495                 OBJ 0.00044999999999999999
    X495                 R445 -1.0009999999999999
    X496                 OBJ 0.00044999999999999999
    X496                 R446 -1.0009999999999999
    X497                 OBJ 0.00044999999999999999
    X497                 R447 -1.0009999999999999
    X498                 OBJ 0.00044999999999999999
    X498                 R448 -1.0009999999999999
    X499                 OBJ 0.00044999999999999999
    X499                 R449 -1.0009999999999999
    X500                 OBJ 0.00044999999999999999
    X500                 R450 -1.0009999999999999
    X501                 OBJ 0.00044999999999999999
    X501                 R451 -1.0009999999999999
    X502                 OBJ 0.00044999999999999999
    X502                 R452 -1.0009999999999999
    X503                 OBJ 0.00044999999999999999
    X503                 R453 -1.0009999999999999
    X504                 OBJ 0.00044999999999999999
    X504                 R454 -1.0009999999999999
    X505                 OBJ 0.00044999999999999999
    X505                 R455 -1.0009999999999999
    X506                 OBJ 0.00044999999999999999
    X506                 R456 -1.0009999999999999
    X507                 OBJ 0.00044999999999999999
    X507                 R457 -1.0009999999999999
    X508                 OBJ 0.00044999999999999999
    X508                 R458 -1.0009999999999999
    X509                 OBJ 0.00044999999999999999
    X509                 R459 -1.0009999999999999
    X510                 OBJ 0.00044999999999999999
    X510                 R460 -1.0009999999999999
    X511                 OBJ 0.00044999999999999999
    X511                 R461 -1.0009999999999999
    X512                 OBJ 0.00044999999999999999
    X512                 R462 -1.0009999999999999
    X513                 OBJ 0.00044999999999999999
    X513                 R463 -1.0009999999999999
    X514                 OBJ 0.00044999999999999999
    X514                 R464 -1.0009999999999999
    X515                 OBJ 0.00044999999999999999
    X515                 R465 -1.0009999999999999
    X516                 OBJ 0.00044999999999999999
    X516                 R466 -1.0009999999999999
    X517                 OBJ 0.00044999999999999999
    X517                 R467 -1.0009999999999999
    X518                 OBJ 0.00044999999999999999
    X518                 R468 -1.0009999999999999
    X519                 OBJ 0.00044999999999999999
    X519                 R469 -1.0009999999999999
    X520                 OBJ 0.00044999999999999999
    X520                 R470 -1.0009999999999999
    X521                 OBJ 0.00044999999999999999
    X521                 R471 -1.0009999999999999
    X522                 OBJ 0.00044999999999999999
    X522                 R472 -1.0009999999999999
    X523                 OBJ 0.00044999999999999999
    X523                 R473 -1.0009999999999999
    X524                 OBJ 0.023259999999999999
    X524                 R474 1.0009999999999999
    X525                 OBJ 0.00044999999999999999
    X525                 R475 -1.0009999999999999
    X526                 OBJ 0.00044999999999999999
    X526                 R476 -1.0009999999999999
    X527                 OBJ 0.00044999999999999999
    X527                 R477 -1.0009999999999999
    X528                 OBJ 0.00044999999999999999
    X528                 R478 -1.0009999999999999
    X529                 OBJ 0.00044999999999999999
    X529                 R479 -1.0009999999999999
    X530                 OBJ 0.023259999999999999
    X530                 R480 1.0009999999999999
    X531                 OBJ 0.00044999999999999999
    X531                 R481 -1.0009999999999999
    X532                 OBJ 0.00044999999999999999
    X532                 R482 -1.0009999999999999
    X533                 OBJ 0.00044999999999999999
    X533                 R483 -1.0009999999999999
    X534                 OBJ 0.023259999999999999
    X534                 R484 1.0009999999999999
RHS
    RHS                  OBJ -0
    RHS                  R0 -0.001
    RHS                  R1 -0.001
    RHS                  R2 -0.001
    RHS                  R3 -0.001
    RHS                  R4 -0.001
    RHS                  R5 -0.001
    RHS                  R6 -0.001
    RHS                  R7 -0.001
    RHS                  R8 -0.001
    RHS                  R9 -0.001
    RHS                  R10 -0.001
    RHS                  R11 -0.001
    RHS                  R12 -0.001
    RHS                  R13 -0.001
    RHS                  R14 -0.001
    RHS                  R15 -0.001
    RHS                  R16 -0.001
    RHS                  R17 -0.001
    RHS                  R18 -0.001
    RHS                  R19 -0.001
    RHS                  R20 -0.001
    RHS                  R21 0.001
    RHS                  R22 -0.001
    RHS                  R23 -0.001
    RHS                  R24 -0.001
    RHS                  R25 -0.001
    RHS                  R26 -0.001
    RHS                  R27 0.001
    RHS                  R28 -0.001
    RHS                  R29 -0.001
    RHS                  R30 -0.001
    RHS                  R31 -0.001
    RHS                  R32 -0.001
    RHS                  R33 -0.001
    RHS                  R34 -0.001
    RHS                  R35 -0.001
    RHS                  R36 -0.001
    RHS                  R37 -0.001
    RHS                  R38 -0.001
    RHS                  R39 -0.001
    RHS                  R40 -0.001
    RHS                  R41 -0.001
    RHS                  R42 -0.001
    RHS                  R43 0.001
    RHS                  R44 -0.001
    RHS                  R45 -0.001
    RHS                  R46 0.001
    RHS                  R47 -0.001
    RHS                  R48 -0.001
    RHS                  R49 -0.001
    RHS                  R50 -0.001
    RHS                  R51 -0.001
    RHS                  R52 -0.001
    RHS                  R53 -0.001
    RHS                  R54 -0.001
    RHS                  R55 -0.001
    RHS                  R56 -0.001
    RHS                  R57 0.001
    RHS                  R58 -0.001
    RHS                  R59 -0.001
    RHS                  R60 -0.001
    RHS                  R61 -0.001
    RHS                  R62 -0.001
    RHS                  R63 -0.001
    RHS                  R64 -0.001
    RHS                  R65 -0.001
    RHS                  R66 -0.001
    RHS                  R67 -0.001
    RHS                  R68 -0.001
    RHS                  R69 -0.001
    RHS                  R70 -0.001
    RHS                  R71 -0.001
    RHS                  R72 -0.001
    RHS                  R73 -0.001
    RHS                  R74 -0.001
    RHS                  R75 0.001
    RHS                  R76 -0.001
    RHS                  R77 -0.001
    RHS                  R78 -0.001
    RHS                  R79 0.001
    RHS                  R80 -0.001
    RHS                  R81 -0.001
    RHS                  R82 -0.001
    RHS                  R83 -0.001
    RHS                  R84 0.001
    RHS                  R85 -0.001
    RHS                  R86 -0.001
    RHS                  R87 -0.001
    RHS                  R88 -0.001
    RHS                  R89 -0.001
    RHS                  R90 -0.001
    RHS                  R91 -0.001
    RHS                  R92 -0.001
    RHS                  R93 -0.001
    RHS                  R94 -0.001
    RHS                  R95 -0.001
    RHS                  R96 -0.001
    RHS                  R97 -0.001
    RHS                  R98 -0.001
    RHS                  R99 0.001
    RHS                  R100 -0.001
    RHS                  R101 -0.001
    RHS                  R102 0.001
    RHS                  R103 -0.001
    RHS                  R104 -0.001
    RHS                  R105 -0.001
    RHS                  R106 0.001
    RHS                  R107 -0.001
    RHS                  R108 -0.001
    RHS                  R109 -0.001
    RHS                  R110 -0.001
    RHS                  R111 -0.001
    RHS                  R112 -0.001
    RHS                  R113 -0.001
    RHS                  R114 -0.001
    RHS                  R115 -0.001
    RHS                  R116 0.001
    RHS                  R117 -0.001
    RHS                  R118 -0.001
    RHS                  R119 -0.001
    RHS                  R120 0.001
    RHS                  R121 0.001
    RHS                  R122 -0.001
    RHS                  R123 -0.001
    RHS                  R124 0.001
    RHS                  R125 -0.001
    RHS                  R126 -0.001
    RHS                  R127 -0.001
    RHS                  R128 -0.001
    RHS                  R129 -0.001
    RHS                  R130 -0.001
    RHS                  R131 -0.001
    RHS                  R132 -0.001
    RHS                  R133 -0.001
    RHS                  R134 -0.001
    RHS                  R135 -0.001
    RHS                  R136 -0.001
    RHS                  R137 -0.001
    RHS                  R138 -0.001
    RHS                  R139 -0.001
    RHS                  R140 -0.001
    RHS                  R141 -0.001
    RHS                  R142 -0.001
    RHS                  R143 -0.001
    RHS                  R144 -0.001
    RHS                  R145 -0.001
    RHS                  R146 -0.001
    RHS                  R147 -0.001
    RHS                  R148 -0.001
    RHS                  R149 -0.001
    RHS                  R150 -0.001
    RHS                  R151 -0.001
    RHS                  R152 -0.001
    RHS                  R153 -0.001
    RHS                  R154 -0.001
    RHS                  R155 -0.001
    RHS                  R156 -0.001
    RHS                  R157 -0.001
    RHS                  R158 -0.001
    RHS                  R159 -0.001
    RHS                  R160 -0.001
    RHS                  R161 -0.001
    RHS                  R162 -0.001
    RHS                  R163 -0.001
    RHS                  R164 -0.001
    RHS                  R165 -0.001
    RHS                  R166 -0.001
    RHS                  R167 -0.001
    RHS                  R168 -0.001
    RHS                  R169 -0.001
    RHS                  R170 -0.001
    RHS                  R171 -0.001
    RHS                  R172 -0.001
    RHS                  R173 -0.001
    RHS                  R174 -0.001
    RHS                  R175 -0.001
    RHS                  R176 -0.001
    RHS                  R177 -0.001
    RHS                  R178 -0.001
    RHS                  R179 -0.001
    RHS                  R180 -0.001
    RHS                  R181 -0.001
    RHS                  R182 -0.001
    RHS                  R183 0.001
    RHS                  R184 -0.001
    RHS                  R185 -0.001
    RHS                  R186 -0.001
    RHS                  R187 -0.001
    RHS                  R188 -0.001
    RHS                  R189 -0.001
    RHS                  R190 -0.001
    RHS                  R191 -0.001
    RHS                  R192 -0.001
    RHS                  R193 -0.001
    RHS                  R194 -0.001
    RHS                  R195 -0.001
    RHS                  R196 -0.001
    RHS                  R197 -0.001
    RHS                  R198 -0.001
    RHS                  R199 -0.001
    RHS                  R200 -0.001
    RHS                  R201 -0.001
    RHS                  R202 -0.001
    RHS                  R203 -0.001
    RHS                  R204 -0.001
    RHS                  R205 -0.001
    RHS                  R206 -0.001
    RHS                  R207 -0.001
    RHS                  R208 -0.001
    RHS                  R209 -0.001
    RHS                  R210 0.001
    RHS                  R211 -0.001
    RHS                  R212 -0.001
    RHS                  R213 -0.001
    RHS                  R214 -0.001
    RHS                  R215 -0.001
    RHS                  R216 -0.001
    RHS                  R217 -0.001
    RHS                  R218 -0.001
    RHS                  R219 -0.001
    RHS                  R220 -0.001
    RHS                  R221 -0.001
    RHS                  R222 -0.001
    RHS                  R223 -0.001
    RHS                  R224 -0.001
    RHS                  R225 -0.001
    RHS                  R226 0.001
    RHS                  R227 0.001
    RHS                  R228 -0.001
    RHS                  R229 -0.001
    RHS                  R230 -0.001
    RHS                  R231 -0.001
    RHS                  R232 -0.001
    RHS                  R233 -0.001
    RHS                  R234 -0.001
    RHS                  R235 -0.001
    RHS                  R236 -0.001
    RHS                  R237 -0.001
    RHS                  R238 -0.001
    RHS                  R239 0.001
    RHS                  R240 -0.001
    RHS                  R241 -0.001
    RHS                  R242 -0.001
    RHS                  R243 -0.001
    RHS                  R244 -0.001
    RHS                  R245 -0.001
    RHS                  R246 -0.001
    RHS                  R247 -0.001
    RHS                  R248 -0.001
    RHS                  R249 -0.001
    RHS                  R250 -0.001
    RHS                  R251 -0.001
    RHS                  R252 -0.001
    RHS                  R253 0.001
    RHS                  R254 -0.001
    RHS                  R255 -0.001
    RHS                  R256 0.001
    RHS                  R257 -0.001
    RHS                  R258 -0.001
    RHS                  R259 -0.001
    RHS                  R260 -0.001
    RHS                  R261 -0.001
    RHS                  R262 -0.001
    RHS                  R263 -0.001
    RHS                  R264 -0.001
    RHS                  R265 -0.001
    RHS                  R266 -0.001
    RHS                  R267 -0.001
    RHS                  R268 -0.001
    RHS                  R269 -0.001
    RHS                  R270 -0.001
    RHS                  R271 -0.001
    RHS                  R272 -0.001
    RHS                  R273 -0.001
    RHS                  R274 -0.001
    RHS                  R275 -0.001
    RHS                  R276 -0.001
    RHS                  R277 -0.001
    RHS                  R278 -0.001
    RHS                  R279 -0.001
    RHS                  R280 -0.001
    RHS                  R281 -0.001
    RHS                  R282 -0.001
    RHS                  R283 -0.001
    RHS                  R284 -0.001
    RHS                  R285 -0.001
    RHS                  R286 -0.001
    RHS                  R287 -0.001
    RHS                  R288 -0.001
    RHS                  R289 -0.001
    RHS                  R290 -0.001
    RHS                  R291 -0.001
    RHS                  R292 -0.001
    RHS                  R293 -0.001
    RHS                  R294 -0.001
    RHS                  R295 -0.001
    RHS                  R296 -0.001
    RHS                  R297 -0.001
    RHS                  R298 -0.001
    RHS                  R299 -0.001
    RHS                  R300 -0.001
    RHS                  R301 -0.001
    RHS                  R302 -0.001
    RHS                  R303 -0.001
    RHS                  R304 -0.001
    RHS                  R305 -0.001
    RHS                  R306 -0.001
    RHS                  R307 -0.001
    RHS                  R308 -0.001
    RHS                  R309 -0.001
    RHS                  R310 -0.001
    RHS                  R311 -0.001
    RHS                  R312 -0.001
    RHS                  R313 -0.001
    RHS                  R314 -0.001
    RHS                  R315 -0.001
    RHS                  R316 -0.001
    RHS                  R317 -0.001
    RHS                  R318 -0.001
    RHS                  R319 -0.001
    RHS                  R320 -0.001
    RHS                  R321 -0.001
    RHS                  R322 -0.001
    RHS                  R323 -0.001
    RHS                  R324 0.001
    RHS                  R325 -0.001
    RHS                  R326 -0.001
    RHS                  R327 -0.001
    RHS                  R328 -0.001
    RHS                  R329 -0.001
    RHS                  R330 -0.001
    RHS                  R331 -0.001
    RHS                  R332 -0.001
    RHS                  R333 -0.001
    RHS                  R334 0.001
    RHS                  R335 0.001
    RHS                  R336 -0.001
    RHS                  R337 -0.001
    RHS                  R338 0.001
    RHS                  R339 -0.001
    RHS                  R340 -0.001
    RHS                  R341 -0.001
    RHS                  R342 -0.001
    RHS                  R343 -0.001
    RHS                  R344 -0.001
    RHS                  R345 -0.001
    RHS                  R346 -0.001
    RHS                  R347 -0.001
    RHS                  R348 -0.001
    RHS                  R349 -0.001
    RHS                  R350 -0.001
    RHS                  R351 -0.001
    RHS                  R352 -0.001
    RHS                  R353 -0.001
    RHS                  R354 -0.001
    RHS                  R355 -0.001
    RHS                  R356 -0.001
    RHS                  R357 -0.001
    RHS                  R358 -0.001
    RHS                  R359 -0.001
    RHS                  R360 -0.001
    RHS                  R361 -0.001
    RHS                  R362 -0.001
    RHS                  R363 -0.001
    RHS                  R364 -0.001
    RHS                  R365 -0.001
    RHS                  R366 -0.001
    RHS                  R367 -0.001
    RHS                  R368 -0.001
    RHS                  R369 -0.001
    RHS                  R370 -0.001
    RHS                  R371 -0.001
    RHS                  R372 -0.001
    RHS                  R373 -0.001
    RHS                  R374 -0.001
    RHS                  R375 -0.001
    RHS                  R376 -0.001
    RHS                  R377 -0.001
    RHS                  R378 -0.001
    RHS                  R379 -0.001
    RHS                  R380 -0.001
    RHS                  R381 -0.001
    RHS                  R382 -0.001
    RHS                  R383 -0.001
    RHS                  R384 -0.001
    RHS                  R385 -0.001
    RHS                  R386 -0.001
    RHS                  R387 -0.001
    RHS                  R388 -0.001
    RHS                  R389 -0.001
    RHS                  R390 -0.001
    RHS                  R391 -0.001
    RHS                  R392 -0.001
    RHS                  R393 -0.001
    RHS                  R394 -0.001
    RHS                  R395 0.001
    RHS                  R396 -0.001
    RHS                  R397 -0.001
    RHS                  R398 -0.001
    RHS                  R399 -0.001
    RHS                  R400 0.001
    RHS                  R401 -0.001
    RHS                  R402 -0.001
    RHS                  R403 0.001
    RHS                  R404 -0.001
    RHS                  R405 -0.001
    RHS                  R406 -0.001
    RHS                  R407 -0.001
    RHS                  R408 -0.001
    RHS                  R409 -0.001
    RHS                  R410 -0.001
    RHS                  R411 -0.001
    RHS                  R412 -0.001
    RHS                  R413 -0.001
    RHS                  R414 -0.001
    RHS                  R415 -0.001
    RHS                  R416 -0.001
    RHS                  R417 -0.001
    RHS                  R418 0.001
    RHS                  R419 -0.001
    RHS                  R420 -0.001
    RHS                  R421 -0.001
    RHS                  R422 -0.001
    RHS                  R423 -0.001
    RHS                  R424 -0.001
    RHS                  R425 -0.001
    RHS                  R426 -0.001
    RHS                  R427 -0.001
    RHS                  R428 0.001
    RHS                  R429 -0.001
    RHS                  R430 -0.001
    RHS                  R431 -0.001
    RHS                  R432 -0.001
    RHS                  R433 -0.001
    RHS                  R434 -0.001
    RHS                  R435 -0.001
    RHS                  R436 0.001
    RHS                  R437 -0.001
    RHS                  R438 -0.001
    RHS                  R439 -0.001
    RHS                  R440 -0.001
    RHS                  R441 -0.001
    RHS                  R442 -0.001
    RHS                  R443 -0.001
    RHS                  R444 -0.001
    RHS                  R445 -0.001
    RHS                  R446 -0.001
    RHS                  R447 -0.001
    RHS                  R448 -0.001
    RHS                  R449 -0.001
    RHS                  R450 -0.001
    RHS                  R451 -0.001
    RHS                  R452 -0.001
    RHS                  R453 -0.001
    RHS                  R454 -0.001
    RHS                  R455 -0.001
    RHS                  R456 -0.001
    RHS                  R457 -0.001
    RHS                  R458 -0.001
    RHS                  R459 -0.001
    RHS                  R460 -0.001
    RHS                  R461 -0.001
    RHS                  R462 -0.001
    RHS                  R463 -0.001
    RHS                  R464 -0.001
    RHS                  R465 -0.001
    RHS                  R466 -0.001
    RHS                  R467 -0.001
    RHS                  R468 -0.001
    RHS                  R469 -0.001
    RHS                  R470 -0.001
    RHS                  R471 -0.001
    RHS                  R472 -0.001
    RHS                  R473 -0.001
    RHS                  R474 0.001
    RHS                  R475 -0.001
    RHS                  R476 -0.001
    RHS                  R477 -0.001
    RHS                  R478 -0.001
    RHS                  R479 -0.001
    RHS                  R480 0.001
    RHS                  R481 -0.001
    RHS                  R482 -0.001
    RHS                  R483 -0.001
    RHS                  R484 0.001
    RHS                  R485 1
BOUNDS
 	FR BND X0
 	LO BND X0 0
 	FR BND X1
 	LO BND X1 0
 	FR BND X2
 	LO BND X2 0
 	FR BND X3
 	LO BND X3 0
 	FR BND X4
 	LO BND X4 0
 	FR BND X5
 	LO BND X5 0
 	FR BND X6
 	LO BND X6 0
 	FR BND X7
 	LO BND X7 0
 	FR BND X8
 	LO BND X8 0
 	FR BND X9
 	LO BND X9 0
 	FR BND X10
 	LO BND X10 0
 	FR BND X11
 	LO BND X11 0
 	FR BND X12
 	LO BND X12 0
 	FR BND X13
 	LO BND X13 0
 	FR BND X14
 	LO BND X14 0
 	FR BND X15
 	LO BND X15 0
 	FR BND X16
 	LO BND X16 0
 	FR BND X17
 	LO BND X17 0
 	FR BND X18
 	LO BND X18 0
 	FR BND X19
 	LO BND X19 0
 	FR BND X20
 	LO BND X20 0
 	FR BND X21
 	LO BND X21 0
 	FR BND X22
 	LO BND X22 0
 	FR BND X23
 	LO BND X23 0
 	FR BND X24
 	LO BND X24 0
 	FX BND X25 0
 	FX BND X26 0
 	FX BND X27 0
 	FX BND X28 0
 	FX BND X29 0
 	FX BND X30 0
 	FX BND X31 0
 	FX BND X32 0
 	FX BND X33 0
 	FX BND X34 0
 	FX BND X35 0
 	FX BND X36 0
 	FX BND X37 0
 	FX BND X38 0
 	FX BND X39 0
 	FX BND X40 0
 	FX BND X41 0
 	FX BND X42 0
 	FX BND X43 0
 	FX BND X44 0
 	FX BND X45 0
 	FX BND X46 0
 	FX BND X47 0
 	FX BND X48 0
 	FR BND X49
 	LO BND X49 0
 	FR BND X50
 	LO BND X50 0
 	UP BND X50 1
 	FR BND X51
 	LO BND X51 0
 	UP BND X51 1
 	FR BND X52
 	LO BND X52 0
 	UP BND X52 1
 	FR BND X53
 	LO BND X53 0
 	UP BND X53 1
 	FR BND X54
 	LO BND X54 0
 	UP BND X54 1
 	FR BND X55
 	LO BND X55 0
 	UP BND X55 1
 	FR BND X56
 	LO BND X56 0
 	UP BND X56 1
 	FR BND X57
 	LO BND X57 0
 	UP BND X57 1
 	FR BND X58
 	LO BND X58 0
 	UP BND X58 1
 	FR BND X59
 	LO BND X59 0
 	UP BND X59 1
 	FR BND X60
 	LO BND X60 0
 	UP BND X60 1
 	FR BND X61
 	LO BND X61 0
 	UP BND X61 1
 	FR BND X62
 	LO BND X62 0
 	UP BND X62 1
 	FR BND X63
 	LO BND X63 0
 	UP BND X63 1
 	FR BND X64
 	LO BND X64 0
 	UP BND X64 1
 	FR BND X65
 	LO BND X65 0
 	UP BND X65 1
 	FR BND X66
 	LO BND X66 0
 	UP BND X66 1
 	FR BND X67
 	LO BND X67 0
 	UP BND X67 1
 	FR BND X68
 	LO BND X68 0
 	UP BND X68 1
 	FR BND X69
 	LO BND X69 0
 	UP BND X69 1
 	FR BND X70
 	LO BND X70 0
 	UP BND X70 1
 	FR BND X71
 	LO BND X71 0
 	UP BND X71 1
 	FR BND X72
 	LO BND X72 0
 	UP BND X72 1
 	FR BND X73
 	LO BND X73 0
 	UP BND X73 1
 	FR BND X74
 	LO BND X74 0
 	UP BND X74 1
 	FR BND X75
 	LO BND X75 0
 	UP BND X75 1
 	FR BND X76
 	LO BND X76 0
 	UP BND X76 1
 	FR BND X77
 	LO BND X77 0
 	UP BND X77 1
 	FR BND X78
 	LO BND X78 0
 	UP BND X78 1
 	FR BND X79
 	LO BND X79 0
 	UP BND X79 1
 	FR BND X80
 	LO BND X80 0
 	UP BND X80 1
 	FR BND X81
 	LO BND X81 0
 	UP BND X81 1
 	FR BND X82
 	LO BND X82 0
 	UP BND X82 1
 	FR BND X83
 	LO BND X83 0
 	UP BND X83 1
 	FR BND X84
 	LO BND X84 0
 	UP BND X84 1
 	FR BND X85
 	LO BND X85 0
 	UP BND X85 1
 	FR BND X86
 	LO BND X86 0
 	UP BND X86 1
 	FR BND X87
 	LO BND X87 0
 	UP BND X87 1
 	FR BND X88
 	LO BND X88 0
 	UP BND X88 1
 	FR BND X89
 	LO BND X89 0
 	UP BND X89 1
 	FR BND X90
 	LO BND X90 0
 	UP BND X90 1
 	FR BND X91
 	LO BND X91 0
 	UP BND X91 1
 	FR BND X92
 	LO BND X92 0
 	UP BND X92 1
 	FR BND X93
 	LO BND X93 0
 	UP BND X93 1
 	FR BND X94
 	LO BND X94 0
 	UP BND X94 1
 	FR BND X95
 	LO BND X95 0
 	UP BND X95 1
 	FR BND X96
 	LO BND X96 0
 	UP BND X96 1
 	FR BND X97
 	LO BND X97 0
 	UP BND X97 1
 	FR BND X98
 	LO BND X98 0
 	UP BND X98 1
 	FR BND X99
 	LO BND X99 0
 	UP BND X99 1
 	FR BND X100
 	LO BND X100 0
 	UP BND X100 1
 	FR BND X101
 	LO BND X101 0
 	UP BND X101 1
 	FR BND X102
 	LO BND X102 0
 	UP BND X102 1
 	FR BND X103
 	LO BND X103 0
 	UP BND X103 1
 	FR BND X104
 	LO BND X104 0
 	UP BND X104 1
 	FR BND X105
 	LO BND X105 0
 	UP BND X105 1
 	FR BND X106
 	LO BND X106 0
 	UP BND X106 1
 	FR BND X107
 	LO BND X107 0
 	UP BND X107 1
 	FR BND X108
 	LO BND X108 0
 	UP BND X108 1
 	FR BND X109
 	LO BND X109 0
 	UP BND X109 1
 	FR BND X110
 	LO BND X110 0
 	UP BND X110 1
 	FR BND X111
 	LO BND X111 0
 	UP BND X111 1
 	FR BND X112
 	LO BND X112 0
 	UP BND X112 1
 	FR BND X113
 	LO BND X113 0
 	UP BND X113 1
 	FR BND X114
 	LO BND X114 0
 	UP BND X114 1
 	FR BND X115
 	LO BND X115 0
 	UP BND X115 1
 	FR BND X116
 	LO BND X116 0
 	UP BND X116 1
 	FR BND X117
 	LO BND X117 0
 	UP BND X117 1
 	FR BND X118
 	LO BND X118 0
 	UP BND X118 1
 	FR BND X119
 	LO BND X119 0
 	UP BND X119 1
 	FR BND X120
 	LO BND X120 0
 	UP BND X120 1
 	FR BND X121
 	LO BND X121 0
 	UP BND X121 1
 	FR BND X122
 	LO BND X122 0
 	UP BND X122 1
 	FR BND X123
 	LO BND X123 0
 	UP BND X123 1
 	FR BND X124
 	LO BND X124 0
 	UP BND X124 1
 	FR BND X125
 	LO BND X125 0
 	UP BND X125 1
 	FR BND X126
 	LO BND X126 0
 	UP BND X126 1
 	FR BND X127
 	LO BND X127 0
 	UP BND X127 1
 	FR BND X128
 	LO BND X128 0
 	UP BND X128 1
 	FR BND X129
 	LO BND X129 0
 	UP BND X129 1
 	FR BND X130
 	LO BND X130 0
 	UP BND X130 1
 	FR BND X131
 	LO BND X131 0
 	UP BND X131 1
 	FR BND X132
 	LO BND X132 0
 	UP BND X132 1
 	FR BND X133
 	LO BND X133 0
 	UP BND X133 1
 	FR BND X134
 	LO BND X134 0
 	UP BND X134 1
 	FR BND X135
 	LO BND X135 0
 	UP BND X135 1
 	FR BND X136
 	LO BND X136 0
 	UP BND X136 1
 	FR BND X137
 	LO BND X137 0
 	UP BND X137 1
 	FR BND X138
 	LO BND X138 0
 	UP BND X138 1
 	FR BND X139
 	LO BND X139 0
 	UP BND X139 1
 	FR BND X140
 	LO BND X140 0
 	UP BND X140 1
 	FR BND X141
 	LO BND X141 0
 	UP BND X141 1
 	FR BND X142
 	LO BND X142 0
 	UP BND X142 1
 	FR BND X143
 	LO BND X143 0
 	UP BND X143 1
 	FR BND X144
 	LO BND X144 0
 	UP BND X144 1
 	FR BND X145
 	LO BND X145 0
 	UP BND X145 1
 	FR BND X146
 	LO BND X146 0
 	UP BND X146 1
 	FR BND X147
 	LO BND X147 0
 	UP BND X147 1
 	FR BND X148
 	LO BND X148 0
 	UP BND X148 1
 	FR BND X149
 	LO BND X149 0
 	UP BND X149 1
 	FR BND X150
 	LO BND X150 0
 	UP BND X150 1
 	FR BND X151
 	LO BND X151 0
 	UP BND X151 1
 	FR BND X152
 	LO BND X152 0
 	UP BND X152 1
 	FR BND X153
 	LO BND X153 0
 	UP BND X153 1
 	FR BND X154
 	LO BND X154 0
 	UP BND X154 1
 	FR BND X155
 	LO BND X155 0
 	UP BND X155 1
 	FR BND X156
 	LO BND X156 0
 	UP BND X156 1
 	FR BND X157
 	LO BND X157 0
 	UP BND X157 1
 	FR BND X158
 	LO BND X158 0
 	UP BND X158 1
 	FR BND X159
 	LO BND X159 0
 	UP BND X159 1
 	FR BND X160
 	LO BND X160 0
 	UP BND X160 1
 	FR BND X161
 	LO BND X161 0
 	UP BND X161 1
 	FR BND X162
 	LO BND X162 0
 	UP BND X162 1
 	FR BND X163
 	LO BND X163 0
 	UP BND X163 1
 	FR BND X164
 	LO BND X164 0
 	UP BND X164 1
 	FR BND X165
 	LO BND X165 0
 	UP BND X165 1
 	FR BND X166
 	LO BND X166 0
 	UP BND X166 1
 	FR BND X167
 	LO BND X167 0
 	UP BND X167 1
 	FR BND X168
 	LO BND X168 0
 	UP BND X168 1
 	FR BND X169
 	LO BND X169 0
 	UP BND X169 1
 	FR BND X170
 	LO BND X170 0
 	UP BND X170 1
 	FR BND X171
 	LO BND X171 0
 	UP BND X171 1
 	FR BND X172
 	LO BND X172 0
 	UP BND X172 1
 	FR BND X173
 	LO BND X173 0
 	UP BND X173 1
 	FR BND X174
 	LO BND X174 0
 	UP BND X174 1
 	FR BND X175
 	LO BND X175 0
 	UP BND X175 1
 	FR BND X176
 	LO BND X176 0
 	UP BND X176 1
 	FR BND X177
 	LO BND X177 0
 	UP BND X177 1
 	FR BND X178
 	LO BND X178 0
 	UP BND X178 1
 	FR BND X179
 	LO BND X179 0
 	UP BND X179 1
 	FR BND X180
 	LO BND X180 0
 	UP BND X180 1
 	FR BND X181
 	LO BND X181 0
 	UP BND X181 1
 	FR BND X182
 	LO BND X182 0
 	UP BND X182 1
 	FR BND X183
 	LO BND X183 0
 	UP BND X183 1
 	FR BND X184
 	LO BND X184 0
 	UP BND X184 1
 	FR BND X185
 	LO BND X185 0
 	UP BND X185 1
 	FR BND X186
 	LO BND X186 0
 	UP BND X186 1
 	FR BND X187
 	LO BND X187 0
 	UP BND X187 1
 	FR BND X188
 	LO BND X188 0
 	UP BND X188 1
 	FR BND X189
 	LO BND X189 0
 	UP BND X189 1
 	FR BND X190
 	LO BND X190 0
 	UP BND X190 1
 	FR BND X191
 	LO BND X191 0
 	UP BND X191 1
 	FR BND X192
 	LO BND X192 0
 	UP BND X192 1
 	FR BND X193
 	LO BND X193 0
 	UP BND X193 1
 	FR BND X194
 	LO BND X194 0
 	UP BND X194 1
 	FR BND X195
 	LO BND X195 0
 	UP BND X195 1
 	FR BND X196
 	LO BND X196 0
 	UP BND X196 1
 	FR BND X197
 	LO BND X197 0
 	UP BND X197 1
 	FR BND X198
 	LO BND X198 0
 	UP BND X198 1
 	FR BND X199
 	LO BND X199 0
 	UP BND X199 1
 	FR BND X200
 	LO BND X200 0
 	UP BND X200 1
 	FR BND X201
 	LO BND X201 0
 	UP BND X201 1
 	FR BND X202
 	LO BND X202 0
 	UP BND X202 1
 	FR BND X203
 	LO BND X203 0
 	UP BND X203 1
 	FR BND X204
 	LO BND X204 0
 	UP BND X204 1
 	FR BND X205
 	LO BND X205 0
 	UP BND X205 1
 	FR BND X206
 	LO BND X206 0
 	UP BND X206 1
 	FR BND X207
 	LO BND X207 0
 	UP BND X207 1
 	FR BND X208
 	LO BND X208 0
 	UP BND X208 1
 	FR BND X209
 	LO BND X209 0
 	UP BND X209 1
 	FR BND X210
 	LO BND X210 0
 	UP BND X210 1
 	FR BND X211
 	LO BND X211 0
 	UP BND X211 1
 	FR BND X212
 	LO BND X212 0
 	UP BND X212 1
 	FR BND X213
 	LO BND X213 0
 	UP BND X213 1
 	FR BND X214
 	LO BND X214 0
 	UP BND X214 1
 	FR BND X215
 	LO BND X215 0
 	UP BND X215 1
 	FR BND X216
 	LO BND X216 0
 	UP BND X216 1
 	FR BND X217
 	LO BND X217 0
 	UP BND X217 1
 	FR BND X218
 	LO BND X218 0
 	UP BND X218 1
 	FR BND X219
 	LO BND X219 0
 	UP BND X219 1
 	FR BND X220
 	LO BND X220 0
 	UP BND X220 1
 	FR BND X221
 	LO BND X221 0
 	UP BND X221 1
 	FR BND X222
 	LO BND X222 0
 	UP BND X222 1
 	FR BND X223
 	LO BND X223 0
 	UP BND X223 1
 	FR BND X224
 	LO BND X224 0
 	UP BND X224 1
 	FR BND X225
 	LO BND X225 0
 	UP BND X225 1
 	FR BND X226
 	LO BND X226 0
 	UP BND X226 1
 	FR BND X227
 	LO BND X227 0
 	UP BND X227 1
 	FR BND X228
 	LO BND X228 0
 	UP BND X228 1
 	FR BND X229
 	LO BND X229 0
 	UP BND X229 1
 	FR BND X230
 	LO BND X230 0
 	UP BND X230 1
 	FR BND X231
 	LO BND X231 0
 	UP BND X231 1
 	FR BND X232
 	LO BND X232 0
 	UP BND X232 1
 	FR BND X233
 	LO BND X233 0
 	UP BND X233 1
 	FR BND X234
 	LO BND X234 0
 	UP BND X234 1
 	FR BND X235
 	LO BND X235 0
 	UP BND X235 1
 	FR BND X236
 	LO BND X236 0
 	UP BND X236 1
 	FR BND X237
 	LO BND X237 0
 	UP BND X237 1
 	FR BND X238
 	LO BND X238 0
 	UP BND X238 1
 	FR BND X239
 	LO BND X239 0
 	UP BND X239 1
 	FR BND X240
 	LO BND X240 0
 	UP BND X240 1
 	FR BND X241
 	LO BND X241 0
 	UP BND X241 1
 	FR BND X242
 	LO BND X242 0
 	UP BND X242 1
 	FR BND X243
 	LO BND X243 0
 	UP BND X243 1
 	FR BND X244
 	LO BND X244 0
 	UP BND X244 1
 	FR BND X245
 	LO BND X245 0
 	UP BND X245 1
 	FR BND X246
 	LO BND X246 0
 	UP BND X246 1
 	FR BND X247
 	LO BND X247 0
 	UP BND X247 1
 	FR BND X248
 	LO BND X248 0
 	UP BND X248 1
 	FR BND X249
 	LO BND X249 0
 	UP BND X249 1
 	FR BND X250
 	LO BND X250 0
 	UP BND X250 1
 	FR BND X251
 	LO BND X251 0
 	UP BND X251 1
 	FR BND X252
 	LO BND X252 0
 	UP BND X252 1
 	FR BND X253
 	LO BND X253 0
 	UP BND X253 1
 	FR BND X254
 	LO BND X254 0
 	UP BND X254 1
 	FR BND X255
 	LO BND X255 0
 	UP BND X255 1
 	FR BND X256
 	LO BND X256 0
 	UP BND X256 1
 	FR BND X257
 	LO BND X257 0
 	UP BND X257 1
 	FR BND X258
 	LO BND X258 0
 	UP BND X258 1
 	FR BND X259
 	LO BND X259 0
 	UP BND X259 1
 	FR BND X260
 	LO BND X260 0
 	UP BND X260 1
 	FR BND X261
 	LO BND X261 0
 	UP BND X261 1
 	FR BND X262
 	LO BND X262 0
 	UP BND X262 1
 	FR BND X263
 	LO BND X263 0
 	UP BND X263 1
 	FR BND X264
 	LO BND X264 0
 	UP BND X264 1
 	FR BND X265
 	LO BND X265 0
 	UP BND X265 1
 	FR BND X266
 	LO BND X266 0
 	UP BND X266 1
 	FR BND X267
 	LO BND X267 0
 	UP BND X267 1
 	FR BND X268
 	LO BND X268 0
 	UP BND X268 1
 	FR BND X269
 	LO BND X269 0
 	UP BND X269 1
 	FR BND X270
 	LO BND X270 0
 	UP BND X270 1
 	FR BND X271
 	LO BND X271 0
 	UP BND X271 1
 	FR BND X272
 	LO BND X272 0
 	UP BND X272 1
 	FR BND X273
 	LO BND X273 0
 	UP BND X273 1
 	FR BND X274
 	LO BND X274 0
 	UP BND X274 1
 	FR BND X275
 	LO BND X275 0
 	UP BND X275 1
 	FR BND X276
 	LO BND X276 0
 	UP BND X276 1
 	FR BND X277
 	LO BND X277 0
 	UP BND X277 1
 	FR BND X278
 	LO BND X278 0
 	UP BND X278 1
 	FR BND X279
 	LO BND X279 0
 	UP BND X279 1
 	FR BND X280
 	LO BND X280 0
 	UP BND X280 1
 	FR BND X281
 	LO BND X281 0
 	UP BND X281 1
 	FR BND X282
 	LO BND X282 0
 	UP BND X282 1
 	FR BND X283
 	LO BND X283 0
 	UP BND X283 1
 	FR BND X284
 	LO BND X284 0
 	UP BND X284 1
 	FR BND X285
 	LO BND X285 0
 	UP BND X285 1
 	FR BND X286
 	LO BND X286 0
 	UP BND X286 1
 	FR BND X287
 	LO BND X287 0
 	UP BND X287 1
 	FR BND X288
 	LO BND X288 0
 	UP BND X288 1
 	FR BND X289
 	LO BND X289 0
 	UP BND X289 1
 	FR BND X290
 	LO BND X290 0
 	UP BND X290 1
 	FR BND X291
 	LO BND X291 0
 	UP BND X291 1
 	FR BND X292
 	LO BND X292 0
 	UP BND X292 1
 	FR BND X293
 	LO BND X293 0
 	UP BND X293 1
 	FR BND X294
 	LO BND X294 0
 	UP BND X294 1
 	FR BND X295
 	LO BND X295 0
 	UP BND X295 1
 	FR BND X296
 	LO BND X296 0
 	UP BND X296 1
 	FR BND X297
 	LO BND X297 0
 	UP BND X297 1
 	FR BND X298
 	LO BND X298 0
 	UP BND X298 1
 	FR BND X299
 	LO BND X299 0
 	UP BND X299 1
 	FR BND X300
 	LO BND X300 0
 	UP BND X300 1
 	FR BND X301
 	LO BND X301 0
 	UP BND X301 1
 	FR BND X302
 	LO BND X302 0
 	UP BND X302 1
 	FR BND X303
 	LO BND X303 0
 	UP BND X303 1
 	FR BND X304
 	LO BND X304 0
 	UP BND X304 1
 	FR BND X305
 	LO BND X305 0
 	UP BND X305 1
 	FR BND X306
 	LO BND X306 0
 	UP BND X306 1
 	FR BND X307
 	LO BND X307 0
 	UP BND X307 1
 	FR BND X308
 	LO BND X308 0
 	UP BND X308 1
 	FR BND X309
 	LO BND X309 0
 	UP BND X309 1
 	FR BND X310
 	LO BND X310 0
 	UP BND X310 1
 	FR BND X311
 	LO BND X311 0
 	UP BND X311 1
 	FR BND X312
 	LO BND X312 0
 	UP BND X312 1
 	FR BND X313
 	LO BND X313 0
 	UP BND X313 1
 	FR BND X314
 	LO BND X314 0
 	UP BND X314 1
 	FR BND X315
 	LO BND X315 0
 	UP BND X315 1
 	FR BND X316
 	LO BND X316 0
 	UP BND X316 1
 	FR BND X317
 	LO BND X317 0
 	UP BND X317 1
 	FR BND X318
 	LO BND X318 0
 	UP BND X318 1
 	FR BND X319
 	LO BND X319 0
 	UP BND X319 1
 	FR BND X320
 	LO BND X320 0
 	UP BND X320 1
 	FR BND X321
 	LO BND X321 0
 	UP BND X321 1
 	FR BND X322
 	LO BND X322 0
 	UP BND X322 1
 	FR BND X323
 	LO BND X323 0
 	UP BND X323 1
 	FR BND X324
 	LO BND X324 0
 	UP BND X324 1
 	FR BND X325
 	LO BND X325 0
 	UP BND X325 1
 	FR BND X326
 	LO BND X326 0
 	UP BND X326 1
 	FR BND X327
 	LO BND X327 0
 	UP BND X327 1
 	FR BND X328
 	LO BND X328 0
 	UP BND X328 1
 	FR BND X329
 	LO BND X329 0
 	UP BND X329 1
 	FR BND X330
 	LO BND X330 0
 	UP BND X330 1
 	FR BND X331
 	LO BND X331 0
 	UP BND X331 1
 	FR BND X332
 	LO BND X332 0
 	UP BND X332 1
 	FR BND X333
 	LO BND X333 0
 	UP BND X333 1
 	FR BND X334
 	LO BND X334 0
 	UP BND X334 1
 	FR BND X335
 	LO BND X335 0
 	UP BND X335 1
 	FR BND X336
 	LO BND X336 0
 	UP BND X336 1
 	FR BND X337
 	LO BND X337 0
 	UP BND X337 1
 	FR BND X338
 	LO BND X338 0
 	UP BND X338 1
 	FR BND X339
 	LO BND X339 0
 	UP BND X339 1
 	FR BND X340
 	LO BND X340 0
 	UP BND X340 1
 	FR BND X341
 	LO BND X341 0
 	UP BND X341 1
 	FR BND X342
 	LO BND X342 0
 	UP BND X342 1
 	FR BND X343
 	LO BND X343 0
 	UP BND X343 1
 	FR BND X344
 	LO BND X344 0
 	UP BND X344 1
 	FR BND X345
 	LO BND X345 0
 	UP BND X345 1
 	FR BND X346
 	LO BND X346 0
 	UP BND X346 1
 	FR BND X347
 	LO BND X347 0
 	UP BND X347 1
 	FR BND X348
 	LO BND X348 0
 	UP BND X348 1
 	FR BND X349
 	LO BND X349 0
 	UP BND X349 1
 	FR BND X350
 	LO BND X350 0
 	UP BND X350 1
 	FR BND X351
 	LO BND X351 0
 	UP BND X351 1
 	FR BND X352
 	LO BND X352 0
 	UP BND X352 1
 	FR BND X353
 	LO BND X353 0
 	UP BND X353 1
 	FR BND X354
 	LO BND X354 0
 	UP BND X354 1
 	FR BND X355
 	LO BND X355 0
 	UP BND X355 1
 	FR BND X356
 	LO BND X356 0
 	UP BND X356 1
 	FR BND X357
 	LO BND X357 0
 	UP BND X357 1
 	FR BND X358
 	LO BND X358 0
 	UP BND X358 1
 	FR BND X359
 	LO BND X359 0
 	UP BND X359 1
 	FR BND X360
 	LO BND X360 0
 	UP BND X360 1
 	FR BND X361
 	LO BND X361 0
 	UP BND X361 1
 	FR BND X362
 	LO BND X362 0
 	UP BND X362 1
 	FR BND X363
 	LO BND X363 0
 	UP BND X363 1
 	FR BND X364
 	LO BND X364 0
 	UP BND X364 1
 	FR BND X365
 	LO BND X365 0
 	UP BND X365 1
 	FR BND X366
 	LO BND X366 0
 	UP BND X366 1
 	FR BND X367
 	LO BND X367 0
 	UP BND X367 1
 	FR BND X368
 	LO BND X368 0
 	UP BND X368 1
 	FR BND X369
 	LO BND X369 0
 	UP BND X369 1
 	FR BND X370
 	LO BND X370 0
 	UP BND X370 1
 	FR BND X371
 	LO BND X371 0
 	UP BND X371 1
 	FR BND X372
 	LO BND X372 0
 	UP BND X372 1
 	FR BND X373
 	LO BND X373 0
 	UP BND X373 1
 	FR BND X374
 	LO BND X374 0
 	UP BND X374 1
 	FR BND X375
 	LO BND X375 0
 	UP BND X375 1
 	FR BND X376
 	LO BND X376 0
 	UP BND X376 1
 	FR BND X377
 	LO BND X377 0
 	UP BND X377 1
 	FR BND X378
 	LO BND X378 0
 	UP BND X378 1
 	FR BND X379
 	LO BND X379 0
 	UP BND X379 1
 	FR BND X380
 	LO BND X380 0
 	UP BND X380 1
 	FR BND X381
 	LO BND X381 0
 	UP BND X381 1
 	FR BND X382
 	LO BND X382 0
 	UP BND X382 1
 	FR BND X383
 	LO BND X383 0
 	UP BND X383 1
 	FR BND X384
 	LO BND X384 0
 	UP BND X384 1
 	FR BND X385
 	LO BND X385 0
 	UP BND X385 1
 	FR BND X386
 	LO BND X386 0
 	UP BND X386 1
 	FR BND X387
 	LO BND X387 0
 	UP BND X387 1
 	FR BND X388
 	LO BND X388 0
 	UP BND X388 1
 	FR BND X389
 	LO BND X389 0
 	UP BND X389 1
 	FR BND X390
 	LO BND X390 0
 	UP BND X390 1
 	FR BND X391
 	LO BND X391 0
 	UP BND X391 1
 	FR BND X392
 	LO BND X392 0
 	UP BND X392 1
 	FR BND X393
 	LO BND X393 0
 	UP BND X393 1
 	FR BND X394
 	LO BND X394 0
 	UP BND X394 1
 	FR BND X395
 	LO BND X395 0
 	UP BND X395 1
 	FR BND X396
 	LO BND X396 0
 	UP BND X396 1
 	FR BND X397
 	LO BND X397 0
 	UP BND X397 1
 	FR BND X398
 	LO BND X398 0
 	UP BND X398 1
 	FR BND X399
 	LO BND X399 0
 	UP BND X399 1
 	FR BND X400
 	LO BND X400 0
 	UP BND X400 1
 	FR BND X401
 	LO BND X401 0
 	UP BND X401 1
 	FR BND X402
 	LO BND X402 0
 	UP BND X402 1
 	FR BND X403
 	LO BND X403 0
 	UP BND X403 1
 	FR BND X404
 	LO BND X404 0
 	UP BND X404 1
 	FR BND X405
 	LO BND X405 0
 	UP BND X405 1
 	FR BND X406
 	LO BND X406 0
 	UP BND X406 1
 	FR BND X407
 	LO BND X407 0
 	UP BND X407 1
 	FR BND X408
 	LO BND X408 0
 	UP BND X408 1
 	FR BND X409
 	LO BND X409 0
 	UP BND X409 1
 	FR BND X410
 	LO BND X410 0
 	UP BND X410 1
 	FR BND X411
 	LO BND X411 0
 	UP BND X411 1
 	FR BND X412
 	LO BND X412 0
 	UP BND X412 1
 	FR BND X413
 	LO BND X413 0
 	UP BND X413 1
 	FR BND X414
 	LO BND X414 0
 	UP BND X414 1
 	FR BND X415
 	LO BND X415 0
 	UP BND X415 1
 	FR BND X416
 	LO BND X416 0
 	UP BND X416 1
 	FR BND X417
 	LO BND X417 0
 	UP BND X417 1
 	FR BND X418
 	LO BND X418 0
 	UP BND X418 1
 	FR BND X419
 	LO BND X419 0
 	UP BND X419 1
 	FR BND X420
 	LO BND X420 0
 	UP BND X420 1
 	FR BND X421
 	LO BND X421 0
 	UP BND X421 1
 	FR BND X422
 	LO BND X422 0
 	UP BND X422 1
 	FR BND X423
 	LO BND X423 0
 	UP BND X423 1
 	FR BND X424
 	LO BND X424 0
 	UP BND X424 1
 	FR BND X425
 	LO BND X425 0
 	UP BND X425 1
 	FR BND X426
 	LO BND X426 0
 	UP BND X426 1
 	FR BND X427
 	LO BND X427 0
 	UP BND X427 1
 	FR BND X428
 	LO BND X428 0
 	UP BND X428 1
 	FR BND X429
 	LO BND X429 0
 	UP BND X429 1
 	FR BND X430
 	LO BND X430 0
 	UP BND X430 1
 	FR BND X431
 	LO BND X431 0
 	UP BND X431 1
 	FR BND X432
 	LO BND X432 0
 	UP BND X432 1
 	FR BND X433
 	LO BND X433 0
 	UP BND X433 1
 	FR BND X434
 	LO BND X434 0
 	UP BND X434 1
 	FR BND X435
 	LO BND X435 0
 	UP BND X435 1
 	FR BND X436
 	LO BND X436 0
 	UP BND X436 1
 	FR BND X437
 	LO BND X437 0
 	UP BND X437 1
 	FR BND X438
 	LO BND X438 0
 	UP BND X438 1
 	FR BND X439
 	LO BND X439 0
 	UP BND X439 1
 	FR BND X440
 	LO BND X440 0
 	UP BND X440 1
 	FR BND X441
 	LO BND X441 0
 	UP BND X441 1
 	FR BND X442
 	LO BND X442 0
 	UP BND X442 1
 	FR BND X443
 	LO BND X443 0
 	UP BND X443 1
 	FR BND X444
 	LO BND X444 0
 	UP BND X444 1
 	FR BND X445
 	LO BND X445 0
 	UP BND X445 1
 	FR BND X446
 	LO BND X446 0
 	UP BND X446 1
 	FR BND X447
 	LO BND X447 0
 	UP BND X447 1
 	FR BND X448
 	LO BND X448 0
 	UP BND X448 1
 	FR BND X449
 	LO BND X449 0
 	UP BND X449 1
 	FR BND X450
 	LO BND X450 0
 	UP BND X450 1
 	FR BND X451
 	LO BND X451 0
 	UP BND X451 1
 	FR BND X452
 	LO BND X452 0
 	UP BND X452 1
 	FR BND X453
 	LO BND X453 0
 	UP BND X453 1
 	FR BND X454
 	LO BND X454 0
 	UP BND X454 1
 	FR BND X455
 	LO BND X455 0
 	UP BND X455 1
 	FR BND X456
 	LO BND X456 0
 	UP BND X456 1
 	FR BND X457
 	LO BND X457 0
 	UP BND X457 1
 	FR BND X458
 	LO BND X458 0
 	UP BND X458 1
 	FR BND X459
 	LO BND X459 0
 	UP BND X459 1
 	FR BND X460
 	LO BND X460 0
 	UP BND X460 1
 	FR BND X461
 	LO BND X461 0
 	UP BND X461 1
 	FR BND X462
 	LO BND X462 0
 	UP BND X462 1
 	FR BND X463
 	LO BND X463 0
 	UP BND X463 1
 	FR BND X464
 	LO BND X464 0
 	UP BND X464 1
 	FR BND X465
 	LO BND X465 0
 	UP BND X465 1
 	FR BND X466
 	LO BND X466 0
 	UP BND X466 1
 	FR BND X467
 	LO BND X467 0
 	UP BND X467 1
 	FR BND X468
 	LO BND X468 0
 	UP BND X468 1
 	FR BND X469
 	LO BND X469 0
 	UP BND X469 1
 	FR BND X470
 	LO BND X470 0
 	UP BND X470 1
 	FR BND X471
 	LO BND X471 0
 	UP BND X471 1
 	FR BND X472
 	LO BND X472 0
 	UP BND X472 1
 	FR BND X473
 	LO BND X473 0
 	UP BND X473 1
 	FR BND X474
 	LO BND X474 0
 	UP BND X474 1
 	FR BND X475
 	LO BND X475 0
 	UP BND X475 1
 	FR BND X476
 	LO BND X476 0
 	UP BND X476 1
 	FR BND X477
 	LO BND X477 0
 	UP BND X477 1
 	FR BND X478
 	LO BND X478 0
 	UP BND X478 1
 	FR BND X479
 	LO BND X479 0
 	UP BND X479 1
 	FR BND X480
 	LO BND X480 0
 	UP BND X480 1
 	FR BND X481
 	LO BND X481 0
 	UP BND X481 1
 	FR BND X482
 	LO BND X482 0
 	UP BND X482 1
 	FR BND X483
 	LO BND X483 0
 	UP BND X483 1
 	FR BND X484
 	LO BND X484 0
 	UP BND X484 1
 	FR BND X485
 	LO BND X485 0
 	UP BND X485 1
 	FR BND X486
 	LO BND X486 0
 	UP BND X486 1
 	FR BND X487
 	LO BND X487 0
 	UP BND X487 1
 	FR BND X488
 	LO BND X488 0
 	UP BND X488 1
 	FR BND X489
 	LO BND X489 0
 	UP BND X489 1
 	FR BND X490
 	LO BND X490 0
 	UP BND X490 1
 	FR BND X491
 	LO BND X491 0
 	UP BND X491 1
 	FR BND X492
 	LO BND X492 0
 	UP BND X492 1
 	FR BND X493
 	LO BND X493 0
 	UP BND X493 1
 	FR BND X494
 	LO BND X494 0
 	UP BND X494 1
 	FR BND X495
 	LO BND X495 0
 	UP BND X495 1
 	FR BND X496
 	LO BND X496 0
 	UP BND X496 1
 	FR BND X497
 	LO BND X497 0
 	UP BND X497 1
 	FR BND X498
 	LO BND X498 0
 	UP BND X498 1
 	FR BND X499
 	LO BND X499 0
 	UP BND X499 1
 	FR BND X500
 	LO BND X500 0
 	UP BND X500 1
 	FR BND X501
 	LO BND X501 0
 	UP BND X501 1
 	FR BND X502
 	LO BND X502 0
 	UP BND X502 1
 	FR BND X503
 	LO BND X503 0
 	UP BND X503 1
 	FR BND X504
 	LO BND X504 0
 	UP BND X504 1
 	FR BND X505
 	LO BND X505 0
 	UP BND X505 1
 	FR BND X506
 	LO BND X506 0
 	UP BND X506 1
 	FR BND X507
 	LO BND X507 0
 	UP BND X507 1
 	FR BND X508
 	LO BND X508 0
 	UP BND X508 1
 	FR BND X509
 	LO BND X509 0
 	UP BND X509 1
 	FR BND X510
 	LO BND X510 0
 	UP BND X510 1
 	FR BND X511
 	LO BND X511 0
 	UP BND X511 1
 	FR BND X512
 	LO BND X512 0
 	UP BND X512 1
 	FR BND X513
 	LO BND X513 0
 	UP BND X513 1
 	FR BND X514
 	LO BND X514 0
 	UP BND X514 1
 	FR BND X515
 	LO BND X515 0
 	UP BND X515 1
 	FR BND X516
 	LO BND X516 0
 	UP BND X516 1
 	FR BND X517
 	LO BND X517 0
 	UP BND X517 1
 	FR BND X518
 	LO BND X518 0
 	UP BND X518 1
 	FR BND X519
 	LO BND X519 0
 	UP BND X519 1
 	FR BND X520
 	LO BND X520 0
 	UP BND X520 1
 	FR BND X521
 	LO BND X521 0
 	UP BND X521 1
 	FR BND X522
 	LO BND X522 0
 	UP BND X522 1
 	FR BND X523
 	LO BND X523 0
 	UP BND X523 1
 	FR BND X524
 	LO BND X524 0
 	UP BND X524 1
 	FR BND X525
 	LO BND X525 0
 	UP BND X525 1
 	FR BND X526
 	LO BND X526 0
 	UP BND X526 1
 	FR BND X527
 	LO BND X527 0
 	UP BND X527 1
 	FR BND X528
 	LO BND X528 0
 	UP BND X528 1
 	FR BND X529
 	LO BND X529 0
 	UP BND X529 1
 	FR BND X530
 	LO BND X530 0
 	UP BND X530 1
 	FR BND X531
 	LO BND X531 0
 	UP BND X531 1
 	FR BND X532
 	LO BND X532 0
 	UP BND X532 1
 	FR BND X533
 	LO BND X533 0
 	UP BND X533 1
 	FR BND X534
 	LO BND X534 0
 	UP BND X534 1
ENDATA
