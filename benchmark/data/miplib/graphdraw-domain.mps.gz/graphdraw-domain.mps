* MIPLIB 2017 benchmark v2; LP relaxation (integrality removed).
* Source: https://miplib.zib.de/downloads/benchmark.zip ; retrieved 2026-09-21
* Instance: graphdraw-domain ; Gleixner et al. (2021), doi:10.1007/s12532-020-00194-3
* Bounds and coefficients preserved; rows/variables renamed; objective minimized.
* Original compressed SHA256: b34048178c8856db760e87b62d22a11dda8690103a2c51540e578ab16644e80c
* Problem:    1st_phase
* Class:      MIP
* Rows:       866
* Columns:    254 (200 integer, 180 binary)
* Non-zeros:  2654
* Format:     Free MPS
*
NAME graphdraw-domain
ROWS
 N OBJ
 E R0
 E R1
 E R2
 E R3
 E R4
 E R5
 E R6
 E R7
 E R8
 E R9
 E R10
 E R11
 E R12
 E R13
 E R14
 E R15
 E R16
 E R17
 E R18
 E R19
 E R20
 E R21
 E R22
 E R23
 E R24
 E R25
 E R26
 E R27
 E R28
 E R29
 E R30
 E R31
 E R32
 E R33
 E R34
 E R35
 E R36
 E R37
 E R38
 E R39
 E R40
 E R41
 E R42
 E R43
 E R44
 G R45
 G R46
 G R47
 G R48
 G R49
 G R50
 G R51
 G R52
 G R53
 G R54
 G R55
 G R56
 G R57
 G R58
 G R59
 G R60
 G R61
 G R62
 G R63
 G R64
 G R65
 G R66
 G R67
 G R68
 G R69
 G R70
 G R71
 G R72
 G R73
 G R74
 G R75
 G R76
 G R77
 G R78
 G R79
 G R80
 G R81
 G R82
 G R83
 G R84
 G R85
 G R86
 G R87
 G R88
 G R89
 G R90
 G R91
 G R92
 G R93
 G R94
 G R95
 G R96
 G R97
 G R98
 G R99
 G R100
 G R101
 G R102
 G R103
 G R104
 G R105
 G R106
 G R107
 G R108
 G R109
 G R110
 G R111
 G R112
 G R113
 G R114
 G R115
 G R116
 G R117
 G R118
 G R119
 G R120
 G R121
 G R122
 G R123
 G R124
 G R125
 G R126
 G R127
 G R128
 G R129
 G R130
 G R131
 G R132
 G R133
 G R134
 G R135
 G R136
 G R137
 G R138
 G R139
 G R140
 G R141
 G R142
 G R143
 G R144
 G R145
 G R146
 G R147
 G R148
 G R149
 G R150
 G R151
 G R152
 G R153
 G R154
 G R155
 G R156
 G R157
 G R158
 G R159
 G R160
 G R161
 G R162
 G R163
 G R164
 G R165
 G R166
 G R167
 G R168
 G R169
 G R170
 G R171
 G R172
 G R173
 G R174
 G R175
 G R176
 G R177
 G R178
 G R179
 G R180
 G R181
 G R182
 G R183
 G R184
 G R185
 G R186
 G R187
 G R188
 G R189
 G R190
 G R191
 G R192
 G R193
 G R194
 G R195
 G R196
 G R197
 G R198
 G R199
 G R200
 G R201
 G R202
 G R203
 G R204
 G R205
 G R206
 G R207
 G R208
 G R209
 G R210
 G R211
 G R212
 G R213
 G R214
 G R215
 G R216
 G R217
 G R218
 G R219
 G R220
 G R221
 G R222
 G R223
 G R224
 G R225
 G R226
 G R227
 G R228
 G R229
 G R230
 G R231
 G R232
 G R233
 G R234
 G R235
 G R236
 G R237
 G R238
 G R239
 G R240
 G R241
 G R242
 G R243
 G R244
 G R245
 G R246
 G R247
 G R248
 G R249
 G R250
 G R251
 G R252
 G R253
 G R254
 G R255
 G R256
 G R257
 G R258
 G R259
 G R260
 G R261
 G R262
 G R263
 G R264
 G R265
 G R266
 G R267
 G R268
 G R269
 G R270
 G R271
 G R272
 G R273
 G R274
 G R275
 G R276
 G R277
 G R278
 G R279
 G R280
 G R281
 G R282
 G R283
 G R284
 G R285
 G R286
 G R287
 G R288
 G R289
 G R290
 G R291
 G R292
 G R293
 G R294
 G R295
 G R296
 G R297
 G R298
 G R299
 G R300
 G R301
 G R302
 G R303
 G R304
 G R305
 G R306
 G R307
 G R308
 G R309
 G R310
 G R311
 G R312
 G R313
 G R314
 G R315
 G R316
 G R317
 G R318
 G R319
 G R320
 G R321
 G R322
 G R323
 G R324
 G R325
 G R326
 G R327
 G R328
 G R329
 G R330
 G R331
 G R332
 G R333
 G R334
 G R335
 G R336
 G R337
 G R338
 G R339
 G R340
 G R341
 G R342
 G R343
 G R344
 G R345
 G R346
 G R347
 G R348
 G R349
 G R350
 G R351
 G R352
 G R353
 G R354
 G R355
 G R356
 G R357
 G R358
 G R359
 G R360
 G R361
 G R362
 G R363
 G R364
 G R365
 G R366
 G R367
 G R368
 G R369
 G R370
 G R371
 G R372
 G R373
 G R374
 G R375
 G R376
 G R377
 G R378
 G R379
 G R380
 G R381
 G R382
 G R383
 G R384
 L R385
 L R386
 L R387
 L R388
 L R389
 L R390
 L R391
 L R392
 L R393
 L R394
 L R395
 L R396
 L R397
 L R398
 L R399
 L R400
 L R401
 L R402
 L R403
 L R404
 L R405
 L R406
 L R407
 L R408
 L R409
 L R410
 L R411
 L R412
 L R413
 L R414
 L R415
 L R416
 L R417
 L R418
 L R419
 L R420
 L R421
 L R422
 L R423
 L R424
 L R425
 L R426
 L R427
 L R428
 L R429
 L R430
 L R431
 L R432
 L R433
 L R434
 L R435
 L R436
 L R437
 L R438
 L R439
 L R440
 L R441
 L R442
 L R443
 L R444
 L R445
 L R446
 L R447
 L R448
 L R449
 L R450
 L R451
 L R452
 L R453
 L R454
 L R455
 L R456
 L R457
 L R458
 L R459
 L R460
 L R461
 L R462
 L R463
 L R464
 L R465
 L R466
 L R467
 L R468
 L R469
 L R470
 L R471
 L R472
 L R473
 L R474
 L R475
 L R476
 L R477
 L R478
 L R479
 L R480
 L R481
 L R482
 L R483
 L R484
 L R485
 L R486
 L R487
 L R488
 L R489
 L R490
 L R491
 L R492
 L R493
 L R494
 L R495
 L R496
 L R497
 L R498
 L R499
 L R500
 L R501
 L R502
 L R503
 L R504
 L R505
 L R506
 L R507
 L R508
 L R509
 L R510
 L R511
 L R512
 L R513
 L R514
 L R515
 L R516
 L R517
 L R518
 L R519
 L R520
 L R521
 L R522
 L R523
 L R524
 L R525
 L R526
 L R527
 L R528
 L R529
 L R530
 L R531
 L R532
 L R533
 L R534
 L R535
 L R536
 L R537
 L R538
 L R539
 L R540
 L R541
 L R542
 L R543
 L R544
 L R545
 L R546
 L R547
 L R548
 L R549
 L R550
 L R551
 L R552
 L R553
 L R554
 L R555
 L R556
 L R557
 L R558
 L R559
 L R560
 L R561
 L R562
 L R563
 L R564
 L R565
 L R566
 L R567
 L R568
 L R569
 L R570
 L R571
 L R572
 L R573
 L R574
 L R575
 L R576
 L R577
 L R578
 L R579
 L R580
 L R581
 L R582
 L R583
 L R584
 L R585
 L R586
 L R587
 L R588
 L R589
 L R590
 L R591
 L R592
 L R593
 L R594
 L R595
 L R596
 L R597
 L R598
 L R599
 L R600
 L R601
 L R602
 L R603
 L R604
 L R605
 L R606
 L R607
 L R608
 L R609
 L R610
 L R611
 L R612
 L R613
 L R614
 L R615
 L R616
 L R617
 L R618
 L R619
 L R620
 L R621
 L R622
 L R623
 L R624
 L R625
 L R626
 L R627
 L R628
 L R629
 L R630
 L R631
 L R632
 L R633
 L R634
 L R635
 L R636
 L R637
 L R638
 L R639
 L R640
 L R641
 L R642
 L R643
 L R644
 L R645
 L R646
 L R647
 L R648
 L R649
 L R650
 L R651
 L R652
 L R653
 L R654
 L R655
 L R656
 L R657
 L R658
 L R659
 L R660
 L R661
 L R662
 L R663
 L R664
 L R665
 L R666
 L R667
 L R668
 L R669
 L R670
 L R671
 L R672
 L R673
 L R674
 L R675
 L R676
 L R677
 L R678
 L R679
 L R680
 L R681
 L R682
 L R683
 L R684
 L R685
 L R686
 L R687
 L R688
 L R689
 L R690
 L R691
 L R692
 L R693
 L R694
 L R695
 L R696
 L R697
 L R698
 L R699
 L R700
 L R701
 L R702
 L R703
 L R704
 L R705
 L R706
 L R707
 L R708
 L R709
 L R710
 L R711
 L R712
 L R713
 L R714
 L R715
 L R716
 L R717
 L R718
 L R719
 L R720
 L R721
 L R722
 L R723
 L R724
 L R725
 L R726
 L R727
 L R728
 L R729
 L R730
 L R731
 L R732
 L R733
 L R734
 L R735
 L R736
 L R737
 L R738
 L R739
 L R740
 L R741
 L R742
 L R743
 L R744
 L R745
 L R746
 L R747
 L R748
 L R749
 L R750
 L R751
 L R752
 L R753
 L R754
 L R755
 L R756
 L R757
 L R758
 L R759
 L R760
 L R761
 L R762
 L R763
 L R764
 L R765
 L R766
 L R767
 L R768
 L R769
 L R770
 L R771
 L R772
 L R773
 L R774
 L R775
 L R776
 L R777
 L R778
 L R779
 L R780
 L R781
 L R782
 L R783
 L R784
 L R785
 L R786
 L R787
 L R788
 L R789
 L R790
 L R791
 L R792
 L R793
 L R794
 L R795
 L R796
 L R797
 L R798
 L R799
 L R800
 L R801
 L R802
 L R803
 L R804
 L R805
 L R806
 L R807
 L R808
 L R809
 L R810
 L R811
 L R812
 L R813
 L R814
 L R815
 L R816
 L R817
 L R818
 L R819
 L R820
 L R821
 L R822
 L R823
 L R824
 L R825
 L R826
 L R827
 L R828
 L R829
 L R830
 L R831
 L R832
 L R833
 L R834
 L R835
 L R836
 L R837
 L R838
 L R839
 L R840
 L R841
 L R842
 L R843
 L R844
 L R845
 L R846
 L R847
 L R848
 L R849
 L R850
 L R851
 L R852
 L R853
 L R854
 L R855
 L R856
 L R857
 L R858
 L R859
 L R860
 L R861
 L R862
 L R863
 L R864
COLUMNS
    X0                   OBJ 0
    X0                   R45 1
    X0                   R65 -1
    X0                   R85 -1
    X0                   R86 -1
    X0                   R87 -1
    X0                   R88 -1
    X0                   R89 -1
    X0                   R90 -1
    X0                   R91 -1
    X0                   R92 -1
    X0                   R93 -1
    X0                   R175 1
    X0                   R176 1
    X0                   R177 1
    X0                   R178 1
    X0                   R179 1
    X0                   R180 1
    X0                   R181 1
    X0                   R182 1
    X0                   R183 1
    X0                   R265 -1
    X0                   R266 -1
    X0                   R267 -1
    X0                   R268 -1
    X0                   R269 -1
    X0                   R299 1
    X0                   R300 1
    X0                   R301 1
    X0                   R302 1
    X0                   R303 1
    X1                   OBJ 0
    X1                   R46 1
    X1                   R66 -1
    X1                   R85 1
    X1                   R94 -1
    X1                   R95 -1
    X1                   R96 -1
    X1                   R97 -1
    X1                   R98 -1
    X1                   R99 -1
    X1                   R100 -1
    X1                   R101 -1
    X1                   R175 -1
    X1                   R184 1
    X1                   R185 1
    X1                   R186 1
    X1                   R187 1
    X1                   R188 1
    X1                   R189 1
    X1                   R190 1
    X1                   R191 1
    X1                   R265 1
    X1                   R270 -1
    X1                   R299 -1
    X1                   R304 1
    X2                   OBJ 0
    X2                   R47 1
    X2                   R67 -1
    X2                   R86 1
    X2                   R94 1
    X2                   R102 -1
    X2                   R103 -1
    X2                   R104 -1
    X2                   R105 -1
    X2                   R106 -1
    X2                   R107 -1
    X2                   R108 -1
    X2                   R176 -1
    X2                   R184 -1
    X2                   R192 1
    X2                   R193 1
    X2                   R194 1
    X2                   R195 1
    X2                   R196 1
    X2                   R197 1
    X2                   R198 1
    X2                   R271 -1
    X2                   R305 1
    X3                   OBJ 0
    X3                   R48 1
    X3                   R68 -1
    X3                   R87 1
    X3                   R95 1
    X3                   R102 1
    X3                   R109 -1
    X3                   R110 -1
    X3                   R111 -1
    X3                   R112 -1
    X3                   R113 -1
    X3                   R114 -1
    X3                   R177 -1
    X3                   R185 -1
    X3                   R192 -1
    X3                   R199 1
    X3                   R200 1
    X3                   R201 1
    X3                   R202 1
    X3                   R203 1
    X3                   R204 1
    X3                   R279 -1
    X3                   R313 1
    X4                   OBJ 0
    X4                   R49 1
    X4                   R69 -1
    X4                   R88 1
    X4                   R96 1
    X4                   R103 1
    X4                   R109 1
    X4                   R115 -1
    X4                   R116 -1
    X4                   R117 -1
    X4                   R118 -1
    X4                   R119 -1
    X4                   R178 -1
    X4                   R186 -1
    X4                   R193 -1
    X4                   R199 -1
    X4                   R205 1
    X4                   R206 1
    X4                   R207 1
    X4                   R208 1
    X4                   R209 1
    X4                   R269 1
    X4                   R279 1
    X4                   R280 -1
    X4                   R281 -1
    X4                   R303 -1
    X4                   R313 -1
    X4                   R314 1
    X4                   R315 1
    X5                   OBJ 0
    X5                   R50 1
    X5                   R70 -1
    X5                   R89 1
    X5                   R97 1
    X5                   R104 1
    X5                   R110 1
    X5                   R115 1
    X5                   R120 -1
    X5                   R121 -1
    X5                   R122 -1
    X5                   R123 -1
    X5                   R179 -1
    X5                   R187 -1
    X5                   R194 -1
    X5                   R200 -1
    X5                   R205 -1
    X5                   R210 1
    X5                   R211 1
    X5                   R212 1
    X5                   R213 1
    X5                   R266 1
    X5                   R270 1
    X5                   R271 1
    X5                   R272 -1
    X5                   R277 1
    X5                   R278 1
    X5                   R300 -1
    X5                   R304 -1
    X5                   R305 -1
    X5                   R306 1
    X5                   R311 -1
    X5                   R312 -1
    X6                   OBJ 0
    X6                   R51 1
    X6                   R71 -1
    X6                   R90 1
    X6                   R98 1
    X6                   R105 1
    X6                   R111 1
    X6                   R116 1
    X6                   R120 1
    X6                   R124 -1
    X6                   R125 -1
    X6                   R126 -1
    X6                   R180 -1
    X6                   R188 -1
    X6                   R195 -1
    X6                   R201 -1
    X6                   R206 -1
    X6                   R210 -1
    X6                   R214 1
    X6                   R215 1
    X6                   R216 1
    X6                   R274 -1
    X6                   R275 -1
    X6                   R308 1
    X6                   R309 1
    X7                   OBJ 0
    X7                   R52 1
    X7                   R72 -1
    X7                   R91 1
    X7                   R99 1
    X7                   R106 1
    X7                   R112 1
    X7                   R117 1
    X7                   R121 1
    X7                   R124 1
    X7                   R127 -1
    X7                   R128 -1
    X7                   R181 -1
    X7                   R189 -1
    X7                   R196 -1
    X7                   R202 -1
    X7                   R207 -1
    X7                   R211 -1
    X7                   R214 -1
    X7                   R217 1
    X7                   R218 1
    X7                   R268 1
    X7                   R273 1
    X7                   R274 1
    X7                   R276 -1
    X7                   R277 -1
    X7                   R302 -1
    X7                   R307 -1
    X7                   R308 -1
    X7                   R310 1
    X7                   R311 1
    X8                   OBJ 0
    X8                   R53 1
    X8                   R73 -1
    X8                   R92 1
    X8                   R100 1
    X8                   R107 1
    X8                   R113 1
    X8                   R118 1
    X8                   R122 1
    X8                   R125 1
    X8                   R127 1
    X8                   R129 -1
    X8                   R182 -1
    X8                   R190 -1
    X8                   R197 -1
    X8                   R203 -1
    X8                   R208 -1
    X8                   R212 -1
    X8                   R215 -1
    X8                   R217 -1
    X8                   R219 1
    X8                   R275 1
    X8                   R276 1
    X8                   R278 -1
    X8                   R281 1
    X8                   R309 -1
    X8                   R310 -1
    X8                   R312 1
    X8                   R315 -1
    X9                   OBJ 0
    X9                   R54 1
    X9                   R74 -1
    X9                   R93 1
    X9                   R101 1
    X9                   R108 1
    X9                   R114 1
    X9                   R119 1
    X9                   R123 1
    X9                   R126 1
    X9                   R128 1
    X9                   R129 1
    X9                   R183 -1
    X9                   R191 -1
    X9                   R198 -1
    X9                   R204 -1
    X9                   R209 -1
    X9                   R213 -1
    X9                   R216 -1
    X9                   R218 -1
    X9                   R219 -1
    X9                   R267 1
    X9                   R272 1
    X9                   R273 -1
    X9                   R280 1
    X9                   R301 -1
    X9                   R306 -1
    X9                   R307 1
    X9                   R314 -1
    X10                  OBJ 0
    X10                  R55 1
    X10                  R75 -1
    X10                  R130 -1
    X10                  R131 -1
    X10                  R132 -1
    X10                  R133 -1
    X10                  R134 -1
    X10                  R135 -1
    X10                  R136 -1
    X10                  R137 -1
    X10                  R138 -1
    X10                  R220 1
    X10                  R221 1
    X10                  R222 1
    X10                  R223 1
    X10                  R224 1
    X10                  R225 1
    X10                  R226 1
    X10                  R227 1
    X10                  R228 1
    X10                  R282 -1
    X10                  R283 -1
    X10                  R284 -1
    X10                  R285 -1
    X10                  R286 -1
    X10                  R316 1
    X10                  R317 1
    X10                  R318 1
    X10                  R319 1
    X10                  R320 1
    X11                  OBJ 0
    X11                  R56 1
    X11                  R76 -1
    X11                  R130 1
    X11                  R139 -1
    X11                  R140 -1
    X11                  R141 -1
    X11                  R142 -1
    X11                  R143 -1
    X11                  R144 -1
    X11                  R145 -1
    X11                  R146 -1
    X11                  R220 -1
    X11                  R229 1
    X11                  R230 1
    X11                  R231 1
    X11                  R232 1
    X11                  R233 1
    X11                  R234 1
    X11                  R235 1
    X11                  R236 1
    X11                  R282 1
    X11                  R287 -1
    X11                  R316 -1
    X11                  R321 1
    X12                  OBJ 0
    X12                  R57 1
    X12                  R77 -1
    X12                  R131 1
    X12                  R139 1
    X12                  R147 -1
    X12                  R148 -1
    X12                  R149 -1
    X12                  R150 -1
    X12                  R151 -1
    X12                  R152 -1
    X12                  R153 -1
    X12                  R221 -1
    X12                  R229 -1
    X12                  R237 1
    X12                  R238 1
    X12                  R239 1
    X12                  R240 1
    X12                  R241 1
    X12                  R242 1
    X12                  R243 1
    X12                  R288 -1
    X12                  R322 1
    X13                  OBJ 0
    X13                  R58 1
    X13                  R78 -1
    X13                  R132 1
    X13                  R140 1
    X13                  R147 1
    X13                  R154 -1
    X13                  R155 -1
    X13                  R156 -1
    X13                  R157 -1
    X13                  R158 -1
    X13                  R159 -1
    X13                  R222 -1
    X13                  R230 -1
    X13                  R237 -1
    X13                  R244 1
    X13                  R245 1
    X13                  R246 1
    X13                  R247 1
    X13                  R248 1
    X13                  R249 1
    X13                  R296 -1
    X13                  R330 1
    X14                  OBJ 0
    X14                  R59 1
    X14                  R79 -1
    X14                  R133 1
    X14                  R141 1
    X14                  R148 1
    X14                  R154 1
    X14                  R160 -1
    X14                  R161 -1
    X14                  R162 -1
    X14                  R163 -1
    X14                  R164 -1
    X14                  R223 -1
    X14                  R231 -1
    X14                  R238 -1
    X14                  R244 -1
    X14                  R250 1
    X14                  R251 1
    X14                  R252 1
    X14                  R253 1
    X14                  R254 1
    X14                  R286 1
    X14                  R296 1
    X14                  R297 -1
    X14                  R298 -1
    X14                  R320 -1
    X14                  R330 -1
    X14                  R331 1
    X14                  R332 1
    X15                  OBJ 0
    X15                  R60 1
    X15                  R80 -1
    X15                  R134 1
    X15                  R142 1
    X15                  R149 1
    X15                  R155 1
    X15                  R160 1
    X15                  R165 -1
    X15                  R166 -1
    X15                  R167 -1
    X15                  R168 -1
    X15                  R224 -1
    X15                  R232 -1
    X15                  R239 -1
    X15                  R245 -1
    X15                  R250 -1
    X15                  R255 1
    X15                  R256 1
    X15                  R257 1
    X15                  R258 1
    X15                  R283 1
    X15                  R287 1
    X15                  R288 1
    X15                  R289 -1
    X15                  R294 1
    X15                  R295 1
    X15                  R317 -1
    X15                  R321 -1
    X15                  R322 -1
    X15                  R323 1
    X15                  R328 -1
    X15                  R329 -1
    X16                  OBJ 0
    X16                  R61 1
    X16                  R81 -1
    X16                  R135 1
    X16                  R143 1
    X16                  R150 1
    X16                  R156 1
    X16                  R161 1
    X16                  R165 1
    X16                  R169 -1
    X16                  R170 -1
    X16                  R171 -1
    X16                  R225 -1
    X16                  R233 -1
    X16                  R240 -1
    X16                  R246 -1
    X16                  R251 -1
    X16                  R255 -1
    X16                  R259 1
    X16                  R260 1
    X16                  R261 1
    X16                  R291 -1
    X16                  R292 -1
    X16                  R325 1
    X16                  R326 1
    X17                  OBJ 0
    X17                  R62 1
    X17                  R82 -1
    X17                  R136 1
    X17                  R144 1
    X17                  R151 1
    X17                  R157 1
    X17                  R162 1
    X17                  R166 1
    X17                  R169 1
    X17                  R172 -1
    X17                  R173 -1
    X17                  R226 -1
    X17                  R234 -1
    X17                  R241 -1
    X17                  R247 -1
    X17                  R252 -1
    X17                  R256 -1
    X17                  R259 -1
    X17                  R262 1
    X17                  R263 1
    X17                  R285 1
    X17                  R290 1
    X17                  R291 1
    X17                  R293 -1
    X17                  R294 -1
    X17                  R319 -1
    X17                  R324 -1
    X17                  R325 -1
    X17                  R327 1
    X17                  R328 1
    X18                  OBJ 0
    X18                  R63 1
    X18                  R83 -1
    X18                  R137 1
    X18                  R145 1
    X18                  R152 1
    X18                  R158 1
    X18                  R163 1
    X18                  R167 1
    X18                  R170 1
    X18                  R172 1
    X18                  R174 -1
    X18                  R227 -1
    X18                  R235 -1
    X18                  R242 -1
    X18                  R248 -1
    X18                  R253 -1
    X18                  R257 -1
    X18                  R260 -1
    X18                  R262 -1
    X18                  R264 1
    X18                  R292 1
    X18                  R293 1
    X18                  R295 -1
    X18                  R298 1
    X18                  R326 -1
    X18                  R327 -1
    X18                  R329 1
    X18                  R332 -1
    X19                  OBJ 0
    X19                  R64 1
    X19                  R84 -1
    X19                  R138 1
    X19                  R146 1
    X19                  R153 1
    X19                  R159 1
    X19                  R164 1
    X19                  R168 1
    X19                  R171 1
    X19                  R173 1
    X19                  R174 1
    X19                  R228 -1
    X19                  R236 -1
    X19                  R243 -1
    X19                  R249 -1
    X19                  R254 -1
    X19                  R258 -1
    X19                  R261 -1
    X19                  R263 -1
    X19                  R264 -1
    X19                  R284 1
    X19                  R289 1
    X19                  R290 -1
    X19                  R297 1
    X19                  R318 -1
    X19                  R323 -1
    X19                  R324 1
    X19                  R331 -1
    X20                  OBJ 1
    X20                  R45 1
    X20                  R65 1
    X20                  R350 1
    X21                  OBJ 1
    X21                  R46 1
    X21                  R66 1
    X21                  R350 1
    X22                  OBJ 1
    X22                  R47 1
    X22                  R67 1
    X22                  R350 1
    X23                  OBJ 1
    X23                  R48 1
    X23                  R68 1
    X23                  R350 1
    X24                  OBJ 1
    X24                  R49 1
    X24                  R69 1
    X24                  R350 1
    X25                  OBJ 1
    X25                  R50 1
    X25                  R70 1
    X25                  R350 1
    X26                  OBJ 1
    X26                  R51 1
    X26                  R71 1
    X26                  R350 1
    X27                  OBJ 1
    X27                  R52 1
    X27                  R72 1
    X27                  R350 1
    X28                  OBJ 1
    X28                  R53 1
    X28                  R73 1
    X28                  R350 1
    X29                  OBJ 1
    X29                  R54 1
    X29                  R74 1
    X29                  R350 1
    X30                  OBJ 1
    X30                  R55 1
    X30                  R75 1
    X30                  R350 1
    X31                  OBJ 1
    X31                  R56 1
    X31                  R76 1
    X31                  R350 1
    X32                  OBJ 1
    X32                  R57 1
    X32                  R77 1
    X32                  R350 1
    X33                  OBJ 1
    X33                  R58 1
    X33                  R78 1
    X33                  R350 1
    X34                  OBJ 1
    X34                  R59 1
    X34                  R79 1
    X34                  R350 1
    X35                  OBJ 1
    X35                  R60 1
    X35                  R80 1
    X35                  R350 1
    X36                  OBJ 1
    X36                  R61 1
    X36                  R81 1
    X36                  R350 1
    X37                  OBJ 1
    X37                  R62 1
    X37                  R82 1
    X37                  R350 1
    X38                  OBJ 1
    X38                  R63 1
    X38                  R83 1
    X38                  R350 1
    X39                  OBJ 1
    X39                  R64 1
    X39                  R84 1
    X39                  R350 1
    X40                  OBJ 86
    X40                  R265 1
    X40                  R299 1
    X40                  R333 1
    X40                  R351 1
    X41                  OBJ 86
    X41                  R266 1
    X41                  R300 1
    X41                  R334 1
    X41                  R352 1
    X42                  OBJ 86
    X42                  R267 1
    X42                  R301 1
    X42                  R335 1
    X42                  R353 1
    X43                  OBJ 86
    X43                  R268 1
    X43                  R302 1
    X43                  R336 1
    X43                  R354 1
    X44                  OBJ 86
    X44                  R269 1
    X44                  R303 1
    X44                  R337 1
    X44                  R355 1
    X45                  OBJ 86
    X45                  R270 1
    X45                  R304 1
    X45                  R338 1
    X45                  R356 1
    X46                  OBJ 86
    X46                  R271 1
    X46                  R305 1
    X46                  R339 1
    X46                  R357 1
    X47                  OBJ 86
    X47                  R272 1
    X47                  R306 1
    X47                  R340 1
    X47                  R358 1
    X48                  OBJ 86
    X48                  R273 1
    X48                  R307 1
    X48                  R341 1
    X48                  R359 1
    X49                  OBJ 86
    X49                  R274 1
    X49                  R308 1
    X49                  R342 1
    X49                  R360 1
    X50                  OBJ 86
    X50                  R275 1
    X50                  R309 1
    X50                  R343 1
    X50                  R361 1
    X51                  OBJ 86
    X51                  R276 1
    X51                  R310 1
    X51                  R344 1
    X51                  R362 1
    X52                  OBJ 86
    X52                  R277 1
    X52                  R311 1
    X52                  R345 1
    X52                  R363 1
    X53                  OBJ 86
    X53                  R278 1
    X53                  R312 1
    X53                  R346 1
    X53                  R364 1
    X54                  OBJ 86
    X54                  R279 1
    X54                  R313 1
    X54                  R347 1
    X54                  R365 1
    X55                  OBJ 86
    X55                  R280 1
    X55                  R314 1
    X55                  R348 1
    X55                  R366 1
    X56                  OBJ 86
    X56                  R281 1
    X56                  R315 1
    X56                  R349 1
    X56                  R367 1
    X57                  OBJ 86
    X57                  R282 1
    X57                  R316 1
    X57                  R333 1
    X57                  R368 1
    X58                  OBJ 86
    X58                  R283 1
    X58                  R317 1
    X58                  R334 1
    X58                  R369 1
    X59                  OBJ 86
    X59                  R284 1
    X59                  R318 1
    X59                  R335 1
    X59                  R370 1
    X60                  OBJ 86
    X60                  R285 1
    X60                  R319 1
    X60                  R336 1
    X60                  R371 1
    X61                  OBJ 86
    X61                  R286 1
    X61                  R320 1
    X61                  R337 1
    X61                  R372 1
    X62                  OBJ 86
    X62                  R287 1
    X62                  R321 1
    X62                  R338 1
    X62                  R373 1
    X63                  OBJ 86
    X63                  R288 1
    X63                  R322 1
    X63                  R339 1
    X63                  R374 1
    X64                  OBJ 86
    X64                  R289 1
    X64                  R323 1
    X64                  R340 1
    X64                  R375 1
    X65                  OBJ 86
    X65                  R290 1
    X65                  R324 1
    X65                  R341 1
    X65                  R376 1
    X66                  OBJ 86
    X66                  R291 1
    X66                  R325 1
    X66                  R342 1
    X66                  R377 1
    X67                  OBJ 86
    X67                  R292 1
    X67                  R326 1
    X67                  R343 1
    X67                  R378 1
    X68                  OBJ 86
    X68                  R293 1
    X68                  R327 1
    X68                  R344 1
    X68                  R379 1
    X69                  OBJ 86
    X69                  R294 1
    X69                  R328 1
    X69                  R345 1
    X69                  R380 1
    X70                  OBJ 86
    X70                  R295 1
    X70                  R329 1
    X70                  R346 1
    X70                  R381 1
    X71                  OBJ 86
    X71                  R296 1
    X71                  R330 1
    X71                  R347 1
    X71                  R382 1
    X72                  OBJ 86
    X72                  R297 1
    X72                  R331 1
    X72                  R348 1
    X72                  R383 1
    X73                  OBJ 86
    X73                  R298 1
    X73                  R332 1
    X73                  R349 1
    X73                  R384 1
    X74                  OBJ 0
    X74                  R0 1
    X74                  R175 -49
    X74                  R368 11.5
    X74                  R385 1
    X74                  R387 1
    X74                  R389 1
    X74                  R391 1
    X74                  R393 1
    X74                  R395 1
    X74                  R397 1
    X74                  R399 1
    X75                  OBJ 0
    X75                  R0 1
    X75                  R220 -54
    X75                  R351 8
    X75                  R386 1
    X75                  R388 1
    X75                  R390 1
    X75                  R392 1
    X75                  R394 1
    X75                  R396 1
    X75                  R398 1
    X75                  R400 1
    X76                  OBJ 0
    X76                  R0 1
    X76                  R85 -51
    X76                  R368 11.5
    X76                  R625 1
    X76                  R627 1
    X76                  R629 1
    X76                  R631 1
    X76                  R633 1
    X76                  R635 1
    X76                  R637 1
    X76                  R639 1
    X77                  OBJ 0
    X77                  R0 1
    X77                  R130 -53
    X77                  R351 8
    X77                  R626 1
    X77                  R628 1
    X77                  R630 1
    X77                  R632 1
    X77                  R634 1
    X77                  R636 1
    X77                  R638 1
    X77                  R640 1
    X78                  OBJ 0
    X78                  R1 1
    X78                  R176 -48
    X78                  R401 1
    X78                  R403 1
    X78                  R405 1
    X78                  R407 1
    X78                  R409 1
    X78                  R411 1
    X78                  R413 1
    X78                  R625 1
    X79                  OBJ 0
    X79                  R1 1
    X79                  R221 -52
    X79                  R402 1
    X79                  R404 1
    X79                  R406 1
    X79                  R408 1
    X79                  R410 1
    X79                  R412 1
    X79                  R414 1
    X79                  R626 1
    X80                  OBJ 0
    X80                  R1 1
    X80                  R86 -51
    X80                  R385 1
    X80                  R641 1
    X80                  R643 1
    X80                  R645 1
    X80                  R647 1
    X80                  R649 1
    X80                  R651 1
    X80                  R653 1
    X81                  OBJ 0
    X81                  R1 1
    X81                  R131 -53
    X81                  R386 1
    X81                  R642 1
    X81                  R644 1
    X81                  R646 1
    X81                  R648 1
    X81                  R650 1
    X81                  R652 1
    X81                  R654 1
    X82                  OBJ 0
    X82                  R2 1
    X82                  R177 -48
    X82                  R415 1
    X82                  R417 1
    X82                  R419 1
    X82                  R421 1
    X82                  R423 1
    X82                  R425 1
    X82                  R627 1
    X82                  R641 1
    X83                  OBJ 0
    X83                  R2 1
    X83                  R222 -52
    X83                  R416 1
    X83                  R418 1
    X83                  R420 1
    X83                  R422 1
    X83                  R424 1
    X83                  R426 1
    X83                  R628 1
    X83                  R642 1
    X84                  OBJ 0
    X84                  R2 1
    X84                  R87 -51
    X84                  R387 1
    X84                  R401 1
    X84                  R655 1
    X84                  R657 1
    X84                  R659 1
    X84                  R661 1
    X84                  R663 1
    X84                  R665 1
    X85                  OBJ 0
    X85                  R2 1
    X85                  R132 -53
    X85                  R388 1
    X85                  R402 1
    X85                  R656 1
    X85                  R658 1
    X85                  R660 1
    X85                  R662 1
    X85                  R664 1
    X85                  R666 1
    X86                  OBJ 0
    X86                  R3 1
    X86                  R178 -49
    X86                  R372 11
    X86                  R427 1
    X86                  R429 1
    X86                  R431 1
    X86                  R433 1
    X86                  R435 1
    X86                  R629 1
    X86                  R643 1
    X86                  R655 1
    X87                  OBJ 0
    X87                  R3 1
    X87                  R223 -53
    X87                  R355 8
    X87                  R428 1
    X87                  R430 1
    X87                  R432 1
    X87                  R434 1
    X87                  R436 1
    X87                  R630 1
    X87                  R644 1
    X87                  R656 1
    X88                  OBJ 0
    X88                  R3 1
    X88                  R88 -51
    X88                  R372 11
    X88                  R389 1
    X88                  R403 1
    X88                  R415 1
    X88                  R667 1
    X88                  R669 1
    X88                  R671 1
    X88                  R673 1
    X88                  R675 1
    X89                  OBJ 0
    X89                  R3 1
    X89                  R133 -53
    X89                  R355 8
    X89                  R390 1
    X89                  R404 1
    X89                  R416 1
    X89                  R668 1
    X89                  R670 1
    X89                  R672 1
    X89                  R674 1
    X89                  R676 1
    X90                  OBJ 0
    X90                  R4 1
    X90                  R179 -51
    X90                  R369 12.5
    X90                  R437 1
    X90                  R439 1
    X90                  R441 1
    X90                  R443 1
    X90                  R631 1
    X90                  R645 1
    X90                  R657 1
    X90                  R667 1
    X91                  OBJ 0
    X91                  R4 1
    X91                  R224 -56
    X91                  R352 9
    X91                  R438 1
    X91                  R440 1
    X91                  R442 1
    X91                  R444 1
    X91                  R632 1
    X91                  R646 1
    X91                  R658 1
    X91                  R668 1
    X92                  OBJ 0
    X92                  R4 1
    X92                  R89 -51
    X92                  R369 12.5
    X92                  R391 1
    X92                  R405 1
    X92                  R417 1
    X92                  R427 1
    X92                  R677 1
    X92                  R679 1
    X92                  R681 1
    X92                  R683 1
    X93                  OBJ 0
    X93                  R4 1
    X93                  R134 -53
    X93                  R352 9
    X93                  R392 1
    X93                  R406 1
    X93                  R418 1
    X93                  R428 1
    X93                  R678 1
    X93                  R680 1
    X93                  R682 1
    X93                  R684 1
    X94                  OBJ 0
    X94                  R5 1
    X94                  R180 -50
    X94                  R445 1
    X94                  R447 1
    X94                  R449 1
    X94                  R633 1
    X94                  R647 1
    X94                  R659 1
    X94                  R669 1
    X94                  R677 1
    X95                  OBJ 0
    X95                  R5 1
    X95                  R225 -53
    X95                  R446 1
    X95                  R448 1
    X95                  R450 1
    X95                  R634 1
    X95                  R648 1
    X95                  R660 1
    X95                  R670 1
    X95                  R678 1
    X96                  OBJ 0
    X96                  R5 1
    X96                  R90 -51
    X96                  R393 1
    X96                  R407 1
    X96                  R419 1
    X96                  R429 1
    X96                  R437 1
    X96                  R685 1
    X96                  R687 1
    X96                  R689 1
    X97                  OBJ 0
    X97                  R5 1
    X97                  R135 -53
    X97                  R394 1
    X97                  R408 1
    X97                  R420 1
    X97                  R430 1
    X97                  R438 1
    X97                  R686 1
    X97                  R688 1
    X97                  R690 1
    X98                  OBJ 0
    X98                  R6 1
    X98                  R181 -51
    X98                  R371 11
    X98                  R451 1
    X98                  R453 1
    X98                  R635 1
    X98                  R649 1
    X98                  R661 1
    X98                  R671 1
    X98                  R679 1
    X98                  R685 1
    X99                  OBJ 0
    X99                  R6 1
    X99                  R226 -53
    X99                  R354 9
    X99                  R452 1
    X99                  R454 1
    X99                  R636 1
    X99                  R650 1
    X99                  R662 1
    X99                  R672 1
    X99                  R680 1
    X99                  R686 1
    X100                 OBJ 0
    X100                 R6 1
    X100                 R91 -51
    X100                 R371 11
    X100                 R395 1
    X100                 R409 1
    X100                 R421 1
    X100                 R431 1
    X100                 R439 1
    X100                 R445 1
    X100                 R691 1
    X100                 R693 1
    X101                 OBJ 0
    X101                 R6 1
    X101                 R136 -53
    X101                 R354 9
    X101                 R396 1
    X101                 R410 1
    X101                 R422 1
    X101                 R432 1
    X101                 R440 1
    X101                 R446 1
    X101                 R692 1
    X101                 R694 1
    X102                 OBJ 0
    X102                 R7 1
    X102                 R182 -52
    X102                 R455 1
    X102                 R637 1
    X102                 R651 1
    X102                 R663 1
    X102                 R673 1
    X102                 R681 1
    X102                 R687 1
    X102                 R691 1
    X103                 OBJ 0
    X103                 R7 1
    X103                 R227 -53
    X103                 R456 1
    X103                 R638 1
    X103                 R652 1
    X103                 R664 1
    X103                 R674 1
    X103                 R682 1
    X103                 R688 1
    X103                 R692 1
    X104                 OBJ 0
    X104                 R7 1
    X104                 R92 -51
    X104                 R397 1
    X104                 R411 1
    X104                 R423 1
    X104                 R433 1
    X104                 R441 1
    X104                 R447 1
    X104                 R451 1
    X104                 R695 1
    X105                 OBJ 0
    X105                 R7 1
    X105                 R137 -53
    X105                 R398 1
    X105                 R412 1
    X105                 R424 1
    X105                 R434 1
    X105                 R442 1
    X105                 R448 1
    X105                 R452 1
    X105                 R696 1
    X106                 OBJ 0
    X106                 R8 1
    X106                 R183 -52
    X106                 R370 11.5
    X106                 R639 1
    X106                 R653 1
    X106                 R665 1
    X106                 R675 1
    X106                 R683 1
    X106                 R689 1
    X106                 R693 1
    X106                 R695 1
    X107                 OBJ 0
    X107                 R8 1
    X107                 R228 -54
    X107                 R353 9.5
    X107                 R640 1
    X107                 R654 1
    X107                 R666 1
    X107                 R676 1
    X107                 R684 1
    X107                 R690 1
    X107                 R694 1
    X107                 R696 1
    X108                 OBJ 0
    X108                 R8 1
    X108                 R93 -51
    X108                 R370 11.5
    X108                 R399 1
    X108                 R413 1
    X108                 R425 1
    X108                 R435 1
    X108                 R443 1
    X108                 R449 1
    X108                 R453 1
    X108                 R455 1
    X109                 OBJ 0
    X109                 R8 1
    X109                 R138 -53
    X109                 R353 9.5
    X109                 R400 1
    X109                 R414 1
    X109                 R426 1
    X109                 R436 1
    X109                 R444 1
    X109                 R450 1
    X109                 R454 1
    X109                 R456 1
    X110                 OBJ 0
    X110                 R9 1
    X110                 R184 -48
    X110                 R385 1
    X110                 R457 1
    X110                 R459 1
    X110                 R461 1
    X110                 R463 1
    X110                 R465 1
    X110                 R467 1
    X110                 R469 1
    X111                 OBJ 0
    X111                 R9 1
    X111                 R229 -52
    X111                 R386 1
    X111                 R458 1
    X111                 R460 1
    X111                 R462 1
    X111                 R464 1
    X111                 R466 1
    X111                 R468 1
    X111                 R470 1
    X112                 OBJ 0
    X112                 R9 1
    X112                 R94 -49
    X112                 R625 1
    X112                 R697 1
    X112                 R699 1
    X112                 R701 1
    X112                 R703 1
    X112                 R705 1
    X112                 R707 1
    X112                 R709 1
    X113                 OBJ 0
    X113                 R9 1
    X113                 R139 -54
    X113                 R626 1
    X113                 R698 1
    X113                 R700 1
    X113                 R702 1
    X113                 R704 1
    X113                 R706 1
    X113                 R708 1
    X113                 R710 1
    X114                 OBJ 0
    X114                 R10 1
    X114                 R185 -48
    X114                 R387 1
    X114                 R471 1
    X114                 R473 1
    X114                 R475 1
    X114                 R477 1
    X114                 R479 1
    X114                 R481 1
    X114                 R697 1
    X115                 OBJ 0
    X115                 R10 1
    X115                 R230 -52
    X115                 R388 1
    X115                 R472 1
    X115                 R474 1
    X115                 R476 1
    X115                 R478 1
    X115                 R480 1
    X115                 R482 1
    X115                 R698 1
    X116                 OBJ 0
    X116                 R10 1
    X116                 R95 -49
    X116                 R457 1
    X116                 R627 1
    X116                 R711 1
    X116                 R713 1
    X116                 R715 1
    X116                 R717 1
    X116                 R719 1
    X116                 R721 1
    X117                 OBJ 0
    X117                 R10 1
    X117                 R140 -54
    X117                 R458 1
    X117                 R628 1
    X117                 R712 1
    X117                 R714 1
    X117                 R716 1
    X117                 R718 1
    X117                 R720 1
    X117                 R722 1
    X118                 OBJ 0
    X118                 R11 1
    X118                 R186 -49
    X118                 R389 1
    X118                 R483 1
    X118                 R485 1
    X118                 R487 1
    X118                 R489 1
    X118                 R491 1
    X118                 R699 1
    X118                 R711 1
    X119                 OBJ 0
    X119                 R11 1
    X119                 R231 -53
    X119                 R390 1
    X119                 R484 1
    X119                 R486 1
    X119                 R488 1
    X119                 R490 1
    X119                 R492 1
    X119                 R700 1
    X119                 R712 1
    X120                 OBJ 0
    X120                 R11 1
    X120                 R96 -49
    X120                 R459 1
    X120                 R471 1
    X120                 R629 1
    X120                 R723 1
    X120                 R725 1
    X120                 R727 1
    X120                 R729 1
    X120                 R731 1
    X121                 OBJ 0
    X121                 R11 1
    X121                 R141 -54
    X121                 R460 1
    X121                 R472 1
    X121                 R630 1
    X121                 R724 1
    X121                 R726 1
    X121                 R728 1
    X121                 R730 1
    X121                 R732 1
    X122                 OBJ 0
    X122                 R12 1
    X122                 R187 -51
    X122                 R373 13
    X122                 R391 1
    X122                 R493 1
    X122                 R495 1
    X122                 R497 1
    X122                 R499 1
    X122                 R701 1
    X122                 R713 1
    X122                 R723 1
    X123                 OBJ 0
    X123                 R12 1
    X123                 R232 -56
    X123                 R356 8
    X123                 R392 1
    X123                 R494 1
    X123                 R496 1
    X123                 R498 1
    X123                 R500 1
    X123                 R702 1
    X123                 R714 1
    X123                 R724 1
    X124                 OBJ 0
    X124                 R12 1
    X124                 R97 -49
    X124                 R373 13
    X124                 R461 1
    X124                 R473 1
    X124                 R483 1
    X124                 R631 1
    X124                 R733 1
    X124                 R735 1
    X124                 R737 1
    X124                 R739 1
    X125                 OBJ 0
    X125                 R12 1
    X125                 R142 -54
    X125                 R356 8
    X125                 R462 1
    X125                 R474 1
    X125                 R484 1
    X125                 R632 1
    X125                 R734 1
    X125                 R736 1
    X125                 R738 1
    X125                 R740 1
    X126                 OBJ 0
    X126                 R13 1
    X126                 R188 -50
    X126                 R393 1
    X126                 R501 1
    X126                 R503 1
    X126                 R505 1
    X126                 R703 1
    X126                 R715 1
    X126                 R725 1
    X126                 R733 1
    X127                 OBJ 0
    X127                 R13 1
    X127                 R233 -53
    X127                 R394 1
    X127                 R502 1
    X127                 R504 1
    X127                 R506 1
    X127                 R704 1
    X127                 R716 1
    X127                 R726 1
    X127                 R734 1
    X128                 OBJ 0
    X128                 R13 1
    X128                 R98 -49
    X128                 R463 1
    X128                 R475 1
    X128                 R485 1
    X128                 R493 1
    X128                 R633 1
    X128                 R741 1
    X128                 R743 1
    X128                 R745 1
    X129                 OBJ 0
    X129                 R13 1
    X129                 R143 -54
    X129                 R464 1
    X129                 R476 1
    X129                 R486 1
    X129                 R494 1
    X129                 R634 1
    X129                 R742 1
    X129                 R744 1
    X129                 R746 1
    X130                 OBJ 0
    X130                 R14 1
    X130                 R189 -51
    X130                 R395 1
    X130                 R507 1
    X130                 R509 1
    X130                 R705 1
    X130                 R717 1
    X130                 R727 1
    X130                 R735 1
    X130                 R741 1
    X131                 OBJ 0
    X131                 R14 1
    X131                 R234 -53
    X131                 R396 1
    X131                 R508 1
    X131                 R510 1
    X131                 R706 1
    X131                 R718 1
    X131                 R728 1
    X131                 R736 1
    X131                 R742 1
    X132                 OBJ 0
    X132                 R14 1
    X132                 R99 -49
    X132                 R465 1
    X132                 R477 1
    X132                 R487 1
    X132                 R495 1
    X132                 R501 1
    X132                 R635 1
    X132                 R747 1
    X132                 R749 1
    X133                 OBJ 0
    X133                 R14 1
    X133                 R144 -54
    X133                 R466 1
    X133                 R478 1
    X133                 R488 1
    X133                 R496 1
    X133                 R502 1
    X133                 R636 1
    X133                 R748 1
    X133                 R750 1
    X134                 OBJ 0
    X134                 R15 1
    X134                 R190 -52
    X134                 R397 1
    X134                 R511 1
    X134                 R707 1
    X134                 R719 1
    X134                 R729 1
    X134                 R737 1
    X134                 R743 1
    X134                 R747 1
    X135                 OBJ 0
    X135                 R15 1
    X135                 R235 -53
    X135                 R398 1
    X135                 R512 1
    X135                 R708 1
    X135                 R720 1
    X135                 R730 1
    X135                 R738 1
    X135                 R744 1
    X135                 R748 1
    X136                 OBJ 0
    X136                 R15 1
    X136                 R100 -49
    X136                 R467 1
    X136                 R479 1
    X136                 R489 1
    X136                 R497 1
    X136                 R503 1
    X136                 R507 1
    X136                 R637 1
    X136                 R751 1
    X137                 OBJ 0
    X137                 R15 1
    X137                 R145 -54
    X137                 R468 1
    X137                 R480 1
    X137                 R490 1
    X137                 R498 1
    X137                 R504 1
    X137                 R508 1
    X137                 R638 1
    X137                 R752 1
    X138                 OBJ 0
    X138                 R16 1
    X138                 R191 -52
    X138                 R399 1
    X138                 R709 1
    X138                 R721 1
    X138                 R731 1
    X138                 R739 1
    X138                 R745 1
    X138                 R749 1
    X138                 R751 1
    X139                 OBJ 0
    X139                 R16 1
    X139                 R236 -54
    X139                 R400 1
    X139                 R710 1
    X139                 R722 1
    X139                 R732 1
    X139                 R740 1
    X139                 R746 1
    X139                 R750 1
    X139                 R752 1
    X140                 OBJ 0
    X140                 R16 1
    X140                 R101 -49
    X140                 R469 1
    X140                 R481 1
    X140                 R491 1
    X140                 R499 1
    X140                 R505 1
    X140                 R509 1
    X140                 R511 1
    X140                 R639 1
    X141                 OBJ 0
    X141                 R16 1
    X141                 R146 -54
    X141                 R470 1
    X141                 R482 1
    X141                 R492 1
    X141                 R500 1
    X141                 R506 1
    X141                 R510 1
    X141                 R512 1
    X141                 R640 1
    X142                 OBJ 0
    X142                 R17 1
    X142                 R192 -48
    X142                 R401 1
    X142                 R457 1
    X142                 R513 1
    X142                 R515 1
    X142                 R517 1
    X142                 R519 1
    X142                 R521 1
    X142                 R523 1
    X143                 OBJ 0
    X143                 R17 1
    X143                 R237 -52
    X143                 R402 1
    X143                 R458 1
    X143                 R514 1
    X143                 R516 1
    X143                 R518 1
    X143                 R520 1
    X143                 R522 1
    X143                 R524 1
    X144                 OBJ 0
    X144                 R17 1
    X144                 R102 -48
    X144                 R641 1
    X144                 R697 1
    X144                 R753 1
    X144                 R755 1
    X144                 R757 1
    X144                 R759 1
    X144                 R761 1
    X144                 R763 1
    X145                 OBJ 0
    X145                 R17 1
    X145                 R147 -52
    X145                 R642 1
    X145                 R698 1
    X145                 R754 1
    X145                 R756 1
    X145                 R758 1
    X145                 R760 1
    X145                 R762 1
    X145                 R764 1
    X146                 OBJ 0
    X146                 R18 1
    X146                 R193 -49
    X146                 R403 1
    X146                 R459 1
    X146                 R525 1
    X146                 R527 1
    X146                 R529 1
    X146                 R531 1
    X146                 R533 1
    X146                 R753 1
    X147                 OBJ 0
    X147                 R18 1
    X147                 R238 -53
    X147                 R404 1
    X147                 R460 1
    X147                 R526 1
    X147                 R528 1
    X147                 R530 1
    X147                 R532 1
    X147                 R534 1
    X147                 R754 1
    X148                 OBJ 0
    X148                 R18 1
    X148                 R103 -48
    X148                 R513 1
    X148                 R643 1
    X148                 R699 1
    X148                 R765 1
    X148                 R767 1
    X148                 R769 1
    X148                 R771 1
    X148                 R773 1
    X149                 OBJ 0
    X149                 R18 1
    X149                 R148 -52
    X149                 R514 1
    X149                 R644 1
    X149                 R700 1
    X149                 R766 1
    X149                 R768 1
    X149                 R770 1
    X149                 R772 1
    X149                 R774 1
    X150                 OBJ 0
    X150                 R19 1
    X150                 R194 -51
    X150                 R374 12
    X150                 R405 1
    X150                 R461 1
    X150                 R535 1
    X150                 R537 1
    X150                 R539 1
    X150                 R541 1
    X150                 R755 1
    X150                 R765 1
    X151                 OBJ 0
    X151                 R19 1
    X151                 R239 -56
    X151                 R357 7.5
    X151                 R406 1
    X151                 R462 1
    X151                 R536 1
    X151                 R538 1
    X151                 R540 1
    X151                 R542 1
    X151                 R756 1
    X151                 R766 1
    X152                 OBJ 0
    X152                 R19 1
    X152                 R104 -48
    X152                 R374 12
    X152                 R515 1
    X152                 R525 1
    X152                 R645 1
    X152                 R701 1
    X152                 R775 1
    X152                 R777 1
    X152                 R779 1
    X152                 R781 1
    X153                 OBJ 0
    X153                 R19 1
    X153                 R149 -52
    X153                 R357 7.5
    X153                 R516 1
    X153                 R526 1
    X153                 R646 1
    X153                 R702 1
    X153                 R776 1
    X153                 R778 1
    X153                 R780 1
    X153                 R782 1
    X154                 OBJ 0
    X154                 R20 1
    X154                 R195 -50
    X154                 R407 1
    X154                 R463 1
    X154                 R543 1
    X154                 R545 1
    X154                 R547 1
    X154                 R757 1
    X154                 R767 1
    X154                 R775 1
    X155                 OBJ 0
    X155                 R20 1
    X155                 R240 -53
    X155                 R408 1
    X155                 R464 1
    X155                 R544 1
    X155                 R546 1
    X155                 R548 1
    X155                 R758 1
    X155                 R768 1
    X155                 R776 1
    X156                 OBJ 0
    X156                 R20 1
    X156                 R105 -48
    X156                 R517 1
    X156                 R527 1
    X156                 R535 1
    X156                 R647 1
    X156                 R703 1
    X156                 R783 1
    X156                 R785 1
    X156                 R787 1
    X157                 OBJ 0
    X157                 R20 1
    X157                 R150 -52
    X157                 R518 1
    X157                 R528 1
    X157                 R536 1
    X157                 R648 1
    X157                 R704 1
    X157                 R784 1
    X157                 R786 1
    X157                 R788 1
    X158                 OBJ 0
    X158                 R21 1
    X158                 R196 -51
    X158                 R409 1
    X158                 R465 1
    X158                 R549 1
    X158                 R551 1
    X158                 R759 1
    X158                 R769 1
    X158                 R777 1
    X158                 R783 1
    X159                 OBJ 0
    X159                 R21 1
    X159                 R241 -53
    X159                 R410 1
    X159                 R466 1
    X159                 R550 1
    X159                 R552 1
    X159                 R760 1
    X159                 R770 1
    X159                 R778 1
    X159                 R784 1
    X160                 OBJ 0
    X160                 R21 1
    X160                 R106 -48
    X160                 R519 1
    X160                 R529 1
    X160                 R537 1
    X160                 R543 1
    X160                 R649 1
    X160                 R705 1
    X160                 R789 1
    X160                 R791 1
    X161                 OBJ 0
    X161                 R21 1
    X161                 R151 -52
    X161                 R520 1
    X161                 R530 1
    X161                 R538 1
    X161                 R544 1
    X161                 R650 1
    X161                 R706 1
    X161                 R790 1
    X161                 R792 1
    X162                 OBJ 0
    X162                 R22 1
    X162                 R197 -52
    X162                 R411 1
    X162                 R467 1
    X162                 R553 1
    X162                 R761 1
    X162                 R771 1
    X162                 R779 1
    X162                 R785 1
    X162                 R789 1
    X163                 OBJ 0
    X163                 R22 1
    X163                 R242 -53
    X163                 R412 1
    X163                 R468 1
    X163                 R554 1
    X163                 R762 1
    X163                 R772 1
    X163                 R780 1
    X163                 R786 1
    X163                 R790 1
    X164                 OBJ 0
    X164                 R22 1
    X164                 R107 -48
    X164                 R521 1
    X164                 R531 1
    X164                 R539 1
    X164                 R545 1
    X164                 R549 1
    X164                 R651 1
    X164                 R707 1
    X164                 R793 1
    X165                 OBJ 0
    X165                 R22 1
    X165                 R152 -52
    X165                 R522 1
    X165                 R532 1
    X165                 R540 1
    X165                 R546 1
    X165                 R550 1
    X165                 R652 1
    X165                 R708 1
    X165                 R794 1
    X166                 OBJ 0
    X166                 R23 1
    X166                 R198 -52
    X166                 R413 1
    X166                 R469 1
    X166                 R763 1
    X166                 R773 1
    X166                 R781 1
    X166                 R787 1
    X166                 R791 1
    X166                 R793 1
    X167                 OBJ 0
    X167                 R23 1
    X167                 R243 -54
    X167                 R414 1
    X167                 R470 1
    X167                 R764 1
    X167                 R774 1
    X167                 R782 1
    X167                 R788 1
    X167                 R792 1
    X167                 R794 1
    X168                 OBJ 0
    X168                 R23 1
    X168                 R108 -48
    X168                 R523 1
    X168                 R533 1
    X168                 R541 1
    X168                 R547 1
    X168                 R551 1
    X168                 R553 1
    X168                 R653 1
    X168                 R709 1
    X169                 OBJ 0
    X169                 R23 1
    X169                 R153 -52
    X169                 R524 1
    X169                 R534 1
    X169                 R542 1
    X169                 R548 1
    X169                 R552 1
    X169                 R554 1
    X169                 R654 1
    X169                 R710 1
    X170                 OBJ 0
    X170                 R24 1
    X170                 R199 -49
    X170                 R382 10.5
    X170                 R415 1
    X170                 R471 1
    X170                 R513 1
    X170                 R555 1
    X170                 R557 1
    X170                 R559 1
    X170                 R561 1
    X170                 R563 1
    X171                 OBJ 0
    X171                 R24 1
    X171                 R244 -53
    X171                 R365 6.5
    X171                 R416 1
    X171                 R472 1
    X171                 R514 1
    X171                 R556 1
    X171                 R558 1
    X171                 R560 1
    X171                 R562 1
    X171                 R564 1
    X172                 OBJ 0
    X172                 R24 1
    X172                 R109 -48
    X172                 R382 10.5
    X172                 R655 1
    X172                 R711 1
    X172                 R753 1
    X172                 R795 1
    X172                 R797 1
    X172                 R799 1
    X172                 R801 1
    X172                 R803 1
    X173                 OBJ 0
    X173                 R24 1
    X173                 R154 -52
    X173                 R365 6.5
    X173                 R656 1
    X173                 R712 1
    X173                 R754 1
    X173                 R796 1
    X173                 R798 1
    X173                 R800 1
    X173                 R802 1
    X173                 R804 1
    X174                 OBJ 0
    X174                 R25 1
    X174                 R200 -51
    X174                 R417 1
    X174                 R473 1
    X174                 R515 1
    X174                 R565 1
    X174                 R567 1
    X174                 R569 1
    X174                 R571 1
    X174                 R795 1
    X175                 OBJ 0
    X175                 R25 1
    X175                 R245 -56
    X175                 R418 1
    X175                 R474 1
    X175                 R516 1
    X175                 R566 1
    X175                 R568 1
    X175                 R570 1
    X175                 R572 1
    X175                 R796 1
    X176                 OBJ 0
    X176                 R25 1
    X176                 R110 -48
    X176                 R555 1
    X176                 R657 1
    X176                 R713 1
    X176                 R755 1
    X176                 R805 1
    X176                 R807 1
    X176                 R809 1
    X176                 R811 1
    X177                 OBJ 0
    X177                 R25 1
    X177                 R155 -52
    X177                 R556 1
    X177                 R658 1
    X177                 R714 1
    X177                 R756 1
    X177                 R806 1
    X177                 R808 1
    X177                 R810 1
    X177                 R812 1
    X178                 OBJ 0
    X178                 R26 1
    X178                 R201 -50
    X178                 R419 1
    X178                 R475 1
    X178                 R517 1
    X178                 R573 1
    X178                 R575 1
    X178                 R577 1
    X178                 R797 1
    X178                 R805 1
    X179                 OBJ 0
    X179                 R26 1
    X179                 R246 -53
    X179                 R420 1
    X179                 R476 1
    X179                 R518 1
    X179                 R574 1
    X179                 R576 1
    X179                 R578 1
    X179                 R798 1
    X179                 R806 1
    X180                 OBJ 0
    X180                 R26 1
    X180                 R111 -48
    X180                 R557 1
    X180                 R565 1
    X180                 R659 1
    X180                 R715 1
    X180                 R757 1
    X180                 R813 1
    X180                 R815 1
    X180                 R817 1
    X181                 OBJ 0
    X181                 R26 1
    X181                 R156 -52
    X181                 R558 1
    X181                 R566 1
    X181                 R660 1
    X181                 R716 1
    X181                 R758 1
    X181                 R814 1
    X181                 R816 1
    X181                 R818 1
    X182                 OBJ 0
    X182                 R27 1
    X182                 R202 -51
    X182                 R421 1
    X182                 R477 1
    X182                 R519 1
    X182                 R579 1
    X182                 R581 1
    X182                 R799 1
    X182                 R807 1
    X182                 R813 1
    X183                 OBJ 0
    X183                 R27 1
    X183                 R247 -53
    X183                 R422 1
    X183                 R478 1
    X183                 R520 1
    X183                 R580 1
    X183                 R582 1
    X183                 R800 1
    X183                 R808 1
    X183                 R814 1
    X184                 OBJ 0
    X184                 R27 1
    X184                 R112 -48
    X184                 R559 1
    X184                 R567 1
    X184                 R573 1
    X184                 R661 1
    X184                 R717 1
    X184                 R759 1
    X184                 R819 1
    X184                 R821 1
    X185                 OBJ 0
    X185                 R27 1
    X185                 R157 -52
    X185                 R560 1
    X185                 R568 1
    X185                 R574 1
    X185                 R662 1
    X185                 R718 1
    X185                 R760 1
    X185                 R820 1
    X185                 R822 1
    X186                 OBJ 0
    X186                 R28 1
    X186                 R203 -52
    X186                 R423 1
    X186                 R479 1
    X186                 R521 1
    X186                 R583 1
    X186                 R801 1
    X186                 R809 1
    X186                 R815 1
    X186                 R819 1
    X187                 OBJ 0
    X187                 R28 1
    X187                 R248 -53
    X187                 R424 1
    X187                 R480 1
    X187                 R522 1
    X187                 R584 1
    X187                 R802 1
    X187                 R810 1
    X187                 R816 1
    X187                 R820 1
    X188                 OBJ 0
    X188                 R28 1
    X188                 R113 -48
    X188                 R561 1
    X188                 R569 1
    X188                 R575 1
    X188                 R579 1
    X188                 R663 1
    X188                 R719 1
    X188                 R761 1
    X188                 R823 1
    X189                 OBJ 0
    X189                 R28 1
    X189                 R158 -52
    X189                 R562 1
    X189                 R570 1
    X189                 R576 1
    X189                 R580 1
    X189                 R664 1
    X189                 R720 1
    X189                 R762 1
    X189                 R824 1
    X190                 OBJ 0
    X190                 R29 1
    X190                 R204 -52
    X190                 R425 1
    X190                 R481 1
    X190                 R523 1
    X190                 R803 1
    X190                 R811 1
    X190                 R817 1
    X190                 R821 1
    X190                 R823 1
    X191                 OBJ 0
    X191                 R29 1
    X191                 R249 -54
    X191                 R426 1
    X191                 R482 1
    X191                 R524 1
    X191                 R804 1
    X191                 R812 1
    X191                 R818 1
    X191                 R822 1
    X191                 R824 1
    X192                 OBJ 0
    X192                 R29 1
    X192                 R114 -48
    X192                 R563 1
    X192                 R571 1
    X192                 R577 1
    X192                 R581 1
    X192                 R583 1
    X192                 R665 1
    X192                 R721 1
    X192                 R763 1
    X193                 OBJ 0
    X193                 R29 1
    X193                 R159 -52
    X193                 R564 1
    X193                 R572 1
    X193                 R578 1
    X193                 R582 1
    X193                 R584 1
    X193                 R666 1
    X193                 R722 1
    X193                 R764 1
    X194                 OBJ 0
    X194                 R30 1
    X194                 R205 -51
    X194                 R427 1
    X194                 R483 1
    X194                 R525 1
    X194                 R555 1
    X194                 R585 1
    X194                 R587 1
    X194                 R589 1
    X194                 R591 1
    X195                 OBJ 0
    X195                 R30 1
    X195                 R250 -56
    X195                 R428 1
    X195                 R484 1
    X195                 R526 1
    X195                 R556 1
    X195                 R586 1
    X195                 R588 1
    X195                 R590 1
    X195                 R592 1
    X196                 OBJ 0
    X196                 R30 1
    X196                 R115 -49
    X196                 R667 1
    X196                 R723 1
    X196                 R765 1
    X196                 R795 1
    X196                 R825 1
    X196                 R827 1
    X196                 R829 1
    X196                 R831 1
    X197                 OBJ 0
    X197                 R30 1
    X197                 R160 -53
    X197                 R668 1
    X197                 R724 1
    X197                 R766 1
    X197                 R796 1
    X197                 R826 1
    X197                 R828 1
    X197                 R830 1
    X197                 R832 1
    X198                 OBJ 0
    X198                 R31 1
    X198                 R206 -50
    X198                 R429 1
    X198                 R485 1
    X198                 R527 1
    X198                 R557 1
    X198                 R593 1
    X198                 R595 1
    X198                 R597 1
    X198                 R825 1
    X199                 OBJ 0
    X199                 R31 1
    X199                 R251 -53
    X199                 R430 1
    X199                 R486 1
    X199                 R528 1
    X199                 R558 1
    X199                 R594 1
    X199                 R596 1
    X199                 R598 1
    X199                 R826 1
    X200                 OBJ 0
    X200                 R31 1
    X200                 R116 -49
    X200                 R585 1
    X200                 R669 1
    X200                 R725 1
    X200                 R767 1
    X200                 R797 1
    X200                 R833 1
    X200                 R835 1
    X200                 R837 1
    X201                 OBJ 0
    X201                 R31 1
    X201                 R161 -53
    X201                 R586 1
    X201                 R670 1
    X201                 R726 1
    X201                 R768 1
    X201                 R798 1
    X201                 R834 1
    X201                 R836 1
    X201                 R838 1
    X202                 OBJ 0
    X202                 R32 1
    X202                 R207 -51
    X202                 R431 1
    X202                 R487 1
    X202                 R529 1
    X202                 R559 1
    X202                 R599 1
    X202                 R601 1
    X202                 R827 1
    X202                 R833 1
    X203                 OBJ 0
    X203                 R32 1
    X203                 R252 -53
    X203                 R432 1
    X203                 R488 1
    X203                 R530 1
    X203                 R560 1
    X203                 R600 1
    X203                 R602 1
    X203                 R828 1
    X203                 R834 1
    X204                 OBJ 0
    X204                 R32 1
    X204                 R117 -49
    X204                 R587 1
    X204                 R593 1
    X204                 R671 1
    X204                 R727 1
    X204                 R769 1
    X204                 R799 1
    X204                 R839 1
    X204                 R841 1
    X205                 OBJ 0
    X205                 R32 1
    X205                 R162 -53
    X205                 R588 1
    X205                 R594 1
    X205                 R672 1
    X205                 R728 1
    X205                 R770 1
    X205                 R800 1
    X205                 R840 1
    X205                 R842 1
    X206                 OBJ 0
    X206                 R33 1
    X206                 R208 -52
    X206                 R384 11
    X206                 R433 1
    X206                 R489 1
    X206                 R531 1
    X206                 R561 1
    X206                 R603 1
    X206                 R829 1
    X206                 R835 1
    X206                 R839 1
    X207                 OBJ 0
    X207                 R33 1
    X207                 R253 -53
    X207                 R367 8.5
    X207                 R434 1
    X207                 R490 1
    X207                 R532 1
    X207                 R562 1
    X207                 R604 1
    X207                 R830 1
    X207                 R836 1
    X207                 R840 1
    X208                 OBJ 0
    X208                 R33 1
    X208                 R118 -49
    X208                 R384 11
    X208                 R589 1
    X208                 R595 1
    X208                 R599 1
    X208                 R673 1
    X208                 R729 1
    X208                 R771 1
    X208                 R801 1
    X208                 R843 1
    X209                 OBJ 0
    X209                 R33 1
    X209                 R163 -53
    X209                 R367 8.5
    X209                 R590 1
    X209                 R596 1
    X209                 R600 1
    X209                 R674 1
    X209                 R730 1
    X209                 R772 1
    X209                 R802 1
    X209                 R844 1
    X210                 OBJ 0
    X210                 R34 1
    X210                 R209 -52
    X210                 R383 11.5
    X210                 R435 1
    X210                 R491 1
    X210                 R533 1
    X210                 R563 1
    X210                 R831 1
    X210                 R837 1
    X210                 R841 1
    X210                 R843 1
    X211                 OBJ 0
    X211                 R34 1
    X211                 R254 -54
    X211                 R366 8.5
    X211                 R436 1
    X211                 R492 1
    X211                 R534 1
    X211                 R564 1
    X211                 R832 1
    X211                 R838 1
    X211                 R842 1
    X211                 R844 1
    X212                 OBJ 0
    X212                 R34 1
    X212                 R119 -49
    X212                 R383 11.5
    X212                 R591 1
    X212                 R597 1
    X212                 R601 1
    X212                 R603 1
    X212                 R675 1
    X212                 R731 1
    X212                 R773 1
    X212                 R803 1
    X213                 OBJ 0
    X213                 R34 1
    X213                 R164 -53
    X213                 R366 8.5
    X213                 R592 1
    X213                 R598 1
    X213                 R602 1
    X213                 R604 1
    X213                 R676 1
    X213                 R732 1
    X213                 R774 1
    X213                 R804 1
    X214                 OBJ 0
    X214                 R35 1
    X214                 R210 -50
    X214                 R437 1
    X214                 R493 1
    X214                 R535 1
    X214                 R565 1
    X214                 R585 1
    X214                 R605 1
    X214                 R607 1
    X214                 R609 1
    X215                 OBJ 0
    X215                 R35 1
    X215                 R255 -53
    X215                 R438 1
    X215                 R494 1
    X215                 R536 1
    X215                 R566 1
    X215                 R586 1
    X215                 R606 1
    X215                 R608 1
    X215                 R610 1
    X216                 OBJ 0
    X216                 R35 1
    X216                 R120 -51
    X216                 R677 1
    X216                 R733 1
    X216                 R775 1
    X216                 R805 1
    X216                 R825 1
    X216                 R845 1
    X216                 R847 1
    X216                 R849 1
    X217                 OBJ 0
    X217                 R35 1
    X217                 R165 -56
    X217                 R678 1
    X217                 R734 1
    X217                 R776 1
    X217                 R806 1
    X217                 R826 1
    X217                 R846 1
    X217                 R848 1
    X217                 R850 1
    X218                 OBJ 0
    X218                 R36 1
    X218                 R211 -51
    X218                 R380 12.5
    X218                 R439 1
    X218                 R495 1
    X218                 R537 1
    X218                 R567 1
    X218                 R587 1
    X218                 R611 1
    X218                 R613 1
    X218                 R845 1
    X219                 OBJ 0
    X219                 R36 1
    X219                 R256 -53
    X219                 R363 9
    X219                 R440 1
    X219                 R496 1
    X219                 R538 1
    X219                 R568 1
    X219                 R588 1
    X219                 R612 1
    X219                 R614 1
    X219                 R846 1
    X220                 OBJ 0
    X220                 R36 1
    X220                 R121 -51
    X220                 R380 12.5
    X220                 R605 1
    X220                 R679 1
    X220                 R735 1
    X220                 R777 1
    X220                 R807 1
    X220                 R827 1
    X220                 R851 1
    X220                 R853 1
    X221                 OBJ 0
    X221                 R36 1
    X221                 R166 -56
    X221                 R363 9
    X221                 R606 1
    X221                 R680 1
    X221                 R736 1
    X221                 R778 1
    X221                 R808 1
    X221                 R828 1
    X221                 R852 1
    X221                 R854 1
    X222                 OBJ 0
    X222                 R37 1
    X222                 R212 -52
    X222                 R381 12.5
    X222                 R441 1
    X222                 R497 1
    X222                 R539 1
    X222                 R569 1
    X222                 R589 1
    X222                 R615 1
    X222                 R847 1
    X222                 R851 1
    X223                 OBJ 0
    X223                 R37 1
    X223                 R257 -53
    X223                 R364 9.5
    X223                 R442 1
    X223                 R498 1
    X223                 R540 1
    X223                 R570 1
    X223                 R590 1
    X223                 R616 1
    X223                 R848 1
    X223                 R852 1
    X224                 OBJ 0
    X224                 R37 1
    X224                 R122 -51
    X224                 R381 12.5
    X224                 R607 1
    X224                 R611 1
    X224                 R681 1
    X224                 R737 1
    X224                 R779 1
    X224                 R809 1
    X224                 R829 1
    X224                 R855 1
    X225                 OBJ 0
    X225                 R37 1
    X225                 R167 -56
    X225                 R364 9.5
    X225                 R608 1
    X225                 R612 1
    X225                 R682 1
    X225                 R738 1
    X225                 R780 1
    X225                 R810 1
    X225                 R830 1
    X225                 R856 1
    X226                 OBJ 0
    X226                 R38 1
    X226                 R213 -52
    X226                 R375 13
    X226                 R443 1
    X226                 R499 1
    X226                 R541 1
    X226                 R571 1
    X226                 R591 1
    X226                 R849 1
    X226                 R853 1
    X226                 R855 1
    X227                 OBJ 0
    X227                 R38 1
    X227                 R258 -54
    X227                 R358 9.5
    X227                 R444 1
    X227                 R500 1
    X227                 R542 1
    X227                 R572 1
    X227                 R592 1
    X227                 R850 1
    X227                 R854 1
    X227                 R856 1
    X228                 OBJ 0
    X228                 R38 1
    X228                 R123 -51
    X228                 R375 13
    X228                 R609 1
    X228                 R613 1
    X228                 R615 1
    X228                 R683 1
    X228                 R739 1
    X228                 R781 1
    X228                 R811 1
    X228                 R831 1
    X229                 OBJ 0
    X229                 R38 1
    X229                 R168 -56
    X229                 R358 9.5
    X229                 R610 1
    X229                 R614 1
    X229                 R616 1
    X229                 R684 1
    X229                 R740 1
    X229                 R782 1
    X229                 R812 1
    X229                 R832 1
    X230                 OBJ 0
    X230                 R39 1
    X230                 R214 -51
    X230                 R377 11
    X230                 R445 1
    X230                 R501 1
    X230                 R543 1
    X230                 R573 1
    X230                 R593 1
    X230                 R605 1
    X230                 R617 1
    X230                 R619 1
    X231                 OBJ 0
    X231                 R39 1
    X231                 R259 -53
    X231                 R360 8.5
    X231                 R446 1
    X231                 R502 1
    X231                 R544 1
    X231                 R574 1
    X231                 R594 1
    X231                 R606 1
    X231                 R618 1
    X231                 R620 1
    X232                 OBJ 0
    X232                 R39 1
    X232                 R124 -50
    X232                 R377 11
    X232                 R685 1
    X232                 R741 1
    X232                 R783 1
    X232                 R813 1
    X232                 R833 1
    X232                 R845 1
    X232                 R857 1
    X232                 R859 1
    X233                 OBJ 0
    X233                 R39 1
    X233                 R169 -53
    X233                 R360 8.5
    X233                 R686 1
    X233                 R742 1
    X233                 R784 1
    X233                 R814 1
    X233                 R834 1
    X233                 R846 1
    X233                 R858 1
    X233                 R860 1
    X234                 OBJ 0
    X234                 R40 1
    X234                 R215 -52
    X234                 R378 11
    X234                 R447 1
    X234                 R503 1
    X234                 R545 1
    X234                 R575 1
    X234                 R595 1
    X234                 R607 1
    X234                 R621 1
    X234                 R857 1
    X235                 OBJ 0
    X235                 R40 1
    X235                 R260 -53
    X235                 R361 9
    X235                 R448 1
    X235                 R504 1
    X235                 R546 1
    X235                 R576 1
    X235                 R596 1
    X235                 R608 1
    X235                 R622 1
    X235                 R858 1
    X236                 OBJ 0
    X236                 R40 1
    X236                 R125 -50
    X236                 R378 11
    X236                 R617 1
    X236                 R687 1
    X236                 R743 1
    X236                 R785 1
    X236                 R815 1
    X236                 R835 1
    X236                 R847 1
    X236                 R861 1
    X237                 OBJ 0
    X237                 R40 1
    X237                 R170 -53
    X237                 R361 9
    X237                 R618 1
    X237                 R688 1
    X237                 R744 1
    X237                 R786 1
    X237                 R816 1
    X237                 R836 1
    X237                 R848 1
    X237                 R862 1
    X238                 OBJ 0
    X238                 R41 1
    X238                 R216 -52
    X238                 R449 1
    X238                 R505 1
    X238                 R547 1
    X238                 R577 1
    X238                 R597 1
    X238                 R609 1
    X238                 R859 1
    X238                 R861 1
    X239                 OBJ 0
    X239                 R41 1
    X239                 R261 -54
    X239                 R450 1
    X239                 R506 1
    X239                 R548 1
    X239                 R578 1
    X239                 R598 1
    X239                 R610 1
    X239                 R860 1
    X239                 R862 1
    X240                 OBJ 0
    X240                 R41 1
    X240                 R126 -50
    X240                 R619 1
    X240                 R621 1
    X240                 R689 1
    X240                 R745 1
    X240                 R787 1
    X240                 R817 1
    X240                 R837 1
    X240                 R849 1
    X241                 OBJ 0
    X241                 R41 1
    X241                 R171 -53
    X241                 R620 1
    X241                 R622 1
    X241                 R690 1
    X241                 R746 1
    X241                 R788 1
    X241                 R818 1
    X241                 R838 1
    X241                 R850 1
    X242                 OBJ 0
    X242                 R42 1
    X242                 R217 -52
    X242                 R379 11
    X242                 R451 1
    X242                 R507 1
    X242                 R549 1
    X242                 R579 1
    X242                 R599 1
    X242                 R611 1
    X242                 R617 1
    X242                 R623 1
    X243                 OBJ 0
    X243                 R42 1
    X243                 R262 -53
    X243                 R362 9.5
    X243                 R452 1
    X243                 R508 1
    X243                 R550 1
    X243                 R580 1
    X243                 R600 1
    X243                 R612 1
    X243                 R618 1
    X243                 R624 1
    X244                 OBJ 0
    X244                 R42 1
    X244                 R127 -51
    X244                 R379 11
    X244                 R691 1
    X244                 R747 1
    X244                 R789 1
    X244                 R819 1
    X244                 R839 1
    X244                 R851 1
    X244                 R857 1
    X244                 R863 1
    X245                 OBJ 0
    X245                 R42 1
    X245                 R172 -53
    X245                 R362 9.5
    X245                 R692 1
    X245                 R748 1
    X245                 R790 1
    X245                 R820 1
    X245                 R840 1
    X245                 R852 1
    X245                 R858 1
    X245                 R864 1
    X246                 OBJ 0
    X246                 R43 1
    X246                 R218 -52
    X246                 R376 11.5
    X246                 R453 1
    X246                 R509 1
    X246                 R551 1
    X246                 R581 1
    X246                 R601 1
    X246                 R613 1
    X246                 R619 1
    X246                 R863 1
    X247                 OBJ 0
    X247                 R43 1
    X247                 R263 -54
    X247                 R359 9.5
    X247                 R454 1
    X247                 R510 1
    X247                 R552 1
    X247                 R582 1
    X247                 R602 1
    X247                 R614 1
    X247                 R620 1
    X247                 R864 1
    X248                 OBJ 0
    X248                 R43 1
    X248                 R128 -51
    X248                 R376 11.5
    X248                 R623 1
    X248                 R693 1
    X248                 R749 1
    X248                 R791 1
    X248                 R821 1
    X248                 R841 1
    X248                 R853 1
    X248                 R859 1
    X249                 OBJ 0
    X249                 R43 1
    X249                 R173 -53
    X249                 R359 9.5
    X249                 R624 1
    X249                 R694 1
    X249                 R750 1
    X249                 R792 1
    X249                 R822 1
    X249                 R842 1
    X249                 R854 1
    X249                 R860 1
    X250                 OBJ 0
    X250                 R44 1
    X250                 R219 -52
    X250                 R455 1
    X250                 R511 1
    X250                 R553 1
    X250                 R583 1
    X250                 R603 1
    X250                 R615 1
    X250                 R621 1
    X250                 R623 1
    X251                 OBJ 0
    X251                 R44 1
    X251                 R264 -54
    X251                 R456 1
    X251                 R512 1
    X251                 R554 1
    X251                 R584 1
    X251                 R604 1
    X251                 R616 1
    X251                 R622 1
    X251                 R624 1
    X252                 OBJ 0
    X252                 R44 1
    X252                 R129 -52
    X252                 R695 1
    X252                 R751 1
    X252                 R793 1
    X252                 R823 1
    X252                 R843 1
    X252                 R855 1
    X252                 R861 1
    X252                 R863 1
    X253                 OBJ 0
    X253                 R44 1
    X253                 R174 -53
    X253                 R696 1
    X253                 R752 1
    X253                 R794 1
    X253                 R824 1
    X253                 R844 1
    X253                 R856 1
    X253                 R862 1
    X253                 R864 1
RHS
    RHS                  OBJ -0
    RHS                  R0 1
    RHS                  R1 1
    RHS                  R2 1
    RHS                  R3 1
    RHS                  R4 1
    RHS                  R5 1
    RHS                  R6 1
    RHS                  R7 1
    RHS                  R8 1
    RHS                  R9 1
    RHS                  R10 1
    RHS                  R11 1
    RHS                  R12 1
    RHS                  R13 1
    RHS                  R14 1
    RHS                  R15 1
    RHS                  R16 1
    RHS                  R17 1
    RHS                  R18 1
    RHS                  R19 1
    RHS                  R20 1
    RHS                  R21 1
    RHS                  R22 1
    RHS                  R23 1
    RHS                  R24 1
    RHS                  R25 1
    RHS                  R26 1
    RHS                  R27 1
    RHS                  R28 1
    RHS                  R29 1
    RHS                  R30 1
    RHS                  R31 1
    RHS                  R32 1
    RHS                  R33 1
    RHS                  R34 1
    RHS                  R35 1
    RHS                  R36 1
    RHS                  R37 1
    RHS                  R38 1
    RHS                  R39 1
    RHS                  R40 1
    RHS                  R41 1
    RHS                  R42 1
    RHS                  R43 1
    RHS                  R44 1
    RHS                  R45 17.5
    RHS                  R46 18.5
    RHS                  R47 19
    RHS                  R48 19
    RHS                  R49 18.5
    RHS                  R50 17.5
    RHS                  R51 18
    RHS                  R52 17.5
    RHS                  R53 17
    RHS                  R54 17
    RHS                  R55 16.5
    RHS                  R56 16
    RHS                  R57 17
    RHS                  R58 17
    RHS                  R59 16.5
    RHS                  R60 15
    RHS                  R61 16.5
    RHS                  R62 16.5
    RHS                  R63 16.5
    RHS                  R64 16
    RHS                  R65 -17.5
    RHS                  R66 -18.5
    RHS                  R67 -19
    RHS                  R68 -19
    RHS                  R69 -18.5
    RHS                  R70 -17.5
    RHS                  R71 -18
    RHS                  R72 -17.5
    RHS                  R73 -17
    RHS                  R74 -17
    RHS                  R75 -16.5
    RHS                  R76 -16
    RHS                  R77 -17
    RHS                  R78 -17
    RHS                  R79 -16.5
    RHS                  R80 -15
    RHS                  R81 -16.5
    RHS                  R82 -16.5
    RHS                  R83 -16.5
    RHS                  R84 -16
    RHS                  R85 -42
    RHS                  R86 -42
    RHS                  R87 -42
    RHS                  R88 -42
    RHS                  R89 -42
    RHS                  R90 -42
    RHS                  R91 -42
    RHS                  R92 -42
    RHS                  R93 -42
    RHS                  R94 -42
    RHS                  R95 -42
    RHS                  R96 -42
    RHS                  R97 -42
    RHS                  R98 -42
    RHS                  R99 -42
    RHS                  R100 -42
    RHS                  R101 -42
    RHS                  R102 -42
    RHS                  R103 -42
    RHS                  R104 -42
    RHS                  R105 -42
    RHS                  R106 -42
    RHS                  R107 -42
    RHS                  R108 -42
    RHS                  R109 -42
    RHS                  R110 -42
    RHS                  R111 -42
    RHS                  R112 -42
    RHS                  R113 -42
    RHS                  R114 -42
    RHS                  R115 -42
    RHS                  R116 -42
    RHS                  R117 -42
    RHS                  R118 -42
    RHS                  R119 -42
    RHS                  R120 -42
    RHS                  R121 -42
    RHS                  R122 -42
    RHS                  R123 -42
    RHS                  R124 -42
    RHS                  R125 -42
    RHS                  R126 -42
    RHS                  R127 -42
    RHS                  R128 -42
    RHS                  R129 -42
    RHS                  R130 -42
    RHS                  R131 -42
    RHS                  R132 -42
    RHS                  R133 -42
    RHS                  R134 -42
    RHS                  R135 -42
    RHS                  R136 -42
    RHS                  R137 -42
    RHS                  R138 -42
    RHS                  R139 -42
    RHS                  R140 -42
    RHS                  R141 -42
    RHS                  R142 -42
    RHS                  R143 -42
    RHS                  R144 -42
    RHS                  R145 -42
    RHS                  R146 -42
    RHS                  R147 -42
    RHS                  R148 -42
    RHS                  R149 -42
    RHS                  R150 -42
    RHS                  R151 -42
    RHS                  R152 -42
    RHS                  R153 -42
    RHS                  R154 -42
    RHS                  R155 -42
    RHS                  R156 -42
    RHS                  R157 -42
    RHS                  R158 -42
    RHS                  R159 -42
    RHS                  R160 -42
    RHS                  R161 -42
    RHS                  R162 -42
    RHS                  R163 -42
    RHS                  R164 -42
    RHS                  R165 -42
    RHS                  R166 -42
    RHS                  R167 -42
    RHS                  R168 -42
    RHS                  R169 -42
    RHS                  R170 -42
    RHS                  R171 -42
    RHS                  R172 -42
    RHS                  R173 -42
    RHS                  R174 -42
    RHS                  R175 -42
    RHS                  R176 -42
    RHS                  R177 -42
    RHS                  R178 -42
    RHS                  R179 -42
    RHS                  R180 -42
    RHS                  R181 -42
    RHS                  R182 -42
    RHS                  R183 -42
    RHS                  R184 -42
    RHS                  R185 -42
    RHS                  R186 -42
    RHS                  R187 -42
    RHS                  R188 -42
    RHS                  R189 -42
    RHS                  R190 -42
    RHS                  R191 -42
    RHS                  R192 -42
    RHS                  R193 -42
    RHS                  R194 -42
    RHS                  R195 -42
    RHS                  R196 -42
    RHS                  R197 -42
    RHS                  R198 -42
    RHS                  R199 -42
    RHS                  R200 -42
    RHS                  R201 -42
    RHS                  R202 -42
    RHS                  R203 -42
    RHS                  R204 -42
    RHS                  R205 -42
    RHS                  R206 -42
    RHS                  R207 -42
    RHS                  R208 -42
    RHS                  R209 -42
    RHS                  R210 -42
    RHS                  R211 -42
    RHS                  R212 -42
    RHS                  R213 -42
    RHS                  R214 -42
    RHS                  R215 -42
    RHS                  R216 -42
    RHS                  R217 -42
    RHS                  R218 -42
    RHS                  R219 -42
    RHS                  R220 -42
    RHS                  R221 -42
    RHS                  R222 -42
    RHS                  R223 -42
    RHS                  R224 -42
    RHS                  R225 -42
    RHS                  R226 -42
    RHS                  R227 -42
    RHS                  R228 -42
    RHS                  R229 -42
    RHS                  R230 -42
    RHS                  R231 -42
    RHS                  R232 -42
    RHS                  R233 -42
    RHS                  R234 -42
    RHS                  R235 -42
    RHS                  R236 -42
    RHS                  R237 -42
    RHS                  R238 -42
    RHS                  R239 -42
    RHS                  R240 -42
    RHS                  R241 -42
    RHS                  R242 -42
    RHS                  R243 -42
    RHS                  R244 -42
    RHS                  R245 -42
    RHS                  R246 -42
    RHS                  R247 -42
    RHS                  R248 -42
    RHS                  R249 -42
    RHS                  R250 -42
    RHS                  R251 -42
    RHS                  R252 -42
    RHS                  R253 -42
    RHS                  R254 -42
    RHS                  R255 -42
    RHS                  R256 -42
    RHS                  R257 -42
    RHS                  R258 -42
    RHS                  R259 -42
    RHS                  R260 -42
    RHS                  R261 -42
    RHS                  R262 -42
    RHS                  R263 -42
    RHS                  R264 -42
    RHS                  R265 1
    RHS                  R266 0
    RHS                  R267 -0.5
    RHS                  R268 0
    RHS                  R269 1
    RHS                  R270 -1
    RHS                  R271 -1.5
    RHS                  R272 -0.5
    RHS                  R273 0.5
    RHS                  R274 -0.5
    RHS                  R275 -1
    RHS                  R276 -0.5
    RHS                  R277 0
    RHS                  R278 0.5
    RHS                  R279 -0.5
    RHS                  R280 -1.5
    RHS                  R281 -1.5
    RHS                  R282 -0.5
    RHS                  R283 -1.5
    RHS                  R284 -0.5
    RHS                  R285 0
    RHS                  R286 0
    RHS                  R287 -1
    RHS                  R288 -2
    RHS                  R289 1
    RHS                  R290 0.5
    RHS                  R291 0
    RHS                  R292 0
    RHS                  R293 0
    RHS                  R294 -1.5
    RHS                  R295 -1.5
    RHS                  R296 -0.5
    RHS                  R297 -0.5
    RHS                  R298 0
    RHS                  R299 -1
    RHS                  R300 0
    RHS                  R301 0.5
    RHS                  R302 0
    RHS                  R303 -1
    RHS                  R304 1
    RHS                  R305 1.5
    RHS                  R306 0.5
    RHS                  R307 -0.5
    RHS                  R308 0.5
    RHS                  R309 1
    RHS                  R310 0.5
    RHS                  R311 0
    RHS                  R312 -0.5
    RHS                  R313 0.5
    RHS                  R314 1.5
    RHS                  R315 1.5
    RHS                  R316 0.5
    RHS                  R317 1.5
    RHS                  R318 0.5
    RHS                  R319 0
    RHS                  R320 0
    RHS                  R321 1
    RHS                  R322 2
    RHS                  R323 -1
    RHS                  R324 -0.5
    RHS                  R325 0
    RHS                  R326 0
    RHS                  R327 0
    RHS                  R328 1.5
    RHS                  R329 1.5
    RHS                  R330 0.5
    RHS                  R331 0.5
    RHS                  R332 0
    RHS                  R333 8
    RHS                  R334 9
    RHS                  R335 9.5
    RHS                  R336 9
    RHS                  R337 8
    RHS                  R338 8
    RHS                  R339 7.5
    RHS                  R340 9.5
    RHS                  R341 9.5
    RHS                  R342 8.5
    RHS                  R343 9
    RHS                  R344 9.5
    RHS                  R345 9
    RHS                  R346 9.5
    RHS                  R347 6.5
    RHS                  R348 8.5
    RHS                  R349 8.5
    RHS                  R350 30
    RHS                  R351 8
    RHS                  R352 9
    RHS                  R353 9.5
    RHS                  R354 9
    RHS                  R355 8
    RHS                  R356 8
    RHS                  R357 7.5
    RHS                  R358 9.5
    RHS                  R359 9.5
    RHS                  R360 8.5
    RHS                  R361 9
    RHS                  R362 9.5
    RHS                  R363 9
    RHS                  R364 9.5
    RHS                  R365 6.5
    RHS                  R366 8.5
    RHS                  R367 8.5
    RHS                  R368 11.5
    RHS                  R369 12.5
    RHS                  R370 11.5
    RHS                  R371 11
    RHS                  R372 11
    RHS                  R373 13
    RHS                  R374 12
    RHS                  R375 13
    RHS                  R376 11.5
    RHS                  R377 11
    RHS                  R378 11
    RHS                  R379 11
    RHS                  R380 12.5
    RHS                  R381 12.5
    RHS                  R382 10.5
    RHS                  R383 11.5
    RHS                  R384 11
    RHS                  R385 2
    RHS                  R386 2
    RHS                  R387 2
    RHS                  R388 2
    RHS                  R389 2
    RHS                  R390 2
    RHS                  R391 2
    RHS                  R392 2
    RHS                  R393 2
    RHS                  R394 2
    RHS                  R395 2
    RHS                  R396 2
    RHS                  R397 2
    RHS                  R398 2
    RHS                  R399 2
    RHS                  R400 2
    RHS                  R401 2
    RHS                  R402 2
    RHS                  R403 2
    RHS                  R404 2
    RHS                  R405 2
    RHS                  R406 2
    RHS                  R407 2
    RHS                  R408 2
    RHS                  R409 2
    RHS                  R410 2
    RHS                  R411 2
    RHS                  R412 2
    RHS                  R413 2
    RHS                  R414 2
    RHS                  R415 2
    RHS                  R416 2
    RHS                  R417 2
    RHS                  R418 2
    RHS                  R419 2
    RHS                  R420 2
    RHS                  R421 2
    RHS                  R422 2
    RHS                  R423 2
    RHS                  R424 2
    RHS                  R425 2
    RHS                  R426 2
    RHS                  R427 2
    RHS                  R428 2
    RHS                  R429 2
    RHS                  R430 2
    RHS                  R431 2
    RHS                  R432 2
    RHS                  R433 2
    RHS                  R434 2
    RHS                  R435 2
    RHS                  R436 2
    RHS                  R437 2
    RHS                  R438 2
    RHS                  R439 2
    RHS                  R440 2
    RHS                  R441 2
    RHS                  R442 2
    RHS                  R443 2
    RHS                  R444 2
    RHS                  R445 2
    RHS                  R446 2
    RHS                  R447 2
    RHS                  R448 2
    RHS                  R449 2
    RHS                  R450 2
    RHS                  R451 2
    RHS                  R452 2
    RHS                  R453 2
    RHS                  R454 2
    RHS                  R455 2
    RHS                  R456 2
    RHS                  R457 2
    RHS                  R458 2
    RHS                  R459 2
    RHS                  R460 2
    RHS                  R461 2
    RHS                  R462 2
    RHS                  R463 2
    RHS                  R464 2
    RHS                  R465 2
    RHS                  R466 2
    RHS                  R467 2
    RHS                  R468 2
    RHS                  R469 2
    RHS                  R470 2
    RHS                  R471 2
    RHS                  R472 2
    RHS                  R473 2
    RHS                  R474 2
    RHS                  R475 2
    RHS                  R476 2
    RHS                  R477 2
    RHS                  R478 2
    RHS                  R479 2
    RHS                  R480 2
    RHS                  R481 2
    RHS                  R482 2
    RHS                  R483 2
    RHS                  R484 2
    RHS                  R485 2
    RHS                  R486 2
    RHS                  R487 2
    RHS                  R488 2
    RHS                  R489 2
    RHS                  R490 2
    RHS                  R491 2
    RHS                  R492 2
    RHS                  R493 2
    RHS                  R494 2
    RHS                  R495 2
    RHS                  R496 2
    RHS                  R497 2
    RHS                  R498 2
    RHS                  R499 2
    RHS                  R500 2
    RHS                  R501 2
    RHS                  R502 2
    RHS                  R503 2
    RHS                  R504 2
    RHS                  R505 2
    RHS                  R506 2
    RHS                  R507 2
    RHS                  R508 2
    RHS                  R509 2
    RHS                  R510 2
    RHS                  R511 2
    RHS                  R512 2
    RHS                  R513 2
    RHS                  R514 2
    RHS                  R515 2
    RHS                  R516 2
    RHS                  R517 2
    RHS                  R518 2
    RHS                  R519 2
    RHS                  R520 2
    RHS                  R521 2
    RHS                  R522 2
    RHS                  R523 2
    RHS                  R524 2
    RHS                  R525 2
    RHS                  R526 2
    RHS                  R527 2
    RHS                  R528 2
    RHS                  R529 2
    RHS                  R530 2
    RHS                  R531 2
    RHS                  R532 2
    RHS                  R533 2
    RHS                  R534 2
    RHS                  R535 2
    RHS                  R536 2
    RHS                  R537 2
    RHS                  R538 2
    RHS                  R539 2
    RHS                  R540 2
    RHS                  R541 2
    RHS                  R542 2
    RHS                  R543 2
    RHS                  R544 2
    RHS                  R545 2
    RHS                  R546 2
    RHS                  R547 2
    RHS                  R548 2
    RHS                  R549 2
    RHS                  R550 2
    RHS                  R551 2
    RHS                  R552 2
    RHS                  R553 2
    RHS                  R554 2
    RHS                  R555 2
    RHS                  R556 2
    RHS                  R557 2
    RHS                  R558 2
    RHS                  R559 2
    RHS                  R560 2
    RHS                  R561 2
    RHS                  R562 2
    RHS                  R563 2
    RHS                  R564 2
    RHS                  R565 2
    RHS                  R566 2
    RHS                  R567 2
    RHS                  R568 2
    RHS                  R569 2
    RHS                  R570 2
    RHS                  R571 2
    RHS                  R572 2
    RHS                  R573 2
    RHS                  R574 2
    RHS                  R575 2
    RHS                  R576 2
    RHS                  R577 2
    RHS                  R578 2
    RHS                  R579 2
    RHS                  R580 2
    RHS                  R581 2
    RHS                  R582 2
    RHS                  R583 2
    RHS                  R584 2
    RHS                  R585 2
    RHS                  R586 2
    RHS                  R587 2
    RHS                  R588 2
    RHS                  R589 2
    RHS                  R590 2
    RHS                  R591 2
    RHS                  R592 2
    RHS                  R593 2
    RHS                  R594 2
    RHS                  R595 2
    RHS                  R596 2
    RHS                  R597 2
    RHS                  R598 2
    RHS                  R599 2
    RHS                  R600 2
    RHS                  R601 2
    RHS                  R602 2
    RHS                  R603 2
    RHS                  R604 2
    RHS                  R605 2
    RHS                  R606 2
    RHS                  R607 2
    RHS                  R608 2
    RHS                  R609 2
    RHS                  R610 2
    RHS                  R611 2
    RHS                  R612 2
    RHS                  R613 2
    RHS                  R614 2
    RHS                  R615 2
    RHS                  R616 2
    RHS                  R617 2
    RHS                  R618 2
    RHS                  R619 2
    RHS                  R620 2
    RHS                  R621 2
    RHS                  R622 2
    RHS                  R623 2
    RHS                  R624 2
    RHS                  R625 2
    RHS                  R626 2
    RHS                  R627 2
    RHS                  R628 2
    RHS                  R629 2
    RHS                  R630 2
    RHS                  R631 2
    RHS                  R632 2
    RHS                  R633 2
    RHS                  R634 2
    RHS                  R635 2
    RHS                  R636 2
    RHS                  R637 2
    RHS                  R638 2
    RHS                  R639 2
    RHS                  R640 2
    RHS                  R641 2
    RHS                  R642 2
    RHS                  R643 2
    RHS                  R644 2
    RHS                  R645 2
    RHS                  R646 2
    RHS                  R647 2
    RHS                  R648 2
    RHS                  R649 2
    RHS                  R650 2
    RHS                  R651 2
    RHS                  R652 2
    RHS                  R653 2
    RHS                  R654 2
    RHS                  R655 2
    RHS                  R656 2
    RHS                  R657 2
    RHS                  R658 2
    RHS                  R659 2
    RHS                  R660 2
    RHS                  R661 2
    RHS                  R662 2
    RHS                  R663 2
    RHS                  R664 2
    RHS                  R665 2
    RHS                  R666 2
    RHS                  R667 2
    RHS                  R668 2
    RHS                  R669 2
    RHS                  R670 2
    RHS                  R671 2
    RHS                  R672 2
    RHS                  R673 2
    RHS                  R674 2
    RHS                  R675 2
    RHS                  R676 2
    RHS                  R677 2
    RHS                  R678 2
    RHS                  R679 2
    RHS                  R680 2
    RHS                  R681 2
    RHS                  R682 2
    RHS                  R683 2
    RHS                  R684 2
    RHS                  R685 2
    RHS                  R686 2
    RHS                  R687 2
    RHS                  R688 2
    RHS                  R689 2
    RHS                  R690 2
    RHS                  R691 2
    RHS                  R692 2
    RHS                  R693 2
    RHS                  R694 2
    RHS                  R695 2
    RHS                  R696 2
    RHS                  R697 2
    RHS                  R698 2
    RHS                  R699 2
    RHS                  R700 2
    RHS                  R701 2
    RHS                  R702 2
    RHS                  R703 2
    RHS                  R704 2
    RHS                  R705 2
    RHS                  R706 2
    RHS                  R707 2
    RHS                  R708 2
    RHS                  R709 2
    RHS                  R710 2
    RHS                  R711 2
    RHS                  R712 2
    RHS                  R713 2
    RHS                  R714 2
    RHS                  R715 2
    RHS                  R716 2
    RHS                  R717 2
    RHS                  R718 2
    RHS                  R719 2
    RHS                  R720 2
    RHS                  R721 2
    RHS                  R722 2
    RHS                  R723 2
    RHS                  R724 2
    RHS                  R725 2
    RHS                  R726 2
    RHS                  R727 2
    RHS                  R728 2
    RHS                  R729 2
    RHS                  R730 2
    RHS                  R731 2
    RHS                  R732 2
    RHS                  R733 2
    RHS                  R734 2
    RHS                  R735 2
    RHS                  R736 2
    RHS                  R737 2
    RHS                  R738 2
    RHS                  R739 2
    RHS                  R740 2
    RHS                  R741 2
    RHS                  R742 2
    RHS                  R743 2
    RHS                  R744 2
    RHS                  R745 2
    RHS                  R746 2
    RHS                  R747 2
    RHS                  R748 2
    RHS                  R749 2
    RHS                  R750 2
    RHS                  R751 2
    RHS                  R752 2
    RHS                  R753 2
    RHS                  R754 2
    RHS                  R755 2
    RHS                  R756 2
    RHS                  R757 2
    RHS                  R758 2
    RHS                  R759 2
    RHS                  R760 2
    RHS                  R761 2
    RHS                  R762 2
    RHS                  R763 2
    RHS                  R764 2
    RHS                  R765 2
    RHS                  R766 2
    RHS                  R767 2
    RHS                  R768 2
    RHS                  R769 2
    RHS                  R770 2
    RHS                  R771 2
    RHS                  R772 2
    RHS                  R773 2
    RHS                  R774 2
    RHS                  R775 2
    RHS                  R776 2
    RHS                  R777 2
    RHS                  R778 2
    RHS                  R779 2
    RHS                  R780 2
    RHS                  R781 2
    RHS                  R782 2
    RHS                  R783 2
    RHS                  R784 2
    RHS                  R785 2
    RHS                  R786 2
    RHS                  R787 2
    RHS                  R788 2
    RHS                  R789 2
    RHS                  R790 2
    RHS                  R791 2
    RHS                  R792 2
    RHS                  R793 2
    RHS                  R794 2
    RHS                  R795 2
    RHS                  R796 2
    RHS                  R797 2
    RHS                  R798 2
    RHS                  R799 2
    RHS                  R800 2
    RHS                  R801 2
    RHS                  R802 2
    RHS                  R803 2
    RHS                  R804 2
    RHS                  R805 2
    RHS                  R806 2
    RHS                  R807 2
    RHS                  R808 2
    RHS                  R809 2
    RHS                  R810 2
    RHS                  R811 2
    RHS                  R812 2
    RHS                  R813 2
    RHS                  R814 2
    RHS                  R815 2
    RHS                  R816 2
    RHS                  R817 2
    RHS                  R818 2
    RHS                  R819 2
    RHS                  R820 2
    RHS                  R821 2
    RHS                  R822 2
    RHS                  R823 2
    RHS                  R824 2
    RHS                  R825 2
    RHS                  R826 2
    RHS                  R827 2
    RHS                  R828 2
    RHS                  R829 2
    RHS                  R830 2
    RHS                  R831 2
    RHS                  R832 2
    RHS                  R833 2
    RHS                  R834 2
    RHS                  R835 2
    RHS                  R836 2
    RHS                  R837 2
    RHS                  R838 2
    RHS                  R839 2
    RHS                  R840 2
    RHS                  R841 2
    RHS                  R842 2
    RHS                  R843 2
    RHS                  R844 2
    RHS                  R845 2
    RHS                  R846 2
    RHS                  R847 2
    RHS                  R848 2
    RHS                  R849 2
    RHS                  R850 2
    RHS                  R851 2
    RHS                  R852 2
    RHS                  R853 2
    RHS                  R854 2
    RHS                  R855 2
    RHS                  R856 2
    RHS                  R857 2
    RHS                  R858 2
    RHS                  R859 2
    RHS                  R860 2
    RHS                  R861 2
    RHS                  R862 2
    RHS                  R863 2
    RHS                  R864 2
BOUNDS
 	FR BND X0
 	LO BND X0 1
 	UP BND X0 34
 	FR BND X1
 	LO BND X1 1
 	UP BND X1 36
 	FR BND X2
 	LO BND X2 1
 	UP BND X2 37
 	FR BND X3
 	LO BND X3 1
 	UP BND X3 37
 	FR BND X4
 	LO BND X4 1
 	UP BND X4 36
 	FR BND X5
 	LO BND X5 1
 	UP BND X5 34
 	FR BND X6
 	LO BND X6 1
 	UP BND X6 35
 	FR BND X7
 	LO BND X7 1
 	UP BND X7 34
 	FR BND X8
 	LO BND X8 1
 	UP BND X8 33
 	FR BND X9
 	LO BND X9 1
 	UP BND X9 33
 	FR BND X10
 	LO BND X10 1
 	UP BND X10 32
 	FR BND X11
 	LO BND X11 1
 	UP BND X11 31
 	FR BND X12
 	LO BND X12 1
 	UP BND X12 33
 	FR BND X13
 	LO BND X13 1
 	UP BND X13 33
 	FR BND X14
 	LO BND X14 1
 	UP BND X14 32
 	FR BND X15
 	LO BND X15 1
 	UP BND X15 29
 	FR BND X16
 	LO BND X16 1
 	UP BND X16 32
 	FR BND X17
 	LO BND X17 1
 	UP BND X17 32
 	FR BND X18
 	LO BND X18 1
 	UP BND X18 32
 	FR BND X19
 	LO BND X19 1
 	UP BND X19 31
 	FR BND X20
 	FR BND X21
 	FR BND X22
 	FR BND X23
 	FR BND X24
 	FR BND X25
 	FR BND X26
 	FR BND X27
 	FR BND X28
 	FR BND X29
 	FR BND X30
 	FR BND X31
 	FR BND X32
 	FR BND X33
 	FR BND X34
 	FR BND X35
 	FR BND X36
 	FR BND X37
 	FR BND X38
 	FR BND X39
 	FR BND X40
 	LO BND X40 0
 	UP BND X40 43
 	FR BND X41
 	LO BND X41 0
 	UP BND X41 42
 	FR BND X42
 	LO BND X42 0
 	UP BND X42 42.5
 	FR BND X43
 	LO BND X43 0
 	UP BND X43 42
 	FR BND X44
 	LO BND X44 0
 	UP BND X44 43
 	FR BND X45
 	LO BND X45 0
 	UP BND X45 43
 	FR BND X46
 	LO BND X46 0
 	UP BND X46 43.5
 	FR BND X47
 	LO BND X47 0
 	UP BND X47 42.5
 	FR BND X48
 	LO BND X48 0
 	UP BND X48 42.5
 	FR BND X49
 	LO BND X49 0
 	UP BND X49 42.5
 	FR BND X50
 	LO BND X50 0
 	UP BND X50 43
 	FR BND X51
 	LO BND X51 0
 	UP BND X51 42.5
 	FR BND X52
 	LO BND X52 0
 	UP BND X52 42
 	FR BND X53
 	LO BND X53 0
 	UP BND X53 42.5
 	FR BND X54
 	LO BND X54 0
 	UP BND X54 42.5
 	FR BND X55
 	LO BND X55 0
 	UP BND X55 43.5
 	FR BND X56
 	LO BND X56 0
 	UP BND X56 43.5
 	FR BND X57
 	LO BND X57 0
 	UP BND X57 42.5
 	FR BND X58
 	LO BND X58 0
 	UP BND X58 43.5
 	FR BND X59
 	LO BND X59 0
 	UP BND X59 42.5
 	FR BND X60
 	LO BND X60 0
 	UP BND X60 42
 	FR BND X61
 	LO BND X61 0
 	UP BND X61 42
 	FR BND X62
 	LO BND X62 0
 	UP BND X62 43
 	FR BND X63
 	LO BND X63 0
 	UP BND X63 44
 	FR BND X64
 	LO BND X64 0
 	UP BND X64 43
 	FR BND X65
 	LO BND X65 0
 	UP BND X65 42.5
 	FR BND X66
 	LO BND X66 0
 	UP BND X66 42
 	FR BND X67
 	LO BND X67 0
 	UP BND X67 42
 	FR BND X68
 	LO BND X68 0
 	UP BND X68 42
 	FR BND X69
 	LO BND X69 0
 	UP BND X69 43.5
 	FR BND X70
 	LO BND X70 0
 	UP BND X70 43.5
 	FR BND X71
 	LO BND X71 0
 	UP BND X71 42.5
 	FR BND X72
 	LO BND X72 0
 	UP BND X72 42.5
 	FR BND X73
 	LO BND X73 0
 	UP BND X73 42
 	FR BND X74
 	LO BND X74 0
 	UP BND X74 1
 	FR BND X75
 	LO BND X75 0
 	UP BND X75 1
 	FR BND X76
 	LO BND X76 0
 	UP BND X76 1
 	FR BND X77
 	LO BND X77 0
 	UP BND X77 1
 	FR BND X78
 	LO BND X78 0
 	UP BND X78 1
 	FR BND X79
 	LO BND X79 0
 	UP BND X79 1
 	FR BND X80
 	LO BND X80 0
 	UP BND X80 1
 	FR BND X81
 	LO BND X81 0
 	UP BND X81 1
 	FR BND X82
 	LO BND X82 0
 	UP BND X82 1
 	FR BND X83
 	LO BND X83 0
 	UP BND X83 1
 	FR BND X84
 	LO BND X84 0
 	UP BND X84 1
 	FR BND X85
 	LO BND X85 0
 	UP BND X85 1
 	FR BND X86
 	LO BND X86 0
 	UP BND X86 1
 	FR BND X87
 	LO BND X87 0
 	UP BND X87 1
 	FR BND X88
 	LO BND X88 0
 	UP BND X88 1
 	FR BND X89
 	LO BND X89 0
 	UP BND X89 1
 	FR BND X90
 	LO BND X90 0
 	UP BND X90 1
 	FR BND X91
 	LO BND X91 0
 	UP BND X91 1
 	FR BND X92
 	LO BND X92 0
 	UP BND X92 1
 	FR BND X93
 	LO BND X93 0
 	UP BND X93 1
 	FR BND X94
 	LO BND X94 0
 	UP BND X94 1
 	FR BND X95
 	LO BND X95 0
 	UP BND X95 1
 	FR BND X96
 	LO BND X96 0
 	UP BND X96 1
 	FR BND X97
 	LO BND X97 0
 	UP BND X97 1
 	FR BND X98
 	LO BND X98 0
 	UP BND X98 1
 	FR BND X99
 	LO BND X99 0
 	UP BND X99 1
 	FR BND X100
 	LO BND X100 0
 	UP BND X100 1
 	FR BND X101
 	LO BND X101 0
 	UP BND X101 1
 	FR BND X102
 	LO BND X102 0
 	UP BND X102 1
 	FR BND X103
 	LO BND X103 0
 	UP BND X103 1
 	FR BND X104
 	LO BND X104 0
 	UP BND X104 1
 	FR BND X105
 	LO BND X105 0
 	UP BND X105 1
 	FR BND X106
 	LO BND X106 0
 	UP BND X106 1
 	FR BND X107
 	LO BND X107 0
 	UP BND X107 1
 	FR BND X108
 	LO BND X108 0
 	UP BND X108 1
 	FR BND X109
 	LO BND X109 0
 	UP BND X109 1
 	FR BND X110
 	LO BND X110 0
 	UP BND X110 1
 	FR BND X111
 	LO BND X111 0
 	UP BND X111 1
 	FR BND X112
 	LO BND X112 0
 	UP BND X112 1
 	FR BND X113
 	LO BND X113 0
 	UP BND X113 1
 	FR BND X114
 	LO BND X114 0
 	UP BND X114 1
 	FR BND X115
 	LO BND X115 0
 	UP BND X115 1
 	FR BND X116
 	LO BND X116 0
 	UP BND X116 1
 	FR BND X117
 	LO BND X117 0
 	UP BND X117 1
 	FR BND X118
 	LO BND X118 0
 	UP BND X118 1
 	FR BND X119
 	LO BND X119 0
 	UP BND X119 1
 	FR BND X120
 	LO BND X120 0
 	UP BND X120 1
 	FR BND X121
 	LO BND X121 0
 	UP BND X121 1
 	FR BND X122
 	LO BND X122 0
 	UP BND X122 1
 	FR BND X123
 	LO BND X123 0
 	UP BND X123 1
 	FR BND X124
 	LO BND X124 0
 	UP BND X124 1
 	FR BND X125
 	LO BND X125 0
 	UP BND X125 1
 	FR BND X126
 	LO BND X126 0
 	UP BND X126 1
 	FR BND X127
 	LO BND X127 0
 	UP BND X127 1
 	FR BND X128
 	LO BND X128 0
 	UP BND X128 1
 	FR BND X129
 	LO BND X129 0
 	UP BND X129 1
 	FR BND X130
 	LO BND X130 0
 	UP BND X130 1
 	FR BND X131
 	LO BND X131 0
 	UP BND X131 1
 	FR BND X132
 	LO BND X132 0
 	UP BND X132 1
 	FR BND X133
 	LO BND X133 0
 	UP BND X133 1
 	FR BND X134
 	LO BND X134 0
 	UP BND X134 1
 	FR BND X135
 	LO BND X135 0
 	UP BND X135 1
 	FR BND X136
 	LO BND X136 0
 	UP BND X136 1
 	FR BND X137
 	LO BND X137 0
 	UP BND X137 1
 	FR BND X138
 	LO BND X138 0
 	UP BND X138 1
 	FR BND X139
 	LO BND X139 0
 	UP BND X139 1
 	FR BND X140
 	LO BND X140 0
 	UP BND X140 1
 	FR BND X141
 	LO BND X141 0
 	UP BND X141 1
 	FR BND X142
 	LO BND X142 0
 	UP BND X142 1
 	FR BND X143
 	LO BND X143 0
 	UP BND X143 1
 	FR BND X144
 	LO BND X144 0
 	UP BND X144 1
 	FR BND X145
 	LO BND X145 0
 	UP BND X145 1
 	FR BND X146
 	LO BND X146 0
 	UP BND X146 1
 	FR BND X147
 	LO BND X147 0
 	UP BND X147 1
 	FR BND X148
 	LO BND X148 0
 	UP BND X148 1
 	FR BND X149
 	LO BND X149 0
 	UP BND X149 1
 	FR BND X150
 	LO BND X150 0
 	UP BND X150 1
 	FR BND X151
 	LO BND X151 0
 	UP BND X151 1
 	FR BND X152
 	LO BND X152 0
 	UP BND X152 1
 	FR BND X153
 	LO BND X153 0
 	UP BND X153 1
 	FR BND X154
 	LO BND X154 0
 	UP BND X154 1
 	FR BND X155
 	LO BND X155 0
 	UP BND X155 1
 	FR BND X156
 	LO BND X156 0
 	UP BND X156 1
 	FR BND X157
 	LO BND X157 0
 	UP BND X157 1
 	FR BND X158
 	LO BND X158 0
 	UP BND X158 1
 	FR BND X159
 	LO BND X159 0
 	UP BND X159 1
 	FR BND X160
 	LO BND X160 0
 	UP BND X160 1
 	FR BND X161
 	LO BND X161 0
 	UP BND X161 1
 	FR BND X162
 	LO BND X162 0
 	UP BND X162 1
 	FR BND X163
 	LO BND X163 0
 	UP BND X163 1
 	FR BND X164
 	LO BND X164 0
 	UP BND X164 1
 	FR BND X165
 	LO BND X165 0
 	UP BND X165 1
 	FR BND X166
 	LO BND X166 0
 	UP BND X166 1
 	FR BND X167
 	LO BND X167 0
 	UP BND X167 1
 	FR BND X168
 	LO BND X168 0
 	UP BND X168 1
 	FR BND X169
 	LO BND X169 0
 	UP BND X169 1
 	FR BND X170
 	LO BND X170 0
 	UP BND X170 1
 	FR BND X171
 	LO BND X171 0
 	UP BND X171 1
 	FR BND X172
 	LO BND X172 0
 	UP BND X172 1
 	FR BND X173
 	LO BND X173 0
 	UP BND X173 1
 	FR BND X174
 	LO BND X174 0
 	UP BND X174 1
 	FR BND X175
 	LO BND X175 0
 	UP BND X175 1
 	FR BND X176
 	LO BND X176 0
 	UP BND X176 1
 	FR BND X177
 	LO BND X177 0
 	UP BND X177 1
 	FR BND X178
 	LO BND X178 0
 	UP BND X178 1
 	FR BND X179
 	LO BND X179 0
 	UP BND X179 1
 	FR BND X180
 	LO BND X180 0
 	UP BND X180 1
 	FR BND X181
 	LO BND X181 0
 	UP BND X181 1
 	FR BND X182
 	LO BND X182 0
 	UP BND X182 1
 	FR BND X183
 	LO BND X183 0
 	UP BND X183 1
 	FR BND X184
 	LO BND X184 0
 	UP BND X184 1
 	FR BND X185
 	LO BND X185 0
 	UP BND X185 1
 	FR BND X186
 	LO BND X186 0
 	UP BND X186 1
 	FR BND X187
 	LO BND X187 0
 	UP BND X187 1
 	FR BND X188
 	LO BND X188 0
 	UP BND X188 1
 	FR BND X189
 	LO BND X189 0
 	UP BND X189 1
 	FR BND X190
 	LO BND X190 0
 	UP BND X190 1
 	FR BND X191
 	LO BND X191 0
 	UP BND X191 1
 	FR BND X192
 	LO BND X192 0
 	UP BND X192 1
 	FR BND X193
 	LO BND X193 0
 	UP BND X193 1
 	FR BND X194
 	LO BND X194 0
 	UP BND X194 1
 	FR BND X195
 	LO BND X195 0
 	UP BND X195 1
 	FR BND X196
 	LO BND X196 0
 	UP BND X196 1
 	FR BND X197
 	LO BND X197 0
 	UP BND X197 1
 	FR BND X198
 	LO BND X198 0
 	UP BND X198 1
 	FR BND X199
 	LO BND X199 0
 	UP BND X199 1
 	FR BND X200
 	LO BND X200 0
 	UP BND X200 1
 	FR BND X201
 	LO BND X201 0
 	UP BND X201 1
 	FR BND X202
 	LO BND X202 0
 	UP BND X202 1
 	FR BND X203
 	LO BND X203 0
 	UP BND X203 1
 	FR BND X204
 	LO BND X204 0
 	UP BND X204 1
 	FR BND X205
 	LO BND X205 0
 	UP BND X205 1
 	FR BND X206
 	LO BND X206 0
 	UP BND X206 1
 	FR BND X207
 	LO BND X207 0
 	UP BND X207 1
 	FR BND X208
 	LO BND X208 0
 	UP BND X208 1
 	FR BND X209
 	LO BND X209 0
 	UP BND X209 1
 	FR BND X210
 	LO BND X210 0
 	UP BND X210 1
 	FR BND X211
 	LO BND X211 0
 	UP BND X211 1
 	FR BND X212
 	LO BND X212 0
 	UP BND X212 1
 	FR BND X213
 	LO BND X213 0
 	UP BND X213 1
 	FR BND X214
 	LO BND X214 0
 	UP BND X214 1
 	FR BND X215
 	LO BND X215 0
 	UP BND X215 1
 	FR BND X216
 	LO BND X216 0
 	UP BND X216 1
 	FR BND X217
 	LO BND X217 0
 	UP BND X217 1
 	FR BND X218
 	LO BND X218 0
 	UP BND X218 1
 	FR BND X219
 	LO BND X219 0
 	UP BND X219 1
 	FR BND X220
 	LO BND X220 0
 	UP BND X220 1
 	FR BND X221
 	LO BND X221 0
 	UP BND X221 1
 	FR BND X222
 	LO BND X222 0
 	UP BND X222 1
 	FR BND X223
 	LO BND X223 0
 	UP BND X223 1
 	FR BND X224
 	LO BND X224 0
 	UP BND X224 1
 	FR BND X225
 	LO BND X225 0
 	UP BND X225 1
 	FR BND X226
 	LO BND X226 0
 	UP BND X226 1
 	FR BND X227
 	LO BND X227 0
 	UP BND X227 1
 	FR BND X228
 	LO BND X228 0
 	UP BND X228 1
 	FR BND X229
 	LO BND X229 0
 	UP BND X229 1
 	FR BND X230
 	LO BND X230 0
 	UP BND X230 1
 	FR BND X231
 	LO BND X231 0
 	UP BND X231 1
 	FR BND X232
 	LO BND X232 0
 	UP BND X232 1
 	FR BND X233
 	LO BND X233 0
 	UP BND X233 1
 	FR BND X234
 	LO BND X234 0
 	UP BND X234 1
 	FR BND X235
 	LO BND X235 0
 	UP BND X235 1
 	FR BND X236
 	LO BND X236 0
 	UP BND X236 1
 	FR BND X237
 	LO BND X237 0
 	UP BND X237 1
 	FR BND X238
 	LO BND X238 0
 	UP BND X238 1
 	FR BND X239
 	LO BND X239 0
 	UP BND X239 1
 	FR BND X240
 	LO BND X240 0
 	UP BND X240 1
 	FR BND X241
 	LO BND X241 0
 	UP BND X241 1
 	FR BND X242
 	LO BND X242 0
 	UP BND X242 1
 	FR BND X243
 	LO BND X243 0
 	UP BND X243 1
 	FR BND X244
 	LO BND X244 0
 	UP BND X244 1
 	FR BND X245
 	LO BND X245 0
 	UP BND X245 1
 	FR BND X246
 	LO BND X246 0
 	UP BND X246 1
 	FR BND X247
 	LO BND X247 0
 	UP BND X247 1
 	FR BND X248
 	LO BND X248 0
 	UP BND X248 1
 	FR BND X249
 	LO BND X249 0
 	UP BND X249 1
 	FR BND X250
 	LO BND X250 0
 	UP BND X250 1
 	FR BND X251
 	LO BND X251 0
 	UP BND X251 1
 	FR BND X252
 	LO BND X252 0
 	UP BND X252 1
 	FR BND X253
 	LO BND X253 0
 	UP BND X253 1
ENDATA
