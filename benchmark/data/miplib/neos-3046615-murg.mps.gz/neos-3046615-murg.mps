* MIPLIB 2017 benchmark v2; LP relaxation (integrality removed).
* Source: https://miplib.zib.de/downloads/benchmark.zip ; retrieved 2026-09-21
* Instance: neos-3046615-murg ; Gleixner et al. (2021), doi:10.1007/s12532-020-00194-3
* Bounds and coefficients preserved; rows/variables renamed; objective minimized.
* Original compressed SHA256: 07d98d3032b201c023a7628a75974093c945987119a19803bcc69f0476956e19
NAME neos-3046615-murg
ROWS
 N OBJ
 E R0
 E R1
 E R2
 E R3
 E R4
 E R5
 E R6
 E R7
 E R8
 E R9
 E R10
 E R11
 E R12
 E R13
 E R14
 E R15
 E R16
 E R17
 E R18
 E R19
 E R20
 E R21
 E R22
 E R23
 E R24
 E R25
 E R26
 E R27
 E R28
 E R29
 E R30
 E R31
 E R32
 E R33
 E R34
 E R35
 E R36
 E R37
 E R38
 E R39
 E R40
 E R41
 E R42
 E R43
 E R44
 E R45
 E R46
 E R47
 E R48
 E R49
 E R50
 E R51
 E R52
 E R53
 E R54
 E R55
 E R56
 E R57
 E R58
 E R59
 E R60
 E R61
 E R62
 E R63
 E R64
 E R65
 E R66
 E R67
 E R68
 E R69
 E R70
 E R71
 E R72
 E R73
 E R74
 E R75
 E R76
 E R77
 E R78
 E R79
 E R80
 E R81
 E R82
 E R83
 E R84
 E R85
 E R86
 E R87
 E R88
 E R89
 E R90
 E R91
 E R92
 E R93
 E R94
 E R95
 E R96
 E R97
 E R98
 E R99
 E R100
 E R101
 E R102
 E R103
 E R104
 E R105
 E R106
 E R107
 E R108
 E R109
 E R110
 E R111
 E R112
 E R113
 E R114
 E R115
 E R116
 E R117
 E R118
 E R119
 E R120
 E R121
 E R122
 E R123
 E R124
 E R125
 E R126
 E R127
 E R128
 E R129
 E R130
 E R131
 E R132
 E R133
 E R134
 E R135
 E R136
 E R137
 E R138
 E R139
 E R140
 E R141
 E R142
 E R143
 E R144
 E R145
 E R146
 E R147
 E R148
 E R149
 E R150
 E R151
 E R152
 E R153
 E R154
 E R155
 E R156
 E R157
 E R158
 E R159
 E R160
 E R161
 E R162
 E R163
 E R164
 E R165
 E R166
 E R167
 E R168
 E R169
 E R170
 E R171
 E R172
 E R173
 E R174
 E R175
 E R176
 E R177
 E R178
 E R179
 E R180
 E R181
 E R182
 E R183
 E R184
 E R185
 E R186
 E R187
 E R188
 E R189
 E R190
 E R191
 E R192
 E R193
 E R194
 E R195
 E R196
 E R197
 E R198
 E R199
 E R200
 E R201
 E R202
 E R203
 E R204
 E R205
 E R206
 E R207
 E R208
 E R209
 E R210
 E R211
 E R212
 E R213
 E R214
 E R215
 E R216
 E R217
 E R218
 E R219
 E R220
 E R221
 E R222
 E R223
 E R224
 E R225
 E R226
 E R227
 E R228
 E R229
 E R230
 E R231
 E R232
 E R233
 E R234
 E R235
 E R236
 E R237
 E R238
 E R239
 G R240
 G R241
 G R242
 G R243
 G R244
 G R245
 G R246
 G R247
 G R248
 G R249
 G R250
 G R251
 G R252
 G R253
 G R254
 G R255
 G R256
 G R257
 G R258
 G R259
 G R260
 G R261
 G R262
 G R263
 G R264
 G R265
 G R266
 G R267
 G R268
 G R269
 G R270
 G R271
 G R272
 G R273
 G R274
 G R275
 G R276
 G R277
 G R278
 G R279
 G R280
 G R281
 G R282
 G R283
 G R284
 G R285
 G R286
 G R287
 G R288
 G R289
 G R290
 G R291
 G R292
 G R293
 G R294
 G R295
 G R296
 G R297
 G R298
 G R299
 G R300
 G R301
 G R302
 G R303
 G R304
 G R305
 G R306
 G R307
 G R308
 G R309
 G R310
 G R311
 G R312
 G R313
 G R314
 G R315
 G R316
 G R317
 G R318
 G R319
 G R320
 G R321
 G R322
 G R323
 G R324
 G R325
 G R326
 G R327
 G R328
 G R329
 G R330
 G R331
 G R332
 G R333
 G R334
 G R335
 G R336
 G R337
 G R338
 G R339
 G R340
 G R341
 G R342
 G R343
 G R344
 G R345
 G R346
 G R347
 G R348
 G R349
 G R350
 G R351
 G R352
 G R353
 G R354
 G R355
 G R356
 G R357
 G R358
 G R359
 G R360
 G R361
 G R362
 G R363
 G R364
 G R365
 G R366
 G R367
 G R368
 G R369
 G R370
 G R371
 G R372
 G R373
 G R374
 G R375
 G R376
 G R377
 G R378
 G R379
 G R380
 G R381
 G R382
 G R383
 G R384
 G R385
 G R386
 G R387
 G R388
 G R389
 G R390
 G R391
 G R392
 G R393
 G R394
 G R395
 G R396
 G R397
 G R398
 G R399
 G R400
 G R401
 G R402
 G R403
 G R404
 G R405
 G R406
 G R407
 G R408
 G R409
 G R410
 G R411
 G R412
 G R413
 G R414
 G R415
 G R416
 G R417
 G R418
 G R419
 G R420
 G R421
 G R422
 G R423
 G R424
 G R425
 G R426
 G R427
 G R428
 G R429
 G R430
 G R431
 G R432
 G R433
 G R434
 G R435
 G R436
 G R437
 G R438
 G R439
 G R440
 G R441
 G R442
 G R443
 G R444
 G R445
 G R446
 G R447
 G R448
 G R449
 G R450
 G R451
 G R452
 G R453
 G R454
 G R455
 G R456
 G R457
 G R458
 G R459
 G R460
 G R461
 G R462
 G R463
 G R464
 G R465
 G R466
 G R467
 G R468
 G R469
 G R470
 G R471
 G R472
 G R473
 G R474
 G R475
 G R476
 G R477
 G R478
 G R479
 L R480
 L R481
 L R482
 L R483
 L R484
 L R485
 L R486
 L R487
 L R488
 L R489
 L R490
 L R491
 L R492
 L R493
 L R494
 L R495
 L R496
 L R497
COLUMNS
    X0                   OBJ 0
    X0                   R480 -1
    X0                   R497 1
    X1                   OBJ 0
    X1                   R481 -1
    X1                   R497 1
    X2                   OBJ 0
    X2                   R482 -1
    X2                   R497 1
    X3                   OBJ 0
    X3                   R483 -1
    X3                   R497 1
    X4                   OBJ 0
    X4                   R484 -1
    X4                   R497 1
    X5                   OBJ 0
    X5                   R485 -1
    X5                   R497 1
    X6                   OBJ 0
    X6                   R486 -1
    X6                   R497 1
    X7                   OBJ 0
    X7                   R487 -1
    X7                   R497 1
    X8                   OBJ 0
    X8                   R488 -1
    X8                   R497 1
    X9                   OBJ 0
    X9                   R489 -1
    X9                   R497 1
    X10                  OBJ 0
    X10                  R490 -1
    X10                  R497 1
    X11                  OBJ 0
    X11                  R491 -1
    X11                  R497 1
    X12                  OBJ 0
    X12                  R492 -1
    X12                  R497 1
    X13                  OBJ 0
    X13                  R493 -1
    X13                  R497 1
    X14                  OBJ 0
    X14                  R494 -1
    X14                  R497 1
    X15                  OBJ 0
    X15                  R495 -1
    X15                  R497 1
    X16                  OBJ 1
    X16                  R497 -1
    X17                  OBJ 1
    X17                  R496 -1
    X18                  OBJ 0
    X18                  R0 1
    X18                  R15 1
    X18                  R240 10000
    X19                  OBJ 0
    X19                  R1 1
    X19                  R30 1
    X19                  R241 10000
    X20                  OBJ 0
    X20                  R2 1
    X20                  R45 1
    X20                  R242 10000
    X21                  OBJ 0
    X21                  R3 1
    X21                  R60 1
    X21                  R243 10000
    X22                  OBJ 0
    X22                  R4 1
    X22                  R75 1
    X22                  R244 10000
    X23                  OBJ 0
    X23                  R5 1
    X23                  R90 1
    X23                  R245 10000
    X24                  OBJ 0
    X24                  R6 1
    X24                  R105 1
    X24                  R246 10000
    X25                  OBJ 0
    X25                  R7 1
    X25                  R120 1
    X25                  R247 10000
    X26                  OBJ 0
    X26                  R8 1
    X26                  R135 1
    X26                  R248 10000
    X27                  OBJ 0
    X27                  R9 1
    X27                  R150 1
    X27                  R249 10000
    X28                  OBJ 0
    X28                  R10 1
    X28                  R165 1
    X28                  R250 10000
    X29                  OBJ 0
    X29                  R11 1
    X29                  R180 1
    X29                  R251 10000
    X30                  OBJ 0
    X30                  R12 1
    X30                  R195 1
    X30                  R252 10000
    X31                  OBJ 0
    X31                  R13 1
    X31                  R210 1
    X31                  R253 10000
    X32                  OBJ 0
    X32                  R14 1
    X32                  R225 1
    X32                  R254 10000
    X33                  OBJ 0
    X33                  R0 1
    X33                  R15 1
    X33                  R255 10000
    X34                  OBJ 0
    X34                  R16 1
    X34                  R31 1
    X34                  R256 10000
    X35                  OBJ 0
    X35                  R17 1
    X35                  R46 1
    X35                  R257 10000
    X36                  OBJ 0
    X36                  R18 1
    X36                  R61 1
    X36                  R258 10000
    X37                  OBJ 0
    X37                  R19 1
    X37                  R76 1
    X37                  R259 10000
    X38                  OBJ 0
    X38                  R20 1
    X38                  R91 1
    X38                  R260 10000
    X39                  OBJ 0
    X39                  R21 1
    X39                  R106 1
    X39                  R261 10000
    X40                  OBJ 0
    X40                  R22 1
    X40                  R121 1
    X40                  R262 10000
    X41                  OBJ 0
    X41                  R23 1
    X41                  R136 1
    X41                  R263 10000
    X42                  OBJ 0
    X42                  R24 1
    X42                  R151 1
    X42                  R264 10000
    X43                  OBJ 0
    X43                  R25 1
    X43                  R166 1
    X43                  R265 10000
    X44                  OBJ 0
    X44                  R26 1
    X44                  R181 1
    X44                  R266 10000
    X45                  OBJ 0
    X45                  R27 1
    X45                  R196 1
    X45                  R267 10000
    X46                  OBJ 0
    X46                  R28 1
    X46                  R211 1
    X46                  R268 10000
    X47                  OBJ 0
    X47                  R29 1
    X47                  R226 1
    X47                  R269 10000
    X48                  OBJ 0
    X48                  R1 1
    X48                  R30 1
    X48                  R270 10000
    X49                  OBJ 0
    X49                  R16 1
    X49                  R31 1
    X49                  R271 10000
    X50                  OBJ 0
    X50                  R32 1
    X50                  R47 1
    X50                  R272 10000
    X51                  OBJ 0
    X51                  R33 1
    X51                  R62 1
    X51                  R273 10000
    X52                  OBJ 0
    X52                  R34 1
    X52                  R77 1
    X52                  R274 10000
    X53                  OBJ 0
    X53                  R35 1
    X53                  R92 1
    X53                  R275 10000
    X54                  OBJ 0
    X54                  R36 1
    X54                  R107 1
    X54                  R276 10000
    X55                  OBJ 0
    X55                  R37 1
    X55                  R122 1
    X55                  R277 10000
    X56                  OBJ 0
    X56                  R38 1
    X56                  R137 1
    X56                  R278 10000
    X57                  OBJ 0
    X57                  R39 1
    X57                  R152 1
    X57                  R279 10000
    X58                  OBJ 0
    X58                  R40 1
    X58                  R167 1
    X58                  R280 10000
    X59                  OBJ 0
    X59                  R41 1
    X59                  R182 1
    X59                  R281 10000
    X60                  OBJ 0
    X60                  R42 1
    X60                  R197 1
    X60                  R282 10000
    X61                  OBJ 0
    X61                  R43 1
    X61                  R212 1
    X61                  R283 10000
    X62                  OBJ 0
    X62                  R44 1
    X62                  R227 1
    X62                  R284 10000
    X63                  OBJ 0
    X63                  R2 1
    X63                  R45 1
    X63                  R285 10000
    X64                  OBJ 0
    X64                  R17 1
    X64                  R46 1
    X64                  R286 10000
    X65                  OBJ 0
    X65                  R32 1
    X65                  R47 1
    X65                  R287 10000
    X66                  OBJ 0
    X66                  R48 1
    X66                  R63 1
    X66                  R288 10000
    X67                  OBJ 0
    X67                  R49 1
    X67                  R78 1
    X67                  R289 10000
    X68                  OBJ 0
    X68                  R50 1
    X68                  R93 1
    X68                  R290 10000
    X69                  OBJ 0
    X69                  R51 1
    X69                  R108 1
    X69                  R291 10000
    X70                  OBJ 0
    X70                  R52 1
    X70                  R123 1
    X70                  R292 10000
    X71                  OBJ 0
    X71                  R53 1
    X71                  R138 1
    X71                  R293 10000
    X72                  OBJ 0
    X72                  R54 1
    X72                  R153 1
    X72                  R294 10000
    X73                  OBJ 0
    X73                  R55 1
    X73                  R168 1
    X73                  R295 10000
    X74                  OBJ 0
    X74                  R56 1
    X74                  R183 1
    X74                  R296 10000
    X75                  OBJ 0
    X75                  R57 1
    X75                  R198 1
    X75                  R297 10000
    X76                  OBJ 0
    X76                  R58 1
    X76                  R213 1
    X76                  R298 10000
    X77                  OBJ 0
    X77                  R59 1
    X77                  R228 1
    X77                  R299 10000
    X78                  OBJ 0
    X78                  R3 1
    X78                  R60 1
    X78                  R300 10000
    X79                  OBJ 0
    X79                  R18 1
    X79                  R61 1
    X79                  R301 10000
    X80                  OBJ 0
    X80                  R33 1
    X80                  R62 1
    X80                  R302 10000
    X81                  OBJ 0
    X81                  R48 1
    X81                  R63 1
    X81                  R303 10000
    X82                  OBJ 0
    X82                  R64 1
    X82                  R79 1
    X82                  R304 10000
    X83                  OBJ 0
    X83                  R65 1
    X83                  R94 1
    X83                  R305 10000
    X84                  OBJ 0
    X84                  R66 1
    X84                  R109 1
    X84                  R306 10000
    X85                  OBJ 0
    X85                  R67 1
    X85                  R124 1
    X85                  R307 10000
    X86                  OBJ 0
    X86                  R68 1
    X86                  R139 1
    X86                  R308 10000
    X87                  OBJ 0
    X87                  R69 1
    X87                  R154 1
    X87                  R309 10000
    X88                  OBJ 0
    X88                  R70 1
    X88                  R169 1
    X88                  R310 10000
    X89                  OBJ 0
    X89                  R71 1
    X89                  R184 1
    X89                  R311 10000
    X90                  OBJ 0
    X90                  R72 1
    X90                  R199 1
    X90                  R312 10000
    X91                  OBJ 0
    X91                  R73 1
    X91                  R214 1
    X91                  R313 10000
    X92                  OBJ 0
    X92                  R74 1
    X92                  R229 1
    X92                  R314 10000
    X93                  OBJ 0
    X93                  R4 1
    X93                  R75 1
    X93                  R315 10000
    X94                  OBJ 0
    X94                  R19 1
    X94                  R76 1
    X94                  R316 10000
    X95                  OBJ 0
    X95                  R34 1
    X95                  R77 1
    X95                  R317 10000
    X96                  OBJ 0
    X96                  R49 1
    X96                  R78 1
    X96                  R318 10000
    X97                  OBJ 0
    X97                  R64 1
    X97                  R79 1
    X97                  R319 10000
    X98                  OBJ 0
    X98                  R80 1
    X98                  R95 1
    X98                  R320 10000
    X99                  OBJ 0
    X99                  R81 1
    X99                  R110 1
    X99                  R321 10000
    X100                 OBJ 0
    X100                 R82 1
    X100                 R125 1
    X100                 R322 10000
    X101                 OBJ 0
    X101                 R83 1
    X101                 R140 1
    X101                 R323 10000
    X102                 OBJ 0
    X102                 R84 1
    X102                 R155 1
    X102                 R324 10000
    X103                 OBJ 0
    X103                 R85 1
    X103                 R170 1
    X103                 R325 10000
    X104                 OBJ 0
    X104                 R86 1
    X104                 R185 1
    X104                 R326 10000
    X105                 OBJ 0
    X105                 R87 1
    X105                 R200 1
    X105                 R327 10000
    X106                 OBJ 0
    X106                 R88 1
    X106                 R215 1
    X106                 R328 10000
    X107                 OBJ 0
    X107                 R89 1
    X107                 R230 1
    X107                 R329 10000
    X108                 OBJ 0
    X108                 R5 1
    X108                 R90 1
    X108                 R330 10000
    X109                 OBJ 0
    X109                 R20 1
    X109                 R91 1
    X109                 R331 10000
    X110                 OBJ 0
    X110                 R35 1
    X110                 R92 1
    X110                 R332 10000
    X111                 OBJ 0
    X111                 R50 1
    X111                 R93 1
    X111                 R333 10000
    X112                 OBJ 0
    X112                 R65 1
    X112                 R94 1
    X112                 R334 10000
    X113                 OBJ 0
    X113                 R80 1
    X113                 R95 1
    X113                 R335 10000
    X114                 OBJ 0
    X114                 R96 1
    X114                 R111 1
    X114                 R336 10000
    X115                 OBJ 0
    X115                 R97 1
    X115                 R126 1
    X115                 R337 10000
    X116                 OBJ 0
    X116                 R98 1
    X116                 R141 1
    X116                 R338 10000
    X117                 OBJ 0
    X117                 R99 1
    X117                 R156 1
    X117                 R339 10000
    X118                 OBJ 0
    X118                 R100 1
    X118                 R171 1
    X118                 R340 10000
    X119                 OBJ 0
    X119                 R101 1
    X119                 R186 1
    X119                 R341 10000
    X120                 OBJ 0
    X120                 R102 1
    X120                 R201 1
    X120                 R342 10000
    X121                 OBJ 0
    X121                 R103 1
    X121                 R216 1
    X121                 R343 10000
    X122                 OBJ 0
    X122                 R104 1
    X122                 R231 1
    X122                 R344 10000
    X123                 OBJ 0
    X123                 R6 1
    X123                 R105 1
    X123                 R345 10000
    X124                 OBJ 0
    X124                 R21 1
    X124                 R106 1
    X124                 R346 10000
    X125                 OBJ 0
    X125                 R36 1
    X125                 R107 1
    X125                 R347 10000
    X126                 OBJ 0
    X126                 R51 1
    X126                 R108 1
    X126                 R348 10000
    X127                 OBJ 0
    X127                 R66 1
    X127                 R109 1
    X127                 R349 10000
    X128                 OBJ 0
    X128                 R81 1
    X128                 R110 1
    X128                 R350 10000
    X129                 OBJ 0
    X129                 R96 1
    X129                 R111 1
    X129                 R351 10000
    X130                 OBJ 0
    X130                 R112 1
    X130                 R127 1
    X130                 R352 10000
    X131                 OBJ 0
    X131                 R113 1
    X131                 R142 1
    X131                 R353 10000
    X132                 OBJ 0
    X132                 R114 1
    X132                 R157 1
    X132                 R354 10000
    X133                 OBJ 0
    X133                 R115 1
    X133                 R172 1
    X133                 R355 10000
    X134                 OBJ 0
    X134                 R116 1
    X134                 R187 1
    X134                 R356 10000
    X135                 OBJ 0
    X135                 R117 1
    X135                 R202 1
    X135                 R357 10000
    X136                 OBJ 0
    X136                 R118 1
    X136                 R217 1
    X136                 R358 10000
    X137                 OBJ 0
    X137                 R119 1
    X137                 R232 1
    X137                 R359 10000
    X138                 OBJ 0
    X138                 R7 1
    X138                 R120 1
    X138                 R360 10000
    X139                 OBJ 0
    X139                 R22 1
    X139                 R121 1
    X139                 R361 10000
    X140                 OBJ 0
    X140                 R37 1
    X140                 R122 1
    X140                 R362 10000
    X141                 OBJ 0
    X141                 R52 1
    X141                 R123 1
    X141                 R363 10000
    X142                 OBJ 0
    X142                 R67 1
    X142                 R124 1
    X142                 R364 10000
    X143                 OBJ 0
    X143                 R82 1
    X143                 R125 1
    X143                 R365 10000
    X144                 OBJ 0
    X144                 R97 1
    X144                 R126 1
    X144                 R366 10000
    X145                 OBJ 0
    X145                 R112 1
    X145                 R127 1
    X145                 R367 10000
    X146                 OBJ 0
    X146                 R128 1
    X146                 R143 1
    X146                 R368 10000
    X147                 OBJ 0
    X147                 R129 1
    X147                 R158 1
    X147                 R369 10000
    X148                 OBJ 0
    X148                 R130 1
    X148                 R173 1
    X148                 R370 10000
    X149                 OBJ 0
    X149                 R131 1
    X149                 R188 1
    X149                 R371 10000
    X150                 OBJ 0
    X150                 R132 1
    X150                 R203 1
    X150                 R372 10000
    X151                 OBJ 0
    X151                 R133 1
    X151                 R218 1
    X151                 R373 10000
    X152                 OBJ 0
    X152                 R134 1
    X152                 R233 1
    X152                 R374 10000
    X153                 OBJ 0
    X153                 R8 1
    X153                 R135 1
    X153                 R375 10000
    X154                 OBJ 0
    X154                 R23 1
    X154                 R136 1
    X154                 R376 10000
    X155                 OBJ 0
    X155                 R38 1
    X155                 R137 1
    X155                 R377 10000
    X156                 OBJ 0
    X156                 R53 1
    X156                 R138 1
    X156                 R378 10000
    X157                 OBJ 0
    X157                 R68 1
    X157                 R139 1
    X157                 R379 10000
    X158                 OBJ 0
    X158                 R83 1
    X158                 R140 1
    X158                 R380 10000
    X159                 OBJ 0
    X159                 R98 1
    X159                 R141 1
    X159                 R381 10000
    X160                 OBJ 0
    X160                 R113 1
    X160                 R142 1
    X160                 R382 10000
    X161                 OBJ 0
    X161                 R128 1
    X161                 R143 1
    X161                 R383 10000
    X162                 OBJ 0
    X162                 R144 1
    X162                 R159 1
    X162                 R384 10000
    X163                 OBJ 0
    X163                 R145 1
    X163                 R174 1
    X163                 R385 10000
    X164                 OBJ 0
    X164                 R146 1
    X164                 R189 1
    X164                 R386 10000
    X165                 OBJ 0
    X165                 R147 1
    X165                 R204 1
    X165                 R387 10000
    X166                 OBJ 0
    X166                 R148 1
    X166                 R219 1
    X166                 R388 10000
    X167                 OBJ 0
    X167                 R149 1
    X167                 R234 1
    X167                 R389 10000
    X168                 OBJ 0
    X168                 R9 1
    X168                 R150 1
    X168                 R390 10000
    X169                 OBJ 0
    X169                 R24 1
    X169                 R151 1
    X169                 R391 10000
    X170                 OBJ 0
    X170                 R39 1
    X170                 R152 1
    X170                 R392 10000
    X171                 OBJ 0
    X171                 R54 1
    X171                 R153 1
    X171                 R393 10000
    X172                 OBJ 0
    X172                 R69 1
    X172                 R154 1
    X172                 R394 10000
    X173                 OBJ 0
    X173                 R84 1
    X173                 R155 1
    X173                 R395 10000
    X174                 OBJ 0
    X174                 R99 1
    X174                 R156 1
    X174                 R396 10000
    X175                 OBJ 0
    X175                 R114 1
    X175                 R157 1
    X175                 R397 10000
    X176                 OBJ 0
    X176                 R129 1
    X176                 R158 1
    X176                 R398 10000
    X177                 OBJ 0
    X177                 R144 1
    X177                 R159 1
    X177                 R399 10000
    X178                 OBJ 0
    X178                 R160 1
    X178                 R175 1
    X178                 R400 10000
    X179                 OBJ 0
    X179                 R161 1
    X179                 R190 1
    X179                 R401 10000
    X180                 OBJ 0
    X180                 R162 1
    X180                 R205 1
    X180                 R402 10000
    X181                 OBJ 0
    X181                 R163 1
    X181                 R220 1
    X181                 R403 10000
    X182                 OBJ 0
    X182                 R164 1
    X182                 R235 1
    X182                 R404 10000
    X183                 OBJ 0
    X183                 R10 1
    X183                 R165 1
    X183                 R405 10000
    X184                 OBJ 0
    X184                 R25 1
    X184                 R166 1
    X184                 R406 10000
    X185                 OBJ 0
    X185                 R40 1
    X185                 R167 1
    X185                 R407 10000
    X186                 OBJ 0
    X186                 R55 1
    X186                 R168 1
    X186                 R408 10000
    X187                 OBJ 0
    X187                 R70 1
    X187                 R169 1
    X187                 R409 10000
    X188                 OBJ 0
    X188                 R85 1
    X188                 R170 1
    X188                 R410 10000
    X189                 OBJ 0
    X189                 R100 1
    X189                 R171 1
    X189                 R411 10000
    X190                 OBJ 0
    X190                 R115 1
    X190                 R172 1
    X190                 R412 10000
    X191                 OBJ 0
    X191                 R130 1
    X191                 R173 1
    X191                 R413 10000
    X192                 OBJ 0
    X192                 R145 1
    X192                 R174 1
    X192                 R414 10000
    X193                 OBJ 0
    X193                 R160 1
    X193                 R175 1
    X193                 R415 10000
    X194                 OBJ 0
    X194                 R176 1
    X194                 R191 1
    X194                 R416 10000
    X195                 OBJ 0
    X195                 R177 1
    X195                 R206 1
    X195                 R417 10000
    X196                 OBJ 0
    X196                 R178 1
    X196                 R221 1
    X196                 R418 10000
    X197                 OBJ 0
    X197                 R179 1
    X197                 R236 1
    X197                 R419 10000
    X198                 OBJ 0
    X198                 R11 1
    X198                 R180 1
    X198                 R420 10000
    X199                 OBJ 0
    X199                 R26 1
    X199                 R181 1
    X199                 R421 10000
    X200                 OBJ 0
    X200                 R41 1
    X200                 R182 1
    X200                 R422 10000
    X201                 OBJ 0
    X201                 R56 1
    X201                 R183 1
    X201                 R423 10000
    X202                 OBJ 0
    X202                 R71 1
    X202                 R184 1
    X202                 R424 10000
    X203                 OBJ 0
    X203                 R86 1
    X203                 R185 1
    X203                 R425 10000
    X204                 OBJ 0
    X204                 R101 1
    X204                 R186 1
    X204                 R426 10000
    X205                 OBJ 0
    X205                 R116 1
    X205                 R187 1
    X205                 R427 10000
    X206                 OBJ 0
    X206                 R131 1
    X206                 R188 1
    X206                 R428 10000
    X207                 OBJ 0
    X207                 R146 1
    X207                 R189 1
    X207                 R429 10000
    X208                 OBJ 0
    X208                 R161 1
    X208                 R190 1
    X208                 R430 10000
    X209                 OBJ 0
    X209                 R176 1
    X209                 R191 1
    X209                 R431 10000
    X210                 OBJ 0
    X210                 R192 1
    X210                 R207 1
    X210                 R432 10000
    X211                 OBJ 0
    X211                 R193 1
    X211                 R222 1
    X211                 R433 10000
    X212                 OBJ 0
    X212                 R194 1
    X212                 R237 1
    X212                 R434 10000
    X213                 OBJ 0
    X213                 R12 1
    X213                 R195 1
    X213                 R435 10000
    X214                 OBJ 0
    X214                 R27 1
    X214                 R196 1
    X214                 R436 10000
    X215                 OBJ 0
    X215                 R42 1
    X215                 R197 1
    X215                 R437 10000
    X216                 OBJ 0
    X216                 R57 1
    X216                 R198 1
    X216                 R438 10000
    X217                 OBJ 0
    X217                 R72 1
    X217                 R199 1
    X217                 R439 10000
    X218                 OBJ 0
    X218                 R87 1
    X218                 R200 1
    X218                 R440 10000
    X219                 OBJ 0
    X219                 R102 1
    X219                 R201 1
    X219                 R441 10000
    X220                 OBJ 0
    X220                 R117 1
    X220                 R202 1
    X220                 R442 10000
    X221                 OBJ 0
    X221                 R132 1
    X221                 R203 1
    X221                 R443 10000
    X222                 OBJ 0
    X222                 R147 1
    X222                 R204 1
    X222                 R444 10000
    X223                 OBJ 0
    X223                 R162 1
    X223                 R205 1
    X223                 R445 10000
    X224                 OBJ 0
    X224                 R177 1
    X224                 R206 1
    X224                 R446 10000
    X225                 OBJ 0
    X225                 R192 1
    X225                 R207 1
    X225                 R447 10000
    X226                 OBJ 0
    X226                 R208 1
    X226                 R223 1
    X226                 R448 10000
    X227                 OBJ 0
    X227                 R209 1
    X227                 R238 1
    X227                 R449 10000
    X228                 OBJ 0
    X228                 R13 1
    X228                 R210 1
    X228                 R450 10000
    X229                 OBJ 0
    X229                 R28 1
    X229                 R211 1
    X229                 R451 10000
    X230                 OBJ 0
    X230                 R43 1
    X230                 R212 1
    X230                 R452 10000
    X231                 OBJ 0
    X231                 R58 1
    X231                 R213 1
    X231                 R453 10000
    X232                 OBJ 0
    X232                 R73 1
    X232                 R214 1
    X232                 R454 10000
    X233                 OBJ 0
    X233                 R88 1
    X233                 R215 1
    X233                 R455 10000
    X234                 OBJ 0
    X234                 R103 1
    X234                 R216 1
    X234                 R456 10000
    X235                 OBJ 0
    X235                 R118 1
    X235                 R217 1
    X235                 R457 10000
    X236                 OBJ 0
    X236                 R133 1
    X236                 R218 1
    X236                 R458 10000
    X237                 OBJ 0
    X237                 R148 1
    X237                 R219 1
    X237                 R459 10000
    X238                 OBJ 0
    X238                 R163 1
    X238                 R220 1
    X238                 R460 10000
    X239                 OBJ 0
    X239                 R178 1
    X239                 R221 1
    X239                 R461 10000
    X240                 OBJ 0
    X240                 R193 1
    X240                 R222 1
    X240                 R462 10000
    X241                 OBJ 0
    X241                 R208 1
    X241                 R223 1
    X241                 R463 10000
    X242                 OBJ 0
    X242                 R224 1
    X242                 R239 1
    X242                 R464 10000
    X243                 OBJ 0
    X243                 R14 1
    X243                 R225 1
    X243                 R465 10000
    X244                 OBJ 0
    X244                 R29 1
    X244                 R226 1
    X244                 R466 10000
    X245                 OBJ 0
    X245                 R44 1
    X245                 R227 1
    X245                 R467 10000
    X246                 OBJ 0
    X246                 R59 1
    X246                 R228 1
    X246                 R468 10000
    X247                 OBJ 0
    X247                 R74 1
    X247                 R229 1
    X247                 R469 10000
    X248                 OBJ 0
    X248                 R89 1
    X248                 R230 1
    X248                 R470 10000
    X249                 OBJ 0
    X249                 R104 1
    X249                 R231 1
    X249                 R471 10000
    X250                 OBJ 0
    X250                 R119 1
    X250                 R232 1
    X250                 R472 10000
    X251                 OBJ 0
    X251                 R134 1
    X251                 R233 1
    X251                 R473 10000
    X252                 OBJ 0
    X252                 R149 1
    X252                 R234 1
    X252                 R474 10000
    X253                 OBJ 0
    X253                 R164 1
    X253                 R235 1
    X253                 R475 10000
    X254                 OBJ 0
    X254                 R179 1
    X254                 R236 1
    X254                 R476 10000
    X255                 OBJ 0
    X255                 R194 1
    X255                 R237 1
    X255                 R477 10000
    X256                 OBJ 0
    X256                 R209 1
    X256                 R238 1
    X256                 R478 10000
    X257                 OBJ 0
    X257                 R224 1
    X257                 R239 1
    X257                 R479 10000
    X258                 OBJ 0
    X258                 R240 1
    X258                 R241 1
    X258                 R242 1
    X258                 R243 1
    X258                 R244 1
    X258                 R245 1
    X258                 R246 1
    X258                 R247 1
    X258                 R248 1
    X258                 R249 1
    X258                 R250 1
    X258                 R251 1
    X258                 R252 1
    X258                 R253 1
    X258                 R254 1
    X258                 R255 -1
    X258                 R270 -1
    X258                 R285 -1
    X258                 R300 -1
    X258                 R315 -1
    X258                 R330 -1
    X258                 R345 -1
    X258                 R360 -1
    X258                 R375 -1
    X258                 R390 -1
    X258                 R405 -1
    X258                 R420 -1
    X258                 R435 -1
    X258                 R450 -1
    X258                 R465 -1
    X258                 R480 1
    X258                 R496 1
    X259                 OBJ 0
    X259                 R240 -1
    X259                 R255 1
    X259                 R256 1
    X259                 R257 1
    X259                 R258 1
    X259                 R259 1
    X259                 R260 1
    X259                 R261 1
    X259                 R262 1
    X259                 R263 1
    X259                 R264 1
    X259                 R265 1
    X259                 R266 1
    X259                 R267 1
    X259                 R268 1
    X259                 R269 1
    X259                 R271 -1
    X259                 R286 -1
    X259                 R301 -1
    X259                 R316 -1
    X259                 R331 -1
    X259                 R346 -1
    X259                 R361 -1
    X259                 R376 -1
    X259                 R391 -1
    X259                 R406 -1
    X259                 R421 -1
    X259                 R436 -1
    X259                 R451 -1
    X259                 R466 -1
    X259                 R481 1
    X259                 R496 1
    X260                 OBJ 0
    X260                 R241 -1
    X260                 R256 -1
    X260                 R270 1
    X260                 R271 1
    X260                 R272 1
    X260                 R273 1
    X260                 R274 1
    X260                 R275 1
    X260                 R276 1
    X260                 R277 1
    X260                 R278 1
    X260                 R279 1
    X260                 R280 1
    X260                 R281 1
    X260                 R282 1
    X260                 R283 1
    X260                 R284 1
    X260                 R287 -1
    X260                 R302 -1
    X260                 R317 -1
    X260                 R332 -1
    X260                 R347 -1
    X260                 R362 -1
    X260                 R377 -1
    X260                 R392 -1
    X260                 R407 -1
    X260                 R422 -1
    X260                 R437 -1
    X260                 R452 -1
    X260                 R467 -1
    X260                 R482 1
    X260                 R496 1
    X261                 OBJ 0
    X261                 R242 -1
    X261                 R257 -1
    X261                 R272 -1
    X261                 R285 1
    X261                 R286 1
    X261                 R287 1
    X261                 R288 1
    X261                 R289 1
    X261                 R290 1
    X261                 R291 1
    X261                 R292 1
    X261                 R293 1
    X261                 R294 1
    X261                 R295 1
    X261                 R296 1
    X261                 R297 1
    X261                 R298 1
    X261                 R299 1
    X261                 R303 -1
    X261                 R318 -1
    X261                 R333 -1
    X261                 R348 -1
    X261                 R363 -1
    X261                 R378 -1
    X261                 R393 -1
    X261                 R408 -1
    X261                 R423 -1
    X261                 R438 -1
    X261                 R453 -1
    X261                 R468 -1
    X261                 R483 1
    X261                 R496 1
    X262                 OBJ 0
    X262                 R243 -1
    X262                 R258 -1
    X262                 R273 -1
    X262                 R288 -1
    X262                 R300 1
    X262                 R301 1
    X262                 R302 1
    X262                 R303 1
    X262                 R304 1
    X262                 R305 1
    X262                 R306 1
    X262                 R307 1
    X262                 R308 1
    X262                 R309 1
    X262                 R310 1
    X262                 R311 1
    X262                 R312 1
    X262                 R313 1
    X262                 R314 1
    X262                 R319 -1
    X262                 R334 -1
    X262                 R349 -1
    X262                 R364 -1
    X262                 R379 -1
    X262                 R394 -1
    X262                 R409 -1
    X262                 R424 -1
    X262                 R439 -1
    X262                 R454 -1
    X262                 R469 -1
    X262                 R484 1
    X262                 R496 1
    X263                 OBJ 0
    X263                 R244 -1
    X263                 R259 -1
    X263                 R274 -1
    X263                 R289 -1
    X263                 R304 -1
    X263                 R315 1
    X263                 R316 1
    X263                 R317 1
    X263                 R318 1
    X263                 R319 1
    X263                 R320 1
    X263                 R321 1
    X263                 R322 1
    X263                 R323 1
    X263                 R324 1
    X263                 R325 1
    X263                 R326 1
    X263                 R327 1
    X263                 R328 1
    X263                 R329 1
    X263                 R335 -1
    X263                 R350 -1
    X263                 R365 -1
    X263                 R380 -1
    X263                 R395 -1
    X263                 R410 -1
    X263                 R425 -1
    X263                 R440 -1
    X263                 R455 -1
    X263                 R470 -1
    X263                 R485 1
    X263                 R496 1
    X264                 OBJ 0
    X264                 R245 -1
    X264                 R260 -1
    X264                 R275 -1
    X264                 R290 -1
    X264                 R305 -1
    X264                 R320 -1
    X264                 R330 1
    X264                 R331 1
    X264                 R332 1
    X264                 R333 1
    X264                 R334 1
    X264                 R335 1
    X264                 R336 1
    X264                 R337 1
    X264                 R338 1
    X264                 R339 1
    X264                 R340 1
    X264                 R341 1
    X264                 R342 1
    X264                 R343 1
    X264                 R344 1
    X264                 R351 -1
    X264                 R366 -1
    X264                 R381 -1
    X264                 R396 -1
    X264                 R411 -1
    X264                 R426 -1
    X264                 R441 -1
    X264                 R456 -1
    X264                 R471 -1
    X264                 R486 1
    X264                 R496 1
    X265                 OBJ 0
    X265                 R246 -1
    X265                 R261 -1
    X265                 R276 -1
    X265                 R291 -1
    X265                 R306 -1
    X265                 R321 -1
    X265                 R336 -1
    X265                 R345 1
    X265                 R346 1
    X265                 R347 1
    X265                 R348 1
    X265                 R349 1
    X265                 R350 1
    X265                 R351 1
    X265                 R352 1
    X265                 R353 1
    X265                 R354 1
    X265                 R355 1
    X265                 R356 1
    X265                 R357 1
    X265                 R358 1
    X265                 R359 1
    X265                 R367 -1
    X265                 R382 -1
    X265                 R397 -1
    X265                 R412 -1
    X265                 R427 -1
    X265                 R442 -1
    X265                 R457 -1
    X265                 R472 -1
    X265                 R487 1
    X265                 R496 1
    X266                 OBJ 0
    X266                 R247 -1
    X266                 R262 -1
    X266                 R277 -1
    X266                 R292 -1
    X266                 R307 -1
    X266                 R322 -1
    X266                 R337 -1
    X266                 R352 -1
    X266                 R360 1
    X266                 R361 1
    X266                 R362 1
    X266                 R363 1
    X266                 R364 1
    X266                 R365 1
    X266                 R366 1
    X266                 R367 1
    X266                 R368 1
    X266                 R369 1
    X266                 R370 1
    X266                 R371 1
    X266                 R372 1
    X266                 R373 1
    X266                 R374 1
    X266                 R383 -1
    X266                 R398 -1
    X266                 R413 -1
    X266                 R428 -1
    X266                 R443 -1
    X266                 R458 -1
    X266                 R473 -1
    X266                 R488 1
    X266                 R496 1
    X267                 OBJ 0
    X267                 R248 -1
    X267                 R263 -1
    X267                 R278 -1
    X267                 R293 -1
    X267                 R308 -1
    X267                 R323 -1
    X267                 R338 -1
    X267                 R353 -1
    X267                 R368 -1
    X267                 R375 1
    X267                 R376 1
    X267                 R377 1
    X267                 R378 1
    X267                 R379 1
    X267                 R380 1
    X267                 R381 1
    X267                 R382 1
    X267                 R383 1
    X267                 R384 1
    X267                 R385 1
    X267                 R386 1
    X267                 R387 1
    X267                 R388 1
    X267                 R389 1
    X267                 R399 -1
    X267                 R414 -1
    X267                 R429 -1
    X267                 R444 -1
    X267                 R459 -1
    X267                 R474 -1
    X267                 R489 1
    X267                 R496 1
    X268                 OBJ 0
    X268                 R249 -1
    X268                 R264 -1
    X268                 R279 -1
    X268                 R294 -1
    X268                 R309 -1
    X268                 R324 -1
    X268                 R339 -1
    X268                 R354 -1
    X268                 R369 -1
    X268                 R384 -1
    X268                 R390 1
    X268                 R391 1
    X268                 R392 1
    X268                 R393 1
    X268                 R394 1
    X268                 R395 1
    X268                 R396 1
    X268                 R397 1
    X268                 R398 1
    X268                 R399 1
    X268                 R400 1
    X268                 R401 1
    X268                 R402 1
    X268                 R403 1
    X268                 R404 1
    X268                 R415 -1
    X268                 R430 -1
    X268                 R445 -1
    X268                 R460 -1
    X268                 R475 -1
    X268                 R490 1
    X268                 R496 1
    X269                 OBJ 0
    X269                 R250 -1
    X269                 R265 -1
    X269                 R280 -1
    X269                 R295 -1
    X269                 R310 -1
    X269                 R325 -1
    X269                 R340 -1
    X269                 R355 -1
    X269                 R370 -1
    X269                 R385 -1
    X269                 R400 -1
    X269                 R405 1
    X269                 R406 1
    X269                 R407 1
    X269                 R408 1
    X269                 R409 1
    X269                 R410 1
    X269                 R411 1
    X269                 R412 1
    X269                 R413 1
    X269                 R414 1
    X269                 R415 1
    X269                 R416 1
    X269                 R417 1
    X269                 R418 1
    X269                 R419 1
    X269                 R431 -1
    X269                 R446 -1
    X269                 R461 -1
    X269                 R476 -1
    X269                 R491 1
    X269                 R496 1
    X270                 OBJ 0
    X270                 R251 -1
    X270                 R266 -1
    X270                 R281 -1
    X270                 R296 -1
    X270                 R311 -1
    X270                 R326 -1
    X270                 R341 -1
    X270                 R356 -1
    X270                 R371 -1
    X270                 R386 -1
    X270                 R401 -1
    X270                 R416 -1
    X270                 R420 1
    X270                 R421 1
    X270                 R422 1
    X270                 R423 1
    X270                 R424 1
    X270                 R425 1
    X270                 R426 1
    X270                 R427 1
    X270                 R428 1
    X270                 R429 1
    X270                 R430 1
    X270                 R431 1
    X270                 R432 1
    X270                 R433 1
    X270                 R434 1
    X270                 R447 -1
    X270                 R462 -1
    X270                 R477 -1
    X270                 R492 1
    X270                 R496 1
    X271                 OBJ 0
    X271                 R252 -1
    X271                 R267 -1
    X271                 R282 -1
    X271                 R297 -1
    X271                 R312 -1
    X271                 R327 -1
    X271                 R342 -1
    X271                 R357 -1
    X271                 R372 -1
    X271                 R387 -1
    X271                 R402 -1
    X271                 R417 -1
    X271                 R432 -1
    X271                 R435 1
    X271                 R436 1
    X271                 R437 1
    X271                 R438 1
    X271                 R439 1
    X271                 R440 1
    X271                 R441 1
    X271                 R442 1
    X271                 R443 1
    X271                 R444 1
    X271                 R445 1
    X271                 R446 1
    X271                 R447 1
    X271                 R448 1
    X271                 R449 1
    X271                 R463 -1
    X271                 R478 -1
    X271                 R493 1
    X271                 R496 1
    X272                 OBJ 0
    X272                 R253 -1
    X272                 R268 -1
    X272                 R283 -1
    X272                 R298 -1
    X272                 R313 -1
    X272                 R328 -1
    X272                 R343 -1
    X272                 R358 -1
    X272                 R373 -1
    X272                 R388 -1
    X272                 R403 -1
    X272                 R418 -1
    X272                 R433 -1
    X272                 R448 -1
    X272                 R450 1
    X272                 R451 1
    X272                 R452 1
    X272                 R453 1
    X272                 R454 1
    X272                 R455 1
    X272                 R456 1
    X272                 R457 1
    X272                 R458 1
    X272                 R459 1
    X272                 R460 1
    X272                 R461 1
    X272                 R462 1
    X272                 R463 1
    X272                 R464 1
    X272                 R479 -1
    X272                 R494 1
    X272                 R496 1
    X273                 OBJ 0
    X273                 R254 -1
    X273                 R269 -1
    X273                 R284 -1
    X273                 R299 -1
    X273                 R314 -1
    X273                 R329 -1
    X273                 R344 -1
    X273                 R359 -1
    X273                 R374 -1
    X273                 R389 -1
    X273                 R404 -1
    X273                 R419 -1
    X273                 R434 -1
    X273                 R449 -1
    X273                 R464 -1
    X273                 R465 1
    X273                 R466 1
    X273                 R467 1
    X273                 R468 1
    X273                 R469 1
    X273                 R470 1
    X273                 R471 1
    X273                 R472 1
    X273                 R473 1
    X273                 R474 1
    X273                 R475 1
    X273                 R476 1
    X273                 R477 1
    X273                 R478 1
    X273                 R479 1
    X273                 R495 1
    X273                 R496 1
RHS
    RHS                  OBJ -0
    RHS                  R0 1
    RHS                  R1 1
    RHS                  R2 1
    RHS                  R3 1
    RHS                  R4 1
    RHS                  R5 1
    RHS                  R6 1
    RHS                  R7 1
    RHS                  R8 1
    RHS                  R9 1
    RHS                  R10 1
    RHS                  R11 1
    RHS                  R12 1
    RHS                  R13 1
    RHS                  R14 1
    RHS                  R15 1
    RHS                  R16 1
    RHS                  R17 1
    RHS                  R18 1
    RHS                  R19 1
    RHS                  R20 1
    RHS                  R21 1
    RHS                  R22 1
    RHS                  R23 1
    RHS                  R24 1
    RHS                  R25 1
    RHS                  R26 1
    RHS                  R27 1
    RHS                  R28 1
    RHS                  R29 1
    RHS                  R30 1
    RHS                  R31 1
    RHS                  R32 1
    RHS                  R33 1
    RHS                  R34 1
    RHS                  R35 1
    RHS                  R36 1
    RHS                  R37 1
    RHS                  R38 1
    RHS                  R39 1
    RHS                  R40 1
    RHS                  R41 1
    RHS                  R42 1
    RHS                  R43 1
    RHS                  R44 1
    RHS                  R45 1
    RHS                  R46 1
    RHS                  R47 1
    RHS                  R48 1
    RHS                  R49 1
    RHS                  R50 1
    RHS                  R51 1
    RHS                  R52 1
    RHS                  R53 1
    RHS                  R54 1
    RHS                  R55 1
    RHS                  R56 1
    RHS                  R57 1
    RHS                  R58 1
    RHS                  R59 1
    RHS                  R60 1
    RHS                  R61 1
    RHS                  R62 1
    RHS                  R63 1
    RHS                  R64 1
    RHS                  R65 1
    RHS                  R66 1
    RHS                  R67 1
    RHS                  R68 1
    RHS                  R69 1
    RHS                  R70 1
    RHS                  R71 1
    RHS                  R72 1
    RHS                  R73 1
    RHS                  R74 1
    RHS                  R75 1
    RHS                  R76 1
    RHS                  R77 1
    RHS                  R78 1
    RHS                  R79 1
    RHS                  R80 1
    RHS                  R81 1
    RHS                  R82 1
    RHS                  R83 1
    RHS                  R84 1
    RHS                  R85 1
    RHS                  R86 1
    RHS                  R87 1
    RHS                  R88 1
    RHS                  R89 1
    RHS                  R90 1
    RHS                  R91 1
    RHS                  R92 1
    RHS                  R93 1
    RHS                  R94 1
    RHS                  R95 1
    RHS                  R96 1
    RHS                  R97 1
    RHS                  R98 1
    RHS                  R99 1
    RHS                  R100 1
    RHS                  R101 1
    RHS                  R102 1
    RHS                  R103 1
    RHS                  R104 1
    RHS                  R105 1
    RHS                  R106 1
    RHS                  R107 1
    RHS                  R108 1
    RHS                  R109 1
    RHS                  R110 1
    RHS                  R111 1
    RHS                  R112 1
    RHS                  R113 1
    RHS                  R114 1
    RHS                  R115 1
    RHS                  R116 1
    RHS                  R117 1
    RHS                  R118 1
    RHS                  R119 1
    RHS                  R120 1
    RHS                  R121 1
    RHS                  R122 1
    RHS                  R123 1
    RHS                  R124 1
    RHS                  R125 1
    RHS                  R126 1
    RHS                  R127 1
    RHS                  R128 1
    RHS                  R129 1
    RHS                  R130 1
    RHS                  R131 1
    RHS                  R132 1
    RHS                  R133 1
    RHS                  R134 1
    RHS                  R135 1
    RHS                  R136 1
    RHS                  R137 1
    RHS                  R138 1
    RHS                  R139 1
    RHS                  R140 1
    RHS                  R141 1
    RHS                  R142 1
    RHS                  R143 1
    RHS                  R144 1
    RHS                  R145 1
    RHS                  R146 1
    RHS                  R147 1
    RHS                  R148 1
    RHS                  R149 1
    RHS                  R150 1
    RHS                  R151 1
    RHS                  R152 1
    RHS                  R153 1
    RHS                  R154 1
    RHS                  R155 1
    RHS                  R156 1
    RHS                  R157 1
    RHS                  R158 1
    RHS                  R159 1
    RHS                  R160 1
    RHS                  R161 1
    RHS                  R162 1
    RHS                  R163 1
    RHS                  R164 1
    RHS                  R165 1
    RHS                  R166 1
    RHS                  R167 1
    RHS                  R168 1
    RHS                  R169 1
    RHS                  R170 1
    RHS                  R171 1
    RHS                  R172 1
    RHS                  R173 1
    RHS                  R174 1
    RHS                  R175 1
    RHS                  R176 1
    RHS                  R177 1
    RHS                  R178 1
    RHS                  R179 1
    RHS                  R180 1
    RHS                  R181 1
    RHS                  R182 1
    RHS                  R183 1
    RHS                  R184 1
    RHS                  R185 1
    RHS                  R186 1
    RHS                  R187 1
    RHS                  R188 1
    RHS                  R189 1
    RHS                  R190 1
    RHS                  R191 1
    RHS                  R192 1
    RHS                  R193 1
    RHS                  R194 1
    RHS                  R195 1
    RHS                  R196 1
    RHS                  R197 1
    RHS                  R198 1
    RHS                  R199 1
    RHS                  R200 1
    RHS                  R201 1
    RHS                  R202 1
    RHS                  R203 1
    RHS                  R204 1
    RHS                  R205 1
    RHS                  R206 1
    RHS                  R207 1
    RHS                  R208 1
    RHS                  R209 1
    RHS                  R210 1
    RHS                  R211 1
    RHS                  R212 1
    RHS                  R213 1
    RHS                  R214 1
    RHS                  R215 1
    RHS                  R216 1
    RHS                  R217 1
    RHS                  R218 1
    RHS                  R219 1
    RHS                  R220 1
    RHS                  R221 1
    RHS                  R222 1
    RHS                  R223 1
    RHS                  R224 1
    RHS                  R225 1
    RHS                  R226 1
    RHS                  R227 1
    RHS                  R228 1
    RHS                  R229 1
    RHS                  R230 1
    RHS                  R231 1
    RHS                  R232 1
    RHS                  R233 1
    RHS                  R234 1
    RHS                  R235 1
    RHS                  R236 1
    RHS                  R237 1
    RHS                  R238 1
    RHS                  R239 1
    RHS                  R240 12
    RHS                  R241 7
    RHS                  R242 11
    RHS                  R243 14
    RHS                  R244 8
    RHS                  R245 16
    RHS                  R246 14
    RHS                  R247 10
    RHS                  R248 7
    RHS                  R249 10
    RHS                  R250 15
    RHS                  R251 3
    RHS                  R252 10
    RHS                  R253 13
    RHS                  R254 6
    RHS                  R255 11
    RHS                  R256 7
    RHS                  R257 11
    RHS                  R258 14
    RHS                  R259 8
    RHS                  R260 16
    RHS                  R261 14
    RHS                  R262 10
    RHS                  R263 7
    RHS                  R264 10
    RHS                  R265 15
    RHS                  R266 3
    RHS                  R267 10
    RHS                  R268 13
    RHS                  R269 6
    RHS                  R270 11
    RHS                  R271 12
    RHS                  R272 11
    RHS                  R273 14
    RHS                  R274 8
    RHS                  R275 16
    RHS                  R276 14
    RHS                  R277 10
    RHS                  R278 7
    RHS                  R279 10
    RHS                  R280 15
    RHS                  R281 3
    RHS                  R282 10
    RHS                  R283 13
    RHS                  R284 6
    RHS                  R285 11
    RHS                  R286 12
    RHS                  R287 7
    RHS                  R288 14
    RHS                  R289 8
    RHS                  R290 16
    RHS                  R291 14
    RHS                  R292 10
    RHS                  R293 7
    RHS                  R294 10
    RHS                  R295 15
    RHS                  R296 3
    RHS                  R297 10
    RHS                  R298 13
    RHS                  R299 6
    RHS                  R300 11
    RHS                  R301 12
    RHS                  R302 7
    RHS                  R303 11
    RHS                  R304 8
    RHS                  R305 16
    RHS                  R306 14
    RHS                  R307 10
    RHS                  R308 7
    RHS                  R309 10
    RHS                  R310 15
    RHS                  R311 3
    RHS                  R312 10
    RHS                  R313 13
    RHS                  R314 6
    RHS                  R315 11
    RHS                  R316 12
    RHS                  R317 7
    RHS                  R318 11
    RHS                  R319 14
    RHS                  R320 16
    RHS                  R321 14
    RHS                  R322 10
    RHS                  R323 7
    RHS                  R324 10
    RHS                  R325 15
    RHS                  R326 3
    RHS                  R327 10
    RHS                  R328 13
    RHS                  R329 6
    RHS                  R330 11
    RHS                  R331 12
    RHS                  R332 7
    RHS                  R333 11
    RHS                  R334 14
    RHS                  R335 8
    RHS                  R336 14
    RHS                  R337 10
    RHS                  R338 7
    RHS                  R339 10
    RHS                  R340 15
    RHS                  R341 3
    RHS                  R342 10
    RHS                  R343 13
    RHS                  R344 6
    RHS                  R345 11
    RHS                  R346 12
    RHS                  R347 7
    RHS                  R348 11
    RHS                  R349 14
    RHS                  R350 8
    RHS                  R351 16
    RHS                  R352 10
    RHS                  R353 7
    RHS                  R354 10
    RHS                  R355 15
    RHS                  R356 3
    RHS                  R357 10
    RHS                  R358 13
    RHS                  R359 6
    RHS                  R360 11
    RHS                  R361 12
    RHS                  R362 7
    RHS                  R363 11
    RHS                  R364 14
    RHS                  R365 8
    RHS                  R366 16
    RHS                  R367 14
    RHS                  R368 7
    RHS                  R369 10
    RHS                  R370 15
    RHS                  R371 3
    RHS                  R372 10
    RHS                  R373 13
    RHS                  R374 6
    RHS                  R375 11
    RHS                  R376 12
    RHS                  R377 7
    RHS                  R378 11
    RHS                  R379 14
    RHS                  R380 8
    RHS                  R381 16
    RHS                  R382 14
    RHS                  R383 10
    RHS                  R384 10
    RHS                  R385 15
    RHS                  R386 3
    RHS                  R387 10
    RHS                  R388 13
    RHS                  R389 6
    RHS                  R390 11
    RHS                  R391 12
    RHS                  R392 7
    RHS                  R393 11
    RHS                  R394 14
    RHS                  R395 8
    RHS                  R396 16
    RHS                  R397 14
    RHS                  R398 10
    RHS                  R399 7
    RHS                  R400 15
    RHS                  R401 3
    RHS                  R402 10
    RHS                  R403 13
    RHS                  R404 6
    RHS                  R405 11
    RHS                  R406 12
    RHS                  R407 7
    RHS                  R408 11
    RHS                  R409 14
    RHS                  R410 8
    RHS                  R411 16
    RHS                  R412 14
    RHS                  R413 10
    RHS                  R414 7
    RHS                  R415 10
    RHS                  R416 3
    RHS                  R417 10
    RHS                  R418 13
    RHS                  R419 6
    RHS                  R420 11
    RHS                  R421 12
    RHS                  R422 7
    RHS                  R423 11
    RHS                  R424 14
    RHS                  R425 8
    RHS                  R426 16
    RHS                  R427 14
    RHS                  R428 10
    RHS                  R429 7
    RHS                  R430 10
    RHS                  R431 15
    RHS                  R432 10
    RHS                  R433 13
    RHS                  R434 6
    RHS                  R435 11
    RHS                  R436 12
    RHS                  R437 7
    RHS                  R438 11
    RHS                  R439 14
    RHS                  R440 8
    RHS                  R441 16
    RHS                  R442 14
    RHS                  R443 10
    RHS                  R444 7
    RHS                  R445 10
    RHS                  R446 15
    RHS                  R447 3
    RHS                  R448 13
    RHS                  R449 6
    RHS                  R450 11
    RHS                  R451 12
    RHS                  R452 7
    RHS                  R453 11
    RHS                  R454 14
    RHS                  R455 8
    RHS                  R456 16
    RHS                  R457 14
    RHS                  R458 10
    RHS                  R459 7
    RHS                  R460 10
    RHS                  R461 15
    RHS                  R462 3
    RHS                  R463 10
    RHS                  R464 6
    RHS                  R465 11
    RHS                  R466 12
    RHS                  R467 7
    RHS                  R468 11
    RHS                  R469 14
    RHS                  R470 8
    RHS                  R471 16
    RHS                  R472 14
    RHS                  R473 10
    RHS                  R474 7
    RHS                  R475 10
    RHS                  R476 15
    RHS                  R477 3
    RHS                  R478 10
    RHS                  R479 13
    RHS                  R480 22
    RHS                  R481 2
    RHS                  R482 11
    RHS                  R483 46
    RHS                  R484 21
    RHS                  R485 13
    RHS                  R486 45
    RHS                  R487 46
    RHS                  R488 19
    RHS                  R489 69
    RHS                  R490 44
    RHS                  R491 23
    RHS                  R492 32
    RHS                  R493 7
    RHS                  R494 30
    RHS                  R495 16
    RHS                  R496 203
    RHS                  R497 0
BOUNDS
 	FR BND X0
 	LO BND X0 0
 	FR BND X1
 	LO BND X1 0
 	FR BND X2
 	LO BND X2 0
 	FR BND X3
 	LO BND X3 0
 	FR BND X4
 	LO BND X4 0
 	FR BND X5
 	LO BND X5 0
 	FR BND X6
 	LO BND X6 0
 	FR BND X7
 	LO BND X7 0
 	FR BND X8
 	LO BND X8 0
 	FR BND X9
 	LO BND X9 0
 	FR BND X10
 	LO BND X10 0
 	FR BND X11
 	LO BND X11 0
 	FR BND X12
 	LO BND X12 0
 	FR BND X13
 	LO BND X13 0
 	FR BND X14
 	LO BND X14 0
 	FR BND X15
 	LO BND X15 0
 	FR BND X16
 	FR BND X17
 	FR BND X18
 	LO BND X18 0
 	UP BND X18 1
 	FR BND X19
 	LO BND X19 0
 	UP BND X19 1
 	FR BND X20
 	LO BND X20 0
 	UP BND X20 1
 	FR BND X21
 	LO BND X21 0
 	UP BND X21 1
 	FR BND X22
 	LO BND X22 0
 	UP BND X22 1
 	FR BND X23
 	LO BND X23 0
 	UP BND X23 1
 	FR BND X24
 	LO BND X24 0
 	UP BND X24 1
 	FR BND X25
 	LO BND X25 0
 	UP BND X25 1
 	FR BND X26
 	LO BND X26 0
 	UP BND X26 1
 	FR BND X27
 	LO BND X27 0
 	UP BND X27 1
 	FR BND X28
 	LO BND X28 0
 	UP BND X28 1
 	FR BND X29
 	LO BND X29 0
 	UP BND X29 1
 	FR BND X30
 	LO BND X30 0
 	UP BND X30 1
 	FR BND X31
 	LO BND X31 0
 	UP BND X31 1
 	FR BND X32
 	LO BND X32 0
 	UP BND X32 1
 	FR BND X33
 	LO BND X33 0
 	UP BND X33 1
 	FR BND X34
 	LO BND X34 0
 	UP BND X34 1
 	FR BND X35
 	LO BND X35 0
 	UP BND X35 1
 	FR BND X36
 	LO BND X36 0
 	UP BND X36 1
 	FR BND X37
 	LO BND X37 0
 	UP BND X37 1
 	FR BND X38
 	LO BND X38 0
 	UP BND X38 1
 	FR BND X39
 	LO BND X39 0
 	UP BND X39 1
 	FR BND X40
 	LO BND X40 0
 	UP BND X40 1
 	FR BND X41
 	LO BND X41 0
 	UP BND X41 1
 	FR BND X42
 	LO BND X42 0
 	UP BND X42 1
 	FR BND X43
 	LO BND X43 0
 	UP BND X43 1
 	FR BND X44
 	LO BND X44 0
 	UP BND X44 1
 	FR BND X45
 	LO BND X45 0
 	UP BND X45 1
 	FR BND X46
 	LO BND X46 0
 	UP BND X46 1
 	FR BND X47
 	LO BND X47 0
 	UP BND X47 1
 	FR BND X48
 	LO BND X48 0
 	UP BND X48 1
 	FR BND X49
 	LO BND X49 0
 	UP BND X49 1
 	FR BND X50
 	LO BND X50 0
 	UP BND X50 1
 	FR BND X51
 	LO BND X51 0
 	UP BND X51 1
 	FR BND X52
 	LO BND X52 0
 	UP BND X52 1
 	FR BND X53
 	LO BND X53 0
 	UP BND X53 1
 	FR BND X54
 	LO BND X54 0
 	UP BND X54 1
 	FR BND X55
 	LO BND X55 0
 	UP BND X55 1
 	FR BND X56
 	LO BND X56 0
 	UP BND X56 1
 	FR BND X57
 	LO BND X57 0
 	UP BND X57 1
 	FR BND X58
 	LO BND X58 0
 	UP BND X58 1
 	FR BND X59
 	LO BND X59 0
 	UP BND X59 1
 	FR BND X60
 	LO BND X60 0
 	UP BND X60 1
 	FR BND X61
 	LO BND X61 0
 	UP BND X61 1
 	FR BND X62
 	LO BND X62 0
 	UP BND X62 1
 	FR BND X63
 	LO BND X63 0
 	UP BND X63 1
 	FR BND X64
 	LO BND X64 0
 	UP BND X64 1
 	FR BND X65
 	LO BND X65 0
 	UP BND X65 1
 	FR BND X66
 	LO BND X66 0
 	UP BND X66 1
 	FR BND X67
 	LO BND X67 0
 	UP BND X67 1
 	FR BND X68
 	LO BND X68 0
 	UP BND X68 1
 	FR BND X69
 	LO BND X69 0
 	UP BND X69 1
 	FR BND X70
 	LO BND X70 0
 	UP BND X70 1
 	FR BND X71
 	LO BND X71 0
 	UP BND X71 1
 	FR BND X72
 	LO BND X72 0
 	UP BND X72 1
 	FR BND X73
 	LO BND X73 0
 	UP BND X73 1
 	FR BND X74
 	LO BND X74 0
 	UP BND X74 1
 	FR BND X75
 	LO BND X75 0
 	UP BND X75 1
 	FR BND X76
 	LO BND X76 0
 	UP BND X76 1
 	FR BND X77
 	LO BND X77 0
 	UP BND X77 1
 	FR BND X78
 	LO BND X78 0
 	UP BND X78 1
 	FR BND X79
 	LO BND X79 0
 	UP BND X79 1
 	FR BND X80
 	LO BND X80 0
 	UP BND X80 1
 	FR BND X81
 	LO BND X81 0
 	UP BND X81 1
 	FR BND X82
 	LO BND X82 0
 	UP BND X82 1
 	FR BND X83
 	LO BND X83 0
 	UP BND X83 1
 	FR BND X84
 	LO BND X84 0
 	UP BND X84 1
 	FR BND X85
 	LO BND X85 0
 	UP BND X85 1
 	FR BND X86
 	LO BND X86 0
 	UP BND X86 1
 	FR BND X87
 	LO BND X87 0
 	UP BND X87 1
 	FR BND X88
 	LO BND X88 0
 	UP BND X88 1
 	FR BND X89
 	LO BND X89 0
 	UP BND X89 1
 	FR BND X90
 	LO BND X90 0
 	UP BND X90 1
 	FR BND X91
 	LO BND X91 0
 	UP BND X91 1
 	FR BND X92
 	LO BND X92 0
 	UP BND X92 1
 	FR BND X93
 	LO BND X93 0
 	UP BND X93 1
 	FR BND X94
 	LO BND X94 0
 	UP BND X94 1
 	FR BND X95
 	LO BND X95 0
 	UP BND X95 1
 	FR BND X96
 	LO BND X96 0
 	UP BND X96 1
 	FR BND X97
 	LO BND X97 0
 	UP BND X97 1
 	FR BND X98
 	LO BND X98 0
 	UP BND X98 1
 	FR BND X99
 	LO BND X99 0
 	UP BND X99 1
 	FR BND X100
 	LO BND X100 0
 	UP BND X100 1
 	FR BND X101
 	LO BND X101 0
 	UP BND X101 1
 	FR BND X102
 	LO BND X102 0
 	UP BND X102 1
 	FR BND X103
 	LO BND X103 0
 	UP BND X103 1
 	FR BND X104
 	LO BND X104 0
 	UP BND X104 1
 	FR BND X105
 	LO BND X105 0
 	UP BND X105 1
 	FR BND X106
 	LO BND X106 0
 	UP BND X106 1
 	FR BND X107
 	LO BND X107 0
 	UP BND X107 1
 	FR BND X108
 	LO BND X108 0
 	UP BND X108 1
 	FR BND X109
 	LO BND X109 0
 	UP BND X109 1
 	FR BND X110
 	LO BND X110 0
 	UP BND X110 1
 	FR BND X111
 	LO BND X111 0
 	UP BND X111 1
 	FR BND X112
 	LO BND X112 0
 	UP BND X112 1
 	FR BND X113
 	LO BND X113 0
 	UP BND X113 1
 	FR BND X114
 	LO BND X114 0
 	UP BND X114 1
 	FR BND X115
 	LO BND X115 0
 	UP BND X115 1
 	FR BND X116
 	LO BND X116 0
 	UP BND X116 1
 	FR BND X117
 	LO BND X117 0
 	UP BND X117 1
 	FR BND X118
 	LO BND X118 0
 	UP BND X118 1
 	FR BND X119
 	LO BND X119 0
 	UP BND X119 1
 	FR BND X120
 	LO BND X120 0
 	UP BND X120 1
 	FR BND X121
 	LO BND X121 0
 	UP BND X121 1
 	FR BND X122
 	LO BND X122 0
 	UP BND X122 1
 	FR BND X123
 	LO BND X123 0
 	UP BND X123 1
 	FR BND X124
 	LO BND X124 0
 	UP BND X124 1
 	FR BND X125
 	LO BND X125 0
 	UP BND X125 1
 	FR BND X126
 	LO BND X126 0
 	UP BND X126 1
 	FR BND X127
 	LO BND X127 0
 	UP BND X127 1
 	FR BND X128
 	LO BND X128 0
 	UP BND X128 1
 	FR BND X129
 	LO BND X129 0
 	UP BND X129 1
 	FR BND X130
 	LO BND X130 0
 	UP BND X130 1
 	FR BND X131
 	LO BND X131 0
 	UP BND X131 1
 	FR BND X132
 	LO BND X132 0
 	UP BND X132 1
 	FR BND X133
 	LO BND X133 0
 	UP BND X133 1
 	FR BND X134
 	LO BND X134 0
 	UP BND X134 1
 	FR BND X135
 	LO BND X135 0
 	UP BND X135 1
 	FR BND X136
 	LO BND X136 0
 	UP BND X136 1
 	FR BND X137
 	LO BND X137 0
 	UP BND X137 1
 	FR BND X138
 	LO BND X138 0
 	UP BND X138 1
 	FR BND X139
 	LO BND X139 0
 	UP BND X139 1
 	FR BND X140
 	LO BND X140 0
 	UP BND X140 1
 	FR BND X141
 	LO BND X141 0
 	UP BND X141 1
 	FR BND X142
 	LO BND X142 0
 	UP BND X142 1
 	FR BND X143
 	LO BND X143 0
 	UP BND X143 1
 	FR BND X144
 	LO BND X144 0
 	UP BND X144 1
 	FR BND X145
 	LO BND X145 0
 	UP BND X145 1
 	FR BND X146
 	LO BND X146 0
 	UP BND X146 1
 	FR BND X147
 	LO BND X147 0
 	UP BND X147 1
 	FR BND X148
 	LO BND X148 0
 	UP BND X148 1
 	FR BND X149
 	LO BND X149 0
 	UP BND X149 1
 	FR BND X150
 	LO BND X150 0
 	UP BND X150 1
 	FR BND X151
 	LO BND X151 0
 	UP BND X151 1
 	FR BND X152
 	LO BND X152 0
 	UP BND X152 1
 	FR BND X153
 	LO BND X153 0
 	UP BND X153 1
 	FR BND X154
 	LO BND X154 0
 	UP BND X154 1
 	FR BND X155
 	LO BND X155 0
 	UP BND X155 1
 	FR BND X156
 	LO BND X156 0
 	UP BND X156 1
 	FR BND X157
 	LO BND X157 0
 	UP BND X157 1
 	FR BND X158
 	LO BND X158 0
 	UP BND X158 1
 	FR BND X159
 	LO BND X159 0
 	UP BND X159 1
 	FR BND X160
 	LO BND X160 0
 	UP BND X160 1
 	FR BND X161
 	LO BND X161 0
 	UP BND X161 1
 	FR BND X162
 	LO BND X162 0
 	UP BND X162 1
 	FR BND X163
 	LO BND X163 0
 	UP BND X163 1
 	FR BND X164
 	LO BND X164 0
 	UP BND X164 1
 	FR BND X165
 	LO BND X165 0
 	UP BND X165 1
 	FR BND X166
 	LO BND X166 0
 	UP BND X166 1
 	FR BND X167
 	LO BND X167 0
 	UP BND X167 1
 	FR BND X168
 	LO BND X168 0
 	UP BND X168 1
 	FR BND X169
 	LO BND X169 0
 	UP BND X169 1
 	FR BND X170
 	LO BND X170 0
 	UP BND X170 1
 	FR BND X171
 	LO BND X171 0
 	UP BND X171 1
 	FR BND X172
 	LO BND X172 0
 	UP BND X172 1
 	FR BND X173
 	LO BND X173 0
 	UP BND X173 1
 	FR BND X174
 	LO BND X174 0
 	UP BND X174 1
 	FR BND X175
 	LO BND X175 0
 	UP BND X175 1
 	FR BND X176
 	LO BND X176 0
 	UP BND X176 1
 	FR BND X177
 	LO BND X177 0
 	UP BND X177 1
 	FR BND X178
 	LO BND X178 0
 	UP BND X178 1
 	FR BND X179
 	LO BND X179 0
 	UP BND X179 1
 	FR BND X180
 	LO BND X180 0
 	UP BND X180 1
 	FR BND X181
 	LO BND X181 0
 	UP BND X181 1
 	FR BND X182
 	LO BND X182 0
 	UP BND X182 1
 	FR BND X183
 	LO BND X183 0
 	UP BND X183 1
 	FR BND X184
 	LO BND X184 0
 	UP BND X184 1
 	FR BND X185
 	LO BND X185 0
 	UP BND X185 1
 	FR BND X186
 	LO BND X186 0
 	UP BND X186 1
 	FR BND X187
 	LO BND X187 0
 	UP BND X187 1
 	FR BND X188
 	LO BND X188 0
 	UP BND X188 1
 	FR BND X189
 	LO BND X189 0
 	UP BND X189 1
 	FR BND X190
 	LO BND X190 0
 	UP BND X190 1
 	FR BND X191
 	LO BND X191 0
 	UP BND X191 1
 	FR BND X192
 	LO BND X192 0
 	UP BND X192 1
 	FR BND X193
 	LO BND X193 0
 	UP BND X193 1
 	FR BND X194
 	LO BND X194 0
 	UP BND X194 1
 	FR BND X195
 	LO BND X195 0
 	UP BND X195 1
 	FR BND X196
 	LO BND X196 0
 	UP BND X196 1
 	FR BND X197
 	LO BND X197 0
 	UP BND X197 1
 	FR BND X198
 	LO BND X198 0
 	UP BND X198 1
 	FR BND X199
 	LO BND X199 0
 	UP BND X199 1
 	FR BND X200
 	LO BND X200 0
 	UP BND X200 1
 	FR BND X201
 	LO BND X201 0
 	UP BND X201 1
 	FR BND X202
 	LO BND X202 0
 	UP BND X202 1
 	FR BND X203
 	LO BND X203 0
 	UP BND X203 1
 	FR BND X204
 	LO BND X204 0
 	UP BND X204 1
 	FR BND X205
 	LO BND X205 0
 	UP BND X205 1
 	FR BND X206
 	LO BND X206 0
 	UP BND X206 1
 	FR BND X207
 	LO BND X207 0
 	UP BND X207 1
 	FR BND X208
 	LO BND X208 0
 	UP BND X208 1
 	FR BND X209
 	LO BND X209 0
 	UP BND X209 1
 	FR BND X210
 	LO BND X210 0
 	UP BND X210 1
 	FR BND X211
 	LO BND X211 0
 	UP BND X211 1
 	FR BND X212
 	LO BND X212 0
 	UP BND X212 1
 	FR BND X213
 	LO BND X213 0
 	UP BND X213 1
 	FR BND X214
 	LO BND X214 0
 	UP BND X214 1
 	FR BND X215
 	LO BND X215 0
 	UP BND X215 1
 	FR BND X216
 	LO BND X216 0
 	UP BND X216 1
 	FR BND X217
 	LO BND X217 0
 	UP BND X217 1
 	FR BND X218
 	LO BND X218 0
 	UP BND X218 1
 	FR BND X219
 	LO BND X219 0
 	UP BND X219 1
 	FR BND X220
 	LO BND X220 0
 	UP BND X220 1
 	FR BND X221
 	LO BND X221 0
 	UP BND X221 1
 	FR BND X222
 	LO BND X222 0
 	UP BND X222 1
 	FR BND X223
 	LO BND X223 0
 	UP BND X223 1
 	FR BND X224
 	LO BND X224 0
 	UP BND X224 1
 	FR BND X225
 	LO BND X225 0
 	UP BND X225 1
 	FR BND X226
 	LO BND X226 0
 	UP BND X226 1
 	FR BND X227
 	LO BND X227 0
 	UP BND X227 1
 	FR BND X228
 	LO BND X228 0
 	UP BND X228 1
 	FR BND X229
 	LO BND X229 0
 	UP BND X229 1
 	FR BND X230
 	LO BND X230 0
 	UP BND X230 1
 	FR BND X231
 	LO BND X231 0
 	UP BND X231 1
 	FR BND X232
 	LO BND X232 0
 	UP BND X232 1
 	FR BND X233
 	LO BND X233 0
 	UP BND X233 1
 	FR BND X234
 	LO BND X234 0
 	UP BND X234 1
 	FR BND X235
 	LO BND X235 0
 	UP BND X235 1
 	FR BND X236
 	LO BND X236 0
 	UP BND X236 1
 	FR BND X237
 	LO BND X237 0
 	UP BND X237 1
 	FR BND X238
 	LO BND X238 0
 	UP BND X238 1
 	FR BND X239
 	LO BND X239 0
 	UP BND X239 1
 	FR BND X240
 	LO BND X240 0
 	UP BND X240 1
 	FR BND X241
 	LO BND X241 0
 	UP BND X241 1
 	FR BND X242
 	LO BND X242 0
 	UP BND X242 1
 	FR BND X243
 	LO BND X243 0
 	UP BND X243 1
 	FR BND X244
 	LO BND X244 0
 	UP BND X244 1
 	FR BND X245
 	LO BND X245 0
 	UP BND X245 1
 	FR BND X246
 	LO BND X246 0
 	UP BND X246 1
 	FR BND X247
 	LO BND X247 0
 	UP BND X247 1
 	FR BND X248
 	LO BND X248 0
 	UP BND X248 1
 	FR BND X249
 	LO BND X249 0
 	UP BND X249 1
 	FR BND X250
 	LO BND X250 0
 	UP BND X250 1
 	FR BND X251
 	LO BND X251 0
 	UP BND X251 1
 	FR BND X252
 	LO BND X252 0
 	UP BND X252 1
 	FR BND X253
 	LO BND X253 0
 	UP BND X253 1
 	FR BND X254
 	LO BND X254 0
 	UP BND X254 1
 	FR BND X255
 	LO BND X255 0
 	UP BND X255 1
 	FR BND X256
 	LO BND X256 0
 	UP BND X256 1
 	FR BND X257
 	LO BND X257 0
 	UP BND X257 1
 	FR BND X258
 	LO BND X258 4
 	FR BND X259
 	LO BND X259 8
 	FR BND X260
 	LO BND X260 7
 	FR BND X261
 	LO BND X261 31
 	FR BND X262
 	LO BND X262 11
 	FR BND X263
 	LO BND X263 13
 	FR BND X264
 	LO BND X264 55
 	FR BND X265
 	LO BND X265 45
 	FR BND X266
 	LO BND X266 19
 	FR BND X267
 	LO BND X267 71
 	FR BND X268
 	LO BND X268 28
 	FR BND X269
 	LO BND X269 9
 	FR BND X270
 	LO BND X270 11
 	FR BND X271
 	LO BND X271 14
 	FR BND X272
 	LO BND X272 28
 	FR BND X273
 	LO BND X273 16
ENDATA
