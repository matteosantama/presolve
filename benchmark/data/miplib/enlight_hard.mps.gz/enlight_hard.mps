* MIPLIB 2017 benchmark v2; LP relaxation (integrality removed).
* Source: https://miplib.zib.de/downloads/benchmark.zip ; retrieved 2026-09-21
* Instance: enlight_hard ; Gleixner et al. (2021), doi:10.1007/s12532-020-00194-3
* Bounds and coefficients preserved; rows/variables renamed; objective minimized.
* Original compressed SHA256: 942168c2126a2a91ae3ec1ededea59bc1af0cad55f94223edf4c03d20e831f66
NAME enlight_hard
ROWS
 N OBJ
 E R0
 E R1
 E R2
 E R3
 E R4
 E R5
 E R6
 E R7
 E R8
 E R9
 E R10
 E R11
 E R12
 E R13
 E R14
 E R15
 E R16
 E R17
 E R18
 E R19
 E R20
 E R21
 E R22
 E R23
 E R24
 E R25
 E R26
 E R27
 E R28
 E R29
 E R30
 E R31
 E R32
 E R33
 E R34
 E R35
 E R36
 E R37
 E R38
 E R39
 E R40
 E R41
 E R42
 E R43
 E R44
 E R45
 E R46
 E R47
 E R48
 E R49
 E R50
 E R51
 E R52
 E R53
 E R54
 E R55
 E R56
 E R57
 E R58
 E R59
 E R60
 E R61
 E R62
 E R63
 E R64
 E R65
 E R66
 E R67
 E R68
 E R69
 E R70
 E R71
 E R72
 E R73
 E R74
 E R75
 E R76
 E R77
 E R78
 E R79
 E R80
 E R81
 E R82
 E R83
 E R84
 E R85
 E R86
 E R87
 E R88
 E R89
 E R90
 E R91
 E R92
 E R93
 E R94
 E R95
 E R96
 E R97
 E R98
 E R99
COLUMNS
    X0                   OBJ 1
    X0                   R64 1
    X0                   R80 1
    X0                   R96 1
    X1                   OBJ 1
    X1                   R0 1
    X1                   R64 1
    X1                   R65 1
    X1                   R96 1
    X2                   OBJ 1
    X2                   R1 1
    X2                   R64 1
    X2                   R65 1
    X2                   R66 1
    X3                   OBJ 1
    X3                   R2 1
    X3                   R65 1
    X3                   R66 1
    X3                   R67 1
    X4                   OBJ 1
    X4                   R3 1
    X4                   R66 1
    X4                   R67 1
    X4                   R68 1
    X5                   OBJ 1
    X5                   R4 1
    X5                   R67 1
    X5                   R68 1
    X5                   R69 1
    X6                   OBJ 1
    X6                   R5 1
    X6                   R68 1
    X6                   R69 1
    X6                   R70 1
    X7                   OBJ 1
    X7                   R6 1
    X7                   R69 1
    X7                   R70 1
    X7                   R71 1
    X8                   OBJ 1
    X8                   R7 1
    X8                   R70 1
    X8                   R71 1
    X8                   R98 1
    X9                   OBJ 1
    X9                   R71 1
    X9                   R88 1
    X9                   R98 1
    X10                  OBJ 1
    X10                  R0 1
    X10                  R80 1
    X10                  R81 1
    X10                  R96 1
    X11                  OBJ 1
    X11                  R0 1
    X11                  R1 1
    X11                  R8 1
    X11                  R64 1
    X11                  R80 1
    X12                  OBJ 1
    X12                  R0 1
    X12                  R1 1
    X12                  R2 1
    X12                  R9 1
    X12                  R65 1
    X13                  OBJ 1
    X13                  R1 1
    X13                  R2 1
    X13                  R3 1
    X13                  R10 1
    X13                  R66 1
    X14                  OBJ 1
    X14                  R2 1
    X14                  R3 1
    X14                  R4 1
    X14                  R11 1
    X14                  R67 1
    X15                  OBJ 1
    X15                  R3 1
    X15                  R4 1
    X15                  R5 1
    X15                  R12 1
    X15                  R68 1
    X16                  OBJ 1
    X16                  R4 1
    X16                  R5 1
    X16                  R6 1
    X16                  R13 1
    X16                  R69 1
    X17                  OBJ 1
    X17                  R5 1
    X17                  R6 1
    X17                  R7 1
    X17                  R14 1
    X17                  R70 1
    X18                  OBJ 1
    X18                  R6 1
    X18                  R7 1
    X18                  R15 1
    X18                  R71 1
    X18                  R88 1
    X19                  OBJ 1
    X19                  R7 1
    X19                  R88 1
    X19                  R89 1
    X19                  R98 1
    X20                  OBJ 1
    X20                  R8 1
    X20                  R80 1
    X20                  R81 1
    X20                  R82 1
    X21                  OBJ 1
    X21                  R0 1
    X21                  R8 1
    X21                  R9 1
    X21                  R16 1
    X21                  R81 1
    X22                  OBJ 1
    X22                  R1 1
    X22                  R8 1
    X22                  R9 1
    X22                  R10 1
    X22                  R17 1
    X23                  OBJ 1
    X23                  R2 1
    X23                  R9 1
    X23                  R10 1
    X23                  R11 1
    X23                  R18 1
    X24                  OBJ 1
    X24                  R3 1
    X24                  R10 1
    X24                  R11 1
    X24                  R12 1
    X24                  R19 1
    X25                  OBJ 1
    X25                  R4 1
    X25                  R11 1
    X25                  R12 1
    X25                  R13 1
    X25                  R20 1
    X26                  OBJ 1
    X26                  R5 1
    X26                  R12 1
    X26                  R13 1
    X26                  R14 1
    X26                  R21 1
    X27                  OBJ 1
    X27                  R6 1
    X27                  R13 1
    X27                  R14 1
    X27                  R15 1
    X27                  R22 1
    X28                  OBJ 1
    X28                  R7 1
    X28                  R14 1
    X28                  R15 1
    X28                  R23 1
    X28                  R89 1
    X29                  OBJ 1
    X29                  R15 1
    X29                  R88 1
    X29                  R89 1
    X29                  R90 1
    X30                  OBJ 1
    X30                  R16 1
    X30                  R81 1
    X30                  R82 1
    X30                  R83 1
    X31                  OBJ 1
    X31                  R8 1
    X31                  R16 1
    X31                  R17 1
    X31                  R24 1
    X31                  R82 1
    X32                  OBJ 1
    X32                  R9 1
    X32                  R16 1
    X32                  R17 1
    X32                  R18 1
    X32                  R25 1
    X33                  OBJ 1
    X33                  R10 1
    X33                  R17 1
    X33                  R18 1
    X33                  R19 1
    X33                  R26 1
    X34                  OBJ 1
    X34                  R11 1
    X34                  R18 1
    X34                  R19 1
    X34                  R20 1
    X34                  R27 1
    X35                  OBJ 1
    X35                  R12 1
    X35                  R19 1
    X35                  R20 1
    X35                  R21 1
    X35                  R28 1
    X36                  OBJ 1
    X36                  R13 1
    X36                  R20 1
    X36                  R21 1
    X36                  R22 1
    X36                  R29 1
    X37                  OBJ 1
    X37                  R14 1
    X37                  R21 1
    X37                  R22 1
    X37                  R23 1
    X37                  R30 1
    X38                  OBJ 1
    X38                  R15 1
    X38                  R22 1
    X38                  R23 1
    X38                  R31 1
    X38                  R90 1
    X39                  OBJ 1
    X39                  R23 1
    X39                  R89 1
    X39                  R90 1
    X39                  R91 1
    X40                  OBJ 1
    X40                  R24 1
    X40                  R82 1
    X40                  R83 1
    X40                  R84 1
    X41                  OBJ 1
    X41                  R16 1
    X41                  R24 1
    X41                  R25 1
    X41                  R32 1
    X41                  R83 1
    X42                  OBJ 1
    X42                  R17 1
    X42                  R24 1
    X42                  R25 1
    X42                  R26 1
    X42                  R33 1
    X43                  OBJ 1
    X43                  R18 1
    X43                  R25 1
    X43                  R26 1
    X43                  R27 1
    X43                  R34 1
    X44                  OBJ 1
    X44                  R19 1
    X44                  R26 1
    X44                  R27 1
    X44                  R28 1
    X44                  R35 1
    X45                  OBJ 1
    X45                  R20 1
    X45                  R27 1
    X45                  R28 1
    X45                  R29 1
    X45                  R36 1
    X46                  OBJ 1
    X46                  R21 1
    X46                  R28 1
    X46                  R29 1
    X46                  R30 1
    X46                  R37 1
    X47                  OBJ 1
    X47                  R22 1
    X47                  R29 1
    X47                  R30 1
    X47                  R31 1
    X47                  R38 1
    X48                  OBJ 1
    X48                  R23 1
    X48                  R30 1
    X48                  R31 1
    X48                  R39 1
    X48                  R91 1
    X49                  OBJ 1
    X49                  R31 1
    X49                  R90 1
    X49                  R91 1
    X49                  R92 1
    X50                  OBJ 1
    X50                  R32 1
    X50                  R83 1
    X50                  R84 1
    X50                  R85 1
    X51                  OBJ 1
    X51                  R24 1
    X51                  R32 1
    X51                  R33 1
    X51                  R40 1
    X51                  R84 1
    X52                  OBJ 1
    X52                  R25 1
    X52                  R32 1
    X52                  R33 1
    X52                  R34 1
    X52                  R41 1
    X53                  OBJ 1
    X53                  R26 1
    X53                  R33 1
    X53                  R34 1
    X53                  R35 1
    X53                  R42 1
    X54                  OBJ 1
    X54                  R27 1
    X54                  R34 1
    X54                  R35 1
    X54                  R36 1
    X54                  R43 1
    X55                  OBJ 1
    X55                  R28 1
    X55                  R35 1
    X55                  R36 1
    X55                  R37 1
    X55                  R44 1
    X56                  OBJ 1
    X56                  R29 1
    X56                  R36 1
    X56                  R37 1
    X56                  R38 1
    X56                  R45 1
    X57                  OBJ 1
    X57                  R30 1
    X57                  R37 1
    X57                  R38 1
    X57                  R39 1
    X57                  R46 1
    X58                  OBJ 1
    X58                  R31 1
    X58                  R38 1
    X58                  R39 1
    X58                  R47 1
    X58                  R92 1
    X59                  OBJ 1
    X59                  R39 1
    X59                  R91 1
    X59                  R92 1
    X59                  R93 1
    X60                  OBJ 1
    X60                  R40 1
    X60                  R84 1
    X60                  R85 1
    X60                  R86 1
    X61                  OBJ 1
    X61                  R32 1
    X61                  R40 1
    X61                  R41 1
    X61                  R48 1
    X61                  R85 1
    X62                  OBJ 1
    X62                  R33 1
    X62                  R40 1
    X62                  R41 1
    X62                  R42 1
    X62                  R49 1
    X63                  OBJ 1
    X63                  R34 1
    X63                  R41 1
    X63                  R42 1
    X63                  R43 1
    X63                  R50 1
    X64                  OBJ 1
    X64                  R35 1
    X64                  R42 1
    X64                  R43 1
    X64                  R44 1
    X64                  R51 1
    X65                  OBJ 1
    X65                  R36 1
    X65                  R43 1
    X65                  R44 1
    X65                  R45 1
    X65                  R52 1
    X66                  OBJ 1
    X66                  R37 1
    X66                  R44 1
    X66                  R45 1
    X66                  R46 1
    X66                  R53 1
    X67                  OBJ 1
    X67                  R38 1
    X67                  R45 1
    X67                  R46 1
    X67                  R47 1
    X67                  R54 1
    X68                  OBJ 1
    X68                  R39 1
    X68                  R46 1
    X68                  R47 1
    X68                  R55 1
    X68                  R93 1
    X69                  OBJ 1
    X69                  R47 1
    X69                  R92 1
    X69                  R93 1
    X69                  R94 1
    X70                  OBJ 1
    X70                  R48 1
    X70                  R85 1
    X70                  R86 1
    X70                  R87 1
    X71                  OBJ 1
    X71                  R40 1
    X71                  R48 1
    X71                  R49 1
    X71                  R56 1
    X71                  R86 1
    X72                  OBJ 1
    X72                  R41 1
    X72                  R48 1
    X72                  R49 1
    X72                  R50 1
    X72                  R57 1
    X73                  OBJ 1
    X73                  R42 1
    X73                  R49 1
    X73                  R50 1
    X73                  R51 1
    X73                  R58 1
    X74                  OBJ 1
    X74                  R43 1
    X74                  R50 1
    X74                  R51 1
    X74                  R52 1
    X74                  R59 1
    X75                  OBJ 1
    X75                  R44 1
    X75                  R51 1
    X75                  R52 1
    X75                  R53 1
    X75                  R60 1
    X76                  OBJ 1
    X76                  R45 1
    X76                  R52 1
    X76                  R53 1
    X76                  R54 1
    X76                  R61 1
    X77                  OBJ 1
    X77                  R46 1
    X77                  R53 1
    X77                  R54 1
    X77                  R55 1
    X77                  R62 1
    X78                  OBJ 1
    X78                  R47 1
    X78                  R54 1
    X78                  R55 1
    X78                  R63 1
    X78                  R94 1
    X79                  OBJ 1
    X79                  R55 1
    X79                  R93 1
    X79                  R94 1
    X79                  R95 1
    X80                  OBJ 1
    X80                  R56 1
    X80                  R86 1
    X80                  R87 1
    X80                  R97 1
    X81                  OBJ 1
    X81                  R48 1
    X81                  R56 1
    X81                  R57 1
    X81                  R72 1
    X81                  R87 1
    X82                  OBJ 1
    X82                  R49 1
    X82                  R56 1
    X82                  R57 1
    X82                  R58 1
    X82                  R73 1
    X83                  OBJ 1
    X83                  R50 1
    X83                  R57 1
    X83                  R58 1
    X83                  R59 1
    X83                  R74 1
    X84                  OBJ 1
    X84                  R51 1
    X84                  R58 1
    X84                  R59 1
    X84                  R60 1
    X84                  R75 1
    X85                  OBJ 1
    X85                  R52 1
    X85                  R59 1
    X85                  R60 1
    X85                  R61 1
    X85                  R76 1
    X86                  OBJ 1
    X86                  R53 1
    X86                  R60 1
    X86                  R61 1
    X86                  R62 1
    X86                  R77 1
    X87                  OBJ 1
    X87                  R54 1
    X87                  R61 1
    X87                  R62 1
    X87                  R63 1
    X87                  R78 1
    X88                  OBJ 1
    X88                  R55 1
    X88                  R62 1
    X88                  R63 1
    X88                  R79 1
    X88                  R95 1
    X89                  OBJ 1
    X89                  R63 1
    X89                  R94 1
    X89                  R95 1
    X89                  R99 1
    X90                  OBJ 1
    X90                  R72 1
    X90                  R87 1
    X90                  R97 1
    X91                  OBJ 1
    X91                  R56 1
    X91                  R72 1
    X91                  R73 1
    X91                  R97 1
    X92                  OBJ 1
    X92                  R57 1
    X92                  R72 1
    X92                  R73 1
    X92                  R74 1
    X93                  OBJ 1
    X93                  R58 1
    X93                  R73 1
    X93                  R74 1
    X93                  R75 1
    X94                  OBJ 1
    X94                  R59 1
    X94                  R74 1
    X94                  R75 1
    X94                  R76 1
    X95                  OBJ 1
    X95                  R60 1
    X95                  R75 1
    X95                  R76 1
    X95                  R77 1
    X96                  OBJ 1
    X96                  R61 1
    X96                  R76 1
    X96                  R77 1
    X96                  R78 1
    X97                  OBJ 1
    X97                  R62 1
    X97                  R77 1
    X97                  R78 1
    X97                  R79 1
    X98                  OBJ 1
    X98                  R63 1
    X98                  R78 1
    X98                  R79 1
    X98                  R99 1
    X99                  OBJ 1
    X99                  R79 1
    X99                  R95 1
    X99                  R99 1
    X100                 OBJ 0
    X100                 R0 -2
    X101                 OBJ 0
    X101                 R1 -2
    X102                 OBJ 0
    X102                 R2 -2
    X103                 OBJ 0
    X103                 R3 -2
    X104                 OBJ 0
    X104                 R4 -2
    X105                 OBJ 0
    X105                 R5 -2
    X106                 OBJ 0
    X106                 R6 -2
    X107                 OBJ 0
    X107                 R7 -2
    X108                 OBJ 0
    X108                 R8 -2
    X109                 OBJ 0
    X109                 R9 -2
    X110                 OBJ 0
    X110                 R10 -2
    X111                 OBJ 0
    X111                 R11 -2
    X112                 OBJ 0
    X112                 R12 -2
    X113                 OBJ 0
    X113                 R13 -2
    X114                 OBJ 0
    X114                 R14 -2
    X115                 OBJ 0
    X115                 R15 -2
    X116                 OBJ 0
    X116                 R16 -2
    X117                 OBJ 0
    X117                 R17 -2
    X118                 OBJ 0
    X118                 R18 -2
    X119                 OBJ 0
    X119                 R19 -2
    X120                 OBJ 0
    X120                 R20 -2
    X121                 OBJ 0
    X121                 R21 -2
    X122                 OBJ 0
    X122                 R22 -2
    X123                 OBJ 0
    X123                 R23 -2
    X124                 OBJ 0
    X124                 R24 -2
    X125                 OBJ 0
    X125                 R25 -2
    X126                 OBJ 0
    X126                 R26 -2
    X127                 OBJ 0
    X127                 R27 -2
    X128                 OBJ 0
    X128                 R28 -2
    X129                 OBJ 0
    X129                 R29 -2
    X130                 OBJ 0
    X130                 R30 -2
    X131                 OBJ 0
    X131                 R31 -2
    X132                 OBJ 0
    X132                 R32 -2
    X133                 OBJ 0
    X133                 R33 -2
    X134                 OBJ 0
    X134                 R34 -2
    X135                 OBJ 0
    X135                 R35 -2
    X136                 OBJ 0
    X136                 R36 -2
    X137                 OBJ 0
    X137                 R37 -2
    X138                 OBJ 0
    X138                 R38 -2
    X139                 OBJ 0
    X139                 R39 -2
    X140                 OBJ 0
    X140                 R40 -2
    X141                 OBJ 0
    X141                 R41 -2
    X142                 OBJ 0
    X142                 R42 -2
    X143                 OBJ 0
    X143                 R43 -2
    X144                 OBJ 0
    X144                 R44 -2
    X145                 OBJ 0
    X145                 R45 -2
    X146                 OBJ 0
    X146                 R46 -2
    X147                 OBJ 0
    X147                 R47 -2
    X148                 OBJ 0
    X148                 R48 -2
    X149                 OBJ 0
    X149                 R49 -2
    X150                 OBJ 0
    X150                 R50 -2
    X151                 OBJ 0
    X151                 R51 -2
    X152                 OBJ 0
    X152                 R52 -2
    X153                 OBJ 0
    X153                 R53 -2
    X154                 OBJ 0
    X154                 R54 -2
    X155                 OBJ 0
    X155                 R55 -2
    X156                 OBJ 0
    X156                 R56 -2
    X157                 OBJ 0
    X157                 R57 -2
    X158                 OBJ 0
    X158                 R58 -2
    X159                 OBJ 0
    X159                 R59 -2
    X160                 OBJ 0
    X160                 R60 -2
    X161                 OBJ 0
    X161                 R61 -2
    X162                 OBJ 0
    X162                 R62 -2
    X163                 OBJ 0
    X163                 R63 -2
    X164                 OBJ 0
    X164                 R64 -2
    X165                 OBJ 0
    X165                 R65 -2
    X166                 OBJ 0
    X166                 R66 -2
    X167                 OBJ 0
    X167                 R67 -2
    X168                 OBJ 0
    X168                 R68 -2
    X169                 OBJ 0
    X169                 R69 -2
    X170                 OBJ 0
    X170                 R70 -2
    X171                 OBJ 0
    X171                 R71 -2
    X172                 OBJ 0
    X172                 R72 -2
    X173                 OBJ 0
    X173                 R73 -2
    X174                 OBJ 0
    X174                 R74 -2
    X175                 OBJ 0
    X175                 R75 -2
    X176                 OBJ 0
    X176                 R76 -2
    X177                 OBJ 0
    X177                 R77 -2
    X178                 OBJ 0
    X178                 R78 -2
    X179                 OBJ 0
    X179                 R79 -2
    X180                 OBJ 0
    X180                 R80 -2
    X181                 OBJ 0
    X181                 R81 -2
    X182                 OBJ 0
    X182                 R82 -2
    X183                 OBJ 0
    X183                 R83 -2
    X184                 OBJ 0
    X184                 R84 -2
    X185                 OBJ 0
    X185                 R85 -2
    X186                 OBJ 0
    X186                 R86 -2
    X187                 OBJ 0
    X187                 R87 -2
    X188                 OBJ 0
    X188                 R88 -2
    X189                 OBJ 0
    X189                 R89 -2
    X190                 OBJ 0
    X190                 R90 -2
    X191                 OBJ 0
    X191                 R91 -2
    X192                 OBJ 0
    X192                 R92 -2
    X193                 OBJ 0
    X193                 R93 -2
    X194                 OBJ 0
    X194                 R94 -2
    X195                 OBJ 0
    X195                 R95 -2
    X196                 OBJ 0
    X196                 R96 -2
    X197                 OBJ 0
    X197                 R97 -2
    X198                 OBJ 0
    X198                 R98 -2
    X199                 OBJ 0
    X199                 R99 -2
RHS
    RHS                  OBJ -0
    RHS                  R0 0
    RHS                  R1 0
    RHS                  R2 0
    RHS                  R3 0
    RHS                  R4 0
    RHS                  R5 -1
    RHS                  R6 0
    RHS                  R7 0
    RHS                  R8 -1
    RHS                  R9 0
    RHS                  R10 0
    RHS                  R11 -1
    RHS                  R12 -1
    RHS                  R13 0
    RHS                  R14 0
    RHS                  R15 0
    RHS                  R16 0
    RHS                  R17 0
    RHS                  R18 0
    RHS                  R19 0
    RHS                  R20 0
    RHS                  R21 0
    RHS                  R22 -1
    RHS                  R23 0
    RHS                  R24 0
    RHS                  R25 0
    RHS                  R26 0
    RHS                  R27 0
    RHS                  R28 -1
    RHS                  R29 0
    RHS                  R30 0
    RHS                  R31 0
    RHS                  R32 0
    RHS                  R33 -1
    RHS                  R34 0
    RHS                  R35 0
    RHS                  R36 0
    RHS                  R37 0
    RHS                  R38 -1
    RHS                  R39 0
    RHS                  R40 0
    RHS                  R41 0
    RHS                  R42 -1
    RHS                  R43 0
    RHS                  R44 0
    RHS                  R45 -1
    RHS                  R46 0
    RHS                  R47 -1
    RHS                  R48 0
    RHS                  R49 0
    RHS                  R50 0
    RHS                  R51 -1
    RHS                  R52 0
    RHS                  R53 0
    RHS                  R54 -1
    RHS                  R55 0
    RHS                  R56 -1
    RHS                  R57 0
    RHS                  R58 0
    RHS                  R59 0
    RHS                  R60 0
    RHS                  R61 -1
    RHS                  R62 -1
    RHS                  R63 0
    RHS                  R64 0
    RHS                  R65 0
    RHS                  R66 0
    RHS                  R67 0
    RHS                  R68 0
    RHS                  R69 0
    RHS                  R70 -1
    RHS                  R71 0
    RHS                  R72 0
    RHS                  R73 -1
    RHS                  R74 -1
    RHS                  R75 -1
    RHS                  R76 0
    RHS                  R77 -1
    RHS                  R78 0
    RHS                  R79 -1
    RHS                  R80 0
    RHS                  R81 0
    RHS                  R82 0
    RHS                  R83 -1
    RHS                  R84 0
    RHS                  R85 0
    RHS                  R86 -1
    RHS                  R87 0
    RHS                  R88 0
    RHS                  R89 -1
    RHS                  R90 0
    RHS                  R91 0
    RHS                  R92 0
    RHS                  R93 0
    RHS                  R94 -1
    RHS                  R95 -1
    RHS                  R96 -1
    RHS                  R97 -1
    RHS                  R98 0
    RHS                  R99 0
BOUNDS
 	FR BND X0
 	LO BND X0 0
 	UP BND X0 1
 	FR BND X1
 	LO BND X1 0
 	UP BND X1 1
 	FR BND X2
 	LO BND X2 0
 	UP BND X2 1
 	FR BND X3
 	LO BND X3 0
 	UP BND X3 1
 	FR BND X4
 	LO BND X4 0
 	UP BND X4 1
 	FR BND X5
 	LO BND X5 0
 	UP BND X5 1
 	FR BND X6
 	LO BND X6 0
 	UP BND X6 1
 	FR BND X7
 	LO BND X7 0
 	UP BND X7 1
 	FR BND X8
 	LO BND X8 0
 	UP BND X8 1
 	FR BND X9
 	LO BND X9 0
 	UP BND X9 1
 	FR BND X10
 	LO BND X10 0
 	UP BND X10 1
 	FR BND X11
 	LO BND X11 0
 	UP BND X11 1
 	FR BND X12
 	LO BND X12 0
 	UP BND X12 1
 	FR BND X13
 	LO BND X13 0
 	UP BND X13 1
 	FR BND X14
 	LO BND X14 0
 	UP BND X14 1
 	FR BND X15
 	LO BND X15 0
 	UP BND X15 1
 	FR BND X16
 	LO BND X16 0
 	UP BND X16 1
 	FR BND X17
 	LO BND X17 0
 	UP BND X17 1
 	FR BND X18
 	LO BND X18 0
 	UP BND X18 1
 	FR BND X19
 	LO BND X19 0
 	UP BND X19 1
 	FR BND X20
 	LO BND X20 0
 	UP BND X20 1
 	FR BND X21
 	LO BND X21 0
 	UP BND X21 1
 	FR BND X22
 	LO BND X22 0
 	UP BND X22 1
 	FR BND X23
 	LO BND X23 0
 	UP BND X23 1
 	FR BND X24
 	LO BND X24 0
 	UP BND X24 1
 	FR BND X25
 	LO BND X25 0
 	UP BND X25 1
 	FR BND X26
 	LO BND X26 0
 	UP BND X26 1
 	FR BND X27
 	LO BND X27 0
 	UP BND X27 1
 	FR BND X28
 	LO BND X28 0
 	UP BND X28 1
 	FR BND X29
 	LO BND X29 0
 	UP BND X29 1
 	FR BND X30
 	LO BND X30 0
 	UP BND X30 1
 	FR BND X31
 	LO BND X31 0
 	UP BND X31 1
 	FR BND X32
 	LO BND X32 0
 	UP BND X32 1
 	FR BND X33
 	LO BND X33 0
 	UP BND X33 1
 	FR BND X34
 	LO BND X34 0
 	UP BND X34 1
 	FR BND X35
 	LO BND X35 0
 	UP BND X35 1
 	FR BND X36
 	LO BND X36 0
 	UP BND X36 1
 	FR BND X37
 	LO BND X37 0
 	UP BND X37 1
 	FR BND X38
 	LO BND X38 0
 	UP BND X38 1
 	FR BND X39
 	LO BND X39 0
 	UP BND X39 1
 	FR BND X40
 	LO BND X40 0
 	UP BND X40 1
 	FR BND X41
 	LO BND X41 0
 	UP BND X41 1
 	FR BND X42
 	LO BND X42 0
 	UP BND X42 1
 	FR BND X43
 	LO BND X43 0
 	UP BND X43 1
 	FR BND X44
 	LO BND X44 0
 	UP BND X44 1
 	FR BND X45
 	LO BND X45 0
 	UP BND X45 1
 	FR BND X46
 	LO BND X46 0
 	UP BND X46 1
 	FR BND X47
 	LO BND X47 0
 	UP BND X47 1
 	FR BND X48
 	LO BND X48 0
 	UP BND X48 1
 	FR BND X49
 	LO BND X49 0
 	UP BND X49 1
 	FR BND X50
 	LO BND X50 0
 	UP BND X50 1
 	FR BND X51
 	LO BND X51 0
 	UP BND X51 1
 	FR BND X52
 	LO BND X52 0
 	UP BND X52 1
 	FR BND X53
 	LO BND X53 0
 	UP BND X53 1
 	FR BND X54
 	LO BND X54 0
 	UP BND X54 1
 	FR BND X55
 	LO BND X55 0
 	UP BND X55 1
 	FR BND X56
 	LO BND X56 0
 	UP BND X56 1
 	FR BND X57
 	LO BND X57 0
 	UP BND X57 1
 	FR BND X58
 	LO BND X58 0
 	UP BND X58 1
 	FR BND X59
 	LO BND X59 0
 	UP BND X59 1
 	FR BND X60
 	LO BND X60 0
 	UP BND X60 1
 	FR BND X61
 	LO BND X61 0
 	UP BND X61 1
 	FR BND X62
 	LO BND X62 0
 	UP BND X62 1
 	FR BND X63
 	LO BND X63 0
 	UP BND X63 1
 	FR BND X64
 	LO BND X64 0
 	UP BND X64 1
 	FR BND X65
 	LO BND X65 0
 	UP BND X65 1
 	FR BND X66
 	LO BND X66 0
 	UP BND X66 1
 	FR BND X67
 	LO BND X67 0
 	UP BND X67 1
 	FR BND X68
 	LO BND X68 0
 	UP BND X68 1
 	FR BND X69
 	LO BND X69 0
 	UP BND X69 1
 	FR BND X70
 	LO BND X70 0
 	UP BND X70 1
 	FR BND X71
 	LO BND X71 0
 	UP BND X71 1
 	FR BND X72
 	LO BND X72 0
 	UP BND X72 1
 	FR BND X73
 	LO BND X73 0
 	UP BND X73 1
 	FR BND X74
 	LO BND X74 0
 	UP BND X74 1
 	FR BND X75
 	LO BND X75 0
 	UP BND X75 1
 	FR BND X76
 	LO BND X76 0
 	UP BND X76 1
 	FR BND X77
 	LO BND X77 0
 	UP BND X77 1
 	FR BND X78
 	LO BND X78 0
 	UP BND X78 1
 	FR BND X79
 	LO BND X79 0
 	UP BND X79 1
 	FR BND X80
 	LO BND X80 0
 	UP BND X80 1
 	FR BND X81
 	LO BND X81 0
 	UP BND X81 1
 	FR BND X82
 	LO BND X82 0
 	UP BND X82 1
 	FR BND X83
 	LO BND X83 0
 	UP BND X83 1
 	FR BND X84
 	LO BND X84 0
 	UP BND X84 1
 	FR BND X85
 	LO BND X85 0
 	UP BND X85 1
 	FR BND X86
 	LO BND X86 0
 	UP BND X86 1
 	FR BND X87
 	LO BND X87 0
 	UP BND X87 1
 	FR BND X88
 	LO BND X88 0
 	UP BND X88 1
 	FR BND X89
 	LO BND X89 0
 	UP BND X89 1
 	FR BND X90
 	LO BND X90 0
 	UP BND X90 1
 	FR BND X91
 	LO BND X91 0
 	UP BND X91 1
 	FR BND X92
 	LO BND X92 0
 	UP BND X92 1
 	FR BND X93
 	LO BND X93 0
 	UP BND X93 1
 	FR BND X94
 	LO BND X94 0
 	UP BND X94 1
 	FR BND X95
 	LO BND X95 0
 	UP BND X95 1
 	FR BND X96
 	LO BND X96 0
 	UP BND X96 1
 	FR BND X97
 	LO BND X97 0
 	UP BND X97 1
 	FR BND X98
 	LO BND X98 0
 	UP BND X98 1
 	FR BND X99
 	LO BND X99 0
 	UP BND X99 1
 	FR BND X100
 	LO BND X100 0
 	FR BND X101
 	LO BND X101 0
 	FR BND X102
 	LO BND X102 0
 	FR BND X103
 	LO BND X103 0
 	FR BND X104
 	LO BND X104 0
 	FR BND X105
 	LO BND X105 0
 	FR BND X106
 	LO BND X106 0
 	FR BND X107
 	LO BND X107 0
 	FR BND X108
 	LO BND X108 0
 	FR BND X109
 	LO BND X109 0
 	FR BND X110
 	LO BND X110 0
 	FR BND X111
 	LO BND X111 0
 	FR BND X112
 	LO BND X112 0
 	FR BND X113
 	LO BND X113 0
 	FR BND X114
 	LO BND X114 0
 	FR BND X115
 	LO BND X115 0
 	FR BND X116
 	LO BND X116 0
 	FR BND X117
 	LO BND X117 0
 	FR BND X118
 	LO BND X118 0
 	FR BND X119
 	LO BND X119 0
 	FR BND X120
 	LO BND X120 0
 	FR BND X121
 	LO BND X121 0
 	FR BND X122
 	LO BND X122 0
 	FR BND X123
 	LO BND X123 0
 	FR BND X124
 	LO BND X124 0
 	FR BND X125
 	LO BND X125 0
 	FR BND X126
 	LO BND X126 0
 	FR BND X127
 	LO BND X127 0
 	FR BND X128
 	LO BND X128 0
 	FR BND X129
 	LO BND X129 0
 	FR BND X130
 	LO BND X130 0
 	FR BND X131
 	LO BND X131 0
 	FR BND X132
 	LO BND X132 0
 	FR BND X133
 	LO BND X133 0
 	FR BND X134
 	LO BND X134 0
 	FR BND X135
 	LO BND X135 0
 	FR BND X136
 	LO BND X136 0
 	FR BND X137
 	LO BND X137 0
 	FR BND X138
 	LO BND X138 0
 	FR BND X139
 	LO BND X139 0
 	FR BND X140
 	LO BND X140 0
 	FR BND X141
 	LO BND X141 0
 	FR BND X142
 	LO BND X142 0
 	FR BND X143
 	LO BND X143 0
 	FR BND X144
 	LO BND X144 0
 	FR BND X145
 	LO BND X145 0
 	FR BND X146
 	LO BND X146 0
 	FR BND X147
 	LO BND X147 0
 	FR BND X148
 	LO BND X148 0
 	FR BND X149
 	LO BND X149 0
 	FR BND X150
 	LO BND X150 0
 	FR BND X151
 	LO BND X151 0
 	FR BND X152
 	LO BND X152 0
 	FR BND X153
 	LO BND X153 0
 	FR BND X154
 	LO BND X154 0
 	FR BND X155
 	LO BND X155 0
 	FR BND X156
 	LO BND X156 0
 	FR BND X157
 	LO BND X157 0
 	FR BND X158
 	LO BND X158 0
 	FR BND X159
 	LO BND X159 0
 	FR BND X160
 	LO BND X160 0
 	FR BND X161
 	LO BND X161 0
 	FR BND X162
 	LO BND X162 0
 	FR BND X163
 	LO BND X163 0
 	FR BND X164
 	LO BND X164 0
 	FR BND X165
 	LO BND X165 0
 	FR BND X166
 	LO BND X166 0
 	FR BND X167
 	LO BND X167 0
 	FR BND X168
 	LO BND X168 0
 	FR BND X169
 	LO BND X169 0
 	FR BND X170
 	LO BND X170 0
 	FR BND X171
 	LO BND X171 0
 	FR BND X172
 	LO BND X172 0
 	FR BND X173
 	LO BND X173 0
 	FR BND X174
 	LO BND X174 0
 	FR BND X175
 	LO BND X175 0
 	FR BND X176
 	LO BND X176 0
 	FR BND X177
 	LO BND X177 0
 	FR BND X178
 	LO BND X178 0
 	FR BND X179
 	LO BND X179 0
 	FR BND X180
 	LO BND X180 0
 	FR BND X181
 	LO BND X181 0
 	FR BND X182
 	LO BND X182 0
 	FR BND X183
 	LO BND X183 0
 	FR BND X184
 	LO BND X184 0
 	FR BND X185
 	LO BND X185 0
 	FR BND X186
 	LO BND X186 0
 	FR BND X187
 	LO BND X187 0
 	FR BND X188
 	LO BND X188 0
 	FR BND X189
 	LO BND X189 0
 	FR BND X190
 	LO BND X190 0
 	FR BND X191
 	LO BND X191 0
 	FR BND X192
 	LO BND X192 0
 	FR BND X193
 	LO BND X193 0
 	FR BND X194
 	LO BND X194 0
 	FR BND X195
 	LO BND X195 0
 	FR BND X196
 	LO BND X196 0
 	FR BND X197
 	LO BND X197 0
 	FR BND X198
 	LO BND X198 0
 	FR BND X199
 	LO BND X199 0
ENDATA
