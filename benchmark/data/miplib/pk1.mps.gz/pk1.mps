* MIPLIB 2017 benchmark v2; LP relaxation (integrality removed).
* Source: https://miplib.zib.de/downloads/benchmark.zip ; retrieved 2026-09-21
* Instance: pk1 ; Gleixner et al. (2021), doi:10.1007/s12532-020-00194-3
* Bounds and coefficients preserved; rows/variables renamed; objective minimized.
* Original compressed SHA256: 6c64530538b254a8ae648f8f8f188847366ae52da560fdec0ad290c642973ba0
NAME pk1
ROWS
 N OBJ
 E R0
 E R1
 E R2
 E R3
 E R4
 E R5
 E R6
 E R7
 E R8
 E R9
 E R10
 E R11
 E R12
 E R13
 E R14
 G R15
 G R16
 G R17
 G R18
 G R19
 G R20
 G R21
 G R22
 G R23
 G R24
 G R25
 G R26
 G R27
 G R28
 G R29
 G R30
 G R31
 G R32
 G R33
 G R34
 G R35
 G R36
 G R37
 G R38
 G R39
 G R40
 G R41
 G R42
 G R43
 G R44
COLUMNS
    X0                   OBJ 1
    X0                   R15 1
    X0                   R16 1
    X0                   R17 1
    X0                   R18 1
    X0                   R19 1
    X0                   R20 1
    X0                   R21 1
    X0                   R22 1
    X0                   R23 1
    X0                   R24 1
    X0                   R25 1
    X0                   R26 1
    X0                   R27 1
    X0                   R28 1
    X0                   R29 1
    X0                   R30 1
    X0                   R31 1
    X0                   R32 1
    X0                   R33 1
    X0                   R34 1
    X0                   R35 1
    X0                   R36 1
    X0                   R37 1
    X0                   R38 1
    X0                   R39 1
    X0                   R40 1
    X0                   R41 1
    X0                   R42 1
    X0                   R43 1
    X0                   R44 1
    X1                   OBJ 0
    X1                   R0 14
    X1                   R1 53
    X1                   R2 48
    X1                   R3 33
    X1                   R4 15
    X1                   R5 43
    X1                   R6 8
    X1                   R7 38
    X1                   R8 34
    X1                   R9 37
    X1                   R10 25
    X1                   R11 42
    X1                   R12 16
    X1                   R13 10
    X1                   R14 28
    X2                   OBJ 0
    X2                   R0 36
    X2                   R1 48
    X2                   R2 34
    X2                   R3 34
    X2                   R4 9
    X2                   R5 28
    X2                   R6 30
    X2                   R7 42
    X2                   R8 13
    X2                   R9 42
    X2                   R10 47
    X2                   R11 33
    X2                   R12 6
    X2                   R13 51
    X2                   R14 47
    X3                   OBJ 0
    X3                   R0 11
    X3                   R1 48
    X3                   R2 8
    X3                   R3 36
    X3                   R4 24
    X3                   R5 30
    X3                   R6 18
    X3                   R7 24
    X3                   R8 39
    X3                   R9 23
    X3                   R10 25
    X3                   R11 45
    X3                   R12 47
    X3                   R13 33
    X3                   R14 16
    X4                   OBJ 0
    X4                   R0 27
    X4                   R1 12
    X4                   R2 5
    X4                   R3 34
    X4                   R4 43
    X4                   R5 30
    X4                   R6 16
    X4                   R7 46
    X4                   R8 19
    X4                   R9 41
    X4                   R10 29
    X4                   R11 6
    X4                   R12 30
    X4                   R13 23
    X4                   R14 32
    X5                   OBJ 0
    X5                   R0 49
    X5                   R1 43
    X5                   R2 49
    X5                   R3 19
    X5                   R4 53
    X5                   R5 10
    X5                   R6 18
    X5                   R7 20
    X5                   R8 51
    X5                   R9 33
    X5                   R10 44
    X5                   R11 33
    X5                   R12 45
    X5                   R13 31
    X5                   R14 28
    X6                   OBJ 0
    X6                   R0 26
    X6                   R1 42
    X6                   R2 21
    X6                   R3 19
    X6                   R4 54
    X6                   R5 26
    X6                   R6 21
    X6                   R7 11
    X6                   R8 13
    X6                   R9 14
    X6                   R10 22
    X6                   R11 6
    X6                   R12 37
    X6                   R13 34
    X6                   R14 16
    X7                   OBJ 0
    X7                   R0 37
    X7                   R1 14
    X7                   R2 38
    X7                   R3 30
    X7                   R4 29
    X7                   R5 32
    X7                   R6 24
    X7                   R7 32
    X7                   R8 22
    X7                   R9 40
    X7                   R10 10
    X7                   R11 24
    X7                   R12 16
    X7                   R13 32
    X7                   R14 32
    X8                   OBJ 0
    X8                   R0 45
    X8                   R1 48
    X8                   R2 11
    X8                   R3 48
    X8                   R4 24
    X8                   R5 54
    X8                   R6 46
    X8                   R7 52
    X8                   R8 20
    X8                   R9 53
    X8                   R10 21
    X8                   R11 54
    X8                   R12 19
    X8                   R13 23
    X8                   R14 15
    X9                   OBJ 0
    X9                   R0 21
    X9                   R1 16
    X9                   R2 26
    X9                   R3 32
    X9                   R4 11
    X9                   R5 26
    X9                   R6 47
    X9                   R7 24
    X9                   R8 24
    X9                   R9 14
    X9                   R10 5
    X9                   R11 9
    X9                   R12 5
    X9                   R13 38
    X9                   R14 11
    X10                  OBJ 0
    X10                  R0 6
    X10                  R1 23
    X10                  R2 12
    X10                  R3 30
    X10                  R4 47
    X10                  R5 52
    X10                  R6 6
    X10                  R7 31
    X10                  R8 45
    X10                  R9 23
    X10                  R10 10
    X10                  R11 12
    X10                  R12 44
    X10                  R13 32
    X10                  R14 8
    X11                  OBJ 0
    X11                  R0 48
    X11                  R1 25
    X11                  R2 30
    X11                  R3 26
    X11                  R4 24
    X11                  R5 34
    X11                  R6 48
    X11                  R7 45
    X11                  R8 30
    X11                  R9 37
    X11                  R10 35
    X11                  R11 48
    X11                  R12 45
    X11                  R13 40
    X11                  R14 21
    X12                  OBJ 0
    X12                  R0 38
    X12                  R1 36
    X12                  R2 18
    X12                  R3 39
    X12                  R4 34
    X12                  R5 24
    X12                  R6 27
    X12                  R7 50
    X12                  R8 51
    X12                  R9 9
    X12                  R10 17
    X12                  R11 51
    X12                  R12 53
    X12                  R13 30
    X12                  R14 33
    X13                  OBJ 0
    X13                  R0 37
    X13                  R1 54
    X13                  R2 23
    X13                  R3 47
    X13                  R4 29
    X13                  R5 21
    X13                  R6 10
    X13                  R7 47
    X13                  R8 24
    X13                  R9 14
    X13                  R10 20
    X13                  R11 16
    X13                  R12 22
    X13                  R13 14
    X13                  R14 15
    X14                  OBJ 0
    X14                  R0 10
    X14                  R1 34
    X14                  R2 8
    X14                  R3 37
    X14                  R4 49
    X14                  R5 39
    X14                  R6 26
    X14                  R7 6
    X14                  R8 17
    X14                  R9 38
    X14                  R10 33
    X14                  R11 48
    X14                  R12 40
    X14                  R13 19
    X14                  R14 54
    X15                  OBJ 0
    X15                  R0 16
    X15                  R1 45
    X15                  R2 55
    X15                  R3 52
    X15                  R4 50
    X15                  R5 41
    X15                  R6 6
    X15                  R7 15
    X15                  R8 23
    X15                  R9 19
    X15                  R10 27
    X15                  R11 8
    X15                  R12 47
    X15                  R13 37
    X15                  R14 22
    X16                  OBJ 0
    X16                  R0 35
    X16                  R1 51
    X16                  R2 46
    X16                  R3 33
    X16                  R4 39
    X16                  R5 47
    X16                  R6 36
    X16                  R7 53
    X16                  R8 22
    X16                  R9 24
    X16                  R10 39
    X16                  R11 21
    X16                  R12 55
    X16                  R13 48
    X16                  R14 55
    X17                  OBJ 0
    X17                  R0 17
    X17                  R1 45
    X17                  R2 5
    X17                  R3 5
    X17                  R4 50
    X17                  R5 36
    X17                  R6 52
    X17                  R7 20
    X17                  R8 29
    X17                  R9 29
    X17                  R10 50
    X17                  R11 54
    X17                  R12 43
    X17                  R13 36
    X17                  R14 13
    X18                  OBJ 0
    X18                  R0 7
    X18                  R1 46
    X18                  R2 10
    X18                  R3 39
    X18                  R4 36
    X18                  R5 27
    X18                  R6 14
    X18                  R7 24
    X18                  R8 36
    X18                  R9 55
    X18                  R10 17
    X18                  R11 46
    X18                  R12 34
    X18                  R13 33
    X18                  R14 47
    X19                  OBJ 0
    X19                  R0 46
    X19                  R1 30
    X19                  R2 50
    X19                  R3 34
    X19                  R4 32
    X19                  R5 52
    X19                  R6 29
    X19                  R7 31
    X19                  R8 14
    X19                  R9 29
    X19                  R10 11
    X19                  R11 39
    X19                  R12 33
    X19                  R13 27
    X19                  R14 19
    X20                  OBJ 0
    X20                  R0 26
    X20                  R1 38
    X20                  R2 52
    X20                  R3 42
    X20                  R4 42
    X20                  R5 7
    X20                  R6 43
    X20                  R7 40
    X20                  R8 33
    X20                  R9 40
    X20                  R10 25
    X20                  R11 23
    X20                  R12 6
    X20                  R13 20
    X20                  R14 33
    X21                  OBJ 0
    X21                  R0 8
    X21                  R1 52
    X21                  R2 45
    X21                  R3 30
    X21                  R4 55
    X21                  R5 6
    X21                  R6 7
    X21                  R7 54
    X21                  R8 51
    X21                  R9 52
    X21                  R10 42
    X21                  R11 11
    X21                  R12 13
    X21                  R13 14
    X21                  R14 35
    X22                  OBJ 0
    X22                  R0 40
    X22                  R1 21
    X22                  R2 42
    X22                  R3 33
    X22                  R4 21
    X22                  R5 52
    X22                  R6 8
    X22                  R7 10
    X22                  R8 17
    X22                  R9 54
    X22                  R10 50
    X22                  R11 28
    X22                  R12 15
    X22                  R13 50
    X22                  R14 15
    X23                  OBJ 0
    X23                  R0 19
    X23                  R1 9
    X23                  R2 43
    X23                  R3 19
    X23                  R4 11
    X23                  R5 13
    X23                  R6 26
    X23                  R7 40
    X23                  R8 35
    X23                  R9 16
    X23                  R10 19
    X23                  R11 27
    X23                  R12 36
    X23                  R13 54
    X23                  R14 44
    X24                  OBJ 0
    X24                  R0 33
    X24                  R1 21
    X24                  R2 19
    X24                  R3 21
    X24                  R4 24
    X24                  R5 30
    X24                  R6 31
    X24                  R7 30
    X24                  R8 31
    X24                  R9 23
    X24                  R10 40
    X24                  R11 21
    X24                  R12 41
    X24                  R13 34
    X24                  R14 55
    X25                  OBJ 0
    X25                  R0 5
    X25                  R1 15
    X25                  R2 25
    X25                  R3 38
    X25                  R4 45
    X25                  R5 32
    X25                  R6 10
    X25                  R7 50
    X25                  R8 39
    X25                  R9 8
    X25                  R10 37
    X25                  R11 30
    X25                  R12 39
    X25                  R13 50
    X25                  R14 39
    X26                  OBJ 0
    X26                  R0 42
    X26                  R1 22
    X26                  R2 8
    X26                  R3 40
    X26                  R4 10
    X26                  R5 46
    X26                  R6 6
    X26                  R7 14
    X26                  R8 12
    X26                  R9 53
    X26                  R10 38
    X26                  R11 38
    X26                  R12 50
    X26                  R13 14
    X26                  R14 28
    X27                  OBJ 0
    X27                  R0 22
    X27                  R1 12
    X27                  R2 27
    X27                  R3 9
    X27                  R4 30
    X27                  R5 41
    X27                  R6 7
    X27                  R7 44
    X27                  R8 47
    X27                  R9 23
    X27                  R10 22
    X27                  R11 52
    X27                  R12 38
    X27                  R13 54
    X27                  R14 39
    X28                  OBJ 0
    X28                  R0 14
    X28                  R1 12
    X28                  R2 5
    X28                  R3 33
    X28                  R4 42
    X28                  R5 12
    X28                  R6 12
    X28                  R7 41
    X28                  R8 9
    X28                  R9 9
    X28                  R10 20
    X28                  R11 18
    X28                  R12 18
    X28                  R13 9
    X28                  R14 23
    X29                  OBJ 0
    X29                  R0 51
    X29                  R1 19
    X29                  R2 41
    X29                  R3 48
    X29                  R4 38
    X29                  R5 44
    X29                  R6 33
    X29                  R7 42
    X29                  R8 46
    X29                  R9 52
    X29                  R10 5
    X29                  R11 43
    X29                  R12 36
    X29                  R13 37
    X29                  R14 6
    X30                  OBJ 0
    X30                  R0 49
    X30                  R1 17
    X30                  R2 39
    X30                  R3 35
    X30                  R4 51
    X30                  R5 7
    X30                  R6 42
    X30                  R7 29
    X30                  R8 46
    X30                  R9 52
    X30                  R10 16
    X30                  R11 46
    X30                  R12 6
    X30                  R13 55
    X30                  R14 20
    X31                  OBJ 0
    X31                  R0 7
    X31                  R1 38
    X31                  R2 52
    X31                  R3 42
    X31                  R4 6
    X31                  R5 12
    X31                  R6 41
    X31                  R7 8
    X31                  R8 55
    X31                  R9 37
    X31                  R10 22
    X31                  R11 42
    X31                  R12 13
    X31                  R13 55
    X31                  R14 36
    X32                  OBJ 0
    X32                  R0 10
    X32                  R1 17
    X32                  R2 33
    X32                  R3 26
    X32                  R4 48
    X32                  R5 32
    X32                  R6 37
    X32                  R7 24
    X32                  R8 25
    X32                  R9 33
    X32                  R10 25
    X32                  R11 29
    X32                  R12 47
    X32                  R13 42
    X32                  R14 29
    X33                  OBJ 0
    X33                  R0 30
    X33                  R1 9
    X33                  R2 17
    X33                  R3 13
    X33                  R4 5
    X33                  R5 30
    X33                  R6 17
    X33                  R7 16
    X33                  R8 55
    X33                  R9 39
    X33                  R10 8
    X33                  R11 23
    X33                  R12 8
    X33                  R13 51
    X33                  R14 12
    X34                  OBJ 0
    X34                  R0 14
    X34                  R1 30
    X34                  R2 5
    X34                  R3 23
    X34                  R4 25
    X34                  R5 38
    X34                  R6 55
    X34                  R7 27
    X34                  R8 38
    X34                  R9 55
    X34                  R10 43
    X34                  R11 32
    X34                  R12 5
    X34                  R13 32
    X34                  R14 48
    X35                  OBJ 0
    X35                  R0 32
    X35                  R1 24
    X35                  R2 34
    X35                  R3 55
    X35                  R4 36
    X35                  R5 6
    X35                  R6 48
    X35                  R7 15
    X35                  R8 39
    X35                  R9 18
    X35                  R10 50
    X35                  R11 31
    X35                  R12 22
    X35                  R13 10
    X35                  R14 6
    X36                  OBJ 0
    X36                  R0 24
    X36                  R1 48
    X36                  R2 11
    X36                  R3 27
    X36                  R4 53
    X36                  R5 36
    X36                  R6 31
    X36                  R7 31
    X36                  R8 51
    X36                  R9 17
    X36                  R10 47
    X36                  R11 52
    X36                  R12 48
    X36                  R13 26
    X36                  R14 35
    X37                  OBJ 0
    X37                  R0 36
    X37                  R1 16
    X37                  R2 21
    X37                  R3 37
    X37                  R4 24
    X37                  R5 8
    X37                  R6 20
    X37                  R7 34
    X37                  R8 46
    X37                  R9 14
    X37                  R10 9
    X37                  R11 33
    X37                  R12 37
    X37                  R13 11
    X37                  R14 8
    X38                  OBJ 0
    X38                  R0 14
    X38                  R1 34
    X38                  R2 16
    X38                  R3 30
    X38                  R4 10
    X38                  R5 34
    X38                  R6 17
    X38                  R7 42
    X38                  R8 6
    X38                  R9 54
    X38                  R10 5
    X38                  R11 51
    X38                  R12 34
    X38                  R13 38
    X38                  R14 33
    X39                  OBJ 0
    X39                  R0 13
    X39                  R1 41
    X39                  R2 17
    X39                  R3 20
    X39                  R4 22
    X39                  R5 34
    X39                  R6 21
    X39                  R7 28
    X39                  R8 15
    X39                  R9 14
    X39                  R10 12
    X39                  R11 50
    X39                  R12 11
    X39                  R13 45
    X39                  R14 46
    X40                  OBJ 0
    X40                  R0 52
    X40                  R1 28
    X40                  R2 42
    X40                  R3 14
    X40                  R4 31
    X40                  R5 30
    X40                  R6 11
    X40                  R7 53
    X40                  R8 15
    X40                  R9 24
    X40                  R10 10
    X40                  R11 38
    X40                  R12 38
    X40                  R13 44
    X40                  R14 15
    X41                  OBJ 0
    X41                  R0 16
    X41                  R1 52
    X41                  R2 23
    X41                  R3 5
    X41                  R4 53
    X41                  R5 31
    X41                  R6 19
    X41                  R7 17
    X41                  R8 47
    X41                  R9 21
    X41                  R10 10
    X41                  R11 7
    X41                  R12 22
    X41                  R13 14
    X41                  R14 37
    X42                  OBJ 0
    X42                  R0 5
    X42                  R1 10
    X42                  R2 43
    X42                  R3 42
    X42                  R4 41
    X42                  R5 13
    X42                  R6 13
    X42                  R7 18
    X42                  R8 40
    X42                  R9 46
    X42                  R10 42
    X42                  R11 42
    X42                  R12 52
    X42                  R13 30
    X42                  R14 11
    X43                  OBJ 0
    X43                  R0 35
    X43                  R1 8
    X43                  R2 5
    X43                  R3 49
    X43                  R4 10
    X43                  R5 49
    X43                  R6 34
    X43                  R7 48
    X43                  R8 10
    X43                  R9 28
    X43                  R10 22
    X43                  R11 34
    X43                  R12 35
    X43                  R13 19
    X43                  R14 44
    X44                  OBJ 0
    X44                  R0 48
    X44                  R1 51
    X44                  R2 42
    X44                  R3 47
    X44                  R4 26
    X44                  R5 47
    X44                  R6 24
    X44                  R7 8
    X44                  R8 15
    X44                  R9 30
    X44                  R10 25
    X44                  R11 18
    X44                  R12 39
    X44                  R13 24
    X44                  R14 48
    X45                  OBJ 0
    X45                  R0 11
    X45                  R1 40
    X45                  R2 47
    X45                  R3 24
    X45                  R4 35
    X45                  R5 48
    X45                  R6 35
    X45                  R7 19
    X45                  R8 52
    X45                  R9 29
    X45                  R10 20
    X45                  R11 35
    X45                  R12 37
    X45                  R13 44
    X45                  R14 9
    X46                  OBJ 0
    X46                  R0 47
    X46                  R1 48
    X46                  R2 55
    X46                  R3 45
    X46                  R4 55
    X46                  R5 35
    X46                  R6 35
    X46                  R7 7
    X46                  R8 29
    X46                  R9 43
    X46                  R10 45
    X46                  R11 37
    X46                  R12 27
    X46                  R13 52
    X46                  R14 11
    X47                  OBJ 0
    X47                  R0 27
    X47                  R1 46
    X47                  R2 32
    X47                  R3 25
    X47                  R4 10
    X47                  R5 39
    X47                  R6 55
    X47                  R7 6
    X47                  R8 32
    X47                  R9 50
    X47                  R10 9
    X47                  R11 35
    X47                  R12 38
    X47                  R13 16
    X47                  R14 47
    X48                  OBJ 0
    X48                  R0 24
    X48                  R1 30
    X48                  R2 47
    X48                  R3 24
    X48                  R4 29
    X48                  R5 29
    X48                  R6 31
    X48                  R7 35
    X48                  R8 26
    X48                  R9 53
    X48                  R10 15
    X48                  R11 33
    X48                  R12 24
    X48                  R13 24
    X48                  R14 18
    X49                  OBJ 0
    X49                  R0 49
    X49                  R1 38
    X49                  R2 9
    X49                  R3 28
    X49                  R4 36
    X49                  R5 6
    X49                  R6 44
    X49                  R7 27
    X49                  R8 10
    X49                  R9 43
    X49                  R10 7
    X49                  R11 28
    X49                  R12 5
    X49                  R13 29
    X49                  R14 54
    X50                  OBJ 0
    X50                  R0 17
    X50                  R1 21
    X50                  R2 26
    X50                  R3 54
    X50                  R4 37
    X50                  R5 35
    X50                  R6 29
    X50                  R7 33
    X50                  R8 42
    X50                  R9 24
    X50                  R10 15
    X50                  R11 18
    X50                  R12 16
    X50                  R13 39
    X50                  R14 10
    X51                  OBJ 0
    X51                  R0 46
    X51                  R1 12
    X51                  R2 43
    X51                  R3 11
    X51                  R4 15
    X51                  R5 32
    X51                  R6 19
    X51                  R7 20
    X51                  R8 55
    X51                  R9 38
    X51                  R10 35
    X51                  R11 52
    X51                  R12 25
    X51                  R13 39
    X51                  R14 46
    X52                  OBJ 0
    X52                  R0 53
    X52                  R1 35
    X52                  R2 50
    X52                  R3 53
    X52                  R4 36
    X52                  R5 7
    X52                  R6 46
    X52                  R7 25
    X52                  R8 6
    X52                  R9 39
    X52                  R10 44
    X52                  R11 34
    X52                  R12 14
    X52                  R13 39
    X52                  R14 34
    X53                  OBJ 0
    X53                  R0 53
    X53                  R1 38
    X53                  R2 13
    X53                  R3 32
    X53                  R4 54
    X53                  R5 32
    X53                  R6 33
    X53                  R7 39
    X53                  R8 54
    X53                  R9 22
    X53                  R10 9
    X53                  R11 42
    X53                  R12 27
    X53                  R13 33
    X53                  R14 20
    X54                  OBJ 0
    X54                  R0 10
    X54                  R1 17
    X54                  R2 30
    X54                  R3 25
    X54                  R4 22
    X54                  R5 40
    X54                  R6 41
    X54                  R7 55
    X54                  R8 34
    X54                  R9 49
    X54                  R10 50
    X54                  R11 24
    X54                  R12 6
    X54                  R13 37
    X54                  R14 35
    X55                  OBJ 0
    X55                  R0 30
    X55                  R1 52
    X55                  R2 14
    X55                  R3 19
    X55                  R4 55
    X55                  R5 33
    X55                  R6 22
    X55                  R7 51
    X55                  R8 32
    X55                  R9 7
    X55                  R10 28
    X55                  R11 51
    X55                  R12 51
    X55                  R13 17
    X55                  R14 33
    X56                  OBJ 0
    X56                  R0 1
    X56                  R15 -1
    X57                  OBJ 0
    X57                  R0 -1
    X57                  R16 -1
    X58                  OBJ 0
    X58                  R1 1
    X58                  R17 -1
    X59                  OBJ 0
    X59                  R1 -1
    X59                  R18 -1
    X60                  OBJ 0
    X60                  R2 1
    X60                  R19 -1
    X61                  OBJ 0
    X61                  R2 -1
    X61                  R20 -1
    X62                  OBJ 0
    X62                  R3 1
    X62                  R21 -1
    X63                  OBJ 0
    X63                  R3 -1
    X63                  R22 -1
    X64                  OBJ 0
    X64                  R4 1
    X64                  R23 -1
    X65                  OBJ 0
    X65                  R4 -1
    X65                  R24 -1
    X66                  OBJ 0
    X66                  R5 1
    X66                  R25 -1
    X67                  OBJ 0
    X67                  R5 -1
    X67                  R26 -1
    X68                  OBJ 0
    X68                  R6 1
    X68                  R27 -1
    X69                  OBJ 0
    X69                  R6 -1
    X69                  R28 -1
    X70                  OBJ 0
    X70                  R7 1
    X70                  R29 -1
    X71                  OBJ 0
    X71                  R7 -1
    X71                  R30 -1
    X72                  OBJ 0
    X72                  R8 1
    X72                  R31 -1
    X73                  OBJ 0
    X73                  R8 -1
    X73                  R32 -1
    X74                  OBJ 0
    X74                  R9 1
    X74                  R33 -1
    X75                  OBJ 0
    X75                  R9 -1
    X75                  R34 -1
    X76                  OBJ 0
    X76                  R10 1
    X76                  R35 -1
    X77                  OBJ 0
    X77                  R10 -1
    X77                  R36 -1
    X78                  OBJ 0
    X78                  R11 1
    X78                  R37 -1
    X79                  OBJ 0
    X79                  R11 -1
    X79                  R38 -1
    X80                  OBJ 0
    X80                  R12 1
    X80                  R39 -1
    X81                  OBJ 0
    X81                  R12 -1
    X81                  R40 -1
    X82                  OBJ 0
    X82                  R13 1
    X82                  R41 -1
    X83                  OBJ 0
    X83                  R13 -1
    X83                  R42 -1
    X84                  OBJ 0
    X84                  R14 1
    X84                  R43 -1
    X85                  OBJ 0
    X85                  R14 -1
    X85                  R44 -1
RHS
    RHS                  OBJ -0
    RHS                  R0 731
    RHS                  R1 731
    RHS                  R2 731
    RHS                  R3 731
    RHS                  R4 731
    RHS                  R5 731
    RHS                  R6 731
    RHS                  R7 731
    RHS                  R8 731
    RHS                  R9 731
    RHS                  R10 731
    RHS                  R11 731
    RHS                  R12 731
    RHS                  R13 731
    RHS                  R14 731
    RHS                  R15 0
    RHS                  R16 0
    RHS                  R17 0
    RHS                  R18 0
    RHS                  R19 0
    RHS                  R20 0
    RHS                  R21 0
    RHS                  R22 0
    RHS                  R23 0
    RHS                  R24 0
    RHS                  R25 0
    RHS                  R26 0
    RHS                  R27 0
    RHS                  R28 0
    RHS                  R29 0
    RHS                  R30 0
    RHS                  R31 0
    RHS                  R32 0
    RHS                  R33 0
    RHS                  R34 0
    RHS                  R35 0
    RHS                  R36 0
    RHS                  R37 0
    RHS                  R38 0
    RHS                  R39 0
    RHS                  R40 0
    RHS                  R41 0
    RHS                  R42 0
    RHS                  R43 0
    RHS                  R44 0
BOUNDS
 	FR BND X0
 	LO BND X0 0
 	FR BND X1
 	LO BND X1 0
 	UP BND X1 1
 	FR BND X2
 	LO BND X2 0
 	UP BND X2 1
 	FR BND X3
 	LO BND X3 0
 	UP BND X3 1
 	FR BND X4
 	LO BND X4 0
 	UP BND X4 1
 	FR BND X5
 	LO BND X5 0
 	UP BND X5 1
 	FR BND X6
 	LO BND X6 0
 	UP BND X6 1
 	FR BND X7
 	LO BND X7 0
 	UP BND X7 1
 	FR BND X8
 	LO BND X8 0
 	UP BND X8 1
 	FR BND X9
 	LO BND X9 0
 	UP BND X9 1
 	FR BND X10
 	LO BND X10 0
 	UP BND X10 1
 	FR BND X11
 	LO BND X11 0
 	UP BND X11 1
 	FR BND X12
 	LO BND X12 0
 	UP BND X12 1
 	FR BND X13
 	LO BND X13 0
 	UP BND X13 1
 	FR BND X14
 	LO BND X14 0
 	UP BND X14 1
 	FR BND X15
 	LO BND X15 0
 	UP BND X15 1
 	FR BND X16
 	LO BND X16 0
 	UP BND X16 1
 	FR BND X17
 	LO BND X17 0
 	UP BND X17 1
 	FR BND X18
 	LO BND X18 0
 	UP BND X18 1
 	FR BND X19
 	LO BND X19 0
 	UP BND X19 1
 	FR BND X20
 	LO BND X20 0
 	UP BND X20 1
 	FR BND X21
 	LO BND X21 0
 	UP BND X21 1
 	FR BND X22
 	LO BND X22 0
 	UP BND X22 1
 	FR BND X23
 	LO BND X23 0
 	UP BND X23 1
 	FR BND X24
 	LO BND X24 0
 	UP BND X24 1
 	FR BND X25
 	LO BND X25 0
 	UP BND X25 1
 	FR BND X26
 	LO BND X26 0
 	UP BND X26 1
 	FR BND X27
 	LO BND X27 0
 	UP BND X27 1
 	FR BND X28
 	LO BND X28 0
 	UP BND X28 1
 	FR BND X29
 	LO BND X29 0
 	UP BND X29 1
 	FR BND X30
 	LO BND X30 0
 	UP BND X30 1
 	FR BND X31
 	LO BND X31 0
 	UP BND X31 1
 	FR BND X32
 	LO BND X32 0
 	UP BND X32 1
 	FR BND X33
 	LO BND X33 0
 	UP BND X33 1
 	FR BND X34
 	LO BND X34 0
 	UP BND X34 1
 	FR BND X35
 	LO BND X35 0
 	UP BND X35 1
 	FR BND X36
 	LO BND X36 0
 	UP BND X36 1
 	FR BND X37
 	LO BND X37 0
 	UP BND X37 1
 	FR BND X38
 	LO BND X38 0
 	UP BND X38 1
 	FR BND X39
 	LO BND X39 0
 	UP BND X39 1
 	FR BND X40
 	LO BND X40 0
 	UP BND X40 1
 	FR BND X41
 	LO BND X41 0
 	UP BND X41 1
 	FR BND X42
 	LO BND X42 0
 	UP BND X42 1
 	FR BND X43
 	LO BND X43 0
 	UP BND X43 1
 	FR BND X44
 	LO BND X44 0
 	UP BND X44 1
 	FR BND X45
 	LO BND X45 0
 	UP BND X45 1
 	FR BND X46
 	LO BND X46 0
 	UP BND X46 1
 	FR BND X47
 	LO BND X47 0
 	UP BND X47 1
 	FR BND X48
 	LO BND X48 0
 	UP BND X48 1
 	FR BND X49
 	LO BND X49 0
 	UP BND X49 1
 	FR BND X50
 	LO BND X50 0
 	UP BND X50 1
 	FR BND X51
 	LO BND X51 0
 	UP BND X51 1
 	FR BND X52
 	LO BND X52 0
 	UP BND X52 1
 	FR BND X53
 	LO BND X53 0
 	UP BND X53 1
 	FR BND X54
 	LO BND X54 0
 	UP BND X54 1
 	FR BND X55
 	LO BND X55 0
 	UP BND X55 1
 	FR BND X56
 	LO BND X56 0
 	FR BND X57
 	LO BND X57 0
 	FR BND X58
 	LO BND X58 0
 	FR BND X59
 	LO BND X59 0
 	FR BND X60
 	LO BND X60 0
 	FR BND X61
 	LO BND X61 0
 	FR BND X62
 	LO BND X62 0
 	FR BND X63
 	LO BND X63 0
 	FR BND X64
 	LO BND X64 0
 	FR BND X65
 	LO BND X65 0
 	FR BND X66
 	LO BND X66 0
 	FR BND X67
 	LO BND X67 0
 	FR BND X68
 	LO BND X68 0
 	FR BND X69
 	LO BND X69 0
 	FR BND X70
 	LO BND X70 0
 	FR BND X71
 	LO BND X71 0
 	FR BND X72
 	LO BND X72 0
 	FR BND X73
 	LO BND X73 0
 	FR BND X74
 	LO BND X74 0
 	FR BND X75
 	LO BND X75 0
 	FR BND X76
 	LO BND X76 0
 	FR BND X77
 	LO BND X77 0
 	FR BND X78
 	LO BND X78 0
 	FR BND X79
 	LO BND X79 0
 	FR BND X80
 	LO BND X80 0
 	FR BND X81
 	LO BND X81 0
 	FR BND X82
 	LO BND X82 0
 	FR BND X83
 	LO BND X83 0
 	FR BND X84
 	LO BND X84 0
 	FR BND X85
 	LO BND X85 0
ENDATA
