* MIPLIB 2017 benchmark v2; LP relaxation (integrality removed).
* Source: https://miplib.zib.de/downloads/benchmark.zip ; retrieved 2026-09-21
* Instance: markshare_4_0 ; Gleixner et al. (2021), doi:10.1007/s12532-020-00194-3
* Bounds and coefficients preserved; rows/variables renamed; objective minimized.
* Original compressed SHA256: 1a1feb04f5637db9f69be53bd6224fcd9fe5b8d750870d9b2002b535d25f4353
NAME markshare_4_0
ROWS
 N OBJ
 E R0
 E R1
 E R2
 E R3
COLUMNS
    X0                   OBJ 1
    X0                   R0 1
    X1                   OBJ 1
    X1                   R1 1
    X2                   OBJ 1
    X2                   R2 1
    X3                   OBJ 1
    X3                   R3 1
    X4                   OBJ 0
    X4                   R0 17
    X4                   R1 93
    X4                   R2 46
    X4                   R3 2
    X5                   OBJ 0
    X5                   R0 75
    X5                   R1 44
    X5                   R2 63
    X5                   R3 77
    X6                   OBJ 0
    X6                   R0 9
    X6                   R1 79
    X6                   R2 13
    X6                   R3 73
    X7                   OBJ 0
    X7                   R0 87
    X7                   R1 12
    X7                   R2 97
    X7                   R3 59
    X8                   OBJ 0
    X8                   R0 58
    X8                   R1 8
    X8                   R2 14
    X8                   R3 43
    X9                   OBJ 0
    X9                   R0 79
    X9                   R1 95
    X9                   R2 45
    X9                   R3 64
    X10                  OBJ 0
    X10                  R0 69
    X10                  R1 2
    X10                  R2 32
    X10                  R3 75
    X11                  OBJ 0
    X11                  R0 37
    X11                  R1 15
    X11                  R2 96
    X11                  R3 6
    X12                  OBJ 0
    X12                  R0 88
    X12                  R1 38
    X12                  R2 36
    X12                  R3 5
    X13                  OBJ 0
    X13                  R0 75
    X13                  R1 15
    X13                  R2 40
    X13                  R3 78
    X14                  OBJ 0
    X14                  R0 45
    X14                  R1 53
    X14                  R2 10
    X14                  R3 71
    X15                  OBJ 0
    X15                  R0 35
    X15                  R1 88
    X15                  R2 96
    X15                  R3 12
    X16                  OBJ 0
    X16                  R0 73
    X16                  R1 43
    X16                  R2 99
    X16                  R3 30
    X17                  OBJ 0
    X17                  R0 26
    X17                  R1 26
    X17                  R2 58
    X17                  R3 7
    X18                  OBJ 0
    X18                  R0 39
    X18                  R1 31
    X18                  R2 87
    X18                  R3 69
    X19                  OBJ 0
    X19                  R0 78
    X19                  R1 77
    X19                  R2 15
    X19                  R3 36
    X20                  OBJ 0
    X20                  R0 85
    X20                  R1 10
    X20                  R2 91
    X20                  R3 73
    X21                  OBJ 0
    X21                  R0 58
    X21                  R1 77
    X21                  R2 65
    X21                  R3 19
    X22                  OBJ 0
    X22                  R0 72
    X22                  R1 71
    X22                  R2 6
    X22                  R3 15
    X23                  OBJ 0
    X23                  R0 8
    X23                  R1 22
    X23                  R2 96
    X23                  R3 16
    X24                  OBJ 0
    X24                  R0 46
    X24                  R1 76
    X24                  R2 97
    X24                  R3 84
    X25                  OBJ 0
    X25                  R0 11
    X25                  R1 41
    X25                  R2 79
    X25                  R3 55
    X26                  OBJ 0
    X26                  R0 55
    X26                  R1 65
    X26                  R2 81
    X26                  R3 32
    X27                  OBJ 0
    X27                  R0 39
    X27                  R1 93
    X27                  R2 57
    X27                  R3 53
    X28                  OBJ 0
    X28                  R0 57
    X28                  R1 50
    X28                  R2 28
    X28                  R3 43
    X29                  OBJ 0
    X29                  R0 96
    X29                  R1 69
    X29                  R2 97
    X29                  R3 21
    X30                  OBJ 0
    X30                  R0 87
    X30                  R1 44
    X30                  R2 58
    X30                  R3 73
    X31                  OBJ 0
    X31                  R0 16
    X31                  R1 61
    X31                  R2 44
    X32                  OBJ 0
    X32                  R0 27
    X32                  R1 58
    X32                  R2 37
    X32                  R3 59
    X33                  OBJ 0
    X33                  R0 26
    X33                  R1 63
    X33                  R2 93
    X33                  R3 48
RHS
    RHS                  OBJ -0
    RHS                  R0 786
    RHS                  R1 759
    RHS                  R2 888
    RHS                  R3 649
BOUNDS
 	FR BND X0
 	LO BND X0 0
 	FR BND X1
 	LO BND X1 0
 	FR BND X2
 	LO BND X2 0
 	FR BND X3
 	LO BND X3 0
 	FR BND X4
 	LO BND X4 0
 	UP BND X4 1
 	FR BND X5
 	LO BND X5 0
 	UP BND X5 1
 	FR BND X6
 	LO BND X6 0
 	UP BND X6 1
 	FR BND X7
 	LO BND X7 0
 	UP BND X7 1
 	FR BND X8
 	LO BND X8 0
 	UP BND X8 1
 	FR BND X9
 	LO BND X9 0
 	UP BND X9 1
 	FR BND X10
 	LO BND X10 0
 	UP BND X10 1
 	FR BND X11
 	LO BND X11 0
 	UP BND X11 1
 	FR BND X12
 	LO BND X12 0
 	UP BND X12 1
 	FR BND X13
 	LO BND X13 0
 	UP BND X13 1
 	FR BND X14
 	LO BND X14 0
 	UP BND X14 1
 	FR BND X15
 	LO BND X15 0
 	UP BND X15 1
 	FR BND X16
 	LO BND X16 0
 	UP BND X16 1
 	FR BND X17
 	LO BND X17 0
 	UP BND X17 1
 	FR BND X18
 	LO BND X18 0
 	UP BND X18 1
 	FR BND X19
 	LO BND X19 0
 	UP BND X19 1
 	FR BND X20
 	LO BND X20 0
 	UP BND X20 1
 	FR BND X21
 	LO BND X21 0
 	UP BND X21 1
 	FR BND X22
 	LO BND X22 0
 	UP BND X22 1
 	FR BND X23
 	LO BND X23 0
 	UP BND X23 1
 	FR BND X24
 	LO BND X24 0
 	UP BND X24 1
 	FR BND X25
 	LO BND X25 0
 	UP BND X25 1
 	FR BND X26
 	LO BND X26 0
 	UP BND X26 1
 	FR BND X27
 	LO BND X27 0
 	UP BND X27 1
 	FR BND X28
 	LO BND X28 0
 	UP BND X28 1
 	FR BND X29
 	LO BND X29 0
 	UP BND X29 1
 	FR BND X30
 	LO BND X30 0
 	UP BND X30 1
 	FR BND X31
 	LO BND X31 0
 	UP BND X31 1
 	FR BND X32
 	LO BND X32 0
 	UP BND X32 1
 	FR BND X33
 	LO BND X33 0
 	UP BND X33 1
ENDATA
