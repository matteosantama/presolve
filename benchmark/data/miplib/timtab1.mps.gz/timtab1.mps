* MIPLIB 2017 benchmark v2; LP relaxation (integrality removed).
* Source: https://miplib.zib.de/downloads/benchmark.zip ; retrieved 2026-09-21
* Instance: timtab1 ; Gleixner et al. (2021), doi:10.1007/s12532-020-00194-3
* Bounds and coefficients preserved; rows/variables renamed; objective minimized.
* Original compressed SHA256: 5867d1a9c1067a849211c1a61bdb8839fb0025255dde09989d0ed333e0674d7a
NAME timtab1
ROWS
 N OBJ
 E R0
 E R1
 E R2
 E R3
 E R4
 E R5
 E R6
 E R7
 E R8
 E R9
 E R10
 E R11
 E R12
 E R13
 E R14
 E R15
 E R16
 E R17
 E R18
 E R19
 E R20
 E R21
 E R22
 E R23
 E R24
 E R25
 E R26
 E R27
 E R28
 E R29
 E R30
 E R31
 E R32
 E R33
 E R34
 E R35
 E R36
 E R37
 E R38
 E R39
 E R40
 E R41
 E R42
 E R43
 E R44
 E R45
 E R46
 E R47
 E R48
 E R49
 E R50
 E R51
 E R52
 E R53
 E R54
 E R55
 E R56
 E R57
 E R58
 E R59
 E R60
 E R61
 E R62
 E R63
 E R64
 E R65
 E R66
 E R67
 E R68
 E R69
 E R70
 E R71
 E R72
 E R73
 E R74
 E R75
 E R76
 E R77
 E R78
 E R79
 E R80
 E R81
 E R82
 E R83
 E R84
 E R85
 E R86
 E R87
 E R88
 E R89
 E R90
 E R91
 E R92
 E R93
 E R94
 E R95
 E R96
 E R97
 E R98
 E R99
 E R100
 E R101
 E R102
 E R103
 E R104
 E R105
 E R106
 E R107
 E R108
 E R109
 E R110
 E R111
 E R112
 E R113
 E R114
 E R115
 E R116
 E R117
 E R118
 E R119
 E R120
 E R121
 E R122
 E R123
 E R124
 E R125
 E R126
 E R127
 E R128
 E R129
 E R130
 E R131
 E R132
 E R133
 E R134
 E R135
 E R136
 E R137
 E R138
 E R139
 E R140
 E R141
 E R142
 E R143
 E R144
 E R145
 E R146
 E R147
 E R148
 E R149
 E R150
 E R151
 E R152
 E R153
 E R154
 E R155
 E R156
 E R157
 E R158
 E R159
 E R160
 E R161
 E R162
 E R163
 E R164
 E R165
 E R166
 E R167
 E R168
 E R169
 E R170
COLUMNS
    X0                   OBJ 1001
    X0                   R0 1
    X1                   OBJ 0
    X1                   R1 -1
    X1                   R2 -1
    X1                   R124 1
    X2                   OBJ 0
    X2                   R1 1
    X3                   OBJ 1000
    X3                   R0 1
    X3                   R2 -1
    X3                   R124 1
    X4                   OBJ 1001
    X4                   R0 1
    X4                   R3 -1
    X4                   R124 1
    X5                   OBJ 0
    X5                   R2 -1
    X5                   R3 1
    X6                   OBJ 1000
    X6                   R2 1
    X7                   OBJ 1001
    X7                   R3 1
    X8                   OBJ 0
    X8                   R4 1
    X9                   OBJ 0
    X9                   R5 1
    X10                  OBJ 0
    X10                  R6 1
    X11                  OBJ 1387
    X11                  R3 1
    X11                  R4 1
    X11                  R5 -1
    X11                  R6 -1
    X12                  OBJ 0
    X12                  R7 1
    X13                  OBJ 245
    X13                  R0 1
    X13                  R3 -1
    X13                  R4 -1
    X13                  R114 -1
    X13                  R124 1
    X13                  R165 -1
    X13                  R169 -1
    X14                  OBJ 437
    X14                  R9 -1
    X14                  R91 1
    X14                  R95 -1
    X14                  R96 1
    X14                  R115 -1
    X14                  R144 -1
    X15                  OBJ 500
    X15                  R88 1
    X15                  R99 1
    X15                  R160 -1
    X15                  R163 1
    X15                  R164 1
    X16                  OBJ 500
    X16                  R8 1
    X17                  OBJ 725
    X17                  R9 1
    X18                  OBJ 0
    X18                  R10 -1
    X18                  R78 -1
    X18                  R160 1
    X18                  R161 1
    X18                  R162 -1
    X19                  OBJ 0
    X19                  R10 1
    X20                  OBJ 0
    X20                  R11 1
    X21                  OBJ 2002
    X21                  R0 1
    X21                  R5 -1
    X21                  R6 -1
    X21                  R7 1
    X21                  R8 1
    X21                  R11 -1
    X21                  R78 -1
    X21                  R88 1
    X21                  R91 1
    X21                  R95 -1
    X21                  R96 1
    X21                  R99 1
    X21                  R114 -1
    X21                  R115 -1
    X21                  R124 1
    X21                  R144 -1
    X21                  R161 1
    X21                  R162 -1
    X21                  R163 1
    X21                  R164 1
    X21                  R165 -1
    X21                  R169 -1
    X22                  OBJ 0
    X22                  R13 -1
    X22                  R14 -1
    X22                  R15 -1
    X22                  R52 -1
    X22                  R63 -1
    X22                  R102 -1
    X22                  R109 1
    X22                  R155 -1
    X22                  R157 1
    X22                  R159 -1
    X23                  OBJ 0
    X23                  R12 1
    X24                  OBJ 291
    X24                  R13 1
    X25                  OBJ 0
    X25                  R14 1
    X26                  OBJ 331
    X26                  R15 1
    X27                  OBJ 481
    X27                  R16 -1
    X27                  R105 1
    X27                  R157 -1
    X28                  OBJ 341
    X28                  R7 -1
    X28                  R11 1
    X28                  R17 -1
    X28                  R90 1
    X28                  R95 1
    X28                  R158 -1
    X28                  R162 1
    X29                  OBJ 650
    X29                  R16 1
    X30                  OBJ 520
    X30                  R17 1
    X31                  OBJ 1000
    X31                  R8 1
    X31                  R24 1
    X31                  R25 1
    X31                  R29 -1
    X31                  R30 -1
    X31                  R31 -1
    X31                  R32 -1
    X31                  R40 -1
    X31                  R41 -1
    X31                  R46 1
    X31                  R48 1
    X31                  R49 1
    X31                  R52 -1
    X31                  R53 -1
    X31                  R54 -1
    X31                  R60 -1
    X31                  R61 1
    X31                  R62 1
    X31                  R63 -1
    X31                  R64 -1
    X31                  R65 -1
    X31                  R66 -1
    X31                  R67 -1
    X31                  R68 -1
    X31                  R69 1
    X31                  R70 1
    X31                  R71 1
    X31                  R72 1
    X31                  R73 1
    X31                  R74 1
    X31                  R78 -1
    X31                  R82 -1
    X31                  R83 -1
    X31                  R86 1
    X31                  R88 1
    X31                  R90 1
    X31                  R91 1
    X31                  R98 -1
    X31                  R99 1
    X31                  R101 -1
    X31                  R102 -1
    X31                  R103 -1
    X31                  R105 1
    X31                  R122 1
    X31                  R126 1
    X31                  R128 1
    X31                  R148 1
    X31                  R149 1
    X31                  R150 1
    X31                  R161 1
    X31                  R163 1
    X31                  R164 1
    X32                  OBJ 0
    X32                  R19 -1
    X32                  R20 -1
    X32                  R48 -1
    X32                  R60 1
    X32                  R67 1
    X32                  R72 -1
    X32                  R74 -1
    X32                  R86 -1
    X32                  R98 1
    X32                  R103 1
    X32                  R111 -1
    X32                  R148 -1
    X32                  R150 -1
    X32                  R155 -1
    X32                  R156 -1
    X33                  OBJ 0
    X33                  R0 1
    X33                  R5 -1
    X33                  R6 -1
    X33                  R18 -1
    X33                  R26 1
    X33                  R46 -1
    X33                  R49 -1
    X33                  R53 1
    X33                  R61 -1
    X33                  R62 -1
    X33                  R64 1
    X33                  R65 1
    X33                  R68 1
    X33                  R70 -1
    X33                  R71 -1
    X33                  R82 1
    X33                  R96 1
    X33                  R101 1
    X33                  R109 1
    X33                  R110 1
    X33                  R111 1
    X33                  R112 1
    X33                  R114 -1
    X33                  R115 -1
    X33                  R120 1
    X33                  R122 -1
    X33                  R124 1
    X33                  R126 -1
    X33                  R128 -1
    X33                  R137 1
    X33                  R144 -1
    X33                  R145 1
    X33                  R149 -1
    X33                  R153 -1
    X33                  R154 -1
    X33                  R165 -1
    X33                  R169 -1
    X34                  OBJ 0
    X34                  R66 1
    X34                  R73 -1
    X34                  R112 -1
    X34                  R120 -1
    X34                  R137 -1
    X34                  R145 -1
    X34                  R152 1
    X34                  R153 1
    X34                  R154 1
    X35                  OBJ 0
    X35                  R18 1
    X36                  OBJ 0
    X36                  R12 1
    X36                  R54 1
    X36                  R69 -1
    X36                  R83 1
    X36                  R110 -1
    X36                  R156 1
    X36                  R158 -1
    X36                  R159 -1
    X37                  OBJ 0
    X37                  R19 1
    X38                  OBJ 250
    X38                  R20 1
    X39                  OBJ 1001
    X39                  R27 1
    X39                  R28 1
    X39                  R40 1
    X39                  R41 1
    X39                  R152 -1
    X40                  OBJ 227
    X40                  R21 -1
    X40                  R22 -1
    X40                  R23 -1
    X40                  R24 -1
    X40                  R25 -1
    X40                  R26 -1
    X40                  R27 -1
    X40                  R28 -1
    X40                  R29 1
    X40                  R30 1
    X40                  R31 1
    X40                  R32 1
    X41                  OBJ 338
    X41                  R21 1
    X42                  OBJ 0
    X42                  R22 1
    X43                  OBJ 954
    X43                  R23 1
    X44                  OBJ 0
    X44                  R24 1
    X45                  OBJ 0
    X45                  R25 1
    X46                  OBJ 2002
    X46                  R26 1
    X47                  OBJ 0
    X47                  R27 1
    X48                  OBJ 0
    X48                  R28 1
    X49                  OBJ 333.33333333000002
    X49                  R29 1
    X50                  OBJ 333.33333333000002
    X50                  R30 1
    X51                  OBJ 666.66666667000004
    X51                  R31 1
    X52                  OBJ 666.66666667000004
    X52                  R32 1
    X53                  OBJ 333.33333333000002
    X53                  R24 -1
    X53                  R25 -1
    X53                  R33 -1
    X53                  R79 1
    X53                  R151 -1
    X54                  OBJ 333.33333333000002
    X54                  R33 1
    X55                  OBJ 0
    X55                  R29 -1
    X55                  R30 -1
    X55                  R35 -1
    X55                  R97 1
    X55                  R151 -1
    X56                  OBJ 1001
    X56                  R34 1
    X57                  OBJ 0
    X57                  R35 1
    X58                  OBJ 1001
    X58                  R36 1
    X59                  OBJ 0
    X59                  R37 1
    X60                  OBJ 0
    X60                  R38 1
    X61                  OBJ 823
    X61                  R24 -1
    X61                  R25 -1
    X61                  R29 1
    X61                  R30 1
    X61                  R31 1
    X61                  R32 1
    X61                  R34 -1
    X61                  R36 -1
    X61                  R37 -1
    X61                  R38 -1
    X61                  R39 -1
    X61                  R79 1
    X61                  R97 -1
    X62                  OBJ 440
    X62                  R39 1
    X63                  OBJ 1000
    X63                  R40 1
    X64                  OBJ 1000
    X64                  R41 1
    X65                  OBJ 371
    X65                  R42 1
    X66                  OBJ 1001
    X66                  R37 1
    X66                  R38 1
    X66                  R40 1
    X66                  R41 1
    X66                  R42 -1
    X66                  R43 -1
    X67                  OBJ 1001
    X67                  R43 1
    X68                  OBJ 0
    X68                  R44 1
    X69                  OBJ 0
    X69                  R45 1
    X70                  OBJ 1001
    X70                  R46 1
    X71                  OBJ 231
    X71                  R47 1
    X72                  OBJ 0
    X72                  R48 1
    X73                  OBJ 0
    X73                  R43 1
    X73                  R44 1
    X73                  R45 1
    X73                  R46 -1
    X73                  R47 -1
    X73                  R48 -1
    X73                  R49 -1
    X73                  R50 -1
    X74                  OBJ 470
    X74                  R49 1
    X75                  OBJ 520
    X75                  R50 1
    X76                  OBJ 235
    X76                  R47 -1
    X76                  R50 -1
    X76                  R51 -1
    X76                  R52 -1
    X76                  R53 -1
    X76                  R54 -1
    X76                  R55 -1
    X76                  R56 -1
    X76                  R57 -1
    X76                  R58 -1
    X76                  R59 -1
    X76                  R60 -1
    X76                  R61 1
    X76                  R62 1
    X77                  OBJ 295
    X77                  R51 1
    X78                  OBJ 650
    X78                  R52 1
    X79                  OBJ 500
    X79                  R53 1
    X80                  OBJ 500
    X80                  R54 1
    X81                  OBJ 0
    X81                  R55 1
    X82                  OBJ 0
    X82                  R56 1
    X83                  OBJ 0
    X83                  R57 1
    X84                  OBJ 474
    X84                  R58 1
    X85                  OBJ 909
    X85                  R59 1
    X86                  OBJ 283
    X86                  R60 1
    X87                  OBJ 384
    X87                  R61 1
    X88                  OBJ 1001
    X88                  R62 1
    X89                  OBJ 0
    X89                  R63 1
    X90                  OBJ 1100
    X90                  R64 1
    X91                  OBJ 490
    X91                  R65 1
    X92                  OBJ 464
    X92                  R66 1
    X93                  OBJ 1000
    X93                  R67 1
    X94                  OBJ 0
    X94                  R78 1
    X94                  R79 -1
    X95                  OBJ 0
    X95                  R68 1
    X96                  OBJ 0
    X96                  R57 -1
    X96                  R63 1
    X96                  R64 1
    X96                  R65 1
    X96                  R66 1
    X96                  R67 1
    X96                  R68 1
    X96                  R69 -1
    X96                  R70 -1
    X96                  R71 -1
    X96                  R72 -1
    X96                  R73 -1
    X96                  R74 -1
    X96                  R75 -1
    X96                  R76 -1
    X96                  R77 -1
    X96                  R78 1
    X96                  R79 -1
    X97                  OBJ 0
    X97                  R69 1
    X98                  OBJ 0
    X98                  R70 1
    X99                  OBJ 0
    X99                  R71 1
    X100                 OBJ 0
    X100                 R72 1
    X101                 OBJ 0
    X101                 R73 1
    X102                 OBJ 1000
    X102                 R74 1
    X103                 OBJ 287
    X103                 R75 1
    X104                 OBJ 0
    X104                 R76 1
    X105                 OBJ 0
    X105                 R77 1
    X106                 OBJ 1001
    X106                 R78 1
    X107                 OBJ 1001
    X107                 R79 1
    X108                 OBJ 0
    X108                 R56 1
    X108                 R77 -1
    X108                 R80 -1
    X108                 R81 -1
    X108                 R82 -1
    X108                 R83 -1
    X108                 R84 1
    X108                 R85 1
    X108                 R86 1
    X108                 R87 1
    X109                 OBJ 520
    X109                 R80 1
    X110                 OBJ 1100
    X110                 R81 1
    X111                 OBJ 500
    X111                 R82 1
    X112                 OBJ 500
    X112                 R83 1
    X113                 OBJ 0
    X113                 R84 1
    X114                 OBJ 1001
    X114                 R85 1
    X115                 OBJ 0
    X115                 R86 1
    X116                 OBJ 0
    X116                 R87 1
    X117                 OBJ 337
    X117                 R97 1
    X117                 R98 1
    X117                 R99 -1
    X118                 OBJ 312
    X118                 R85 -1
    X118                 R88 1
    X118                 R89 1
    X118                 R90 1
    X118                 R91 1
    X118                 R97 -1
    X118                 R98 -1
    X118                 R99 1
    X119                 OBJ 0
    X119                 R88 1
    X120                 OBJ 0
    X120                 R89 1
    X121                 OBJ 0
    X121                 R90 1
    X122                 OBJ 1001
    X122                 R91 1
    X123                 OBJ 500
    X123                 R91 1
    X123                 R92 -1
    X123                 R93 -1
    X124                 OBJ 0
    X124                 R92 1
    X125                 OBJ 500
    X125                 R93 1
    X126                 OBJ 500
    X126                 R94 1
    X127                 OBJ 0
    X127                 R93 -1
    X127                 R94 -1
    X127                 R95 1
    X128                 OBJ 1001
    X128                 R95 1
    X129                 OBJ 1001
    X129                 R96 1
    X130                 OBJ 500
    X130                 R92 1
    X130                 R94 -1
    X130                 R96 1
    X131                 OBJ 1001
    X131                 R97 1
    X132                 OBJ 0
    X132                 R98 1
    X133                 OBJ 1001
    X133                 R99 1
    X134                 OBJ 0
    X134                 R55 1
    X134                 R76 -1
    X134                 R87 -1
    X134                 R100 -1
    X134                 R101 -1
    X134                 R102 -1
    X134                 R103 -1
    X134                 R104 -1
    X134                 R105 1
    X135                 OBJ 366
    X135                 R100 1
    X136                 OBJ 489
    X136                 R101 1
    X137                 OBJ 1000
    X137                 R102 1
    X138                 OBJ 0
    X138                 R103 1
    X139                 OBJ 906
    X139                 R104 1
    X140                 OBJ 1001
    X140                 R105 1
    X141                 OBJ 1001
    X141                 R106 1
    X142                 OBJ 0
    X142                 R105 1
    X142                 R106 -1
    X143                 OBJ 1000
    X143                 R106 1
    X144                 OBJ 1001
    X144                 R106 1
    X145                 OBJ 1001
    X145                 R107 1
    X146                 OBJ 232
    X146                 R108 1
    X147                 OBJ 0
    X147                 R109 1
    X148                 OBJ 0
    X148                 R110 1
    X149                 OBJ 0
    X149                 R111 1
    X150                 OBJ 0
    X150                 R53 -1
    X150                 R68 -1
    X150                 R82 -1
    X150                 R101 -1
    X150                 R107 1
    X150                 R108 1
    X150                 R109 -1
    X150                 R110 -1
    X150                 R111 -1
    X150                 R112 -1
    X150                 R113 -1
    X151                 OBJ 293
    X151                 R112 1
    X152                 OBJ 703
    X152                 R113 1
    X153                 OBJ 1001
    X153                 R114 1
    X154                 OBJ 499
    X154                 R115 1
    X155                 OBJ 0
    X155                 R116 1
    X156                 OBJ 1001
    X156                 R117 1
    X157                 OBJ 580
    X157                 R118 1
    X158                 OBJ 247
    X158                 R0 -1
    X158                 R108 -1
    X158                 R114 1
    X158                 R115 1
    X158                 R116 -1
    X158                 R117 -1
    X158                 R118 -1
    X158                 R119 -1
    X158                 R120 -1
    X158                 R121 -1
    X158                 R122 1
    X158                 R123 1
    X158                 R124 -1
    X158                 R146 1
    X158                 R170 1
    X159                 OBJ 0
    X159                 R0 1
    X159                 R125 -1
    X159                 R146 -1
    X159                 R170 -1
    X160                 OBJ 0
    X160                 R122 -1
    X160                 R123 -1
    X160                 R124 1
    X160                 R125 1
    X161                 OBJ 600
    X161                 R119 1
    X162                 OBJ 520
    X162                 R120 1
    X163                 OBJ 0
    X163                 R121 1
    X164                 OBJ 1001
    X164                 R122 1
    X165                 OBJ 0
    X165                 R123 1
    X166                 OBJ 1001
    X166                 R124 1
    X167                 OBJ 0
    X167                 R125 1
    X168                 OBJ 0
    X168                 R117 1
    X168                 R127 -1
    X168                 R139 -1
    X168                 R143 -1
    X169                 OBJ 1001
    X169                 R126 1
    X170                 OBJ 0
    X170                 R127 1
    X171                 OBJ 1001
    X171                 R128 1
    X172                 OBJ 476
    X172                 R129 1
    X173                 OBJ 1000
    X173                 R46 1
    X173                 R117 1
    X173                 R118 1
    X173                 R126 1
    X173                 R128 1
    X173                 R129 1
    X173                 R130 -1
    X173                 R131 -1
    X173                 R133 -1
    X173                 R139 -1
    X173                 R142 -1
    X174                 OBJ 0
    X174                 R46 -1
    X174                 R132 -1
    X174                 R133 1
    X174                 R142 1
    X174                 R143 -1
    X175                 OBJ 500
    X175                 R130 1
    X176                 OBJ 500
    X176                 R131 1
    X177                 OBJ 0
    X177                 R132 1
    X178                 OBJ 500
    X178                 R133 1
    X179                 OBJ 261
    X179                 R131 -1
    X179                 R133 -1
    X179                 R134 1
    X179                 R135 1
    X179                 R136 1
    X179                 R137 1
    X180                 OBJ 0
    X180                 R134 1
    X181                 OBJ 0
    X181                 R135 1
    X182                 OBJ 0
    X182                 R136 1
    X183                 OBJ 1001
    X183                 R137 1
    X184                 OBJ 0
    X184                 R138 1
    X185                 OBJ 0
    X185                 R134 -1
    X185                 R138 -1
    X185                 R139 -1
    X185                 R140 1
    X186                 OBJ 1000
    X186                 R139 1
    X187                 OBJ 1001
    X187                 R140 1
    X188                 OBJ 0
    X188                 R141 1
    X189                 OBJ 500
    X189                 R142 1
    X190                 OBJ 1001
    X190                 R130 1
    X190                 R135 1
    X190                 R138 -1
    X190                 R141 1
    X190                 R142 1
    X191                 OBJ 1001
    X191                 R5 1
    X191                 R6 1
    X191                 R46 1
    X191                 R49 1
    X191                 R61 1
    X191                 R62 1
    X191                 R96 -1
    X191                 R117 1
    X191                 R118 1
    X191                 R126 1
    X191                 R128 1
    X191                 R129 1
    X191                 R130 -1
    X191                 R135 -1
    X191                 R137 -1
    X191                 R138 1
    X191                 R141 -1
    X191                 R142 -1
    X191                 R149 1
    X191                 R165 1
    X191                 R169 1
    X191                 R170 -1
    X192                 OBJ 540
    X192                 R5 -1
    X192                 R49 -1
    X192                 R61 -1
    X192                 R140 -1
    X192                 R149 -1
    X192                 R166 1
    X192                 R167 -1
    X192                 R168 -1
    X192                 R169 -1
    X192                 R170 1
    X193                 OBJ 431
    X193                 R6 -1
    X193                 R62 -1
    X193                 R96 1
    X193                 R165 -1
    X193                 R166 -1
    X193                 R167 1
    X193                 R168 1
    X194                 OBJ 0
    X194                 R143 1
    X195                 OBJ 1001
    X195                 R144 1
    X196                 OBJ 328
    X196                 R107 -1
    X196                 R116 1
    X196                 R121 1
    X196                 R123 -1
    X196                 R129 -1
    X196                 R144 1
    X196                 R145 -1
    X196                 R146 -1
    X197                 OBJ 520
    X197                 R145 1
    X198                 OBJ 0
    X198                 R146 1
    X199                 OBJ 0
    X199                 R147 1
    X200                 OBJ 0
    X200                 R148 1
    X201                 OBJ 0
    X201                 R36 1
    X201                 R42 1
    X201                 R45 -1
    X201                 R51 -1
    X201                 R59 -1
    X201                 R128 -1
    X201                 R147 1
    X201                 R148 -1
    X201                 R149 -1
    X202                 OBJ 600
    X202                 R149 1
    X203                 OBJ 0
    X203                 R150 1
    X204                 OBJ 0
    X204                 R34 1
    X204                 R44 -1
    X204                 R47 1
    X204                 R50 1
    X204                 R51 1
    X204                 R52 1
    X204                 R53 1
    X204                 R54 1
    X204                 R55 1
    X204                 R56 1
    X204                 R57 1
    X204                 R59 1
    X204                 R60 1
    X204                 R61 -1
    X204                 R62 -1
    X204                 R126 -1
    X204                 R147 -1
    X204                 R150 -1
    X205                 OBJ 333.33333333000002
    X205                 R151 1
    X206                 OBJ 1001
    X206                 R152 1
    X207                 OBJ 0
    X207                 R153 1
    X208                 OBJ 0
    X208                 R154 1
    X209                 OBJ 0
    X209                 R155 1
    X210                 OBJ 0
    X210                 R156 1
    X211                 OBJ 2002
    X211                 R8 1
    X211                 R85 -1
    X211                 R88 1
    X211                 R90 1
    X211                 R91 1
    X211                 R97 -1
    X211                 R98 -1
    X211                 R99 1
    X211                 R122 1
    X211                 R161 1
    X211                 R163 1
    X211                 R164 1
    X212                 OBJ 1001
    X212                 R157 1
    X213                 OBJ 1001
    X213                 R158 1
    X214                 OBJ 0
    X214                 R159 1
    X215                 OBJ 500
    X215                 R160 1
    X216                 OBJ 500
    X216                 R161 1
    X217                 OBJ 0
    X217                 R162 1
    X218                 OBJ 0
    X218                 R163 1
    X219                 OBJ 0
    X219                 R164 1
    X220                 OBJ 0
    X220                 R165 1
    X221                 OBJ 719
    X221                 R166 1
    X222                 OBJ 0
    X222                 R167 1
    X223                 OBJ 0
    X223                 R168 1
    X224                 OBJ 0
    X224                 R169 1
    X225                 OBJ 1001
    X225                 R170 1
    X226                 OBJ 0
    X226                 R0 -60
    X227                 OBJ 0
    X227                 R1 -60
    X228                 OBJ 0
    X228                 R2 -60
    X229                 OBJ 0
    X229                 R3 -60
    X230                 OBJ 0
    X230                 R4 -60
    X231                 OBJ 0
    X231                 R5 -60
    X232                 OBJ 0
    X232                 R6 -60
    X233                 OBJ 0
    X233                 R7 -60
    X234                 OBJ 0
    X234                 R8 -60
    X235                 OBJ 0
    X235                 R9 -60
    X236                 OBJ 0
    X236                 R10 -60
    X237                 OBJ 0
    X237                 R11 -60
    X238                 OBJ 0
    X238                 R12 -60
    X239                 OBJ 0
    X239                 R13 -60
    X240                 OBJ 0
    X240                 R14 -60
    X241                 OBJ 0
    X241                 R15 -60
    X242                 OBJ 0
    X242                 R16 -60
    X243                 OBJ 0
    X243                 R17 -60
    X244                 OBJ 0
    X244                 R18 -60
    X245                 OBJ 0
    X245                 R19 -60
    X246                 OBJ 0
    X246                 R20 -60
    X247                 OBJ 0
    X247                 R21 -60
    X248                 OBJ 0
    X248                 R22 -60
    X249                 OBJ 0
    X249                 R23 -60
    X250                 OBJ 0
    X250                 R24 -60
    X251                 OBJ 0
    X251                 R25 -60
    X252                 OBJ 0
    X252                 R26 -60
    X253                 OBJ 0
    X253                 R27 -60
    X254                 OBJ 0
    X254                 R28 -60
    X255                 OBJ 0
    X255                 R29 -60
    X256                 OBJ 0
    X256                 R30 -60
    X257                 OBJ 0
    X257                 R31 -60
    X258                 OBJ 0
    X258                 R32 -60
    X259                 OBJ 0
    X259                 R33 -60
    X260                 OBJ 0
    X260                 R34 -60
    X261                 OBJ 0
    X261                 R35 -60
    X262                 OBJ 0
    X262                 R36 -60
    X263                 OBJ 0
    X263                 R37 -60
    X264                 OBJ 0
    X264                 R38 -60
    X265                 OBJ 0
    X265                 R39 -60
    X266                 OBJ 0
    X266                 R40 -60
    X267                 OBJ 0
    X267                 R41 -60
    X268                 OBJ 0
    X268                 R42 -60
    X269                 OBJ 0
    X269                 R43 -60
    X270                 OBJ 0
    X270                 R44 -60
    X271                 OBJ 0
    X271                 R45 -60
    X272                 OBJ 0
    X272                 R46 -60
    X273                 OBJ 0
    X273                 R47 -60
    X274                 OBJ 0
    X274                 R48 -60
    X275                 OBJ 0
    X275                 R49 -60
    X276                 OBJ 0
    X276                 R50 -60
    X277                 OBJ 0
    X277                 R51 -60
    X278                 OBJ 0
    X278                 R52 -60
    X279                 OBJ 0
    X279                 R53 -60
    X280                 OBJ 0
    X280                 R54 -60
    X281                 OBJ 0
    X281                 R55 -60
    X282                 OBJ 0
    X282                 R56 -60
    X283                 OBJ 0
    X283                 R57 -60
    X284                 OBJ 0
    X284                 R58 -60
    X285                 OBJ 0
    X285                 R59 -60
    X286                 OBJ 0
    X286                 R60 -60
    X287                 OBJ 0
    X287                 R61 -60
    X288                 OBJ 0
    X288                 R62 -60
    X289                 OBJ 0
    X289                 R63 -60
    X290                 OBJ 0
    X290                 R64 -60
    X291                 OBJ 0
    X291                 R65 -60
    X292                 OBJ 0
    X292                 R66 -60
    X293                 OBJ 0
    X293                 R67 -60
    X294                 OBJ 0
    X294                 R68 -60
    X295                 OBJ 0
    X295                 R69 -60
    X296                 OBJ 0
    X296                 R70 -60
    X297                 OBJ 0
    X297                 R71 -60
    X298                 OBJ 0
    X298                 R72 -60
    X299                 OBJ 0
    X299                 R73 -60
    X300                 OBJ 0
    X300                 R74 -60
    X301                 OBJ 0
    X301                 R75 -60
    X302                 OBJ 0
    X302                 R76 -60
    X303                 OBJ 0
    X303                 R77 -60
    X304                 OBJ 0
    X304                 R78 -60
    X305                 OBJ 0
    X305                 R79 -60
    X306                 OBJ 0
    X306                 R80 -60
    X307                 OBJ 0
    X307                 R81 -60
    X308                 OBJ 0
    X308                 R82 -60
    X309                 OBJ 0
    X309                 R83 -60
    X310                 OBJ 0
    X310                 R84 -60
    X311                 OBJ 0
    X311                 R85 -60
    X312                 OBJ 0
    X312                 R86 -60
    X313                 OBJ 0
    X313                 R87 -60
    X314                 OBJ 0
    X314                 R88 -60
    X315                 OBJ 0
    X315                 R89 -60
    X316                 OBJ 0
    X316                 R90 -60
    X317                 OBJ 0
    X317                 R91 -60
    X318                 OBJ 0
    X318                 R92 -60
    X319                 OBJ 0
    X319                 R93 -60
    X320                 OBJ 0
    X320                 R94 -60
    X321                 OBJ 0
    X321                 R95 -60
    X322                 OBJ 0
    X322                 R96 -60
    X323                 OBJ 0
    X323                 R97 -60
    X324                 OBJ 0
    X324                 R98 -60
    X325                 OBJ 0
    X325                 R99 -60
    X326                 OBJ 0
    X326                 R100 -60
    X327                 OBJ 0
    X327                 R101 -60
    X328                 OBJ 0
    X328                 R102 -60
    X329                 OBJ 0
    X329                 R103 -60
    X330                 OBJ 0
    X330                 R104 -60
    X331                 OBJ 0
    X331                 R105 -60
    X332                 OBJ 0
    X332                 R106 -60
    X333                 OBJ 0
    X333                 R107 -60
    X334                 OBJ 0
    X334                 R108 -60
    X335                 OBJ 0
    X335                 R109 -60
    X336                 OBJ 0
    X336                 R110 -60
    X337                 OBJ 0
    X337                 R111 -60
    X338                 OBJ 0
    X338                 R112 -60
    X339                 OBJ 0
    X339                 R113 -60
    X340                 OBJ 0
    X340                 R114 -60
    X341                 OBJ 0
    X341                 R115 -60
    X342                 OBJ 0
    X342                 R116 -60
    X343                 OBJ 0
    X343                 R117 -60
    X344                 OBJ 0
    X344                 R118 -60
    X345                 OBJ 0
    X345                 R119 -60
    X346                 OBJ 0
    X346                 R120 -60
    X347                 OBJ 0
    X347                 R121 -60
    X348                 OBJ 0
    X348                 R122 -60
    X349                 OBJ 0
    X349                 R123 -60
    X350                 OBJ 0
    X350                 R124 -60
    X351                 OBJ 0
    X351                 R125 -60
    X352                 OBJ 0
    X352                 R126 -60
    X353                 OBJ 0
    X353                 R127 -60
    X354                 OBJ 0
    X354                 R128 -60
    X355                 OBJ 0
    X355                 R129 -60
    X356                 OBJ 0
    X356                 R130 -60
    X357                 OBJ 0
    X357                 R131 -60
    X358                 OBJ 0
    X358                 R132 -60
    X359                 OBJ 0
    X359                 R133 -60
    X360                 OBJ 0
    X360                 R134 -60
    X361                 OBJ 0
    X361                 R135 -60
    X362                 OBJ 0
    X362                 R136 -60
    X363                 OBJ 0
    X363                 R137 -60
    X364                 OBJ 0
    X364                 R138 -60
    X365                 OBJ 0
    X365                 R139 -60
    X366                 OBJ 0
    X366                 R140 -60
    X367                 OBJ 0
    X367                 R141 -60
    X368                 OBJ 0
    X368                 R142 -60
    X369                 OBJ 0
    X369                 R143 -60
    X370                 OBJ 0
    X370                 R144 -60
    X371                 OBJ 0
    X371                 R145 -60
    X372                 OBJ 0
    X372                 R146 -60
    X373                 OBJ 0
    X373                 R147 -60
    X374                 OBJ 0
    X374                 R148 -60
    X375                 OBJ 0
    X375                 R149 -60
    X376                 OBJ 0
    X376                 R150 -60
    X377                 OBJ 0
    X377                 R151 -60
    X378                 OBJ 0
    X378                 R152 -60
    X379                 OBJ 0
    X379                 R153 -60
    X380                 OBJ 0
    X380                 R154 -60
    X381                 OBJ 0
    X381                 R155 -60
    X382                 OBJ 0
    X382                 R156 -60
    X383                 OBJ 0
    X383                 R157 -60
    X384                 OBJ 0
    X384                 R158 -60
    X385                 OBJ 0
    X385                 R159 -60
    X386                 OBJ 0
    X386                 R160 -60
    X387                 OBJ 0
    X387                 R161 -60
    X388                 OBJ 0
    X388                 R162 -60
    X389                 OBJ 0
    X389                 R163 -60
    X390                 OBJ 0
    X390                 R164 -60
    X391                 OBJ 0
    X391                 R165 -60
    X392                 OBJ 0
    X392                 R166 -60
    X393                 OBJ 0
    X393                 R167 -60
    X394                 OBJ 0
    X394                 R168 -60
    X395                 OBJ 0
    X395                 R169 -60
    X396                 OBJ 0
    X396                 R170 -60
RHS
    RHS                  OBJ -0
    RHS                  R0 -35
    RHS                  R1 -1
    RHS                  R2 -115
    RHS                  R3 -24
    RHS                  R4 -31
    RHS                  R5 -91
    RHS                  R6 -80
    RHS                  R7 0
    RHS                  R8 2
    RHS                  R9 -30
    RHS                  R10 -30
    RHS                  R11 22
    RHS                  R12 24
    RHS                  R13 -1
    RHS                  R14 -30
    RHS                  R15 -31
    RHS                  R16 -30
    RHS                  R17 -30
    RHS                  R18 -30
    RHS                  R19 -30
    RHS                  R20 -31
    RHS                  R21 -1
    RHS                  R22 -30
    RHS                  R23 -31
    RHS                  R24 -122
    RHS                  R25 -152
    RHS                  R26 0
    RHS                  R27 1
    RHS                  R28 -29
    RHS                  R29 -59
    RHS                  R30 -89
    RHS                  R31 -2.84217e-14
    RHS                  R32 -30
    RHS                  R33 -30
    RHS                  R34 0
    RHS                  R35 -30
    RHS                  R36 -30
    RHS                  R37 1
    RHS                  R38 -29
    RHS                  R39 -30
    RHS                  R40 -14
    RHS                  R41 -44
    RHS                  R42 -6
    RHS                  R43 27
    RHS                  R44 -3
    RHS                  R45 -3
    RHS                  R46 -156
    RHS                  R47 -60
    RHS                  R48 -68
    RHS                  R49 -134
    RHS                  R50 -59
    RHS                  R51 -60
    RHS                  R52 -167
    RHS                  R53 -145
    RHS                  R54 -108
    RHS                  R55 -45
    RHS                  R56 -45
    RHS                  R57 -99
    RHS                  R58 -59
    RHS                  R59 -59
    RHS                  R60 -116
    RHS                  R61 -138
    RHS                  R62 -136
    RHS                  R63 -73
    RHS                  R64 -27
    RHS                  R65 -57
    RHS                  R66 -57
    RHS                  R67 -56
    RHS                  R68 -87
    RHS                  R69 -78
    RHS                  R70 -98
    RHS                  R71 -68
    RHS                  R72 -49
    RHS                  R73 -68
    RHS                  R74 -86
    RHS                  R75 -30
    RHS                  R76 -57
    RHS                  R77 -57
    RHS                  R78 -99
    RHS                  R79 -88
    RHS                  R80 -1
    RHS                  R81 -30
    RHS                  R82 -163
    RHS                  R83 -66
    RHS                  R84 24
    RHS                  R85 0
    RHS                  R86 -54
    RHS                  R87 -3
    RHS                  R88 55
    RHS                  R89 23
    RHS                  R90 39
    RHS                  R91 29
    RHS                  R92 -3
    RHS                  R93 -63
    RHS                  R94 -57
    RHS                  R95 -6
    RHS                  R96 54
    RHS                  R97 -101
    RHS                  R98 -102
    RHS                  R99 -58
    RHS                  R100 -1
    RHS                  R101 -138
    RHS                  R102 -150
    RHS                  R103 -72
    RHS                  R104 -30
    RHS                  R105 2
    RHS                  R106 -22
    RHS                  R107 -1
    RHS                  R108 -3
    RHS                  R109 -16
    RHS                  R110 -100
    RHS                  R111 -71
    RHS                  R112 -90
    RHS                  R113 -30
    RHS                  R114 -74
    RHS                  R115 -75
    RHS                  R116 -1
    RHS                  R117 -22
    RHS                  R118 -53
    RHS                  R119 -30
    RHS                  R120 -90
    RHS                  R121 -15
    RHS                  R122 -75
    RHS                  R123 -110
    RHS                  R124 -31
    RHS                  R125 -3
    RHS                  R126 -97
    RHS                  R127 -30
    RHS                  R128 -67
    RHS                  R129 -53
    RHS                  R130 -45
    RHS                  R131 -72
    RHS                  R132 -30
    RHS                  R133 -73
    RHS                  R134 -3
    RHS                  R135 26
    RHS                  R136 56
    RHS                  R137 -33
    RHS                  R138 -30
    RHS                  R139 -133
    RHS                  R140 0
    RHS                  R141 29
    RHS                  R142 -46
    RHS                  R143 -59
    RHS                  R144 -82
    RHS                  R145 -90
    RHS                  R146 -110
    RHS                  R147 -3
    RHS                  R148 -68
    RHS                  R149 -134
    RHS                  R150 -68
    RHS                  R151 -59
    RHS                  R152 27
    RHS                  R153 -33
    RHS                  R154 -3
    RHS                  R155 -58
    RHS                  R156 -34
    RHS                  R157 0
    RHS                  R158 -84
    RHS                  R159 -87
    RHS                  R160 -3
    RHS                  R161 59
    RHS                  R162 -5
    RHS                  R163 29
    RHS                  R164 59
    RHS                  R165 -168
    RHS                  R166 -50
    RHS                  R167 -1
    RHS                  R168 -16
    RHS                  R169 -119
    RHS                  R170 -15
BOUNDS
 	FR BND X0
 	LO BND X0 0
 	UP BND X0 4
 	FR BND X1
 	LO BND X1 0
 	UP BND X1 54
 	FR BND X2
 	LO BND X2 0
 	UP BND X2 54
 	FR BND X3
 	LO BND X3 0
 	UP BND X3 59
 	FR BND X4
 	LO BND X4 0
 	UP BND X4 4
 	FR BND X5
 	LO BND X5 0
 	UP BND X5 54
 	FR BND X6
 	LO BND X6 0
 	UP BND X6 59
 	FR BND X7
 	LO BND X7 0
 	UP BND X7 4
 	FR BND X8
 	LO BND X8 0
 	UP BND X8 48
 	FR BND X9
 	LO BND X9 0
 	UP BND X9 58
 	FR BND X10
 	LO BND X10 0
 	UP BND X10 58
 	FR BND X11
 	LO BND X11 0
 	UP BND X11 4
 	FR BND X12
 	LO BND X12 0
 	UP BND X12 52
 	FR BND X13
 	LO BND X13 0
 	UP BND X13 59
 	FR BND X14
 	LO BND X14 0
 	UP BND X14 59
 	FR BND X15
 	LO BND X15 0
 	UP BND X15 59
 	FR BND X16
 	LO BND X16 0
 	UP BND X16 59
 	FR BND X17
 	LO BND X17 0
 	UP BND X17 59
 	FR BND X18
 	LO BND X18 0
 	UP BND X18 54
 	FR BND X19
 	LO BND X19 0
 	UP BND X19 54
 	FR BND X20
 	LO BND X20 0
 	UP BND X20 52
 	FR BND X21
 	LO BND X21 0
 	UP BND X21 4
 	FR BND X22
 	LO BND X22 0
 	UP BND X22 54
 	FR BND X23
 	LO BND X23 0
 	UP BND X23 54
 	FR BND X24
 	LO BND X24 0
 	UP BND X24 59
 	FR BND X25
 	LO BND X25 0
 	UP BND X25 54
 	FR BND X26
 	LO BND X26 0
 	UP BND X26 59
 	FR BND X27
 	LO BND X27 0
 	UP BND X27 59
 	FR BND X28
 	LO BND X28 0
 	UP BND X28 59
 	FR BND X29
 	LO BND X29 0
 	UP BND X29 59
 	FR BND X30
 	LO BND X30 0
 	UP BND X30 59
 	FR BND X31
 	LO BND X31 0
 	UP BND X31 59
 	FR BND X32
 	LO BND X32 0
 	UP BND X32 54
 	FR BND X33
 	LO BND X33 0
 	UP BND X33 51
 	FR BND X34
 	LO BND X34 0
 	UP BND X34 51
 	FR BND X35
 	LO BND X35 0
 	UP BND X35 51
 	FR BND X36
 	LO BND X36 0
 	UP BND X36 54
 	FR BND X37
 	LO BND X37 0
 	UP BND X37 54
 	FR BND X38
 	LO BND X38 0
 	UP BND X38 59
 	FR BND X39
 	LO BND X39 0
 	UP BND X39 6
 	FR BND X40
 	LO BND X40 0
 	UP BND X40 54
 	FR BND X41
 	LO BND X41 0
 	UP BND X41 54
 	FR BND X42
 	LO BND X42 0
 	UP BND X42 54
 	FR BND X43
 	LO BND X43 0
 	UP BND X43 54
 	FR BND X44
 	LO BND X44 0
 	UP BND X44 57
 	FR BND X45
 	LO BND X45 0
 	UP BND X45 57
 	FR BND X46
 	LO BND X46 0
 	UP BND X46 6
 	FR BND X47
 	LO BND X47 0
 	UP BND X47 54
 	FR BND X48
 	LO BND X48 0
 	UP BND X48 54
 	FR BND X49
 	LO BND X49 0
 	UP BND X49 59
 	FR BND X50
 	LO BND X50 0
 	UP BND X50 59
 	FR BND X51
 	LO BND X51 0
 	UP BND X51 59
 	FR BND X52
 	LO BND X52 0
 	UP BND X52 59
 	FR BND X53
 	LO BND X53 0
 	UP BND X53 59
 	FR BND X54
 	LO BND X54 0
 	UP BND X54 59
 	FR BND X55
 	LO BND X55 0
 	UP BND X55 58
 	FR BND X56
 	LO BND X56 0
 	UP BND X56 6
 	FR BND X57
 	LO BND X57 0
 	UP BND X57 58
 	FR BND X58
 	LO BND X58 0
 	UP BND X58 6
 	FR BND X59
 	LO BND X59 0
 	UP BND X59 54
 	FR BND X60
 	LO BND X60 0
 	UP BND X60 54
 	FR BND X61
 	LO BND X61 0
 	UP BND X61 54
 	FR BND X62
 	LO BND X62 0
 	UP BND X62 54
 	FR BND X63
 	LO BND X63 0
 	UP BND X63 59
 	FR BND X64
 	LO BND X64 0
 	UP BND X64 59
 	FR BND X65
 	LO BND X65 0
 	UP BND X65 59
 	FR BND X66
 	LO BND X66 0
 	UP BND X66 6
 	FR BND X67
 	LO BND X67 0
 	UP BND X67 6
 	FR BND X68
 	LO BND X68 0
 	UP BND X68 54
 	FR BND X69
 	LO BND X69 0
 	UP BND X69 54
 	FR BND X70
 	LO BND X70 0
 	UP BND X70 4
 	FR BND X71
 	LO BND X71 0
 	UP BND X71 59
 	FR BND X72
 	LO BND X72 0
 	UP BND X72 52
 	FR BND X73
 	LO BND X73 0
 	UP BND X73 51
 	FR BND X74
 	LO BND X74 0
 	UP BND X74 59
 	FR BND X75
 	LO BND X75 0
 	UP BND X75 54
 	FR BND X76
 	LO BND X76 0
 	UP BND X76 59
 	FR BND X77
 	LO BND X77 0
 	UP BND X77 59
 	FR BND X78
 	LO BND X78 0
 	UP BND X78 59
 	FR BND X79
 	LO BND X79 0
 	UP BND X79 59
 	FR BND X80
 	LO BND X80 0
 	UP BND X80 59
 	FR BND X81
 	LO BND X81 0
 	UP BND X81 54
 	FR BND X82
 	LO BND X82 0
 	UP BND X82 54
 	FR BND X83
 	LO BND X83 0
 	UP BND X83 54
 	FR BND X84
 	LO BND X84 0
 	UP BND X84 54
 	FR BND X85
 	LO BND X85 0
 	UP BND X85 54
 	FR BND X86
 	LO BND X86 0
 	UP BND X86 52
 	FR BND X87
 	LO BND X87 0
 	UP BND X87 59
 	FR BND X88
 	LO BND X88 0
 	UP BND X88 4
 	FR BND X89
 	LO BND X89 0
 	UP BND X89 53
 	FR BND X90
 	LO BND X90 0
 	UP BND X90 59
 	FR BND X91
 	LO BND X91 0
 	UP BND X91 59
 	FR BND X92
 	LO BND X92 0
 	UP BND X92 59
 	FR BND X93
 	LO BND X93 0
 	UP BND X93 59
 	FR BND X94
 	LO BND X94 0
 	UP BND X94 50
 	FR BND X95
 	LO BND X95 0
 	UP BND X95 52
 	FR BND X96
 	LO BND X96 0
 	UP BND X96 54
 	FR BND X97
 	LO BND X97 0
 	UP BND X97 53
 	FR BND X98
 	LO BND X98 0
 	UP BND X98 52
 	FR BND X99
 	LO BND X99 0
 	UP BND X99 52
 	FR BND X100
 	LO BND X100 0
 	UP BND X100 53
 	FR BND X101
 	LO BND X101 0
 	UP BND X101 52
 	FR BND X102
 	LO BND X102 0
 	UP BND X102 59
 	FR BND X103
 	LO BND X103 0
 	UP BND X103 54
 	FR BND X104
 	LO BND X104 0
 	UP BND X104 54
 	FR BND X105
 	LO BND X105 0
 	UP BND X105 54
 	FR BND X106
 	LO BND X106 0
 	UP BND X106 4
 	FR BND X107
 	LO BND X107 0
 	UP BND X107 5
 	FR BND X108
 	LO BND X108 0
 	UP BND X108 54
 	FR BND X109
 	LO BND X109 0
 	UP BND X109 59
 	FR BND X110
 	LO BND X110 0
 	UP BND X110 59
 	FR BND X111
 	LO BND X111 0
 	UP BND X111 59
 	FR BND X112
 	LO BND X112 0
 	UP BND X112 59
 	FR BND X113
 	LO BND X113 0
 	UP BND X113 54
 	FR BND X114
 	LO BND X114 0
 	UP BND X114 4
 	FR BND X115
 	LO BND X115 0
 	UP BND X115 54
 	FR BND X116
 	LO BND X116 0
 	UP BND X116 54
 	FR BND X117
 	LO BND X117 0
 	UP BND X117 59
 	FR BND X118
 	LO BND X118 0
 	UP BND X118 53
 	FR BND X119
 	LO BND X119 0
 	UP BND X119 53
 	FR BND X120
 	LO BND X120 0
 	UP BND X120 53
 	FR BND X121
 	LO BND X121 0
 	UP BND X121 56
 	FR BND X122
 	LO BND X122 0
 	UP BND X122 4
 	FR BND X123
 	LO BND X123 0
 	UP BND X123 59
 	FR BND X124
 	LO BND X124 0
 	UP BND X124 54
 	FR BND X125
 	LO BND X125 0
 	UP BND X125 39
 	FR BND X126
 	LO BND X126 0
 	UP BND X126 59
 	FR BND X127
 	LO BND X127 0
 	UP BND X127 54
 	FR BND X128
 	LO BND X128 0
 	UP BND X128 4
 	FR BND X129
 	LO BND X129 0
 	UP BND X129 4
 	FR BND X130
 	LO BND X130 0
 	UP BND X130 59
 	FR BND X131
 	LO BND X131 0
 	UP BND X131 5
 	FR BND X132
 	LO BND X132 0
 	UP BND X132 51
 	FR BND X133
 	LO BND X133 0
 	UP BND X133 4
 	FR BND X134
 	LO BND X134 0
 	UP BND X134 54
 	FR BND X135
 	LO BND X135 0
 	UP BND X135 59
 	FR BND X136
 	LO BND X136 0
 	UP BND X136 59
 	FR BND X137
 	LO BND X137 0
 	UP BND X137 59
 	FR BND X138
 	LO BND X138 0
 	UP BND X138 54
 	FR BND X139
 	LO BND X139 0
 	UP BND X139 54
 	FR BND X140
 	LO BND X140 0
 	UP BND X140 4
 	FR BND X141
 	LO BND X141 0
 	UP BND X141 4
 	FR BND X142
 	LO BND X142 0
 	UP BND X142 56
 	FR BND X143
 	LO BND X143 0
 	UP BND X143 59
 	FR BND X144
 	LO BND X144 0
 	UP BND X144 4
 	FR BND X145
 	LO BND X145 0
 	UP BND X145 4
 	FR BND X146
 	LO BND X146 0
 	UP BND X146 59
 	FR BND X147
 	LO BND X147 0
 	UP BND X147 54
 	FR BND X148
 	LO BND X148 0
 	UP BND X148 54
 	FR BND X149
 	LO BND X149 0
 	UP BND X149 54
 	FR BND X150
 	LO BND X150 0
 	UP BND X150 54
 	FR BND X151
 	LO BND X151 0
 	UP BND X151 54
 	FR BND X152
 	LO BND X152 0
 	UP BND X152 54
 	FR BND X153
 	LO BND X153 0
 	UP BND X153 4
 	FR BND X154
 	LO BND X154 0
 	UP BND X154 59
 	FR BND X155
 	LO BND X155 0
 	UP BND X155 58
 	FR BND X156
 	LO BND X156 0
 	UP BND X156 4
 	FR BND X157
 	LO BND X157 0
 	UP BND X157 59
 	FR BND X158
 	LO BND X158 0
 	UP BND X158 59
 	FR BND X159
 	LO BND X159 0
 	UP BND X159 58
 	FR BND X160
 	LO BND X160 0
 	UP BND X160 58
 	FR BND X161
 	LO BND X161 0
 	UP BND X161 59
 	FR BND X162
 	LO BND X162 0
 	UP BND X162 59
 	FR BND X163
 	LO BND X163 0
 	UP BND X163 52
 	FR BND X164
 	LO BND X164 0
 	UP BND X164 4
 	FR BND X165
 	LO BND X165 0
 	UP BND X165 58
 	FR BND X166
 	LO BND X166 0
 	UP BND X166 4
 	FR BND X167
 	LO BND X167 0
 	UP BND X167 49
 	FR BND X168
 	LO BND X168 0
 	UP BND X168 58
 	FR BND X169
 	LO BND X169 0
 	UP BND X169 4
 	FR BND X170
 	LO BND X170 0
 	UP BND X170 58
 	FR BND X171
 	LO BND X171 0
 	UP BND X171 4
 	FR BND X172
 	LO BND X172 0
 	UP BND X172 59
 	FR BND X173
 	LO BND X173 0
 	UP BND X173 59
 	FR BND X174
 	LO BND X174 0
 	UP BND X174 58
 	FR BND X175
 	LO BND X175 0
 	UP BND X175 59
 	FR BND X176
 	LO BND X176 0
 	UP BND X176 59
 	FR BND X177
 	LO BND X177 0
 	UP BND X177 58
 	FR BND X178
 	LO BND X178 0
 	UP BND X178 59
 	FR BND X179
 	LO BND X179 0
 	UP BND X179 59
 	FR BND X180
 	LO BND X180 0
 	UP BND X180 57
 	FR BND X181
 	LO BND X181 0
 	UP BND X181 58
 	FR BND X182
 	LO BND X182 0
 	UP BND X182 58
 	FR BND X183
 	LO BND X183 0
 	UP BND X183 4
 	FR BND X184
 	LO BND X184 0
 	UP BND X184 57
 	FR BND X185
 	LO BND X185 0
 	UP BND X185 57
 	FR BND X186
 	LO BND X186 0
 	UP BND X186 59
 	FR BND X187
 	LO BND X187 0
 	UP BND X187 4
 	FR BND X188
 	LO BND X188 0
 	UP BND X188 58
 	FR BND X189
 	LO BND X189 0
 	UP BND X189 59
 	FR BND X190
 	LO BND X190 0
 	UP BND X190 4
 	FR BND X191
 	LO BND X191 0
 	UP BND X191 4
 	FR BND X192
 	LO BND X192 0
 	UP BND X192 59
 	FR BND X193
 	LO BND X193 0
 	UP BND X193 59
 	FR BND X194
 	LO BND X194 0
 	UP BND X194 58
 	FR BND X195
 	LO BND X195 0
 	UP BND X195 4
 	FR BND X196
 	LO BND X196 0
 	UP BND X196 59
 	FR BND X197
 	LO BND X197 0
 	UP BND X197 59
 	FR BND X198
 	LO BND X198 0
 	UP BND X198 58
 	FR BND X199
 	LO BND X199 0
 	UP BND X199 54
 	FR BND X200
 	LO BND X200 0
 	UP BND X200 52
 	FR BND X201
 	LO BND X201 0
 	UP BND X201 51
 	FR BND X202
 	LO BND X202 0
 	UP BND X202 59
 	FR BND X203
 	LO BND X203 0
 	UP BND X203 52
 	FR BND X204
 	LO BND X204 0
 	UP BND X204 51
 	FR BND X205
 	LO BND X205 0
 	UP BND X205 59
 	FR BND X206
 	LO BND X206 0
 	UP BND X206 6
 	FR BND X207
 	LO BND X207 0
 	UP BND X207 54
 	FR BND X208
 	LO BND X208 0
 	UP BND X208 54
 	FR BND X209
 	LO BND X209 0
 	UP BND X209 53
 	FR BND X210
 	LO BND X210 0
 	UP BND X210 53
 	FR BND X211
 	LO BND X211 0
 	UP BND X211 4
 	FR BND X212
 	LO BND X212 0
 	UP BND X212 4
 	FR BND X213
 	LO BND X213 0
 	UP BND X213 4
 	FR BND X214
 	LO BND X214 0
 	UP BND X214 54
 	FR BND X215
 	LO BND X215 0
 	UP BND X215 59
 	FR BND X216
 	LO BND X216 0
 	UP BND X216 59
 	FR BND X217
 	LO BND X217 0
 	UP BND X217 52
 	FR BND X218
 	LO BND X218 0
 	UP BND X218 54
 	FR BND X219
 	LO BND X219 0
 	UP BND X219 54
 	FR BND X220
 	LO BND X220 0
 	UP BND X220 58
 	FR BND X221
 	LO BND X221 0
 	UP BND X221 59
 	FR BND X222
 	LO BND X222 0
 	UP BND X222 58
 	FR BND X223
 	LO BND X223 0
 	UP BND X223 52
 	FR BND X224
 	LO BND X224 0
 	UP BND X224 58
 	FR BND X225
 	LO BND X225 0
 	UP BND X225 4
 	FR BND X226
 	LO BND X226 0
 	UP BND X226 4
 	FX BND X227 0
 	FR BND X228
 	LO BND X228 0
 	UP BND X228 2
 	FR BND X229
 	LO BND X229 0
 	UP BND X229 1
 	FR BND X230
 	LO BND X230 0
 	UP BND X230 1
 	FR BND X231
 	LO BND X231 0
 	UP BND X231 2
 	FR BND X232
 	LO BND X232 0
 	UP BND X232 2
 	FX BND X233 0
 	FR BND X234
 	LO BND X234 0
 	UP BND X234 2
 	FR BND X235
 	LO BND X235 0
 	UP BND X235 1
 	FR BND X236
 	LO BND X236 0
 	UP BND X236 1
 	FR BND X237
 	LO BND X237 0
 	UP BND X237 1
 	FR BND X238
 	LO BND X238 0
 	UP BND X238 1
 	FR BND X239
 	LO BND X239 0
 	UP BND X239 1
 	FR BND X240
 	LO BND X240 0
 	UP BND X240 1
 	FR BND X241
 	LO BND X241 0
 	UP BND X241 1
 	FR BND X242
 	LO BND X242 0
 	UP BND X242 1
 	FR BND X243
 	LO BND X243 0
 	UP BND X243 1
 	FR BND X244
 	LO BND X244 0
 	UP BND X244 1
 	FR BND X245
 	LO BND X245 0
 	UP BND X245 1
 	FR BND X246
 	LO BND X246 0
 	UP BND X246 1
 	FX BND X247 0
 	FR BND X248
 	LO BND X248 0
 	UP BND X248 1
 	FR BND X249
 	LO BND X249 0
 	UP BND X249 1
 	FR BND X250
 	LO BND X250 0
 	UP BND X250 3
 	FR BND X251
 	LO BND X251 0
 	UP BND X251 4
 	FX BND X252 0
 	FX BND X253 0
 	FR BND X254
 	LO BND X254 0
 	UP BND X254 1
 	FR BND X255
 	LO BND X255 0
 	UP BND X255 3
 	FR BND X256
 	LO BND X256 0
 	UP BND X256 4
 	FR BND X257
 	LO BND X257 0
 	UP BND X257 2
 	FR BND X258
 	LO BND X258 0
 	UP BND X258 3
 	FR BND X259
 	LO BND X259 0
 	UP BND X259 1
 	FX BND X260 0
 	FR BND X261
 	LO BND X261 0
 	UP BND X261 1
 	FR BND X262
 	LO BND X262 0
 	UP BND X262 1
 	FX BND X263 0
 	FR BND X264
 	LO BND X264 0
 	UP BND X264 1
 	FR BND X265
 	LO BND X265 0
 	UP BND X265 1
 	FR BND X266
 	LO BND X266 0
 	UP BND X266 1
 	FR BND X267
 	LO BND X267 0
 	UP BND X267 1
 	FR BND X268
 	LO BND X268 0
 	UP BND X268 1
 	FX BND X269 0
 	FR BND X270
 	LO BND X270 0
 	UP BND X270 1
 	FR BND X271
 	LO BND X271 0
 	UP BND X271 1
 	FR BND X272
 	LO BND X272 0
 	UP BND X272 4
 	FR BND X273
 	LO BND X273 0
 	UP BND X273 2
 	FR BND X274
 	LO BND X274 0
 	UP BND X274 2
 	FR BND X275
 	LO BND X275 0
 	UP BND X275 4
 	FR BND X276
 	LO BND X276 0
 	UP BND X276 2
 	FR BND X277
 	LO BND X277 0
 	UP BND X277 2
 	FR BND X278
 	LO BND X278 0
 	UP BND X278 4
 	FR BND X279
 	LO BND X279 0
 	UP BND X279 5
 	FR BND X280
 	LO BND X280 0
 	UP BND X280 4
 	FR BND X281
 	LO BND X281 0
 	UP BND X281 3
 	FR BND X282
 	LO BND X282 0
 	UP BND X282 3
 	FR BND X283
 	LO BND X283 0
 	UP BND X283 3
 	FR BND X284
 	LO BND X284 0
 	UP BND X284 1
 	FR BND X285
 	LO BND X285 0
 	UP BND X285 2
 	FR BND X286
 	LO BND X286 0
 	UP BND X286 4
 	FR BND X287
 	LO BND X287 0
 	UP BND X287 5
 	FR BND X288
 	LO BND X288 0
 	UP BND X288 4
 	FR BND X289
 	LO BND X289 0
 	UP BND X289 3
 	FR BND X290
 	LO BND X290 0
 	UP BND X290 3
 	FR BND X291
 	LO BND X291 0
 	UP BND X291 3
 	FR BND X292
 	LO BND X292 0
 	UP BND X292 3
 	FR BND X293
 	LO BND X293 0
 	UP BND X293 3
 	FR BND X294
 	LO BND X294 0
 	UP BND X294 4
 	FR BND X295
 	LO BND X295 0
 	UP BND X295 3
 	FR BND X296
 	LO BND X296 0
 	UP BND X296 3
 	FR BND X297
 	LO BND X297 0
 	UP BND X297 2
 	FR BND X298
 	LO BND X298 0
 	UP BND X298 2
 	FR BND X299
 	LO BND X299 0
 	UP BND X299 2
 	FR BND X300
 	LO BND X300 0
 	UP BND X300 3
 	FR BND X301
 	LO BND X301 0
 	UP BND X301 1
 	FR BND X302
 	LO BND X302 0
 	UP BND X302 1
 	FR BND X303
 	LO BND X303 0
 	UP BND X303 1
 	FR BND X304
 	LO BND X304 0
 	UP BND X304 3
 	FR BND X305
 	LO BND X305 0
 	UP BND X305 3
 	FR BND X306
 	LO BND X306 0
 	UP BND X306 1
 	FR BND X307
 	LO BND X307 0
 	UP BND X307 1
 	FR BND X308
 	LO BND X308 0
 	UP BND X308 4
 	FR BND X309
 	LO BND X309 0
 	UP BND X309 2
 	FR BND X310
 	LO BND X310 0
 	UP BND X310 1
 	FX BND X311 0
 	FR BND X312
 	LO BND X312 0
 	UP BND X312 3
 	FR BND X313
 	LO BND X313 0
 	UP BND X313 1
 	FR BND X314
 	LO BND X314 0
 	UP BND X314 2
 	FR BND X315
 	LO BND X315 0
 	UP BND X315 1
 	FR BND X316
 	LO BND X316 0
 	UP BND X316 3
 	FR BND X317
 	LO BND X317 0
 	UP BND X317 3
 	FR BND X318
 	LO BND X318 0
 	UP BND X318 1
 	FR BND X319
 	LO BND X319 0
 	UP BND X319 1
 	FR BND X320
 	LO BND X320 0
 	UP BND X320 1
 	FR BND X321
 	LO BND X321 0
 	UP BND X321 2
 	FR BND X322
 	LO BND X322 0
 	UP BND X322 3
 	FR BND X323
 	LO BND X323 0
 	UP BND X323 3
 	FR BND X324
 	LO BND X324 0
 	UP BND X324 4
 	FR BND X325
 	LO BND X325 0
 	UP BND X325 4
 	FR BND X326
 	LO BND X326 0
 	UP BND X326 1
 	FR BND X327
 	LO BND X327 0
 	UP BND X327 4
 	FR BND X328
 	LO BND X328 0
 	UP BND X328 3
 	FR BND X329
 	LO BND X329 0
 	UP BND X329 3
 	FR BND X330
 	LO BND X330 0
 	UP BND X330 1
 	FR BND X331
 	LO BND X331 0
 	UP BND X331 3
 	FR BND X332
 	LO BND X332 0
 	UP BND X332 1
 	FX BND X333 0
 	FR BND X334
 	LO BND X334 0
 	UP BND X334 1
 	FR BND X335
 	LO BND X335 0
 	UP BND X335 2
 	FR BND X336
 	LO BND X336 0
 	UP BND X336 3
 	FR BND X337
 	LO BND X337 0
 	UP BND X337 2
 	FR BND X338
 	LO BND X338 0
 	UP BND X338 3
 	FR BND X339
 	LO BND X339 0
 	UP BND X339 1
 	FR BND X340
 	LO BND X340 0
 	UP BND X340 2
 	FR BND X341
 	LO BND X341 0
 	UP BND X341 3
 	FR BND X342
 	LO BND X342 0
 	UP BND X342 1
 	FR BND X343
 	LO BND X343 0
 	UP BND X343 2
 	FR BND X344
 	LO BND X344 0
 	UP BND X344 2
 	FR BND X345
 	LO BND X345 0
 	UP BND X345 1
 	FR BND X346
 	LO BND X346 0
 	UP BND X346 3
 	FR BND X347
 	LO BND X347 0
 	UP BND X347 2
 	FR BND X348
 	LO BND X348 0
 	UP BND X348 3
 	FR BND X349
 	LO BND X349 0
 	UP BND X349 3
 	FR BND X350
 	LO BND X350 0
 	UP BND X350 5
 	FR BND X351
 	LO BND X351 0
 	UP BND X351 1
 	FR BND X352
 	LO BND X352 0
 	UP BND X352 3
 	FR BND X353
 	LO BND X353 0
 	UP BND X353 1
 	FR BND X354
 	LO BND X354 0
 	UP BND X354 3
 	FR BND X355
 	LO BND X355 0
 	UP BND X355 2
 	FR BND X356
 	LO BND X356 0
 	UP BND X356 1
 	FR BND X357
 	LO BND X357 0
 	UP BND X357 2
 	FR BND X358
 	LO BND X358 0
 	UP BND X358 1
 	FR BND X359
 	LO BND X359 0
 	UP BND X359 3
 	FR BND X360
 	LO BND X360 0
 	UP BND X360 1
 	FR BND X361
 	LO BND X361 0
 	UP BND X361 1
 	FR BND X362
 	LO BND X362 0
 	UP BND X362 1
 	FR BND X363
 	LO BND X363 0
 	UP BND X363 2
 	FR BND X364
 	LO BND X364 0
 	UP BND X364 1
 	FR BND X365
 	LO BND X365 0
 	UP BND X365 3
 	FR BND X366
 	LO BND X366 0
 	UP BND X366 1
 	FX BND X367 0
 	FR BND X368
 	LO BND X368 0
 	UP BND X368 2
 	FR BND X369
 	LO BND X369 0
 	UP BND X369 1
 	FR BND X370
 	LO BND X370 0
 	UP BND X370 2
 	FR BND X371
 	LO BND X371 0
 	UP BND X371 3
 	FR BND X372
 	LO BND X372 0
 	UP BND X372 3
 	FR BND X373
 	LO BND X373 0
 	UP BND X373 1
 	FR BND X374
 	LO BND X374 0
 	UP BND X374 2
 	FR BND X375
 	LO BND X375 0
 	UP BND X375 4
 	FR BND X376
 	LO BND X376 0
 	UP BND X376 2
 	FR BND X377
 	LO BND X377 0
 	UP BND X377 1
 	FX BND X378 0
 	FR BND X379
 	LO BND X379 0
 	UP BND X379 2
 	FR BND X380
 	LO BND X380 0
 	UP BND X380 1
 	FR BND X381
 	LO BND X381 0
 	UP BND X381 1
 	FR BND X382
 	LO BND X382 0
 	UP BND X382 2
 	FX BND X383 0
 	FR BND X384
 	LO BND X384 0
 	UP BND X384 1
 	FR BND X385
 	LO BND X385 0
 	UP BND X385 2
 	FR BND X386
 	LO BND X386 0
 	UP BND X386 1
 	FR BND X387
 	LO BND X387 0
 	UP BND X387 2
 	FR BND X388
 	LO BND X388 0
 	UP BND X388 1
 	FR BND X389
 	LO BND X389 0
 	UP BND X389 2
 	FR BND X390
 	LO BND X390 0
 	UP BND X390 2
 	FR BND X391
 	LO BND X391 0
 	UP BND X391 3
 	FR BND X392
 	LO BND X392 0
 	UP BND X392 2
 	FR BND X393
 	LO BND X393 0
 	UP BND X393 1
 	FR BND X394
 	LO BND X394 0
 	UP BND X394 2
 	FR BND X395
 	LO BND X395 0
 	UP BND X395 3
 	FR BND X396
 	LO BND X396 0
 	UP BND X396 2
ENDATA
