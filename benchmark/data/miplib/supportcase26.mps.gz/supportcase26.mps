* MIPLIB 2017 benchmark v2; LP relaxation (integrality removed).
* Source: https://miplib.zib.de/downloads/benchmark.zip ; retrieved 2026-09-21
* Instance: supportcase26 ; Gleixner et al. (2021), doi:10.1007/s12532-020-00194-3
* Bounds and coefficients preserved; rows/variables renamed; objective minimized.
* Original compressed SHA256: e5769bd12cc2b5e711165d986ec324d68d336d6314e2b9db4156d5003b9f4ae4
NAME supportcase26
ROWS
 N OBJ
 G R0
 G R1
 G R2
 G R3
 G R4
 G R5
 G R6
 G R7
 G R8
 G R9
 G R10
 G R11
 G R12
 G R13
 G R14
 G R15
 G R16
 G R17
 G R18
 G R19
 G R20
 G R21
 G R22
 G R23
 G R24
 G R25
 G R26
 G R27
 G R28
 G R29
 G R30
 G R31
 G R32
 G R33
 G R34
 G R35
 G R36
 G R37
 G R38
 G R39
 G R40
 G R41
 G R42
 G R43
 G R44
 G R45
 G R46
 G R47
 G R48
 G R49
 G R50
 G R51
 G R52
 G R53
 G R54
 G R55
 G R56
 G R57
 G R58
 G R59
 G R60
 G R61
 G R62
 G R63
 G R64
 G R65
 G R66
 G R67
 G R68
 G R69
 G R70
 G R71
 G R72
 G R73
 G R74
 G R75
 G R76
 G R77
 G R78
 G R79
 G R80
 G R81
 G R82
 G R83
 G R84
 G R85
 G R86
 G R87
 G R88
 G R89
 G R90
 G R91
 G R92
 G R93
 G R94
 G R95
 G R96
 G R97
 G R98
 G R99
 G R100
 G R101
 G R102
 G R103
 G R104
 G R105
 G R106
 G R107
 G R108
 G R109
 G R110
 G R111
 G R112
 G R113
 G R114
 G R115
 G R116
 G R117
 G R118
 G R119
 G R120
 G R121
 G R122
 G R123
 G R124
 G R125
 G R126
 G R127
 G R128
 G R129
 G R130
 G R131
 G R132
 G R133
 G R134
 G R135
 G R136
 G R137
 G R138
 G R139
 G R140
 G R141
 G R142
 G R143
 G R144
 G R145
 G R146
 G R147
 G R148
 G R149
 G R150
 G R151
 G R152
 G R153
 G R154
 G R155
 G R156
 G R157
 G R158
 G R159
 G R160
 G R161
 G R162
 G R163
 G R164
 G R165
 G R166
 G R167
 G R168
 G R169
 G R170
 G R171
 G R172
 G R173
 G R174
 G R175
 G R176
 G R177
 G R178
 G R179
 G R180
 G R181
 G R182
 G R183
 G R184
 G R185
 G R186
 G R187
 G R188
 G R189
 G R190
 G R191
 G R192
 G R193
 G R194
 G R195
 G R196
 G R197
 G R198
 G R199
 G R200
 G R201
 G R202
 G R203
 G R204
 G R205
 G R206
 G R207
 G R208
 G R209
 G R210
 G R211
 G R212
 G R213
 G R214
 G R215
 G R216
 G R217
 G R218
 G R219
 G R220
 G R221
 G R222
 G R223
 G R224
 G R225
 G R226
 G R227
 G R228
 G R229
 G R230
 G R231
 G R232
 G R233
 G R234
 G R235
 G R236
 G R237
 G R238
 G R239
 G R240
 G R241
 G R242
 G R243
 G R244
 G R245
 G R246
 G R247
 G R248
 G R249
 G R250
 G R251
 G R252
 G R253
 G R254
 G R255
 G R256
 G R257
 G R258
 G R259
 G R260
 G R261
 G R262
 G R263
 G R264
 G R265
 G R266
 G R267
 G R268
 G R269
 G R270
 G R271
 G R272
 G R273
 G R274
 G R275
 G R276
 G R277
 G R278
 G R279
 G R280
 G R281
 G R282
 G R283
 G R284
 G R285
 G R286
 G R287
 G R288
 G R289
 G R290
 G R291
 G R292
 G R293
 G R294
 G R295
 G R296
 G R297
 G R298
 G R299
 G R300
 G R301
 G R302
 G R303
 G R304
 G R305
 G R306
 G R307
 G R308
 G R309
 G R310
 G R311
 G R312
 G R313
 G R314
 G R315
 G R316
 G R317
 G R318
 G R319
 G R320
 G R321
 G R322
 G R323
 G R324
 G R325
 G R326
 G R327
 G R328
 G R329
 G R330
 G R331
 G R332
 G R333
 G R334
 G R335
 G R336
 G R337
 G R338
 G R339
 G R340
 G R341
 G R342
 G R343
 G R344
 G R345
 G R346
 G R347
 G R348
 G R349
 G R350
 G R351
 G R352
 G R353
 G R354
 G R355
 G R356
 G R357
 G R358
 G R359
 G R360
 G R361
 G R362
 G R363
 G R364
 G R365
 G R366
 G R367
 G R368
 G R369
 G R370
 G R371
 G R372
 G R373
 G R374
 G R375
 G R376
 G R377
 G R378
 G R379
 G R380
 G R381
 G R382
 G R383
 G R384
 G R385
 G R386
 G R387
 G R388
 G R389
 G R390
 G R391
 G R392
 G R393
 G R394
 G R395
 G R396
 G R397
 G R398
 G R399
 G R400
 G R401
 G R402
 G R403
 G R404
 G R405
 G R406
 G R407
 G R408
 G R409
 G R410
 G R411
 G R412
 G R413
 G R414
 G R415
 G R416
 G R417
 G R418
 G R419
 G R420
 G R421
 G R422
 G R423
 G R424
 G R425
 G R426
 G R427
 G R428
 G R429
 G R430
 G R431
 G R432
 G R433
 G R434
 G R435
 G R436
 G R437
 G R438
 G R439
 G R440
 G R441
 G R442
 G R443
 G R444
 G R445
 G R446
 G R447
 G R448
 G R449
 G R450
 G R451
 G R452
 G R453
 G R454
 G R455
 G R456
 G R457
 G R458
 G R459
 G R460
 G R461
 G R462
 G R463
 G R464
 G R465
 G R466
 G R467
 G R468
 G R469
 G R470
 G R471
 G R472
 G R473
 G R474
 G R475
 G R476
 G R477
 G R478
 G R479
 G R480
 G R481
 G R482
 G R483
 G R484
 G R485
 G R486
 G R487
 G R488
 G R489
 G R490
 G R491
 G R492
 G R493
 G R494
 G R495
 G R496
 G R497
 G R498
 G R499
 G R500
 G R501
 G R502
 G R503
 G R504
 G R505
 G R506
 G R507
 G R508
 G R509
 G R510
 G R511
 G R512
 G R513
 G R514
 G R515
 G R516
 G R517
 G R518
 G R519
 G R520
 G R521
 G R522
 G R523
 G R524
 G R525
 G R526
 G R527
 G R528
 G R529
 G R530
 G R531
 G R532
 G R533
 G R534
 G R535
 G R536
 G R537
 G R538
 G R539
 G R540
 G R541
 G R542
 G R543
 G R544
 G R545
 G R546
 G R547
 G R548
 G R549
 G R550
 G R551
 G R552
 G R553
 G R554
 G R555
 G R556
 G R557
 G R558
 G R559
 G R560
 G R561
 G R562
 G R563
 G R564
 G R565
 G R566
 G R567
 G R568
 G R569
 G R570
 G R571
 G R572
 G R573
 G R574
 G R575
 G R576
 G R577
 G R578
 G R579
 G R580
 G R581
 G R582
 G R583
 G R584
 G R585
 G R586
 G R587
 G R588
 G R589
 G R590
 G R591
 G R592
 G R593
 G R594
 G R595
 G R596
 G R597
 G R598
 G R599
 G R600
 G R601
 G R602
 G R603
 G R604
 G R605
 G R606
 G R607
 G R608
 G R609
 G R610
 G R611
 G R612
 G R613
 G R614
 G R615
 G R616
 G R617
 G R618
 G R619
 G R620
 G R621
 G R622
 G R623
 G R624
 G R625
 G R626
 G R627
 G R628
 G R629
 G R630
 G R631
 G R632
 G R633
 G R634
 G R635
 G R636
 G R637
 G R638
 G R639
 G R640
 G R641
 G R642
 G R643
 G R644
 G R645
 G R646
 G R647
 G R648
 G R649
 G R650
 G R651
 G R652
 G R653
 G R654
 G R655
 G R656
 G R657
 G R658
 G R659
 G R660
 G R661
 G R662
 G R663
 G R664
 G R665
 G R666
 G R667
 G R668
 G R669
 G R670
 G R671
 G R672
 G R673
 G R674
 G R675
 G R676
 G R677
 G R678
 G R679
 G R680
 G R681
 G R682
 G R683
 G R684
 G R685
 G R686
 G R687
 G R688
 G R689
 G R690
 G R691
 G R692
 G R693
 G R694
 G R695
 G R696
 G R697
 G R698
 G R699
 G R700
 G R701
 G R702
 G R703
 G R704
 G R705
 G R706
 G R707
 G R708
 G R709
 G R710
 G R711
 G R712
 G R713
 G R714
 G R715
 G R716
 G R717
 G R718
 G R719
 G R720
 G R721
 G R722
 G R723
 G R724
 G R725
 G R726
 G R727
 G R728
 G R729
 G R730
 G R731
 G R732
 G R733
 G R734
 G R735
 G R736
 G R737
 G R738
 G R739
 G R740
 G R741
 G R742
 G R743
 G R744
 G R745
 G R746
 G R747
 G R748
 G R749
 G R750
 G R751
 G R752
 G R753
 G R754
 G R755
 G R756
 G R757
 G R758
 G R759
 G R760
 G R761
 G R762
 G R763
 G R764
 G R765
 G R766
 G R767
 G R768
 G R769
 G R770
 G R771
 G R772
 G R773
 G R774
 G R775
 G R776
 G R777
 G R778
 G R779
 G R780
 G R781
 G R782
 G R783
 G R784
 G R785
 G R786
 G R787
 G R788
 G R789
 G R790
 G R791
 G R792
 G R793
 G R794
 G R795
 G R796
 G R797
 G R798
 G R799
 G R800
 G R801
 G R802
 G R803
 G R804
 G R805
 G R806
 G R807
 G R808
 G R809
 G R810
 G R811
 G R812
 G R813
 G R814
 G R815
 G R816
 G R817
 G R818
 G R819
 G R820
 G R821
 G R822
 G R823
 G R824
 G R825
 G R826
 G R827
 G R828
 G R829
 G R830
 G R831
 G R832
 G R833
 G R834
 G R835
 G R836
 G R837
 G R838
 G R839
 G R840
 G R841
 G R842
 G R843
 G R844
 G R845
 G R846
 G R847
 G R848
 G R849
 G R850
 G R851
 G R852
 G R853
 G R854
 G R855
 G R856
 G R857
 G R858
 G R859
 G R860
 G R861
 G R862
 G R863
 G R864
 G R865
 G R866
 G R867
 G R868
 G R869
COLUMNS
    X0                   OBJ 1
    X0                   R0 1
    X0                   R40 -1
    X0                   R78 -1
    X0                   R79 -1
    X0                   R80 -1
    X0                   R81 -1
    X0                   R82 -1
    X0                   R83 -1
    X0                   R84 -1
    X0                   R85 -1
    X0                   R86 -1
    X0                   R87 -1
    X0                   R88 -1
    X0                   R89 -1
    X0                   R90 -1
    X0                   R91 -1
    X0                   R92 -1
    X0                   R93 -1
    X0                   R94 -1
    X0                   R95 -1
    X0                   R96 -1
    X0                   R97 -1
    X0                   R98 -1
    X0                   R99 -1
    X0                   R474 1
    X0                   R475 1
    X0                   R476 1
    X0                   R477 1
    X0                   R478 1
    X0                   R479 1
    X0                   R480 1
    X0                   R481 1
    X0                   R482 1
    X0                   R483 1
    X0                   R484 1
    X0                   R485 1
    X0                   R486 1
    X0                   R487 1
    X0                   R488 1
    X0                   R489 1
    X0                   R490 1
    X0                   R491 1
    X0                   R492 1
    X0                   R493 1
    X0                   R494 1
    X0                   R495 1
    X1                   OBJ 1
    X1                   R1 1
    X1                   R40 1
    X1                   R41 -1
    X1                   R100 -1
    X1                   R101 -1
    X1                   R102 -1
    X1                   R103 -1
    X1                   R104 -1
    X1                   R105 -1
    X1                   R106 -1
    X1                   R107 -1
    X1                   R108 -1
    X1                   R109 -1
    X1                   R110 -1
    X1                   R111 -1
    X1                   R112 -1
    X1                   R113 -1
    X1                   R114 -1
    X1                   R115 -1
    X1                   R116 -1
    X1                   R117 -1
    X1                   R118 -1
    X1                   R119 -1
    X1                   R120 -1
    X1                   R121 -1
    X1                   R496 1
    X1                   R497 1
    X1                   R498 1
    X1                   R499 1
    X1                   R500 1
    X1                   R501 1
    X1                   R502 1
    X1                   R503 1
    X1                   R504 1
    X1                   R505 1
    X1                   R506 1
    X1                   R507 1
    X1                   R508 1
    X1                   R509 1
    X1                   R510 1
    X1                   R511 1
    X1                   R512 1
    X1                   R513 1
    X1                   R514 1
    X1                   R515 1
    X1                   R516 1
    X1                   R517 1
    X2                   OBJ 1
    X2                   R2 1
    X2                   R41 1
    X2                   R42 -1
    X2                   R122 -1
    X2                   R123 -1
    X2                   R124 -1
    X2                   R125 -1
    X2                   R126 -1
    X2                   R127 -1
    X2                   R128 -1
    X2                   R129 -1
    X2                   R130 -1
    X2                   R131 -1
    X2                   R132 -1
    X2                   R133 -1
    X2                   R134 -1
    X2                   R135 -1
    X2                   R136 -1
    X2                   R137 -1
    X2                   R138 -1
    X2                   R139 -1
    X2                   R140 -1
    X2                   R141 -1
    X2                   R142 -1
    X2                   R143 -1
    X2                   R518 1
    X2                   R519 1
    X2                   R520 1
    X2                   R521 1
    X2                   R522 1
    X2                   R523 1
    X2                   R524 1
    X2                   R525 1
    X2                   R526 1
    X2                   R527 1
    X2                   R528 1
    X2                   R529 1
    X2                   R530 1
    X2                   R531 1
    X2                   R532 1
    X2                   R533 1
    X2                   R534 1
    X2                   R535 1
    X2                   R536 1
    X2                   R537 1
    X2                   R538 1
    X2                   R539 1
    X3                   OBJ 1
    X3                   R3 1
    X3                   R42 1
    X3                   R43 -1
    X3                   R144 -1
    X3                   R145 -1
    X3                   R146 -1
    X3                   R147 -1
    X3                   R148 -1
    X3                   R149 -1
    X3                   R150 -1
    X3                   R151 -1
    X3                   R152 -1
    X3                   R153 -1
    X3                   R154 -1
    X3                   R155 -1
    X3                   R156 -1
    X3                   R157 -1
    X3                   R158 -1
    X3                   R159 -1
    X3                   R160 -1
    X3                   R161 -1
    X3                   R162 -1
    X3                   R163 -1
    X3                   R164 -1
    X3                   R165 -1
    X3                   R540 1
    X3                   R541 1
    X3                   R542 1
    X3                   R543 1
    X3                   R544 1
    X3                   R545 1
    X3                   R546 1
    X3                   R547 1
    X3                   R548 1
    X3                   R549 1
    X3                   R550 1
    X3                   R551 1
    X3                   R552 1
    X3                   R553 1
    X3                   R554 1
    X3                   R555 1
    X3                   R556 1
    X3                   R557 1
    X3                   R558 1
    X3                   R559 1
    X3                   R560 1
    X3                   R561 1
    X4                   OBJ 1
    X4                   R4 1
    X4                   R43 1
    X4                   R44 -1
    X4                   R166 -1
    X4                   R167 -1
    X4                   R168 -1
    X4                   R169 -1
    X4                   R170 -1
    X4                   R171 -1
    X4                   R172 -1
    X4                   R173 -1
    X4                   R174 -1
    X4                   R175 -1
    X4                   R176 -1
    X4                   R177 -1
    X4                   R178 -1
    X4                   R179 -1
    X4                   R180 -1
    X4                   R181 -1
    X4                   R182 -1
    X4                   R183 -1
    X4                   R184 -1
    X4                   R185 -1
    X4                   R186 -1
    X4                   R187 -1
    X4                   R562 1
    X4                   R563 1
    X4                   R564 1
    X4                   R565 1
    X4                   R566 1
    X4                   R567 1
    X4                   R568 1
    X4                   R569 1
    X4                   R570 1
    X4                   R571 1
    X4                   R572 1
    X4                   R573 1
    X4                   R574 1
    X4                   R575 1
    X4                   R576 1
    X4                   R577 1
    X4                   R578 1
    X4                   R579 1
    X4                   R580 1
    X4                   R581 1
    X4                   R582 1
    X4                   R583 1
    X5                   OBJ 1
    X5                   R5 1
    X5                   R44 1
    X5                   R45 -1
    X5                   R188 -1
    X5                   R189 -1
    X5                   R190 -1
    X5                   R191 -1
    X5                   R192 -1
    X5                   R193 -1
    X5                   R194 -1
    X5                   R195 -1
    X5                   R196 -1
    X5                   R197 -1
    X5                   R198 -1
    X5                   R199 -1
    X5                   R200 -1
    X5                   R201 -1
    X5                   R202 -1
    X5                   R203 -1
    X5                   R204 -1
    X5                   R205 -1
    X5                   R206 -1
    X5                   R207 -1
    X5                   R208 -1
    X5                   R209 -1
    X5                   R584 1
    X5                   R585 1
    X5                   R586 1
    X5                   R587 1
    X5                   R588 1
    X5                   R589 1
    X5                   R590 1
    X5                   R591 1
    X5                   R592 1
    X5                   R593 1
    X5                   R594 1
    X5                   R595 1
    X5                   R596 1
    X5                   R597 1
    X5                   R598 1
    X5                   R599 1
    X5                   R600 1
    X5                   R601 1
    X5                   R602 1
    X5                   R603 1
    X5                   R604 1
    X5                   R605 1
    X6                   OBJ 1
    X6                   R6 1
    X6                   R45 1
    X6                   R46 -1
    X6                   R210 -1
    X6                   R211 -1
    X6                   R212 -1
    X6                   R213 -1
    X6                   R214 -1
    X6                   R215 -1
    X6                   R216 -1
    X6                   R217 -1
    X6                   R218 -1
    X6                   R219 -1
    X6                   R220 -1
    X6                   R221 -1
    X6                   R222 -1
    X6                   R223 -1
    X6                   R224 -1
    X6                   R225 -1
    X6                   R226 -1
    X6                   R227 -1
    X6                   R228 -1
    X6                   R229 -1
    X6                   R230 -1
    X6                   R231 -1
    X6                   R606 1
    X6                   R607 1
    X6                   R608 1
    X6                   R609 1
    X6                   R610 1
    X6                   R611 1
    X6                   R612 1
    X6                   R613 1
    X6                   R614 1
    X6                   R615 1
    X6                   R616 1
    X6                   R617 1
    X6                   R618 1
    X6                   R619 1
    X6                   R620 1
    X6                   R621 1
    X6                   R622 1
    X6                   R623 1
    X6                   R624 1
    X6                   R625 1
    X6                   R626 1
    X6                   R627 1
    X7                   OBJ 1
    X7                   R7 1
    X7                   R46 1
    X7                   R47 -1
    X7                   R232 -1
    X7                   R233 -1
    X7                   R234 -1
    X7                   R235 -1
    X7                   R236 -1
    X7                   R237 -1
    X7                   R238 -1
    X7                   R239 -1
    X7                   R240 -1
    X7                   R241 -1
    X7                   R242 -1
    X7                   R243 -1
    X7                   R244 -1
    X7                   R245 -1
    X7                   R246 -1
    X7                   R247 -1
    X7                   R248 -1
    X7                   R249 -1
    X7                   R250 -1
    X7                   R251 -1
    X7                   R252 -1
    X7                   R253 -1
    X7                   R628 1
    X7                   R629 1
    X7                   R630 1
    X7                   R631 1
    X7                   R632 1
    X7                   R633 1
    X7                   R634 1
    X7                   R635 1
    X7                   R636 1
    X7                   R637 1
    X7                   R638 1
    X7                   R639 1
    X7                   R640 1
    X7                   R641 1
    X7                   R642 1
    X7                   R643 1
    X7                   R644 1
    X7                   R645 1
    X7                   R646 1
    X7                   R647 1
    X7                   R648 1
    X7                   R649 1
    X8                   OBJ 1
    X8                   R8 1
    X8                   R47 1
    X8                   R48 -1
    X8                   R254 -1
    X8                   R255 -1
    X8                   R256 -1
    X8                   R257 -1
    X8                   R258 -1
    X8                   R259 -1
    X8                   R260 -1
    X8                   R261 -1
    X8                   R262 -1
    X8                   R263 -1
    X8                   R264 -1
    X8                   R265 -1
    X8                   R266 -1
    X8                   R267 -1
    X8                   R268 -1
    X8                   R269 -1
    X8                   R270 -1
    X8                   R271 -1
    X8                   R272 -1
    X8                   R273 -1
    X8                   R274 -1
    X8                   R275 -1
    X8                   R650 1
    X8                   R651 1
    X8                   R652 1
    X8                   R653 1
    X8                   R654 1
    X8                   R655 1
    X8                   R656 1
    X8                   R657 1
    X8                   R658 1
    X8                   R659 1
    X8                   R660 1
    X8                   R661 1
    X8                   R662 1
    X8                   R663 1
    X8                   R664 1
    X8                   R665 1
    X8                   R666 1
    X8                   R667 1
    X8                   R668 1
    X8                   R669 1
    X8                   R670 1
    X8                   R671 1
    X9                   OBJ 1
    X9                   R9 1
    X9                   R48 1
    X9                   R49 -1
    X9                   R276 -1
    X9                   R277 -1
    X9                   R278 -1
    X9                   R279 -1
    X9                   R280 -1
    X9                   R281 -1
    X9                   R282 -1
    X9                   R283 -1
    X9                   R284 -1
    X9                   R285 -1
    X9                   R286 -1
    X9                   R287 -1
    X9                   R288 -1
    X9                   R289 -1
    X9                   R290 -1
    X9                   R291 -1
    X9                   R292 -1
    X9                   R293 -1
    X9                   R294 -1
    X9                   R295 -1
    X9                   R296 -1
    X9                   R297 -1
    X9                   R672 1
    X9                   R673 1
    X9                   R674 1
    X9                   R675 1
    X9                   R676 1
    X9                   R677 1
    X9                   R678 1
    X9                   R679 1
    X9                   R680 1
    X9                   R681 1
    X9                   R682 1
    X9                   R683 1
    X9                   R684 1
    X9                   R685 1
    X9                   R686 1
    X9                   R687 1
    X9                   R688 1
    X9                   R689 1
    X9                   R690 1
    X9                   R691 1
    X9                   R692 1
    X9                   R693 1
    X10                  OBJ 1
    X10                  R10 1
    X10                  R49 1
    X10                  R50 -1
    X10                  R298 -1
    X10                  R299 -1
    X10                  R300 -1
    X10                  R301 -1
    X10                  R302 -1
    X10                  R303 -1
    X10                  R304 -1
    X10                  R305 -1
    X10                  R306 -1
    X10                  R307 -1
    X10                  R308 -1
    X10                  R309 -1
    X10                  R310 -1
    X10                  R311 -1
    X10                  R312 -1
    X10                  R313 -1
    X10                  R314 -1
    X10                  R315 -1
    X10                  R316 -1
    X10                  R317 -1
    X10                  R318 -1
    X10                  R319 -1
    X10                  R694 1
    X10                  R695 1
    X10                  R696 1
    X10                  R697 1
    X10                  R698 1
    X10                  R699 1
    X10                  R700 1
    X10                  R701 1
    X10                  R702 1
    X10                  R703 1
    X10                  R704 1
    X10                  R705 1
    X10                  R706 1
    X10                  R707 1
    X10                  R708 1
    X10                  R709 1
    X10                  R710 1
    X10                  R711 1
    X10                  R712 1
    X10                  R713 1
    X10                  R714 1
    X10                  R715 1
    X11                  OBJ 1
    X11                  R11 1
    X11                  R50 1
    X11                  R51 -1
    X11                  R320 -1
    X11                  R321 -1
    X11                  R322 -1
    X11                  R323 -1
    X11                  R324 -1
    X11                  R325 -1
    X11                  R326 -1
    X11                  R327 -1
    X11                  R328 -1
    X11                  R329 -1
    X11                  R330 -1
    X11                  R331 -1
    X11                  R332 -1
    X11                  R333 -1
    X11                  R334 -1
    X11                  R335 -1
    X11                  R336 -1
    X11                  R337 -1
    X11                  R338 -1
    X11                  R339 -1
    X11                  R340 -1
    X11                  R341 -1
    X11                  R716 1
    X11                  R717 1
    X11                  R718 1
    X11                  R719 1
    X11                  R720 1
    X11                  R721 1
    X11                  R722 1
    X11                  R723 1
    X11                  R724 1
    X11                  R725 1
    X11                  R726 1
    X11                  R727 1
    X11                  R728 1
    X11                  R729 1
    X11                  R730 1
    X11                  R731 1
    X11                  R732 1
    X11                  R733 1
    X11                  R734 1
    X11                  R735 1
    X11                  R736 1
    X11                  R737 1
    X12                  OBJ 1
    X12                  R12 1
    X12                  R51 1
    X12                  R52 -1
    X12                  R342 -1
    X12                  R343 -1
    X12                  R344 -1
    X12                  R345 -1
    X12                  R346 -1
    X12                  R347 -1
    X12                  R348 -1
    X12                  R349 -1
    X12                  R350 -1
    X12                  R351 -1
    X12                  R352 -1
    X12                  R353 -1
    X12                  R354 -1
    X12                  R355 -1
    X12                  R356 -1
    X12                  R357 -1
    X12                  R358 -1
    X12                  R359 -1
    X12                  R360 -1
    X12                  R361 -1
    X12                  R362 -1
    X12                  R363 -1
    X12                  R738 1
    X12                  R739 1
    X12                  R740 1
    X12                  R741 1
    X12                  R742 1
    X12                  R743 1
    X12                  R744 1
    X12                  R745 1
    X12                  R746 1
    X12                  R747 1
    X12                  R748 1
    X12                  R749 1
    X12                  R750 1
    X12                  R751 1
    X12                  R752 1
    X12                  R753 1
    X12                  R754 1
    X12                  R755 1
    X12                  R756 1
    X12                  R757 1
    X12                  R758 1
    X12                  R759 1
    X13                  OBJ 1
    X13                  R13 1
    X13                  R52 1
    X13                  R53 -1
    X13                  R364 -1
    X13                  R365 -1
    X13                  R366 -1
    X13                  R367 -1
    X13                  R368 -1
    X13                  R369 -1
    X13                  R370 -1
    X13                  R371 -1
    X13                  R372 -1
    X13                  R373 -1
    X13                  R374 -1
    X13                  R375 -1
    X13                  R376 -1
    X13                  R377 -1
    X13                  R378 -1
    X13                  R379 -1
    X13                  R380 -1
    X13                  R381 -1
    X13                  R382 -1
    X13                  R383 -1
    X13                  R384 -1
    X13                  R385 -1
    X13                  R760 1
    X13                  R761 1
    X13                  R762 1
    X13                  R763 1
    X13                  R764 1
    X13                  R765 1
    X13                  R766 1
    X13                  R767 1
    X13                  R768 1
    X13                  R769 1
    X13                  R770 1
    X13                  R771 1
    X13                  R772 1
    X13                  R773 1
    X13                  R774 1
    X13                  R775 1
    X13                  R776 1
    X13                  R777 1
    X13                  R778 1
    X13                  R779 1
    X13                  R780 1
    X13                  R781 1
    X14                  OBJ 1
    X14                  R14 1
    X14                  R53 1
    X14                  R54 -1
    X14                  R386 -1
    X14                  R387 -1
    X14                  R388 -1
    X14                  R389 -1
    X14                  R390 -1
    X14                  R391 -1
    X14                  R392 -1
    X14                  R393 -1
    X14                  R394 -1
    X14                  R395 -1
    X14                  R396 -1
    X14                  R397 -1
    X14                  R398 -1
    X14                  R399 -1
    X14                  R400 -1
    X14                  R401 -1
    X14                  R402 -1
    X14                  R403 -1
    X14                  R404 -1
    X14                  R405 -1
    X14                  R406 -1
    X14                  R407 -1
    X14                  R782 1
    X14                  R783 1
    X14                  R784 1
    X14                  R785 1
    X14                  R786 1
    X14                  R787 1
    X14                  R788 1
    X14                  R789 1
    X14                  R790 1
    X14                  R791 1
    X14                  R792 1
    X14                  R793 1
    X14                  R794 1
    X14                  R795 1
    X14                  R796 1
    X14                  R797 1
    X14                  R798 1
    X14                  R799 1
    X14                  R800 1
    X14                  R801 1
    X14                  R802 1
    X14                  R803 1
    X15                  OBJ 1
    X15                  R15 1
    X15                  R54 1
    X15                  R55 -1
    X15                  R408 -1
    X15                  R409 -1
    X15                  R410 -1
    X15                  R411 -1
    X15                  R412 -1
    X15                  R413 -1
    X15                  R414 -1
    X15                  R415 -1
    X15                  R416 -1
    X15                  R417 -1
    X15                  R418 -1
    X15                  R419 -1
    X15                  R420 -1
    X15                  R421 -1
    X15                  R422 -1
    X15                  R423 -1
    X15                  R424 -1
    X15                  R425 -1
    X15                  R426 -1
    X15                  R427 -1
    X15                  R428 -1
    X15                  R429 -1
    X15                  R804 1
    X15                  R805 1
    X15                  R806 1
    X15                  R807 1
    X15                  R808 1
    X15                  R809 1
    X15                  R810 1
    X15                  R811 1
    X15                  R812 1
    X15                  R813 1
    X15                  R814 1
    X15                  R815 1
    X15                  R816 1
    X15                  R817 1
    X15                  R818 1
    X15                  R819 1
    X15                  R820 1
    X15                  R821 1
    X15                  R822 1
    X15                  R823 1
    X15                  R824 1
    X15                  R825 1
    X16                  OBJ 1
    X16                  R16 1
    X16                  R55 1
    X16                  R56 -1
    X16                  R430 -1
    X16                  R431 -1
    X16                  R432 -1
    X16                  R433 -1
    X16                  R434 -1
    X16                  R435 -1
    X16                  R436 -1
    X16                  R437 -1
    X16                  R438 -1
    X16                  R439 -1
    X16                  R440 -1
    X16                  R441 -1
    X16                  R442 -1
    X16                  R443 -1
    X16                  R444 -1
    X16                  R445 -1
    X16                  R446 -1
    X16                  R447 -1
    X16                  R448 -1
    X16                  R449 -1
    X16                  R450 -1
    X16                  R451 -1
    X16                  R826 1
    X16                  R827 1
    X16                  R828 1
    X16                  R829 1
    X16                  R830 1
    X16                  R831 1
    X16                  R832 1
    X16                  R833 1
    X16                  R834 1
    X16                  R835 1
    X16                  R836 1
    X16                  R837 1
    X16                  R838 1
    X16                  R839 1
    X16                  R840 1
    X16                  R841 1
    X16                  R842 1
    X16                  R843 1
    X16                  R844 1
    X16                  R845 1
    X16                  R846 1
    X16                  R847 1
    X17                  OBJ 1
    X17                  R17 1
    X17                  R56 1
    X17                  R452 -1
    X17                  R453 -1
    X17                  R454 -1
    X17                  R455 -1
    X17                  R456 -1
    X17                  R457 -1
    X17                  R458 -1
    X17                  R459 -1
    X17                  R460 -1
    X17                  R461 -1
    X17                  R462 -1
    X17                  R463 -1
    X17                  R464 -1
    X17                  R465 -1
    X17                  R466 -1
    X17                  R467 -1
    X17                  R468 -1
    X17                  R469 -1
    X17                  R470 -1
    X17                  R471 -1
    X17                  R472 -1
    X17                  R473 -1
    X17                  R848 1
    X17                  R849 1
    X17                  R850 1
    X17                  R851 1
    X17                  R852 1
    X17                  R853 1
    X17                  R854 1
    X17                  R855 1
    X17                  R856 1
    X17                  R857 1
    X17                  R858 1
    X17                  R859 1
    X17                  R860 1
    X17                  R861 1
    X17                  R862 1
    X17                  R863 1
    X17                  R864 1
    X17                  R865 1
    X17                  R866 1
    X17                  R867 1
    X17                  R868 1
    X17                  R869 1
    X18                  OBJ 1
    X18                  R18 1
    X18                  R57 -1
    X18                  R78 1
    X18                  R100 1
    X18                  R122 1
    X18                  R144 1
    X18                  R166 1
    X18                  R188 1
    X18                  R210 1
    X18                  R232 1
    X18                  R254 1
    X18                  R276 1
    X18                  R298 1
    X18                  R320 1
    X18                  R342 1
    X18                  R364 1
    X18                  R386 1
    X18                  R408 1
    X18                  R430 1
    X18                  R452 1
    X18                  R474 -1
    X18                  R496 -1
    X18                  R518 -1
    X18                  R540 -1
    X18                  R562 -1
    X18                  R584 -1
    X18                  R606 -1
    X18                  R628 -1
    X18                  R650 -1
    X18                  R672 -1
    X18                  R694 -1
    X18                  R716 -1
    X18                  R738 -1
    X18                  R760 -1
    X18                  R782 -1
    X18                  R804 -1
    X18                  R826 -1
    X18                  R848 -1
    X19                  OBJ 1
    X19                  R19 1
    X19                  R57 1
    X19                  R58 -1
    X19                  R79 1
    X19                  R101 1
    X19                  R123 1
    X19                  R145 1
    X19                  R167 1
    X19                  R189 1
    X19                  R211 1
    X19                  R233 1
    X19                  R255 1
    X19                  R277 1
    X19                  R299 1
    X19                  R321 1
    X19                  R343 1
    X19                  R365 1
    X19                  R387 1
    X19                  R409 1
    X19                  R431 1
    X19                  R453 1
    X19                  R475 -1
    X19                  R497 -1
    X19                  R519 -1
    X19                  R541 -1
    X19                  R563 -1
    X19                  R585 -1
    X19                  R607 -1
    X19                  R629 -1
    X19                  R651 -1
    X19                  R673 -1
    X19                  R695 -1
    X19                  R717 -1
    X19                  R739 -1
    X19                  R761 -1
    X19                  R783 -1
    X19                  R805 -1
    X19                  R827 -1
    X19                  R849 -1
    X20                  OBJ 1
    X20                  R20 1
    X20                  R58 1
    X20                  R59 -1
    X20                  R80 1
    X20                  R102 1
    X20                  R124 1
    X20                  R146 1
    X20                  R168 1
    X20                  R190 1
    X20                  R212 1
    X20                  R234 1
    X20                  R256 1
    X20                  R278 1
    X20                  R300 1
    X20                  R322 1
    X20                  R344 1
    X20                  R366 1
    X20                  R388 1
    X20                  R410 1
    X20                  R432 1
    X20                  R454 1
    X20                  R476 -1
    X20                  R498 -1
    X20                  R520 -1
    X20                  R542 -1
    X20                  R564 -1
    X20                  R586 -1
    X20                  R608 -1
    X20                  R630 -1
    X20                  R652 -1
    X20                  R674 -1
    X20                  R696 -1
    X20                  R718 -1
    X20                  R740 -1
    X20                  R762 -1
    X20                  R784 -1
    X20                  R806 -1
    X20                  R828 -1
    X20                  R850 -1
    X21                  OBJ 1
    X21                  R21 1
    X21                  R59 1
    X21                  R60 -1
    X21                  R81 1
    X21                  R103 1
    X21                  R125 1
    X21                  R147 1
    X21                  R169 1
    X21                  R191 1
    X21                  R213 1
    X21                  R235 1
    X21                  R257 1
    X21                  R279 1
    X21                  R301 1
    X21                  R323 1
    X21                  R345 1
    X21                  R367 1
    X21                  R389 1
    X21                  R411 1
    X21                  R433 1
    X21                  R455 1
    X21                  R477 -1
    X21                  R499 -1
    X21                  R521 -1
    X21                  R543 -1
    X21                  R565 -1
    X21                  R587 -1
    X21                  R609 -1
    X21                  R631 -1
    X21                  R653 -1
    X21                  R675 -1
    X21                  R697 -1
    X21                  R719 -1
    X21                  R741 -1
    X21                  R763 -1
    X21                  R785 -1
    X21                  R807 -1
    X21                  R829 -1
    X21                  R851 -1
    X22                  OBJ 1
    X22                  R22 1
    X22                  R60 1
    X22                  R61 -1
    X22                  R82 1
    X22                  R104 1
    X22                  R126 1
    X22                  R148 1
    X22                  R170 1
    X22                  R192 1
    X22                  R214 1
    X22                  R236 1
    X22                  R258 1
    X22                  R280 1
    X22                  R302 1
    X22                  R324 1
    X22                  R346 1
    X22                  R368 1
    X22                  R390 1
    X22                  R412 1
    X22                  R434 1
    X22                  R456 1
    X22                  R478 -1
    X22                  R500 -1
    X22                  R522 -1
    X22                  R544 -1
    X22                  R566 -1
    X22                  R588 -1
    X22                  R610 -1
    X22                  R632 -1
    X22                  R654 -1
    X22                  R676 -1
    X22                  R698 -1
    X22                  R720 -1
    X22                  R742 -1
    X22                  R764 -1
    X22                  R786 -1
    X22                  R808 -1
    X22                  R830 -1
    X22                  R852 -1
    X23                  OBJ 1
    X23                  R23 1
    X23                  R61 1
    X23                  R62 -1
    X23                  R83 1
    X23                  R105 1
    X23                  R127 1
    X23                  R149 1
    X23                  R171 1
    X23                  R193 1
    X23                  R215 1
    X23                  R237 1
    X23                  R259 1
    X23                  R281 1
    X23                  R303 1
    X23                  R325 1
    X23                  R347 1
    X23                  R369 1
    X23                  R391 1
    X23                  R413 1
    X23                  R435 1
    X23                  R457 1
    X23                  R479 -1
    X23                  R501 -1
    X23                  R523 -1
    X23                  R545 -1
    X23                  R567 -1
    X23                  R589 -1
    X23                  R611 -1
    X23                  R633 -1
    X23                  R655 -1
    X23                  R677 -1
    X23                  R699 -1
    X23                  R721 -1
    X23                  R743 -1
    X23                  R765 -1
    X23                  R787 -1
    X23                  R809 -1
    X23                  R831 -1
    X23                  R853 -1
    X24                  OBJ 1
    X24                  R24 1
    X24                  R62 1
    X24                  R63 -1
    X24                  R84 1
    X24                  R106 1
    X24                  R128 1
    X24                  R150 1
    X24                  R172 1
    X24                  R194 1
    X24                  R216 1
    X24                  R238 1
    X24                  R260 1
    X24                  R282 1
    X24                  R304 1
    X24                  R326 1
    X24                  R348 1
    X24                  R370 1
    X24                  R392 1
    X24                  R414 1
    X24                  R436 1
    X24                  R458 1
    X24                  R480 -1
    X24                  R502 -1
    X24                  R524 -1
    X24                  R546 -1
    X24                  R568 -1
    X24                  R590 -1
    X24                  R612 -1
    X24                  R634 -1
    X24                  R656 -1
    X24                  R678 -1
    X24                  R700 -1
    X24                  R722 -1
    X24                  R744 -1
    X24                  R766 -1
    X24                  R788 -1
    X24                  R810 -1
    X24                  R832 -1
    X24                  R854 -1
    X25                  OBJ 1
    X25                  R25 1
    X25                  R63 1
    X25                  R64 -1
    X25                  R85 1
    X25                  R107 1
    X25                  R129 1
    X25                  R151 1
    X25                  R173 1
    X25                  R195 1
    X25                  R217 1
    X25                  R239 1
    X25                  R261 1
    X25                  R283 1
    X25                  R305 1
    X25                  R327 1
    X25                  R349 1
    X25                  R371 1
    X25                  R393 1
    X25                  R415 1
    X25                  R437 1
    X25                  R459 1
    X25                  R481 -1
    X25                  R503 -1
    X25                  R525 -1
    X25                  R547 -1
    X25                  R569 -1
    X25                  R591 -1
    X25                  R613 -1
    X25                  R635 -1
    X25                  R657 -1
    X25                  R679 -1
    X25                  R701 -1
    X25                  R723 -1
    X25                  R745 -1
    X25                  R767 -1
    X25                  R789 -1
    X25                  R811 -1
    X25                  R833 -1
    X25                  R855 -1
    X26                  OBJ 1
    X26                  R26 1
    X26                  R64 1
    X26                  R65 -1
    X26                  R86 1
    X26                  R108 1
    X26                  R130 1
    X26                  R152 1
    X26                  R174 1
    X26                  R196 1
    X26                  R218 1
    X26                  R240 1
    X26                  R262 1
    X26                  R284 1
    X26                  R306 1
    X26                  R328 1
    X26                  R350 1
    X26                  R372 1
    X26                  R394 1
    X26                  R416 1
    X26                  R438 1
    X26                  R460 1
    X26                  R482 -1
    X26                  R504 -1
    X26                  R526 -1
    X26                  R548 -1
    X26                  R570 -1
    X26                  R592 -1
    X26                  R614 -1
    X26                  R636 -1
    X26                  R658 -1
    X26                  R680 -1
    X26                  R702 -1
    X26                  R724 -1
    X26                  R746 -1
    X26                  R768 -1
    X26                  R790 -1
    X26                  R812 -1
    X26                  R834 -1
    X26                  R856 -1
    X27                  OBJ 1
    X27                  R27 1
    X27                  R65 1
    X27                  R66 -1
    X27                  R87 1
    X27                  R109 1
    X27                  R131 1
    X27                  R153 1
    X27                  R175 1
    X27                  R197 1
    X27                  R219 1
    X27                  R241 1
    X27                  R263 1
    X27                  R285 1
    X27                  R307 1
    X27                  R329 1
    X27                  R351 1
    X27                  R373 1
    X27                  R395 1
    X27                  R417 1
    X27                  R439 1
    X27                  R461 1
    X27                  R483 -1
    X27                  R505 -1
    X27                  R527 -1
    X27                  R549 -1
    X27                  R571 -1
    X27                  R593 -1
    X27                  R615 -1
    X27                  R637 -1
    X27                  R659 -1
    X27                  R681 -1
    X27                  R703 -1
    X27                  R725 -1
    X27                  R747 -1
    X27                  R769 -1
    X27                  R791 -1
    X27                  R813 -1
    X27                  R835 -1
    X27                  R857 -1
    X28                  OBJ 1
    X28                  R28 1
    X28                  R66 1
    X28                  R67 -1
    X28                  R88 1
    X28                  R110 1
    X28                  R132 1
    X28                  R154 1
    X28                  R176 1
    X28                  R198 1
    X28                  R220 1
    X28                  R242 1
    X28                  R264 1
    X28                  R286 1
    X28                  R308 1
    X28                  R330 1
    X28                  R352 1
    X28                  R374 1
    X28                  R396 1
    X28                  R418 1
    X28                  R440 1
    X28                  R462 1
    X28                  R484 -1
    X28                  R506 -1
    X28                  R528 -1
    X28                  R550 -1
    X28                  R572 -1
    X28                  R594 -1
    X28                  R616 -1
    X28                  R638 -1
    X28                  R660 -1
    X28                  R682 -1
    X28                  R704 -1
    X28                  R726 -1
    X28                  R748 -1
    X28                  R770 -1
    X28                  R792 -1
    X28                  R814 -1
    X28                  R836 -1
    X28                  R858 -1
    X29                  OBJ 1
    X29                  R29 1
    X29                  R67 1
    X29                  R68 -1
    X29                  R89 1
    X29                  R111 1
    X29                  R133 1
    X29                  R155 1
    X29                  R177 1
    X29                  R199 1
    X29                  R221 1
    X29                  R243 1
    X29                  R265 1
    X29                  R287 1
    X29                  R309 1
    X29                  R331 1
    X29                  R353 1
    X29                  R375 1
    X29                  R397 1
    X29                  R419 1
    X29                  R441 1
    X29                  R463 1
    X29                  R485 -1
    X29                  R507 -1
    X29                  R529 -1
    X29                  R551 -1
    X29                  R573 -1
    X29                  R595 -1
    X29                  R617 -1
    X29                  R639 -1
    X29                  R661 -1
    X29                  R683 -1
    X29                  R705 -1
    X29                  R727 -1
    X29                  R749 -1
    X29                  R771 -1
    X29                  R793 -1
    X29                  R815 -1
    X29                  R837 -1
    X29                  R859 -1
    X30                  OBJ 1
    X30                  R30 1
    X30                  R68 1
    X30                  R69 -1
    X30                  R90 1
    X30                  R112 1
    X30                  R134 1
    X30                  R156 1
    X30                  R178 1
    X30                  R200 1
    X30                  R222 1
    X30                  R244 1
    X30                  R266 1
    X30                  R288 1
    X30                  R310 1
    X30                  R332 1
    X30                  R354 1
    X30                  R376 1
    X30                  R398 1
    X30                  R420 1
    X30                  R442 1
    X30                  R464 1
    X30                  R486 -1
    X30                  R508 -1
    X30                  R530 -1
    X30                  R552 -1
    X30                  R574 -1
    X30                  R596 -1
    X30                  R618 -1
    X30                  R640 -1
    X30                  R662 -1
    X30                  R684 -1
    X30                  R706 -1
    X30                  R728 -1
    X30                  R750 -1
    X30                  R772 -1
    X30                  R794 -1
    X30                  R816 -1
    X30                  R838 -1
    X30                  R860 -1
    X31                  OBJ 1
    X31                  R31 1
    X31                  R69 1
    X31                  R70 -1
    X31                  R91 1
    X31                  R113 1
    X31                  R135 1
    X31                  R157 1
    X31                  R179 1
    X31                  R201 1
    X31                  R223 1
    X31                  R245 1
    X31                  R267 1
    X31                  R289 1
    X31                  R311 1
    X31                  R333 1
    X31                  R355 1
    X31                  R377 1
    X31                  R399 1
    X31                  R421 1
    X31                  R443 1
    X31                  R465 1
    X31                  R487 -1
    X31                  R509 -1
    X31                  R531 -1
    X31                  R553 -1
    X31                  R575 -1
    X31                  R597 -1
    X31                  R619 -1
    X31                  R641 -1
    X31                  R663 -1
    X31                  R685 -1
    X31                  R707 -1
    X31                  R729 -1
    X31                  R751 -1
    X31                  R773 -1
    X31                  R795 -1
    X31                  R817 -1
    X31                  R839 -1
    X31                  R861 -1
    X32                  OBJ 1
    X32                  R32 1
    X32                  R70 1
    X32                  R71 -1
    X32                  R92 1
    X32                  R114 1
    X32                  R136 1
    X32                  R158 1
    X32                  R180 1
    X32                  R202 1
    X32                  R224 1
    X32                  R246 1
    X32                  R268 1
    X32                  R290 1
    X32                  R312 1
    X32                  R334 1
    X32                  R356 1
    X32                  R378 1
    X32                  R400 1
    X32                  R422 1
    X32                  R444 1
    X32                  R466 1
    X32                  R488 -1
    X32                  R510 -1
    X32                  R532 -1
    X32                  R554 -1
    X32                  R576 -1
    X32                  R598 -1
    X32                  R620 -1
    X32                  R642 -1
    X32                  R664 -1
    X32                  R686 -1
    X32                  R708 -1
    X32                  R730 -1
    X32                  R752 -1
    X32                  R774 -1
    X32                  R796 -1
    X32                  R818 -1
    X32                  R840 -1
    X32                  R862 -1
    X33                  OBJ 1
    X33                  R33 1
    X33                  R71 1
    X33                  R72 -1
    X33                  R93 1
    X33                  R115 1
    X33                  R137 1
    X33                  R159 1
    X33                  R181 1
    X33                  R203 1
    X33                  R225 1
    X33                  R247 1
    X33                  R269 1
    X33                  R291 1
    X33                  R313 1
    X33                  R335 1
    X33                  R357 1
    X33                  R379 1
    X33                  R401 1
    X33                  R423 1
    X33                  R445 1
    X33                  R467 1
    X33                  R489 -1
    X33                  R511 -1
    X33                  R533 -1
    X33                  R555 -1
    X33                  R577 -1
    X33                  R599 -1
    X33                  R621 -1
    X33                  R643 -1
    X33                  R665 -1
    X33                  R687 -1
    X33                  R709 -1
    X33                  R731 -1
    X33                  R753 -1
    X33                  R775 -1
    X33                  R797 -1
    X33                  R819 -1
    X33                  R841 -1
    X33                  R863 -1
    X34                  OBJ 1
    X34                  R34 1
    X34                  R72 1
    X34                  R73 -1
    X34                  R94 1
    X34                  R116 1
    X34                  R138 1
    X34                  R160 1
    X34                  R182 1
    X34                  R204 1
    X34                  R226 1
    X34                  R248 1
    X34                  R270 1
    X34                  R292 1
    X34                  R314 1
    X34                  R336 1
    X34                  R358 1
    X34                  R380 1
    X34                  R402 1
    X34                  R424 1
    X34                  R446 1
    X34                  R468 1
    X34                  R490 -1
    X34                  R512 -1
    X34                  R534 -1
    X34                  R556 -1
    X34                  R578 -1
    X34                  R600 -1
    X34                  R622 -1
    X34                  R644 -1
    X34                  R666 -1
    X34                  R688 -1
    X34                  R710 -1
    X34                  R732 -1
    X34                  R754 -1
    X34                  R776 -1
    X34                  R798 -1
    X34                  R820 -1
    X34                  R842 -1
    X34                  R864 -1
    X35                  OBJ 1
    X35                  R35 1
    X35                  R73 1
    X35                  R74 -1
    X35                  R95 1
    X35                  R117 1
    X35                  R139 1
    X35                  R161 1
    X35                  R183 1
    X35                  R205 1
    X35                  R227 1
    X35                  R249 1
    X35                  R271 1
    X35                  R293 1
    X35                  R315 1
    X35                  R337 1
    X35                  R359 1
    X35                  R381 1
    X35                  R403 1
    X35                  R425 1
    X35                  R447 1
    X35                  R469 1
    X35                  R491 -1
    X35                  R513 -1
    X35                  R535 -1
    X35                  R557 -1
    X35                  R579 -1
    X35                  R601 -1
    X35                  R623 -1
    X35                  R645 -1
    X35                  R667 -1
    X35                  R689 -1
    X35                  R711 -1
    X35                  R733 -1
    X35                  R755 -1
    X35                  R777 -1
    X35                  R799 -1
    X35                  R821 -1
    X35                  R843 -1
    X35                  R865 -1
    X36                  OBJ 1
    X36                  R36 1
    X36                  R74 1
    X36                  R75 -1
    X36                  R96 1
    X36                  R118 1
    X36                  R140 1
    X36                  R162 1
    X36                  R184 1
    X36                  R206 1
    X36                  R228 1
    X36                  R250 1
    X36                  R272 1
    X36                  R294 1
    X36                  R316 1
    X36                  R338 1
    X36                  R360 1
    X36                  R382 1
    X36                  R404 1
    X36                  R426 1
    X36                  R448 1
    X36                  R470 1
    X36                  R492 -1
    X36                  R514 -1
    X36                  R536 -1
    X36                  R558 -1
    X36                  R580 -1
    X36                  R602 -1
    X36                  R624 -1
    X36                  R646 -1
    X36                  R668 -1
    X36                  R690 -1
    X36                  R712 -1
    X36                  R734 -1
    X36                  R756 -1
    X36                  R778 -1
    X36                  R800 -1
    X36                  R822 -1
    X36                  R844 -1
    X36                  R866 -1
    X37                  OBJ 1
    X37                  R37 1
    X37                  R75 1
    X37                  R76 -1
    X37                  R97 1
    X37                  R119 1
    X37                  R141 1
    X37                  R163 1
    X37                  R185 1
    X37                  R207 1
    X37                  R229 1
    X37                  R251 1
    X37                  R273 1
    X37                  R295 1
    X37                  R317 1
    X37                  R339 1
    X37                  R361 1
    X37                  R383 1
    X37                  R405 1
    X37                  R427 1
    X37                  R449 1
    X37                  R471 1
    X37                  R493 -1
    X37                  R515 -1
    X37                  R537 -1
    X37                  R559 -1
    X37                  R581 -1
    X37                  R603 -1
    X37                  R625 -1
    X37                  R647 -1
    X37                  R669 -1
    X37                  R691 -1
    X37                  R713 -1
    X37                  R735 -1
    X37                  R757 -1
    X37                  R779 -1
    X37                  R801 -1
    X37                  R823 -1
    X37                  R845 -1
    X37                  R867 -1
    X38                  OBJ 1
    X38                  R38 1
    X38                  R76 1
    X38                  R77 -1
    X38                  R98 1
    X38                  R120 1
    X38                  R142 1
    X38                  R164 1
    X38                  R186 1
    X38                  R208 1
    X38                  R230 1
    X38                  R252 1
    X38                  R274 1
    X38                  R296 1
    X38                  R318 1
    X38                  R340 1
    X38                  R362 1
    X38                  R384 1
    X38                  R406 1
    X38                  R428 1
    X38                  R450 1
    X38                  R472 1
    X38                  R494 -1
    X38                  R516 -1
    X38                  R538 -1
    X38                  R560 -1
    X38                  R582 -1
    X38                  R604 -1
    X38                  R626 -1
    X38                  R648 -1
    X38                  R670 -1
    X38                  R692 -1
    X38                  R714 -1
    X38                  R736 -1
    X38                  R758 -1
    X38                  R780 -1
    X38                  R802 -1
    X38                  R824 -1
    X38                  R846 -1
    X38                  R868 -1
    X39                  OBJ 1
    X39                  R39 1
    X39                  R77 1
    X39                  R99 1
    X39                  R121 1
    X39                  R143 1
    X39                  R165 1
    X39                  R187 1
    X39                  R209 1
    X39                  R231 1
    X39                  R253 1
    X39                  R275 1
    X39                  R297 1
    X39                  R319 1
    X39                  R341 1
    X39                  R363 1
    X39                  R385 1
    X39                  R407 1
    X39                  R429 1
    X39                  R451 1
    X39                  R473 1
    X39                  R495 -1
    X39                  R517 -1
    X39                  R539 -1
    X39                  R561 -1
    X39                  R583 -1
    X39                  R605 -1
    X39                  R627 -1
    X39                  R649 -1
    X39                  R671 -1
    X39                  R693 -1
    X39                  R715 -1
    X39                  R737 -1
    X39                  R759 -1
    X39                  R781 -1
    X39                  R803 -1
    X39                  R825 -1
    X39                  R847 -1
    X39                  R869 -1
    X40                  OBJ 0
    X40                  R78 -10000
    X40                  R474 10000
    X41                  OBJ 0
    X41                  R79 -10000
    X41                  R475 10000
    X42                  OBJ 0
    X42                  R80 -10000
    X42                  R476 10000
    X43                  OBJ 0
    X43                  R81 -10000
    X43                  R477 10000
    X44                  OBJ 0
    X44                  R82 -10000
    X44                  R478 10000
    X45                  OBJ 0
    X45                  R83 -10000
    X45                  R479 10000
    X46                  OBJ 0
    X46                  R84 -10000
    X46                  R480 10000
    X47                  OBJ 0
    X47                  R85 -10000
    X47                  R481 10000
    X48                  OBJ 0
    X48                  R86 -10000
    X48                  R482 10000
    X49                  OBJ 0
    X49                  R87 -10000
    X49                  R483 10000
    X50                  OBJ 0
    X50                  R88 -10000
    X50                  R484 10000
    X51                  OBJ 0
    X51                  R89 -10000
    X51                  R485 10000
    X52                  OBJ 0
    X52                  R90 -10000
    X52                  R486 10000
    X53                  OBJ 0
    X53                  R91 -10000
    X53                  R487 10000
    X54                  OBJ 0
    X54                  R92 -10000
    X54                  R488 10000
    X55                  OBJ 0
    X55                  R93 -10000
    X55                  R489 10000
    X56                  OBJ 0
    X56                  R94 -10000
    X56                  R490 10000
    X57                  OBJ 0
    X57                  R95 -10000
    X57                  R491 10000
    X58                  OBJ 0
    X58                  R96 -10000
    X58                  R492 10000
    X59                  OBJ 0
    X59                  R97 -10000
    X59                  R493 10000
    X60                  OBJ 0
    X60                  R98 -10000
    X60                  R494 10000
    X61                  OBJ 0
    X61                  R99 -10000
    X61                  R495 10000
    X62                  OBJ 0
    X62                  R100 -10000
    X62                  R496 10000
    X63                  OBJ 0
    X63                  R101 -10000
    X63                  R497 10000
    X64                  OBJ 0
    X64                  R102 -10000
    X64                  R498 10000
    X65                  OBJ 0
    X65                  R103 -10000
    X65                  R499 10000
    X66                  OBJ 0
    X66                  R104 -10000
    X66                  R500 10000
    X67                  OBJ 0
    X67                  R105 -10000
    X67                  R501 10000
    X68                  OBJ 0
    X68                  R106 -10000
    X68                  R502 10000
    X69                  OBJ 0
    X69                  R107 -10000
    X69                  R503 10000
    X70                  OBJ 0
    X70                  R108 -10000
    X70                  R504 10000
    X71                  OBJ 0
    X71                  R109 -10000
    X71                  R505 10000
    X72                  OBJ 0
    X72                  R110 -10000
    X72                  R506 10000
    X73                  OBJ 0
    X73                  R111 -10000
    X73                  R507 10000
    X74                  OBJ 0
    X74                  R112 -10000
    X74                  R508 10000
    X75                  OBJ 0
    X75                  R113 -10000
    X75                  R509 10000
    X76                  OBJ 0
    X76                  R114 -10000
    X76                  R510 10000
    X77                  OBJ 0
    X77                  R115 -10000
    X77                  R511 10000
    X78                  OBJ 0
    X78                  R116 -10000
    X78                  R512 10000
    X79                  OBJ 0
    X79                  R117 -10000
    X79                  R513 10000
    X80                  OBJ 0
    X80                  R118 -10000
    X80                  R514 10000
    X81                  OBJ 0
    X81                  R119 -10000
    X81                  R515 10000
    X82                  OBJ 0
    X82                  R120 -10000
    X82                  R516 10000
    X83                  OBJ 0
    X83                  R121 -10000
    X83                  R517 10000
    X84                  OBJ 0
    X84                  R122 -10000
    X84                  R518 10000
    X85                  OBJ 0
    X85                  R123 -10000
    X85                  R519 10000
    X86                  OBJ 0
    X86                  R124 -10000
    X86                  R520 10000
    X87                  OBJ 0
    X87                  R125 -10000
    X87                  R521 10000
    X88                  OBJ 0
    X88                  R126 -10000
    X88                  R522 10000
    X89                  OBJ 0
    X89                  R127 -10000
    X89                  R523 10000
    X90                  OBJ 0
    X90                  R128 -10000
    X90                  R524 10000
    X91                  OBJ 0
    X91                  R129 -10000
    X91                  R525 10000
    X92                  OBJ 0
    X92                  R130 -10000
    X92                  R526 10000
    X93                  OBJ 0
    X93                  R131 -10000
    X93                  R527 10000
    X94                  OBJ 0
    X94                  R132 -10000
    X94                  R528 10000
    X95                  OBJ 0
    X95                  R133 -10000
    X95                  R529 10000
    X96                  OBJ 0
    X96                  R134 -10000
    X96                  R530 10000
    X97                  OBJ 0
    X97                  R135 -10000
    X97                  R531 10000
    X98                  OBJ 0
    X98                  R136 -10000
    X98                  R532 10000
    X99                  OBJ 0
    X99                  R137 -10000
    X99                  R533 10000
    X100                 OBJ 0
    X100                 R138 -10000
    X100                 R534 10000
    X101                 OBJ 0
    X101                 R139 -10000
    X101                 R535 10000
    X102                 OBJ 0
    X102                 R140 -10000
    X102                 R536 10000
    X103                 OBJ 0
    X103                 R141 -10000
    X103                 R537 10000
    X104                 OBJ 0
    X104                 R142 -10000
    X104                 R538 10000
    X105                 OBJ 0
    X105                 R143 -10000
    X105                 R539 10000
    X106                 OBJ 0
    X106                 R144 -10000
    X106                 R540 10000
    X107                 OBJ 0
    X107                 R145 -10000
    X107                 R541 10000
    X108                 OBJ 0
    X108                 R146 -10000
    X108                 R542 10000
    X109                 OBJ 0
    X109                 R147 -10000
    X109                 R543 10000
    X110                 OBJ 0
    X110                 R148 -10000
    X110                 R544 10000
    X111                 OBJ 0
    X111                 R149 -10000
    X111                 R545 10000
    X112                 OBJ 0
    X112                 R150 -10000
    X112                 R546 10000
    X113                 OBJ 0
    X113                 R151 -10000
    X113                 R547 10000
    X114                 OBJ 0
    X114                 R152 -10000
    X114                 R548 10000
    X115                 OBJ 0
    X115                 R153 -10000
    X115                 R549 10000
    X116                 OBJ 0
    X116                 R154 -10000
    X116                 R550 10000
    X117                 OBJ 0
    X117                 R155 -10000
    X117                 R551 10000
    X118                 OBJ 0
    X118                 R156 -10000
    X118                 R552 10000
    X119                 OBJ 0
    X119                 R157 -10000
    X119                 R553 10000
    X120                 OBJ 0
    X120                 R158 -10000
    X120                 R554 10000
    X121                 OBJ 0
    X121                 R159 -10000
    X121                 R555 10000
    X122                 OBJ 0
    X122                 R160 -10000
    X122                 R556 10000
    X123                 OBJ 0
    X123                 R161 -10000
    X123                 R557 10000
    X124                 OBJ 0
    X124                 R162 -10000
    X124                 R558 10000
    X125                 OBJ 0
    X125                 R163 -10000
    X125                 R559 10000
    X126                 OBJ 0
    X126                 R164 -10000
    X126                 R560 10000
    X127                 OBJ 0
    X127                 R165 -10000
    X127                 R561 10000
    X128                 OBJ 0
    X128                 R166 -10000
    X128                 R562 10000
    X129                 OBJ 0
    X129                 R167 -10000
    X129                 R563 10000
    X130                 OBJ 0
    X130                 R168 -10000
    X130                 R564 10000
    X131                 OBJ 0
    X131                 R169 -10000
    X131                 R565 10000
    X132                 OBJ 0
    X132                 R170 -10000
    X132                 R566 10000
    X133                 OBJ 0
    X133                 R171 -10000
    X133                 R567 10000
    X134                 OBJ 0
    X134                 R172 -10000
    X134                 R568 10000
    X135                 OBJ 0
    X135                 R173 -10000
    X135                 R569 10000
    X136                 OBJ 0
    X136                 R174 -10000
    X136                 R570 10000
    X137                 OBJ 0
    X137                 R175 -10000
    X137                 R571 10000
    X138                 OBJ 0
    X138                 R176 -10000
    X138                 R572 10000
    X139                 OBJ 0
    X139                 R177 -10000
    X139                 R573 10000
    X140                 OBJ 0
    X140                 R178 -10000
    X140                 R574 10000
    X141                 OBJ 0
    X141                 R179 -10000
    X141                 R575 10000
    X142                 OBJ 0
    X142                 R180 -10000
    X142                 R576 10000
    X143                 OBJ 0
    X143                 R181 -10000
    X143                 R577 10000
    X144                 OBJ 0
    X144                 R182 -10000
    X144                 R578 10000
    X145                 OBJ 0
    X145                 R183 -10000
    X145                 R579 10000
    X146                 OBJ 0
    X146                 R184 -10000
    X146                 R580 10000
    X147                 OBJ 0
    X147                 R185 -10000
    X147                 R581 10000
    X148                 OBJ 0
    X148                 R186 -10000
    X148                 R582 10000
    X149                 OBJ 0
    X149                 R187 -10000
    X149                 R583 10000
    X150                 OBJ 0
    X150                 R188 -10000
    X150                 R584 10000
    X151                 OBJ 0
    X151                 R189 -10000
    X151                 R585 10000
    X152                 OBJ 0
    X152                 R190 -10000
    X152                 R586 10000
    X153                 OBJ 0
    X153                 R191 -10000
    X153                 R587 10000
    X154                 OBJ 0
    X154                 R192 -10000
    X154                 R588 10000
    X155                 OBJ 0
    X155                 R193 -10000
    X155                 R589 10000
    X156                 OBJ 0
    X156                 R194 -10000
    X156                 R590 10000
    X157                 OBJ 0
    X157                 R195 -10000
    X157                 R591 10000
    X158                 OBJ 0
    X158                 R196 -10000
    X158                 R592 10000
    X159                 OBJ 0
    X159                 R197 -10000
    X159                 R593 10000
    X160                 OBJ 0
    X160                 R198 -10000
    X160                 R594 10000
    X161                 OBJ 0
    X161                 R199 -10000
    X161                 R595 10000
    X162                 OBJ 0
    X162                 R200 -10000
    X162                 R596 10000
    X163                 OBJ 0
    X163                 R201 -10000
    X163                 R597 10000
    X164                 OBJ 0
    X164                 R202 -10000
    X164                 R598 10000
    X165                 OBJ 0
    X165                 R203 -10000
    X165                 R599 10000
    X166                 OBJ 0
    X166                 R204 -10000
    X166                 R600 10000
    X167                 OBJ 0
    X167                 R205 -10000
    X167                 R601 10000
    X168                 OBJ 0
    X168                 R206 -10000
    X168                 R602 10000
    X169                 OBJ 0
    X169                 R207 -10000
    X169                 R603 10000
    X170                 OBJ 0
    X170                 R208 -10000
    X170                 R604 10000
    X171                 OBJ 0
    X171                 R209 -10000
    X171                 R605 10000
    X172                 OBJ 0
    X172                 R210 -10000
    X172                 R606 10000
    X173                 OBJ 0
    X173                 R211 -10000
    X173                 R607 10000
    X174                 OBJ 0
    X174                 R212 -10000
    X174                 R608 10000
    X175                 OBJ 0
    X175                 R213 -10000
    X175                 R609 10000
    X176                 OBJ 0
    X176                 R214 -10000
    X176                 R610 10000
    X177                 OBJ 0
    X177                 R215 -10000
    X177                 R611 10000
    X178                 OBJ 0
    X178                 R216 -10000
    X178                 R612 10000
    X179                 OBJ 0
    X179                 R217 -10000
    X179                 R613 10000
    X180                 OBJ 0
    X180                 R218 -10000
    X180                 R614 10000
    X181                 OBJ 0
    X181                 R219 -10000
    X181                 R615 10000
    X182                 OBJ 0
    X182                 R220 -10000
    X182                 R616 10000
    X183                 OBJ 0
    X183                 R221 -10000
    X183                 R617 10000
    X184                 OBJ 0
    X184                 R222 -10000
    X184                 R618 10000
    X185                 OBJ 0
    X185                 R223 -10000
    X185                 R619 10000
    X186                 OBJ 0
    X186                 R224 -10000
    X186                 R620 10000
    X187                 OBJ 0
    X187                 R225 -10000
    X187                 R621 10000
    X188                 OBJ 0
    X188                 R226 -10000
    X188                 R622 10000
    X189                 OBJ 0
    X189                 R227 -10000
    X189                 R623 10000
    X190                 OBJ 0
    X190                 R228 -10000
    X190                 R624 10000
    X191                 OBJ 0
    X191                 R229 -10000
    X191                 R625 10000
    X192                 OBJ 0
    X192                 R230 -10000
    X192                 R626 10000
    X193                 OBJ 0
    X193                 R231 -10000
    X193                 R627 10000
    X194                 OBJ 0
    X194                 R232 -10000
    X194                 R628 10000
    X195                 OBJ 0
    X195                 R233 -10000
    X195                 R629 10000
    X196                 OBJ 0
    X196                 R234 -10000
    X196                 R630 10000
    X197                 OBJ 0
    X197                 R235 -10000
    X197                 R631 10000
    X198                 OBJ 0
    X198                 R236 -10000
    X198                 R632 10000
    X199                 OBJ 0
    X199                 R237 -10000
    X199                 R633 10000
    X200                 OBJ 0
    X200                 R238 -10000
    X200                 R634 10000
    X201                 OBJ 0
    X201                 R239 -10000
    X201                 R635 10000
    X202                 OBJ 0
    X202                 R240 -10000
    X202                 R636 10000
    X203                 OBJ 0
    X203                 R241 -10000
    X203                 R637 10000
    X204                 OBJ 0
    X204                 R242 -10000
    X204                 R638 10000
    X205                 OBJ 0
    X205                 R243 -10000
    X205                 R639 10000
    X206                 OBJ 0
    X206                 R244 -10000
    X206                 R640 10000
    X207                 OBJ 0
    X207                 R245 -10000
    X207                 R641 10000
    X208                 OBJ 0
    X208                 R246 -10000
    X208                 R642 10000
    X209                 OBJ 0
    X209                 R247 -10000
    X209                 R643 10000
    X210                 OBJ 0
    X210                 R248 -10000
    X210                 R644 10000
    X211                 OBJ 0
    X211                 R249 -10000
    X211                 R645 10000
    X212                 OBJ 0
    X212                 R250 -10000
    X212                 R646 10000
    X213                 OBJ 0
    X213                 R251 -10000
    X213                 R647 10000
    X214                 OBJ 0
    X214                 R252 -10000
    X214                 R648 10000
    X215                 OBJ 0
    X215                 R253 -10000
    X215                 R649 10000
    X216                 OBJ 0
    X216                 R254 -10000
    X216                 R650 10000
    X217                 OBJ 0
    X217                 R255 -10000
    X217                 R651 10000
    X218                 OBJ 0
    X218                 R256 -10000
    X218                 R652 10000
    X219                 OBJ 0
    X219                 R257 -10000
    X219                 R653 10000
    X220                 OBJ 0
    X220                 R258 -10000
    X220                 R654 10000
    X221                 OBJ 0
    X221                 R259 -10000
    X221                 R655 10000
    X222                 OBJ 0
    X222                 R260 -10000
    X222                 R656 10000
    X223                 OBJ 0
    X223                 R261 -10000
    X223                 R657 10000
    X224                 OBJ 0
    X224                 R262 -10000
    X224                 R658 10000
    X225                 OBJ 0
    X225                 R263 -10000
    X225                 R659 10000
    X226                 OBJ 0
    X226                 R264 -10000
    X226                 R660 10000
    X227                 OBJ 0
    X227                 R265 -10000
    X227                 R661 10000
    X228                 OBJ 0
    X228                 R266 -10000
    X228                 R662 10000
    X229                 OBJ 0
    X229                 R267 -10000
    X229                 R663 10000
    X230                 OBJ 0
    X230                 R268 -10000
    X230                 R664 10000
    X231                 OBJ 0
    X231                 R269 -10000
    X231                 R665 10000
    X232                 OBJ 0
    X232                 R270 -10000
    X232                 R666 10000
    X233                 OBJ 0
    X233                 R271 -10000
    X233                 R667 10000
    X234                 OBJ 0
    X234                 R272 -10000
    X234                 R668 10000
    X235                 OBJ 0
    X235                 R273 -10000
    X235                 R669 10000
    X236                 OBJ 0
    X236                 R274 -10000
    X236                 R670 10000
    X237                 OBJ 0
    X237                 R275 -10000
    X237                 R671 10000
    X238                 OBJ 0
    X238                 R276 -10000
    X238                 R672 10000
    X239                 OBJ 0
    X239                 R277 -10000
    X239                 R673 10000
    X240                 OBJ 0
    X240                 R278 -10000
    X240                 R674 10000
    X241                 OBJ 0
    X241                 R279 -10000
    X241                 R675 10000
    X242                 OBJ 0
    X242                 R280 -10000
    X242                 R676 10000
    X243                 OBJ 0
    X243                 R281 -10000
    X243                 R677 10000
    X244                 OBJ 0
    X244                 R282 -10000
    X244                 R678 10000
    X245                 OBJ 0
    X245                 R283 -10000
    X245                 R679 10000
    X246                 OBJ 0
    X246                 R284 -10000
    X246                 R680 10000
    X247                 OBJ 0
    X247                 R285 -10000
    X247                 R681 10000
    X248                 OBJ 0
    X248                 R286 -10000
    X248                 R682 10000
    X249                 OBJ 0
    X249                 R287 -10000
    X249                 R683 10000
    X250                 OBJ 0
    X250                 R288 -10000
    X250                 R684 10000
    X251                 OBJ 0
    X251                 R289 -10000
    X251                 R685 10000
    X252                 OBJ 0
    X252                 R290 -10000
    X252                 R686 10000
    X253                 OBJ 0
    X253                 R291 -10000
    X253                 R687 10000
    X254                 OBJ 0
    X254                 R292 -10000
    X254                 R688 10000
    X255                 OBJ 0
    X255                 R293 -10000
    X255                 R689 10000
    X256                 OBJ 0
    X256                 R294 -10000
    X256                 R690 10000
    X257                 OBJ 0
    X257                 R295 -10000
    X257                 R691 10000
    X258                 OBJ 0
    X258                 R296 -10000
    X258                 R692 10000
    X259                 OBJ 0
    X259                 R297 -10000
    X259                 R693 10000
    X260                 OBJ 0
    X260                 R298 -10000
    X260                 R694 10000
    X261                 OBJ 0
    X261                 R299 -10000
    X261                 R695 10000
    X262                 OBJ 0
    X262                 R300 -10000
    X262                 R696 10000
    X263                 OBJ 0
    X263                 R301 -10000
    X263                 R697 10000
    X264                 OBJ 0
    X264                 R302 -10000
    X264                 R698 10000
    X265                 OBJ 0
    X265                 R303 -10000
    X265                 R699 10000
    X266                 OBJ 0
    X266                 R304 -10000
    X266                 R700 10000
    X267                 OBJ 0
    X267                 R305 -10000
    X267                 R701 10000
    X268                 OBJ 0
    X268                 R306 -10000
    X268                 R702 10000
    X269                 OBJ 0
    X269                 R307 -10000
    X269                 R703 10000
    X270                 OBJ 0
    X270                 R308 -10000
    X270                 R704 10000
    X271                 OBJ 0
    X271                 R309 -10000
    X271                 R705 10000
    X272                 OBJ 0
    X272                 R310 -10000
    X272                 R706 10000
    X273                 OBJ 0
    X273                 R311 -10000
    X273                 R707 10000
    X274                 OBJ 0
    X274                 R312 -10000
    X274                 R708 10000
    X275                 OBJ 0
    X275                 R313 -10000
    X275                 R709 10000
    X276                 OBJ 0
    X276                 R314 -10000
    X276                 R710 10000
    X277                 OBJ 0
    X277                 R315 -10000
    X277                 R711 10000
    X278                 OBJ 0
    X278                 R316 -10000
    X278                 R712 10000
    X279                 OBJ 0
    X279                 R317 -10000
    X279                 R713 10000
    X280                 OBJ 0
    X280                 R318 -10000
    X280                 R714 10000
    X281                 OBJ 0
    X281                 R319 -10000
    X281                 R715 10000
    X282                 OBJ 0
    X282                 R320 -10000
    X282                 R716 10000
    X283                 OBJ 0
    X283                 R321 -10000
    X283                 R717 10000
    X284                 OBJ 0
    X284                 R322 -10000
    X284                 R718 10000
    X285                 OBJ 0
    X285                 R323 -10000
    X285                 R719 10000
    X286                 OBJ 0
    X286                 R324 -10000
    X286                 R720 10000
    X287                 OBJ 0
    X287                 R325 -10000
    X287                 R721 10000
    X288                 OBJ 0
    X288                 R326 -10000
    X288                 R722 10000
    X289                 OBJ 0
    X289                 R327 -10000
    X289                 R723 10000
    X290                 OBJ 0
    X290                 R328 -10000
    X290                 R724 10000
    X291                 OBJ 0
    X291                 R329 -10000
    X291                 R725 10000
    X292                 OBJ 0
    X292                 R330 -10000
    X292                 R726 10000
    X293                 OBJ 0
    X293                 R331 -10000
    X293                 R727 10000
    X294                 OBJ 0
    X294                 R332 -10000
    X294                 R728 10000
    X295                 OBJ 0
    X295                 R333 -10000
    X295                 R729 10000
    X296                 OBJ 0
    X296                 R334 -10000
    X296                 R730 10000
    X297                 OBJ 0
    X297                 R335 -10000
    X297                 R731 10000
    X298                 OBJ 0
    X298                 R336 -10000
    X298                 R732 10000
    X299                 OBJ 0
    X299                 R337 -10000
    X299                 R733 10000
    X300                 OBJ 0
    X300                 R338 -10000
    X300                 R734 10000
    X301                 OBJ 0
    X301                 R339 -10000
    X301                 R735 10000
    X302                 OBJ 0
    X302                 R340 -10000
    X302                 R736 10000
    X303                 OBJ 0
    X303                 R341 -10000
    X303                 R737 10000
    X304                 OBJ 0
    X304                 R342 -10000
    X304                 R738 10000
    X305                 OBJ 0
    X305                 R343 -10000
    X305                 R739 10000
    X306                 OBJ 0
    X306                 R344 -10000
    X306                 R740 10000
    X307                 OBJ 0
    X307                 R345 -10000
    X307                 R741 10000
    X308                 OBJ 0
    X308                 R346 -10000
    X308                 R742 10000
    X309                 OBJ 0
    X309                 R347 -10000
    X309                 R743 10000
    X310                 OBJ 0
    X310                 R348 -10000
    X310                 R744 10000
    X311                 OBJ 0
    X311                 R349 -10000
    X311                 R745 10000
    X312                 OBJ 0
    X312                 R350 -10000
    X312                 R746 10000
    X313                 OBJ 0
    X313                 R351 -10000
    X313                 R747 10000
    X314                 OBJ 0
    X314                 R352 -10000
    X314                 R748 10000
    X315                 OBJ 0
    X315                 R353 -10000
    X315                 R749 10000
    X316                 OBJ 0
    X316                 R354 -10000
    X316                 R750 10000
    X317                 OBJ 0
    X317                 R355 -10000
    X317                 R751 10000
    X318                 OBJ 0
    X318                 R356 -10000
    X318                 R752 10000
    X319                 OBJ 0
    X319                 R357 -10000
    X319                 R753 10000
    X320                 OBJ 0
    X320                 R358 -10000
    X320                 R754 10000
    X321                 OBJ 0
    X321                 R359 -10000
    X321                 R755 10000
    X322                 OBJ 0
    X322                 R360 -10000
    X322                 R756 10000
    X323                 OBJ 0
    X323                 R361 -10000
    X323                 R757 10000
    X324                 OBJ 0
    X324                 R362 -10000
    X324                 R758 10000
    X325                 OBJ 0
    X325                 R363 -10000
    X325                 R759 10000
    X326                 OBJ 0
    X326                 R364 -10000
    X326                 R760 10000
    X327                 OBJ 0
    X327                 R365 -10000
    X327                 R761 10000
    X328                 OBJ 0
    X328                 R366 -10000
    X328                 R762 10000
    X329                 OBJ 0
    X329                 R367 -10000
    X329                 R763 10000
    X330                 OBJ 0
    X330                 R368 -10000
    X330                 R764 10000
    X331                 OBJ 0
    X331                 R369 -10000
    X331                 R765 10000
    X332                 OBJ 0
    X332                 R370 -10000
    X332                 R766 10000
    X333                 OBJ 0
    X333                 R371 -10000
    X333                 R767 10000
    X334                 OBJ 0
    X334                 R372 -10000
    X334                 R768 10000
    X335                 OBJ 0
    X335                 R373 -10000
    X335                 R769 10000
    X336                 OBJ 0
    X336                 R374 -10000
    X336                 R770 10000
    X337                 OBJ 0
    X337                 R375 -10000
    X337                 R771 10000
    X338                 OBJ 0
    X338                 R376 -10000
    X338                 R772 10000
    X339                 OBJ 0
    X339                 R377 -10000
    X339                 R773 10000
    X340                 OBJ 0
    X340                 R378 -10000
    X340                 R774 10000
    X341                 OBJ 0
    X341                 R379 -10000
    X341                 R775 10000
    X342                 OBJ 0
    X342                 R380 -10000
    X342                 R776 10000
    X343                 OBJ 0
    X343                 R381 -10000
    X343                 R777 10000
    X344                 OBJ 0
    X344                 R382 -10000
    X344                 R778 10000
    X345                 OBJ 0
    X345                 R383 -10000
    X345                 R779 10000
    X346                 OBJ 0
    X346                 R384 -10000
    X346                 R780 10000
    X347                 OBJ 0
    X347                 R385 -10000
    X347                 R781 10000
    X348                 OBJ 0
    X348                 R386 -10000
    X348                 R782 10000
    X349                 OBJ 0
    X349                 R387 -10000
    X349                 R783 10000
    X350                 OBJ 0
    X350                 R388 -10000
    X350                 R784 10000
    X351                 OBJ 0
    X351                 R389 -10000
    X351                 R785 10000
    X352                 OBJ 0
    X352                 R390 -10000
    X352                 R786 10000
    X353                 OBJ 0
    X353                 R391 -10000
    X353                 R787 10000
    X354                 OBJ 0
    X354                 R392 -10000
    X354                 R788 10000
    X355                 OBJ 0
    X355                 R393 -10000
    X355                 R789 10000
    X356                 OBJ 0
    X356                 R394 -10000
    X356                 R790 10000
    X357                 OBJ 0
    X357                 R395 -10000
    X357                 R791 10000
    X358                 OBJ 0
    X358                 R396 -10000
    X358                 R792 10000
    X359                 OBJ 0
    X359                 R397 -10000
    X359                 R793 10000
    X360                 OBJ 0
    X360                 R398 -10000
    X360                 R794 10000
    X361                 OBJ 0
    X361                 R399 -10000
    X361                 R795 10000
    X362                 OBJ 0
    X362                 R400 -10000
    X362                 R796 10000
    X363                 OBJ 0
    X363                 R401 -10000
    X363                 R797 10000
    X364                 OBJ 0
    X364                 R402 -10000
    X364                 R798 10000
    X365                 OBJ 0
    X365                 R403 -10000
    X365                 R799 10000
    X366                 OBJ 0
    X366                 R404 -10000
    X366                 R800 10000
    X367                 OBJ 0
    X367                 R405 -10000
    X367                 R801 10000
    X368                 OBJ 0
    X368                 R406 -10000
    X368                 R802 10000
    X369                 OBJ 0
    X369                 R407 -10000
    X369                 R803 10000
    X370                 OBJ 0
    X370                 R408 -10000
    X370                 R804 10000
    X371                 OBJ 0
    X371                 R409 -10000
    X371                 R805 10000
    X372                 OBJ 0
    X372                 R410 -10000
    X372                 R806 10000
    X373                 OBJ 0
    X373                 R411 -10000
    X373                 R807 10000
    X374                 OBJ 0
    X374                 R412 -10000
    X374                 R808 10000
    X375                 OBJ 0
    X375                 R413 -10000
    X375                 R809 10000
    X376                 OBJ 0
    X376                 R414 -10000
    X376                 R810 10000
    X377                 OBJ 0
    X377                 R415 -10000
    X377                 R811 10000
    X378                 OBJ 0
    X378                 R416 -10000
    X378                 R812 10000
    X379                 OBJ 0
    X379                 R417 -10000
    X379                 R813 10000
    X380                 OBJ 0
    X380                 R418 -10000
    X380                 R814 10000
    X381                 OBJ 0
    X381                 R419 -10000
    X381                 R815 10000
    X382                 OBJ 0
    X382                 R420 -10000
    X382                 R816 10000
    X383                 OBJ 0
    X383                 R421 -10000
    X383                 R817 10000
    X384                 OBJ 0
    X384                 R422 -10000
    X384                 R818 10000
    X385                 OBJ 0
    X385                 R423 -10000
    X385                 R819 10000
    X386                 OBJ 0
    X386                 R424 -10000
    X386                 R820 10000
    X387                 OBJ 0
    X387                 R425 -10000
    X387                 R821 10000
    X388                 OBJ 0
    X388                 R426 -10000
    X388                 R822 10000
    X389                 OBJ 0
    X389                 R427 -10000
    X389                 R823 10000
    X390                 OBJ 0
    X390                 R428 -10000
    X390                 R824 10000
    X391                 OBJ 0
    X391                 R429 -10000
    X391                 R825 10000
    X392                 OBJ 0
    X392                 R430 -10000
    X392                 R826 10000
    X393                 OBJ 0
    X393                 R431 -10000
    X393                 R827 10000
    X394                 OBJ 0
    X394                 R432 -10000
    X394                 R828 10000
    X395                 OBJ 0
    X395                 R433 -10000
    X395                 R829 10000
    X396                 OBJ 0
    X396                 R434 -10000
    X396                 R830 10000
    X397                 OBJ 0
    X397                 R435 -10000
    X397                 R831 10000
    X398                 OBJ 0
    X398                 R436 -10000
    X398                 R832 10000
    X399                 OBJ 0
    X399                 R437 -10000
    X399                 R833 10000
    X400                 OBJ 0
    X400                 R438 -10000
    X400                 R834 10000
    X401                 OBJ 0
    X401                 R439 -10000
    X401                 R835 10000
    X402                 OBJ 0
    X402                 R440 -10000
    X402                 R836 10000
    X403                 OBJ 0
    X403                 R441 -10000
    X403                 R837 10000
    X404                 OBJ 0
    X404                 R442 -10000
    X404                 R838 10000
    X405                 OBJ 0
    X405                 R443 -10000
    X405                 R839 10000
    X406                 OBJ 0
    X406                 R444 -10000
    X406                 R840 10000
    X407                 OBJ 0
    X407                 R445 -10000
    X407                 R841 10000
    X408                 OBJ 0
    X408                 R446 -10000
    X408                 R842 10000
    X409                 OBJ 0
    X409                 R447 -10000
    X409                 R843 10000
    X410                 OBJ 0
    X410                 R448 -10000
    X410                 R844 10000
    X411                 OBJ 0
    X411                 R449 -10000
    X411                 R845 10000
    X412                 OBJ 0
    X412                 R450 -10000
    X412                 R846 10000
    X413                 OBJ 0
    X413                 R451 -10000
    X413                 R847 10000
    X414                 OBJ 0
    X414                 R452 -10000
    X414                 R848 10000
    X415                 OBJ 0
    X415                 R453 -10000
    X415                 R849 10000
    X416                 OBJ 0
    X416                 R454 -10000
    X416                 R850 10000
    X417                 OBJ 0
    X417                 R455 -10000
    X417                 R851 10000
    X418                 OBJ 0
    X418                 R456 -10000
    X418                 R852 10000
    X419                 OBJ 0
    X419                 R457 -10000
    X419                 R853 10000
    X420                 OBJ 0
    X420                 R458 -10000
    X420                 R854 10000
    X421                 OBJ 0
    X421                 R459 -10000
    X421                 R855 10000
    X422                 OBJ 0
    X422                 R460 -10000
    X422                 R856 10000
    X423                 OBJ 0
    X423                 R461 -10000
    X423                 R857 10000
    X424                 OBJ 0
    X424                 R462 -10000
    X424                 R858 10000
    X425                 OBJ 0
    X425                 R463 -10000
    X425                 R859 10000
    X426                 OBJ 0
    X426                 R464 -10000
    X426                 R860 10000
    X427                 OBJ 0
    X427                 R465 -10000
    X427                 R861 10000
    X428                 OBJ 0
    X428                 R466 -10000
    X428                 R862 10000
    X429                 OBJ 0
    X429                 R467 -10000
    X429                 R863 10000
    X430                 OBJ 0
    X430                 R468 -10000
    X430                 R864 10000
    X431                 OBJ 0
    X431                 R469 -10000
    X431                 R865 10000
    X432                 OBJ 0
    X432                 R470 -10000
    X432                 R866 10000
    X433                 OBJ 0
    X433                 R471 -10000
    X433                 R867 10000
    X434                 OBJ 0
    X434                 R472 -10000
    X434                 R868 10000
    X435                 OBJ 0
    X435                 R473 -10000
    X435                 R869 10000
RHS
    RHS                  OBJ -0
    RHS                  R0 4.4671401964674438
    RHS                  R1 6.212861338662389
    RHS                  R2 7.958575580342039
    RHS                  R3 9.7042736497011504
    RHS                  R4 11.44311839686935
    RHS                  R5 18.07014264914401
    RHS                  R6 21.632285210455851
    RHS                  R7 23.429543901538949
    RHS                  R8 30.191503842725691
    RHS                  R9 41.000994560430073
    RHS                  R10 43.354118127685602
    RHS                  R11 46.964983926437462
    RHS                  R12 50.151058515918798
    RHS                  R13 52.519488213678969
    RHS                  R14 55.216457674844648
    RHS                  R15 58.003095311575997
    RHS                  R16 60.658786838152878
    RHS                  R17 62.488578094467478
    RHS                  R18 0.53576976356001116
    RHS                  R19 2.3206129814243468
    RHS                  R20 4.1041481174214987
    RHS                  R21 5.8961286087221971
    RHS                  R22 10.65767549678511
    RHS                  R23 12.449151189249701
    RHS                  R24 14.240626881714309
    RHS                  R25 16.03210257417896
    RHS                  R26 18.108808713448489
    RHS                  R27 24.023891394023639
    RHS                  R28 32.374917559452641
    RHS                  R29 35.269401037454443
    RHS                  R30 37.066786493253367
    RHS                  R31 39.522133144453669
    RHS                  R32 42.758990006681181
    RHS                  R33 45.750848180563871
    RHS                  R34 48.869081054279107
    RHS                  R35 51.608375221115182
    RHS                  R36 55.086376722907232
    RHS                  R37 56.905364415697157
    RHS                  R38 61.330612307121577
    RHS                  R39 63.242782354275732
    RHS                  R40 2
    RHS                  R41 2
    RHS                  R42 2
    RHS                  R43 2
    RHS                  R44 2
    RHS                  R45 2
    RHS                  R46 2
    RHS                  R47 2
    RHS                  R48 2
    RHS                  R49 2
    RHS                  R50 2
    RHS                  R51 2
    RHS                  R52 2
    RHS                  R53 2
    RHS                  R54 2
    RHS                  R55 2
    RHS                  R56 2
    RHS                  R57 2
    RHS                  R58 2
    RHS                  R59 2
    RHS                  R60 2
    RHS                  R61 2
    RHS                  R62 2
    RHS                  R63 2
    RHS                  R64 2
    RHS                  R65 2
    RHS                  R66 2
    RHS                  R67 2
    RHS                  R68 2
    RHS                  R69 2
    RHS                  R70 2
    RHS                  R71 2
    RHS                  R72 2
    RHS                  R73 2
    RHS                  R74 2
    RHS                  R75 2
    RHS                  R76 2
    RHS                  R77 2
    RHS                  R78 -9995.8768943743817
    RHS                  R79 -9995.8768943743817
    RHS                  R80 -9995.8768943743817
    RHS                  R81 -9995.8768943743817
    RHS                  R82 -9995.8768943743817
    RHS                  R83 -9995.8768943743817
    RHS                  R84 -9995.8768943743817
    RHS                  R85 -9995.8768943743817
    RHS                  R86 -9995.8768943743817
    RHS                  R87 -9995.8768943743817
    RHS                  R88 -9995.8768943743817
    RHS                  R89 -9995.8768943743817
    RHS                  R90 -9995.8768943743817
    RHS                  R91 -9995.8768943743817
    RHS                  R92 -9995.8768943743817
    RHS                  R93 -9995.8768943743817
    RHS                  R94 -9995.8768943743817
    RHS                  R95 -9995.8768943743817
    RHS                  R96 -9995.8768943743817
    RHS                  R97 -9995.8768943743817
    RHS                  R98 -9995.8768943743817
    RHS                  R99 -9995.8768943743817
    RHS                  R100 -9995.8768943743817
    RHS                  R101 -9995.8768943743817
    RHS                  R102 -9995.8768943743817
    RHS                  R103 -9995.8768943743817
    RHS                  R104 -9995.8768943743817
    RHS                  R105 -9995.8768943743817
    RHS                  R106 -9995.8768943743817
    RHS                  R107 -9995.8768943743817
    RHS                  R108 -9995.8768943743817
    RHS                  R109 -9995.8768943743817
    RHS                  R110 -9995.8768943743817
    RHS                  R111 -9995.8768943743817
    RHS                  R112 -9995.8768943743817
    RHS                  R113 -9995.8768943743817
    RHS                  R114 -9995.8768943743817
    RHS                  R115 -9995.8768943743817
    RHS                  R116 -9995.8768943743817
    RHS                  R117 -9995.8768943743817
    RHS                  R118 -9995.8768943743817
    RHS                  R119 -9995.8768943743817
    RHS                  R120 -9995.8768943743817
    RHS                  R121 -9995.8768943743817
    RHS                  R122 -9995.8768943743817
    RHS                  R123 -9995.8768943743817
    RHS                  R124 -9995.8768943743817
    RHS                  R125 -9995.8768943743817
    RHS                  R126 -9995.8768943743817
    RHS                  R127 -9995.8768943743817
    RHS                  R128 -9995.8768943743817
    RHS                  R129 -9995.8768943743817
    RHS                  R130 -9995.8768943743817
    RHS                  R131 -9995.8768943743817
    RHS                  R132 -9995.8768943743817
    RHS                  R133 -9995.8768943743817
    RHS                  R134 -9995.8768943743817
    RHS                  R135 -9995.8768943743817
    RHS                  R136 -9995.8768943743817
    RHS                  R137 -9995.8768943743817
    RHS                  R138 -9995.8768943743817
    RHS                  R139 -9995.8768943743817
    RHS                  R140 -9995.8768943743817
    RHS                  R141 -9995.8768943743817
    RHS                  R142 -9995.8768943743817
    RHS                  R143 -9995.8768943743817
    RHS                  R144 -9995.8768943743817
    RHS                  R145 -9995.8768943743817
    RHS                  R146 -9995.8768943743817
    RHS                  R147 -9995.8768943743817
    RHS                  R148 -9995.8768943743817
    RHS                  R149 -9995.8768943743817
    RHS                  R150 -9995.8768943743817
    RHS                  R151 -9995.8768943743817
    RHS                  R152 -9995.8768943743817
    RHS                  R153 -9995.8768943743817
    RHS                  R154 -9995.8768943743817
    RHS                  R155 -9995.8768943743817
    RHS                  R156 -9995.8768943743817
    RHS                  R157 -9995.8768943743817
    RHS                  R158 -9995.8768943743817
    RHS                  R159 -9995.8768943743817
    RHS                  R160 -9995.8768943743817
    RHS                  R161 -9995.8768943743817
    RHS                  R162 -9995.8768943743817
    RHS                  R163 -9995.8768943743817
    RHS                  R164 -9995.8768943743817
    RHS                  R165 -9995.8768943743817
    RHS                  R166 -9995.8768943743817
    RHS                  R167 -9995.8768943743817
    RHS                  R168 -9995.8768943743817
    RHS                  R169 -9995.8768943743817
    RHS                  R170 -9995.8768943743817
    RHS                  R171 -9995.8768943743817
    RHS                  R172 -9995.8768943743817
    RHS                  R173 -9995.8768943743817
    RHS                  R174 -9995.8768943743817
    RHS                  R175 -9995.8768943743817
    RHS                  R176 -9995.8768943743817
    RHS                  R177 -9995.8768943743817
    RHS                  R178 -9995.8768943743817
    RHS                  R179 -9995.8768943743817
    RHS                  R180 -9995.8768943743817
    RHS                  R181 -9995.8768943743817
    RHS                  R182 -9995.8768943743817
    RHS                  R183 -9995.8768943743817
    RHS                  R184 -9995.8768943743817
    RHS                  R185 -9995.8768943743817
    RHS                  R186 -9995.8768943743817
    RHS                  R187 -9995.8768943743817
    RHS                  R188 -9995.8768943743817
    RHS                  R189 -9995.8768943743817
    RHS                  R190 -9995.8768943743817
    RHS                  R191 -9995.8768943743817
    RHS                  R192 -9995.8768943743817
    RHS                  R193 -9995.8768943743817
    RHS                  R194 -9995.8768943743817
    RHS                  R195 -9995.8768943743817
    RHS                  R196 -9995.8768943743817
    RHS                  R197 -9995.8768943743817
    RHS                  R198 -9995.8768943743817
    RHS                  R199 -9995.8768943743817
    RHS                  R200 -9995.8768943743817
    RHS                  R201 -9995.8768943743817
    RHS                  R202 -9995.8768943743817
    RHS                  R203 -9995.8768943743817
    RHS                  R204 -9995.8768943743817
    RHS                  R205 -9995.8768943743817
    RHS                  R206 -9995.8768943743817
    RHS                  R207 -9995.8768943743817
    RHS                  R208 -9995.8768943743817
    RHS                  R209 -9995.8768943743817
    RHS                  R210 -9995.8768943743817
    RHS                  R211 -9995.8768943743817
    RHS                  R212 -9995.8768943743817
    RHS                  R213 -9995.8768943743817
    RHS                  R214 -9995.8768943743817
    RHS                  R215 -9995.8768943743817
    RHS                  R216 -9995.8768943743817
    RHS                  R217 -9995.8768943743817
    RHS                  R218 -9995.8768943743817
    RHS                  R219 -9995.8768943743817
    RHS                  R220 -9995.8768943743817
    RHS                  R221 -9995.8768943743817
    RHS                  R222 -9995.8768943743817
    RHS                  R223 -9995.8768943743817
    RHS                  R224 -9995.8768943743817
    RHS                  R225 -9995.8768943743817
    RHS                  R226 -9995.8768943743817
    RHS                  R227 -9995.8768943743817
    RHS                  R228 -9995.8768943743817
    RHS                  R229 -9995.8768943743817
    RHS                  R230 -9995.8768943743817
    RHS                  R231 -9995.8768943743817
    RHS                  R232 -9995.8768943743817
    RHS                  R233 -9995.8768943743817
    RHS                  R234 -9995.8768943743817
    RHS                  R235 -9995.8768943743817
    RHS                  R236 -9995.8768943743817
    RHS                  R237 -9995.8768943743817
    RHS                  R238 -9995.8768943743817
    RHS                  R239 -9995.8768943743817
    RHS                  R240 -9995.8768943743817
    RHS                  R241 -9995.8768943743817
    RHS                  R242 -9995.8768943743817
    RHS                  R243 -9995.8768943743817
    RHS                  R244 -9995.8768943743817
    RHS                  R245 -9995.8768943743817
    RHS                  R246 -9995.8768943743817
    RHS                  R247 -9995.8768943743817
    RHS                  R248 -9995.8768943743817
    RHS                  R249 -9995.8768943743817
    RHS                  R250 -9995.8768943743817
    RHS                  R251 -9995.8768943743817
    RHS                  R252 -9995.8768943743817
    RHS                  R253 -9995.8768943743817
    RHS                  R254 -9995.8768943743817
    RHS                  R255 -9995.8768943743817
    RHS                  R256 -9995.8768943743817
    RHS                  R257 -9995.8768943743817
    RHS                  R258 -9995.8768943743817
    RHS                  R259 -9995.8768943743817
    RHS                  R260 -9995.8768943743817
    RHS                  R261 -9995.8768943743817
    RHS                  R262 -9995.8768943743817
    RHS                  R263 -9995.8768943743817
    RHS                  R264 -9995.8768943743817
    RHS                  R265 -9995.8768943743817
    RHS                  R266 -9995.8768943743817
    RHS                  R267 -9995.8768943743817
    RHS                  R268 -9995.8768943743817
    RHS                  R269 -9995.8768943743817
    RHS                  R270 -9995.8768943743817
    RHS                  R271 -9995.8768943743817
    RHS                  R272 -9995.8768943743817
    RHS                  R273 -9995.8768943743817
    RHS                  R274 -9995.8768943743817
    RHS                  R275 -9995.8768943743817
    RHS                  R276 -9995.8768943743817
    RHS                  R277 -9995.8768943743817
    RHS                  R278 -9995.8768943743817
    RHS                  R279 -9995.8768943743817
    RHS                  R280 -9995.8768943743817
    RHS                  R281 -9995.8768943743817
    RHS                  R282 -9995.8768943743817
    RHS                  R283 -9995.8768943743817
    RHS                  R284 -9995.8768943743817
    RHS                  R285 -9995.8768943743817
    RHS                  R286 -9995.8768943743817
    RHS                  R287 -9995.8768943743817
    RHS                  R288 -9995.8768943743817
    RHS                  R289 -9995.8768943743817
    RHS                  R290 -9995.8768943743817
    RHS                  R291 -9995.8768943743817
    RHS                  R292 -9995.8768943743817
    RHS                  R293 -9995.8768943743817
    RHS                  R294 -9995.8768943743817
    RHS                  R295 -9995.8768943743817
    RHS                  R296 -9995.8768943743817
    RHS                  R297 -9995.8768943743817
    RHS                  R298 -9995.8768943743817
    RHS                  R299 -9995.8768943743817
    RHS                  R300 -9995.8768943743817
    RHS                  R301 -9995.8768943743817
    RHS                  R302 -9995.8768943743817
    RHS                  R303 -9995.8768943743817
    RHS                  R304 -9995.8768943743817
    RHS                  R305 -9995.8768943743817
    RHS                  R306 -9995.8768943743817
    RHS                  R307 -9995.8768943743817
    RHS                  R308 -9995.8768943743817
    RHS                  R309 -9995.8768943743817
    RHS                  R310 -9995.8768943743817
    RHS                  R311 -9995.8768943743817
    RHS                  R312 -9995.8768943743817
    RHS                  R313 -9995.8768943743817
    RHS                  R314 -9995.8768943743817
    RHS                  R315 -9995.8768943743817
    RHS                  R316 -9995.8768943743817
    RHS                  R317 -9995.8768943743817
    RHS                  R318 -9995.8768943743817
    RHS                  R319 -9995.8768943743817
    RHS                  R320 -9995.8768943743817
    RHS                  R321 -9995.8768943743817
    RHS                  R322 -9995.8768943743817
    RHS                  R323 -9995.8768943743817
    RHS                  R324 -9995.8768943743817
    RHS                  R325 -9995.8768943743817
    RHS                  R326 -9995.8768943743817
    RHS                  R327 -9995.8768943743817
    RHS                  R328 -9995.8768943743817
    RHS                  R329 -9995.8768943743817
    RHS                  R330 -9995.8768943743817
    RHS                  R331 -9995.8768943743817
    RHS                  R332 -9995.8768943743817
    RHS                  R333 -9995.8768943743817
    RHS                  R334 -9995.8768943743817
    RHS                  R335 -9995.8768943743817
    RHS                  R336 -9995.8768943743817
    RHS                  R337 -9995.8768943743817
    RHS                  R338 -9995.8768943743817
    RHS                  R339 -9995.8768943743817
    RHS                  R340 -9995.8768943743817
    RHS                  R341 -9995.8768943743817
    RHS                  R342 -9995.8768943743817
    RHS                  R343 -9995.8768943743817
    RHS                  R344 -9995.8768943743817
    RHS                  R345 -9995.8768943743817
    RHS                  R346 -9995.8768943743817
    RHS                  R347 -9995.8768943743817
    RHS                  R348 -9995.8768943743817
    RHS                  R349 -9995.8768943743817
    RHS                  R350 -9995.8768943743817
    RHS                  R351 -9995.8768943743817
    RHS                  R352 -9995.8768943743817
    RHS                  R353 -9995.8768943743817
    RHS                  R354 -9995.8768943743817
    RHS                  R355 -9995.8768943743817
    RHS                  R356 -9995.8768943743817
    RHS                  R357 -9995.8768943743817
    RHS                  R358 -9995.8768943743817
    RHS                  R359 -9995.8768943743817
    RHS                  R360 -9995.8768943743817
    RHS                  R361 -9995.8768943743817
    RHS                  R362 -9995.8768943743817
    RHS                  R363 -9995.8768943743817
    RHS                  R364 -9995.8768943743817
    RHS                  R365 -9995.8768943743817
    RHS                  R366 -9995.8768943743817
    RHS                  R367 -9995.8768943743817
    RHS                  R368 -9995.8768943743817
    RHS                  R369 -9995.8768943743817
    RHS                  R370 -9995.8768943743817
    RHS                  R371 -9995.8768943743817
    RHS                  R372 -9995.8768943743817
    RHS                  R373 -9995.8768943743817
    RHS                  R374 -9995.8768943743817
    RHS                  R375 -9995.8768943743817
    RHS                  R376 -9995.8768943743817
    RHS                  R377 -9995.8768943743817
    RHS                  R378 -9995.8768943743817
    RHS                  R379 -9995.8768943743817
    RHS                  R380 -9995.8768943743817
    RHS                  R381 -9995.8768943743817
    RHS                  R382 -9995.8768943743817
    RHS                  R383 -9995.8768943743817
    RHS                  R384 -9995.8768943743817
    RHS                  R385 -9995.8768943743817
    RHS                  R386 -9995.8768943743817
    RHS                  R387 -9995.8768943743817
    RHS                  R388 -9995.8768943743817
    RHS                  R389 -9995.8768943743817
    RHS                  R390 -9995.8768943743817
    RHS                  R391 -9995.8768943743817
    RHS                  R392 -9995.8768943743817
    RHS                  R393 -9995.8768943743817
    RHS                  R394 -9995.8768943743817
    RHS                  R395 -9995.8768943743817
    RHS                  R396 -9995.8768943743817
    RHS                  R397 -9995.8768943743817
    RHS                  R398 -9995.8768943743817
    RHS                  R399 -9995.8768943743817
    RHS                  R400 -9995.8768943743817
    RHS                  R401 -9995.8768943743817
    RHS                  R402 -9995.8768943743817
    RHS                  R403 -9995.8768943743817
    RHS                  R404 -9995.8768943743817
    RHS                  R405 -9995.8768943743817
    RHS                  R406 -9995.8768943743817
    RHS                  R407 -9995.8768943743817
    RHS                  R408 -9995.8768943743817
    RHS                  R409 -9995.8768943743817
    RHS                  R410 -9995.8768943743817
    RHS                  R411 -9995.8768943743817
    RHS                  R412 -9995.8768943743817
    RHS                  R413 -9995.8768943743817
    RHS                  R414 -9995.8768943743817
    RHS                  R415 -9995.8768943743817
    RHS                  R416 -9995.8768943743817
    RHS                  R417 -9995.8768943743817
    RHS                  R418 -9995.8768943743817
    RHS                  R419 -9995.8768943743817
    RHS                  R420 -9995.8768943743817
    RHS                  R421 -9995.8768943743817
    RHS                  R422 -9995.8768943743817
    RHS                  R423 -9995.8768943743817
    RHS                  R424 -9995.8768943743817
    RHS                  R425 -9995.8768943743817
    RHS                  R426 -9995.8768943743817
    RHS                  R427 -9995.8768943743817
    RHS                  R428 -9995.8768943743817
    RHS                  R429 -9995.8768943743817
    RHS                  R430 -9995.8768943743817
    RHS                  R431 -9995.8768943743817
    RHS                  R432 -9995.8768943743817
    RHS                  R433 -9995.8768943743817
    RHS                  R434 -9995.8768943743817
    RHS                  R435 -9995.8768943743817
    RHS                  R436 -9995.8768943743817
    RHS                  R437 -9995.8768943743817
    RHS                  R438 -9995.8768943743817
    RHS                  R439 -9995.8768943743817
    RHS                  R440 -9995.8768943743817
    RHS                  R441 -9995.8768943743817
    RHS                  R442 -9995.8768943743817
    RHS                  R443 -9995.8768943743817
    RHS                  R444 -9995.8768943743817
    RHS                  R445 -9995.8768943743817
    RHS                  R446 -9995.8768943743817
    RHS                  R447 -9995.8768943743817
    RHS                  R448 -9995.8768943743817
    RHS                  R449 -9995.8768943743817
    RHS                  R450 -9995.8768943743817
    RHS                  R451 -9995.8768943743817
    RHS                  R452 -9995.8768943743817
    RHS                  R453 -9995.8768943743817
    RHS                  R454 -9995.8768943743817
    RHS                  R455 -9995.8768943743817
    RHS                  R456 -9995.8768943743817
    RHS                  R457 -9995.8768943743817
    RHS                  R458 -9995.8768943743817
    RHS                  R459 -9995.8768943743817
    RHS                  R460 -9995.8768943743817
    RHS                  R461 -9995.8768943743817
    RHS                  R462 -9995.8768943743817
    RHS                  R463 -9995.8768943743817
    RHS                  R464 -9995.8768943743817
    RHS                  R465 -9995.8768943743817
    RHS                  R466 -9995.8768943743817
    RHS                  R467 -9995.8768943743817
    RHS                  R468 -9995.8768943743817
    RHS                  R469 -9995.8768943743817
    RHS                  R470 -9995.8768943743817
    RHS                  R471 -9995.8768943743817
    RHS                  R472 -9995.8768943743817
    RHS                  R473 -9995.8768943743817
    RHS                  R474 4.1231056256176606
    RHS                  R475 4.1231056256176606
    RHS                  R476 4.1231056256176606
    RHS                  R477 4.1231056256176606
    RHS                  R478 4.1231056256176606
    RHS                  R479 4.1231056256176606
    RHS                  R480 4.1231056256176606
    RHS                  R481 4.1231056256176606
    RHS                  R482 4.1231056256176606
    RHS                  R483 4.1231056256176606
    RHS                  R484 4.1231056256176606
    RHS                  R485 4.1231056256176606
    RHS                  R486 4.1231056256176606
    RHS                  R487 4.1231056256176606
    RHS                  R488 4.1231056256176606
    RHS                  R489 4.1231056256176606
    RHS                  R490 4.1231056256176606
    RHS                  R491 4.1231056256176606
    RHS                  R492 4.1231056256176606
    RHS                  R493 4.1231056256176606
    RHS                  R494 4.1231056256176606
    RHS                  R495 4.1231056256176606
    RHS                  R496 4.1231056256176606
    RHS                  R497 4.1231056256176606
    RHS                  R498 4.1231056256176606
    RHS                  R499 4.1231056256176606
    RHS                  R500 4.1231056256176606
    RHS                  R501 4.1231056256176606
    RHS                  R502 4.1231056256176606
    RHS                  R503 4.1231056256176606
    RHS                  R504 4.1231056256176606
    RHS                  R505 4.1231056256176606
    RHS                  R506 4.1231056256176606
    RHS                  R507 4.1231056256176606
    RHS                  R508 4.1231056256176606
    RHS                  R509 4.1231056256176606
    RHS                  R510 4.1231056256176606
    RHS                  R511 4.1231056256176606
    RHS                  R512 4.1231056256176606
    RHS                  R513 4.1231056256176606
    RHS                  R514 4.1231056256176606
    RHS                  R515 4.1231056256176606
    RHS                  R516 4.1231056256176606
    RHS                  R517 4.1231056256176606
    RHS                  R518 4.1231056256176606
    RHS                  R519 4.1231056256176606
    RHS                  R520 4.1231056256176606
    RHS                  R521 4.1231056256176606
    RHS                  R522 4.1231056256176606
    RHS                  R523 4.1231056256176606
    RHS                  R524 4.1231056256176606
    RHS                  R525 4.1231056256176606
    RHS                  R526 4.1231056256176606
    RHS                  R527 4.1231056256176606
    RHS                  R528 4.1231056256176606
    RHS                  R529 4.1231056256176606
    RHS                  R530 4.1231056256176606
    RHS                  R531 4.1231056256176606
    RHS                  R532 4.1231056256176606
    RHS                  R533 4.1231056256176606
    RHS                  R534 4.1231056256176606
    RHS                  R535 4.1231056256176606
    RHS                  R536 4.1231056256176606
    RHS                  R537 4.1231056256176606
    RHS                  R538 4.1231056256176606
    RHS                  R539 4.1231056256176606
    RHS                  R540 4.1231056256176606
    RHS                  R541 4.1231056256176606
    RHS                  R542 4.1231056256176606
    RHS                  R543 4.1231056256176606
    RHS                  R544 4.1231056256176606
    RHS                  R545 4.1231056256176606
    RHS                  R546 4.1231056256176606
    RHS                  R547 4.1231056256176606
    RHS                  R548 4.1231056256176606
    RHS                  R549 4.1231056256176606
    RHS                  R550 4.1231056256176606
    RHS                  R551 4.1231056256176606
    RHS                  R552 4.1231056256176606
    RHS                  R553 4.1231056256176606
    RHS                  R554 4.1231056256176606
    RHS                  R555 4.1231056256176606
    RHS                  R556 4.1231056256176606
    RHS                  R557 4.1231056256176606
    RHS                  R558 4.1231056256176606
    RHS                  R559 4.1231056256176606
    RHS                  R560 4.1231056256176606
    RHS                  R561 4.1231056256176606
    RHS                  R562 4.1231056256176606
    RHS                  R563 4.1231056256176606
    RHS                  R564 4.1231056256176606
    RHS                  R565 4.1231056256176606
    RHS                  R566 4.1231056256176606
    RHS                  R567 4.1231056256176606
    RHS                  R568 4.1231056256176606
    RHS                  R569 4.1231056256176606
    RHS                  R570 4.1231056256176606
    RHS                  R571 4.1231056256176606
    RHS                  R572 4.1231056256176606
    RHS                  R573 4.1231056256176606
    RHS                  R574 4.1231056256176606
    RHS                  R575 4.1231056256176606
    RHS                  R576 4.1231056256176606
    RHS                  R577 4.1231056256176606
    RHS                  R578 4.1231056256176606
    RHS                  R579 4.1231056256176606
    RHS                  R580 4.1231056256176606
    RHS                  R581 4.1231056256176606
    RHS                  R582 4.1231056256176606
    RHS                  R583 4.1231056256176606
    RHS                  R584 4.1231056256176606
    RHS                  R585 4.1231056256176606
    RHS                  R586 4.1231056256176606
    RHS                  R587 4.1231056256176606
    RHS                  R588 4.1231056256176606
    RHS                  R589 4.1231056256176606
    RHS                  R590 4.1231056256176606
    RHS                  R591 4.1231056256176606
    RHS                  R592 4.1231056256176606
    RHS                  R593 4.1231056256176606
    RHS                  R594 4.1231056256176606
    RHS                  R595 4.1231056256176606
    RHS                  R596 4.1231056256176606
    RHS                  R597 4.1231056256176606
    RHS                  R598 4.1231056256176606
    RHS                  R599 4.1231056256176606
    RHS                  R600 4.1231056256176606
    RHS                  R601 4.1231056256176606
    RHS                  R602 4.1231056256176606
    RHS                  R603 4.1231056256176606
    RHS                  R604 4.1231056256176606
    RHS                  R605 4.1231056256176606
    RHS                  R606 4.1231056256176606
    RHS                  R607 4.1231056256176606
    RHS                  R608 4.1231056256176606
    RHS                  R609 4.1231056256176606
    RHS                  R610 4.1231056256176606
    RHS                  R611 4.1231056256176606
    RHS                  R612 4.1231056256176606
    RHS                  R613 4.1231056256176606
    RHS                  R614 4.1231056256176606
    RHS                  R615 4.1231056256176606
    RHS                  R616 4.1231056256176606
    RHS                  R617 4.1231056256176606
    RHS                  R618 4.1231056256176606
    RHS                  R619 4.1231056256176606
    RHS                  R620 4.1231056256176606
    RHS                  R621 4.1231056256176606
    RHS                  R622 4.1231056256176606
    RHS                  R623 4.1231056256176606
    RHS                  R624 4.1231056256176606
    RHS                  R625 4.1231056256176606
    RHS                  R626 4.1231056256176606
    RHS                  R627 4.1231056256176606
    RHS                  R628 4.1231056256176606
    RHS                  R629 4.1231056256176606
    RHS                  R630 4.1231056256176606
    RHS                  R631 4.1231056256176606
    RHS                  R632 4.1231056256176606
    RHS                  R633 4.1231056256176606
    RHS                  R634 4.1231056256176606
    RHS                  R635 4.1231056256176606
    RHS                  R636 4.1231056256176606
    RHS                  R637 4.1231056256176606
    RHS                  R638 4.1231056256176606
    RHS                  R639 4.1231056256176606
    RHS                  R640 4.1231056256176606
    RHS                  R641 4.1231056256176606
    RHS                  R642 4.1231056256176606
    RHS                  R643 4.1231056256176606
    RHS                  R644 4.1231056256176606
    RHS                  R645 4.1231056256176606
    RHS                  R646 4.1231056256176606
    RHS                  R647 4.1231056256176606
    RHS                  R648 4.1231056256176606
    RHS                  R649 4.1231056256176606
    RHS                  R650 4.1231056256176606
    RHS                  R651 4.1231056256176606
    RHS                  R652 4.1231056256176606
    RHS                  R653 4.1231056256176606
    RHS                  R654 4.1231056256176606
    RHS                  R655 4.1231056256176606
    RHS                  R656 4.1231056256176606
    RHS                  R657 4.1231056256176606
    RHS                  R658 4.1231056256176606
    RHS                  R659 4.1231056256176606
    RHS                  R660 4.1231056256176606
    RHS                  R661 4.1231056256176606
    RHS                  R662 4.1231056256176606
    RHS                  R663 4.1231056256176606
    RHS                  R664 4.1231056256176606
    RHS                  R665 4.1231056256176606
    RHS                  R666 4.1231056256176606
    RHS                  R667 4.1231056256176606
    RHS                  R668 4.1231056256176606
    RHS                  R669 4.1231056256176606
    RHS                  R670 4.1231056256176606
    RHS                  R671 4.1231056256176606
    RHS                  R672 4.1231056256176606
    RHS                  R673 4.1231056256176606
    RHS                  R674 4.1231056256176606
    RHS                  R675 4.1231056256176606
    RHS                  R676 4.1231056256176606
    RHS                  R677 4.1231056256176606
    RHS                  R678 4.1231056256176606
    RHS                  R679 4.1231056256176606
    RHS                  R680 4.1231056256176606
    RHS                  R681 4.1231056256176606
    RHS                  R682 4.1231056256176606
    RHS                  R683 4.1231056256176606
    RHS                  R684 4.1231056256176606
    RHS                  R685 4.1231056256176606
    RHS                  R686 4.1231056256176606
    RHS                  R687 4.1231056256176606
    RHS                  R688 4.1231056256176606
    RHS                  R689 4.1231056256176606
    RHS                  R690 4.1231056256176606
    RHS                  R691 4.1231056256176606
    RHS                  R692 4.1231056256176606
    RHS                  R693 4.1231056256176606
    RHS                  R694 4.1231056256176606
    RHS                  R695 4.1231056256176606
    RHS                  R696 4.1231056256176606
    RHS                  R697 4.1231056256176606
    RHS                  R698 4.1231056256176606
    RHS                  R699 4.1231056256176606
    RHS                  R700 4.1231056256176606
    RHS                  R701 4.1231056256176606
    RHS                  R702 4.1231056256176606
    RHS                  R703 4.1231056256176606
    RHS                  R704 4.1231056256176606
    RHS                  R705 4.1231056256176606
    RHS                  R706 4.1231056256176606
    RHS                  R707 4.1231056256176606
    RHS                  R708 4.1231056256176606
    RHS                  R709 4.1231056256176606
    RHS                  R710 4.1231056256176606
    RHS                  R711 4.1231056256176606
    RHS                  R712 4.1231056256176606
    RHS                  R713 4.1231056256176606
    RHS                  R714 4.1231056256176606
    RHS                  R715 4.1231056256176606
    RHS                  R716 4.1231056256176606
    RHS                  R717 4.1231056256176606
    RHS                  R718 4.1231056256176606
    RHS                  R719 4.1231056256176606
    RHS                  R720 4.1231056256176606
    RHS                  R721 4.1231056256176606
    RHS                  R722 4.1231056256176606
    RHS                  R723 4.1231056256176606
    RHS                  R724 4.1231056256176606
    RHS                  R725 4.1231056256176606
    RHS                  R726 4.1231056256176606
    RHS                  R727 4.1231056256176606
    RHS                  R728 4.1231056256176606
    RHS                  R729 4.1231056256176606
    RHS                  R730 4.1231056256176606
    RHS                  R731 4.1231056256176606
    RHS                  R732 4.1231056256176606
    RHS                  R733 4.1231056256176606
    RHS                  R734 4.1231056256176606
    RHS                  R735 4.1231056256176606
    RHS                  R736 4.1231056256176606
    RHS                  R737 4.1231056256176606
    RHS                  R738 4.1231056256176606
    RHS                  R739 4.1231056256176606
    RHS                  R740 4.1231056256176606
    RHS                  R741 4.1231056256176606
    RHS                  R742 4.1231056256176606
    RHS                  R743 4.1231056256176606
    RHS                  R744 4.1231056256176606
    RHS                  R745 4.1231056256176606
    RHS                  R746 4.1231056256176606
    RHS                  R747 4.1231056256176606
    RHS                  R748 4.1231056256176606
    RHS                  R749 4.1231056256176606
    RHS                  R750 4.1231056256176606
    RHS                  R751 4.1231056256176606
    RHS                  R752 4.1231056256176606
    RHS                  R753 4.1231056256176606
    RHS                  R754 4.1231056256176606
    RHS                  R755 4.1231056256176606
    RHS                  R756 4.1231056256176606
    RHS                  R757 4.1231056256176606
    RHS                  R758 4.1231056256176606
    RHS                  R759 4.1231056256176606
    RHS                  R760 4.1231056256176606
    RHS                  R761 4.1231056256176606
    RHS                  R762 4.1231056256176606
    RHS                  R763 4.1231056256176606
    RHS                  R764 4.1231056256176606
    RHS                  R765 4.1231056256176606
    RHS                  R766 4.1231056256176606
    RHS                  R767 4.1231056256176606
    RHS                  R768 4.1231056256176606
    RHS                  R769 4.1231056256176606
    RHS                  R770 4.1231056256176606
    RHS                  R771 4.1231056256176606
    RHS                  R772 4.1231056256176606
    RHS                  R773 4.1231056256176606
    RHS                  R774 4.1231056256176606
    RHS                  R775 4.1231056256176606
    RHS                  R776 4.1231056256176606
    RHS                  R777 4.1231056256176606
    RHS                  R778 4.1231056256176606
    RHS                  R779 4.1231056256176606
    RHS                  R780 4.1231056256176606
    RHS                  R781 4.1231056256176606
    RHS                  R782 4.1231056256176606
    RHS                  R783 4.1231056256176606
    RHS                  R784 4.1231056256176606
    RHS                  R785 4.1231056256176606
    RHS                  R786 4.1231056256176606
    RHS                  R787 4.1231056256176606
    RHS                  R788 4.1231056256176606
    RHS                  R789 4.1231056256176606
    RHS                  R790 4.1231056256176606
    RHS                  R791 4.1231056256176606
    RHS                  R792 4.1231056256176606
    RHS                  R793 4.1231056256176606
    RHS                  R794 4.1231056256176606
    RHS                  R795 4.1231056256176606
    RHS                  R796 4.1231056256176606
    RHS                  R797 4.1231056256176606
    RHS                  R798 4.1231056256176606
    RHS                  R799 4.1231056256176606
    RHS                  R800 4.1231056256176606
    RHS                  R801 4.1231056256176606
    RHS                  R802 4.1231056256176606
    RHS                  R803 4.1231056256176606
    RHS                  R804 4.1231056256176606
    RHS                  R805 4.1231056256176606
    RHS                  R806 4.1231056256176606
    RHS                  R807 4.1231056256176606
    RHS                  R808 4.1231056256176606
    RHS                  R809 4.1231056256176606
    RHS                  R810 4.1231056256176606
    RHS                  R811 4.1231056256176606
    RHS                  R812 4.1231056256176606
    RHS                  R813 4.1231056256176606
    RHS                  R814 4.1231056256176606
    RHS                  R815 4.1231056256176606
    RHS                  R816 4.1231056256176606
    RHS                  R817 4.1231056256176606
    RHS                  R818 4.1231056256176606
    RHS                  R819 4.1231056256176606
    RHS                  R820 4.1231056256176606
    RHS                  R821 4.1231056256176606
    RHS                  R822 4.1231056256176606
    RHS                  R823 4.1231056256176606
    RHS                  R824 4.1231056256176606
    RHS                  R825 4.1231056256176606
    RHS                  R826 4.1231056256176606
    RHS                  R827 4.1231056256176606
    RHS                  R828 4.1231056256176606
    RHS                  R829 4.1231056256176606
    RHS                  R830 4.1231056256176606
    RHS                  R831 4.1231056256176606
    RHS                  R832 4.1231056256176606
    RHS                  R833 4.1231056256176606
    RHS                  R834 4.1231056256176606
    RHS                  R835 4.1231056256176606
    RHS                  R836 4.1231056256176606
    RHS                  R837 4.1231056256176606
    RHS                  R838 4.1231056256176606
    RHS                  R839 4.1231056256176606
    RHS                  R840 4.1231056256176606
    RHS                  R841 4.1231056256176606
    RHS                  R842 4.1231056256176606
    RHS                  R843 4.1231056256176606
    RHS                  R844 4.1231056256176606
    RHS                  R845 4.1231056256176606
    RHS                  R846 4.1231056256176606
    RHS                  R847 4.1231056256176606
    RHS                  R848 4.1231056256176606
    RHS                  R849 4.1231056256176606
    RHS                  R850 4.1231056256176606
    RHS                  R851 4.1231056256176606
    RHS                  R852 4.1231056256176606
    RHS                  R853 4.1231056256176606
    RHS                  R854 4.1231056256176606
    RHS                  R855 4.1231056256176606
    RHS                  R856 4.1231056256176606
    RHS                  R857 4.1231056256176606
    RHS                  R858 4.1231056256176606
    RHS                  R859 4.1231056256176606
    RHS                  R860 4.1231056256176606
    RHS                  R861 4.1231056256176606
    RHS                  R862 4.1231056256176606
    RHS                  R863 4.1231056256176606
    RHS                  R864 4.1231056256176606
    RHS                  R865 4.1231056256176606
    RHS                  R866 4.1231056256176606
    RHS                  R867 4.1231056256176606
    RHS                  R868 4.1231056256176606
    RHS                  R869 4.1231056256176606
BOUNDS
 	FR BND X0
 	LO BND X0 0
 	FR BND X1
 	LO BND X1 0
 	FR BND X2
 	LO BND X2 0
 	FR BND X3
 	LO BND X3 0
 	FR BND X4
 	LO BND X4 0
 	FR BND X5
 	LO BND X5 0
 	FR BND X6
 	LO BND X6 0
 	FR BND X7
 	LO BND X7 0
 	FR BND X8
 	LO BND X8 0
 	FR BND X9
 	LO BND X9 0
 	FR BND X10
 	LO BND X10 0
 	FR BND X11
 	LO BND X11 0
 	FR BND X12
 	LO BND X12 0
 	FR BND X13
 	LO BND X13 0
 	FR BND X14
 	LO BND X14 0
 	FR BND X15
 	LO BND X15 0
 	FR BND X16
 	LO BND X16 0
 	FR BND X17
 	LO BND X17 0
 	FR BND X18
 	LO BND X18 0
 	FR BND X19
 	LO BND X19 0
 	FR BND X20
 	LO BND X20 0
 	FR BND X21
 	LO BND X21 0
 	FR BND X22
 	LO BND X22 0
 	FR BND X23
 	LO BND X23 0
 	FR BND X24
 	LO BND X24 0
 	FR BND X25
 	LO BND X25 0
 	FR BND X26
 	LO BND X26 0
 	FR BND X27
 	LO BND X27 0
 	FR BND X28
 	LO BND X28 0
 	FR BND X29
 	LO BND X29 0
 	FR BND X30
 	LO BND X30 0
 	FR BND X31
 	LO BND X31 0
 	FR BND X32
 	LO BND X32 0
 	FR BND X33
 	LO BND X33 0
 	FR BND X34
 	LO BND X34 0
 	FR BND X35
 	LO BND X35 0
 	FR BND X36
 	LO BND X36 0
 	FR BND X37
 	LO BND X37 0
 	FR BND X38
 	LO BND X38 0
 	FR BND X39
 	LO BND X39 0
 	FR BND X40
 	LO BND X40 0
 	UP BND X40 1
 	FR BND X41
 	LO BND X41 0
 	UP BND X41 1
 	FR BND X42
 	LO BND X42 0
 	UP BND X42 1
 	FR BND X43
 	LO BND X43 0
 	UP BND X43 1
 	FR BND X44
 	LO BND X44 0
 	UP BND X44 1
 	FR BND X45
 	LO BND X45 0
 	UP BND X45 1
 	FR BND X46
 	LO BND X46 0
 	UP BND X46 1
 	FR BND X47
 	LO BND X47 0
 	UP BND X47 1
 	FR BND X48
 	LO BND X48 0
 	UP BND X48 1
 	FR BND X49
 	LO BND X49 0
 	UP BND X49 1
 	FR BND X50
 	LO BND X50 0
 	UP BND X50 1
 	FR BND X51
 	LO BND X51 0
 	UP BND X51 1
 	FR BND X52
 	LO BND X52 0
 	UP BND X52 1
 	FR BND X53
 	LO BND X53 0
 	UP BND X53 1
 	FR BND X54
 	LO BND X54 0
 	UP BND X54 1
 	FR BND X55
 	LO BND X55 0
 	UP BND X55 1
 	FR BND X56
 	LO BND X56 0
 	UP BND X56 1
 	FR BND X57
 	LO BND X57 0
 	UP BND X57 1
 	FR BND X58
 	LO BND X58 0
 	UP BND X58 1
 	FR BND X59
 	LO BND X59 0
 	UP BND X59 1
 	FR BND X60
 	LO BND X60 0
 	UP BND X60 1
 	FR BND X61
 	LO BND X61 0
 	UP BND X61 1
 	FR BND X62
 	LO BND X62 0
 	UP BND X62 1
 	FR BND X63
 	LO BND X63 0
 	UP BND X63 1
 	FR BND X64
 	LO BND X64 0
 	UP BND X64 1
 	FR BND X65
 	LO BND X65 0
 	UP BND X65 1
 	FR BND X66
 	LO BND X66 0
 	UP BND X66 1
 	FR BND X67
 	LO BND X67 0
 	UP BND X67 1
 	FR BND X68
 	LO BND X68 0
 	UP BND X68 1
 	FR BND X69
 	LO BND X69 0
 	UP BND X69 1
 	FR BND X70
 	LO BND X70 0
 	UP BND X70 1
 	FR BND X71
 	LO BND X71 0
 	UP BND X71 1
 	FR BND X72
 	LO BND X72 0
 	UP BND X72 1
 	FR BND X73
 	LO BND X73 0
 	UP BND X73 1
 	FR BND X74
 	LO BND X74 0
 	UP BND X74 1
 	FR BND X75
 	LO BND X75 0
 	UP BND X75 1
 	FR BND X76
 	LO BND X76 0
 	UP BND X76 1
 	FR BND X77
 	LO BND X77 0
 	UP BND X77 1
 	FR BND X78
 	LO BND X78 0
 	UP BND X78 1
 	FR BND X79
 	LO BND X79 0
 	UP BND X79 1
 	FR BND X80
 	LO BND X80 0
 	UP BND X80 1
 	FR BND X81
 	LO BND X81 0
 	UP BND X81 1
 	FR BND X82
 	LO BND X82 0
 	UP BND X82 1
 	FR BND X83
 	LO BND X83 0
 	UP BND X83 1
 	FR BND X84
 	LO BND X84 0
 	UP BND X84 1
 	FR BND X85
 	LO BND X85 0
 	UP BND X85 1
 	FR BND X86
 	LO BND X86 0
 	UP BND X86 1
 	FR BND X87
 	LO BND X87 0
 	UP BND X87 1
 	FR BND X88
 	LO BND X88 0
 	UP BND X88 1
 	FR BND X89
 	LO BND X89 0
 	UP BND X89 1
 	FR BND X90
 	LO BND X90 0
 	UP BND X90 1
 	FR BND X91
 	LO BND X91 0
 	UP BND X91 1
 	FR BND X92
 	LO BND X92 0
 	UP BND X92 1
 	FR BND X93
 	LO BND X93 0
 	UP BND X93 1
 	FR BND X94
 	LO BND X94 0
 	UP BND X94 1
 	FR BND X95
 	LO BND X95 0
 	UP BND X95 1
 	FR BND X96
 	LO BND X96 0
 	UP BND X96 1
 	FR BND X97
 	LO BND X97 0
 	UP BND X97 1
 	FR BND X98
 	LO BND X98 0
 	UP BND X98 1
 	FR BND X99
 	LO BND X99 0
 	UP BND X99 1
 	FR BND X100
 	LO BND X100 0
 	UP BND X100 1
 	FR BND X101
 	LO BND X101 0
 	UP BND X101 1
 	FR BND X102
 	LO BND X102 0
 	UP BND X102 1
 	FR BND X103
 	LO BND X103 0
 	UP BND X103 1
 	FR BND X104
 	LO BND X104 0
 	UP BND X104 1
 	FR BND X105
 	LO BND X105 0
 	UP BND X105 1
 	FR BND X106
 	LO BND X106 0
 	UP BND X106 1
 	FR BND X107
 	LO BND X107 0
 	UP BND X107 1
 	FR BND X108
 	LO BND X108 0
 	UP BND X108 1
 	FR BND X109
 	LO BND X109 0
 	UP BND X109 1
 	FR BND X110
 	LO BND X110 0
 	UP BND X110 1
 	FR BND X111
 	LO BND X111 0
 	UP BND X111 1
 	FR BND X112
 	LO BND X112 0
 	UP BND X112 1
 	FR BND X113
 	LO BND X113 0
 	UP BND X113 1
 	FR BND X114
 	LO BND X114 0
 	UP BND X114 1
 	FR BND X115
 	LO BND X115 0
 	UP BND X115 1
 	FR BND X116
 	LO BND X116 0
 	UP BND X116 1
 	FR BND X117
 	LO BND X117 0
 	UP BND X117 1
 	FR BND X118
 	LO BND X118 0
 	UP BND X118 1
 	FR BND X119
 	LO BND X119 0
 	UP BND X119 1
 	FR BND X120
 	LO BND X120 0
 	UP BND X120 1
 	FR BND X121
 	LO BND X121 0
 	UP BND X121 1
 	FR BND X122
 	LO BND X122 0
 	UP BND X122 1
 	FR BND X123
 	LO BND X123 0
 	UP BND X123 1
 	FR BND X124
 	LO BND X124 0
 	UP BND X124 1
 	FR BND X125
 	LO BND X125 0
 	UP BND X125 1
 	FR BND X126
 	LO BND X126 0
 	UP BND X126 1
 	FR BND X127
 	LO BND X127 0
 	UP BND X127 1
 	FR BND X128
 	LO BND X128 0
 	UP BND X128 1
 	FR BND X129
 	LO BND X129 0
 	UP BND X129 1
 	FR BND X130
 	LO BND X130 0
 	UP BND X130 1
 	FR BND X131
 	LO BND X131 0
 	UP BND X131 1
 	FR BND X132
 	LO BND X132 0
 	UP BND X132 1
 	FR BND X133
 	LO BND X133 0
 	UP BND X133 1
 	FR BND X134
 	LO BND X134 0
 	UP BND X134 1
 	FR BND X135
 	LO BND X135 0
 	UP BND X135 1
 	FR BND X136
 	LO BND X136 0
 	UP BND X136 1
 	FR BND X137
 	LO BND X137 0
 	UP BND X137 1
 	FR BND X138
 	LO BND X138 0
 	UP BND X138 1
 	FR BND X139
 	LO BND X139 0
 	UP BND X139 1
 	FR BND X140
 	LO BND X140 0
 	UP BND X140 1
 	FR BND X141
 	LO BND X141 0
 	UP BND X141 1
 	FR BND X142
 	LO BND X142 0
 	UP BND X142 1
 	FR BND X143
 	LO BND X143 0
 	UP BND X143 1
 	FR BND X144
 	LO BND X144 0
 	UP BND X144 1
 	FR BND X145
 	LO BND X145 0
 	UP BND X145 1
 	FR BND X146
 	LO BND X146 0
 	UP BND X146 1
 	FR BND X147
 	LO BND X147 0
 	UP BND X147 1
 	FR BND X148
 	LO BND X148 0
 	UP BND X148 1
 	FR BND X149
 	LO BND X149 0
 	UP BND X149 1
 	FR BND X150
 	LO BND X150 0
 	UP BND X150 1
 	FR BND X151
 	LO BND X151 0
 	UP BND X151 1
 	FR BND X152
 	LO BND X152 0
 	UP BND X152 1
 	FR BND X153
 	LO BND X153 0
 	UP BND X153 1
 	FR BND X154
 	LO BND X154 0
 	UP BND X154 1
 	FR BND X155
 	LO BND X155 0
 	UP BND X155 1
 	FR BND X156
 	LO BND X156 0
 	UP BND X156 1
 	FR BND X157
 	LO BND X157 0
 	UP BND X157 1
 	FR BND X158
 	LO BND X158 0
 	UP BND X158 1
 	FR BND X159
 	LO BND X159 0
 	UP BND X159 1
 	FR BND X160
 	LO BND X160 0
 	UP BND X160 1
 	FR BND X161
 	LO BND X161 0
 	UP BND X161 1
 	FR BND X162
 	LO BND X162 0
 	UP BND X162 1
 	FR BND X163
 	LO BND X163 0
 	UP BND X163 1
 	FR BND X164
 	LO BND X164 0
 	UP BND X164 1
 	FR BND X165
 	LO BND X165 0
 	UP BND X165 1
 	FR BND X166
 	LO BND X166 0
 	UP BND X166 1
 	FR BND X167
 	LO BND X167 0
 	UP BND X167 1
 	FR BND X168
 	LO BND X168 0
 	UP BND X168 1
 	FR BND X169
 	LO BND X169 0
 	UP BND X169 1
 	FR BND X170
 	LO BND X170 0
 	UP BND X170 1
 	FR BND X171
 	LO BND X171 0
 	UP BND X171 1
 	FR BND X172
 	LO BND X172 0
 	UP BND X172 1
 	FR BND X173
 	LO BND X173 0
 	UP BND X173 1
 	FR BND X174
 	LO BND X174 0
 	UP BND X174 1
 	FR BND X175
 	LO BND X175 0
 	UP BND X175 1
 	FR BND X176
 	LO BND X176 0
 	UP BND X176 1
 	FR BND X177
 	LO BND X177 0
 	UP BND X177 1
 	FR BND X178
 	LO BND X178 0
 	UP BND X178 1
 	FR BND X179
 	LO BND X179 0
 	UP BND X179 1
 	FR BND X180
 	LO BND X180 0
 	UP BND X180 1
 	FR BND X181
 	LO BND X181 0
 	UP BND X181 1
 	FR BND X182
 	LO BND X182 0
 	UP BND X182 1
 	FR BND X183
 	LO BND X183 0
 	UP BND X183 1
 	FR BND X184
 	LO BND X184 0
 	UP BND X184 1
 	FR BND X185
 	LO BND X185 0
 	UP BND X185 1
 	FR BND X186
 	LO BND X186 0
 	UP BND X186 1
 	FR BND X187
 	LO BND X187 0
 	UP BND X187 1
 	FR BND X188
 	LO BND X188 0
 	UP BND X188 1
 	FR BND X189
 	LO BND X189 0
 	UP BND X189 1
 	FR BND X190
 	LO BND X190 0
 	UP BND X190 1
 	FR BND X191
 	LO BND X191 0
 	UP BND X191 1
 	FR BND X192
 	LO BND X192 0
 	UP BND X192 1
 	FR BND X193
 	LO BND X193 0
 	UP BND X193 1
 	FR BND X194
 	LO BND X194 0
 	UP BND X194 1
 	FR BND X195
 	LO BND X195 0
 	UP BND X195 1
 	FR BND X196
 	LO BND X196 0
 	UP BND X196 1
 	FR BND X197
 	LO BND X197 0
 	UP BND X197 1
 	FR BND X198
 	LO BND X198 0
 	UP BND X198 1
 	FR BND X199
 	LO BND X199 0
 	UP BND X199 1
 	FR BND X200
 	LO BND X200 0
 	UP BND X200 1
 	FR BND X201
 	LO BND X201 0
 	UP BND X201 1
 	FR BND X202
 	LO BND X202 0
 	UP BND X202 1
 	FR BND X203
 	LO BND X203 0
 	UP BND X203 1
 	FR BND X204
 	LO BND X204 0
 	UP BND X204 1
 	FR BND X205
 	LO BND X205 0
 	UP BND X205 1
 	FR BND X206
 	LO BND X206 0
 	UP BND X206 1
 	FR BND X207
 	LO BND X207 0
 	UP BND X207 1
 	FR BND X208
 	LO BND X208 0
 	UP BND X208 1
 	FR BND X209
 	LO BND X209 0
 	UP BND X209 1
 	FR BND X210
 	LO BND X210 0
 	UP BND X210 1
 	FR BND X211
 	LO BND X211 0
 	UP BND X211 1
 	FR BND X212
 	LO BND X212 0
 	UP BND X212 1
 	FR BND X213
 	LO BND X213 0
 	UP BND X213 1
 	FR BND X214
 	LO BND X214 0
 	UP BND X214 1
 	FR BND X215
 	LO BND X215 0
 	UP BND X215 1
 	FR BND X216
 	LO BND X216 0
 	UP BND X216 1
 	FR BND X217
 	LO BND X217 0
 	UP BND X217 1
 	FR BND X218
 	LO BND X218 0
 	UP BND X218 1
 	FR BND X219
 	LO BND X219 0
 	UP BND X219 1
 	FR BND X220
 	LO BND X220 0
 	UP BND X220 1
 	FR BND X221
 	LO BND X221 0
 	UP BND X221 1
 	FR BND X222
 	LO BND X222 0
 	UP BND X222 1
 	FR BND X223
 	LO BND X223 0
 	UP BND X223 1
 	FR BND X224
 	LO BND X224 0
 	UP BND X224 1
 	FR BND X225
 	LO BND X225 0
 	UP BND X225 1
 	FR BND X226
 	LO BND X226 0
 	UP BND X226 1
 	FR BND X227
 	LO BND X227 0
 	UP BND X227 1
 	FR BND X228
 	LO BND X228 0
 	UP BND X228 1
 	FR BND X229
 	LO BND X229 0
 	UP BND X229 1
 	FR BND X230
 	LO BND X230 0
 	UP BND X230 1
 	FR BND X231
 	LO BND X231 0
 	UP BND X231 1
 	FR BND X232
 	LO BND X232 0
 	UP BND X232 1
 	FR BND X233
 	LO BND X233 0
 	UP BND X233 1
 	FR BND X234
 	LO BND X234 0
 	UP BND X234 1
 	FR BND X235
 	LO BND X235 0
 	UP BND X235 1
 	FR BND X236
 	LO BND X236 0
 	UP BND X236 1
 	FR BND X237
 	LO BND X237 0
 	UP BND X237 1
 	FR BND X238
 	LO BND X238 0
 	UP BND X238 1
 	FR BND X239
 	LO BND X239 0
 	UP BND X239 1
 	FR BND X240
 	LO BND X240 0
 	UP BND X240 1
 	FR BND X241
 	LO BND X241 0
 	UP BND X241 1
 	FR BND X242
 	LO BND X242 0
 	UP BND X242 1
 	FR BND X243
 	LO BND X243 0
 	UP BND X243 1
 	FR BND X244
 	LO BND X244 0
 	UP BND X244 1
 	FR BND X245
 	LO BND X245 0
 	UP BND X245 1
 	FR BND X246
 	LO BND X246 0
 	UP BND X246 1
 	FR BND X247
 	LO BND X247 0
 	UP BND X247 1
 	FR BND X248
 	LO BND X248 0
 	UP BND X248 1
 	FR BND X249
 	LO BND X249 0
 	UP BND X249 1
 	FR BND X250
 	LO BND X250 0
 	UP BND X250 1
 	FR BND X251
 	LO BND X251 0
 	UP BND X251 1
 	FR BND X252
 	LO BND X252 0
 	UP BND X252 1
 	FR BND X253
 	LO BND X253 0
 	UP BND X253 1
 	FR BND X254
 	LO BND X254 0
 	UP BND X254 1
 	FR BND X255
 	LO BND X255 0
 	UP BND X255 1
 	FR BND X256
 	LO BND X256 0
 	UP BND X256 1
 	FR BND X257
 	LO BND X257 0
 	UP BND X257 1
 	FR BND X258
 	LO BND X258 0
 	UP BND X258 1
 	FR BND X259
 	LO BND X259 0
 	UP BND X259 1
 	FR BND X260
 	LO BND X260 0
 	UP BND X260 1
 	FR BND X261
 	LO BND X261 0
 	UP BND X261 1
 	FR BND X262
 	LO BND X262 0
 	UP BND X262 1
 	FR BND X263
 	LO BND X263 0
 	UP BND X263 1
 	FR BND X264
 	LO BND X264 0
 	UP BND X264 1
 	FR BND X265
 	LO BND X265 0
 	UP BND X265 1
 	FR BND X266
 	LO BND X266 0
 	UP BND X266 1
 	FR BND X267
 	LO BND X267 0
 	UP BND X267 1
 	FR BND X268
 	LO BND X268 0
 	UP BND X268 1
 	FR BND X269
 	LO BND X269 0
 	UP BND X269 1
 	FR BND X270
 	LO BND X270 0
 	UP BND X270 1
 	FR BND X271
 	LO BND X271 0
 	UP BND X271 1
 	FR BND X272
 	LO BND X272 0
 	UP BND X272 1
 	FR BND X273
 	LO BND X273 0
 	UP BND X273 1
 	FR BND X274
 	LO BND X274 0
 	UP BND X274 1
 	FR BND X275
 	LO BND X275 0
 	UP BND X275 1
 	FR BND X276
 	LO BND X276 0
 	UP BND X276 1
 	FR BND X277
 	LO BND X277 0
 	UP BND X277 1
 	FR BND X278
 	LO BND X278 0
 	UP BND X278 1
 	FR BND X279
 	LO BND X279 0
 	UP BND X279 1
 	FR BND X280
 	LO BND X280 0
 	UP BND X280 1
 	FR BND X281
 	LO BND X281 0
 	UP BND X281 1
 	FR BND X282
 	LO BND X282 0
 	UP BND X282 1
 	FR BND X283
 	LO BND X283 0
 	UP BND X283 1
 	FR BND X284
 	LO BND X284 0
 	UP BND X284 1
 	FR BND X285
 	LO BND X285 0
 	UP BND X285 1
 	FR BND X286
 	LO BND X286 0
 	UP BND X286 1
 	FR BND X287
 	LO BND X287 0
 	UP BND X287 1
 	FR BND X288
 	LO BND X288 0
 	UP BND X288 1
 	FR BND X289
 	LO BND X289 0
 	UP BND X289 1
 	FR BND X290
 	LO BND X290 0
 	UP BND X290 1
 	FR BND X291
 	LO BND X291 0
 	UP BND X291 1
 	FR BND X292
 	LO BND X292 0
 	UP BND X292 1
 	FR BND X293
 	LO BND X293 0
 	UP BND X293 1
 	FR BND X294
 	LO BND X294 0
 	UP BND X294 1
 	FR BND X295
 	LO BND X295 0
 	UP BND X295 1
 	FR BND X296
 	LO BND X296 0
 	UP BND X296 1
 	FR BND X297
 	LO BND X297 0
 	UP BND X297 1
 	FR BND X298
 	LO BND X298 0
 	UP BND X298 1
 	FR BND X299
 	LO BND X299 0
 	UP BND X299 1
 	FR BND X300
 	LO BND X300 0
 	UP BND X300 1
 	FR BND X301
 	LO BND X301 0
 	UP BND X301 1
 	FR BND X302
 	LO BND X302 0
 	UP BND X302 1
 	FR BND X303
 	LO BND X303 0
 	UP BND X303 1
 	FR BND X304
 	LO BND X304 0
 	UP BND X304 1
 	FR BND X305
 	LO BND X305 0
 	UP BND X305 1
 	FR BND X306
 	LO BND X306 0
 	UP BND X306 1
 	FR BND X307
 	LO BND X307 0
 	UP BND X307 1
 	FR BND X308
 	LO BND X308 0
 	UP BND X308 1
 	FR BND X309
 	LO BND X309 0
 	UP BND X309 1
 	FR BND X310
 	LO BND X310 0
 	UP BND X310 1
 	FR BND X311
 	LO BND X311 0
 	UP BND X311 1
 	FR BND X312
 	LO BND X312 0
 	UP BND X312 1
 	FR BND X313
 	LO BND X313 0
 	UP BND X313 1
 	FR BND X314
 	LO BND X314 0
 	UP BND X314 1
 	FR BND X315
 	LO BND X315 0
 	UP BND X315 1
 	FR BND X316
 	LO BND X316 0
 	UP BND X316 1
 	FR BND X317
 	LO BND X317 0
 	UP BND X317 1
 	FR BND X318
 	LO BND X318 0
 	UP BND X318 1
 	FR BND X319
 	LO BND X319 0
 	UP BND X319 1
 	FR BND X320
 	LO BND X320 0
 	UP BND X320 1
 	FR BND X321
 	LO BND X321 0
 	UP BND X321 1
 	FR BND X322
 	LO BND X322 0
 	UP BND X322 1
 	FR BND X323
 	LO BND X323 0
 	UP BND X323 1
 	FR BND X324
 	LO BND X324 0
 	UP BND X324 1
 	FR BND X325
 	LO BND X325 0
 	UP BND X325 1
 	FR BND X326
 	LO BND X326 0
 	UP BND X326 1
 	FR BND X327
 	LO BND X327 0
 	UP BND X327 1
 	FR BND X328
 	LO BND X328 0
 	UP BND X328 1
 	FR BND X329
 	LO BND X329 0
 	UP BND X329 1
 	FR BND X330
 	LO BND X330 0
 	UP BND X330 1
 	FR BND X331
 	LO BND X331 0
 	UP BND X331 1
 	FR BND X332
 	LO BND X332 0
 	UP BND X332 1
 	FR BND X333
 	LO BND X333 0
 	UP BND X333 1
 	FR BND X334
 	LO BND X334 0
 	UP BND X334 1
 	FR BND X335
 	LO BND X335 0
 	UP BND X335 1
 	FR BND X336
 	LO BND X336 0
 	UP BND X336 1
 	FR BND X337
 	LO BND X337 0
 	UP BND X337 1
 	FR BND X338
 	LO BND X338 0
 	UP BND X338 1
 	FR BND X339
 	LO BND X339 0
 	UP BND X339 1
 	FR BND X340
 	LO BND X340 0
 	UP BND X340 1
 	FR BND X341
 	LO BND X341 0
 	UP BND X341 1
 	FR BND X342
 	LO BND X342 0
 	UP BND X342 1
 	FR BND X343
 	LO BND X343 0
 	UP BND X343 1
 	FR BND X344
 	LO BND X344 0
 	UP BND X344 1
 	FR BND X345
 	LO BND X345 0
 	UP BND X345 1
 	FR BND X346
 	LO BND X346 0
 	UP BND X346 1
 	FR BND X347
 	LO BND X347 0
 	UP BND X347 1
 	FR BND X348
 	LO BND X348 0
 	UP BND X348 1
 	FR BND X349
 	LO BND X349 0
 	UP BND X349 1
 	FR BND X350
 	LO BND X350 0
 	UP BND X350 1
 	FR BND X351
 	LO BND X351 0
 	UP BND X351 1
 	FR BND X352
 	LO BND X352 0
 	UP BND X352 1
 	FR BND X353
 	LO BND X353 0
 	UP BND X353 1
 	FR BND X354
 	LO BND X354 0
 	UP BND X354 1
 	FR BND X355
 	LO BND X355 0
 	UP BND X355 1
 	FR BND X356
 	LO BND X356 0
 	UP BND X356 1
 	FR BND X357
 	LO BND X357 0
 	UP BND X357 1
 	FR BND X358
 	LO BND X358 0
 	UP BND X358 1
 	FR BND X359
 	LO BND X359 0
 	UP BND X359 1
 	FR BND X360
 	LO BND X360 0
 	UP BND X360 1
 	FR BND X361
 	LO BND X361 0
 	UP BND X361 1
 	FR BND X362
 	LO BND X362 0
 	UP BND X362 1
 	FR BND X363
 	LO BND X363 0
 	UP BND X363 1
 	FR BND X364
 	LO BND X364 0
 	UP BND X364 1
 	FR BND X365
 	LO BND X365 0
 	UP BND X365 1
 	FR BND X366
 	LO BND X366 0
 	UP BND X366 1
 	FR BND X367
 	LO BND X367 0
 	UP BND X367 1
 	FR BND X368
 	LO BND X368 0
 	UP BND X368 1
 	FR BND X369
 	LO BND X369 0
 	UP BND X369 1
 	FR BND X370
 	LO BND X370 0
 	UP BND X370 1
 	FR BND X371
 	LO BND X371 0
 	UP BND X371 1
 	FR BND X372
 	LO BND X372 0
 	UP BND X372 1
 	FR BND X373
 	LO BND X373 0
 	UP BND X373 1
 	FR BND X374
 	LO BND X374 0
 	UP BND X374 1
 	FR BND X375
 	LO BND X375 0
 	UP BND X375 1
 	FR BND X376
 	LO BND X376 0
 	UP BND X376 1
 	FR BND X377
 	LO BND X377 0
 	UP BND X377 1
 	FR BND X378
 	LO BND X378 0
 	UP BND X378 1
 	FR BND X379
 	LO BND X379 0
 	UP BND X379 1
 	FR BND X380
 	LO BND X380 0
 	UP BND X380 1
 	FR BND X381
 	LO BND X381 0
 	UP BND X381 1
 	FR BND X382
 	LO BND X382 0
 	UP BND X382 1
 	FR BND X383
 	LO BND X383 0
 	UP BND X383 1
 	FR BND X384
 	LO BND X384 0
 	UP BND X384 1
 	FR BND X385
 	LO BND X385 0
 	UP BND X385 1
 	FR BND X386
 	LO BND X386 0
 	UP BND X386 1
 	FR BND X387
 	LO BND X387 0
 	UP BND X387 1
 	FR BND X388
 	LO BND X388 0
 	UP BND X388 1
 	FR BND X389
 	LO BND X389 0
 	UP BND X389 1
 	FR BND X390
 	LO BND X390 0
 	UP BND X390 1
 	FR BND X391
 	LO BND X391 0
 	UP BND X391 1
 	FR BND X392
 	LO BND X392 0
 	UP BND X392 1
 	FR BND X393
 	LO BND X393 0
 	UP BND X393 1
 	FR BND X394
 	LO BND X394 0
 	UP BND X394 1
 	FR BND X395
 	LO BND X395 0
 	UP BND X395 1
 	FR BND X396
 	LO BND X396 0
 	UP BND X396 1
 	FR BND X397
 	LO BND X397 0
 	UP BND X397 1
 	FR BND X398
 	LO BND X398 0
 	UP BND X398 1
 	FR BND X399
 	LO BND X399 0
 	UP BND X399 1
 	FR BND X400
 	LO BND X400 0
 	UP BND X400 1
 	FR BND X401
 	LO BND X401 0
 	UP BND X401 1
 	FR BND X402
 	LO BND X402 0
 	UP BND X402 1
 	FR BND X403
 	LO BND X403 0
 	UP BND X403 1
 	FR BND X404
 	LO BND X404 0
 	UP BND X404 1
 	FR BND X405
 	LO BND X405 0
 	UP BND X405 1
 	FR BND X406
 	LO BND X406 0
 	UP BND X406 1
 	FR BND X407
 	LO BND X407 0
 	UP BND X407 1
 	FR BND X408
 	LO BND X408 0
 	UP BND X408 1
 	FR BND X409
 	LO BND X409 0
 	UP BND X409 1
 	FR BND X410
 	LO BND X410 0
 	UP BND X410 1
 	FR BND X411
 	LO BND X411 0
 	UP BND X411 1
 	FR BND X412
 	LO BND X412 0
 	UP BND X412 1
 	FR BND X413
 	LO BND X413 0
 	UP BND X413 1
 	FR BND X414
 	LO BND X414 0
 	UP BND X414 1
 	FR BND X415
 	LO BND X415 0
 	UP BND X415 1
 	FR BND X416
 	LO BND X416 0
 	UP BND X416 1
 	FR BND X417
 	LO BND X417 0
 	UP BND X417 1
 	FR BND X418
 	LO BND X418 0
 	UP BND X418 1
 	FR BND X419
 	LO BND X419 0
 	UP BND X419 1
 	FR BND X420
 	LO BND X420 0
 	UP BND X420 1
 	FR BND X421
 	LO BND X421 0
 	UP BND X421 1
 	FR BND X422
 	LO BND X422 0
 	UP BND X422 1
 	FR BND X423
 	LO BND X423 0
 	UP BND X423 1
 	FR BND X424
 	LO BND X424 0
 	UP BND X424 1
 	FR BND X425
 	LO BND X425 0
 	UP BND X425 1
 	FR BND X426
 	LO BND X426 0
 	UP BND X426 1
 	FR BND X427
 	LO BND X427 0
 	UP BND X427 1
 	FR BND X428
 	LO BND X428 0
 	UP BND X428 1
 	FR BND X429
 	LO BND X429 0
 	UP BND X429 1
 	FR BND X430
 	LO BND X430 0
 	UP BND X430 1
 	FR BND X431
 	LO BND X431 0
 	UP BND X431 1
 	FR BND X432
 	LO BND X432 0
 	UP BND X432 1
 	FR BND X433
 	LO BND X433 0
 	UP BND X433 1
 	FR BND X434
 	LO BND X434 0
 	UP BND X434 1
 	FR BND X435
 	LO BND X435 0
 	UP BND X435 1
ENDATA
