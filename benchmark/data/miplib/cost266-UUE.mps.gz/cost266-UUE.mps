* MIPLIB 2017 benchmark v2; LP relaxation (integrality removed).
* Source: https://miplib.zib.de/downloads/benchmark.zip ; retrieved 2026-09-21
* Instance: cost266-UUE ; Gleixner et al. (2021), doi:10.1007/s12532-020-00194-3
* Bounds and coefficients preserved; rows/variables renamed; objective minimized.
* Original compressed SHA256: a6048c81daa7c992ff5c3f6b954e2fd4d77048c9b9c3e49b76380a3c3e73fa7d
NAME cost266-UUE
ROWS
 N OBJ
 E R0
 E R1
 L R2
 E R3
 L R4
 E R5
 L R6
 E R7
 L R8
 E R9
 E R10
 L R11
 E R12
 L R13
 E R14
 L R15
 E R16
 E R17
 L R18
 E R19
 L R20
 E R21
 L R22
 E R23
 E R24
 L R25
 L R26
 L R27
 E R28
 E R29
 L R30
 L R31
 E R32
 L R33
 E R34
 L R35
 E R36
 L R37
 E R38
 L R39
 L R40
 E R41
 L R42
 L R43
 E R44
 L R45
 E R46
 L R47
 L R48
 E R49
 L R50
 L R51
 E R52
 L R53
 E R54
 L R55
 E R56
 L R57
 L R58
 E R59
 L R60
 L R61
 L R62
 E R63
 L R64
 E R65
 L R66
 L R67
 L R68
 L R69
 E R70
 L R71
 L R72
 L R73
 L R74
 E R75
 L R76
 L R77
 E R78
 L R79
 E R80
 L R81
 E R82
 L R83
 L R84
 L R85
 E R86
 L R87
 L R88
 L R89
 L R90
 L R91
 L R92
 L R93
 E R94
 E R95
 E R96
 E R97
 E R98
 E R99
 E R100
 E R101
 E R102
 E R103
 E R104
 E R105
 E R106
 E R107
 E R108
 E R109
 E R110
 E R111
 E R112
 E R113
 E R114
 E R115
 E R116
 E R117
 E R118
 E R119
 E R120
 E R121
 E R122
 E R123
 E R124
 E R125
 E R126
 E R127
 E R128
 E R129
 E R130
 E R131
 E R132
 E R133
 E R134
 E R135
 E R136
 E R137
 E R138
 E R139
 E R140
 E R141
 E R142
 E R143
 E R144
 E R145
 E R146
 E R147
 E R148
 E R149
 E R150
 E R151
 E R152
 E R153
 E R154
 E R155
 E R156
 E R157
 E R158
 E R159
 E R160
 E R161
 E R162
 E R163
 E R164
 E R165
 E R166
 E R167
 E R168
 E R169
 E R170
 E R171
 E R172
 E R173
 E R174
 E R175
 E R176
 E R177
 E R178
 E R179
 E R180
 E R181
 E R182
 E R183
 E R184
 E R185
 E R186
 E R187
 E R188
 E R189
 E R190
 E R191
 E R192
 E R193
 E R194
 E R195
 E R196
 E R197
 E R198
 E R199
 E R200
 E R201
 E R202
 E R203
 E R204
 E R205
 E R206
 E R207
 E R208
 E R209
 E R210
 E R211
 E R212
 E R213
 E R214
 E R215
 E R216
 E R217
 E R218
 E R219
 E R220
 E R221
 E R222
 E R223
 E R224
 E R225
 E R226
 E R227
 E R228
 E R229
 E R230
 E R231
 E R232
 E R233
 E R234
 E R235
 E R236
 E R237
 E R238
 E R239
 E R240
 E R241
 E R242
 E R243
 E R244
 E R245
 E R246
 E R247
 E R248
 E R249
 E R250
 E R251
 E R252
 E R253
 E R254
 E R255
 E R256
 E R257
 E R258
 E R259
 E R260
 E R261
 E R262
 E R263
 E R264
 E R265
 E R266
 E R267
 E R268
 E R269
 E R270
 E R271
 E R272
 E R273
 E R274
 E R275
 E R276
 E R277
 E R278
 E R279
 E R280
 E R281
 E R282
 E R283
 E R284
 E R285
 E R286
 E R287
 E R288
 E R289
 E R290
 E R291
 E R292
 E R293
 E R294
 E R295
 E R296
 E R297
 E R298
 E R299
 E R300
 E R301
 E R302
 E R303
 E R304
 E R305
 E R306
 E R307
 E R308
 E R309
 E R310
 E R311
 E R312
 E R313
 E R314
 E R315
 E R316
 E R317
 E R318
 E R319
 E R320
 E R321
 E R322
 E R323
 E R324
 E R325
 E R326
 E R327
 E R328
 E R329
 E R330
 E R331
 E R332
 E R333
 E R334
 E R335
 E R336
 E R337
 E R338
 E R339
 E R340
 E R341
 E R342
 E R343
 E R344
 E R345
 E R346
 E R347
 E R348
 E R349
 E R350
 E R351
 E R352
 E R353
 E R354
 E R355
 E R356
 E R357
 E R358
 E R359
 E R360
 E R361
 E R362
 E R363
 E R364
 E R365
 E R366
 E R367
 E R368
 E R369
 E R370
 E R371
 E R372
 E R373
 E R374
 E R375
 E R376
 E R377
 E R378
 E R379
 E R380
 E R381
 E R382
 E R383
 E R384
 E R385
 E R386
 E R387
 E R388
 E R389
 E R390
 E R391
 E R392
 E R393
 E R394
 E R395
 E R396
 E R397
 E R398
 E R399
 E R400
 E R401
 E R402
 E R403
 E R404
 E R405
 E R406
 E R407
 E R408
 E R409
 E R410
 E R411
 E R412
 E R413
 E R414
 E R415
 E R416
 E R417
 E R418
 E R419
 E R420
 E R421
 E R422
 E R423
 E R424
 E R425
 E R426
 E R427
 E R428
 E R429
 E R430
 E R431
 E R432
 E R433
 E R434
 E R435
 E R436
 E R437
 E R438
 E R439
 E R440
 E R441
 E R442
 E R443
 E R444
 E R445
 E R446
 E R447
 E R448
 E R449
 E R450
 E R451
 E R452
 E R453
 E R454
 E R455
 E R456
 E R457
 E R458
 E R459
 E R460
 E R461
 E R462
 E R463
 E R464
 E R465
 E R466
 E R467
 E R468
 E R469
 E R470
 E R471
 E R472
 E R473
 E R474
 E R475
 E R476
 E R477
 E R478
 E R479
 E R480
 E R481
 E R482
 E R483
 E R484
 E R485
 E R486
 E R487
 E R488
 E R489
 E R490
 E R491
 E R492
 E R493
 E R494
 E R495
 E R496
 E R497
 E R498
 E R499
 E R500
 E R501
 E R502
 E R503
 E R504
 E R505
 E R506
 E R507
 E R508
 E R509
 E R510
 E R511
 E R512
 E R513
 E R514
 E R515
 E R516
 E R517
 E R518
 E R519
 E R520
 E R521
 E R522
 E R523
 E R524
 E R525
 E R526
 E R527
 E R528
 E R529
 E R530
 E R531
 E R532
 E R533
 E R534
 E R535
 E R536
 E R537
 E R538
 E R539
 E R540
 E R541
 E R542
 E R543
 E R544
 E R545
 E R546
 E R547
 E R548
 E R549
 E R550
 E R551
 E R552
 E R553
 E R554
 E R555
 E R556
 E R557
 E R558
 E R559
 E R560
 E R561
 E R562
 E R563
 E R564
 E R565
 E R566
 E R567
 E R568
 E R569
 E R570
 E R571
 E R572
 E R573
 E R574
 E R575
 E R576
 E R577
 E R578
 E R579
 E R580
 E R581
 E R582
 E R583
 E R584
 E R585
 E R586
 E R587
 E R588
 E R589
 E R590
 E R591
 E R592
 E R593
 E R594
 E R595
 E R596
 E R597
 E R598
 E R599
 E R600
 E R601
 E R602
 E R603
 E R604
 E R605
 E R606
 E R607
 E R608
 E R609
 E R610
 E R611
 E R612
 E R613
 E R614
 E R615
 E R616
 E R617
 E R618
 E R619
 E R620
 E R621
 E R622
 E R623
 E R624
 E R625
 E R626
 E R627
 E R628
 E R629
 E R630
 E R631
 E R632
 E R633
 E R634
 E R635
 E R636
 E R637
 E R638
 E R639
 E R640
 E R641
 E R642
 E R643
 E R644
 E R645
 E R646
 E R647
 E R648
 E R649
 E R650
 E R651
 E R652
 E R653
 E R654
 E R655
 E R656
 E R657
 E R658
 E R659
 E R660
 E R661
 E R662
 E R663
 E R664
 E R665
 E R666
 E R667
 E R668
 E R669
 E R670
 E R671
 E R672
 E R673
 E R674
 E R675
 E R676
 E R677
 E R678
 E R679
 E R680
 E R681
 E R682
 E R683
 E R684
 E R685
 E R686
 E R687
 E R688
 E R689
 E R690
 E R691
 E R692
 E R693
 E R694
 E R695
 E R696
 E R697
 E R698
 E R699
 E R700
 E R701
 E R702
 E R703
 E R704
 E R705
 E R706
 E R707
 E R708
 E R709
 E R710
 E R711
 E R712
 E R713
 E R714
 E R715
 E R716
 E R717
 E R718
 E R719
 E R720
 E R721
 E R722
 E R723
 E R724
 E R725
 E R726
 E R727
 E R728
 E R729
 E R730
 E R731
 E R732
 E R733
 E R734
 E R735
 E R736
 E R737
 E R738
 E R739
 E R740
 E R741
 E R742
 E R743
 E R744
 E R745
 E R746
 E R747
 E R748
 E R749
 E R750
 E R751
 E R752
 E R753
 E R754
 E R755
 E R756
 E R757
 E R758
 E R759
 E R760
 E R761
 E R762
 E R763
 E R764
 E R765
 E R766
 E R767
 E R768
 E R769
 E R770
 E R771
 E R772
 E R773
 E R774
 E R775
 E R776
 E R777
 E R778
 E R779
 E R780
 E R781
 E R782
 E R783
 E R784
 E R785
 E R786
 E R787
 E R788
 E R789
 E R790
 E R791
 E R792
 E R793
 E R794
 E R795
 E R796
 E R797
 E R798
 E R799
 E R800
 E R801
 E R802
 E R803
 E R804
 E R805
 E R806
 E R807
 E R808
 E R809
 E R810
 E R811
 E R812
 E R813
 E R814
 E R815
 E R816
 E R817
 E R818
 E R819
 E R820
 E R821
 E R822
 E R823
 E R824
 E R825
 E R826
 E R827
 E R828
 E R829
 E R830
 E R831
 E R832
 E R833
 E R834
 E R835
 E R836
 E R837
 E R838
 E R839
 E R840
 E R841
 E R842
 E R843
 E R844
 E R845
 E R846
 E R847
 E R848
 E R849
 E R850
 E R851
 E R852
 E R853
 E R854
 E R855
 E R856
 E R857
 E R858
 E R859
 E R860
 E R861
 E R862
 E R863
 E R864
 E R865
 E R866
 E R867
 E R868
 E R869
 E R870
 E R871
 E R872
 E R873
 E R874
 E R875
 E R876
 E R877
 E R878
 E R879
 E R880
 E R881
 E R882
 E R883
 E R884
 E R885
 E R886
 E R887
 E R888
 E R889
 E R890
 E R891
 E R892
 E R893
 E R894
 E R895
 E R896
 E R897
 E R898
 E R899
 E R900
 E R901
 E R902
 E R903
 E R904
 E R905
 E R906
 E R907
 E R908
 E R909
 E R910
 E R911
 E R912
 E R913
 E R914
 E R915
 E R916
 E R917
 E R918
 E R919
 E R920
 E R921
 E R922
 E R923
 E R924
 E R925
 E R926
 E R927
 E R928
 E R929
 E R930
 E R931
 E R932
 E R933
 E R934
 E R935
 E R936
 E R937
 E R938
 E R939
 E R940
 E R941
 E R942
 E R943
 E R944
 E R945
 E R946
 E R947
 E R948
 E R949
 E R950
 E R951
 E R952
 E R953
 E R954
 E R955
 E R956
 E R957
 E R958
 E R959
 E R960
 E R961
 E R962
 E R963
 E R964
 E R965
 E R966
 E R967
 E R968
 E R969
 E R970
 E R971
 E R972
 E R973
 E R974
 E R975
 E R976
 E R977
 E R978
 E R979
 E R980
 E R981
 E R982
 E R983
 E R984
 E R985
 E R986
 E R987
 E R988
 E R989
 E R990
 E R991
 E R992
 E R993
 E R994
 E R995
 E R996
 E R997
 E R998
 E R999
 E R1000
 E R1001
 E R1002
 E R1003
 E R1004
 E R1005
 E R1006
 E R1007
 E R1008
 E R1009
 E R1010
 E R1011
 E R1012
 E R1013
 E R1014
 E R1015
 E R1016
 E R1017
 E R1018
 E R1019
 E R1020
 E R1021
 E R1022
 E R1023
 E R1024
 E R1025
 E R1026
 E R1027
 E R1028
 E R1029
 E R1030
 E R1031
 E R1032
 E R1033
 E R1034
 E R1035
 E R1036
 E R1037
 E R1038
 E R1039
 E R1040
 E R1041
 E R1042
 E R1043
 E R1044
 E R1045
 E R1046
 E R1047
 E R1048
 E R1049
 E R1050
 E R1051
 E R1052
 E R1053
 E R1054
 E R1055
 E R1056
 E R1057
 E R1058
 E R1059
 E R1060
 E R1061
 E R1062
 E R1063
 E R1064
 E R1065
 E R1066
 E R1067
 E R1068
 E R1069
 E R1070
 E R1071
 E R1072
 E R1073
 E R1074
 E R1075
 E R1076
 E R1077
 E R1078
 E R1079
 E R1080
 E R1081
 E R1082
 E R1083
 E R1084
 E R1085
 E R1086
 E R1087
 E R1088
 E R1089
 E R1090
 E R1091
 E R1092
 E R1093
 E R1094
 E R1095
 E R1096
 E R1097
 E R1098
 E R1099
 E R1100
 E R1101
 E R1102
 E R1103
 E R1104
 E R1105
 E R1106
 E R1107
 E R1108
 E R1109
 E R1110
 E R1111
 E R1112
 E R1113
 E R1114
 E R1115
 E R1116
 E R1117
 E R1118
 E R1119
 E R1120
 E R1121
 E R1122
 E R1123
 E R1124
 E R1125
 E R1126
 E R1127
 E R1128
 E R1129
 E R1130
 E R1131
 E R1132
 E R1133
 E R1134
 E R1135
 E R1136
 E R1137
 E R1138
 E R1139
 E R1140
 E R1141
 E R1142
 E R1143
 E R1144
 E R1145
 E R1146
 E R1147
 E R1148
 E R1149
 E R1150
 E R1151
 E R1152
 E R1153
 E R1154
 E R1155
 E R1156
 E R1157
 E R1158
 E R1159
 E R1160
 E R1161
 E R1162
 E R1163
 E R1164
 E R1165
 E R1166
 E R1167
 E R1168
 E R1169
 E R1170
 E R1171
 E R1172
 E R1173
 E R1174
 E R1175
 E R1176
 E R1177
 E R1178
 E R1179
 E R1180
 E R1181
 E R1182
 E R1183
 E R1184
 E R1185
 E R1186
 E R1187
 E R1188
 E R1189
 E R1190
 E R1191
 E R1192
 E R1193
 E R1194
 E R1195
 E R1196
 E R1197
 E R1198
 E R1199
 E R1200
 E R1201
 E R1202
 E R1203
 E R1204
 E R1205
 E R1206
 E R1207
 E R1208
 E R1209
 E R1210
 E R1211
 E R1212
 E R1213
 E R1214
 E R1215
 E R1216
 E R1217
 E R1218
 E R1219
 E R1220
 E R1221
 E R1222
 E R1223
 E R1224
 E R1225
 E R1226
 E R1227
 E R1228
 E R1229
 E R1230
 E R1231
 E R1232
 E R1233
 E R1234
 E R1235
 E R1236
 E R1237
 E R1238
 E R1239
 E R1240
 E R1241
 E R1242
 E R1243
 E R1244
 E R1245
 E R1246
 E R1247
 E R1248
 E R1249
 E R1250
 E R1251
 E R1252
 E R1253
 E R1254
 E R1255
 E R1256
 E R1257
 E R1258
 E R1259
 E R1260
 E R1261
 E R1262
 E R1263
 E R1264
 E R1265
 E R1266
 E R1267
 E R1268
 E R1269
 E R1270
 E R1271
 E R1272
 E R1273
 E R1274
 E R1275
 E R1276
 E R1277
 E R1278
 E R1279
 E R1280
 E R1281
 E R1282
 E R1283
 E R1284
 E R1285
 E R1286
 E R1287
 E R1288
 E R1289
 E R1290
 E R1291
 E R1292
 E R1293
 E R1294
 E R1295
 E R1296
 E R1297
 E R1298
 E R1299
 E R1300
 E R1301
 E R1302
 E R1303
 E R1304
 E R1305
 E R1306
 E R1307
 E R1308
 E R1309
 E R1310
 E R1311
 E R1312
 E R1313
 E R1314
 E R1315
 E R1316
 E R1317
 E R1318
 E R1319
 E R1320
 E R1321
 E R1322
 E R1323
 E R1324
 E R1325
 E R1326
 E R1327
 E R1328
 E R1329
 E R1330
 E R1331
 E R1332
 E R1333
 E R1334
 E R1335
 E R1336
 E R1337
 E R1338
 E R1339
 E R1340
 E R1341
 E R1342
 E R1343
 E R1344
 E R1345
 E R1346
 E R1347
 E R1348
 E R1349
 E R1350
 E R1351
 E R1352
 E R1353
 E R1354
 E R1355
 E R1356
 E R1357
 E R1358
 E R1359
 E R1360
 E R1361
 E R1362
 E R1363
 E R1364
 E R1365
 E R1366
 E R1367
 E R1368
 E R1369
 E R1370
 E R1371
 E R1372
 E R1373
 E R1374
 E R1375
 E R1376
 E R1377
 E R1378
 E R1379
 E R1380
 E R1381
 E R1382
 E R1383
 E R1384
 E R1385
 E R1386
 E R1387
 E R1388
 G R1389
 G R1390
 G R1391
 G R1392
 G R1393
 G R1394
 G R1395
 G R1396
 G R1397
 G R1398
 G R1399
 G R1400
 G R1401
 G R1402
 G R1403
 G R1404
 G R1405
 G R1406
 G R1407
 G R1408
 G R1409
 G R1410
 G R1411
 G R1412
 G R1413
 G R1414
 G R1415
 G R1416
 G R1417
 G R1418
 G R1419
 G R1420
 G R1421
 G R1422
 G R1423
 G R1424
 G R1425
 G R1426
 G R1427
 G R1428
 G R1429
 G R1430
 G R1431
 G R1432
 G R1433
 G R1434
 G R1435
 G R1436
 G R1437
 G R1438
 G R1439
 G R1440
 G R1441
 G R1442
 G R1443
 G R1444
 G R1445
COLUMNS
    X0                   OBJ 23310
    X0                   R2 -7560
    X0                   R1389 -1
    X1                   OBJ 69930
    X1                   R2 -30240
    X1                   R1389 -1
    X2                   OBJ 209790
    X2                   R2 -120960
    X2                   R1389 -1
    X3                   OBJ 96030
    X3                   R4 -7560
    X3                   R1390 -1
    X4                   OBJ 288090
    X4                   R4 -30240
    X4                   R1390 -1
    X5                   OBJ 864270
    X5                   R4 -120960
    X5                   R1390 -1
    X6                   OBJ 49680
    X6                   R6 -7560
    X6                   R1391 -1
    X7                   OBJ 149040
    X7                   R6 -30240
    X7                   R1391 -1
    X8                   OBJ 447120
    X8                   R6 -120960
    X8                   R1391 -1
    X9                   OBJ 48600
    X9                   R8 -7560
    X9                   R1392 -1
    X10                  OBJ 145800
    X10                  R8 -30240
    X10                  R1392 -1
    X11                  OBJ 437400
    X11                  R8 -120960
    X11                  R1392 -1
    X12                  OBJ 122670
    X12                  R11 -7560
    X12                  R1393 -1
    X13                  OBJ 368010
    X13                  R11 -30240
    X13                  R1393 -1
    X14                  OBJ 1104030
    X14                  R11 -120960
    X14                  R1393 -1
    X15                  OBJ 71460
    X15                  R13 -7560
    X15                  R1394 -1
    X16                  OBJ 214380
    X16                  R13 -30240
    X16                  R1394 -1
    X17                  OBJ 643140
    X17                  R13 -120960
    X17                  R1394 -1
    X18                  OBJ 135000
    X18                  R15 -7560
    X18                  R1395 -1
    X19                  OBJ 405000
    X19                  R15 -30240
    X19                  R1395 -1
    X20                  OBJ 1215000
    X20                  R15 -120960
    X20                  R1395 -1
    X21                  OBJ 68400
    X21                  R18 -7560
    X21                  R1396 -1
    X22                  OBJ 205200
    X22                  R18 -30240
    X22                  R1396 -1
    X23                  OBJ 615600
    X23                  R18 -120960
    X23                  R1396 -1
    X24                  OBJ 45720
    X24                  R20 -7560
    X24                  R1397 -1
    X25                  OBJ 137160
    X25                  R20 -30240
    X25                  R1397 -1
    X26                  OBJ 411480
    X26                  R20 -120960
    X26                  R1397 -1
    X27                  OBJ 111960
    X27                  R22 -7560
    X27                  R1398 -1
    X28                  OBJ 335880
    X28                  R22 -30240
    X28                  R1398 -1
    X29                  OBJ 1007640
    X29                  R22 -120960
    X29                  R1398 -1
    X30                  OBJ 42660
    X30                  R25 -7560
    X30                  R1399 -1
    X31                  OBJ 127980
    X31                  R25 -30240
    X31                  R1399 -1
    X32                  OBJ 383940
    X32                  R25 -120960
    X32                  R1399 -1
    X33                  OBJ 43830
    X33                  R26 -7560
    X33                  R1400 -1
    X34                  OBJ 131490
    X34                  R26 -30240
    X34                  R1400 -1
    X35                  OBJ 394470
    X35                  R26 -120960
    X35                  R1400 -1
    X36                  OBJ 49590
    X36                  R27 -7560
    X36                  R1401 -1
    X37                  OBJ 148770
    X37                  R27 -30240
    X37                  R1401 -1
    X38                  OBJ 446310
    X38                  R27 -120960
    X38                  R1401 -1
    X39                  OBJ 48600
    X39                  R30 -7560
    X39                  R1402 -1
    X40                  OBJ 145800
    X40                  R30 -30240
    X40                  R1402 -1
    X41                  OBJ 437400
    X41                  R30 -120960
    X41                  R1402 -1
    X42                  OBJ 34290
    X42                  R31 -7560
    X42                  R1403 -1
    X43                  OBJ 102870
    X43                  R31 -30240
    X43                  R1403 -1
    X44                  OBJ 308610
    X44                  R31 -120960
    X44                  R1403 -1
    X45                  OBJ 68130
    X45                  R33 -7560
    X45                  R1404 -1
    X46                  OBJ 204390
    X46                  R33 -30240
    X46                  R1404 -1
    X47                  OBJ 613170
    X47                  R33 -120960
    X47                  R1404 -1
    X48                  OBJ 37800
    X48                  R35 -7560
    X48                  R1405 -1
    X49                  OBJ 113400
    X49                  R35 -30240
    X49                  R1405 -1
    X50                  OBJ 340200
    X50                  R35 -120960
    X50                  R1405 -1
    X51                  OBJ 69750
    X51                  R37 -7560
    X51                  R1406 -1
    X52                  OBJ 209250
    X52                  R37 -30240
    X52                  R1406 -1
    X53                  OBJ 627750
    X53                  R37 -120960
    X53                  R1406 -1
    X54                  OBJ 54900
    X54                  R39 -7560
    X54                  R1407 -1
    X55                  OBJ 164700
    X55                  R39 -30240
    X55                  R1407 -1
    X56                  OBJ 494100
    X56                  R39 -120960
    X56                  R1407 -1
    X57                  OBJ 21510
    X57                  R40 -7560
    X57                  R1408 -1
    X58                  OBJ 64530
    X58                  R40 -30240
    X58                  R1408 -1
    X59                  OBJ 193590
    X59                  R40 -120960
    X59                  R1408 -1
    X60                  OBJ 75060
    X60                  R42 -7560
    X60                  R1409 -1
    X61                  OBJ 225180
    X61                  R42 -30240
    X61                  R1409 -1
    X62                  OBJ 675540
    X62                  R42 -120960
    X62                  R1409 -1
    X63                  OBJ 68040
    X63                  R43 -7560
    X63                  R1410 -1
    X64                  OBJ 204120
    X64                  R43 -30240
    X64                  R1410 -1
    X65                  OBJ 612360
    X65                  R43 -120960
    X65                  R1410 -1
    X66                  OBJ 67230
    X66                  R45 -7560
    X66                  R1411 -1
    X67                  OBJ 201690
    X67                  R45 -30240
    X67                  R1411 -1
    X68                  OBJ 605070
    X68                  R45 -120960
    X68                  R1411 -1
    X69                  OBJ 23760
    X69                  R47 -7560
    X69                  R1412 -1
    X70                  OBJ 71280
    X70                  R47 -30240
    X70                  R1412 -1
    X71                  OBJ 213840
    X71                  R47 -120960
    X71                  R1412 -1
    X72                  OBJ 35370
    X72                  R48 -7560
    X72                  R1413 -1
    X73                  OBJ 106110
    X73                  R48 -30240
    X73                  R1413 -1
    X74                  OBJ 318330
    X74                  R48 -120960
    X74                  R1413 -1
    X75                  OBJ 39240
    X75                  R50 -7560
    X75                  R1414 -1
    X76                  OBJ 117720
    X76                  R50 -30240
    X76                  R1414 -1
    X77                  OBJ 353160
    X77                  R50 -120960
    X77                  R1414 -1
    X78                  OBJ 60120
    X78                  R51 -7560
    X78                  R1415 -1
    X79                  OBJ 180360
    X79                  R51 -30240
    X79                  R1415 -1
    X80                  OBJ 541080
    X80                  R51 -120960
    X80                  R1415 -1
    X81                  OBJ 64980
    X81                  R53 -7560
    X81                  R1416 -1
    X82                  OBJ 194940
    X82                  R53 -30240
    X82                  R1416 -1
    X83                  OBJ 584820
    X83                  R53 -120960
    X83                  R1416 -1
    X84                  OBJ 69930
    X84                  R55 -7560
    X84                  R1417 -1
    X85                  OBJ 209790
    X85                  R55 -30240
    X85                  R1417 -1
    X86                  OBJ 629370
    X86                  R55 -120960
    X86                  R1417 -1
    X87                  OBJ 41580
    X87                  R57 -7560
    X87                  R1418 -1
    X88                  OBJ 124740
    X88                  R57 -30240
    X88                  R1418 -1
    X89                  OBJ 374220
    X89                  R57 -120960
    X89                  R1418 -1
    X90                  OBJ 62100
    X90                  R58 -7560
    X90                  R1419 -1
    X91                  OBJ 186300
    X91                  R58 -30240
    X91                  R1419 -1
    X92                  OBJ 558900
    X92                  R58 -120960
    X92                  R1419 -1
    X93                  OBJ 24750
    X93                  R60 -7560
    X93                  R1420 -1
    X94                  OBJ 74250
    X94                  R60 -30240
    X94                  R1420 -1
    X95                  OBJ 222750
    X95                  R60 -120960
    X95                  R1420 -1
    X96                  OBJ 53280
    X96                  R61 -7560
    X96                  R1421 -1
    X97                  OBJ 159840
    X97                  R61 -30240
    X97                  R1421 -1
    X98                  OBJ 479520
    X98                  R61 -120960
    X98                  R1421 -1
    X99                  OBJ 41040
    X99                  R62 -7560
    X99                  R1422 -1
    X100                 OBJ 123120
    X100                 R62 -30240
    X100                 R1422 -1
    X101                 OBJ 369360
    X101                 R62 -120960
    X101                 R1422 -1
    X102                 OBJ 24390
    X102                 R64 -7560
    X102                 R1423 -1
    X103                 OBJ 73170
    X103                 R64 -30240
    X103                 R1423 -1
    X104                 OBJ 219510
    X104                 R64 -120960
    X104                 R1423 -1
    X105                 OBJ 106380
    X105                 R66 -7560
    X105                 R1424 -1
    X106                 OBJ 319140
    X106                 R66 -30240
    X106                 R1424 -1
    X107                 OBJ 957420
    X107                 R66 -120960
    X107                 R1424 -1
    X108                 OBJ 53730
    X108                 R67 -7560
    X108                 R1425 -1
    X109                 OBJ 161190
    X109                 R67 -30240
    X109                 R1425 -1
    X110                 OBJ 483570
    X110                 R67 -120960
    X110                 R1425 -1
    X111                 OBJ 123300
    X111                 R68 -7560
    X111                 R1426 -1
    X112                 OBJ 369900
    X112                 R68 -30240
    X112                 R1426 -1
    X113                 OBJ 1109700
    X113                 R68 -120960
    X113                 R1426 -1
    X114                 OBJ 34470
    X114                 R69 -7560
    X114                 R1427 -1
    X115                 OBJ 103410
    X115                 R69 -30240
    X115                 R1427 -1
    X116                 OBJ 310230
    X116                 R69 -120960
    X116                 R1427 -1
    X117                 OBJ 177930
    X117                 R71 -7560
    X117                 R1428 -1
    X118                 OBJ 533790
    X118                 R71 -30240
    X118                 R1428 -1
    X119                 OBJ 1601370
    X119                 R71 -120960
    X119                 R1428 -1
    X120                 OBJ 67590
    X120                 R72 -7560
    X120                 R1429 -1
    X121                 OBJ 202770
    X121                 R72 -30240
    X121                 R1429 -1
    X122                 OBJ 608310
    X122                 R72 -120960
    X122                 R1429 -1
    X123                 OBJ 42390
    X123                 R73 -7560
    X123                 R1430 -1
    X124                 OBJ 127170
    X124                 R73 -30240
    X124                 R1430 -1
    X125                 OBJ 381510
    X125                 R73 -120960
    X125                 R1430 -1
    X126                 OBJ 46260
    X126                 R74 -7560
    X126                 R1431 -1
    X127                 OBJ 138780
    X127                 R74 -30240
    X127                 R1431 -1
    X128                 OBJ 416340
    X128                 R74 -120960
    X128                 R1431 -1
    X129                 OBJ 36990
    X129                 R76 -7560
    X129                 R1432 -1
    X130                 OBJ 110970
    X130                 R76 -30240
    X130                 R1432 -1
    X131                 OBJ 332910
    X131                 R76 -120960
    X131                 R1432 -1
    X132                 OBJ 53460
    X132                 R77 -7560
    X132                 R1433 -1
    X133                 OBJ 160380
    X133                 R77 -30240
    X133                 R1433 -1
    X134                 OBJ 481140
    X134                 R77 -120960
    X134                 R1433 -1
    X135                 OBJ 45630
    X135                 R79 -7560
    X135                 R1434 -1
    X136                 OBJ 136890
    X136                 R79 -30240
    X136                 R1434 -1
    X137                 OBJ 410670
    X137                 R79 -120960
    X137                 R1434 -1
    X138                 OBJ 81630
    X138                 R81 -7560
    X138                 R1435 -1
    X139                 OBJ 244890
    X139                 R81 -30240
    X139                 R1435 -1
    X140                 OBJ 734670
    X140                 R81 -120960
    X140                 R1435 -1
    X141                 OBJ 46980
    X141                 R83 -7560
    X141                 R1436 -1
    X142                 OBJ 140940
    X142                 R83 -30240
    X142                 R1436 -1
    X143                 OBJ 422820
    X143                 R83 -120960
    X143                 R1436 -1
    X144                 OBJ 64800
    X144                 R84 -7560
    X144                 R1437 -1
    X145                 OBJ 194400
    X145                 R84 -30240
    X145                 R1437 -1
    X146                 OBJ 583200
    X146                 R84 -120960
    X146                 R1437 -1
    X147                 OBJ 29430
    X147                 R85 -7560
    X147                 R1438 -1
    X148                 OBJ 88290
    X148                 R85 -30240
    X148                 R1438 -1
    X149                 OBJ 264870
    X149                 R85 -120960
    X149                 R1438 -1
    X150                 OBJ 48060
    X150                 R87 -7560
    X150                 R1439 -1
    X151                 OBJ 144180
    X151                 R87 -30240
    X151                 R1439 -1
    X152                 OBJ 432540
    X152                 R87 -120960
    X152                 R1439 -1
    X153                 OBJ 57420
    X153                 R88 -7560
    X153                 R1440 -1
    X154                 OBJ 172260
    X154                 R88 -30240
    X154                 R1440 -1
    X155                 OBJ 516780
    X155                 R88 -120960
    X155                 R1440 -1
    X156                 OBJ 54000
    X156                 R89 -7560
    X156                 R1441 -1
    X157                 OBJ 162000
    X157                 R89 -30240
    X157                 R1441 -1
    X158                 OBJ 486000
    X158                 R89 -120960
    X158                 R1441 -1
    X159                 OBJ 33840
    X159                 R90 -7560
    X159                 R1442 -1
    X160                 OBJ 101520
    X160                 R90 -30240
    X160                 R1442 -1
    X161                 OBJ 304560
    X161                 R90 -120960
    X161                 R1442 -1
    X162                 OBJ 70470
    X162                 R91 -7560
    X162                 R1443 -1
    X163                 OBJ 211410
    X163                 R91 -30240
    X163                 R1443 -1
    X164                 OBJ 634230
    X164                 R91 -120960
    X164                 R1443 -1
    X165                 OBJ 19620
    X165                 R92 -7560
    X165                 R1444 -1
    X166                 OBJ 58860
    X166                 R92 -30240
    X166                 R1444 -1
    X167                 OBJ 176580
    X167                 R92 -120960
    X167                 R1444 -1
    X168                 OBJ 36000
    X168                 R93 -7560
    X168                 R1445 -1
    X169                 OBJ 108000
    X169                 R93 -30240
    X169                 R1445 -1
    X170                 OBJ 324000
    X170                 R93 -120960
    X170                 R1445 -1
    X171                 OBJ 2.5899999999999999
    X171                 R0 1
    X171                 R1 -1
    X171                 R2 1
    X172                 OBJ 2.5899999999999999
    X172                 R0 -1
    X172                 R1 1
    X172                 R2 1
    X173                 OBJ 10.67
    X173                 R0 1
    X173                 R3 -1
    X173                 R4 1
    X174                 OBJ 10.67
    X174                 R0 -1
    X174                 R3 1
    X174                 R4 1
    X175                 OBJ 5.5199999999999996
    X175                 R0 1
    X175                 R5 -1
    X175                 R6 1
    X176                 OBJ 5.5199999999999996
    X176                 R0 -1
    X176                 R5 1
    X176                 R6 1
    X177                 OBJ 5.4000000000000004
    X177                 R0 1
    X177                 R7 -1
    X177                 R8 1
    X178                 OBJ 5.4000000000000004
    X178                 R0 -1
    X178                 R7 1
    X178                 R8 1
    X179                 OBJ 13.630000000000001
    X179                 R9 1
    X179                 R10 -1
    X179                 R11 1
    X180                 OBJ 13.630000000000001
    X180                 R9 -1
    X180                 R10 1
    X180                 R11 1
    X181                 OBJ 7.9400000000000004
    X181                 R9 1
    X181                 R12 -1
    X181                 R13 1
    X182                 OBJ 7.9400000000000004
    X182                 R9 -1
    X182                 R12 1
    X182                 R13 1
    X183                 OBJ 15
    X183                 R9 1
    X183                 R14 -1
    X183                 R15 1
    X184                 OBJ 15
    X184                 R9 -1
    X184                 R14 1
    X184                 R15 1
    X185                 OBJ 7.5999999999999996
    X185                 R16 1
    X185                 R17 -1
    X185                 R18 1
    X186                 OBJ 7.5999999999999996
    X186                 R16 -1
    X186                 R17 1
    X186                 R18 1
    X187                 OBJ 5.0800000000000001
    X187                 R16 1
    X187                 R19 -1
    X187                 R20 1
    X188                 OBJ 5.0800000000000001
    X188                 R16 -1
    X188                 R19 1
    X188                 R20 1
    X189                 OBJ 12.44
    X189                 R16 1
    X189                 R21 -1
    X189                 R22 1
    X190                 OBJ 12.44
    X190                 R16 -1
    X190                 R21 1
    X190                 R22 1
    X191                 OBJ 4.7400000000000002
    X191                 R23 1
    X191                 R24 -1
    X191                 R25 1
    X192                 OBJ 4.7400000000000002
    X192                 R23 -1
    X192                 R24 1
    X192                 R25 1
    X193                 OBJ 4.8700000000000001
    X193                 R12 -1
    X193                 R23 1
    X193                 R26 1
    X194                 OBJ 4.8700000000000001
    X194                 R12 1
    X194                 R23 -1
    X194                 R26 1
    X195                 OBJ 5.5099999999999998
    X195                 R14 -1
    X195                 R23 1
    X195                 R27 1
    X196                 OBJ 5.5099999999999998
    X196                 R14 1
    X196                 R23 -1
    X196                 R27 1
    X197                 OBJ 5.4000000000000004
    X197                 R28 1
    X197                 R29 -1
    X197                 R30 1
    X198                 OBJ 5.4000000000000004
    X198                 R28 -1
    X198                 R29 1
    X198                 R30 1
    X199                 OBJ 3.8100000000000001
    X199                 R5 -1
    X199                 R28 1
    X199                 R31 1
    X200                 OBJ 3.8100000000000001
    X200                 R5 1
    X200                 R28 -1
    X200                 R31 1
    X201                 OBJ 7.5700000000000003
    X201                 R28 1
    X201                 R32 -1
    X201                 R33 1
    X202                 OBJ 7.5700000000000003
    X202                 R28 -1
    X202                 R32 1
    X202                 R33 1
    X203                 OBJ 4.2000000000000002
    X203                 R28 1
    X203                 R34 -1
    X203                 R35 1
    X204                 OBJ 4.2000000000000002
    X204                 R28 -1
    X204                 R34 1
    X204                 R35 1
    X205                 OBJ 7.75
    X205                 R28 1
    X205                 R36 -1
    X205                 R37 1
    X206                 OBJ 7.75
    X206                 R28 -1
    X206                 R36 1
    X206                 R37 1
    X207                 OBJ 6.0999999999999996
    X207                 R3 -1
    X207                 R38 1
    X207                 R39 1
    X208                 OBJ 2.3900000000000001
    X208                 R7 -1
    X208                 R38 1
    X208                 R40 1
    X209                 OBJ 8.3399999999999999
    X209                 R17 -1
    X209                 R41 1
    X209                 R42 1
    X210                 OBJ 8.3399999999999999
    X210                 R17 1
    X210                 R41 -1
    X210                 R42 1
    X211                 OBJ 7.5599999999999996
    X211                 R19 -1
    X211                 R41 1
    X211                 R43 1
    X212                 OBJ 7.5599999999999996
    X212                 R19 1
    X212                 R41 -1
    X212                 R43 1
    X213                 OBJ 7.4699999999999998
    X213                 R41 1
    X213                 R44 -1
    X213                 R45 1
    X214                 OBJ 7.4699999999999998
    X214                 R41 -1
    X214                 R44 1
    X214                 R45 1
    X215                 OBJ 2.6400000000000001
    X215                 R1 1
    X215                 R46 -1
    X215                 R47 1
    X216                 OBJ 2.6400000000000001
    X216                 R1 -1
    X216                 R46 1
    X216                 R47 1
    X217                 OBJ 3.9300000000000002
    X217                 R1 1
    X217                 R44 -1
    X217                 R48 1
    X218                 OBJ 3.9300000000000002
    X218                 R1 -1
    X218                 R44 1
    X218                 R48 1
    X219                 OBJ 4.3600000000000003
    X219                 R24 1
    X219                 R49 -1
    X219                 R50 1
    X220                 OBJ 4.3600000000000003
    X220                 R24 -1
    X220                 R49 1
    X220                 R50 1
    X221                 OBJ 6.6799999999999997
    X221                 R24 1
    X221                 R34 -1
    X221                 R51 1
    X222                 OBJ 6.6799999999999997
    X222                 R24 -1
    X222                 R34 1
    X222                 R51 1
    X223                 OBJ 7.2199999999999998
    X223                 R29 1
    X223                 R52 -1
    X223                 R53 1
    X224                 OBJ 7.2199999999999998
    X224                 R29 -1
    X224                 R52 1
    X224                 R53 1
    X225                 OBJ 7.7699999999999996
    X225                 R29 1
    X225                 R54 -1
    X225                 R55 1
    X226                 OBJ 7.7699999999999996
    X226                 R29 -1
    X226                 R54 1
    X226                 R55 1
    X227                 OBJ 4.6200000000000001
    X227                 R3 -1
    X227                 R56 1
    X227                 R57 1
    X228                 OBJ 4.6200000000000001
    X228                 R3 1
    X228                 R56 -1
    X228                 R57 1
    X229                 OBJ 6.9000000000000004
    X229                 R7 -1
    X229                 R56 1
    X229                 R58 1
    X230                 OBJ 6.9000000000000004
    X230                 R7 1
    X230                 R56 -1
    X230                 R58 1
    X231                 OBJ 2.75
    X231                 R46 1
    X231                 R59 -1
    X231                 R60 1
    X232                 OBJ 2.75
    X232                 R46 -1
    X232                 R59 1
    X232                 R60 1
    X233                 OBJ 5.9199999999999999
    X233                 R5 -1
    X233                 R59 1
    X233                 R61 1
    X234                 OBJ 5.9199999999999999
    X234                 R5 1
    X234                 R59 -1
    X234                 R61 1
    X235                 OBJ 4.5599999999999996
    X235                 R32 -1
    X235                 R59 1
    X235                 R62 1
    X236                 OBJ 4.5599999999999996
    X236                 R32 1
    X236                 R59 -1
    X236                 R62 1
    X237                 OBJ 2.71
    X237                 R59 1
    X237                 R63 -1
    X237                 R64 1
    X238                 OBJ 2.71
    X238                 R59 -1
    X238                 R63 1
    X238                 R64 1
    X239                 OBJ 11.82
    X239                 R52 -1
    X239                 R65 1
    X239                 R66 1
    X240                 OBJ 11.82
    X240                 R52 1
    X240                 R65 -1
    X240                 R66 1
    X241                 OBJ 5.9699999999999998
    X241                 R54 -1
    X241                 R65 1
    X241                 R67 1
    X242                 OBJ 5.9699999999999998
    X242                 R54 1
    X242                 R65 -1
    X242                 R67 1
    X243                 OBJ 13.699999999999999
    X243                 R36 -1
    X243                 R65 1
    X243                 R68 1
    X244                 OBJ 13.699999999999999
    X244                 R36 1
    X244                 R65 -1
    X244                 R68 1
    X245                 OBJ 3.8300000000000001
    X245                 R36 -1
    X245                 R49 1
    X245                 R69 1
    X246                 OBJ 3.8300000000000001
    X246                 R36 1
    X246                 R49 -1
    X246                 R69 1
    X247                 OBJ 19.77
    X247                 R7 -1
    X247                 R70 1
    X247                 R71 1
    X248                 OBJ 19.77
    X248                 R7 1
    X248                 R70 -1
    X248                 R71 1
    X249                 OBJ 7.5099999999999998
    X249                 R17 -1
    X249                 R70 1
    X249                 R72 1
    X250                 OBJ 7.5099999999999998
    X250                 R17 1
    X250                 R70 -1
    X250                 R72 1
    X251                 OBJ 4.71
    X251                 R21 -1
    X251                 R70 1
    X251                 R73 1
    X252                 OBJ 4.71
    X252                 R21 1
    X252                 R70 -1
    X252                 R73 1
    X253                 OBJ 5.1399999999999997
    X253                 R7 1
    X253                 R44 -1
    X253                 R74 1
    X254                 OBJ 5.1399999999999997
    X254                 R7 -1
    X254                 R44 1
    X254                 R74 1
    X255                 OBJ 4.1100000000000003
    X255                 R19 -1
    X255                 R75 1
    X255                 R76 1
    X256                 OBJ 4.1100000000000003
    X256                 R19 1
    X256                 R75 -1
    X256                 R76 1
    X257                 OBJ 5.9400000000000004
    X257                 R44 -1
    X257                 R75 1
    X257                 R77 1
    X258                 OBJ 5.9400000000000004
    X258                 R44 1
    X258                 R75 -1
    X258                 R77 1
    X259                 OBJ 5.0700000000000003
    X259                 R75 1
    X259                 R78 -1
    X259                 R79 1
    X260                 OBJ 5.0700000000000003
    X260                 R75 -1
    X260                 R78 1
    X260                 R79 1
    X261                 OBJ 9.0700000000000003
    X261                 R19 1
    X261                 R80 -1
    X261                 R81 1
    X262                 OBJ 9.0700000000000003
    X262                 R19 -1
    X262                 R80 1
    X262                 R81 1
    X263                 OBJ 5.2199999999999998
    X263                 R32 -1
    X263                 R82 1
    X263                 R83 1
    X264                 OBJ 5.2199999999999998
    X264                 R32 1
    X264                 R82 -1
    X264                 R83 1
    X265                 OBJ 7.2000000000000002
    X265                 R80 -1
    X265                 R82 1
    X265                 R84 1
    X266                 OBJ 7.2000000000000002
    X266                 R80 1
    X266                 R82 -1
    X266                 R84 1
    X267                 OBJ 3.27
    X267                 R78 -1
    X267                 R82 1
    X267                 R85 1
    X268                 OBJ 3.27
    X268                 R78 1
    X268                 R82 -1
    X268                 R85 1
    X269                 OBJ 5.3399999999999999
    X269                 R32 1
    X269                 R86 -1
    X269                 R87 1
    X270                 OBJ 5.3399999999999999
    X270                 R32 -1
    X270                 R86 1
    X270                 R87 1
    X271                 OBJ 6.3799999999999999
    X271                 R10 1
    X271                 R80 -1
    X271                 R88 1
    X272                 OBJ 6.3799999999999999
    X272                 R10 -1
    X272                 R80 1
    X272                 R88 1
    X273                 OBJ 6
    X273                 R44 1
    X273                 R63 -1
    X273                 R89 1
    X274                 OBJ 6
    X274                 R44 -1
    X274                 R63 1
    X274                 R89 1
    X275                 OBJ 3.7599999999999998
    X275                 R34 1
    X275                 R86 -1
    X275                 R90 1
    X276                 OBJ 3.7599999999999998
    X276                 R34 -1
    X276                 R86 1
    X276                 R90 1
    X277                 OBJ 7.8300000000000001
    X277                 R14 -1
    X277                 R80 1
    X277                 R91 1
    X278                 OBJ 7.8300000000000001
    X278                 R14 1
    X278                 R80 -1
    X278                 R91 1
    X279                 OBJ 2.1800000000000002
    X279                 R63 1
    X279                 R78 -1
    X279                 R92 1
    X280                 OBJ 2.1800000000000002
    X280                 R63 -1
    X280                 R78 1
    X280                 R92 1
    X281                 OBJ 4
    X281                 R14 -1
    X281                 R86 1
    X281                 R93 1
    X282                 OBJ 4
    X282                 R14 1
    X282                 R86 -1
    X282                 R93 1
    X283                 OBJ 2.5899999999999999
    X283                 R2 1
    X283                 R94 1
    X283                 R95 -1
    X284                 OBJ 2.5899999999999999
    X284                 R2 1
    X284                 R94 -1
    X284                 R95 1
    X285                 OBJ 10.67
    X285                 R4 1
    X285                 R94 1
    X285                 R96 -1
    X286                 OBJ 10.67
    X286                 R4 1
    X286                 R94 -1
    X286                 R96 1
    X287                 OBJ 5.5199999999999996
    X287                 R6 1
    X287                 R94 1
    X287                 R97 -1
    X288                 OBJ 5.5199999999999996
    X288                 R6 1
    X288                 R94 -1
    X288                 R97 1
    X289                 OBJ 5.4000000000000004
    X289                 R8 1
    X289                 R94 1
    X289                 R98 -1
    X290                 OBJ 5.4000000000000004
    X290                 R8 1
    X290                 R94 -1
    X290                 R98 1
    X291                 OBJ 13.630000000000001
    X291                 R11 1
    X291                 R99 1
    X291                 R100 -1
    X292                 OBJ 13.630000000000001
    X292                 R11 1
    X292                 R99 -1
    X292                 R100 1
    X293                 OBJ 7.9400000000000004
    X293                 R13 1
    X293                 R99 1
    X293                 R101 -1
    X294                 OBJ 7.9400000000000004
    X294                 R13 1
    X294                 R99 -1
    X294                 R101 1
    X295                 OBJ 15
    X295                 R15 1
    X295                 R99 1
    X295                 R102 -1
    X296                 OBJ 15
    X296                 R15 1
    X296                 R99 -1
    X296                 R102 1
    X297                 OBJ 7.5999999999999996
    X297                 R18 1
    X297                 R103 1
    X297                 R104 -1
    X298                 OBJ 7.5999999999999996
    X298                 R18 1
    X298                 R103 -1
    X298                 R104 1
    X299                 OBJ 5.0800000000000001
    X299                 R20 1
    X299                 R103 1
    X299                 R105 -1
    X300                 OBJ 5.0800000000000001
    X300                 R20 1
    X300                 R103 -1
    X300                 R105 1
    X301                 OBJ 12.44
    X301                 R22 1
    X301                 R103 1
    X301                 R106 -1
    X302                 OBJ 12.44
    X302                 R22 1
    X302                 R103 -1
    X302                 R106 1
    X303                 OBJ 4.7400000000000002
    X303                 R25 1
    X303                 R107 1
    X303                 R108 -1
    X304                 OBJ 4.7400000000000002
    X304                 R25 1
    X304                 R107 -1
    X304                 R108 1
    X305                 OBJ 4.8700000000000001
    X305                 R26 1
    X305                 R101 -1
    X305                 R107 1
    X306                 OBJ 4.8700000000000001
    X306                 R26 1
    X306                 R101 1
    X306                 R107 -1
    X307                 OBJ 5.5099999999999998
    X307                 R27 1
    X307                 R102 -1
    X307                 R107 1
    X308                 OBJ 5.5099999999999998
    X308                 R27 1
    X308                 R102 1
    X308                 R107 -1
    X309                 OBJ 5.4000000000000004
    X309                 R30 1
    X309                 R109 1
    X309                 R110 -1
    X310                 OBJ 3.8100000000000001
    X310                 R31 1
    X310                 R97 -1
    X310                 R109 1
    X311                 OBJ 7.5700000000000003
    X311                 R33 1
    X311                 R109 1
    X311                 R111 -1
    X312                 OBJ 4.2000000000000002
    X312                 R35 1
    X312                 R109 1
    X312                 R112 -1
    X313                 OBJ 7.75
    X313                 R37 1
    X313                 R109 1
    X313                 R113 -1
    X314                 OBJ 6.0999999999999996
    X314                 R39 1
    X314                 R96 -1
    X314                 R114 1
    X315                 OBJ 6.0999999999999996
    X315                 R39 1
    X315                 R96 1
    X315                 R114 -1
    X316                 OBJ 2.3900000000000001
    X316                 R40 1
    X316                 R98 -1
    X316                 R114 1
    X317                 OBJ 2.3900000000000001
    X317                 R40 1
    X317                 R98 1
    X317                 R114 -1
    X318                 OBJ 8.3399999999999999
    X318                 R42 1
    X318                 R104 -1
    X318                 R115 1
    X319                 OBJ 8.3399999999999999
    X319                 R42 1
    X319                 R104 1
    X319                 R115 -1
    X320                 OBJ 7.5599999999999996
    X320                 R43 1
    X320                 R105 -1
    X320                 R115 1
    X321                 OBJ 7.5599999999999996
    X321                 R43 1
    X321                 R105 1
    X321                 R115 -1
    X322                 OBJ 7.4699999999999998
    X322                 R45 1
    X322                 R115 1
    X322                 R116 -1
    X323                 OBJ 7.4699999999999998
    X323                 R45 1
    X323                 R115 -1
    X323                 R116 1
    X324                 OBJ 2.6400000000000001
    X324                 R47 1
    X324                 R95 1
    X324                 R117 -1
    X325                 OBJ 2.6400000000000001
    X325                 R47 1
    X325                 R95 -1
    X325                 R117 1
    X326                 OBJ 3.9300000000000002
    X326                 R48 1
    X326                 R95 1
    X326                 R116 -1
    X327                 OBJ 3.9300000000000002
    X327                 R48 1
    X327                 R95 -1
    X327                 R116 1
    X328                 OBJ 4.3600000000000003
    X328                 R50 1
    X328                 R108 1
    X328                 R118 -1
    X329                 OBJ 4.3600000000000003
    X329                 R50 1
    X329                 R108 -1
    X329                 R118 1
    X330                 OBJ 6.6799999999999997
    X330                 R51 1
    X330                 R108 1
    X330                 R112 -1
    X331                 OBJ 6.6799999999999997
    X331                 R51 1
    X331                 R108 -1
    X331                 R112 1
    X332                 OBJ 7.2199999999999998
    X332                 R53 1
    X332                 R110 1
    X332                 R119 -1
    X333                 OBJ 7.2199999999999998
    X333                 R53 1
    X333                 R110 -1
    X333                 R119 1
    X334                 OBJ 7.7699999999999996
    X334                 R55 1
    X334                 R110 1
    X334                 R120 -1
    X335                 OBJ 7.7699999999999996
    X335                 R55 1
    X335                 R110 -1
    X335                 R120 1
    X336                 OBJ 4.6200000000000001
    X336                 R57 1
    X336                 R96 -1
    X336                 R121 1
    X337                 OBJ 4.6200000000000001
    X337                 R57 1
    X337                 R96 1
    X337                 R121 -1
    X338                 OBJ 6.9000000000000004
    X338                 R58 1
    X338                 R98 -1
    X338                 R121 1
    X339                 OBJ 6.9000000000000004
    X339                 R58 1
    X339                 R98 1
    X339                 R121 -1
    X340                 OBJ 2.75
    X340                 R60 1
    X340                 R117 1
    X340                 R122 -1
    X341                 OBJ 2.75
    X341                 R60 1
    X341                 R117 -1
    X341                 R122 1
    X342                 OBJ 5.9199999999999999
    X342                 R61 1
    X342                 R97 -1
    X342                 R122 1
    X343                 OBJ 5.9199999999999999
    X343                 R61 1
    X343                 R97 1
    X343                 R122 -1
    X344                 OBJ 4.5599999999999996
    X344                 R62 1
    X344                 R111 -1
    X344                 R122 1
    X345                 OBJ 4.5599999999999996
    X345                 R62 1
    X345                 R111 1
    X345                 R122 -1
    X346                 OBJ 2.71
    X346                 R64 1
    X346                 R122 1
    X346                 R123 -1
    X347                 OBJ 2.71
    X347                 R64 1
    X347                 R122 -1
    X347                 R123 1
    X348                 OBJ 11.82
    X348                 R66 1
    X348                 R119 -1
    X348                 R124 1
    X349                 OBJ 11.82
    X349                 R66 1
    X349                 R119 1
    X349                 R124 -1
    X350                 OBJ 5.9699999999999998
    X350                 R67 1
    X350                 R120 -1
    X350                 R124 1
    X351                 OBJ 5.9699999999999998
    X351                 R67 1
    X351                 R120 1
    X351                 R124 -1
    X352                 OBJ 13.699999999999999
    X352                 R68 1
    X352                 R113 -1
    X352                 R124 1
    X353                 OBJ 13.699999999999999
    X353                 R68 1
    X353                 R113 1
    X353                 R124 -1
    X354                 OBJ 3.8300000000000001
    X354                 R69 1
    X354                 R113 -1
    X354                 R118 1
    X355                 OBJ 3.8300000000000001
    X355                 R69 1
    X355                 R113 1
    X355                 R118 -1
    X356                 OBJ 19.77
    X356                 R71 1
    X356                 R98 -1
    X356                 R125 1
    X357                 OBJ 19.77
    X357                 R71 1
    X357                 R98 1
    X357                 R125 -1
    X358                 OBJ 7.5099999999999998
    X358                 R72 1
    X358                 R104 -1
    X358                 R125 1
    X359                 OBJ 7.5099999999999998
    X359                 R72 1
    X359                 R104 1
    X359                 R125 -1
    X360                 OBJ 4.71
    X360                 R73 1
    X360                 R106 -1
    X360                 R125 1
    X361                 OBJ 4.71
    X361                 R73 1
    X361                 R106 1
    X361                 R125 -1
    X362                 OBJ 5.1399999999999997
    X362                 R74 1
    X362                 R98 1
    X362                 R116 -1
    X363                 OBJ 5.1399999999999997
    X363                 R74 1
    X363                 R98 -1
    X363                 R116 1
    X364                 OBJ 4.1100000000000003
    X364                 R76 1
    X364                 R105 -1
    X364                 R126 1
    X365                 OBJ 4.1100000000000003
    X365                 R76 1
    X365                 R105 1
    X365                 R126 -1
    X366                 OBJ 5.9400000000000004
    X366                 R77 1
    X366                 R116 -1
    X366                 R126 1
    X367                 OBJ 5.9400000000000004
    X367                 R77 1
    X367                 R116 1
    X367                 R126 -1
    X368                 OBJ 5.0700000000000003
    X368                 R79 1
    X368                 R126 1
    X368                 R127 -1
    X369                 OBJ 5.0700000000000003
    X369                 R79 1
    X369                 R126 -1
    X369                 R127 1
    X370                 OBJ 9.0700000000000003
    X370                 R81 1
    X370                 R105 1
    X370                 R128 -1
    X371                 OBJ 9.0700000000000003
    X371                 R81 1
    X371                 R105 -1
    X371                 R128 1
    X372                 OBJ 5.2199999999999998
    X372                 R83 1
    X372                 R111 -1
    X372                 R129 1
    X373                 OBJ 5.2199999999999998
    X373                 R83 1
    X373                 R111 1
    X373                 R129 -1
    X374                 OBJ 7.2000000000000002
    X374                 R84 1
    X374                 R128 -1
    X374                 R129 1
    X375                 OBJ 7.2000000000000002
    X375                 R84 1
    X375                 R128 1
    X375                 R129 -1
    X376                 OBJ 3.27
    X376                 R85 1
    X376                 R127 -1
    X376                 R129 1
    X377                 OBJ 3.27
    X377                 R85 1
    X377                 R127 1
    X377                 R129 -1
    X378                 OBJ 5.3399999999999999
    X378                 R87 1
    X378                 R111 1
    X378                 R130 -1
    X379                 OBJ 5.3399999999999999
    X379                 R87 1
    X379                 R111 -1
    X379                 R130 1
    X380                 OBJ 6.3799999999999999
    X380                 R88 1
    X380                 R100 1
    X380                 R128 -1
    X381                 OBJ 6.3799999999999999
    X381                 R88 1
    X381                 R100 -1
    X381                 R128 1
    X382                 OBJ 6
    X382                 R89 1
    X382                 R116 1
    X382                 R123 -1
    X383                 OBJ 6
    X383                 R89 1
    X383                 R116 -1
    X383                 R123 1
    X384                 OBJ 3.7599999999999998
    X384                 R90 1
    X384                 R112 1
    X384                 R130 -1
    X385                 OBJ 3.7599999999999998
    X385                 R90 1
    X385                 R112 -1
    X385                 R130 1
    X386                 OBJ 7.8300000000000001
    X386                 R91 1
    X386                 R102 -1
    X386                 R128 1
    X387                 OBJ 7.8300000000000001
    X387                 R91 1
    X387                 R102 1
    X387                 R128 -1
    X388                 OBJ 2.1800000000000002
    X388                 R92 1
    X388                 R123 1
    X388                 R127 -1
    X389                 OBJ 2.1800000000000002
    X389                 R92 1
    X389                 R123 -1
    X389                 R127 1
    X390                 OBJ 4
    X390                 R93 1
    X390                 R102 -1
    X390                 R130 1
    X391                 OBJ 4
    X391                 R93 1
    X391                 R102 1
    X391                 R130 -1
    X392                 OBJ 2.5899999999999999
    X392                 R2 1
    X392                 R131 1
    X392                 R132 -1
    X393                 OBJ 10.67
    X393                 R4 1
    X393                 R131 1
    X393                 R133 -1
    X394                 OBJ 5.5199999999999996
    X394                 R6 1
    X394                 R131 1
    X394                 R134 -1
    X395                 OBJ 5.4000000000000004
    X395                 R8 1
    X395                 R131 1
    X395                 R135 -1
    X396                 OBJ 13.630000000000001
    X396                 R11 1
    X396                 R136 1
    X396                 R137 -1
    X397                 OBJ 13.630000000000001
    X397                 R11 1
    X397                 R136 -1
    X397                 R137 1
    X398                 OBJ 7.9400000000000004
    X398                 R13 1
    X398                 R136 1
    X398                 R138 -1
    X399                 OBJ 7.9400000000000004
    X399                 R13 1
    X399                 R136 -1
    X399                 R138 1
    X400                 OBJ 15
    X400                 R15 1
    X400                 R136 1
    X400                 R139 -1
    X401                 OBJ 15
    X401                 R15 1
    X401                 R136 -1
    X401                 R139 1
    X402                 OBJ 7.5999999999999996
    X402                 R18 1
    X402                 R140 1
    X402                 R141 -1
    X403                 OBJ 7.5999999999999996
    X403                 R18 1
    X403                 R140 -1
    X403                 R141 1
    X404                 OBJ 5.0800000000000001
    X404                 R20 1
    X404                 R140 1
    X404                 R142 -1
    X405                 OBJ 5.0800000000000001
    X405                 R20 1
    X405                 R140 -1
    X405                 R142 1
    X406                 OBJ 12.44
    X406                 R22 1
    X406                 R140 1
    X406                 R143 -1
    X407                 OBJ 12.44
    X407                 R22 1
    X407                 R140 -1
    X407                 R143 1
    X408                 OBJ 4.7400000000000002
    X408                 R25 1
    X408                 R144 1
    X408                 R145 -1
    X409                 OBJ 4.7400000000000002
    X409                 R25 1
    X409                 R144 -1
    X409                 R145 1
    X410                 OBJ 4.8700000000000001
    X410                 R26 1
    X410                 R138 -1
    X410                 R144 1
    X411                 OBJ 4.8700000000000001
    X411                 R26 1
    X411                 R138 1
    X411                 R144 -1
    X412                 OBJ 5.5099999999999998
    X412                 R27 1
    X412                 R139 -1
    X412                 R144 1
    X413                 OBJ 5.5099999999999998
    X413                 R27 1
    X413                 R139 1
    X413                 R144 -1
    X414                 OBJ 5.4000000000000004
    X414                 R30 1
    X414                 R146 1
    X414                 R147 -1
    X415                 OBJ 5.4000000000000004
    X415                 R30 1
    X415                 R146 -1
    X415                 R147 1
    X416                 OBJ 3.8100000000000001
    X416                 R31 1
    X416                 R134 -1
    X416                 R146 1
    X417                 OBJ 3.8100000000000001
    X417                 R31 1
    X417                 R134 1
    X417                 R146 -1
    X418                 OBJ 7.5700000000000003
    X418                 R33 1
    X418                 R146 1
    X418                 R148 -1
    X419                 OBJ 7.5700000000000003
    X419                 R33 1
    X419                 R146 -1
    X419                 R148 1
    X420                 OBJ 4.2000000000000002
    X420                 R35 1
    X420                 R146 1
    X420                 R149 -1
    X421                 OBJ 4.2000000000000002
    X421                 R35 1
    X421                 R146 -1
    X421                 R149 1
    X422                 OBJ 7.75
    X422                 R37 1
    X422                 R146 1
    X422                 R150 -1
    X423                 OBJ 7.75
    X423                 R37 1
    X423                 R146 -1
    X423                 R150 1
    X424                 OBJ 6.0999999999999996
    X424                 R39 1
    X424                 R133 -1
    X424                 R151 1
    X425                 OBJ 6.0999999999999996
    X425                 R39 1
    X425                 R133 1
    X425                 R151 -1
    X426                 OBJ 2.3900000000000001
    X426                 R40 1
    X426                 R135 -1
    X426                 R151 1
    X427                 OBJ 2.3900000000000001
    X427                 R40 1
    X427                 R135 1
    X427                 R151 -1
    X428                 OBJ 8.3399999999999999
    X428                 R42 1
    X428                 R141 -1
    X428                 R152 1
    X429                 OBJ 8.3399999999999999
    X429                 R42 1
    X429                 R141 1
    X429                 R152 -1
    X430                 OBJ 7.5599999999999996
    X430                 R43 1
    X430                 R142 -1
    X430                 R152 1
    X431                 OBJ 7.5599999999999996
    X431                 R43 1
    X431                 R142 1
    X431                 R152 -1
    X432                 OBJ 7.4699999999999998
    X432                 R45 1
    X432                 R152 1
    X432                 R153 -1
    X433                 OBJ 7.4699999999999998
    X433                 R45 1
    X433                 R152 -1
    X433                 R153 1
    X434                 OBJ 2.6400000000000001
    X434                 R47 1
    X434                 R132 1
    X434                 R154 -1
    X435                 OBJ 2.6400000000000001
    X435                 R47 1
    X435                 R132 -1
    X435                 R154 1
    X436                 OBJ 3.9300000000000002
    X436                 R48 1
    X436                 R132 1
    X436                 R153 -1
    X437                 OBJ 3.9300000000000002
    X437                 R48 1
    X437                 R132 -1
    X437                 R153 1
    X438                 OBJ 4.3600000000000003
    X438                 R50 1
    X438                 R145 1
    X438                 R155 -1
    X439                 OBJ 4.3600000000000003
    X439                 R50 1
    X439                 R145 -1
    X439                 R155 1
    X440                 OBJ 6.6799999999999997
    X440                 R51 1
    X440                 R145 1
    X440                 R149 -1
    X441                 OBJ 6.6799999999999997
    X441                 R51 1
    X441                 R145 -1
    X441                 R149 1
    X442                 OBJ 7.2199999999999998
    X442                 R53 1
    X442                 R147 1
    X442                 R156 -1
    X443                 OBJ 7.2199999999999998
    X443                 R53 1
    X443                 R147 -1
    X443                 R156 1
    X444                 OBJ 7.7699999999999996
    X444                 R55 1
    X444                 R147 1
    X444                 R157 -1
    X445                 OBJ 7.7699999999999996
    X445                 R55 1
    X445                 R147 -1
    X445                 R157 1
    X446                 OBJ 4.6200000000000001
    X446                 R57 1
    X446                 R133 -1
    X446                 R158 1
    X447                 OBJ 4.6200000000000001
    X447                 R57 1
    X447                 R133 1
    X447                 R158 -1
    X448                 OBJ 6.9000000000000004
    X448                 R58 1
    X448                 R135 -1
    X448                 R158 1
    X449                 OBJ 6.9000000000000004
    X449                 R58 1
    X449                 R135 1
    X449                 R158 -1
    X450                 OBJ 2.75
    X450                 R60 1
    X450                 R154 1
    X450                 R159 -1
    X451                 OBJ 2.75
    X451                 R60 1
    X451                 R154 -1
    X451                 R159 1
    X452                 OBJ 5.9199999999999999
    X452                 R61 1
    X452                 R134 -1
    X452                 R159 1
    X453                 OBJ 5.9199999999999999
    X453                 R61 1
    X453                 R134 1
    X453                 R159 -1
    X454                 OBJ 4.5599999999999996
    X454                 R62 1
    X454                 R148 -1
    X454                 R159 1
    X455                 OBJ 4.5599999999999996
    X455                 R62 1
    X455                 R148 1
    X455                 R159 -1
    X456                 OBJ 2.71
    X456                 R64 1
    X456                 R159 1
    X456                 R160 -1
    X457                 OBJ 2.71
    X457                 R64 1
    X457                 R159 -1
    X457                 R160 1
    X458                 OBJ 11.82
    X458                 R66 1
    X458                 R156 -1
    X458                 R161 1
    X459                 OBJ 11.82
    X459                 R66 1
    X459                 R156 1
    X459                 R161 -1
    X460                 OBJ 5.9699999999999998
    X460                 R67 1
    X460                 R157 -1
    X460                 R161 1
    X461                 OBJ 5.9699999999999998
    X461                 R67 1
    X461                 R157 1
    X461                 R161 -1
    X462                 OBJ 13.699999999999999
    X462                 R68 1
    X462                 R150 -1
    X462                 R161 1
    X463                 OBJ 13.699999999999999
    X463                 R68 1
    X463                 R150 1
    X463                 R161 -1
    X464                 OBJ 3.8300000000000001
    X464                 R69 1
    X464                 R150 -1
    X464                 R155 1
    X465                 OBJ 3.8300000000000001
    X465                 R69 1
    X465                 R150 1
    X465                 R155 -1
    X466                 OBJ 19.77
    X466                 R71 1
    X466                 R135 -1
    X466                 R162 1
    X467                 OBJ 19.77
    X467                 R71 1
    X467                 R135 1
    X467                 R162 -1
    X468                 OBJ 7.5099999999999998
    X468                 R72 1
    X468                 R141 -1
    X468                 R162 1
    X469                 OBJ 7.5099999999999998
    X469                 R72 1
    X469                 R141 1
    X469                 R162 -1
    X470                 OBJ 4.71
    X470                 R73 1
    X470                 R143 -1
    X470                 R162 1
    X471                 OBJ 4.71
    X471                 R73 1
    X471                 R143 1
    X471                 R162 -1
    X472                 OBJ 5.1399999999999997
    X472                 R74 1
    X472                 R135 1
    X472                 R153 -1
    X473                 OBJ 5.1399999999999997
    X473                 R74 1
    X473                 R135 -1
    X473                 R153 1
    X474                 OBJ 4.1100000000000003
    X474                 R76 1
    X474                 R142 -1
    X474                 R163 1
    X475                 OBJ 4.1100000000000003
    X475                 R76 1
    X475                 R142 1
    X475                 R163 -1
    X476                 OBJ 5.9400000000000004
    X476                 R77 1
    X476                 R153 -1
    X476                 R163 1
    X477                 OBJ 5.9400000000000004
    X477                 R77 1
    X477                 R153 1
    X477                 R163 -1
    X478                 OBJ 5.0700000000000003
    X478                 R79 1
    X478                 R163 1
    X478                 R164 -1
    X479                 OBJ 5.0700000000000003
    X479                 R79 1
    X479                 R163 -1
    X479                 R164 1
    X480                 OBJ 9.0700000000000003
    X480                 R81 1
    X480                 R142 1
    X480                 R165 -1
    X481                 OBJ 9.0700000000000003
    X481                 R81 1
    X481                 R142 -1
    X481                 R165 1
    X482                 OBJ 5.2199999999999998
    X482                 R83 1
    X482                 R148 -1
    X482                 R166 1
    X483                 OBJ 5.2199999999999998
    X483                 R83 1
    X483                 R148 1
    X483                 R166 -1
    X484                 OBJ 7.2000000000000002
    X484                 R84 1
    X484                 R165 -1
    X484                 R166 1
    X485                 OBJ 7.2000000000000002
    X485                 R84 1
    X485                 R165 1
    X485                 R166 -1
    X486                 OBJ 3.27
    X486                 R85 1
    X486                 R164 -1
    X486                 R166 1
    X487                 OBJ 3.27
    X487                 R85 1
    X487                 R164 1
    X487                 R166 -1
    X488                 OBJ 5.3399999999999999
    X488                 R87 1
    X488                 R148 1
    X488                 R167 -1
    X489                 OBJ 5.3399999999999999
    X489                 R87 1
    X489                 R148 -1
    X489                 R167 1
    X490                 OBJ 6.3799999999999999
    X490                 R88 1
    X490                 R137 1
    X490                 R165 -1
    X491                 OBJ 6.3799999999999999
    X491                 R88 1
    X491                 R137 -1
    X491                 R165 1
    X492                 OBJ 6
    X492                 R89 1
    X492                 R153 1
    X492                 R160 -1
    X493                 OBJ 6
    X493                 R89 1
    X493                 R153 -1
    X493                 R160 1
    X494                 OBJ 3.7599999999999998
    X494                 R90 1
    X494                 R149 1
    X494                 R167 -1
    X495                 OBJ 3.7599999999999998
    X495                 R90 1
    X495                 R149 -1
    X495                 R167 1
    X496                 OBJ 7.8300000000000001
    X496                 R91 1
    X496                 R139 -1
    X496                 R165 1
    X497                 OBJ 7.8300000000000001
    X497                 R91 1
    X497                 R139 1
    X497                 R165 -1
    X498                 OBJ 2.1800000000000002
    X498                 R92 1
    X498                 R160 1
    X498                 R164 -1
    X499                 OBJ 2.1800000000000002
    X499                 R92 1
    X499                 R160 -1
    X499                 R164 1
    X500                 OBJ 4
    X500                 R93 1
    X500                 R139 -1
    X500                 R167 1
    X501                 OBJ 4
    X501                 R93 1
    X501                 R139 1
    X501                 R167 -1
    X502                 OBJ 2.5899999999999999
    X502                 R2 1
    X502                 R168 1
    X502                 R169 -1
    X503                 OBJ 2.5899999999999999
    X503                 R2 1
    X503                 R168 -1
    X503                 R169 1
    X504                 OBJ 10.67
    X504                 R4 1
    X504                 R168 1
    X504                 R170 -1
    X505                 OBJ 10.67
    X505                 R4 1
    X505                 R168 -1
    X505                 R170 1
    X506                 OBJ 5.5199999999999996
    X506                 R6 1
    X506                 R168 1
    X506                 R171 -1
    X507                 OBJ 5.5199999999999996
    X507                 R6 1
    X507                 R168 -1
    X507                 R171 1
    X508                 OBJ 5.4000000000000004
    X508                 R8 1
    X508                 R168 1
    X508                 R172 -1
    X509                 OBJ 5.4000000000000004
    X509                 R8 1
    X509                 R168 -1
    X509                 R172 1
    X510                 OBJ 13.630000000000001
    X510                 R11 1
    X510                 R173 1
    X510                 R174 -1
    X511                 OBJ 13.630000000000001
    X511                 R11 1
    X511                 R173 -1
    X511                 R174 1
    X512                 OBJ 7.9400000000000004
    X512                 R13 1
    X512                 R173 1
    X512                 R175 -1
    X513                 OBJ 7.9400000000000004
    X513                 R13 1
    X513                 R173 -1
    X513                 R175 1
    X514                 OBJ 15
    X514                 R15 1
    X514                 R173 1
    X514                 R176 -1
    X515                 OBJ 15
    X515                 R15 1
    X515                 R173 -1
    X515                 R176 1
    X516                 OBJ 7.5999999999999996
    X516                 R18 1
    X516                 R177 1
    X516                 R178 -1
    X517                 OBJ 7.5999999999999996
    X517                 R18 1
    X517                 R177 -1
    X517                 R178 1
    X518                 OBJ 5.0800000000000001
    X518                 R20 1
    X518                 R177 1
    X518                 R179 -1
    X519                 OBJ 5.0800000000000001
    X519                 R20 1
    X519                 R177 -1
    X519                 R179 1
    X520                 OBJ 12.44
    X520                 R22 1
    X520                 R177 1
    X520                 R180 -1
    X521                 OBJ 12.44
    X521                 R22 1
    X521                 R177 -1
    X521                 R180 1
    X522                 OBJ 4.7400000000000002
    X522                 R25 1
    X522                 R181 1
    X522                 R182 -1
    X523                 OBJ 4.7400000000000002
    X523                 R25 1
    X523                 R181 -1
    X523                 R182 1
    X524                 OBJ 4.8700000000000001
    X524                 R26 1
    X524                 R175 -1
    X524                 R181 1
    X525                 OBJ 4.8700000000000001
    X525                 R26 1
    X525                 R175 1
    X525                 R181 -1
    X526                 OBJ 5.5099999999999998
    X526                 R27 1
    X526                 R176 -1
    X526                 R181 1
    X527                 OBJ 5.5099999999999998
    X527                 R27 1
    X527                 R176 1
    X527                 R181 -1
    X528                 OBJ 5.4000000000000004
    X528                 R30 1
    X528                 R183 1
    X528                 R184 -1
    X529                 OBJ 5.4000000000000004
    X529                 R30 1
    X529                 R183 -1
    X529                 R184 1
    X530                 OBJ 3.8100000000000001
    X530                 R31 1
    X530                 R171 -1
    X530                 R183 1
    X531                 OBJ 3.8100000000000001
    X531                 R31 1
    X531                 R171 1
    X531                 R183 -1
    X532                 OBJ 7.5700000000000003
    X532                 R33 1
    X532                 R183 1
    X532                 R185 -1
    X533                 OBJ 7.5700000000000003
    X533                 R33 1
    X533                 R183 -1
    X533                 R185 1
    X534                 OBJ 4.2000000000000002
    X534                 R35 1
    X534                 R183 1
    X534                 R186 -1
    X535                 OBJ 4.2000000000000002
    X535                 R35 1
    X535                 R183 -1
    X535                 R186 1
    X536                 OBJ 7.75
    X536                 R37 1
    X536                 R183 1
    X536                 R187 -1
    X537                 OBJ 7.75
    X537                 R37 1
    X537                 R183 -1
    X537                 R187 1
    X538                 OBJ 6.0999999999999996
    X538                 R39 1
    X538                 R170 -1
    X538                 R188 1
    X539                 OBJ 6.0999999999999996
    X539                 R39 1
    X539                 R170 1
    X539                 R188 -1
    X540                 OBJ 2.3900000000000001
    X540                 R40 1
    X540                 R172 -1
    X540                 R188 1
    X541                 OBJ 2.3900000000000001
    X541                 R40 1
    X541                 R172 1
    X541                 R188 -1
    X542                 OBJ 8.3399999999999999
    X542                 R42 1
    X542                 R178 -1
    X542                 R189 1
    X543                 OBJ 8.3399999999999999
    X543                 R42 1
    X543                 R178 1
    X543                 R189 -1
    X544                 OBJ 7.5599999999999996
    X544                 R43 1
    X544                 R179 -1
    X544                 R189 1
    X545                 OBJ 7.5599999999999996
    X545                 R43 1
    X545                 R179 1
    X545                 R189 -1
    X546                 OBJ 7.4699999999999998
    X546                 R45 1
    X546                 R189 1
    X546                 R190 -1
    X547                 OBJ 7.4699999999999998
    X547                 R45 1
    X547                 R189 -1
    X547                 R190 1
    X548                 OBJ 2.6400000000000001
    X548                 R47 1
    X548                 R169 1
    X548                 R191 -1
    X549                 OBJ 2.6400000000000001
    X549                 R47 1
    X549                 R169 -1
    X549                 R191 1
    X550                 OBJ 3.9300000000000002
    X550                 R48 1
    X550                 R169 1
    X550                 R190 -1
    X551                 OBJ 3.9300000000000002
    X551                 R48 1
    X551                 R169 -1
    X551                 R190 1
    X552                 OBJ 4.3600000000000003
    X552                 R50 1
    X552                 R182 -1
    X552                 R192 1
    X553                 OBJ 6.6799999999999997
    X553                 R51 1
    X553                 R182 1
    X553                 R186 -1
    X554                 OBJ 6.6799999999999997
    X554                 R51 1
    X554                 R182 -1
    X554                 R186 1
    X555                 OBJ 7.2199999999999998
    X555                 R53 1
    X555                 R184 1
    X555                 R193 -1
    X556                 OBJ 7.2199999999999998
    X556                 R53 1
    X556                 R184 -1
    X556                 R193 1
    X557                 OBJ 7.7699999999999996
    X557                 R55 1
    X557                 R184 1
    X557                 R194 -1
    X558                 OBJ 7.7699999999999996
    X558                 R55 1
    X558                 R184 -1
    X558                 R194 1
    X559                 OBJ 4.6200000000000001
    X559                 R57 1
    X559                 R170 -1
    X559                 R195 1
    X560                 OBJ 4.6200000000000001
    X560                 R57 1
    X560                 R170 1
    X560                 R195 -1
    X561                 OBJ 6.9000000000000004
    X561                 R58 1
    X561                 R172 -1
    X561                 R195 1
    X562                 OBJ 6.9000000000000004
    X562                 R58 1
    X562                 R172 1
    X562                 R195 -1
    X563                 OBJ 2.75
    X563                 R60 1
    X563                 R191 1
    X563                 R196 -1
    X564                 OBJ 2.75
    X564                 R60 1
    X564                 R191 -1
    X564                 R196 1
    X565                 OBJ 5.9199999999999999
    X565                 R61 1
    X565                 R171 -1
    X565                 R196 1
    X566                 OBJ 5.9199999999999999
    X566                 R61 1
    X566                 R171 1
    X566                 R196 -1
    X567                 OBJ 4.5599999999999996
    X567                 R62 1
    X567                 R185 -1
    X567                 R196 1
    X568                 OBJ 4.5599999999999996
    X568                 R62 1
    X568                 R185 1
    X568                 R196 -1
    X569                 OBJ 2.71
    X569                 R64 1
    X569                 R196 1
    X569                 R197 -1
    X570                 OBJ 2.71
    X570                 R64 1
    X570                 R196 -1
    X570                 R197 1
    X571                 OBJ 11.82
    X571                 R66 1
    X571                 R193 -1
    X571                 R198 1
    X572                 OBJ 11.82
    X572                 R66 1
    X572                 R193 1
    X572                 R198 -1
    X573                 OBJ 5.9699999999999998
    X573                 R67 1
    X573                 R194 -1
    X573                 R198 1
    X574                 OBJ 5.9699999999999998
    X574                 R67 1
    X574                 R194 1
    X574                 R198 -1
    X575                 OBJ 13.699999999999999
    X575                 R68 1
    X575                 R187 -1
    X575                 R198 1
    X576                 OBJ 13.699999999999999
    X576                 R68 1
    X576                 R187 1
    X576                 R198 -1
    X577                 OBJ 3.8300000000000001
    X577                 R69 1
    X577                 R187 -1
    X577                 R192 1
    X578                 OBJ 19.77
    X578                 R71 1
    X578                 R172 -1
    X578                 R199 1
    X579                 OBJ 19.77
    X579                 R71 1
    X579                 R172 1
    X579                 R199 -1
    X580                 OBJ 7.5099999999999998
    X580                 R72 1
    X580                 R178 -1
    X580                 R199 1
    X581                 OBJ 7.5099999999999998
    X581                 R72 1
    X581                 R178 1
    X581                 R199 -1
    X582                 OBJ 4.71
    X582                 R73 1
    X582                 R180 -1
    X582                 R199 1
    X583                 OBJ 4.71
    X583                 R73 1
    X583                 R180 1
    X583                 R199 -1
    X584                 OBJ 5.1399999999999997
    X584                 R74 1
    X584                 R172 1
    X584                 R190 -1
    X585                 OBJ 5.1399999999999997
    X585                 R74 1
    X585                 R172 -1
    X585                 R190 1
    X586                 OBJ 4.1100000000000003
    X586                 R76 1
    X586                 R179 -1
    X586                 R200 1
    X587                 OBJ 4.1100000000000003
    X587                 R76 1
    X587                 R179 1
    X587                 R200 -1
    X588                 OBJ 5.9400000000000004
    X588                 R77 1
    X588                 R190 -1
    X588                 R200 1
    X589                 OBJ 5.9400000000000004
    X589                 R77 1
    X589                 R190 1
    X589                 R200 -1
    X590                 OBJ 5.0700000000000003
    X590                 R79 1
    X590                 R200 1
    X590                 R201 -1
    X591                 OBJ 5.0700000000000003
    X591                 R79 1
    X591                 R200 -1
    X591                 R201 1
    X592                 OBJ 9.0700000000000003
    X592                 R81 1
    X592                 R179 1
    X592                 R202 -1
    X593                 OBJ 9.0700000000000003
    X593                 R81 1
    X593                 R179 -1
    X593                 R202 1
    X594                 OBJ 5.2199999999999998
    X594                 R83 1
    X594                 R185 -1
    X594                 R203 1
    X595                 OBJ 5.2199999999999998
    X595                 R83 1
    X595                 R185 1
    X595                 R203 -1
    X596                 OBJ 7.2000000000000002
    X596                 R84 1
    X596                 R202 -1
    X596                 R203 1
    X597                 OBJ 7.2000000000000002
    X597                 R84 1
    X597                 R202 1
    X597                 R203 -1
    X598                 OBJ 3.27
    X598                 R85 1
    X598                 R201 -1
    X598                 R203 1
    X599                 OBJ 3.27
    X599                 R85 1
    X599                 R201 1
    X599                 R203 -1
    X600                 OBJ 5.3399999999999999
    X600                 R87 1
    X600                 R185 1
    X600                 R204 -1
    X601                 OBJ 5.3399999999999999
    X601                 R87 1
    X601                 R185 -1
    X601                 R204 1
    X602                 OBJ 6.3799999999999999
    X602                 R88 1
    X602                 R174 1
    X602                 R202 -1
    X603                 OBJ 6.3799999999999999
    X603                 R88 1
    X603                 R174 -1
    X603                 R202 1
    X604                 OBJ 6
    X604                 R89 1
    X604                 R190 1
    X604                 R197 -1
    X605                 OBJ 6
    X605                 R89 1
    X605                 R190 -1
    X605                 R197 1
    X606                 OBJ 3.7599999999999998
    X606                 R90 1
    X606                 R186 1
    X606                 R204 -1
    X607                 OBJ 3.7599999999999998
    X607                 R90 1
    X607                 R186 -1
    X607                 R204 1
    X608                 OBJ 7.8300000000000001
    X608                 R91 1
    X608                 R176 -1
    X608                 R202 1
    X609                 OBJ 7.8300000000000001
    X609                 R91 1
    X609                 R176 1
    X609                 R202 -1
    X610                 OBJ 2.1800000000000002
    X610                 R92 1
    X610                 R197 1
    X610                 R201 -1
    X611                 OBJ 2.1800000000000002
    X611                 R92 1
    X611                 R197 -1
    X611                 R201 1
    X612                 OBJ 4
    X612                 R93 1
    X612                 R176 -1
    X612                 R204 1
    X613                 OBJ 4
    X613                 R93 1
    X613                 R176 1
    X613                 R204 -1
    X614                 OBJ 2.5899999999999999
    X614                 R2 1
    X614                 R205 1
    X614                 R206 -1
    X615                 OBJ 2.5899999999999999
    X615                 R2 1
    X615                 R205 -1
    X615                 R206 1
    X616                 OBJ 10.67
    X616                 R4 1
    X616                 R205 -1
    X616                 R207 1
    X617                 OBJ 5.5199999999999996
    X617                 R6 1
    X617                 R205 1
    X617                 R208 -1
    X618                 OBJ 5.5199999999999996
    X618                 R6 1
    X618                 R205 -1
    X618                 R208 1
    X619                 OBJ 5.4000000000000004
    X619                 R8 1
    X619                 R205 1
    X619                 R209 -1
    X620                 OBJ 5.4000000000000004
    X620                 R8 1
    X620                 R205 -1
    X620                 R209 1
    X621                 OBJ 13.630000000000001
    X621                 R11 1
    X621                 R210 1
    X621                 R211 -1
    X622                 OBJ 13.630000000000001
    X622                 R11 1
    X622                 R210 -1
    X622                 R211 1
    X623                 OBJ 7.9400000000000004
    X623                 R13 1
    X623                 R210 1
    X623                 R212 -1
    X624                 OBJ 7.9400000000000004
    X624                 R13 1
    X624                 R210 -1
    X624                 R212 1
    X625                 OBJ 15
    X625                 R15 1
    X625                 R210 1
    X625                 R213 -1
    X626                 OBJ 15
    X626                 R15 1
    X626                 R210 -1
    X626                 R213 1
    X627                 OBJ 7.5999999999999996
    X627                 R18 1
    X627                 R214 1
    X627                 R215 -1
    X628                 OBJ 7.5999999999999996
    X628                 R18 1
    X628                 R214 -1
    X628                 R215 1
    X629                 OBJ 5.0800000000000001
    X629                 R20 1
    X629                 R214 1
    X629                 R216 -1
    X630                 OBJ 5.0800000000000001
    X630                 R20 1
    X630                 R214 -1
    X630                 R216 1
    X631                 OBJ 12.44
    X631                 R22 1
    X631                 R214 1
    X631                 R217 -1
    X632                 OBJ 12.44
    X632                 R22 1
    X632                 R214 -1
    X632                 R217 1
    X633                 OBJ 4.7400000000000002
    X633                 R25 1
    X633                 R218 1
    X633                 R219 -1
    X634                 OBJ 4.7400000000000002
    X634                 R25 1
    X634                 R218 -1
    X634                 R219 1
    X635                 OBJ 4.8700000000000001
    X635                 R26 1
    X635                 R212 -1
    X635                 R218 1
    X636                 OBJ 4.8700000000000001
    X636                 R26 1
    X636                 R212 1
    X636                 R218 -1
    X637                 OBJ 5.5099999999999998
    X637                 R27 1
    X637                 R213 -1
    X637                 R218 1
    X638                 OBJ 5.5099999999999998
    X638                 R27 1
    X638                 R213 1
    X638                 R218 -1
    X639                 OBJ 5.4000000000000004
    X639                 R30 1
    X639                 R220 1
    X639                 R221 -1
    X640                 OBJ 5.4000000000000004
    X640                 R30 1
    X640                 R220 -1
    X640                 R221 1
    X641                 OBJ 3.8100000000000001
    X641                 R31 1
    X641                 R208 -1
    X641                 R220 1
    X642                 OBJ 3.8100000000000001
    X642                 R31 1
    X642                 R208 1
    X642                 R220 -1
    X643                 OBJ 7.5700000000000003
    X643                 R33 1
    X643                 R220 1
    X643                 R222 -1
    X644                 OBJ 7.5700000000000003
    X644                 R33 1
    X644                 R220 -1
    X644                 R222 1
    X645                 OBJ 4.2000000000000002
    X645                 R35 1
    X645                 R220 1
    X645                 R223 -1
    X646                 OBJ 4.2000000000000002
    X646                 R35 1
    X646                 R220 -1
    X646                 R223 1
    X647                 OBJ 7.75
    X647                 R37 1
    X647                 R220 1
    X647                 R224 -1
    X648                 OBJ 7.75
    X648                 R37 1
    X648                 R220 -1
    X648                 R224 1
    X649                 OBJ 6.0999999999999996
    X649                 R39 1
    X649                 R207 1
    X649                 R225 -1
    X650                 OBJ 2.3900000000000001
    X650                 R40 1
    X650                 R209 -1
    X650                 R225 1
    X651                 OBJ 2.3900000000000001
    X651                 R40 1
    X651                 R209 1
    X651                 R225 -1
    X652                 OBJ 8.3399999999999999
    X652                 R42 1
    X652                 R215 -1
    X652                 R226 1
    X653                 OBJ 8.3399999999999999
    X653                 R42 1
    X653                 R215 1
    X653                 R226 -1
    X654                 OBJ 7.5599999999999996
    X654                 R43 1
    X654                 R216 -1
    X654                 R226 1
    X655                 OBJ 7.5599999999999996
    X655                 R43 1
    X655                 R216 1
    X655                 R226 -1
    X656                 OBJ 7.4699999999999998
    X656                 R45 1
    X656                 R226 1
    X656                 R227 -1
    X657                 OBJ 7.4699999999999998
    X657                 R45 1
    X657                 R226 -1
    X657                 R227 1
    X658                 OBJ 2.6400000000000001
    X658                 R47 1
    X658                 R206 1
    X658                 R228 -1
    X659                 OBJ 2.6400000000000001
    X659                 R47 1
    X659                 R206 -1
    X659                 R228 1
    X660                 OBJ 3.9300000000000002
    X660                 R48 1
    X660                 R206 1
    X660                 R227 -1
    X661                 OBJ 3.9300000000000002
    X661                 R48 1
    X661                 R206 -1
    X661                 R227 1
    X662                 OBJ 4.3600000000000003
    X662                 R50 1
    X662                 R219 1
    X662                 R229 -1
    X663                 OBJ 4.3600000000000003
    X663                 R50 1
    X663                 R219 -1
    X663                 R229 1
    X664                 OBJ 6.6799999999999997
    X664                 R51 1
    X664                 R219 1
    X664                 R223 -1
    X665                 OBJ 6.6799999999999997
    X665                 R51 1
    X665                 R219 -1
    X665                 R223 1
    X666                 OBJ 7.2199999999999998
    X666                 R53 1
    X666                 R221 1
    X666                 R230 -1
    X667                 OBJ 7.2199999999999998
    X667                 R53 1
    X667                 R221 -1
    X667                 R230 1
    X668                 OBJ 7.7699999999999996
    X668                 R55 1
    X668                 R221 1
    X668                 R231 -1
    X669                 OBJ 7.7699999999999996
    X669                 R55 1
    X669                 R221 -1
    X669                 R231 1
    X670                 OBJ 4.6200000000000001
    X670                 R57 1
    X670                 R207 1
    X670                 R232 -1
    X671                 OBJ 6.9000000000000004
    X671                 R58 1
    X671                 R209 -1
    X671                 R232 1
    X672                 OBJ 6.9000000000000004
    X672                 R58 1
    X672                 R209 1
    X672                 R232 -1
    X673                 OBJ 2.75
    X673                 R60 1
    X673                 R228 1
    X673                 R233 -1
    X674                 OBJ 2.75
    X674                 R60 1
    X674                 R228 -1
    X674                 R233 1
    X675                 OBJ 5.9199999999999999
    X675                 R61 1
    X675                 R208 -1
    X675                 R233 1
    X676                 OBJ 5.9199999999999999
    X676                 R61 1
    X676                 R208 1
    X676                 R233 -1
    X677                 OBJ 4.5599999999999996
    X677                 R62 1
    X677                 R222 -1
    X677                 R233 1
    X678                 OBJ 4.5599999999999996
    X678                 R62 1
    X678                 R222 1
    X678                 R233 -1
    X679                 OBJ 2.71
    X679                 R64 1
    X679                 R233 1
    X679                 R234 -1
    X680                 OBJ 2.71
    X680                 R64 1
    X680                 R233 -1
    X680                 R234 1
    X681                 OBJ 11.82
    X681                 R66 1
    X681                 R230 -1
    X681                 R235 1
    X682                 OBJ 11.82
    X682                 R66 1
    X682                 R230 1
    X682                 R235 -1
    X683                 OBJ 5.9699999999999998
    X683                 R67 1
    X683                 R231 -1
    X683                 R235 1
    X684                 OBJ 5.9699999999999998
    X684                 R67 1
    X684                 R231 1
    X684                 R235 -1
    X685                 OBJ 13.699999999999999
    X685                 R68 1
    X685                 R224 -1
    X685                 R235 1
    X686                 OBJ 13.699999999999999
    X686                 R68 1
    X686                 R224 1
    X686                 R235 -1
    X687                 OBJ 3.8300000000000001
    X687                 R69 1
    X687                 R224 -1
    X687                 R229 1
    X688                 OBJ 3.8300000000000001
    X688                 R69 1
    X688                 R224 1
    X688                 R229 -1
    X689                 OBJ 19.77
    X689                 R71 1
    X689                 R209 -1
    X689                 R236 1
    X690                 OBJ 19.77
    X690                 R71 1
    X690                 R209 1
    X690                 R236 -1
    X691                 OBJ 7.5099999999999998
    X691                 R72 1
    X691                 R215 -1
    X691                 R236 1
    X692                 OBJ 7.5099999999999998
    X692                 R72 1
    X692                 R215 1
    X692                 R236 -1
    X693                 OBJ 4.71
    X693                 R73 1
    X693                 R217 -1
    X693                 R236 1
    X694                 OBJ 4.71
    X694                 R73 1
    X694                 R217 1
    X694                 R236 -1
    X695                 OBJ 5.1399999999999997
    X695                 R74 1
    X695                 R209 1
    X695                 R227 -1
    X696                 OBJ 5.1399999999999997
    X696                 R74 1
    X696                 R209 -1
    X696                 R227 1
    X697                 OBJ 4.1100000000000003
    X697                 R76 1
    X697                 R216 -1
    X697                 R237 1
    X698                 OBJ 4.1100000000000003
    X698                 R76 1
    X698                 R216 1
    X698                 R237 -1
    X699                 OBJ 5.9400000000000004
    X699                 R77 1
    X699                 R227 -1
    X699                 R237 1
    X700                 OBJ 5.9400000000000004
    X700                 R77 1
    X700                 R227 1
    X700                 R237 -1
    X701                 OBJ 5.0700000000000003
    X701                 R79 1
    X701                 R237 1
    X701                 R238 -1
    X702                 OBJ 5.0700000000000003
    X702                 R79 1
    X702                 R237 -1
    X702                 R238 1
    X703                 OBJ 9.0700000000000003
    X703                 R81 1
    X703                 R216 1
    X703                 R239 -1
    X704                 OBJ 9.0700000000000003
    X704                 R81 1
    X704                 R216 -1
    X704                 R239 1
    X705                 OBJ 5.2199999999999998
    X705                 R83 1
    X705                 R222 -1
    X705                 R240 1
    X706                 OBJ 5.2199999999999998
    X706                 R83 1
    X706                 R222 1
    X706                 R240 -1
    X707                 OBJ 7.2000000000000002
    X707                 R84 1
    X707                 R239 -1
    X707                 R240 1
    X708                 OBJ 7.2000000000000002
    X708                 R84 1
    X708                 R239 1
    X708                 R240 -1
    X709                 OBJ 3.27
    X709                 R85 1
    X709                 R238 -1
    X709                 R240 1
    X710                 OBJ 3.27
    X710                 R85 1
    X710                 R238 1
    X710                 R240 -1
    X711                 OBJ 5.3399999999999999
    X711                 R87 1
    X711                 R222 1
    X711                 R241 -1
    X712                 OBJ 5.3399999999999999
    X712                 R87 1
    X712                 R222 -1
    X712                 R241 1
    X713                 OBJ 6.3799999999999999
    X713                 R88 1
    X713                 R211 1
    X713                 R239 -1
    X714                 OBJ 6.3799999999999999
    X714                 R88 1
    X714                 R211 -1
    X714                 R239 1
    X715                 OBJ 6
    X715                 R89 1
    X715                 R227 1
    X715                 R234 -1
    X716                 OBJ 6
    X716                 R89 1
    X716                 R227 -1
    X716                 R234 1
    X717                 OBJ 3.7599999999999998
    X717                 R90 1
    X717                 R223 1
    X717                 R241 -1
    X718                 OBJ 3.7599999999999998
    X718                 R90 1
    X718                 R223 -1
    X718                 R241 1
    X719                 OBJ 7.8300000000000001
    X719                 R91 1
    X719                 R213 -1
    X719                 R239 1
    X720                 OBJ 7.8300000000000001
    X720                 R91 1
    X720                 R213 1
    X720                 R239 -1
    X721                 OBJ 2.1800000000000002
    X721                 R92 1
    X721                 R234 1
    X721                 R238 -1
    X722                 OBJ 2.1800000000000002
    X722                 R92 1
    X722                 R234 -1
    X722                 R238 1
    X723                 OBJ 4
    X723                 R93 1
    X723                 R213 -1
    X723                 R241 1
    X724                 OBJ 4
    X724                 R93 1
    X724                 R213 1
    X724                 R241 -1
    X725                 OBJ 2.5899999999999999
    X725                 R2 1
    X725                 R242 1
    X725                 R243 -1
    X726                 OBJ 2.5899999999999999
    X726                 R2 1
    X726                 R242 -1
    X726                 R243 1
    X727                 OBJ 10.67
    X727                 R4 1
    X727                 R242 1
    X727                 R244 -1
    X728                 OBJ 10.67
    X728                 R4 1
    X728                 R242 -1
    X728                 R244 1
    X729                 OBJ 5.5199999999999996
    X729                 R6 1
    X729                 R242 1
    X729                 R245 -1
    X730                 OBJ 5.5199999999999996
    X730                 R6 1
    X730                 R242 -1
    X730                 R245 1
    X731                 OBJ 5.4000000000000004
    X731                 R8 1
    X731                 R242 1
    X731                 R246 -1
    X732                 OBJ 5.4000000000000004
    X732                 R8 1
    X732                 R242 -1
    X732                 R246 1
    X733                 OBJ 13.630000000000001
    X733                 R11 1
    X733                 R247 1
    X733                 R248 -1
    X734                 OBJ 13.630000000000001
    X734                 R11 1
    X734                 R247 -1
    X734                 R248 1
    X735                 OBJ 7.9400000000000004
    X735                 R13 1
    X735                 R247 1
    X735                 R249 -1
    X736                 OBJ 7.9400000000000004
    X736                 R13 1
    X736                 R247 -1
    X736                 R249 1
    X737                 OBJ 15
    X737                 R15 1
    X737                 R247 1
    X737                 R250 -1
    X738                 OBJ 15
    X738                 R15 1
    X738                 R247 -1
    X738                 R250 1
    X739                 OBJ 7.5999999999999996
    X739                 R18 1
    X739                 R251 1
    X739                 R252 -1
    X740                 OBJ 7.5999999999999996
    X740                 R18 1
    X740                 R251 -1
    X740                 R252 1
    X741                 OBJ 5.0800000000000001
    X741                 R20 1
    X741                 R251 1
    X741                 R253 -1
    X742                 OBJ 5.0800000000000001
    X742                 R20 1
    X742                 R251 -1
    X742                 R253 1
    X743                 OBJ 12.44
    X743                 R22 1
    X743                 R251 1
    X743                 R254 -1
    X744                 OBJ 12.44
    X744                 R22 1
    X744                 R251 -1
    X744                 R254 1
    X745                 OBJ 4.7400000000000002
    X745                 R25 1
    X745                 R255 1
    X745                 R256 -1
    X746                 OBJ 4.7400000000000002
    X746                 R25 1
    X746                 R255 -1
    X746                 R256 1
    X747                 OBJ 4.8700000000000001
    X747                 R26 1
    X747                 R249 -1
    X747                 R255 1
    X748                 OBJ 4.8700000000000001
    X748                 R26 1
    X748                 R249 1
    X748                 R255 -1
    X749                 OBJ 5.5099999999999998
    X749                 R27 1
    X749                 R250 -1
    X749                 R255 1
    X750                 OBJ 5.5099999999999998
    X750                 R27 1
    X750                 R250 1
    X750                 R255 -1
    X751                 OBJ 5.4000000000000004
    X751                 R30 1
    X751                 R257 1
    X751                 R258 -1
    X752                 OBJ 5.4000000000000004
    X752                 R30 1
    X752                 R257 -1
    X752                 R258 1
    X753                 OBJ 3.8100000000000001
    X753                 R31 1
    X753                 R245 -1
    X753                 R257 1
    X754                 OBJ 3.8100000000000001
    X754                 R31 1
    X754                 R245 1
    X754                 R257 -1
    X755                 OBJ 7.5700000000000003
    X755                 R33 1
    X755                 R257 1
    X755                 R259 -1
    X756                 OBJ 7.5700000000000003
    X756                 R33 1
    X756                 R257 -1
    X756                 R259 1
    X757                 OBJ 4.2000000000000002
    X757                 R35 1
    X757                 R257 1
    X757                 R260 -1
    X758                 OBJ 4.2000000000000002
    X758                 R35 1
    X758                 R257 -1
    X758                 R260 1
    X759                 OBJ 7.75
    X759                 R37 1
    X759                 R257 1
    X759                 R261 -1
    X760                 OBJ 7.75
    X760                 R37 1
    X760                 R257 -1
    X760                 R261 1
    X761                 OBJ 6.0999999999999996
    X761                 R39 1
    X761                 R244 -1
    X761                 R262 1
    X762                 OBJ 6.0999999999999996
    X762                 R39 1
    X762                 R244 1
    X762                 R262 -1
    X763                 OBJ 2.3900000000000001
    X763                 R40 1
    X763                 R246 -1
    X763                 R262 1
    X764                 OBJ 2.3900000000000001
    X764                 R40 1
    X764                 R246 1
    X764                 R262 -1
    X765                 OBJ 8.3399999999999999
    X765                 R42 1
    X765                 R252 -1
    X765                 R263 1
    X766                 OBJ 8.3399999999999999
    X766                 R42 1
    X766                 R252 1
    X766                 R263 -1
    X767                 OBJ 7.5599999999999996
    X767                 R43 1
    X767                 R253 -1
    X767                 R263 1
    X768                 OBJ 7.5599999999999996
    X768                 R43 1
    X768                 R253 1
    X768                 R263 -1
    X769                 OBJ 7.4699999999999998
    X769                 R45 1
    X769                 R263 1
    X769                 R264 -1
    X770                 OBJ 7.4699999999999998
    X770                 R45 1
    X770                 R263 -1
    X770                 R264 1
    X771                 OBJ 2.6400000000000001
    X771                 R47 1
    X771                 R243 -1
    X771                 R265 1
    X772                 OBJ 3.9300000000000002
    X772                 R48 1
    X772                 R243 1
    X772                 R264 -1
    X773                 OBJ 3.9300000000000002
    X773                 R48 1
    X773                 R243 -1
    X773                 R264 1
    X774                 OBJ 4.3600000000000003
    X774                 R50 1
    X774                 R256 1
    X774                 R266 -1
    X775                 OBJ 4.3600000000000003
    X775                 R50 1
    X775                 R256 -1
    X775                 R266 1
    X776                 OBJ 6.6799999999999997
    X776                 R51 1
    X776                 R256 1
    X776                 R260 -1
    X777                 OBJ 6.6799999999999997
    X777                 R51 1
    X777                 R256 -1
    X777                 R260 1
    X778                 OBJ 7.2199999999999998
    X778                 R53 1
    X778                 R258 1
    X778                 R267 -1
    X779                 OBJ 7.2199999999999998
    X779                 R53 1
    X779                 R258 -1
    X779                 R267 1
    X780                 OBJ 7.7699999999999996
    X780                 R55 1
    X780                 R258 1
    X780                 R268 -1
    X781                 OBJ 7.7699999999999996
    X781                 R55 1
    X781                 R258 -1
    X781                 R268 1
    X782                 OBJ 4.6200000000000001
    X782                 R57 1
    X782                 R244 -1
    X782                 R269 1
    X783                 OBJ 4.6200000000000001
    X783                 R57 1
    X783                 R244 1
    X783                 R269 -1
    X784                 OBJ 6.9000000000000004
    X784                 R58 1
    X784                 R246 -1
    X784                 R269 1
    X785                 OBJ 6.9000000000000004
    X785                 R58 1
    X785                 R246 1
    X785                 R269 -1
    X786                 OBJ 2.75
    X786                 R60 1
    X786                 R265 1
    X786                 R270 -1
    X787                 OBJ 5.9199999999999999
    X787                 R61 1
    X787                 R245 -1
    X787                 R270 1
    X788                 OBJ 5.9199999999999999
    X788                 R61 1
    X788                 R245 1
    X788                 R270 -1
    X789                 OBJ 4.5599999999999996
    X789                 R62 1
    X789                 R259 -1
    X789                 R270 1
    X790                 OBJ 4.5599999999999996
    X790                 R62 1
    X790                 R259 1
    X790                 R270 -1
    X791                 OBJ 2.71
    X791                 R64 1
    X791                 R270 1
    X791                 R271 -1
    X792                 OBJ 2.71
    X792                 R64 1
    X792                 R270 -1
    X792                 R271 1
    X793                 OBJ 11.82
    X793                 R66 1
    X793                 R267 -1
    X793                 R272 1
    X794                 OBJ 11.82
    X794                 R66 1
    X794                 R267 1
    X794                 R272 -1
    X795                 OBJ 5.9699999999999998
    X795                 R67 1
    X795                 R268 -1
    X795                 R272 1
    X796                 OBJ 5.9699999999999998
    X796                 R67 1
    X796                 R268 1
    X796                 R272 -1
    X797                 OBJ 13.699999999999999
    X797                 R68 1
    X797                 R261 -1
    X797                 R272 1
    X798                 OBJ 13.699999999999999
    X798                 R68 1
    X798                 R261 1
    X798                 R272 -1
    X799                 OBJ 3.8300000000000001
    X799                 R69 1
    X799                 R261 -1
    X799                 R266 1
    X800                 OBJ 3.8300000000000001
    X800                 R69 1
    X800                 R261 1
    X800                 R266 -1
    X801                 OBJ 19.77
    X801                 R71 1
    X801                 R246 -1
    X801                 R273 1
    X802                 OBJ 19.77
    X802                 R71 1
    X802                 R246 1
    X802                 R273 -1
    X803                 OBJ 7.5099999999999998
    X803                 R72 1
    X803                 R252 -1
    X803                 R273 1
    X804                 OBJ 7.5099999999999998
    X804                 R72 1
    X804                 R252 1
    X804                 R273 -1
    X805                 OBJ 4.71
    X805                 R73 1
    X805                 R254 -1
    X805                 R273 1
    X806                 OBJ 4.71
    X806                 R73 1
    X806                 R254 1
    X806                 R273 -1
    X807                 OBJ 5.1399999999999997
    X807                 R74 1
    X807                 R246 1
    X807                 R264 -1
    X808                 OBJ 5.1399999999999997
    X808                 R74 1
    X808                 R246 -1
    X808                 R264 1
    X809                 OBJ 4.1100000000000003
    X809                 R76 1
    X809                 R253 -1
    X809                 R274 1
    X810                 OBJ 4.1100000000000003
    X810                 R76 1
    X810                 R253 1
    X810                 R274 -1
    X811                 OBJ 5.9400000000000004
    X811                 R77 1
    X811                 R264 -1
    X811                 R274 1
    X812                 OBJ 5.9400000000000004
    X812                 R77 1
    X812                 R264 1
    X812                 R274 -1
    X813                 OBJ 5.0700000000000003
    X813                 R79 1
    X813                 R274 1
    X813                 R275 -1
    X814                 OBJ 5.0700000000000003
    X814                 R79 1
    X814                 R274 -1
    X814                 R275 1
    X815                 OBJ 9.0700000000000003
    X815                 R81 1
    X815                 R253 1
    X815                 R276 -1
    X816                 OBJ 9.0700000000000003
    X816                 R81 1
    X816                 R253 -1
    X816                 R276 1
    X817                 OBJ 5.2199999999999998
    X817                 R83 1
    X817                 R259 -1
    X817                 R277 1
    X818                 OBJ 5.2199999999999998
    X818                 R83 1
    X818                 R259 1
    X818                 R277 -1
    X819                 OBJ 7.2000000000000002
    X819                 R84 1
    X819                 R276 -1
    X819                 R277 1
    X820                 OBJ 7.2000000000000002
    X820                 R84 1
    X820                 R276 1
    X820                 R277 -1
    X821                 OBJ 3.27
    X821                 R85 1
    X821                 R275 -1
    X821                 R277 1
    X822                 OBJ 3.27
    X822                 R85 1
    X822                 R275 1
    X822                 R277 -1
    X823                 OBJ 5.3399999999999999
    X823                 R87 1
    X823                 R259 1
    X823                 R278 -1
    X824                 OBJ 5.3399999999999999
    X824                 R87 1
    X824                 R259 -1
    X824                 R278 1
    X825                 OBJ 6.3799999999999999
    X825                 R88 1
    X825                 R248 1
    X825                 R276 -1
    X826                 OBJ 6.3799999999999999
    X826                 R88 1
    X826                 R248 -1
    X826                 R276 1
    X827                 OBJ 6
    X827                 R89 1
    X827                 R264 1
    X827                 R271 -1
    X828                 OBJ 6
    X828                 R89 1
    X828                 R264 -1
    X828                 R271 1
    X829                 OBJ 3.7599999999999998
    X829                 R90 1
    X829                 R260 1
    X829                 R278 -1
    X830                 OBJ 3.7599999999999998
    X830                 R90 1
    X830                 R260 -1
    X830                 R278 1
    X831                 OBJ 7.8300000000000001
    X831                 R91 1
    X831                 R250 -1
    X831                 R276 1
    X832                 OBJ 7.8300000000000001
    X832                 R91 1
    X832                 R250 1
    X832                 R276 -1
    X833                 OBJ 2.1800000000000002
    X833                 R92 1
    X833                 R271 1
    X833                 R275 -1
    X834                 OBJ 2.1800000000000002
    X834                 R92 1
    X834                 R271 -1
    X834                 R275 1
    X835                 OBJ 4
    X835                 R93 1
    X835                 R250 -1
    X835                 R278 1
    X836                 OBJ 4
    X836                 R93 1
    X836                 R250 1
    X836                 R278 -1
    X837                 OBJ 2.5899999999999999
    X837                 R2 1
    X837                 R279 1
    X837                 R280 -1
    X838                 OBJ 2.5899999999999999
    X838                 R2 1
    X838                 R279 -1
    X838                 R280 1
    X839                 OBJ 10.67
    X839                 R4 1
    X839                 R279 1
    X839                 R281 -1
    X840                 OBJ 10.67
    X840                 R4 1
    X840                 R279 -1
    X840                 R281 1
    X841                 OBJ 5.5199999999999996
    X841                 R6 1
    X841                 R279 1
    X841                 R282 -1
    X842                 OBJ 5.5199999999999996
    X842                 R6 1
    X842                 R279 -1
    X842                 R282 1
    X843                 OBJ 5.4000000000000004
    X843                 R8 1
    X843                 R279 1
    X843                 R283 -1
    X844                 OBJ 5.4000000000000004
    X844                 R8 1
    X844                 R279 -1
    X844                 R283 1
    X845                 OBJ 13.630000000000001
    X845                 R11 1
    X845                 R284 1
    X845                 R285 -1
    X846                 OBJ 13.630000000000001
    X846                 R11 1
    X846                 R284 -1
    X846                 R285 1
    X847                 OBJ 7.9400000000000004
    X847                 R13 1
    X847                 R284 1
    X847                 R286 -1
    X848                 OBJ 7.9400000000000004
    X848                 R13 1
    X848                 R284 -1
    X848                 R286 1
    X849                 OBJ 15
    X849                 R15 1
    X849                 R284 1
    X849                 R287 -1
    X850                 OBJ 15
    X850                 R15 1
    X850                 R284 -1
    X850                 R287 1
    X851                 OBJ 7.5999999999999996
    X851                 R18 1
    X851                 R288 1
    X851                 R289 -1
    X852                 OBJ 7.5999999999999996
    X852                 R18 1
    X852                 R288 -1
    X852                 R289 1
    X853                 OBJ 5.0800000000000001
    X853                 R20 1
    X853                 R288 1
    X853                 R290 -1
    X854                 OBJ 5.0800000000000001
    X854                 R20 1
    X854                 R288 -1
    X854                 R290 1
    X855                 OBJ 12.44
    X855                 R22 1
    X855                 R288 1
    X855                 R291 -1
    X856                 OBJ 12.44
    X856                 R22 1
    X856                 R288 -1
    X856                 R291 1
    X857                 OBJ 4.7400000000000002
    X857                 R25 1
    X857                 R292 1
    X857                 R293 -1
    X858                 OBJ 4.7400000000000002
    X858                 R25 1
    X858                 R292 -1
    X858                 R293 1
    X859                 OBJ 4.8700000000000001
    X859                 R26 1
    X859                 R286 -1
    X859                 R292 1
    X860                 OBJ 4.8700000000000001
    X860                 R26 1
    X860                 R286 1
    X860                 R292 -1
    X861                 OBJ 5.5099999999999998
    X861                 R27 1
    X861                 R287 -1
    X861                 R292 1
    X862                 OBJ 5.5099999999999998
    X862                 R27 1
    X862                 R287 1
    X862                 R292 -1
    X863                 OBJ 5.4000000000000004
    X863                 R30 1
    X863                 R294 1
    X863                 R295 -1
    X864                 OBJ 5.4000000000000004
    X864                 R30 1
    X864                 R294 -1
    X864                 R295 1
    X865                 OBJ 3.8100000000000001
    X865                 R31 1
    X865                 R282 -1
    X865                 R294 1
    X866                 OBJ 3.8100000000000001
    X866                 R31 1
    X866                 R282 1
    X866                 R294 -1
    X867                 OBJ 7.5700000000000003
    X867                 R33 1
    X867                 R294 1
    X867                 R296 -1
    X868                 OBJ 7.5700000000000003
    X868                 R33 1
    X868                 R294 -1
    X868                 R296 1
    X869                 OBJ 4.2000000000000002
    X869                 R35 1
    X869                 R294 1
    X869                 R297 -1
    X870                 OBJ 4.2000000000000002
    X870                 R35 1
    X870                 R294 -1
    X870                 R297 1
    X871                 OBJ 7.75
    X871                 R37 1
    X871                 R294 1
    X871                 R298 -1
    X872                 OBJ 7.75
    X872                 R37 1
    X872                 R294 -1
    X872                 R298 1
    X873                 OBJ 6.0999999999999996
    X873                 R39 1
    X873                 R281 -1
    X873                 R299 1
    X874                 OBJ 6.0999999999999996
    X874                 R39 1
    X874                 R281 1
    X874                 R299 -1
    X875                 OBJ 2.3900000000000001
    X875                 R40 1
    X875                 R283 -1
    X875                 R299 1
    X876                 OBJ 2.3900000000000001
    X876                 R40 1
    X876                 R283 1
    X876                 R299 -1
    X877                 OBJ 8.3399999999999999
    X877                 R42 1
    X877                 R289 -1
    X877                 R300 1
    X878                 OBJ 8.3399999999999999
    X878                 R42 1
    X878                 R289 1
    X878                 R300 -1
    X879                 OBJ 7.5599999999999996
    X879                 R43 1
    X879                 R290 -1
    X879                 R300 1
    X880                 OBJ 7.5599999999999996
    X880                 R43 1
    X880                 R290 1
    X880                 R300 -1
    X881                 OBJ 7.4699999999999998
    X881                 R45 1
    X881                 R300 1
    X881                 R301 -1
    X882                 OBJ 7.4699999999999998
    X882                 R45 1
    X882                 R300 -1
    X882                 R301 1
    X883                 OBJ 2.6400000000000001
    X883                 R47 1
    X883                 R280 1
    X883                 R302 -1
    X884                 OBJ 2.6400000000000001
    X884                 R47 1
    X884                 R280 -1
    X884                 R302 1
    X885                 OBJ 3.9300000000000002
    X885                 R48 1
    X885                 R280 1
    X885                 R301 -1
    X886                 OBJ 3.9300000000000002
    X886                 R48 1
    X886                 R280 -1
    X886                 R301 1
    X887                 OBJ 4.3600000000000003
    X887                 R50 1
    X887                 R293 1
    X887                 R303 -1
    X888                 OBJ 4.3600000000000003
    X888                 R50 1
    X888                 R293 -1
    X888                 R303 1
    X889                 OBJ 6.6799999999999997
    X889                 R51 1
    X889                 R293 1
    X889                 R297 -1
    X890                 OBJ 6.6799999999999997
    X890                 R51 1
    X890                 R293 -1
    X890                 R297 1
    X891                 OBJ 7.2199999999999998
    X891                 R53 1
    X891                 R295 1
    X891                 R304 -1
    X892                 OBJ 7.2199999999999998
    X892                 R53 1
    X892                 R295 -1
    X892                 R304 1
    X893                 OBJ 7.7699999999999996
    X893                 R55 1
    X893                 R295 1
    X893                 R305 -1
    X894                 OBJ 7.7699999999999996
    X894                 R55 1
    X894                 R295 -1
    X894                 R305 1
    X895                 OBJ 4.6200000000000001
    X895                 R57 1
    X895                 R281 -1
    X895                 R306 1
    X896                 OBJ 4.6200000000000001
    X896                 R57 1
    X896                 R281 1
    X896                 R306 -1
    X897                 OBJ 6.9000000000000004
    X897                 R58 1
    X897                 R283 -1
    X897                 R306 1
    X898                 OBJ 6.9000000000000004
    X898                 R58 1
    X898                 R283 1
    X898                 R306 -1
    X899                 OBJ 2.75
    X899                 R60 1
    X899                 R302 -1
    X899                 R307 1
    X900                 OBJ 5.9199999999999999
    X900                 R61 1
    X900                 R282 -1
    X900                 R307 1
    X901                 OBJ 4.5599999999999996
    X901                 R62 1
    X901                 R296 -1
    X901                 R307 1
    X902                 OBJ 2.71
    X902                 R64 1
    X902                 R307 1
    X902                 R308 -1
    X903                 OBJ 11.82
    X903                 R66 1
    X903                 R304 -1
    X903                 R309 1
    X904                 OBJ 11.82
    X904                 R66 1
    X904                 R304 1
    X904                 R309 -1
    X905                 OBJ 5.9699999999999998
    X905                 R67 1
    X905                 R305 -1
    X905                 R309 1
    X906                 OBJ 5.9699999999999998
    X906                 R67 1
    X906                 R305 1
    X906                 R309 -1
    X907                 OBJ 13.699999999999999
    X907                 R68 1
    X907                 R298 -1
    X907                 R309 1
    X908                 OBJ 13.699999999999999
    X908                 R68 1
    X908                 R298 1
    X908                 R309 -1
    X909                 OBJ 3.8300000000000001
    X909                 R69 1
    X909                 R298 -1
    X909                 R303 1
    X910                 OBJ 3.8300000000000001
    X910                 R69 1
    X910                 R298 1
    X910                 R303 -1
    X911                 OBJ 19.77
    X911                 R71 1
    X911                 R283 -1
    X911                 R310 1
    X912                 OBJ 19.77
    X912                 R71 1
    X912                 R283 1
    X912                 R310 -1
    X913                 OBJ 7.5099999999999998
    X913                 R72 1
    X913                 R289 -1
    X913                 R310 1
    X914                 OBJ 7.5099999999999998
    X914                 R72 1
    X914                 R289 1
    X914                 R310 -1
    X915                 OBJ 4.71
    X915                 R73 1
    X915                 R291 -1
    X915                 R310 1
    X916                 OBJ 4.71
    X916                 R73 1
    X916                 R291 1
    X916                 R310 -1
    X917                 OBJ 5.1399999999999997
    X917                 R74 1
    X917                 R283 1
    X917                 R301 -1
    X918                 OBJ 5.1399999999999997
    X918                 R74 1
    X918                 R283 -1
    X918                 R301 1
    X919                 OBJ 4.1100000000000003
    X919                 R76 1
    X919                 R290 -1
    X919                 R311 1
    X920                 OBJ 4.1100000000000003
    X920                 R76 1
    X920                 R290 1
    X920                 R311 -1
    X921                 OBJ 5.9400000000000004
    X921                 R77 1
    X921                 R301 -1
    X921                 R311 1
    X922                 OBJ 5.9400000000000004
    X922                 R77 1
    X922                 R301 1
    X922                 R311 -1
    X923                 OBJ 5.0700000000000003
    X923                 R79 1
    X923                 R311 1
    X923                 R312 -1
    X924                 OBJ 5.0700000000000003
    X924                 R79 1
    X924                 R311 -1
    X924                 R312 1
    X925                 OBJ 9.0700000000000003
    X925                 R81 1
    X925                 R290 1
    X925                 R313 -1
    X926                 OBJ 9.0700000000000003
    X926                 R81 1
    X926                 R290 -1
    X926                 R313 1
    X927                 OBJ 5.2199999999999998
    X927                 R83 1
    X927                 R296 -1
    X927                 R314 1
    X928                 OBJ 5.2199999999999998
    X928                 R83 1
    X928                 R296 1
    X928                 R314 -1
    X929                 OBJ 7.2000000000000002
    X929                 R84 1
    X929                 R313 -1
    X929                 R314 1
    X930                 OBJ 7.2000000000000002
    X930                 R84 1
    X930                 R313 1
    X930                 R314 -1
    X931                 OBJ 3.27
    X931                 R85 1
    X931                 R312 -1
    X931                 R314 1
    X932                 OBJ 3.27
    X932                 R85 1
    X932                 R312 1
    X932                 R314 -1
    X933                 OBJ 5.3399999999999999
    X933                 R87 1
    X933                 R296 1
    X933                 R315 -1
    X934                 OBJ 5.3399999999999999
    X934                 R87 1
    X934                 R296 -1
    X934                 R315 1
    X935                 OBJ 6.3799999999999999
    X935                 R88 1
    X935                 R285 1
    X935                 R313 -1
    X936                 OBJ 6.3799999999999999
    X936                 R88 1
    X936                 R285 -1
    X936                 R313 1
    X937                 OBJ 6
    X937                 R89 1
    X937                 R301 1
    X937                 R308 -1
    X938                 OBJ 6
    X938                 R89 1
    X938                 R301 -1
    X938                 R308 1
    X939                 OBJ 3.7599999999999998
    X939                 R90 1
    X939                 R297 1
    X939                 R315 -1
    X940                 OBJ 3.7599999999999998
    X940                 R90 1
    X940                 R297 -1
    X940                 R315 1
    X941                 OBJ 7.8300000000000001
    X941                 R91 1
    X941                 R287 -1
    X941                 R313 1
    X942                 OBJ 7.8300000000000001
    X942                 R91 1
    X942                 R287 1
    X942                 R313 -1
    X943                 OBJ 2.1800000000000002
    X943                 R92 1
    X943                 R308 1
    X943                 R312 -1
    X944                 OBJ 2.1800000000000002
    X944                 R92 1
    X944                 R308 -1
    X944                 R312 1
    X945                 OBJ 4
    X945                 R93 1
    X945                 R287 -1
    X945                 R315 1
    X946                 OBJ 4
    X946                 R93 1
    X946                 R287 1
    X946                 R315 -1
    X947                 OBJ 2.5899999999999999
    X947                 R2 1
    X947                 R316 1
    X947                 R317 -1
    X948                 OBJ 2.5899999999999999
    X948                 R2 1
    X948                 R316 -1
    X948                 R317 1
    X949                 OBJ 10.67
    X949                 R4 1
    X949                 R316 1
    X949                 R318 -1
    X950                 OBJ 10.67
    X950                 R4 1
    X950                 R316 -1
    X950                 R318 1
    X951                 OBJ 5.5199999999999996
    X951                 R6 1
    X951                 R316 1
    X951                 R319 -1
    X952                 OBJ 5.5199999999999996
    X952                 R6 1
    X952                 R316 -1
    X952                 R319 1
    X953                 OBJ 5.4000000000000004
    X953                 R8 1
    X953                 R316 -1
    X953                 R320 1
    X954                 OBJ 13.630000000000001
    X954                 R11 1
    X954                 R321 1
    X954                 R322 -1
    X955                 OBJ 13.630000000000001
    X955                 R11 1
    X955                 R321 -1
    X955                 R322 1
    X956                 OBJ 7.9400000000000004
    X956                 R13 1
    X956                 R321 1
    X956                 R323 -1
    X957                 OBJ 7.9400000000000004
    X957                 R13 1
    X957                 R321 -1
    X957                 R323 1
    X958                 OBJ 15
    X958                 R15 1
    X958                 R321 1
    X958                 R324 -1
    X959                 OBJ 15
    X959                 R15 1
    X959                 R321 -1
    X959                 R324 1
    X960                 OBJ 7.5999999999999996
    X960                 R18 1
    X960                 R325 1
    X960                 R326 -1
    X961                 OBJ 7.5999999999999996
    X961                 R18 1
    X961                 R325 -1
    X961                 R326 1
    X962                 OBJ 5.0800000000000001
    X962                 R20 1
    X962                 R325 1
    X962                 R327 -1
    X963                 OBJ 5.0800000000000001
    X963                 R20 1
    X963                 R325 -1
    X963                 R327 1
    X964                 OBJ 12.44
    X964                 R22 1
    X964                 R325 1
    X964                 R328 -1
    X965                 OBJ 12.44
    X965                 R22 1
    X965                 R325 -1
    X965                 R328 1
    X966                 OBJ 4.7400000000000002
    X966                 R25 1
    X966                 R329 1
    X966                 R330 -1
    X967                 OBJ 4.7400000000000002
    X967                 R25 1
    X967                 R329 -1
    X967                 R330 1
    X968                 OBJ 4.8700000000000001
    X968                 R26 1
    X968                 R323 -1
    X968                 R329 1
    X969                 OBJ 4.8700000000000001
    X969                 R26 1
    X969                 R323 1
    X969                 R329 -1
    X970                 OBJ 5.5099999999999998
    X970                 R27 1
    X970                 R324 -1
    X970                 R329 1
    X971                 OBJ 5.5099999999999998
    X971                 R27 1
    X971                 R324 1
    X971                 R329 -1
    X972                 OBJ 5.4000000000000004
    X972                 R30 1
    X972                 R331 1
    X972                 R332 -1
    X973                 OBJ 5.4000000000000004
    X973                 R30 1
    X973                 R331 -1
    X973                 R332 1
    X974                 OBJ 3.8100000000000001
    X974                 R31 1
    X974                 R319 -1
    X974                 R331 1
    X975                 OBJ 3.8100000000000001
    X975                 R31 1
    X975                 R319 1
    X975                 R331 -1
    X976                 OBJ 7.5700000000000003
    X976                 R33 1
    X976                 R331 1
    X976                 R333 -1
    X977                 OBJ 7.5700000000000003
    X977                 R33 1
    X977                 R331 -1
    X977                 R333 1
    X978                 OBJ 4.2000000000000002
    X978                 R35 1
    X978                 R331 1
    X978                 R334 -1
    X979                 OBJ 4.2000000000000002
    X979                 R35 1
    X979                 R331 -1
    X979                 R334 1
    X980                 OBJ 7.75
    X980                 R37 1
    X980                 R331 1
    X980                 R335 -1
    X981                 OBJ 7.75
    X981                 R37 1
    X981                 R331 -1
    X981                 R335 1
    X982                 OBJ 6.0999999999999996
    X982                 R39 1
    X982                 R318 -1
    X982                 R336 1
    X983                 OBJ 6.0999999999999996
    X983                 R39 1
    X983                 R318 1
    X983                 R336 -1
    X984                 OBJ 2.3900000000000001
    X984                 R40 1
    X984                 R320 1
    X984                 R336 -1
    X985                 OBJ 8.3399999999999999
    X985                 R42 1
    X985                 R326 -1
    X985                 R337 1
    X986                 OBJ 8.3399999999999999
    X986                 R42 1
    X986                 R326 1
    X986                 R337 -1
    X987                 OBJ 7.5599999999999996
    X987                 R43 1
    X987                 R327 -1
    X987                 R337 1
    X988                 OBJ 7.5599999999999996
    X988                 R43 1
    X988                 R327 1
    X988                 R337 -1
    X989                 OBJ 7.4699999999999998
    X989                 R45 1
    X989                 R337 1
    X989                 R338 -1
    X990                 OBJ 7.4699999999999998
    X990                 R45 1
    X990                 R337 -1
    X990                 R338 1
    X991                 OBJ 2.6400000000000001
    X991                 R47 1
    X991                 R317 1
    X991                 R339 -1
    X992                 OBJ 2.6400000000000001
    X992                 R47 1
    X992                 R317 -1
    X992                 R339 1
    X993                 OBJ 3.9300000000000002
    X993                 R48 1
    X993                 R317 1
    X993                 R338 -1
    X994                 OBJ 3.9300000000000002
    X994                 R48 1
    X994                 R317 -1
    X994                 R338 1
    X995                 OBJ 4.3600000000000003
    X995                 R50 1
    X995                 R330 1
    X995                 R340 -1
    X996                 OBJ 4.3600000000000003
    X996                 R50 1
    X996                 R330 -1
    X996                 R340 1
    X997                 OBJ 6.6799999999999997
    X997                 R51 1
    X997                 R330 1
    X997                 R334 -1
    X998                 OBJ 6.6799999999999997
    X998                 R51 1
    X998                 R330 -1
    X998                 R334 1
    X999                 OBJ 7.2199999999999998
    X999                 R53 1
    X999                 R332 1
    X999                 R341 -1
    X1000                OBJ 7.2199999999999998
    X1000                R53 1
    X1000                R332 -1
    X1000                R341 1
    X1001                OBJ 7.7699999999999996
    X1001                R55 1
    X1001                R332 1
    X1001                R342 -1
    X1002                OBJ 7.7699999999999996
    X1002                R55 1
    X1002                R332 -1
    X1002                R342 1
    X1003                OBJ 4.6200000000000001
    X1003                R57 1
    X1003                R318 -1
    X1003                R343 1
    X1004                OBJ 4.6200000000000001
    X1004                R57 1
    X1004                R318 1
    X1004                R343 -1
    X1005                OBJ 6.9000000000000004
    X1005                R58 1
    X1005                R320 1
    X1005                R343 -1
    X1006                OBJ 2.75
    X1006                R60 1
    X1006                R339 1
    X1006                R344 -1
    X1007                OBJ 2.75
    X1007                R60 1
    X1007                R339 -1
    X1007                R344 1
    X1008                OBJ 5.9199999999999999
    X1008                R61 1
    X1008                R319 -1
    X1008                R344 1
    X1009                OBJ 5.9199999999999999
    X1009                R61 1
    X1009                R319 1
    X1009                R344 -1
    X1010                OBJ 4.5599999999999996
    X1010                R62 1
    X1010                R333 -1
    X1010                R344 1
    X1011                OBJ 4.5599999999999996
    X1011                R62 1
    X1011                R333 1
    X1011                R344 -1
    X1012                OBJ 2.71
    X1012                R64 1
    X1012                R344 1
    X1012                R345 -1
    X1013                OBJ 2.71
    X1013                R64 1
    X1013                R344 -1
    X1013                R345 1
    X1014                OBJ 11.82
    X1014                R66 1
    X1014                R341 -1
    X1014                R346 1
    X1015                OBJ 11.82
    X1015                R66 1
    X1015                R341 1
    X1015                R346 -1
    X1016                OBJ 5.9699999999999998
    X1016                R67 1
    X1016                R342 -1
    X1016                R346 1
    X1017                OBJ 5.9699999999999998
    X1017                R67 1
    X1017                R342 1
    X1017                R346 -1
    X1018                OBJ 13.699999999999999
    X1018                R68 1
    X1018                R335 -1
    X1018                R346 1
    X1019                OBJ 13.699999999999999
    X1019                R68 1
    X1019                R335 1
    X1019                R346 -1
    X1020                OBJ 3.8300000000000001
    X1020                R69 1
    X1020                R335 -1
    X1020                R340 1
    X1021                OBJ 3.8300000000000001
    X1021                R69 1
    X1021                R335 1
    X1021                R340 -1
    X1022                OBJ 19.77
    X1022                R71 1
    X1022                R320 1
    X1022                R347 -1
    X1023                OBJ 7.5099999999999998
    X1023                R72 1
    X1023                R326 -1
    X1023                R347 1
    X1024                OBJ 7.5099999999999998
    X1024                R72 1
    X1024                R326 1
    X1024                R347 -1
    X1025                OBJ 4.71
    X1025                R73 1
    X1025                R328 -1
    X1025                R347 1
    X1026                OBJ 4.71
    X1026                R73 1
    X1026                R328 1
    X1026                R347 -1
    X1027                OBJ 5.1399999999999997
    X1027                R74 1
    X1027                R320 1
    X1027                R338 -1
    X1028                OBJ 4.1100000000000003
    X1028                R76 1
    X1028                R327 -1
    X1028                R348 1
    X1029                OBJ 4.1100000000000003
    X1029                R76 1
    X1029                R327 1
    X1029                R348 -1
    X1030                OBJ 5.9400000000000004
    X1030                R77 1
    X1030                R338 -1
    X1030                R348 1
    X1031                OBJ 5.9400000000000004
    X1031                R77 1
    X1031                R338 1
    X1031                R348 -1
    X1032                OBJ 5.0700000000000003
    X1032                R79 1
    X1032                R348 1
    X1032                R349 -1
    X1033                OBJ 5.0700000000000003
    X1033                R79 1
    X1033                R348 -1
    X1033                R349 1
    X1034                OBJ 9.0700000000000003
    X1034                R81 1
    X1034                R327 1
    X1034                R350 -1
    X1035                OBJ 9.0700000000000003
    X1035                R81 1
    X1035                R327 -1
    X1035                R350 1
    X1036                OBJ 5.2199999999999998
    X1036                R83 1
    X1036                R333 -1
    X1036                R351 1
    X1037                OBJ 5.2199999999999998
    X1037                R83 1
    X1037                R333 1
    X1037                R351 -1
    X1038                OBJ 7.2000000000000002
    X1038                R84 1
    X1038                R350 -1
    X1038                R351 1
    X1039                OBJ 7.2000000000000002
    X1039                R84 1
    X1039                R350 1
    X1039                R351 -1
    X1040                OBJ 3.27
    X1040                R85 1
    X1040                R349 -1
    X1040                R351 1
    X1041                OBJ 3.27
    X1041                R85 1
    X1041                R349 1
    X1041                R351 -1
    X1042                OBJ 5.3399999999999999
    X1042                R87 1
    X1042                R333 1
    X1042                R352 -1
    X1043                OBJ 5.3399999999999999
    X1043                R87 1
    X1043                R333 -1
    X1043                R352 1
    X1044                OBJ 6.3799999999999999
    X1044                R88 1
    X1044                R322 1
    X1044                R350 -1
    X1045                OBJ 6.3799999999999999
    X1045                R88 1
    X1045                R322 -1
    X1045                R350 1
    X1046                OBJ 6
    X1046                R89 1
    X1046                R338 1
    X1046                R345 -1
    X1047                OBJ 6
    X1047                R89 1
    X1047                R338 -1
    X1047                R345 1
    X1048                OBJ 3.7599999999999998
    X1048                R90 1
    X1048                R334 1
    X1048                R352 -1
    X1049                OBJ 3.7599999999999998
    X1049                R90 1
    X1049                R334 -1
    X1049                R352 1
    X1050                OBJ 7.8300000000000001
    X1050                R91 1
    X1050                R324 -1
    X1050                R350 1
    X1051                OBJ 7.8300000000000001
    X1051                R91 1
    X1051                R324 1
    X1051                R350 -1
    X1052                OBJ 2.1800000000000002
    X1052                R92 1
    X1052                R345 1
    X1052                R349 -1
    X1053                OBJ 2.1800000000000002
    X1053                R92 1
    X1053                R345 -1
    X1053                R349 1
    X1054                OBJ 4
    X1054                R93 1
    X1054                R324 -1
    X1054                R352 1
    X1055                OBJ 4
    X1055                R93 1
    X1055                R324 1
    X1055                R352 -1
    X1056                OBJ 2.5899999999999999
    X1056                R2 1
    X1056                R353 1
    X1056                R354 -1
    X1057                OBJ 2.5899999999999999
    X1057                R2 1
    X1057                R353 -1
    X1057                R354 1
    X1058                OBJ 10.67
    X1058                R4 1
    X1058                R353 1
    X1058                R355 -1
    X1059                OBJ 10.67
    X1059                R4 1
    X1059                R353 -1
    X1059                R355 1
    X1060                OBJ 5.5199999999999996
    X1060                R6 1
    X1060                R353 1
    X1060                R356 -1
    X1061                OBJ 5.5199999999999996
    X1061                R6 1
    X1061                R353 -1
    X1061                R356 1
    X1062                OBJ 5.4000000000000004
    X1062                R8 1
    X1062                R353 1
    X1062                R357 -1
    X1063                OBJ 5.4000000000000004
    X1063                R8 1
    X1063                R353 -1
    X1063                R357 1
    X1064                OBJ 13.630000000000001
    X1064                R11 1
    X1064                R358 1
    X1064                R359 -1
    X1065                OBJ 13.630000000000001
    X1065                R11 1
    X1065                R358 -1
    X1065                R359 1
    X1066                OBJ 7.9400000000000004
    X1066                R13 1
    X1066                R358 1
    X1066                R360 -1
    X1067                OBJ 7.9400000000000004
    X1067                R13 1
    X1067                R358 -1
    X1067                R360 1
    X1068                OBJ 15
    X1068                R15 1
    X1068                R358 1
    X1068                R361 -1
    X1069                OBJ 15
    X1069                R15 1
    X1069                R358 -1
    X1069                R361 1
    X1070                OBJ 7.5999999999999996
    X1070                R18 1
    X1070                R362 1
    X1070                R363 -1
    X1071                OBJ 5.0800000000000001
    X1071                R20 1
    X1071                R362 1
    X1071                R364 -1
    X1072                OBJ 12.44
    X1072                R22 1
    X1072                R362 1
    X1072                R365 -1
    X1073                OBJ 4.7400000000000002
    X1073                R25 1
    X1073                R366 1
    X1073                R367 -1
    X1074                OBJ 4.7400000000000002
    X1074                R25 1
    X1074                R366 -1
    X1074                R367 1
    X1075                OBJ 4.8700000000000001
    X1075                R26 1
    X1075                R360 -1
    X1075                R366 1
    X1076                OBJ 4.8700000000000001
    X1076                R26 1
    X1076                R360 1
    X1076                R366 -1
    X1077                OBJ 5.5099999999999998
    X1077                R27 1
    X1077                R361 -1
    X1077                R366 1
    X1078                OBJ 5.5099999999999998
    X1078                R27 1
    X1078                R361 1
    X1078                R366 -1
    X1079                OBJ 5.4000000000000004
    X1079                R30 1
    X1079                R368 1
    X1079                R369 -1
    X1080                OBJ 5.4000000000000004
    X1080                R30 1
    X1080                R368 -1
    X1080                R369 1
    X1081                OBJ 3.8100000000000001
    X1081                R31 1
    X1081                R356 -1
    X1081                R368 1
    X1082                OBJ 3.8100000000000001
    X1082                R31 1
    X1082                R356 1
    X1082                R368 -1
    X1083                OBJ 7.5700000000000003
    X1083                R33 1
    X1083                R368 1
    X1083                R370 -1
    X1084                OBJ 7.5700000000000003
    X1084                R33 1
    X1084                R368 -1
    X1084                R370 1
    X1085                OBJ 4.2000000000000002
    X1085                R35 1
    X1085                R368 1
    X1085                R371 -1
    X1086                OBJ 4.2000000000000002
    X1086                R35 1
    X1086                R368 -1
    X1086                R371 1
    X1087                OBJ 7.75
    X1087                R37 1
    X1087                R368 1
    X1087                R372 -1
    X1088                OBJ 7.75
    X1088                R37 1
    X1088                R368 -1
    X1088                R372 1
    X1089                OBJ 6.0999999999999996
    X1089                R39 1
    X1089                R355 -1
    X1089                R373 1
    X1090                OBJ 6.0999999999999996
    X1090                R39 1
    X1090                R355 1
    X1090                R373 -1
    X1091                OBJ 2.3900000000000001
    X1091                R40 1
    X1091                R357 -1
    X1091                R373 1
    X1092                OBJ 2.3900000000000001
    X1092                R40 1
    X1092                R357 1
    X1092                R373 -1
    X1093                OBJ 8.3399999999999999
    X1093                R42 1
    X1093                R363 -1
    X1093                R374 1
    X1094                OBJ 8.3399999999999999
    X1094                R42 1
    X1094                R363 1
    X1094                R374 -1
    X1095                OBJ 7.5599999999999996
    X1095                R43 1
    X1095                R364 -1
    X1095                R374 1
    X1096                OBJ 7.5599999999999996
    X1096                R43 1
    X1096                R364 1
    X1096                R374 -1
    X1097                OBJ 7.4699999999999998
    X1097                R45 1
    X1097                R374 1
    X1097                R375 -1
    X1098                OBJ 7.4699999999999998
    X1098                R45 1
    X1098                R374 -1
    X1098                R375 1
    X1099                OBJ 2.6400000000000001
    X1099                R47 1
    X1099                R354 1
    X1099                R376 -1
    X1100                OBJ 2.6400000000000001
    X1100                R47 1
    X1100                R354 -1
    X1100                R376 1
    X1101                OBJ 3.9300000000000002
    X1101                R48 1
    X1101                R354 1
    X1101                R375 -1
    X1102                OBJ 3.9300000000000002
    X1102                R48 1
    X1102                R354 -1
    X1102                R375 1
    X1103                OBJ 4.3600000000000003
    X1103                R50 1
    X1103                R367 1
    X1103                R377 -1
    X1104                OBJ 4.3600000000000003
    X1104                R50 1
    X1104                R367 -1
    X1104                R377 1
    X1105                OBJ 6.6799999999999997
    X1105                R51 1
    X1105                R367 1
    X1105                R371 -1
    X1106                OBJ 6.6799999999999997
    X1106                R51 1
    X1106                R367 -1
    X1106                R371 1
    X1107                OBJ 7.2199999999999998
    X1107                R53 1
    X1107                R369 1
    X1107                R378 -1
    X1108                OBJ 7.2199999999999998
    X1108                R53 1
    X1108                R369 -1
    X1108                R378 1
    X1109                OBJ 7.7699999999999996
    X1109                R55 1
    X1109                R369 1
    X1109                R379 -1
    X1110                OBJ 7.7699999999999996
    X1110                R55 1
    X1110                R369 -1
    X1110                R379 1
    X1111                OBJ 4.6200000000000001
    X1111                R57 1
    X1111                R355 -1
    X1111                R380 1
    X1112                OBJ 4.6200000000000001
    X1112                R57 1
    X1112                R355 1
    X1112                R380 -1
    X1113                OBJ 6.9000000000000004
    X1113                R58 1
    X1113                R357 -1
    X1113                R380 1
    X1114                OBJ 6.9000000000000004
    X1114                R58 1
    X1114                R357 1
    X1114                R380 -1
    X1115                OBJ 2.75
    X1115                R60 1
    X1115                R376 1
    X1115                R381 -1
    X1116                OBJ 2.75
    X1116                R60 1
    X1116                R376 -1
    X1116                R381 1
    X1117                OBJ 5.9199999999999999
    X1117                R61 1
    X1117                R356 -1
    X1117                R381 1
    X1118                OBJ 5.9199999999999999
    X1118                R61 1
    X1118                R356 1
    X1118                R381 -1
    X1119                OBJ 4.5599999999999996
    X1119                R62 1
    X1119                R370 -1
    X1119                R381 1
    X1120                OBJ 4.5599999999999996
    X1120                R62 1
    X1120                R370 1
    X1120                R381 -1
    X1121                OBJ 2.71
    X1121                R64 1
    X1121                R381 1
    X1121                R382 -1
    X1122                OBJ 2.71
    X1122                R64 1
    X1122                R381 -1
    X1122                R382 1
    X1123                OBJ 11.82
    X1123                R66 1
    X1123                R378 -1
    X1123                R383 1
    X1124                OBJ 11.82
    X1124                R66 1
    X1124                R378 1
    X1124                R383 -1
    X1125                OBJ 5.9699999999999998
    X1125                R67 1
    X1125                R379 -1
    X1125                R383 1
    X1126                OBJ 5.9699999999999998
    X1126                R67 1
    X1126                R379 1
    X1126                R383 -1
    X1127                OBJ 13.699999999999999
    X1127                R68 1
    X1127                R372 -1
    X1127                R383 1
    X1128                OBJ 13.699999999999999
    X1128                R68 1
    X1128                R372 1
    X1128                R383 -1
    X1129                OBJ 3.8300000000000001
    X1129                R69 1
    X1129                R372 -1
    X1129                R377 1
    X1130                OBJ 3.8300000000000001
    X1130                R69 1
    X1130                R372 1
    X1130                R377 -1
    X1131                OBJ 19.77
    X1131                R71 1
    X1131                R357 -1
    X1131                R384 1
    X1132                OBJ 19.77
    X1132                R71 1
    X1132                R357 1
    X1132                R384 -1
    X1133                OBJ 7.5099999999999998
    X1133                R72 1
    X1133                R363 -1
    X1133                R384 1
    X1134                OBJ 7.5099999999999998
    X1134                R72 1
    X1134                R363 1
    X1134                R384 -1
    X1135                OBJ 4.71
    X1135                R73 1
    X1135                R365 -1
    X1135                R384 1
    X1136                OBJ 4.71
    X1136                R73 1
    X1136                R365 1
    X1136                R384 -1
    X1137                OBJ 5.1399999999999997
    X1137                R74 1
    X1137                R357 1
    X1137                R375 -1
    X1138                OBJ 5.1399999999999997
    X1138                R74 1
    X1138                R357 -1
    X1138                R375 1
    X1139                OBJ 4.1100000000000003
    X1139                R76 1
    X1139                R364 -1
    X1139                R385 1
    X1140                OBJ 4.1100000000000003
    X1140                R76 1
    X1140                R364 1
    X1140                R385 -1
    X1141                OBJ 5.9400000000000004
    X1141                R77 1
    X1141                R375 -1
    X1141                R385 1
    X1142                OBJ 5.9400000000000004
    X1142                R77 1
    X1142                R375 1
    X1142                R385 -1
    X1143                OBJ 5.0700000000000003
    X1143                R79 1
    X1143                R385 1
    X1143                R386 -1
    X1144                OBJ 5.0700000000000003
    X1144                R79 1
    X1144                R385 -1
    X1144                R386 1
    X1145                OBJ 9.0700000000000003
    X1145                R81 1
    X1145                R364 1
    X1145                R387 -1
    X1146                OBJ 9.0700000000000003
    X1146                R81 1
    X1146                R364 -1
    X1146                R387 1
    X1147                OBJ 5.2199999999999998
    X1147                R83 1
    X1147                R370 -1
    X1147                R388 1
    X1148                OBJ 5.2199999999999998
    X1148                R83 1
    X1148                R370 1
    X1148                R388 -1
    X1149                OBJ 7.2000000000000002
    X1149                R84 1
    X1149                R387 -1
    X1149                R388 1
    X1150                OBJ 7.2000000000000002
    X1150                R84 1
    X1150                R387 1
    X1150                R388 -1
    X1151                OBJ 3.27
    X1151                R85 1
    X1151                R386 -1
    X1151                R388 1
    X1152                OBJ 3.27
    X1152                R85 1
    X1152                R386 1
    X1152                R388 -1
    X1153                OBJ 5.3399999999999999
    X1153                R87 1
    X1153                R370 1
    X1153                R389 -1
    X1154                OBJ 5.3399999999999999
    X1154                R87 1
    X1154                R370 -1
    X1154                R389 1
    X1155                OBJ 6.3799999999999999
    X1155                R88 1
    X1155                R359 1
    X1155                R387 -1
    X1156                OBJ 6.3799999999999999
    X1156                R88 1
    X1156                R359 -1
    X1156                R387 1
    X1157                OBJ 6
    X1157                R89 1
    X1157                R375 1
    X1157                R382 -1
    X1158                OBJ 6
    X1158                R89 1
    X1158                R375 -1
    X1158                R382 1
    X1159                OBJ 3.7599999999999998
    X1159                R90 1
    X1159                R371 1
    X1159                R389 -1
    X1160                OBJ 3.7599999999999998
    X1160                R90 1
    X1160                R371 -1
    X1160                R389 1
    X1161                OBJ 7.8300000000000001
    X1161                R91 1
    X1161                R361 -1
    X1161                R387 1
    X1162                OBJ 7.8300000000000001
    X1162                R91 1
    X1162                R361 1
    X1162                R387 -1
    X1163                OBJ 2.1800000000000002
    X1163                R92 1
    X1163                R382 1
    X1163                R386 -1
    X1164                OBJ 2.1800000000000002
    X1164                R92 1
    X1164                R382 -1
    X1164                R386 1
    X1165                OBJ 4
    X1165                R93 1
    X1165                R361 -1
    X1165                R389 1
    X1166                OBJ 4
    X1166                R93 1
    X1166                R361 1
    X1166                R389 -1
    X1167                OBJ 2.5899999999999999
    X1167                R2 1
    X1167                R390 1
    X1167                R391 -1
    X1168                OBJ 2.5899999999999999
    X1168                R2 1
    X1168                R390 -1
    X1168                R391 1
    X1169                OBJ 10.67
    X1169                R4 1
    X1169                R390 1
    X1169                R392 -1
    X1170                OBJ 10.67
    X1170                R4 1
    X1170                R390 -1
    X1170                R392 1
    X1171                OBJ 5.5199999999999996
    X1171                R6 1
    X1171                R390 -1
    X1171                R393 1
    X1172                OBJ 5.4000000000000004
    X1172                R8 1
    X1172                R390 1
    X1172                R394 -1
    X1173                OBJ 5.4000000000000004
    X1173                R8 1
    X1173                R390 -1
    X1173                R394 1
    X1174                OBJ 13.630000000000001
    X1174                R11 1
    X1174                R395 1
    X1174                R396 -1
    X1175                OBJ 13.630000000000001
    X1175                R11 1
    X1175                R395 -1
    X1175                R396 1
    X1176                OBJ 7.9400000000000004
    X1176                R13 1
    X1176                R395 1
    X1176                R397 -1
    X1177                OBJ 7.9400000000000004
    X1177                R13 1
    X1177                R395 -1
    X1177                R397 1
    X1178                OBJ 15
    X1178                R15 1
    X1178                R395 1
    X1178                R398 -1
    X1179                OBJ 15
    X1179                R15 1
    X1179                R395 -1
    X1179                R398 1
    X1180                OBJ 7.5999999999999996
    X1180                R18 1
    X1180                R399 1
    X1180                R400 -1
    X1181                OBJ 7.5999999999999996
    X1181                R18 1
    X1181                R399 -1
    X1181                R400 1
    X1182                OBJ 5.0800000000000001
    X1182                R20 1
    X1182                R399 1
    X1182                R401 -1
    X1183                OBJ 5.0800000000000001
    X1183                R20 1
    X1183                R399 -1
    X1183                R401 1
    X1184                OBJ 12.44
    X1184                R22 1
    X1184                R399 1
    X1184                R402 -1
    X1185                OBJ 12.44
    X1185                R22 1
    X1185                R399 -1
    X1185                R402 1
    X1186                OBJ 4.7400000000000002
    X1186                R25 1
    X1186                R403 1
    X1186                R404 -1
    X1187                OBJ 4.7400000000000002
    X1187                R25 1
    X1187                R403 -1
    X1187                R404 1
    X1188                OBJ 4.8700000000000001
    X1188                R26 1
    X1188                R397 -1
    X1188                R403 1
    X1189                OBJ 4.8700000000000001
    X1189                R26 1
    X1189                R397 1
    X1189                R403 -1
    X1190                OBJ 5.5099999999999998
    X1190                R27 1
    X1190                R398 -1
    X1190                R403 1
    X1191                OBJ 5.5099999999999998
    X1191                R27 1
    X1191                R398 1
    X1191                R403 -1
    X1192                OBJ 5.4000000000000004
    X1192                R30 1
    X1192                R405 1
    X1192                R406 -1
    X1193                OBJ 5.4000000000000004
    X1193                R30 1
    X1193                R405 -1
    X1193                R406 1
    X1194                OBJ 3.8100000000000001
    X1194                R31 1
    X1194                R393 1
    X1194                R405 -1
    X1195                OBJ 7.5700000000000003
    X1195                R33 1
    X1195                R405 1
    X1195                R407 -1
    X1196                OBJ 7.5700000000000003
    X1196                R33 1
    X1196                R405 -1
    X1196                R407 1
    X1197                OBJ 4.2000000000000002
    X1197                R35 1
    X1197                R405 1
    X1197                R408 -1
    X1198                OBJ 4.2000000000000002
    X1198                R35 1
    X1198                R405 -1
    X1198                R408 1
    X1199                OBJ 7.75
    X1199                R37 1
    X1199                R405 1
    X1199                R409 -1
    X1200                OBJ 7.75
    X1200                R37 1
    X1200                R405 -1
    X1200                R409 1
    X1201                OBJ 6.0999999999999996
    X1201                R39 1
    X1201                R392 -1
    X1201                R410 1
    X1202                OBJ 6.0999999999999996
    X1202                R39 1
    X1202                R392 1
    X1202                R410 -1
    X1203                OBJ 2.3900000000000001
    X1203                R40 1
    X1203                R394 -1
    X1203                R410 1
    X1204                OBJ 2.3900000000000001
    X1204                R40 1
    X1204                R394 1
    X1204                R410 -1
    X1205                OBJ 8.3399999999999999
    X1205                R42 1
    X1205                R400 -1
    X1205                R411 1
    X1206                OBJ 8.3399999999999999
    X1206                R42 1
    X1206                R400 1
    X1206                R411 -1
    X1207                OBJ 7.5599999999999996
    X1207                R43 1
    X1207                R401 -1
    X1207                R411 1
    X1208                OBJ 7.5599999999999996
    X1208                R43 1
    X1208                R401 1
    X1208                R411 -1
    X1209                OBJ 7.4699999999999998
    X1209                R45 1
    X1209                R411 1
    X1209                R412 -1
    X1210                OBJ 7.4699999999999998
    X1210                R45 1
    X1210                R411 -1
    X1210                R412 1
    X1211                OBJ 2.6400000000000001
    X1211                R47 1
    X1211                R391 1
    X1211                R413 -1
    X1212                OBJ 2.6400000000000001
    X1212                R47 1
    X1212                R391 -1
    X1212                R413 1
    X1213                OBJ 3.9300000000000002
    X1213                R48 1
    X1213                R391 1
    X1213                R412 -1
    X1214                OBJ 3.9300000000000002
    X1214                R48 1
    X1214                R391 -1
    X1214                R412 1
    X1215                OBJ 4.3600000000000003
    X1215                R50 1
    X1215                R404 1
    X1215                R414 -1
    X1216                OBJ 4.3600000000000003
    X1216                R50 1
    X1216                R404 -1
    X1216                R414 1
    X1217                OBJ 6.6799999999999997
    X1217                R51 1
    X1217                R404 1
    X1217                R408 -1
    X1218                OBJ 6.6799999999999997
    X1218                R51 1
    X1218                R404 -1
    X1218                R408 1
    X1219                OBJ 7.2199999999999998
    X1219                R53 1
    X1219                R406 1
    X1219                R415 -1
    X1220                OBJ 7.2199999999999998
    X1220                R53 1
    X1220                R406 -1
    X1220                R415 1
    X1221                OBJ 7.7699999999999996
    X1221                R55 1
    X1221                R406 1
    X1221                R416 -1
    X1222                OBJ 7.7699999999999996
    X1222                R55 1
    X1222                R406 -1
    X1222                R416 1
    X1223                OBJ 4.6200000000000001
    X1223                R57 1
    X1223                R392 -1
    X1223                R417 1
    X1224                OBJ 4.6200000000000001
    X1224                R57 1
    X1224                R392 1
    X1224                R417 -1
    X1225                OBJ 6.9000000000000004
    X1225                R58 1
    X1225                R394 -1
    X1225                R417 1
    X1226                OBJ 6.9000000000000004
    X1226                R58 1
    X1226                R394 1
    X1226                R417 -1
    X1227                OBJ 2.75
    X1227                R60 1
    X1227                R413 1
    X1227                R418 -1
    X1228                OBJ 2.75
    X1228                R60 1
    X1228                R413 -1
    X1228                R418 1
    X1229                OBJ 5.9199999999999999
    X1229                R61 1
    X1229                R393 1
    X1229                R418 -1
    X1230                OBJ 4.5599999999999996
    X1230                R62 1
    X1230                R407 -1
    X1230                R418 1
    X1231                OBJ 4.5599999999999996
    X1231                R62 1
    X1231                R407 1
    X1231                R418 -1
    X1232                OBJ 2.71
    X1232                R64 1
    X1232                R418 1
    X1232                R419 -1
    X1233                OBJ 2.71
    X1233                R64 1
    X1233                R418 -1
    X1233                R419 1
    X1234                OBJ 11.82
    X1234                R66 1
    X1234                R415 -1
    X1234                R420 1
    X1235                OBJ 11.82
    X1235                R66 1
    X1235                R415 1
    X1235                R420 -1
    X1236                OBJ 5.9699999999999998
    X1236                R67 1
    X1236                R416 -1
    X1236                R420 1
    X1237                OBJ 5.9699999999999998
    X1237                R67 1
    X1237                R416 1
    X1237                R420 -1
    X1238                OBJ 13.699999999999999
    X1238                R68 1
    X1238                R409 -1
    X1238                R420 1
    X1239                OBJ 13.699999999999999
    X1239                R68 1
    X1239                R409 1
    X1239                R420 -1
    X1240                OBJ 3.8300000000000001
    X1240                R69 1
    X1240                R409 -1
    X1240                R414 1
    X1241                OBJ 3.8300000000000001
    X1241                R69 1
    X1241                R409 1
    X1241                R414 -1
    X1242                OBJ 19.77
    X1242                R71 1
    X1242                R394 -1
    X1242                R421 1
    X1243                OBJ 19.77
    X1243                R71 1
    X1243                R394 1
    X1243                R421 -1
    X1244                OBJ 7.5099999999999998
    X1244                R72 1
    X1244                R400 -1
    X1244                R421 1
    X1245                OBJ 7.5099999999999998
    X1245                R72 1
    X1245                R400 1
    X1245                R421 -1
    X1246                OBJ 4.71
    X1246                R73 1
    X1246                R402 -1
    X1246                R421 1
    X1247                OBJ 4.71
    X1247                R73 1
    X1247                R402 1
    X1247                R421 -1
    X1248                OBJ 5.1399999999999997
    X1248                R74 1
    X1248                R394 1
    X1248                R412 -1
    X1249                OBJ 5.1399999999999997
    X1249                R74 1
    X1249                R394 -1
    X1249                R412 1
    X1250                OBJ 4.1100000000000003
    X1250                R76 1
    X1250                R401 -1
    X1250                R422 1
    X1251                OBJ 4.1100000000000003
    X1251                R76 1
    X1251                R401 1
    X1251                R422 -1
    X1252                OBJ 5.9400000000000004
    X1252                R77 1
    X1252                R412 -1
    X1252                R422 1
    X1253                OBJ 5.9400000000000004
    X1253                R77 1
    X1253                R412 1
    X1253                R422 -1
    X1254                OBJ 5.0700000000000003
    X1254                R79 1
    X1254                R422 1
    X1254                R423 -1
    X1255                OBJ 5.0700000000000003
    X1255                R79 1
    X1255                R422 -1
    X1255                R423 1
    X1256                OBJ 9.0700000000000003
    X1256                R81 1
    X1256                R401 1
    X1256                R424 -1
    X1257                OBJ 9.0700000000000003
    X1257                R81 1
    X1257                R401 -1
    X1257                R424 1
    X1258                OBJ 5.2199999999999998
    X1258                R83 1
    X1258                R407 -1
    X1258                R425 1
    X1259                OBJ 5.2199999999999998
    X1259                R83 1
    X1259                R407 1
    X1259                R425 -1
    X1260                OBJ 7.2000000000000002
    X1260                R84 1
    X1260                R424 -1
    X1260                R425 1
    X1261                OBJ 7.2000000000000002
    X1261                R84 1
    X1261                R424 1
    X1261                R425 -1
    X1262                OBJ 3.27
    X1262                R85 1
    X1262                R423 -1
    X1262                R425 1
    X1263                OBJ 3.27
    X1263                R85 1
    X1263                R423 1
    X1263                R425 -1
    X1264                OBJ 5.3399999999999999
    X1264                R87 1
    X1264                R407 1
    X1264                R426 -1
    X1265                OBJ 5.3399999999999999
    X1265                R87 1
    X1265                R407 -1
    X1265                R426 1
    X1266                OBJ 6.3799999999999999
    X1266                R88 1
    X1266                R396 1
    X1266                R424 -1
    X1267                OBJ 6.3799999999999999
    X1267                R88 1
    X1267                R396 -1
    X1267                R424 1
    X1268                OBJ 6
    X1268                R89 1
    X1268                R412 1
    X1268                R419 -1
    X1269                OBJ 6
    X1269                R89 1
    X1269                R412 -1
    X1269                R419 1
    X1270                OBJ 3.7599999999999998
    X1270                R90 1
    X1270                R408 1
    X1270                R426 -1
    X1271                OBJ 3.7599999999999998
    X1271                R90 1
    X1271                R408 -1
    X1271                R426 1
    X1272                OBJ 7.8300000000000001
    X1272                R91 1
    X1272                R398 -1
    X1272                R424 1
    X1273                OBJ 7.8300000000000001
    X1273                R91 1
    X1273                R398 1
    X1273                R424 -1
    X1274                OBJ 2.1800000000000002
    X1274                R92 1
    X1274                R419 1
    X1274                R423 -1
    X1275                OBJ 2.1800000000000002
    X1275                R92 1
    X1275                R419 -1
    X1275                R423 1
    X1276                OBJ 4
    X1276                R93 1
    X1276                R398 -1
    X1276                R426 1
    X1277                OBJ 4
    X1277                R93 1
    X1277                R398 1
    X1277                R426 -1
    X1278                OBJ 2.5899999999999999
    X1278                R2 1
    X1278                R427 1
    X1278                R428 -1
    X1279                OBJ 2.5899999999999999
    X1279                R2 1
    X1279                R427 -1
    X1279                R428 1
    X1280                OBJ 10.67
    X1280                R4 1
    X1280                R427 1
    X1280                R429 -1
    X1281                OBJ 10.67
    X1281                R4 1
    X1281                R427 -1
    X1281                R429 1
    X1282                OBJ 5.5199999999999996
    X1282                R6 1
    X1282                R427 1
    X1282                R430 -1
    X1283                OBJ 5.5199999999999996
    X1283                R6 1
    X1283                R427 -1
    X1283                R430 1
    X1284                OBJ 5.4000000000000004
    X1284                R8 1
    X1284                R427 1
    X1284                R431 -1
    X1285                OBJ 5.4000000000000004
    X1285                R8 1
    X1285                R427 -1
    X1285                R431 1
    X1286                OBJ 13.630000000000001
    X1286                R11 1
    X1286                R432 1
    X1286                R433 -1
    X1287                OBJ 13.630000000000001
    X1287                R11 1
    X1287                R432 -1
    X1287                R433 1
    X1288                OBJ 7.9400000000000004
    X1288                R13 1
    X1288                R432 1
    X1288                R434 -1
    X1289                OBJ 7.9400000000000004
    X1289                R13 1
    X1289                R432 -1
    X1289                R434 1
    X1290                OBJ 15
    X1290                R15 1
    X1290                R432 1
    X1290                R435 -1
    X1291                OBJ 15
    X1291                R15 1
    X1291                R432 -1
    X1291                R435 1
    X1292                OBJ 7.5999999999999996
    X1292                R18 1
    X1292                R436 1
    X1292                R437 -1
    X1293                OBJ 7.5999999999999996
    X1293                R18 1
    X1293                R436 -1
    X1293                R437 1
    X1294                OBJ 5.0800000000000001
    X1294                R20 1
    X1294                R436 1
    X1294                R438 -1
    X1295                OBJ 5.0800000000000001
    X1295                R20 1
    X1295                R436 -1
    X1295                R438 1
    X1296                OBJ 12.44
    X1296                R22 1
    X1296                R436 1
    X1296                R439 -1
    X1297                OBJ 12.44
    X1297                R22 1
    X1297                R436 -1
    X1297                R439 1
    X1298                OBJ 4.7400000000000002
    X1298                R25 1
    X1298                R440 1
    X1298                R441 -1
    X1299                OBJ 4.7400000000000002
    X1299                R25 1
    X1299                R440 -1
    X1299                R441 1
    X1300                OBJ 4.8700000000000001
    X1300                R26 1
    X1300                R434 -1
    X1300                R440 1
    X1301                OBJ 4.8700000000000001
    X1301                R26 1
    X1301                R434 1
    X1301                R440 -1
    X1302                OBJ 5.5099999999999998
    X1302                R27 1
    X1302                R435 -1
    X1302                R440 1
    X1303                OBJ 5.5099999999999998
    X1303                R27 1
    X1303                R435 1
    X1303                R440 -1
    X1304                OBJ 5.4000000000000004
    X1304                R30 1
    X1304                R442 1
    X1304                R443 -1
    X1305                OBJ 5.4000000000000004
    X1305                R30 1
    X1305                R442 -1
    X1305                R443 1
    X1306                OBJ 3.8100000000000001
    X1306                R31 1
    X1306                R430 -1
    X1306                R442 1
    X1307                OBJ 3.8100000000000001
    X1307                R31 1
    X1307                R430 1
    X1307                R442 -1
    X1308                OBJ 7.5700000000000003
    X1308                R33 1
    X1308                R442 1
    X1308                R444 -1
    X1309                OBJ 7.5700000000000003
    X1309                R33 1
    X1309                R442 -1
    X1309                R444 1
    X1310                OBJ 4.2000000000000002
    X1310                R35 1
    X1310                R442 1
    X1310                R445 -1
    X1311                OBJ 4.2000000000000002
    X1311                R35 1
    X1311                R442 -1
    X1311                R445 1
    X1312                OBJ 7.75
    X1312                R37 1
    X1312                R442 1
    X1312                R446 -1
    X1313                OBJ 7.75
    X1313                R37 1
    X1313                R442 -1
    X1313                R446 1
    X1314                OBJ 6.0999999999999996
    X1314                R39 1
    X1314                R429 -1
    X1314                R447 1
    X1315                OBJ 6.0999999999999996
    X1315                R39 1
    X1315                R429 1
    X1315                R447 -1
    X1316                OBJ 2.3900000000000001
    X1316                R40 1
    X1316                R431 -1
    X1316                R447 1
    X1317                OBJ 2.3900000000000001
    X1317                R40 1
    X1317                R431 1
    X1317                R447 -1
    X1318                OBJ 8.3399999999999999
    X1318                R42 1
    X1318                R437 -1
    X1318                R448 1
    X1319                OBJ 7.5599999999999996
    X1319                R43 1
    X1319                R438 -1
    X1319                R448 1
    X1320                OBJ 7.4699999999999998
    X1320                R45 1
    X1320                R448 1
    X1320                R449 -1
    X1321                OBJ 2.6400000000000001
    X1321                R47 1
    X1321                R428 1
    X1321                R450 -1
    X1322                OBJ 2.6400000000000001
    X1322                R47 1
    X1322                R428 -1
    X1322                R450 1
    X1323                OBJ 3.9300000000000002
    X1323                R48 1
    X1323                R428 1
    X1323                R449 -1
    X1324                OBJ 3.9300000000000002
    X1324                R48 1
    X1324                R428 -1
    X1324                R449 1
    X1325                OBJ 4.3600000000000003
    X1325                R50 1
    X1325                R441 1
    X1325                R451 -1
    X1326                OBJ 4.3600000000000003
    X1326                R50 1
    X1326                R441 -1
    X1326                R451 1
    X1327                OBJ 6.6799999999999997
    X1327                R51 1
    X1327                R441 1
    X1327                R445 -1
    X1328                OBJ 6.6799999999999997
    X1328                R51 1
    X1328                R441 -1
    X1328                R445 1
    X1329                OBJ 7.2199999999999998
    X1329                R53 1
    X1329                R443 1
    X1329                R452 -1
    X1330                OBJ 7.2199999999999998
    X1330                R53 1
    X1330                R443 -1
    X1330                R452 1
    X1331                OBJ 7.7699999999999996
    X1331                R55 1
    X1331                R443 1
    X1331                R453 -1
    X1332                OBJ 7.7699999999999996
    X1332                R55 1
    X1332                R443 -1
    X1332                R453 1
    X1333                OBJ 4.6200000000000001
    X1333                R57 1
    X1333                R429 -1
    X1333                R454 1
    X1334                OBJ 4.6200000000000001
    X1334                R57 1
    X1334                R429 1
    X1334                R454 -1
    X1335                OBJ 6.9000000000000004
    X1335                R58 1
    X1335                R431 -1
    X1335                R454 1
    X1336                OBJ 6.9000000000000004
    X1336                R58 1
    X1336                R431 1
    X1336                R454 -1
    X1337                OBJ 2.75
    X1337                R60 1
    X1337                R450 1
    X1337                R455 -1
    X1338                OBJ 2.75
    X1338                R60 1
    X1338                R450 -1
    X1338                R455 1
    X1339                OBJ 5.9199999999999999
    X1339                R61 1
    X1339                R430 -1
    X1339                R455 1
    X1340                OBJ 5.9199999999999999
    X1340                R61 1
    X1340                R430 1
    X1340                R455 -1
    X1341                OBJ 4.5599999999999996
    X1341                R62 1
    X1341                R444 -1
    X1341                R455 1
    X1342                OBJ 4.5599999999999996
    X1342                R62 1
    X1342                R444 1
    X1342                R455 -1
    X1343                OBJ 2.71
    X1343                R64 1
    X1343                R455 1
    X1343                R456 -1
    X1344                OBJ 2.71
    X1344                R64 1
    X1344                R455 -1
    X1344                R456 1
    X1345                OBJ 11.82
    X1345                R66 1
    X1345                R452 -1
    X1345                R457 1
    X1346                OBJ 11.82
    X1346                R66 1
    X1346                R452 1
    X1346                R457 -1
    X1347                OBJ 5.9699999999999998
    X1347                R67 1
    X1347                R453 -1
    X1347                R457 1
    X1348                OBJ 5.9699999999999998
    X1348                R67 1
    X1348                R453 1
    X1348                R457 -1
    X1349                OBJ 13.699999999999999
    X1349                R68 1
    X1349                R446 -1
    X1349                R457 1
    X1350                OBJ 13.699999999999999
    X1350                R68 1
    X1350                R446 1
    X1350                R457 -1
    X1351                OBJ 3.8300000000000001
    X1351                R69 1
    X1351                R446 -1
    X1351                R451 1
    X1352                OBJ 3.8300000000000001
    X1352                R69 1
    X1352                R446 1
    X1352                R451 -1
    X1353                OBJ 19.77
    X1353                R71 1
    X1353                R431 -1
    X1353                R458 1
    X1354                OBJ 19.77
    X1354                R71 1
    X1354                R431 1
    X1354                R458 -1
    X1355                OBJ 7.5099999999999998
    X1355                R72 1
    X1355                R437 -1
    X1355                R458 1
    X1356                OBJ 7.5099999999999998
    X1356                R72 1
    X1356                R437 1
    X1356                R458 -1
    X1357                OBJ 4.71
    X1357                R73 1
    X1357                R439 -1
    X1357                R458 1
    X1358                OBJ 4.71
    X1358                R73 1
    X1358                R439 1
    X1358                R458 -1
    X1359                OBJ 5.1399999999999997
    X1359                R74 1
    X1359                R431 1
    X1359                R449 -1
    X1360                OBJ 5.1399999999999997
    X1360                R74 1
    X1360                R431 -1
    X1360                R449 1
    X1361                OBJ 4.1100000000000003
    X1361                R76 1
    X1361                R438 -1
    X1361                R459 1
    X1362                OBJ 4.1100000000000003
    X1362                R76 1
    X1362                R438 1
    X1362                R459 -1
    X1363                OBJ 5.9400000000000004
    X1363                R77 1
    X1363                R449 -1
    X1363                R459 1
    X1364                OBJ 5.9400000000000004
    X1364                R77 1
    X1364                R449 1
    X1364                R459 -1
    X1365                OBJ 5.0700000000000003
    X1365                R79 1
    X1365                R459 1
    X1365                R460 -1
    X1366                OBJ 5.0700000000000003
    X1366                R79 1
    X1366                R459 -1
    X1366                R460 1
    X1367                OBJ 9.0700000000000003
    X1367                R81 1
    X1367                R438 1
    X1367                R461 -1
    X1368                OBJ 9.0700000000000003
    X1368                R81 1
    X1368                R438 -1
    X1368                R461 1
    X1369                OBJ 5.2199999999999998
    X1369                R83 1
    X1369                R444 -1
    X1369                R462 1
    X1370                OBJ 5.2199999999999998
    X1370                R83 1
    X1370                R444 1
    X1370                R462 -1
    X1371                OBJ 7.2000000000000002
    X1371                R84 1
    X1371                R461 -1
    X1371                R462 1
    X1372                OBJ 7.2000000000000002
    X1372                R84 1
    X1372                R461 1
    X1372                R462 -1
    X1373                OBJ 3.27
    X1373                R85 1
    X1373                R460 -1
    X1373                R462 1
    X1374                OBJ 3.27
    X1374                R85 1
    X1374                R460 1
    X1374                R462 -1
    X1375                OBJ 5.3399999999999999
    X1375                R87 1
    X1375                R444 1
    X1375                R463 -1
    X1376                OBJ 5.3399999999999999
    X1376                R87 1
    X1376                R444 -1
    X1376                R463 1
    X1377                OBJ 6.3799999999999999
    X1377                R88 1
    X1377                R433 1
    X1377                R461 -1
    X1378                OBJ 6.3799999999999999
    X1378                R88 1
    X1378                R433 -1
    X1378                R461 1
    X1379                OBJ 6
    X1379                R89 1
    X1379                R449 1
    X1379                R456 -1
    X1380                OBJ 6
    X1380                R89 1
    X1380                R449 -1
    X1380                R456 1
    X1381                OBJ 3.7599999999999998
    X1381                R90 1
    X1381                R445 1
    X1381                R463 -1
    X1382                OBJ 3.7599999999999998
    X1382                R90 1
    X1382                R445 -1
    X1382                R463 1
    X1383                OBJ 7.8300000000000001
    X1383                R91 1
    X1383                R435 -1
    X1383                R461 1
    X1384                OBJ 7.8300000000000001
    X1384                R91 1
    X1384                R435 1
    X1384                R461 -1
    X1385                OBJ 2.1800000000000002
    X1385                R92 1
    X1385                R456 1
    X1385                R460 -1
    X1386                OBJ 2.1800000000000002
    X1386                R92 1
    X1386                R456 -1
    X1386                R460 1
    X1387                OBJ 4
    X1387                R93 1
    X1387                R435 -1
    X1387                R463 1
    X1388                OBJ 4
    X1388                R93 1
    X1388                R435 1
    X1388                R463 -1
    X1389                OBJ 2.5899999999999999
    X1389                R2 1
    X1389                R464 1
    X1389                R465 -1
    X1390                OBJ 2.5899999999999999
    X1390                R2 1
    X1390                R464 -1
    X1390                R465 1
    X1391                OBJ 10.67
    X1391                R4 1
    X1391                R464 1
    X1391                R466 -1
    X1392                OBJ 10.67
    X1392                R4 1
    X1392                R464 -1
    X1392                R466 1
    X1393                OBJ 5.5199999999999996
    X1393                R6 1
    X1393                R464 1
    X1393                R467 -1
    X1394                OBJ 5.5199999999999996
    X1394                R6 1
    X1394                R464 -1
    X1394                R467 1
    X1395                OBJ 5.4000000000000004
    X1395                R8 1
    X1395                R464 1
    X1395                R468 -1
    X1396                OBJ 5.4000000000000004
    X1396                R8 1
    X1396                R464 -1
    X1396                R468 1
    X1397                OBJ 13.630000000000001
    X1397                R11 1
    X1397                R469 1
    X1397                R470 -1
    X1398                OBJ 13.630000000000001
    X1398                R11 1
    X1398                R469 -1
    X1398                R470 1
    X1399                OBJ 7.9400000000000004
    X1399                R13 1
    X1399                R469 1
    X1399                R471 -1
    X1400                OBJ 7.9400000000000004
    X1400                R13 1
    X1400                R469 -1
    X1400                R471 1
    X1401                OBJ 15
    X1401                R15 1
    X1401                R469 1
    X1401                R472 -1
    X1402                OBJ 15
    X1402                R15 1
    X1402                R469 -1
    X1402                R472 1
    X1403                OBJ 7.5999999999999996
    X1403                R18 1
    X1403                R473 1
    X1403                R474 -1
    X1404                OBJ 7.5999999999999996
    X1404                R18 1
    X1404                R473 -1
    X1404                R474 1
    X1405                OBJ 5.0800000000000001
    X1405                R20 1
    X1405                R473 1
    X1405                R475 -1
    X1406                OBJ 5.0800000000000001
    X1406                R20 1
    X1406                R473 -1
    X1406                R475 1
    X1407                OBJ 12.44
    X1407                R22 1
    X1407                R473 1
    X1407                R476 -1
    X1408                OBJ 12.44
    X1408                R22 1
    X1408                R473 -1
    X1408                R476 1
    X1409                OBJ 4.7400000000000002
    X1409                R25 1
    X1409                R477 1
    X1409                R478 -1
    X1410                OBJ 4.7400000000000002
    X1410                R25 1
    X1410                R477 -1
    X1410                R478 1
    X1411                OBJ 4.8700000000000001
    X1411                R26 1
    X1411                R471 -1
    X1411                R477 1
    X1412                OBJ 4.8700000000000001
    X1412                R26 1
    X1412                R471 1
    X1412                R477 -1
    X1413                OBJ 5.5099999999999998
    X1413                R27 1
    X1413                R472 -1
    X1413                R477 1
    X1414                OBJ 5.5099999999999998
    X1414                R27 1
    X1414                R472 1
    X1414                R477 -1
    X1415                OBJ 5.4000000000000004
    X1415                R30 1
    X1415                R479 1
    X1415                R480 -1
    X1416                OBJ 5.4000000000000004
    X1416                R30 1
    X1416                R479 -1
    X1416                R480 1
    X1417                OBJ 3.8100000000000001
    X1417                R31 1
    X1417                R467 -1
    X1417                R479 1
    X1418                OBJ 3.8100000000000001
    X1418                R31 1
    X1418                R467 1
    X1418                R479 -1
    X1419                OBJ 7.5700000000000003
    X1419                R33 1
    X1419                R479 1
    X1419                R481 -1
    X1420                OBJ 7.5700000000000003
    X1420                R33 1
    X1420                R479 -1
    X1420                R481 1
    X1421                OBJ 4.2000000000000002
    X1421                R35 1
    X1421                R479 1
    X1421                R482 -1
    X1422                OBJ 4.2000000000000002
    X1422                R35 1
    X1422                R479 -1
    X1422                R482 1
    X1423                OBJ 7.75
    X1423                R37 1
    X1423                R479 1
    X1423                R483 -1
    X1424                OBJ 7.75
    X1424                R37 1
    X1424                R479 -1
    X1424                R483 1
    X1425                OBJ 6.0999999999999996
    X1425                R39 1
    X1425                R466 -1
    X1425                R484 1
    X1426                OBJ 6.0999999999999996
    X1426                R39 1
    X1426                R466 1
    X1426                R484 -1
    X1427                OBJ 2.3900000000000001
    X1427                R40 1
    X1427                R468 -1
    X1427                R484 1
    X1428                OBJ 2.3900000000000001
    X1428                R40 1
    X1428                R468 1
    X1428                R484 -1
    X1429                OBJ 8.3399999999999999
    X1429                R42 1
    X1429                R474 -1
    X1429                R485 1
    X1430                OBJ 8.3399999999999999
    X1430                R42 1
    X1430                R474 1
    X1430                R485 -1
    X1431                OBJ 7.5599999999999996
    X1431                R43 1
    X1431                R475 -1
    X1431                R485 1
    X1432                OBJ 7.5599999999999996
    X1432                R43 1
    X1432                R475 1
    X1432                R485 -1
    X1433                OBJ 7.4699999999999998
    X1433                R45 1
    X1433                R485 1
    X1433                R486 -1
    X1434                OBJ 7.4699999999999998
    X1434                R45 1
    X1434                R485 -1
    X1434                R486 1
    X1435                OBJ 2.6400000000000001
    X1435                R47 1
    X1435                R465 1
    X1435                R487 -1
    X1436                OBJ 2.6400000000000001
    X1436                R47 1
    X1436                R465 -1
    X1436                R487 1
    X1437                OBJ 3.9300000000000002
    X1437                R48 1
    X1437                R465 1
    X1437                R486 -1
    X1438                OBJ 3.9300000000000002
    X1438                R48 1
    X1438                R465 -1
    X1438                R486 1
    X1439                OBJ 4.3600000000000003
    X1439                R50 1
    X1439                R478 1
    X1439                R488 -1
    X1440                OBJ 4.3600000000000003
    X1440                R50 1
    X1440                R478 -1
    X1440                R488 1
    X1441                OBJ 6.6799999999999997
    X1441                R51 1
    X1441                R478 1
    X1441                R482 -1
    X1442                OBJ 6.6799999999999997
    X1442                R51 1
    X1442                R478 -1
    X1442                R482 1
    X1443                OBJ 7.2199999999999998
    X1443                R53 1
    X1443                R480 1
    X1443                R489 -1
    X1444                OBJ 7.2199999999999998
    X1444                R53 1
    X1444                R480 -1
    X1444                R489 1
    X1445                OBJ 7.7699999999999996
    X1445                R55 1
    X1445                R480 1
    X1445                R490 -1
    X1446                OBJ 7.7699999999999996
    X1446                R55 1
    X1446                R480 -1
    X1446                R490 1
    X1447                OBJ 4.6200000000000001
    X1447                R57 1
    X1447                R466 -1
    X1447                R491 1
    X1448                OBJ 4.6200000000000001
    X1448                R57 1
    X1448                R466 1
    X1448                R491 -1
    X1449                OBJ 6.9000000000000004
    X1449                R58 1
    X1449                R468 -1
    X1449                R491 1
    X1450                OBJ 6.9000000000000004
    X1450                R58 1
    X1450                R468 1
    X1450                R491 -1
    X1451                OBJ 2.75
    X1451                R60 1
    X1451                R487 1
    X1451                R492 -1
    X1452                OBJ 2.75
    X1452                R60 1
    X1452                R487 -1
    X1452                R492 1
    X1453                OBJ 5.9199999999999999
    X1453                R61 1
    X1453                R467 -1
    X1453                R492 1
    X1454                OBJ 5.9199999999999999
    X1454                R61 1
    X1454                R467 1
    X1454                R492 -1
    X1455                OBJ 4.5599999999999996
    X1455                R62 1
    X1455                R481 -1
    X1455                R492 1
    X1456                OBJ 4.5599999999999996
    X1456                R62 1
    X1456                R481 1
    X1456                R492 -1
    X1457                OBJ 2.71
    X1457                R64 1
    X1457                R492 1
    X1457                R493 -1
    X1458                OBJ 2.71
    X1458                R64 1
    X1458                R492 -1
    X1458                R493 1
    X1459                OBJ 11.82
    X1459                R66 1
    X1459                R489 -1
    X1459                R494 1
    X1460                OBJ 11.82
    X1460                R66 1
    X1460                R489 1
    X1460                R494 -1
    X1461                OBJ 5.9699999999999998
    X1461                R67 1
    X1461                R490 -1
    X1461                R494 1
    X1462                OBJ 5.9699999999999998
    X1462                R67 1
    X1462                R490 1
    X1462                R494 -1
    X1463                OBJ 13.699999999999999
    X1463                R68 1
    X1463                R483 -1
    X1463                R494 1
    X1464                OBJ 13.699999999999999
    X1464                R68 1
    X1464                R483 1
    X1464                R494 -1
    X1465                OBJ 3.8300000000000001
    X1465                R69 1
    X1465                R483 -1
    X1465                R488 1
    X1466                OBJ 3.8300000000000001
    X1466                R69 1
    X1466                R483 1
    X1466                R488 -1
    X1467                OBJ 19.77
    X1467                R71 1
    X1467                R468 -1
    X1467                R495 1
    X1468                OBJ 19.77
    X1468                R71 1
    X1468                R468 1
    X1468                R495 -1
    X1469                OBJ 7.5099999999999998
    X1469                R72 1
    X1469                R474 -1
    X1469                R495 1
    X1470                OBJ 7.5099999999999998
    X1470                R72 1
    X1470                R474 1
    X1470                R495 -1
    X1471                OBJ 4.71
    X1471                R73 1
    X1471                R476 -1
    X1471                R495 1
    X1472                OBJ 4.71
    X1472                R73 1
    X1472                R476 1
    X1472                R495 -1
    X1473                OBJ 5.1399999999999997
    X1473                R74 1
    X1473                R468 1
    X1473                R486 -1
    X1474                OBJ 5.1399999999999997
    X1474                R74 1
    X1474                R468 -1
    X1474                R486 1
    X1475                OBJ 4.1100000000000003
    X1475                R76 1
    X1475                R475 -1
    X1475                R496 1
    X1476                OBJ 4.1100000000000003
    X1476                R76 1
    X1476                R475 1
    X1476                R496 -1
    X1477                OBJ 5.9400000000000004
    X1477                R77 1
    X1477                R486 -1
    X1477                R496 1
    X1478                OBJ 5.9400000000000004
    X1478                R77 1
    X1478                R486 1
    X1478                R496 -1
    X1479                OBJ 5.0700000000000003
    X1479                R79 1
    X1479                R496 1
    X1479                R497 -1
    X1480                OBJ 5.0700000000000003
    X1480                R79 1
    X1480                R496 -1
    X1480                R497 1
    X1481                OBJ 9.0700000000000003
    X1481                R81 1
    X1481                R475 1
    X1481                R498 -1
    X1482                OBJ 9.0700000000000003
    X1482                R81 1
    X1482                R475 -1
    X1482                R498 1
    X1483                OBJ 5.2199999999999998
    X1483                R83 1
    X1483                R481 -1
    X1483                R499 1
    X1484                OBJ 7.2000000000000002
    X1484                R84 1
    X1484                R498 -1
    X1484                R499 1
    X1485                OBJ 3.27
    X1485                R85 1
    X1485                R497 -1
    X1485                R499 1
    X1486                OBJ 5.3399999999999999
    X1486                R87 1
    X1486                R481 1
    X1486                R500 -1
    X1487                OBJ 5.3399999999999999
    X1487                R87 1
    X1487                R481 -1
    X1487                R500 1
    X1488                OBJ 6.3799999999999999
    X1488                R88 1
    X1488                R470 1
    X1488                R498 -1
    X1489                OBJ 6.3799999999999999
    X1489                R88 1
    X1489                R470 -1
    X1489                R498 1
    X1490                OBJ 6
    X1490                R89 1
    X1490                R486 1
    X1490                R493 -1
    X1491                OBJ 6
    X1491                R89 1
    X1491                R486 -1
    X1491                R493 1
    X1492                OBJ 3.7599999999999998
    X1492                R90 1
    X1492                R482 1
    X1492                R500 -1
    X1493                OBJ 3.7599999999999998
    X1493                R90 1
    X1493                R482 -1
    X1493                R500 1
    X1494                OBJ 7.8300000000000001
    X1494                R91 1
    X1494                R472 -1
    X1494                R498 1
    X1495                OBJ 7.8300000000000001
    X1495                R91 1
    X1495                R472 1
    X1495                R498 -1
    X1496                OBJ 2.1800000000000002
    X1496                R92 1
    X1496                R493 1
    X1496                R497 -1
    X1497                OBJ 2.1800000000000002
    X1497                R92 1
    X1497                R493 -1
    X1497                R497 1
    X1498                OBJ 4
    X1498                R93 1
    X1498                R472 -1
    X1498                R500 1
    X1499                OBJ 4
    X1499                R93 1
    X1499                R472 1
    X1499                R500 -1
    X1500                OBJ 2.5899999999999999
    X1500                R2 1
    X1500                R501 -1
    X1500                R502 1
    X1501                OBJ 10.67
    X1501                R4 1
    X1501                R501 1
    X1501                R503 -1
    X1502                OBJ 10.67
    X1502                R4 1
    X1502                R501 -1
    X1502                R503 1
    X1503                OBJ 5.5199999999999996
    X1503                R6 1
    X1503                R501 1
    X1503                R504 -1
    X1504                OBJ 5.5199999999999996
    X1504                R6 1
    X1504                R501 -1
    X1504                R504 1
    X1505                OBJ 5.4000000000000004
    X1505                R8 1
    X1505                R501 1
    X1505                R505 -1
    X1506                OBJ 5.4000000000000004
    X1506                R8 1
    X1506                R501 -1
    X1506                R505 1
    X1507                OBJ 13.630000000000001
    X1507                R11 1
    X1507                R506 1
    X1507                R507 -1
    X1508                OBJ 13.630000000000001
    X1508                R11 1
    X1508                R506 -1
    X1508                R507 1
    X1509                OBJ 7.9400000000000004
    X1509                R13 1
    X1509                R506 1
    X1509                R508 -1
    X1510                OBJ 7.9400000000000004
    X1510                R13 1
    X1510                R506 -1
    X1510                R508 1
    X1511                OBJ 15
    X1511                R15 1
    X1511                R506 1
    X1511                R509 -1
    X1512                OBJ 15
    X1512                R15 1
    X1512                R506 -1
    X1512                R509 1
    X1513                OBJ 7.5999999999999996
    X1513                R18 1
    X1513                R510 1
    X1513                R511 -1
    X1514                OBJ 7.5999999999999996
    X1514                R18 1
    X1514                R510 -1
    X1514                R511 1
    X1515                OBJ 5.0800000000000001
    X1515                R20 1
    X1515                R510 1
    X1515                R512 -1
    X1516                OBJ 5.0800000000000001
    X1516                R20 1
    X1516                R510 -1
    X1516                R512 1
    X1517                OBJ 12.44
    X1517                R22 1
    X1517                R510 1
    X1517                R513 -1
    X1518                OBJ 12.44
    X1518                R22 1
    X1518                R510 -1
    X1518                R513 1
    X1519                OBJ 4.7400000000000002
    X1519                R25 1
    X1519                R514 1
    X1519                R515 -1
    X1520                OBJ 4.7400000000000002
    X1520                R25 1
    X1520                R514 -1
    X1520                R515 1
    X1521                OBJ 4.8700000000000001
    X1521                R26 1
    X1521                R508 -1
    X1521                R514 1
    X1522                OBJ 4.8700000000000001
    X1522                R26 1
    X1522                R508 1
    X1522                R514 -1
    X1523                OBJ 5.5099999999999998
    X1523                R27 1
    X1523                R509 -1
    X1523                R514 1
    X1524                OBJ 5.5099999999999998
    X1524                R27 1
    X1524                R509 1
    X1524                R514 -1
    X1525                OBJ 5.4000000000000004
    X1525                R30 1
    X1525                R516 1
    X1525                R517 -1
    X1526                OBJ 5.4000000000000004
    X1526                R30 1
    X1526                R516 -1
    X1526                R517 1
    X1527                OBJ 3.8100000000000001
    X1527                R31 1
    X1527                R504 -1
    X1527                R516 1
    X1528                OBJ 3.8100000000000001
    X1528                R31 1
    X1528                R504 1
    X1528                R516 -1
    X1529                OBJ 7.5700000000000003
    X1529                R33 1
    X1529                R516 1
    X1529                R518 -1
    X1530                OBJ 7.5700000000000003
    X1530                R33 1
    X1530                R516 -1
    X1530                R518 1
    X1531                OBJ 4.2000000000000002
    X1531                R35 1
    X1531                R516 1
    X1531                R519 -1
    X1532                OBJ 4.2000000000000002
    X1532                R35 1
    X1532                R516 -1
    X1532                R519 1
    X1533                OBJ 7.75
    X1533                R37 1
    X1533                R516 1
    X1533                R520 -1
    X1534                OBJ 7.75
    X1534                R37 1
    X1534                R516 -1
    X1534                R520 1
    X1535                OBJ 6.0999999999999996
    X1535                R39 1
    X1535                R503 -1
    X1535                R521 1
    X1536                OBJ 6.0999999999999996
    X1536                R39 1
    X1536                R503 1
    X1536                R521 -1
    X1537                OBJ 2.3900000000000001
    X1537                R40 1
    X1537                R505 -1
    X1537                R521 1
    X1538                OBJ 2.3900000000000001
    X1538                R40 1
    X1538                R505 1
    X1538                R521 -1
    X1539                OBJ 8.3399999999999999
    X1539                R42 1
    X1539                R511 -1
    X1539                R522 1
    X1540                OBJ 8.3399999999999999
    X1540                R42 1
    X1540                R511 1
    X1540                R522 -1
    X1541                OBJ 7.5599999999999996
    X1541                R43 1
    X1541                R512 -1
    X1541                R522 1
    X1542                OBJ 7.5599999999999996
    X1542                R43 1
    X1542                R512 1
    X1542                R522 -1
    X1543                OBJ 7.4699999999999998
    X1543                R45 1
    X1543                R522 1
    X1543                R523 -1
    X1544                OBJ 7.4699999999999998
    X1544                R45 1
    X1544                R522 -1
    X1544                R523 1
    X1545                OBJ 2.6400000000000001
    X1545                R47 1
    X1545                R502 1
    X1545                R524 -1
    X1546                OBJ 3.9300000000000002
    X1546                R48 1
    X1546                R502 1
    X1546                R523 -1
    X1547                OBJ 4.3600000000000003
    X1547                R50 1
    X1547                R515 1
    X1547                R525 -1
    X1548                OBJ 4.3600000000000003
    X1548                R50 1
    X1548                R515 -1
    X1548                R525 1
    X1549                OBJ 6.6799999999999997
    X1549                R51 1
    X1549                R515 1
    X1549                R519 -1
    X1550                OBJ 6.6799999999999997
    X1550                R51 1
    X1550                R515 -1
    X1550                R519 1
    X1551                OBJ 7.2199999999999998
    X1551                R53 1
    X1551                R517 1
    X1551                R526 -1
    X1552                OBJ 7.2199999999999998
    X1552                R53 1
    X1552                R517 -1
    X1552                R526 1
    X1553                OBJ 7.7699999999999996
    X1553                R55 1
    X1553                R517 1
    X1553                R527 -1
    X1554                OBJ 7.7699999999999996
    X1554                R55 1
    X1554                R517 -1
    X1554                R527 1
    X1555                OBJ 4.6200000000000001
    X1555                R57 1
    X1555                R503 -1
    X1555                R528 1
    X1556                OBJ 4.6200000000000001
    X1556                R57 1
    X1556                R503 1
    X1556                R528 -1
    X1557                OBJ 6.9000000000000004
    X1557                R58 1
    X1557                R505 -1
    X1557                R528 1
    X1558                OBJ 6.9000000000000004
    X1558                R58 1
    X1558                R505 1
    X1558                R528 -1
    X1559                OBJ 2.75
    X1559                R60 1
    X1559                R524 1
    X1559                R529 -1
    X1560                OBJ 2.75
    X1560                R60 1
    X1560                R524 -1
    X1560                R529 1
    X1561                OBJ 5.9199999999999999
    X1561                R61 1
    X1561                R504 -1
    X1561                R529 1
    X1562                OBJ 5.9199999999999999
    X1562                R61 1
    X1562                R504 1
    X1562                R529 -1
    X1563                OBJ 4.5599999999999996
    X1563                R62 1
    X1563                R518 -1
    X1563                R529 1
    X1564                OBJ 4.5599999999999996
    X1564                R62 1
    X1564                R518 1
    X1564                R529 -1
    X1565                OBJ 2.71
    X1565                R64 1
    X1565                R529 1
    X1565                R530 -1
    X1566                OBJ 2.71
    X1566                R64 1
    X1566                R529 -1
    X1566                R530 1
    X1567                OBJ 11.82
    X1567                R66 1
    X1567                R526 -1
    X1567                R531 1
    X1568                OBJ 11.82
    X1568                R66 1
    X1568                R526 1
    X1568                R531 -1
    X1569                OBJ 5.9699999999999998
    X1569                R67 1
    X1569                R527 -1
    X1569                R531 1
    X1570                OBJ 5.9699999999999998
    X1570                R67 1
    X1570                R527 1
    X1570                R531 -1
    X1571                OBJ 13.699999999999999
    X1571                R68 1
    X1571                R520 -1
    X1571                R531 1
    X1572                OBJ 13.699999999999999
    X1572                R68 1
    X1572                R520 1
    X1572                R531 -1
    X1573                OBJ 3.8300000000000001
    X1573                R69 1
    X1573                R520 -1
    X1573                R525 1
    X1574                OBJ 3.8300000000000001
    X1574                R69 1
    X1574                R520 1
    X1574                R525 -1
    X1575                OBJ 19.77
    X1575                R71 1
    X1575                R505 -1
    X1575                R532 1
    X1576                OBJ 19.77
    X1576                R71 1
    X1576                R505 1
    X1576                R532 -1
    X1577                OBJ 7.5099999999999998
    X1577                R72 1
    X1577                R511 -1
    X1577                R532 1
    X1578                OBJ 7.5099999999999998
    X1578                R72 1
    X1578                R511 1
    X1578                R532 -1
    X1579                OBJ 4.71
    X1579                R73 1
    X1579                R513 -1
    X1579                R532 1
    X1580                OBJ 4.71
    X1580                R73 1
    X1580                R513 1
    X1580                R532 -1
    X1581                OBJ 5.1399999999999997
    X1581                R74 1
    X1581                R505 1
    X1581                R523 -1
    X1582                OBJ 5.1399999999999997
    X1582                R74 1
    X1582                R505 -1
    X1582                R523 1
    X1583                OBJ 4.1100000000000003
    X1583                R76 1
    X1583                R512 -1
    X1583                R533 1
    X1584                OBJ 4.1100000000000003
    X1584                R76 1
    X1584                R512 1
    X1584                R533 -1
    X1585                OBJ 5.9400000000000004
    X1585                R77 1
    X1585                R523 -1
    X1585                R533 1
    X1586                OBJ 5.9400000000000004
    X1586                R77 1
    X1586                R523 1
    X1586                R533 -1
    X1587                OBJ 5.0700000000000003
    X1587                R79 1
    X1587                R533 1
    X1587                R534 -1
    X1588                OBJ 5.0700000000000003
    X1588                R79 1
    X1588                R533 -1
    X1588                R534 1
    X1589                OBJ 9.0700000000000003
    X1589                R81 1
    X1589                R512 1
    X1589                R535 -1
    X1590                OBJ 9.0700000000000003
    X1590                R81 1
    X1590                R512 -1
    X1590                R535 1
    X1591                OBJ 5.2199999999999998
    X1591                R83 1
    X1591                R518 -1
    X1591                R536 1
    X1592                OBJ 5.2199999999999998
    X1592                R83 1
    X1592                R518 1
    X1592                R536 -1
    X1593                OBJ 7.2000000000000002
    X1593                R84 1
    X1593                R535 -1
    X1593                R536 1
    X1594                OBJ 7.2000000000000002
    X1594                R84 1
    X1594                R535 1
    X1594                R536 -1
    X1595                OBJ 3.27
    X1595                R85 1
    X1595                R534 -1
    X1595                R536 1
    X1596                OBJ 3.27
    X1596                R85 1
    X1596                R534 1
    X1596                R536 -1
    X1597                OBJ 5.3399999999999999
    X1597                R87 1
    X1597                R518 1
    X1597                R537 -1
    X1598                OBJ 5.3399999999999999
    X1598                R87 1
    X1598                R518 -1
    X1598                R537 1
    X1599                OBJ 6.3799999999999999
    X1599                R88 1
    X1599                R507 1
    X1599                R535 -1
    X1600                OBJ 6.3799999999999999
    X1600                R88 1
    X1600                R507 -1
    X1600                R535 1
    X1601                OBJ 6
    X1601                R89 1
    X1601                R523 1
    X1601                R530 -1
    X1602                OBJ 6
    X1602                R89 1
    X1602                R523 -1
    X1602                R530 1
    X1603                OBJ 3.7599999999999998
    X1603                R90 1
    X1603                R519 1
    X1603                R537 -1
    X1604                OBJ 3.7599999999999998
    X1604                R90 1
    X1604                R519 -1
    X1604                R537 1
    X1605                OBJ 7.8300000000000001
    X1605                R91 1
    X1605                R509 -1
    X1605                R535 1
    X1606                OBJ 7.8300000000000001
    X1606                R91 1
    X1606                R509 1
    X1606                R535 -1
    X1607                OBJ 2.1800000000000002
    X1607                R92 1
    X1607                R530 1
    X1607                R534 -1
    X1608                OBJ 2.1800000000000002
    X1608                R92 1
    X1608                R530 -1
    X1608                R534 1
    X1609                OBJ 4
    X1609                R93 1
    X1609                R509 -1
    X1609                R537 1
    X1610                OBJ 4
    X1610                R93 1
    X1610                R509 1
    X1610                R537 -1
    X1611                OBJ 2.5899999999999999
    X1611                R2 1
    X1611                R538 1
    X1611                R539 -1
    X1612                OBJ 2.5899999999999999
    X1612                R2 1
    X1612                R538 -1
    X1612                R539 1
    X1613                OBJ 10.67
    X1613                R4 1
    X1613                R538 1
    X1613                R540 -1
    X1614                OBJ 10.67
    X1614                R4 1
    X1614                R538 -1
    X1614                R540 1
    X1615                OBJ 5.5199999999999996
    X1615                R6 1
    X1615                R538 1
    X1615                R541 -1
    X1616                OBJ 5.5199999999999996
    X1616                R6 1
    X1616                R538 -1
    X1616                R541 1
    X1617                OBJ 5.4000000000000004
    X1617                R8 1
    X1617                R538 1
    X1617                R542 -1
    X1618                OBJ 5.4000000000000004
    X1618                R8 1
    X1618                R538 -1
    X1618                R542 1
    X1619                OBJ 13.630000000000001
    X1619                R11 1
    X1619                R543 1
    X1619                R544 -1
    X1620                OBJ 13.630000000000001
    X1620                R11 1
    X1620                R543 -1
    X1620                R544 1
    X1621                OBJ 7.9400000000000004
    X1621                R13 1
    X1621                R543 1
    X1621                R545 -1
    X1622                OBJ 7.9400000000000004
    X1622                R13 1
    X1622                R543 -1
    X1622                R545 1
    X1623                OBJ 15
    X1623                R15 1
    X1623                R543 1
    X1623                R546 -1
    X1624                OBJ 15
    X1624                R15 1
    X1624                R543 -1
    X1624                R546 1
    X1625                OBJ 7.5999999999999996
    X1625                R18 1
    X1625                R547 1
    X1625                R548 -1
    X1626                OBJ 7.5999999999999996
    X1626                R18 1
    X1626                R547 -1
    X1626                R548 1
    X1627                OBJ 5.0800000000000001
    X1627                R20 1
    X1627                R547 1
    X1627                R549 -1
    X1628                OBJ 5.0800000000000001
    X1628                R20 1
    X1628                R547 -1
    X1628                R549 1
    X1629                OBJ 12.44
    X1629                R22 1
    X1629                R547 1
    X1629                R550 -1
    X1630                OBJ 12.44
    X1630                R22 1
    X1630                R547 -1
    X1630                R550 1
    X1631                OBJ 4.7400000000000002
    X1631                R25 1
    X1631                R551 1
    X1631                R552 -1
    X1632                OBJ 4.7400000000000002
    X1632                R25 1
    X1632                R551 -1
    X1632                R552 1
    X1633                OBJ 4.8700000000000001
    X1633                R26 1
    X1633                R545 -1
    X1633                R551 1
    X1634                OBJ 4.8700000000000001
    X1634                R26 1
    X1634                R545 1
    X1634                R551 -1
    X1635                OBJ 5.5099999999999998
    X1635                R27 1
    X1635                R546 -1
    X1635                R551 1
    X1636                OBJ 5.5099999999999998
    X1636                R27 1
    X1636                R546 1
    X1636                R551 -1
    X1637                OBJ 5.4000000000000004
    X1637                R30 1
    X1637                R553 1
    X1637                R554 -1
    X1638                OBJ 5.4000000000000004
    X1638                R30 1
    X1638                R553 -1
    X1638                R554 1
    X1639                OBJ 3.8100000000000001
    X1639                R31 1
    X1639                R541 -1
    X1639                R553 1
    X1640                OBJ 3.8100000000000001
    X1640                R31 1
    X1640                R541 1
    X1640                R553 -1
    X1641                OBJ 7.5700000000000003
    X1641                R33 1
    X1641                R553 -1
    X1641                R555 1
    X1642                OBJ 4.2000000000000002
    X1642                R35 1
    X1642                R553 1
    X1642                R556 -1
    X1643                OBJ 4.2000000000000002
    X1643                R35 1
    X1643                R553 -1
    X1643                R556 1
    X1644                OBJ 7.75
    X1644                R37 1
    X1644                R553 1
    X1644                R557 -1
    X1645                OBJ 7.75
    X1645                R37 1
    X1645                R553 -1
    X1645                R557 1
    X1646                OBJ 6.0999999999999996
    X1646                R39 1
    X1646                R540 -1
    X1646                R558 1
    X1647                OBJ 6.0999999999999996
    X1647                R39 1
    X1647                R540 1
    X1647                R558 -1
    X1648                OBJ 2.3900000000000001
    X1648                R40 1
    X1648                R542 -1
    X1648                R558 1
    X1649                OBJ 2.3900000000000001
    X1649                R40 1
    X1649                R542 1
    X1649                R558 -1
    X1650                OBJ 8.3399999999999999
    X1650                R42 1
    X1650                R548 -1
    X1650                R559 1
    X1651                OBJ 8.3399999999999999
    X1651                R42 1
    X1651                R548 1
    X1651                R559 -1
    X1652                OBJ 7.5599999999999996
    X1652                R43 1
    X1652                R549 -1
    X1652                R559 1
    X1653                OBJ 7.5599999999999996
    X1653                R43 1
    X1653                R549 1
    X1653                R559 -1
    X1654                OBJ 7.4699999999999998
    X1654                R45 1
    X1654                R559 1
    X1654                R560 -1
    X1655                OBJ 7.4699999999999998
    X1655                R45 1
    X1655                R559 -1
    X1655                R560 1
    X1656                OBJ 2.6400000000000001
    X1656                R47 1
    X1656                R539 1
    X1656                R561 -1
    X1657                OBJ 2.6400000000000001
    X1657                R47 1
    X1657                R539 -1
    X1657                R561 1
    X1658                OBJ 3.9300000000000002
    X1658                R48 1
    X1658                R539 1
    X1658                R560 -1
    X1659                OBJ 3.9300000000000002
    X1659                R48 1
    X1659                R539 -1
    X1659                R560 1
    X1660                OBJ 4.3600000000000003
    X1660                R50 1
    X1660                R552 1
    X1660                R562 -1
    X1661                OBJ 4.3600000000000003
    X1661                R50 1
    X1661                R552 -1
    X1661                R562 1
    X1662                OBJ 6.6799999999999997
    X1662                R51 1
    X1662                R552 1
    X1662                R556 -1
    X1663                OBJ 6.6799999999999997
    X1663                R51 1
    X1663                R552 -1
    X1663                R556 1
    X1664                OBJ 7.2199999999999998
    X1664                R53 1
    X1664                R554 1
    X1664                R563 -1
    X1665                OBJ 7.2199999999999998
    X1665                R53 1
    X1665                R554 -1
    X1665                R563 1
    X1666                OBJ 7.7699999999999996
    X1666                R55 1
    X1666                R554 1
    X1666                R564 -1
    X1667                OBJ 7.7699999999999996
    X1667                R55 1
    X1667                R554 -1
    X1667                R564 1
    X1668                OBJ 4.6200000000000001
    X1668                R57 1
    X1668                R540 -1
    X1668                R565 1
    X1669                OBJ 4.6200000000000001
    X1669                R57 1
    X1669                R540 1
    X1669                R565 -1
    X1670                OBJ 6.9000000000000004
    X1670                R58 1
    X1670                R542 -1
    X1670                R565 1
    X1671                OBJ 6.9000000000000004
    X1671                R58 1
    X1671                R542 1
    X1671                R565 -1
    X1672                OBJ 2.75
    X1672                R60 1
    X1672                R561 1
    X1672                R566 -1
    X1673                OBJ 2.75
    X1673                R60 1
    X1673                R561 -1
    X1673                R566 1
    X1674                OBJ 5.9199999999999999
    X1674                R61 1
    X1674                R541 -1
    X1674                R566 1
    X1675                OBJ 5.9199999999999999
    X1675                R61 1
    X1675                R541 1
    X1675                R566 -1
    X1676                OBJ 4.5599999999999996
    X1676                R62 1
    X1676                R555 1
    X1676                R566 -1
    X1677                OBJ 2.71
    X1677                R64 1
    X1677                R566 1
    X1677                R567 -1
    X1678                OBJ 2.71
    X1678                R64 1
    X1678                R566 -1
    X1678                R567 1
    X1679                OBJ 11.82
    X1679                R66 1
    X1679                R563 -1
    X1679                R568 1
    X1680                OBJ 11.82
    X1680                R66 1
    X1680                R563 1
    X1680                R568 -1
    X1681                OBJ 5.9699999999999998
    X1681                R67 1
    X1681                R564 -1
    X1681                R568 1
    X1682                OBJ 5.9699999999999998
    X1682                R67 1
    X1682                R564 1
    X1682                R568 -1
    X1683                OBJ 13.699999999999999
    X1683                R68 1
    X1683                R557 -1
    X1683                R568 1
    X1684                OBJ 13.699999999999999
    X1684                R68 1
    X1684                R557 1
    X1684                R568 -1
    X1685                OBJ 3.8300000000000001
    X1685                R69 1
    X1685                R557 -1
    X1685                R562 1
    X1686                OBJ 3.8300000000000001
    X1686                R69 1
    X1686                R557 1
    X1686                R562 -1
    X1687                OBJ 19.77
    X1687                R71 1
    X1687                R542 -1
    X1687                R569 1
    X1688                OBJ 19.77
    X1688                R71 1
    X1688                R542 1
    X1688                R569 -1
    X1689                OBJ 7.5099999999999998
    X1689                R72 1
    X1689                R548 -1
    X1689                R569 1
    X1690                OBJ 7.5099999999999998
    X1690                R72 1
    X1690                R548 1
    X1690                R569 -1
    X1691                OBJ 4.71
    X1691                R73 1
    X1691                R550 -1
    X1691                R569 1
    X1692                OBJ 4.71
    X1692                R73 1
    X1692                R550 1
    X1692                R569 -1
    X1693                OBJ 5.1399999999999997
    X1693                R74 1
    X1693                R542 1
    X1693                R560 -1
    X1694                OBJ 5.1399999999999997
    X1694                R74 1
    X1694                R542 -1
    X1694                R560 1
    X1695                OBJ 4.1100000000000003
    X1695                R76 1
    X1695                R549 -1
    X1695                R570 1
    X1696                OBJ 4.1100000000000003
    X1696                R76 1
    X1696                R549 1
    X1696                R570 -1
    X1697                OBJ 5.9400000000000004
    X1697                R77 1
    X1697                R560 -1
    X1697                R570 1
    X1698                OBJ 5.9400000000000004
    X1698                R77 1
    X1698                R560 1
    X1698                R570 -1
    X1699                OBJ 5.0700000000000003
    X1699                R79 1
    X1699                R570 1
    X1699                R571 -1
    X1700                OBJ 5.0700000000000003
    X1700                R79 1
    X1700                R570 -1
    X1700                R571 1
    X1701                OBJ 9.0700000000000003
    X1701                R81 1
    X1701                R549 1
    X1701                R572 -1
    X1702                OBJ 9.0700000000000003
    X1702                R81 1
    X1702                R549 -1
    X1702                R572 1
    X1703                OBJ 5.2199999999999998
    X1703                R83 1
    X1703                R555 1
    X1703                R573 -1
    X1704                OBJ 7.2000000000000002
    X1704                R84 1
    X1704                R572 -1
    X1704                R573 1
    X1705                OBJ 7.2000000000000002
    X1705                R84 1
    X1705                R572 1
    X1705                R573 -1
    X1706                OBJ 3.27
    X1706                R85 1
    X1706                R571 -1
    X1706                R573 1
    X1707                OBJ 3.27
    X1707                R85 1
    X1707                R571 1
    X1707                R573 -1
    X1708                OBJ 5.3399999999999999
    X1708                R87 1
    X1708                R555 1
    X1708                R574 -1
    X1709                OBJ 6.3799999999999999
    X1709                R88 1
    X1709                R544 1
    X1709                R572 -1
    X1710                OBJ 6.3799999999999999
    X1710                R88 1
    X1710                R544 -1
    X1710                R572 1
    X1711                OBJ 6
    X1711                R89 1
    X1711                R560 1
    X1711                R567 -1
    X1712                OBJ 6
    X1712                R89 1
    X1712                R560 -1
    X1712                R567 1
    X1713                OBJ 3.7599999999999998
    X1713                R90 1
    X1713                R556 1
    X1713                R574 -1
    X1714                OBJ 3.7599999999999998
    X1714                R90 1
    X1714                R556 -1
    X1714                R574 1
    X1715                OBJ 7.8300000000000001
    X1715                R91 1
    X1715                R546 -1
    X1715                R572 1
    X1716                OBJ 7.8300000000000001
    X1716                R91 1
    X1716                R546 1
    X1716                R572 -1
    X1717                OBJ 2.1800000000000002
    X1717                R92 1
    X1717                R567 1
    X1717                R571 -1
    X1718                OBJ 2.1800000000000002
    X1718                R92 1
    X1718                R567 -1
    X1718                R571 1
    X1719                OBJ 4
    X1719                R93 1
    X1719                R546 -1
    X1719                R574 1
    X1720                OBJ 4
    X1720                R93 1
    X1720                R546 1
    X1720                R574 -1
    X1721                OBJ 2.5899999999999999
    X1721                R2 1
    X1721                R575 1
    X1721                R576 -1
    X1722                OBJ 2.5899999999999999
    X1722                R2 1
    X1722                R575 -1
    X1722                R576 1
    X1723                OBJ 10.67
    X1723                R4 1
    X1723                R575 1
    X1723                R577 -1
    X1724                OBJ 10.67
    X1724                R4 1
    X1724                R575 -1
    X1724                R577 1
    X1725                OBJ 5.5199999999999996
    X1725                R6 1
    X1725                R575 1
    X1725                R578 -1
    X1726                OBJ 5.5199999999999996
    X1726                R6 1
    X1726                R575 -1
    X1726                R578 1
    X1727                OBJ 5.4000000000000004
    X1727                R8 1
    X1727                R575 1
    X1727                R579 -1
    X1728                OBJ 5.4000000000000004
    X1728                R8 1
    X1728                R575 -1
    X1728                R579 1
    X1729                OBJ 13.630000000000001
    X1729                R11 1
    X1729                R580 1
    X1729                R581 -1
    X1730                OBJ 13.630000000000001
    X1730                R11 1
    X1730                R580 -1
    X1730                R581 1
    X1731                OBJ 7.9400000000000004
    X1731                R13 1
    X1731                R580 1
    X1731                R582 -1
    X1732                OBJ 7.9400000000000004
    X1732                R13 1
    X1732                R580 -1
    X1732                R582 1
    X1733                OBJ 15
    X1733                R15 1
    X1733                R580 1
    X1733                R583 -1
    X1734                OBJ 15
    X1734                R15 1
    X1734                R580 -1
    X1734                R583 1
    X1735                OBJ 7.5999999999999996
    X1735                R18 1
    X1735                R584 1
    X1735                R585 -1
    X1736                OBJ 7.5999999999999996
    X1736                R18 1
    X1736                R584 -1
    X1736                R585 1
    X1737                OBJ 5.0800000000000001
    X1737                R20 1
    X1737                R584 1
    X1737                R586 -1
    X1738                OBJ 5.0800000000000001
    X1738                R20 1
    X1738                R584 -1
    X1738                R586 1
    X1739                OBJ 12.44
    X1739                R22 1
    X1739                R584 1
    X1739                R587 -1
    X1740                OBJ 12.44
    X1740                R22 1
    X1740                R584 -1
    X1740                R587 1
    X1741                OBJ 4.7400000000000002
    X1741                R25 1
    X1741                R588 -1
    X1741                R589 1
    X1742                OBJ 4.8700000000000001
    X1742                R26 1
    X1742                R582 -1
    X1742                R588 1
    X1743                OBJ 4.8700000000000001
    X1743                R26 1
    X1743                R582 1
    X1743                R588 -1
    X1744                OBJ 5.5099999999999998
    X1744                R27 1
    X1744                R583 -1
    X1744                R588 1
    X1745                OBJ 5.5099999999999998
    X1745                R27 1
    X1745                R583 1
    X1745                R588 -1
    X1746                OBJ 5.4000000000000004
    X1746                R30 1
    X1746                R590 1
    X1746                R591 -1
    X1747                OBJ 5.4000000000000004
    X1747                R30 1
    X1747                R590 -1
    X1747                R591 1
    X1748                OBJ 3.8100000000000001
    X1748                R31 1
    X1748                R578 -1
    X1748                R590 1
    X1749                OBJ 3.8100000000000001
    X1749                R31 1
    X1749                R578 1
    X1749                R590 -1
    X1750                OBJ 7.5700000000000003
    X1750                R33 1
    X1750                R590 1
    X1750                R592 -1
    X1751                OBJ 7.5700000000000003
    X1751                R33 1
    X1751                R590 -1
    X1751                R592 1
    X1752                OBJ 4.2000000000000002
    X1752                R35 1
    X1752                R590 1
    X1752                R593 -1
    X1753                OBJ 4.2000000000000002
    X1753                R35 1
    X1753                R590 -1
    X1753                R593 1
    X1754                OBJ 7.75
    X1754                R37 1
    X1754                R590 1
    X1754                R594 -1
    X1755                OBJ 7.75
    X1755                R37 1
    X1755                R590 -1
    X1755                R594 1
    X1756                OBJ 6.0999999999999996
    X1756                R39 1
    X1756                R577 -1
    X1756                R595 1
    X1757                OBJ 6.0999999999999996
    X1757                R39 1
    X1757                R577 1
    X1757                R595 -1
    X1758                OBJ 2.3900000000000001
    X1758                R40 1
    X1758                R579 -1
    X1758                R595 1
    X1759                OBJ 2.3900000000000001
    X1759                R40 1
    X1759                R579 1
    X1759                R595 -1
    X1760                OBJ 8.3399999999999999
    X1760                R42 1
    X1760                R585 -1
    X1760                R596 1
    X1761                OBJ 8.3399999999999999
    X1761                R42 1
    X1761                R585 1
    X1761                R596 -1
    X1762                OBJ 7.5599999999999996
    X1762                R43 1
    X1762                R586 -1
    X1762                R596 1
    X1763                OBJ 7.5599999999999996
    X1763                R43 1
    X1763                R586 1
    X1763                R596 -1
    X1764                OBJ 7.4699999999999998
    X1764                R45 1
    X1764                R596 1
    X1764                R597 -1
    X1765                OBJ 7.4699999999999998
    X1765                R45 1
    X1765                R596 -1
    X1765                R597 1
    X1766                OBJ 2.6400000000000001
    X1766                R47 1
    X1766                R576 1
    X1766                R598 -1
    X1767                OBJ 2.6400000000000001
    X1767                R47 1
    X1767                R576 -1
    X1767                R598 1
    X1768                OBJ 3.9300000000000002
    X1768                R48 1
    X1768                R576 1
    X1768                R597 -1
    X1769                OBJ 3.9300000000000002
    X1769                R48 1
    X1769                R576 -1
    X1769                R597 1
    X1770                OBJ 4.3600000000000003
    X1770                R50 1
    X1770                R589 1
    X1770                R599 -1
    X1771                OBJ 6.6799999999999997
    X1771                R51 1
    X1771                R589 1
    X1771                R593 -1
    X1772                OBJ 7.2199999999999998
    X1772                R53 1
    X1772                R591 1
    X1772                R600 -1
    X1773                OBJ 7.2199999999999998
    X1773                R53 1
    X1773                R591 -1
    X1773                R600 1
    X1774                OBJ 7.7699999999999996
    X1774                R55 1
    X1774                R591 1
    X1774                R601 -1
    X1775                OBJ 7.7699999999999996
    X1775                R55 1
    X1775                R591 -1
    X1775                R601 1
    X1776                OBJ 4.6200000000000001
    X1776                R57 1
    X1776                R577 -1
    X1776                R602 1
    X1777                OBJ 4.6200000000000001
    X1777                R57 1
    X1777                R577 1
    X1777                R602 -1
    X1778                OBJ 6.9000000000000004
    X1778                R58 1
    X1778                R579 -1
    X1778                R602 1
    X1779                OBJ 6.9000000000000004
    X1779                R58 1
    X1779                R579 1
    X1779                R602 -1
    X1780                OBJ 2.75
    X1780                R60 1
    X1780                R598 1
    X1780                R603 -1
    X1781                OBJ 2.75
    X1781                R60 1
    X1781                R598 -1
    X1781                R603 1
    X1782                OBJ 5.9199999999999999
    X1782                R61 1
    X1782                R578 -1
    X1782                R603 1
    X1783                OBJ 5.9199999999999999
    X1783                R61 1
    X1783                R578 1
    X1783                R603 -1
    X1784                OBJ 4.5599999999999996
    X1784                R62 1
    X1784                R592 -1
    X1784                R603 1
    X1785                OBJ 4.5599999999999996
    X1785                R62 1
    X1785                R592 1
    X1785                R603 -1
    X1786                OBJ 2.71
    X1786                R64 1
    X1786                R603 1
    X1786                R604 -1
    X1787                OBJ 2.71
    X1787                R64 1
    X1787                R603 -1
    X1787                R604 1
    X1788                OBJ 11.82
    X1788                R66 1
    X1788                R600 -1
    X1788                R605 1
    X1789                OBJ 11.82
    X1789                R66 1
    X1789                R600 1
    X1789                R605 -1
    X1790                OBJ 5.9699999999999998
    X1790                R67 1
    X1790                R601 -1
    X1790                R605 1
    X1791                OBJ 5.9699999999999998
    X1791                R67 1
    X1791                R601 1
    X1791                R605 -1
    X1792                OBJ 13.699999999999999
    X1792                R68 1
    X1792                R594 -1
    X1792                R605 1
    X1793                OBJ 13.699999999999999
    X1793                R68 1
    X1793                R594 1
    X1793                R605 -1
    X1794                OBJ 3.8300000000000001
    X1794                R69 1
    X1794                R594 -1
    X1794                R599 1
    X1795                OBJ 3.8300000000000001
    X1795                R69 1
    X1795                R594 1
    X1795                R599 -1
    X1796                OBJ 19.77
    X1796                R71 1
    X1796                R579 -1
    X1796                R606 1
    X1797                OBJ 19.77
    X1797                R71 1
    X1797                R579 1
    X1797                R606 -1
    X1798                OBJ 7.5099999999999998
    X1798                R72 1
    X1798                R585 -1
    X1798                R606 1
    X1799                OBJ 7.5099999999999998
    X1799                R72 1
    X1799                R585 1
    X1799                R606 -1
    X1800                OBJ 4.71
    X1800                R73 1
    X1800                R587 -1
    X1800                R606 1
    X1801                OBJ 4.71
    X1801                R73 1
    X1801                R587 1
    X1801                R606 -1
    X1802                OBJ 5.1399999999999997
    X1802                R74 1
    X1802                R579 1
    X1802                R597 -1
    X1803                OBJ 5.1399999999999997
    X1803                R74 1
    X1803                R579 -1
    X1803                R597 1
    X1804                OBJ 4.1100000000000003
    X1804                R76 1
    X1804                R586 -1
    X1804                R607 1
    X1805                OBJ 4.1100000000000003
    X1805                R76 1
    X1805                R586 1
    X1805                R607 -1
    X1806                OBJ 5.9400000000000004
    X1806                R77 1
    X1806                R597 -1
    X1806                R607 1
    X1807                OBJ 5.9400000000000004
    X1807                R77 1
    X1807                R597 1
    X1807                R607 -1
    X1808                OBJ 5.0700000000000003
    X1808                R79 1
    X1808                R607 1
    X1808                R608 -1
    X1809                OBJ 5.0700000000000003
    X1809                R79 1
    X1809                R607 -1
    X1809                R608 1
    X1810                OBJ 9.0700000000000003
    X1810                R81 1
    X1810                R586 1
    X1810                R609 -1
    X1811                OBJ 9.0700000000000003
    X1811                R81 1
    X1811                R586 -1
    X1811                R609 1
    X1812                OBJ 5.2199999999999998
    X1812                R83 1
    X1812                R592 -1
    X1812                R610 1
    X1813                OBJ 5.2199999999999998
    X1813                R83 1
    X1813                R592 1
    X1813                R610 -1
    X1814                OBJ 7.2000000000000002
    X1814                R84 1
    X1814                R609 -1
    X1814                R610 1
    X1815                OBJ 7.2000000000000002
    X1815                R84 1
    X1815                R609 1
    X1815                R610 -1
    X1816                OBJ 3.27
    X1816                R85 1
    X1816                R608 -1
    X1816                R610 1
    X1817                OBJ 3.27
    X1817                R85 1
    X1817                R608 1
    X1817                R610 -1
    X1818                OBJ 5.3399999999999999
    X1818                R87 1
    X1818                R592 1
    X1818                R611 -1
    X1819                OBJ 5.3399999999999999
    X1819                R87 1
    X1819                R592 -1
    X1819                R611 1
    X1820                OBJ 6.3799999999999999
    X1820                R88 1
    X1820                R581 1
    X1820                R609 -1
    X1821                OBJ 6.3799999999999999
    X1821                R88 1
    X1821                R581 -1
    X1821                R609 1
    X1822                OBJ 6
    X1822                R89 1
    X1822                R597 1
    X1822                R604 -1
    X1823                OBJ 6
    X1823                R89 1
    X1823                R597 -1
    X1823                R604 1
    X1824                OBJ 3.7599999999999998
    X1824                R90 1
    X1824                R593 1
    X1824                R611 -1
    X1825                OBJ 3.7599999999999998
    X1825                R90 1
    X1825                R593 -1
    X1825                R611 1
    X1826                OBJ 7.8300000000000001
    X1826                R91 1
    X1826                R583 -1
    X1826                R609 1
    X1827                OBJ 7.8300000000000001
    X1827                R91 1
    X1827                R583 1
    X1827                R609 -1
    X1828                OBJ 2.1800000000000002
    X1828                R92 1
    X1828                R604 1
    X1828                R608 -1
    X1829                OBJ 2.1800000000000002
    X1829                R92 1
    X1829                R604 -1
    X1829                R608 1
    X1830                OBJ 4
    X1830                R93 1
    X1830                R583 -1
    X1830                R611 1
    X1831                OBJ 4
    X1831                R93 1
    X1831                R583 1
    X1831                R611 -1
    X1832                OBJ 2.5899999999999999
    X1832                R2 1
    X1832                R612 1
    X1832                R613 -1
    X1833                OBJ 2.5899999999999999
    X1833                R2 1
    X1833                R612 -1
    X1833                R613 1
    X1834                OBJ 10.67
    X1834                R4 1
    X1834                R612 1
    X1834                R614 -1
    X1835                OBJ 10.67
    X1835                R4 1
    X1835                R612 -1
    X1835                R614 1
    X1836                OBJ 5.5199999999999996
    X1836                R6 1
    X1836                R612 1
    X1836                R615 -1
    X1837                OBJ 5.5199999999999996
    X1837                R6 1
    X1837                R612 -1
    X1837                R615 1
    X1838                OBJ 5.4000000000000004
    X1838                R8 1
    X1838                R612 1
    X1838                R616 -1
    X1839                OBJ 5.4000000000000004
    X1839                R8 1
    X1839                R612 -1
    X1839                R616 1
    X1840                OBJ 13.630000000000001
    X1840                R11 1
    X1840                R617 1
    X1840                R618 -1
    X1841                OBJ 13.630000000000001
    X1841                R11 1
    X1841                R617 -1
    X1841                R618 1
    X1842                OBJ 7.9400000000000004
    X1842                R13 1
    X1842                R617 1
    X1842                R619 -1
    X1843                OBJ 7.9400000000000004
    X1843                R13 1
    X1843                R617 -1
    X1843                R619 1
    X1844                OBJ 15
    X1844                R15 1
    X1844                R617 1
    X1844                R620 -1
    X1845                OBJ 15
    X1845                R15 1
    X1845                R617 -1
    X1845                R620 1
    X1846                OBJ 7.5999999999999996
    X1846                R18 1
    X1846                R621 1
    X1846                R622 -1
    X1847                OBJ 7.5999999999999996
    X1847                R18 1
    X1847                R621 -1
    X1847                R622 1
    X1848                OBJ 5.0800000000000001
    X1848                R20 1
    X1848                R621 1
    X1848                R623 -1
    X1849                OBJ 5.0800000000000001
    X1849                R20 1
    X1849                R621 -1
    X1849                R623 1
    X1850                OBJ 12.44
    X1850                R22 1
    X1850                R621 1
    X1850                R624 -1
    X1851                OBJ 12.44
    X1851                R22 1
    X1851                R621 -1
    X1851                R624 1
    X1852                OBJ 4.7400000000000002
    X1852                R25 1
    X1852                R625 1
    X1852                R626 -1
    X1853                OBJ 4.7400000000000002
    X1853                R25 1
    X1853                R625 -1
    X1853                R626 1
    X1854                OBJ 4.8700000000000001
    X1854                R26 1
    X1854                R619 -1
    X1854                R625 1
    X1855                OBJ 4.8700000000000001
    X1855                R26 1
    X1855                R619 1
    X1855                R625 -1
    X1856                OBJ 5.5099999999999998
    X1856                R27 1
    X1856                R620 -1
    X1856                R625 1
    X1857                OBJ 5.5099999999999998
    X1857                R27 1
    X1857                R620 1
    X1857                R625 -1
    X1858                OBJ 5.4000000000000004
    X1858                R30 1
    X1858                R627 1
    X1858                R628 -1
    X1859                OBJ 5.4000000000000004
    X1859                R30 1
    X1859                R627 -1
    X1859                R628 1
    X1860                OBJ 3.8100000000000001
    X1860                R31 1
    X1860                R615 -1
    X1860                R627 1
    X1861                OBJ 3.8100000000000001
    X1861                R31 1
    X1861                R615 1
    X1861                R627 -1
    X1862                OBJ 7.5700000000000003
    X1862                R33 1
    X1862                R627 1
    X1862                R629 -1
    X1863                OBJ 7.5700000000000003
    X1863                R33 1
    X1863                R627 -1
    X1863                R629 1
    X1864                OBJ 4.2000000000000002
    X1864                R35 1
    X1864                R627 1
    X1864                R630 -1
    X1865                OBJ 4.2000000000000002
    X1865                R35 1
    X1865                R627 -1
    X1865                R630 1
    X1866                OBJ 7.75
    X1866                R37 1
    X1866                R627 1
    X1866                R631 -1
    X1867                OBJ 7.75
    X1867                R37 1
    X1867                R627 -1
    X1867                R631 1
    X1868                OBJ 6.0999999999999996
    X1868                R39 1
    X1868                R614 -1
    X1868                R632 1
    X1869                OBJ 6.0999999999999996
    X1869                R39 1
    X1869                R614 1
    X1869                R632 -1
    X1870                OBJ 2.3900000000000001
    X1870                R40 1
    X1870                R616 -1
    X1870                R632 1
    X1871                OBJ 2.3900000000000001
    X1871                R40 1
    X1871                R616 1
    X1871                R632 -1
    X1872                OBJ 8.3399999999999999
    X1872                R42 1
    X1872                R622 -1
    X1872                R633 1
    X1873                OBJ 8.3399999999999999
    X1873                R42 1
    X1873                R622 1
    X1873                R633 -1
    X1874                OBJ 7.5599999999999996
    X1874                R43 1
    X1874                R623 -1
    X1874                R633 1
    X1875                OBJ 7.5599999999999996
    X1875                R43 1
    X1875                R623 1
    X1875                R633 -1
    X1876                OBJ 7.4699999999999998
    X1876                R45 1
    X1876                R633 1
    X1876                R634 -1
    X1877                OBJ 7.4699999999999998
    X1877                R45 1
    X1877                R633 -1
    X1877                R634 1
    X1878                OBJ 2.6400000000000001
    X1878                R47 1
    X1878                R613 1
    X1878                R635 -1
    X1879                OBJ 2.6400000000000001
    X1879                R47 1
    X1879                R613 -1
    X1879                R635 1
    X1880                OBJ 3.9300000000000002
    X1880                R48 1
    X1880                R613 1
    X1880                R634 -1
    X1881                OBJ 3.9300000000000002
    X1881                R48 1
    X1881                R613 -1
    X1881                R634 1
    X1882                OBJ 4.3600000000000003
    X1882                R50 1
    X1882                R626 1
    X1882                R636 -1
    X1883                OBJ 4.3600000000000003
    X1883                R50 1
    X1883                R626 -1
    X1883                R636 1
    X1884                OBJ 6.6799999999999997
    X1884                R51 1
    X1884                R626 1
    X1884                R630 -1
    X1885                OBJ 6.6799999999999997
    X1885                R51 1
    X1885                R626 -1
    X1885                R630 1
    X1886                OBJ 7.2199999999999998
    X1886                R53 1
    X1886                R628 1
    X1886                R637 -1
    X1887                OBJ 7.2199999999999998
    X1887                R53 1
    X1887                R628 -1
    X1887                R637 1
    X1888                OBJ 7.7699999999999996
    X1888                R55 1
    X1888                R628 1
    X1888                R638 -1
    X1889                OBJ 7.7699999999999996
    X1889                R55 1
    X1889                R628 -1
    X1889                R638 1
    X1890                OBJ 4.6200000000000001
    X1890                R57 1
    X1890                R614 -1
    X1890                R639 1
    X1891                OBJ 4.6200000000000001
    X1891                R57 1
    X1891                R614 1
    X1891                R639 -1
    X1892                OBJ 6.9000000000000004
    X1892                R58 1
    X1892                R616 -1
    X1892                R639 1
    X1893                OBJ 6.9000000000000004
    X1893                R58 1
    X1893                R616 1
    X1893                R639 -1
    X1894                OBJ 2.75
    X1894                R60 1
    X1894                R635 1
    X1894                R640 -1
    X1895                OBJ 2.75
    X1895                R60 1
    X1895                R635 -1
    X1895                R640 1
    X1896                OBJ 5.9199999999999999
    X1896                R61 1
    X1896                R615 -1
    X1896                R640 1
    X1897                OBJ 5.9199999999999999
    X1897                R61 1
    X1897                R615 1
    X1897                R640 -1
    X1898                OBJ 4.5599999999999996
    X1898                R62 1
    X1898                R629 -1
    X1898                R640 1
    X1899                OBJ 4.5599999999999996
    X1899                R62 1
    X1899                R629 1
    X1899                R640 -1
    X1900                OBJ 2.71
    X1900                R64 1
    X1900                R640 1
    X1900                R641 -1
    X1901                OBJ 2.71
    X1901                R64 1
    X1901                R640 -1
    X1901                R641 1
    X1902                OBJ 11.82
    X1902                R66 1
    X1902                R637 -1
    X1902                R642 1
    X1903                OBJ 11.82
    X1903                R66 1
    X1903                R637 1
    X1903                R642 -1
    X1904                OBJ 5.9699999999999998
    X1904                R67 1
    X1904                R638 -1
    X1904                R642 1
    X1905                OBJ 5.9699999999999998
    X1905                R67 1
    X1905                R638 1
    X1905                R642 -1
    X1906                OBJ 13.699999999999999
    X1906                R68 1
    X1906                R631 -1
    X1906                R642 1
    X1907                OBJ 13.699999999999999
    X1907                R68 1
    X1907                R631 1
    X1907                R642 -1
    X1908                OBJ 3.8300000000000001
    X1908                R69 1
    X1908                R631 -1
    X1908                R636 1
    X1909                OBJ 3.8300000000000001
    X1909                R69 1
    X1909                R631 1
    X1909                R636 -1
    X1910                OBJ 19.77
    X1910                R71 1
    X1910                R616 -1
    X1910                R643 1
    X1911                OBJ 19.77
    X1911                R71 1
    X1911                R616 1
    X1911                R643 -1
    X1912                OBJ 7.5099999999999998
    X1912                R72 1
    X1912                R622 -1
    X1912                R643 1
    X1913                OBJ 7.5099999999999998
    X1913                R72 1
    X1913                R622 1
    X1913                R643 -1
    X1914                OBJ 4.71
    X1914                R73 1
    X1914                R624 -1
    X1914                R643 1
    X1915                OBJ 4.71
    X1915                R73 1
    X1915                R624 1
    X1915                R643 -1
    X1916                OBJ 5.1399999999999997
    X1916                R74 1
    X1916                R616 1
    X1916                R634 -1
    X1917                OBJ 5.1399999999999997
    X1917                R74 1
    X1917                R616 -1
    X1917                R634 1
    X1918                OBJ 4.1100000000000003
    X1918                R76 1
    X1918                R623 -1
    X1918                R644 1
    X1919                OBJ 5.9400000000000004
    X1919                R77 1
    X1919                R634 -1
    X1919                R644 1
    X1920                OBJ 5.0700000000000003
    X1920                R79 1
    X1920                R644 1
    X1920                R645 -1
    X1921                OBJ 9.0700000000000003
    X1921                R81 1
    X1921                R623 1
    X1921                R646 -1
    X1922                OBJ 9.0700000000000003
    X1922                R81 1
    X1922                R623 -1
    X1922                R646 1
    X1923                OBJ 5.2199999999999998
    X1923                R83 1
    X1923                R629 -1
    X1923                R647 1
    X1924                OBJ 5.2199999999999998
    X1924                R83 1
    X1924                R629 1
    X1924                R647 -1
    X1925                OBJ 7.2000000000000002
    X1925                R84 1
    X1925                R646 -1
    X1925                R647 1
    X1926                OBJ 7.2000000000000002
    X1926                R84 1
    X1926                R646 1
    X1926                R647 -1
    X1927                OBJ 3.27
    X1927                R85 1
    X1927                R645 -1
    X1927                R647 1
    X1928                OBJ 3.27
    X1928                R85 1
    X1928                R645 1
    X1928                R647 -1
    X1929                OBJ 5.3399999999999999
    X1929                R87 1
    X1929                R629 1
    X1929                R648 -1
    X1930                OBJ 5.3399999999999999
    X1930                R87 1
    X1930                R629 -1
    X1930                R648 1
    X1931                OBJ 6.3799999999999999
    X1931                R88 1
    X1931                R618 1
    X1931                R646 -1
    X1932                OBJ 6.3799999999999999
    X1932                R88 1
    X1932                R618 -1
    X1932                R646 1
    X1933                OBJ 6
    X1933                R89 1
    X1933                R634 1
    X1933                R641 -1
    X1934                OBJ 6
    X1934                R89 1
    X1934                R634 -1
    X1934                R641 1
    X1935                OBJ 3.7599999999999998
    X1935                R90 1
    X1935                R630 1
    X1935                R648 -1
    X1936                OBJ 3.7599999999999998
    X1936                R90 1
    X1936                R630 -1
    X1936                R648 1
    X1937                OBJ 7.8300000000000001
    X1937                R91 1
    X1937                R620 -1
    X1937                R646 1
    X1938                OBJ 7.8300000000000001
    X1938                R91 1
    X1938                R620 1
    X1938                R646 -1
    X1939                OBJ 2.1800000000000002
    X1939                R92 1
    X1939                R641 1
    X1939                R645 -1
    X1940                OBJ 2.1800000000000002
    X1940                R92 1
    X1940                R641 -1
    X1940                R645 1
    X1941                OBJ 4
    X1941                R93 1
    X1941                R620 -1
    X1941                R648 1
    X1942                OBJ 4
    X1942                R93 1
    X1942                R620 1
    X1942                R648 -1
    X1943                OBJ 2.5899999999999999
    X1943                R2 1
    X1943                R649 1
    X1943                R650 -1
    X1944                OBJ 2.5899999999999999
    X1944                R2 1
    X1944                R649 -1
    X1944                R650 1
    X1945                OBJ 10.67
    X1945                R4 1
    X1945                R649 1
    X1945                R651 -1
    X1946                OBJ 10.67
    X1946                R4 1
    X1946                R649 -1
    X1946                R651 1
    X1947                OBJ 5.5199999999999996
    X1947                R6 1
    X1947                R649 1
    X1947                R652 -1
    X1948                OBJ 5.5199999999999996
    X1948                R6 1
    X1948                R649 -1
    X1948                R652 1
    X1949                OBJ 5.4000000000000004
    X1949                R8 1
    X1949                R649 1
    X1949                R653 -1
    X1950                OBJ 5.4000000000000004
    X1950                R8 1
    X1950                R649 -1
    X1950                R653 1
    X1951                OBJ 13.630000000000001
    X1951                R11 1
    X1951                R654 1
    X1951                R655 -1
    X1952                OBJ 7.9400000000000004
    X1952                R13 1
    X1952                R654 1
    X1952                R656 -1
    X1953                OBJ 15
    X1953                R15 1
    X1953                R654 1
    X1953                R657 -1
    X1954                OBJ 7.5999999999999996
    X1954                R18 1
    X1954                R658 1
    X1954                R659 -1
    X1955                OBJ 7.5999999999999996
    X1955                R18 1
    X1955                R658 -1
    X1955                R659 1
    X1956                OBJ 5.0800000000000001
    X1956                R20 1
    X1956                R658 1
    X1956                R660 -1
    X1957                OBJ 5.0800000000000001
    X1957                R20 1
    X1957                R658 -1
    X1957                R660 1
    X1958                OBJ 12.44
    X1958                R22 1
    X1958                R658 1
    X1958                R661 -1
    X1959                OBJ 12.44
    X1959                R22 1
    X1959                R658 -1
    X1959                R661 1
    X1960                OBJ 4.7400000000000002
    X1960                R25 1
    X1960                R662 1
    X1960                R663 -1
    X1961                OBJ 4.7400000000000002
    X1961                R25 1
    X1961                R662 -1
    X1961                R663 1
    X1962                OBJ 4.8700000000000001
    X1962                R26 1
    X1962                R656 -1
    X1962                R662 1
    X1963                OBJ 4.8700000000000001
    X1963                R26 1
    X1963                R656 1
    X1963                R662 -1
    X1964                OBJ 5.5099999999999998
    X1964                R27 1
    X1964                R657 -1
    X1964                R662 1
    X1965                OBJ 5.5099999999999998
    X1965                R27 1
    X1965                R657 1
    X1965                R662 -1
    X1966                OBJ 5.4000000000000004
    X1966                R30 1
    X1966                R664 1
    X1966                R665 -1
    X1967                OBJ 5.4000000000000004
    X1967                R30 1
    X1967                R664 -1
    X1967                R665 1
    X1968                OBJ 3.8100000000000001
    X1968                R31 1
    X1968                R652 -1
    X1968                R664 1
    X1969                OBJ 3.8100000000000001
    X1969                R31 1
    X1969                R652 1
    X1969                R664 -1
    X1970                OBJ 7.5700000000000003
    X1970                R33 1
    X1970                R664 1
    X1970                R666 -1
    X1971                OBJ 7.5700000000000003
    X1971                R33 1
    X1971                R664 -1
    X1971                R666 1
    X1972                OBJ 4.2000000000000002
    X1972                R35 1
    X1972                R664 1
    X1972                R667 -1
    X1973                OBJ 4.2000000000000002
    X1973                R35 1
    X1973                R664 -1
    X1973                R667 1
    X1974                OBJ 7.75
    X1974                R37 1
    X1974                R664 1
    X1974                R668 -1
    X1975                OBJ 7.75
    X1975                R37 1
    X1975                R664 -1
    X1975                R668 1
    X1976                OBJ 6.0999999999999996
    X1976                R39 1
    X1976                R651 -1
    X1976                R669 1
    X1977                OBJ 6.0999999999999996
    X1977                R39 1
    X1977                R651 1
    X1977                R669 -1
    X1978                OBJ 2.3900000000000001
    X1978                R40 1
    X1978                R653 -1
    X1978                R669 1
    X1979                OBJ 2.3900000000000001
    X1979                R40 1
    X1979                R653 1
    X1979                R669 -1
    X1980                OBJ 8.3399999999999999
    X1980                R42 1
    X1980                R659 -1
    X1980                R670 1
    X1981                OBJ 8.3399999999999999
    X1981                R42 1
    X1981                R659 1
    X1981                R670 -1
    X1982                OBJ 7.5599999999999996
    X1982                R43 1
    X1982                R660 -1
    X1982                R670 1
    X1983                OBJ 7.5599999999999996
    X1983                R43 1
    X1983                R660 1
    X1983                R670 -1
    X1984                OBJ 7.4699999999999998
    X1984                R45 1
    X1984                R670 1
    X1984                R671 -1
    X1985                OBJ 7.4699999999999998
    X1985                R45 1
    X1985                R670 -1
    X1985                R671 1
    X1986                OBJ 2.6400000000000001
    X1986                R47 1
    X1986                R650 1
    X1986                R672 -1
    X1987                OBJ 2.6400000000000001
    X1987                R47 1
    X1987                R650 -1
    X1987                R672 1
    X1988                OBJ 3.9300000000000002
    X1988                R48 1
    X1988                R650 1
    X1988                R671 -1
    X1989                OBJ 3.9300000000000002
    X1989                R48 1
    X1989                R650 -1
    X1989                R671 1
    X1990                OBJ 4.3600000000000003
    X1990                R50 1
    X1990                R663 1
    X1990                R673 -1
    X1991                OBJ 4.3600000000000003
    X1991                R50 1
    X1991                R663 -1
    X1991                R673 1
    X1992                OBJ 6.6799999999999997
    X1992                R51 1
    X1992                R663 1
    X1992                R667 -1
    X1993                OBJ 6.6799999999999997
    X1993                R51 1
    X1993                R663 -1
    X1993                R667 1
    X1994                OBJ 7.2199999999999998
    X1994                R53 1
    X1994                R665 1
    X1994                R674 -1
    X1995                OBJ 7.2199999999999998
    X1995                R53 1
    X1995                R665 -1
    X1995                R674 1
    X1996                OBJ 7.7699999999999996
    X1996                R55 1
    X1996                R665 1
    X1996                R675 -1
    X1997                OBJ 7.7699999999999996
    X1997                R55 1
    X1997                R665 -1
    X1997                R675 1
    X1998                OBJ 4.6200000000000001
    X1998                R57 1
    X1998                R651 -1
    X1998                R676 1
    X1999                OBJ 4.6200000000000001
    X1999                R57 1
    X1999                R651 1
    X1999                R676 -1
    X2000                OBJ 6.9000000000000004
    X2000                R58 1
    X2000                R653 -1
    X2000                R676 1
    X2001                OBJ 6.9000000000000004
    X2001                R58 1
    X2001                R653 1
    X2001                R676 -1
    X2002                OBJ 2.75
    X2002                R60 1
    X2002                R672 1
    X2002                R677 -1
    X2003                OBJ 2.75
    X2003                R60 1
    X2003                R672 -1
    X2003                R677 1
    X2004                OBJ 5.9199999999999999
    X2004                R61 1
    X2004                R652 -1
    X2004                R677 1
    X2005                OBJ 5.9199999999999999
    X2005                R61 1
    X2005                R652 1
    X2005                R677 -1
    X2006                OBJ 4.5599999999999996
    X2006                R62 1
    X2006                R666 -1
    X2006                R677 1
    X2007                OBJ 4.5599999999999996
    X2007                R62 1
    X2007                R666 1
    X2007                R677 -1
    X2008                OBJ 2.71
    X2008                R64 1
    X2008                R677 1
    X2008                R678 -1
    X2009                OBJ 2.71
    X2009                R64 1
    X2009                R677 -1
    X2009                R678 1
    X2010                OBJ 11.82
    X2010                R66 1
    X2010                R674 -1
    X2010                R679 1
    X2011                OBJ 11.82
    X2011                R66 1
    X2011                R674 1
    X2011                R679 -1
    X2012                OBJ 5.9699999999999998
    X2012                R67 1
    X2012                R675 -1
    X2012                R679 1
    X2013                OBJ 5.9699999999999998
    X2013                R67 1
    X2013                R675 1
    X2013                R679 -1
    X2014                OBJ 13.699999999999999
    X2014                R68 1
    X2014                R668 -1
    X2014                R679 1
    X2015                OBJ 13.699999999999999
    X2015                R68 1
    X2015                R668 1
    X2015                R679 -1
    X2016                OBJ 3.8300000000000001
    X2016                R69 1
    X2016                R668 -1
    X2016                R673 1
    X2017                OBJ 3.8300000000000001
    X2017                R69 1
    X2017                R668 1
    X2017                R673 -1
    X2018                OBJ 19.77
    X2018                R71 1
    X2018                R653 -1
    X2018                R680 1
    X2019                OBJ 19.77
    X2019                R71 1
    X2019                R653 1
    X2019                R680 -1
    X2020                OBJ 7.5099999999999998
    X2020                R72 1
    X2020                R659 -1
    X2020                R680 1
    X2021                OBJ 7.5099999999999998
    X2021                R72 1
    X2021                R659 1
    X2021                R680 -1
    X2022                OBJ 4.71
    X2022                R73 1
    X2022                R661 -1
    X2022                R680 1
    X2023                OBJ 4.71
    X2023                R73 1
    X2023                R661 1
    X2023                R680 -1
    X2024                OBJ 5.1399999999999997
    X2024                R74 1
    X2024                R653 1
    X2024                R671 -1
    X2025                OBJ 5.1399999999999997
    X2025                R74 1
    X2025                R653 -1
    X2025                R671 1
    X2026                OBJ 4.1100000000000003
    X2026                R76 1
    X2026                R660 -1
    X2026                R681 1
    X2027                OBJ 4.1100000000000003
    X2027                R76 1
    X2027                R660 1
    X2027                R681 -1
    X2028                OBJ 5.9400000000000004
    X2028                R77 1
    X2028                R671 -1
    X2028                R681 1
    X2029                OBJ 5.9400000000000004
    X2029                R77 1
    X2029                R671 1
    X2029                R681 -1
    X2030                OBJ 5.0700000000000003
    X2030                R79 1
    X2030                R681 1
    X2030                R682 -1
    X2031                OBJ 5.0700000000000003
    X2031                R79 1
    X2031                R681 -1
    X2031                R682 1
    X2032                OBJ 9.0700000000000003
    X2032                R81 1
    X2032                R660 1
    X2032                R683 -1
    X2033                OBJ 9.0700000000000003
    X2033                R81 1
    X2033                R660 -1
    X2033                R683 1
    X2034                OBJ 5.2199999999999998
    X2034                R83 1
    X2034                R666 -1
    X2034                R684 1
    X2035                OBJ 5.2199999999999998
    X2035                R83 1
    X2035                R666 1
    X2035                R684 -1
    X2036                OBJ 7.2000000000000002
    X2036                R84 1
    X2036                R683 -1
    X2036                R684 1
    X2037                OBJ 7.2000000000000002
    X2037                R84 1
    X2037                R683 1
    X2037                R684 -1
    X2038                OBJ 3.27
    X2038                R85 1
    X2038                R682 -1
    X2038                R684 1
    X2039                OBJ 3.27
    X2039                R85 1
    X2039                R682 1
    X2039                R684 -1
    X2040                OBJ 5.3399999999999999
    X2040                R87 1
    X2040                R666 1
    X2040                R685 -1
    X2041                OBJ 5.3399999999999999
    X2041                R87 1
    X2041                R666 -1
    X2041                R685 1
    X2042                OBJ 6.3799999999999999
    X2042                R88 1
    X2042                R655 1
    X2042                R683 -1
    X2043                OBJ 6.3799999999999999
    X2043                R88 1
    X2043                R655 -1
    X2043                R683 1
    X2044                OBJ 6
    X2044                R89 1
    X2044                R671 1
    X2044                R678 -1
    X2045                OBJ 6
    X2045                R89 1
    X2045                R671 -1
    X2045                R678 1
    X2046                OBJ 3.7599999999999998
    X2046                R90 1
    X2046                R667 1
    X2046                R685 -1
    X2047                OBJ 3.7599999999999998
    X2047                R90 1
    X2047                R667 -1
    X2047                R685 1
    X2048                OBJ 7.8300000000000001
    X2048                R91 1
    X2048                R657 -1
    X2048                R683 1
    X2049                OBJ 7.8300000000000001
    X2049                R91 1
    X2049                R657 1
    X2049                R683 -1
    X2050                OBJ 2.1800000000000002
    X2050                R92 1
    X2050                R678 1
    X2050                R682 -1
    X2051                OBJ 2.1800000000000002
    X2051                R92 1
    X2051                R678 -1
    X2051                R682 1
    X2052                OBJ 4
    X2052                R93 1
    X2052                R657 -1
    X2052                R685 1
    X2053                OBJ 4
    X2053                R93 1
    X2053                R657 1
    X2053                R685 -1
    X2054                OBJ 2.5899999999999999
    X2054                R2 1
    X2054                R686 1
    X2054                R687 -1
    X2055                OBJ 2.5899999999999999
    X2055                R2 1
    X2055                R686 -1
    X2055                R687 1
    X2056                OBJ 10.67
    X2056                R4 1
    X2056                R686 1
    X2056                R688 -1
    X2057                OBJ 10.67
    X2057                R4 1
    X2057                R686 -1
    X2057                R688 1
    X2058                OBJ 5.5199999999999996
    X2058                R6 1
    X2058                R686 1
    X2058                R689 -1
    X2059                OBJ 5.5199999999999996
    X2059                R6 1
    X2059                R686 -1
    X2059                R689 1
    X2060                OBJ 5.4000000000000004
    X2060                R8 1
    X2060                R686 1
    X2060                R690 -1
    X2061                OBJ 5.4000000000000004
    X2061                R8 1
    X2061                R686 -1
    X2061                R690 1
    X2062                OBJ 13.630000000000001
    X2062                R11 1
    X2062                R691 1
    X2062                R692 -1
    X2063                OBJ 13.630000000000001
    X2063                R11 1
    X2063                R691 -1
    X2063                R692 1
    X2064                OBJ 7.9400000000000004
    X2064                R13 1
    X2064                R691 1
    X2064                R693 -1
    X2065                OBJ 7.9400000000000004
    X2065                R13 1
    X2065                R691 -1
    X2065                R693 1
    X2066                OBJ 15
    X2066                R15 1
    X2066                R691 1
    X2066                R694 -1
    X2067                OBJ 15
    X2067                R15 1
    X2067                R691 -1
    X2067                R694 1
    X2068                OBJ 7.5999999999999996
    X2068                R18 1
    X2068                R695 -1
    X2068                R696 1
    X2069                OBJ 5.0800000000000001
    X2069                R20 1
    X2069                R695 1
    X2069                R697 -1
    X2070                OBJ 5.0800000000000001
    X2070                R20 1
    X2070                R695 -1
    X2070                R697 1
    X2071                OBJ 12.44
    X2071                R22 1
    X2071                R695 1
    X2071                R698 -1
    X2072                OBJ 12.44
    X2072                R22 1
    X2072                R695 -1
    X2072                R698 1
    X2073                OBJ 4.7400000000000002
    X2073                R25 1
    X2073                R699 1
    X2073                R700 -1
    X2074                OBJ 4.7400000000000002
    X2074                R25 1
    X2074                R699 -1
    X2074                R700 1
    X2075                OBJ 4.8700000000000001
    X2075                R26 1
    X2075                R693 -1
    X2075                R699 1
    X2076                OBJ 4.8700000000000001
    X2076                R26 1
    X2076                R693 1
    X2076                R699 -1
    X2077                OBJ 5.5099999999999998
    X2077                R27 1
    X2077                R694 -1
    X2077                R699 1
    X2078                OBJ 5.5099999999999998
    X2078                R27 1
    X2078                R694 1
    X2078                R699 -1
    X2079                OBJ 5.4000000000000004
    X2079                R30 1
    X2079                R701 1
    X2079                R702 -1
    X2080                OBJ 5.4000000000000004
    X2080                R30 1
    X2080                R701 -1
    X2080                R702 1
    X2081                OBJ 3.8100000000000001
    X2081                R31 1
    X2081                R689 -1
    X2081                R701 1
    X2082                OBJ 3.8100000000000001
    X2082                R31 1
    X2082                R689 1
    X2082                R701 -1
    X2083                OBJ 7.5700000000000003
    X2083                R33 1
    X2083                R701 1
    X2083                R703 -1
    X2084                OBJ 7.5700000000000003
    X2084                R33 1
    X2084                R701 -1
    X2084                R703 1
    X2085                OBJ 4.2000000000000002
    X2085                R35 1
    X2085                R701 1
    X2085                R704 -1
    X2086                OBJ 4.2000000000000002
    X2086                R35 1
    X2086                R701 -1
    X2086                R704 1
    X2087                OBJ 7.75
    X2087                R37 1
    X2087                R701 1
    X2087                R705 -1
    X2088                OBJ 7.75
    X2088                R37 1
    X2088                R701 -1
    X2088                R705 1
    X2089                OBJ 6.0999999999999996
    X2089                R39 1
    X2089                R688 -1
    X2089                R706 1
    X2090                OBJ 6.0999999999999996
    X2090                R39 1
    X2090                R688 1
    X2090                R706 -1
    X2091                OBJ 2.3900000000000001
    X2091                R40 1
    X2091                R690 -1
    X2091                R706 1
    X2092                OBJ 2.3900000000000001
    X2092                R40 1
    X2092                R690 1
    X2092                R706 -1
    X2093                OBJ 8.3399999999999999
    X2093                R42 1
    X2093                R696 1
    X2093                R707 -1
    X2094                OBJ 7.5599999999999996
    X2094                R43 1
    X2094                R697 -1
    X2094                R707 1
    X2095                OBJ 7.5599999999999996
    X2095                R43 1
    X2095                R697 1
    X2095                R707 -1
    X2096                OBJ 7.4699999999999998
    X2096                R45 1
    X2096                R707 1
    X2096                R708 -1
    X2097                OBJ 7.4699999999999998
    X2097                R45 1
    X2097                R707 -1
    X2097                R708 1
    X2098                OBJ 2.6400000000000001
    X2098                R47 1
    X2098                R687 1
    X2098                R709 -1
    X2099                OBJ 2.6400000000000001
    X2099                R47 1
    X2099                R687 -1
    X2099                R709 1
    X2100                OBJ 3.9300000000000002
    X2100                R48 1
    X2100                R687 1
    X2100                R708 -1
    X2101                OBJ 3.9300000000000002
    X2101                R48 1
    X2101                R687 -1
    X2101                R708 1
    X2102                OBJ 4.3600000000000003
    X2102                R50 1
    X2102                R700 1
    X2102                R710 -1
    X2103                OBJ 4.3600000000000003
    X2103                R50 1
    X2103                R700 -1
    X2103                R710 1
    X2104                OBJ 6.6799999999999997
    X2104                R51 1
    X2104                R700 1
    X2104                R704 -1
    X2105                OBJ 6.6799999999999997
    X2105                R51 1
    X2105                R700 -1
    X2105                R704 1
    X2106                OBJ 7.2199999999999998
    X2106                R53 1
    X2106                R702 1
    X2106                R711 -1
    X2107                OBJ 7.2199999999999998
    X2107                R53 1
    X2107                R702 -1
    X2107                R711 1
    X2108                OBJ 7.7699999999999996
    X2108                R55 1
    X2108                R702 1
    X2108                R712 -1
    X2109                OBJ 7.7699999999999996
    X2109                R55 1
    X2109                R702 -1
    X2109                R712 1
    X2110                OBJ 4.6200000000000001
    X2110                R57 1
    X2110                R688 -1
    X2110                R713 1
    X2111                OBJ 4.6200000000000001
    X2111                R57 1
    X2111                R688 1
    X2111                R713 -1
    X2112                OBJ 6.9000000000000004
    X2112                R58 1
    X2112                R690 -1
    X2112                R713 1
    X2113                OBJ 6.9000000000000004
    X2113                R58 1
    X2113                R690 1
    X2113                R713 -1
    X2114                OBJ 2.75
    X2114                R60 1
    X2114                R709 1
    X2114                R714 -1
    X2115                OBJ 2.75
    X2115                R60 1
    X2115                R709 -1
    X2115                R714 1
    X2116                OBJ 5.9199999999999999
    X2116                R61 1
    X2116                R689 -1
    X2116                R714 1
    X2117                OBJ 5.9199999999999999
    X2117                R61 1
    X2117                R689 1
    X2117                R714 -1
    X2118                OBJ 4.5599999999999996
    X2118                R62 1
    X2118                R703 -1
    X2118                R714 1
    X2119                OBJ 4.5599999999999996
    X2119                R62 1
    X2119                R703 1
    X2119                R714 -1
    X2120                OBJ 2.71
    X2120                R64 1
    X2120                R714 1
    X2120                R715 -1
    X2121                OBJ 2.71
    X2121                R64 1
    X2121                R714 -1
    X2121                R715 1
    X2122                OBJ 11.82
    X2122                R66 1
    X2122                R711 -1
    X2122                R716 1
    X2123                OBJ 11.82
    X2123                R66 1
    X2123                R711 1
    X2123                R716 -1
    X2124                OBJ 5.9699999999999998
    X2124                R67 1
    X2124                R712 -1
    X2124                R716 1
    X2125                OBJ 5.9699999999999998
    X2125                R67 1
    X2125                R712 1
    X2125                R716 -1
    X2126                OBJ 13.699999999999999
    X2126                R68 1
    X2126                R705 -1
    X2126                R716 1
    X2127                OBJ 13.699999999999999
    X2127                R68 1
    X2127                R705 1
    X2127                R716 -1
    X2128                OBJ 3.8300000000000001
    X2128                R69 1
    X2128                R705 -1
    X2128                R710 1
    X2129                OBJ 3.8300000000000001
    X2129                R69 1
    X2129                R705 1
    X2129                R710 -1
    X2130                OBJ 19.77
    X2130                R71 1
    X2130                R690 -1
    X2130                R717 1
    X2131                OBJ 19.77
    X2131                R71 1
    X2131                R690 1
    X2131                R717 -1
    X2132                OBJ 7.5099999999999998
    X2132                R72 1
    X2132                R696 1
    X2132                R717 -1
    X2133                OBJ 4.71
    X2133                R73 1
    X2133                R698 -1
    X2133                R717 1
    X2134                OBJ 4.71
    X2134                R73 1
    X2134                R698 1
    X2134                R717 -1
    X2135                OBJ 5.1399999999999997
    X2135                R74 1
    X2135                R690 1
    X2135                R708 -1
    X2136                OBJ 5.1399999999999997
    X2136                R74 1
    X2136                R690 -1
    X2136                R708 1
    X2137                OBJ 4.1100000000000003
    X2137                R76 1
    X2137                R697 -1
    X2137                R718 1
    X2138                OBJ 4.1100000000000003
    X2138                R76 1
    X2138                R697 1
    X2138                R718 -1
    X2139                OBJ 5.9400000000000004
    X2139                R77 1
    X2139                R708 -1
    X2139                R718 1
    X2140                OBJ 5.9400000000000004
    X2140                R77 1
    X2140                R708 1
    X2140                R718 -1
    X2141                OBJ 5.0700000000000003
    X2141                R79 1
    X2141                R718 1
    X2141                R719 -1
    X2142                OBJ 5.0700000000000003
    X2142                R79 1
    X2142                R718 -1
    X2142                R719 1
    X2143                OBJ 9.0700000000000003
    X2143                R81 1
    X2143                R697 1
    X2143                R720 -1
    X2144                OBJ 9.0700000000000003
    X2144                R81 1
    X2144                R697 -1
    X2144                R720 1
    X2145                OBJ 5.2199999999999998
    X2145                R83 1
    X2145                R703 -1
    X2145                R721 1
    X2146                OBJ 5.2199999999999998
    X2146                R83 1
    X2146                R703 1
    X2146                R721 -1
    X2147                OBJ 7.2000000000000002
    X2147                R84 1
    X2147                R720 -1
    X2147                R721 1
    X2148                OBJ 7.2000000000000002
    X2148                R84 1
    X2148                R720 1
    X2148                R721 -1
    X2149                OBJ 3.27
    X2149                R85 1
    X2149                R719 -1
    X2149                R721 1
    X2150                OBJ 3.27
    X2150                R85 1
    X2150                R719 1
    X2150                R721 -1
    X2151                OBJ 5.3399999999999999
    X2151                R87 1
    X2151                R703 1
    X2151                R722 -1
    X2152                OBJ 5.3399999999999999
    X2152                R87 1
    X2152                R703 -1
    X2152                R722 1
    X2153                OBJ 6.3799999999999999
    X2153                R88 1
    X2153                R692 1
    X2153                R720 -1
    X2154                OBJ 6.3799999999999999
    X2154                R88 1
    X2154                R692 -1
    X2154                R720 1
    X2155                OBJ 6
    X2155                R89 1
    X2155                R708 1
    X2155                R715 -1
    X2156                OBJ 6
    X2156                R89 1
    X2156                R708 -1
    X2156                R715 1
    X2157                OBJ 3.7599999999999998
    X2157                R90 1
    X2157                R704 1
    X2157                R722 -1
    X2158                OBJ 3.7599999999999998
    X2158                R90 1
    X2158                R704 -1
    X2158                R722 1
    X2159                OBJ 7.8300000000000001
    X2159                R91 1
    X2159                R694 -1
    X2159                R720 1
    X2160                OBJ 7.8300000000000001
    X2160                R91 1
    X2160                R694 1
    X2160                R720 -1
    X2161                OBJ 2.1800000000000002
    X2161                R92 1
    X2161                R715 1
    X2161                R719 -1
    X2162                OBJ 2.1800000000000002
    X2162                R92 1
    X2162                R715 -1
    X2162                R719 1
    X2163                OBJ 4
    X2163                R93 1
    X2163                R694 -1
    X2163                R722 1
    X2164                OBJ 4
    X2164                R93 1
    X2164                R694 1
    X2164                R722 -1
    X2165                OBJ 2.5899999999999999
    X2165                R2 1
    X2165                R723 1
    X2165                R724 -1
    X2166                OBJ 2.5899999999999999
    X2166                R2 1
    X2166                R723 -1
    X2166                R724 1
    X2167                OBJ 10.67
    X2167                R4 1
    X2167                R723 1
    X2167                R725 -1
    X2168                OBJ 10.67
    X2168                R4 1
    X2168                R723 -1
    X2168                R725 1
    X2169                OBJ 5.5199999999999996
    X2169                R6 1
    X2169                R723 1
    X2169                R726 -1
    X2170                OBJ 5.5199999999999996
    X2170                R6 1
    X2170                R723 -1
    X2170                R726 1
    X2171                OBJ 5.4000000000000004
    X2171                R8 1
    X2171                R723 1
    X2171                R727 -1
    X2172                OBJ 5.4000000000000004
    X2172                R8 1
    X2172                R723 -1
    X2172                R727 1
    X2173                OBJ 13.630000000000001
    X2173                R11 1
    X2173                R728 -1
    X2173                R729 1
    X2174                OBJ 7.9400000000000004
    X2174                R13 1
    X2174                R728 1
    X2174                R730 -1
    X2175                OBJ 7.9400000000000004
    X2175                R13 1
    X2175                R728 -1
    X2175                R730 1
    X2176                OBJ 15
    X2176                R15 1
    X2176                R728 1
    X2176                R731 -1
    X2177                OBJ 15
    X2177                R15 1
    X2177                R728 -1
    X2177                R731 1
    X2178                OBJ 7.5999999999999996
    X2178                R18 1
    X2178                R732 1
    X2178                R733 -1
    X2179                OBJ 7.5999999999999996
    X2179                R18 1
    X2179                R732 -1
    X2179                R733 1
    X2180                OBJ 5.0800000000000001
    X2180                R20 1
    X2180                R732 1
    X2180                R734 -1
    X2181                OBJ 5.0800000000000001
    X2181                R20 1
    X2181                R732 -1
    X2181                R734 1
    X2182                OBJ 12.44
    X2182                R22 1
    X2182                R732 1
    X2182                R735 -1
    X2183                OBJ 12.44
    X2183                R22 1
    X2183                R732 -1
    X2183                R735 1
    X2184                OBJ 4.7400000000000002
    X2184                R25 1
    X2184                R736 1
    X2184                R737 -1
    X2185                OBJ 4.7400000000000002
    X2185                R25 1
    X2185                R736 -1
    X2185                R737 1
    X2186                OBJ 4.8700000000000001
    X2186                R26 1
    X2186                R730 -1
    X2186                R736 1
    X2187                OBJ 4.8700000000000001
    X2187                R26 1
    X2187                R730 1
    X2187                R736 -1
    X2188                OBJ 5.5099999999999998
    X2188                R27 1
    X2188                R731 -1
    X2188                R736 1
    X2189                OBJ 5.5099999999999998
    X2189                R27 1
    X2189                R731 1
    X2189                R736 -1
    X2190                OBJ 5.4000000000000004
    X2190                R30 1
    X2190                R738 1
    X2190                R739 -1
    X2191                OBJ 5.4000000000000004
    X2191                R30 1
    X2191                R738 -1
    X2191                R739 1
    X2192                OBJ 3.8100000000000001
    X2192                R31 1
    X2192                R726 -1
    X2192                R738 1
    X2193                OBJ 3.8100000000000001
    X2193                R31 1
    X2193                R726 1
    X2193                R738 -1
    X2194                OBJ 7.5700000000000003
    X2194                R33 1
    X2194                R738 1
    X2194                R740 -1
    X2195                OBJ 7.5700000000000003
    X2195                R33 1
    X2195                R738 -1
    X2195                R740 1
    X2196                OBJ 4.2000000000000002
    X2196                R35 1
    X2196                R738 1
    X2196                R741 -1
    X2197                OBJ 4.2000000000000002
    X2197                R35 1
    X2197                R738 -1
    X2197                R741 1
    X2198                OBJ 7.75
    X2198                R37 1
    X2198                R738 1
    X2198                R742 -1
    X2199                OBJ 7.75
    X2199                R37 1
    X2199                R738 -1
    X2199                R742 1
    X2200                OBJ 6.0999999999999996
    X2200                R39 1
    X2200                R725 -1
    X2200                R743 1
    X2201                OBJ 6.0999999999999996
    X2201                R39 1
    X2201                R725 1
    X2201                R743 -1
    X2202                OBJ 2.3900000000000001
    X2202                R40 1
    X2202                R727 -1
    X2202                R743 1
    X2203                OBJ 2.3900000000000001
    X2203                R40 1
    X2203                R727 1
    X2203                R743 -1
    X2204                OBJ 8.3399999999999999
    X2204                R42 1
    X2204                R733 -1
    X2204                R744 1
    X2205                OBJ 8.3399999999999999
    X2205                R42 1
    X2205                R733 1
    X2205                R744 -1
    X2206                OBJ 7.5599999999999996
    X2206                R43 1
    X2206                R734 -1
    X2206                R744 1
    X2207                OBJ 7.5599999999999996
    X2207                R43 1
    X2207                R734 1
    X2207                R744 -1
    X2208                OBJ 7.4699999999999998
    X2208                R45 1
    X2208                R744 1
    X2208                R745 -1
    X2209                OBJ 7.4699999999999998
    X2209                R45 1
    X2209                R744 -1
    X2209                R745 1
    X2210                OBJ 2.6400000000000001
    X2210                R47 1
    X2210                R724 1
    X2210                R746 -1
    X2211                OBJ 2.6400000000000001
    X2211                R47 1
    X2211                R724 -1
    X2211                R746 1
    X2212                OBJ 3.9300000000000002
    X2212                R48 1
    X2212                R724 1
    X2212                R745 -1
    X2213                OBJ 3.9300000000000002
    X2213                R48 1
    X2213                R724 -1
    X2213                R745 1
    X2214                OBJ 4.3600000000000003
    X2214                R50 1
    X2214                R737 1
    X2214                R747 -1
    X2215                OBJ 4.3600000000000003
    X2215                R50 1
    X2215                R737 -1
    X2215                R747 1
    X2216                OBJ 6.6799999999999997
    X2216                R51 1
    X2216                R737 1
    X2216                R741 -1
    X2217                OBJ 6.6799999999999997
    X2217                R51 1
    X2217                R737 -1
    X2217                R741 1
    X2218                OBJ 7.2199999999999998
    X2218                R53 1
    X2218                R739 1
    X2218                R748 -1
    X2219                OBJ 7.2199999999999998
    X2219                R53 1
    X2219                R739 -1
    X2219                R748 1
    X2220                OBJ 7.7699999999999996
    X2220                R55 1
    X2220                R739 1
    X2220                R749 -1
    X2221                OBJ 7.7699999999999996
    X2221                R55 1
    X2221                R739 -1
    X2221                R749 1
    X2222                OBJ 4.6200000000000001
    X2222                R57 1
    X2222                R725 -1
    X2222                R750 1
    X2223                OBJ 4.6200000000000001
    X2223                R57 1
    X2223                R725 1
    X2223                R750 -1
    X2224                OBJ 6.9000000000000004
    X2224                R58 1
    X2224                R727 -1
    X2224                R750 1
    X2225                OBJ 6.9000000000000004
    X2225                R58 1
    X2225                R727 1
    X2225                R750 -1
    X2226                OBJ 2.75
    X2226                R60 1
    X2226                R746 1
    X2226                R751 -1
    X2227                OBJ 2.75
    X2227                R60 1
    X2227                R746 -1
    X2227                R751 1
    X2228                OBJ 5.9199999999999999
    X2228                R61 1
    X2228                R726 -1
    X2228                R751 1
    X2229                OBJ 5.9199999999999999
    X2229                R61 1
    X2229                R726 1
    X2229                R751 -1
    X2230                OBJ 4.5599999999999996
    X2230                R62 1
    X2230                R740 -1
    X2230                R751 1
    X2231                OBJ 4.5599999999999996
    X2231                R62 1
    X2231                R740 1
    X2231                R751 -1
    X2232                OBJ 2.71
    X2232                R64 1
    X2232                R751 1
    X2232                R752 -1
    X2233                OBJ 2.71
    X2233                R64 1
    X2233                R751 -1
    X2233                R752 1
    X2234                OBJ 11.82
    X2234                R66 1
    X2234                R748 -1
    X2234                R753 1
    X2235                OBJ 11.82
    X2235                R66 1
    X2235                R748 1
    X2235                R753 -1
    X2236                OBJ 5.9699999999999998
    X2236                R67 1
    X2236                R749 -1
    X2236                R753 1
    X2237                OBJ 5.9699999999999998
    X2237                R67 1
    X2237                R749 1
    X2237                R753 -1
    X2238                OBJ 13.699999999999999
    X2238                R68 1
    X2238                R742 -1
    X2238                R753 1
    X2239                OBJ 13.699999999999999
    X2239                R68 1
    X2239                R742 1
    X2239                R753 -1
    X2240                OBJ 3.8300000000000001
    X2240                R69 1
    X2240                R742 -1
    X2240                R747 1
    X2241                OBJ 3.8300000000000001
    X2241                R69 1
    X2241                R742 1
    X2241                R747 -1
    X2242                OBJ 19.77
    X2242                R71 1
    X2242                R727 -1
    X2242                R754 1
    X2243                OBJ 19.77
    X2243                R71 1
    X2243                R727 1
    X2243                R754 -1
    X2244                OBJ 7.5099999999999998
    X2244                R72 1
    X2244                R733 -1
    X2244                R754 1
    X2245                OBJ 7.5099999999999998
    X2245                R72 1
    X2245                R733 1
    X2245                R754 -1
    X2246                OBJ 4.71
    X2246                R73 1
    X2246                R735 -1
    X2246                R754 1
    X2247                OBJ 4.71
    X2247                R73 1
    X2247                R735 1
    X2247                R754 -1
    X2248                OBJ 5.1399999999999997
    X2248                R74 1
    X2248                R727 1
    X2248                R745 -1
    X2249                OBJ 5.1399999999999997
    X2249                R74 1
    X2249                R727 -1
    X2249                R745 1
    X2250                OBJ 4.1100000000000003
    X2250                R76 1
    X2250                R734 -1
    X2250                R755 1
    X2251                OBJ 4.1100000000000003
    X2251                R76 1
    X2251                R734 1
    X2251                R755 -1
    X2252                OBJ 5.9400000000000004
    X2252                R77 1
    X2252                R745 -1
    X2252                R755 1
    X2253                OBJ 5.9400000000000004
    X2253                R77 1
    X2253                R745 1
    X2253                R755 -1
    X2254                OBJ 5.0700000000000003
    X2254                R79 1
    X2254                R755 1
    X2254                R756 -1
    X2255                OBJ 5.0700000000000003
    X2255                R79 1
    X2255                R755 -1
    X2255                R756 1
    X2256                OBJ 9.0700000000000003
    X2256                R81 1
    X2256                R734 1
    X2256                R757 -1
    X2257                OBJ 9.0700000000000003
    X2257                R81 1
    X2257                R734 -1
    X2257                R757 1
    X2258                OBJ 5.2199999999999998
    X2258                R83 1
    X2258                R740 -1
    X2258                R758 1
    X2259                OBJ 5.2199999999999998
    X2259                R83 1
    X2259                R740 1
    X2259                R758 -1
    X2260                OBJ 7.2000000000000002
    X2260                R84 1
    X2260                R757 -1
    X2260                R758 1
    X2261                OBJ 7.2000000000000002
    X2261                R84 1
    X2261                R757 1
    X2261                R758 -1
    X2262                OBJ 3.27
    X2262                R85 1
    X2262                R756 -1
    X2262                R758 1
    X2263                OBJ 3.27
    X2263                R85 1
    X2263                R756 1
    X2263                R758 -1
    X2264                OBJ 5.3399999999999999
    X2264                R87 1
    X2264                R740 1
    X2264                R759 -1
    X2265                OBJ 5.3399999999999999
    X2265                R87 1
    X2265                R740 -1
    X2265                R759 1
    X2266                OBJ 6.3799999999999999
    X2266                R88 1
    X2266                R729 1
    X2266                R757 -1
    X2267                OBJ 6
    X2267                R89 1
    X2267                R745 1
    X2267                R752 -1
    X2268                OBJ 6
    X2268                R89 1
    X2268                R745 -1
    X2268                R752 1
    X2269                OBJ 3.7599999999999998
    X2269                R90 1
    X2269                R741 1
    X2269                R759 -1
    X2270                OBJ 3.7599999999999998
    X2270                R90 1
    X2270                R741 -1
    X2270                R759 1
    X2271                OBJ 7.8300000000000001
    X2271                R91 1
    X2271                R731 -1
    X2271                R757 1
    X2272                OBJ 7.8300000000000001
    X2272                R91 1
    X2272                R731 1
    X2272                R757 -1
    X2273                OBJ 2.1800000000000002
    X2273                R92 1
    X2273                R752 1
    X2273                R756 -1
    X2274                OBJ 2.1800000000000002
    X2274                R92 1
    X2274                R752 -1
    X2274                R756 1
    X2275                OBJ 4
    X2275                R93 1
    X2275                R731 -1
    X2275                R759 1
    X2276                OBJ 4
    X2276                R93 1
    X2276                R731 1
    X2276                R759 -1
    X2277                OBJ 2.5899999999999999
    X2277                R2 1
    X2277                R760 1
    X2277                R761 -1
    X2278                OBJ 2.5899999999999999
    X2278                R2 1
    X2278                R760 -1
    X2278                R761 1
    X2279                OBJ 10.67
    X2279                R4 1
    X2279                R760 1
    X2279                R762 -1
    X2280                OBJ 10.67
    X2280                R4 1
    X2280                R760 -1
    X2280                R762 1
    X2281                OBJ 5.5199999999999996
    X2281                R6 1
    X2281                R760 1
    X2281                R763 -1
    X2282                OBJ 5.5199999999999996
    X2282                R6 1
    X2282                R760 -1
    X2282                R763 1
    X2283                OBJ 5.4000000000000004
    X2283                R8 1
    X2283                R760 1
    X2283                R764 -1
    X2284                OBJ 5.4000000000000004
    X2284                R8 1
    X2284                R760 -1
    X2284                R764 1
    X2285                OBJ 13.630000000000001
    X2285                R11 1
    X2285                R765 1
    X2285                R766 -1
    X2286                OBJ 13.630000000000001
    X2286                R11 1
    X2286                R765 -1
    X2286                R766 1
    X2287                OBJ 7.9400000000000004
    X2287                R13 1
    X2287                R765 1
    X2287                R767 -1
    X2288                OBJ 7.9400000000000004
    X2288                R13 1
    X2288                R765 -1
    X2288                R767 1
    X2289                OBJ 15
    X2289                R15 1
    X2289                R765 1
    X2289                R768 -1
    X2290                OBJ 15
    X2290                R15 1
    X2290                R765 -1
    X2290                R768 1
    X2291                OBJ 7.5999999999999996
    X2291                R18 1
    X2291                R769 1
    X2291                R770 -1
    X2292                OBJ 7.5999999999999996
    X2292                R18 1
    X2292                R769 -1
    X2292                R770 1
    X2293                OBJ 5.0800000000000001
    X2293                R20 1
    X2293                R769 -1
    X2293                R771 1
    X2294                OBJ 12.44
    X2294                R22 1
    X2294                R769 1
    X2294                R772 -1
    X2295                OBJ 12.44
    X2295                R22 1
    X2295                R769 -1
    X2295                R772 1
    X2296                OBJ 4.7400000000000002
    X2296                R25 1
    X2296                R773 1
    X2296                R774 -1
    X2297                OBJ 4.7400000000000002
    X2297                R25 1
    X2297                R773 -1
    X2297                R774 1
    X2298                OBJ 4.8700000000000001
    X2298                R26 1
    X2298                R767 -1
    X2298                R773 1
    X2299                OBJ 4.8700000000000001
    X2299                R26 1
    X2299                R767 1
    X2299                R773 -1
    X2300                OBJ 5.5099999999999998
    X2300                R27 1
    X2300                R768 -1
    X2300                R773 1
    X2301                OBJ 5.5099999999999998
    X2301                R27 1
    X2301                R768 1
    X2301                R773 -1
    X2302                OBJ 5.4000000000000004
    X2302                R30 1
    X2302                R775 1
    X2302                R776 -1
    X2303                OBJ 5.4000000000000004
    X2303                R30 1
    X2303                R775 -1
    X2303                R776 1
    X2304                OBJ 3.8100000000000001
    X2304                R31 1
    X2304                R763 -1
    X2304                R775 1
    X2305                OBJ 3.8100000000000001
    X2305                R31 1
    X2305                R763 1
    X2305                R775 -1
    X2306                OBJ 7.5700000000000003
    X2306                R33 1
    X2306                R775 1
    X2306                R777 -1
    X2307                OBJ 7.5700000000000003
    X2307                R33 1
    X2307                R775 -1
    X2307                R777 1
    X2308                OBJ 4.2000000000000002
    X2308                R35 1
    X2308                R775 1
    X2308                R778 -1
    X2309                OBJ 4.2000000000000002
    X2309                R35 1
    X2309                R775 -1
    X2309                R778 1
    X2310                OBJ 7.75
    X2310                R37 1
    X2310                R775 1
    X2310                R779 -1
    X2311                OBJ 7.75
    X2311                R37 1
    X2311                R775 -1
    X2311                R779 1
    X2312                OBJ 6.0999999999999996
    X2312                R39 1
    X2312                R762 -1
    X2312                R780 1
    X2313                OBJ 6.0999999999999996
    X2313                R39 1
    X2313                R762 1
    X2313                R780 -1
    X2314                OBJ 2.3900000000000001
    X2314                R40 1
    X2314                R764 -1
    X2314                R780 1
    X2315                OBJ 2.3900000000000001
    X2315                R40 1
    X2315                R764 1
    X2315                R780 -1
    X2316                OBJ 8.3399999999999999
    X2316                R42 1
    X2316                R770 -1
    X2316                R781 1
    X2317                OBJ 8.3399999999999999
    X2317                R42 1
    X2317                R770 1
    X2317                R781 -1
    X2318                OBJ 7.5599999999999996
    X2318                R43 1
    X2318                R771 1
    X2318                R781 -1
    X2319                OBJ 7.4699999999999998
    X2319                R45 1
    X2319                R781 1
    X2319                R782 -1
    X2320                OBJ 7.4699999999999998
    X2320                R45 1
    X2320                R781 -1
    X2320                R782 1
    X2321                OBJ 2.6400000000000001
    X2321                R47 1
    X2321                R761 1
    X2321                R783 -1
    X2322                OBJ 2.6400000000000001
    X2322                R47 1
    X2322                R761 -1
    X2322                R783 1
    X2323                OBJ 3.9300000000000002
    X2323                R48 1
    X2323                R761 1
    X2323                R782 -1
    X2324                OBJ 3.9300000000000002
    X2324                R48 1
    X2324                R761 -1
    X2324                R782 1
    X2325                OBJ 4.3600000000000003
    X2325                R50 1
    X2325                R774 1
    X2325                R784 -1
    X2326                OBJ 4.3600000000000003
    X2326                R50 1
    X2326                R774 -1
    X2326                R784 1
    X2327                OBJ 6.6799999999999997
    X2327                R51 1
    X2327                R774 1
    X2327                R778 -1
    X2328                OBJ 6.6799999999999997
    X2328                R51 1
    X2328                R774 -1
    X2328                R778 1
    X2329                OBJ 7.2199999999999998
    X2329                R53 1
    X2329                R776 1
    X2329                R785 -1
    X2330                OBJ 7.2199999999999998
    X2330                R53 1
    X2330                R776 -1
    X2330                R785 1
    X2331                OBJ 7.7699999999999996
    X2331                R55 1
    X2331                R776 1
    X2331                R786 -1
    X2332                OBJ 7.7699999999999996
    X2332                R55 1
    X2332                R776 -1
    X2332                R786 1
    X2333                OBJ 4.6200000000000001
    X2333                R57 1
    X2333                R762 -1
    X2333                R787 1
    X2334                OBJ 4.6200000000000001
    X2334                R57 1
    X2334                R762 1
    X2334                R787 -1
    X2335                OBJ 6.9000000000000004
    X2335                R58 1
    X2335                R764 -1
    X2335                R787 1
    X2336                OBJ 6.9000000000000004
    X2336                R58 1
    X2336                R764 1
    X2336                R787 -1
    X2337                OBJ 2.75
    X2337                R60 1
    X2337                R783 1
    X2337                R788 -1
    X2338                OBJ 2.75
    X2338                R60 1
    X2338                R783 -1
    X2338                R788 1
    X2339                OBJ 5.9199999999999999
    X2339                R61 1
    X2339                R763 -1
    X2339                R788 1
    X2340                OBJ 5.9199999999999999
    X2340                R61 1
    X2340                R763 1
    X2340                R788 -1
    X2341                OBJ 4.5599999999999996
    X2341                R62 1
    X2341                R777 -1
    X2341                R788 1
    X2342                OBJ 4.5599999999999996
    X2342                R62 1
    X2342                R777 1
    X2342                R788 -1
    X2343                OBJ 2.71
    X2343                R64 1
    X2343                R788 1
    X2343                R789 -1
    X2344                OBJ 2.71
    X2344                R64 1
    X2344                R788 -1
    X2344                R789 1
    X2345                OBJ 11.82
    X2345                R66 1
    X2345                R785 -1
    X2345                R790 1
    X2346                OBJ 11.82
    X2346                R66 1
    X2346                R785 1
    X2346                R790 -1
    X2347                OBJ 5.9699999999999998
    X2347                R67 1
    X2347                R786 -1
    X2347                R790 1
    X2348                OBJ 5.9699999999999998
    X2348                R67 1
    X2348                R786 1
    X2348                R790 -1
    X2349                OBJ 13.699999999999999
    X2349                R68 1
    X2349                R779 -1
    X2349                R790 1
    X2350                OBJ 13.699999999999999
    X2350                R68 1
    X2350                R779 1
    X2350                R790 -1
    X2351                OBJ 3.8300000000000001
    X2351                R69 1
    X2351                R779 -1
    X2351                R784 1
    X2352                OBJ 3.8300000000000001
    X2352                R69 1
    X2352                R779 1
    X2352                R784 -1
    X2353                OBJ 19.77
    X2353                R71 1
    X2353                R764 -1
    X2353                R791 1
    X2354                OBJ 19.77
    X2354                R71 1
    X2354                R764 1
    X2354                R791 -1
    X2355                OBJ 7.5099999999999998
    X2355                R72 1
    X2355                R770 -1
    X2355                R791 1
    X2356                OBJ 7.5099999999999998
    X2356                R72 1
    X2356                R770 1
    X2356                R791 -1
    X2357                OBJ 4.71
    X2357                R73 1
    X2357                R772 -1
    X2357                R791 1
    X2358                OBJ 4.71
    X2358                R73 1
    X2358                R772 1
    X2358                R791 -1
    X2359                OBJ 5.1399999999999997
    X2359                R74 1
    X2359                R764 1
    X2359                R782 -1
    X2360                OBJ 5.1399999999999997
    X2360                R74 1
    X2360                R764 -1
    X2360                R782 1
    X2361                OBJ 4.1100000000000003
    X2361                R76 1
    X2361                R771 1
    X2361                R792 -1
    X2362                OBJ 5.9400000000000004
    X2362                R77 1
    X2362                R782 -1
    X2362                R792 1
    X2363                OBJ 5.9400000000000004
    X2363                R77 1
    X2363                R782 1
    X2363                R792 -1
    X2364                OBJ 5.0700000000000003
    X2364                R79 1
    X2364                R792 1
    X2364                R793 -1
    X2365                OBJ 5.0700000000000003
    X2365                R79 1
    X2365                R792 -1
    X2365                R793 1
    X2366                OBJ 9.0700000000000003
    X2366                R81 1
    X2366                R771 1
    X2366                R794 -1
    X2367                OBJ 5.2199999999999998
    X2367                R83 1
    X2367                R777 -1
    X2367                R795 1
    X2368                OBJ 5.2199999999999998
    X2368                R83 1
    X2368                R777 1
    X2368                R795 -1
    X2369                OBJ 7.2000000000000002
    X2369                R84 1
    X2369                R794 -1
    X2369                R795 1
    X2370                OBJ 7.2000000000000002
    X2370                R84 1
    X2370                R794 1
    X2370                R795 -1
    X2371                OBJ 3.27
    X2371                R85 1
    X2371                R793 -1
    X2371                R795 1
    X2372                OBJ 3.27
    X2372                R85 1
    X2372                R793 1
    X2372                R795 -1
    X2373                OBJ 5.3399999999999999
    X2373                R87 1
    X2373                R777 1
    X2373                R796 -1
    X2374                OBJ 5.3399999999999999
    X2374                R87 1
    X2374                R777 -1
    X2374                R796 1
    X2375                OBJ 6.3799999999999999
    X2375                R88 1
    X2375                R766 1
    X2375                R794 -1
    X2376                OBJ 6.3799999999999999
    X2376                R88 1
    X2376                R766 -1
    X2376                R794 1
    X2377                OBJ 6
    X2377                R89 1
    X2377                R782 1
    X2377                R789 -1
    X2378                OBJ 6
    X2378                R89 1
    X2378                R782 -1
    X2378                R789 1
    X2379                OBJ 3.7599999999999998
    X2379                R90 1
    X2379                R778 1
    X2379                R796 -1
    X2380                OBJ 3.7599999999999998
    X2380                R90 1
    X2380                R778 -1
    X2380                R796 1
    X2381                OBJ 7.8300000000000001
    X2381                R91 1
    X2381                R768 -1
    X2381                R794 1
    X2382                OBJ 7.8300000000000001
    X2382                R91 1
    X2382                R768 1
    X2382                R794 -1
    X2383                OBJ 2.1800000000000002
    X2383                R92 1
    X2383                R789 1
    X2383                R793 -1
    X2384                OBJ 2.1800000000000002
    X2384                R92 1
    X2384                R789 -1
    X2384                R793 1
    X2385                OBJ 4
    X2385                R93 1
    X2385                R768 -1
    X2385                R796 1
    X2386                OBJ 4
    X2386                R93 1
    X2386                R768 1
    X2386                R796 -1
    X2387                OBJ 2.5899999999999999
    X2387                R2 1
    X2387                R797 1
    X2387                R798 -1
    X2388                OBJ 2.5899999999999999
    X2388                R2 1
    X2388                R797 -1
    X2388                R798 1
    X2389                OBJ 10.67
    X2389                R4 1
    X2389                R797 1
    X2389                R799 -1
    X2390                OBJ 10.67
    X2390                R4 1
    X2390                R797 -1
    X2390                R799 1
    X2391                OBJ 5.5199999999999996
    X2391                R6 1
    X2391                R797 1
    X2391                R800 -1
    X2392                OBJ 5.5199999999999996
    X2392                R6 1
    X2392                R797 -1
    X2392                R800 1
    X2393                OBJ 5.4000000000000004
    X2393                R8 1
    X2393                R797 1
    X2393                R801 -1
    X2394                OBJ 5.4000000000000004
    X2394                R8 1
    X2394                R797 -1
    X2394                R801 1
    X2395                OBJ 13.630000000000001
    X2395                R11 1
    X2395                R802 1
    X2395                R803 -1
    X2396                OBJ 13.630000000000001
    X2396                R11 1
    X2396                R802 -1
    X2396                R803 1
    X2397                OBJ 7.9400000000000004
    X2397                R13 1
    X2397                R802 1
    X2397                R804 -1
    X2398                OBJ 7.9400000000000004
    X2398                R13 1
    X2398                R802 -1
    X2398                R804 1
    X2399                OBJ 15
    X2399                R15 1
    X2399                R802 1
    X2399                R805 -1
    X2400                OBJ 15
    X2400                R15 1
    X2400                R802 -1
    X2400                R805 1
    X2401                OBJ 7.5999999999999996
    X2401                R18 1
    X2401                R806 1
    X2401                R807 -1
    X2402                OBJ 7.5999999999999996
    X2402                R18 1
    X2402                R806 -1
    X2402                R807 1
    X2403                OBJ 5.0800000000000001
    X2403                R20 1
    X2403                R806 1
    X2403                R808 -1
    X2404                OBJ 5.0800000000000001
    X2404                R20 1
    X2404                R806 -1
    X2404                R808 1
    X2405                OBJ 12.44
    X2405                R22 1
    X2405                R806 1
    X2405                R809 -1
    X2406                OBJ 12.44
    X2406                R22 1
    X2406                R806 -1
    X2406                R809 1
    X2407                OBJ 4.7400000000000002
    X2407                R25 1
    X2407                R810 1
    X2407                R811 -1
    X2408                OBJ 4.7400000000000002
    X2408                R25 1
    X2408                R810 -1
    X2408                R811 1
    X2409                OBJ 4.8700000000000001
    X2409                R26 1
    X2409                R804 -1
    X2409                R810 1
    X2410                OBJ 4.8700000000000001
    X2410                R26 1
    X2410                R804 1
    X2410                R810 -1
    X2411                OBJ 5.5099999999999998
    X2411                R27 1
    X2411                R805 -1
    X2411                R810 1
    X2412                OBJ 5.5099999999999998
    X2412                R27 1
    X2412                R805 1
    X2412                R810 -1
    X2413                OBJ 5.4000000000000004
    X2413                R30 1
    X2413                R812 -1
    X2413                R813 1
    X2414                OBJ 3.8100000000000001
    X2414                R31 1
    X2414                R800 -1
    X2414                R812 1
    X2415                OBJ 3.8100000000000001
    X2415                R31 1
    X2415                R800 1
    X2415                R812 -1
    X2416                OBJ 7.5700000000000003
    X2416                R33 1
    X2416                R812 1
    X2416                R814 -1
    X2417                OBJ 7.5700000000000003
    X2417                R33 1
    X2417                R812 -1
    X2417                R814 1
    X2418                OBJ 4.2000000000000002
    X2418                R35 1
    X2418                R812 1
    X2418                R815 -1
    X2419                OBJ 4.2000000000000002
    X2419                R35 1
    X2419                R812 -1
    X2419                R815 1
    X2420                OBJ 7.75
    X2420                R37 1
    X2420                R812 1
    X2420                R816 -1
    X2421                OBJ 7.75
    X2421                R37 1
    X2421                R812 -1
    X2421                R816 1
    X2422                OBJ 6.0999999999999996
    X2422                R39 1
    X2422                R799 -1
    X2422                R817 1
    X2423                OBJ 6.0999999999999996
    X2423                R39 1
    X2423                R799 1
    X2423                R817 -1
    X2424                OBJ 2.3900000000000001
    X2424                R40 1
    X2424                R801 -1
    X2424                R817 1
    X2425                OBJ 2.3900000000000001
    X2425                R40 1
    X2425                R801 1
    X2425                R817 -1
    X2426                OBJ 8.3399999999999999
    X2426                R42 1
    X2426                R807 -1
    X2426                R818 1
    X2427                OBJ 8.3399999999999999
    X2427                R42 1
    X2427                R807 1
    X2427                R818 -1
    X2428                OBJ 7.5599999999999996
    X2428                R43 1
    X2428                R808 -1
    X2428                R818 1
    X2429                OBJ 7.5599999999999996
    X2429                R43 1
    X2429                R808 1
    X2429                R818 -1
    X2430                OBJ 7.4699999999999998
    X2430                R45 1
    X2430                R818 1
    X2430                R819 -1
    X2431                OBJ 7.4699999999999998
    X2431                R45 1
    X2431                R818 -1
    X2431                R819 1
    X2432                OBJ 2.6400000000000001
    X2432                R47 1
    X2432                R798 1
    X2432                R820 -1
    X2433                OBJ 2.6400000000000001
    X2433                R47 1
    X2433                R798 -1
    X2433                R820 1
    X2434                OBJ 3.9300000000000002
    X2434                R48 1
    X2434                R798 1
    X2434                R819 -1
    X2435                OBJ 3.9300000000000002
    X2435                R48 1
    X2435                R798 -1
    X2435                R819 1
    X2436                OBJ 4.3600000000000003
    X2436                R50 1
    X2436                R811 1
    X2436                R821 -1
    X2437                OBJ 4.3600000000000003
    X2437                R50 1
    X2437                R811 -1
    X2437                R821 1
    X2438                OBJ 6.6799999999999997
    X2438                R51 1
    X2438                R811 1
    X2438                R815 -1
    X2439                OBJ 6.6799999999999997
    X2439                R51 1
    X2439                R811 -1
    X2439                R815 1
    X2440                OBJ 7.2199999999999998
    X2440                R53 1
    X2440                R813 1
    X2440                R822 -1
    X2441                OBJ 7.7699999999999996
    X2441                R55 1
    X2441                R813 1
    X2441                R823 -1
    X2442                OBJ 4.6200000000000001
    X2442                R57 1
    X2442                R799 -1
    X2442                R824 1
    X2443                OBJ 4.6200000000000001
    X2443                R57 1
    X2443                R799 1
    X2443                R824 -1
    X2444                OBJ 6.9000000000000004
    X2444                R58 1
    X2444                R801 -1
    X2444                R824 1
    X2445                OBJ 6.9000000000000004
    X2445                R58 1
    X2445                R801 1
    X2445                R824 -1
    X2446                OBJ 2.75
    X2446                R60 1
    X2446                R820 1
    X2446                R825 -1
    X2447                OBJ 2.75
    X2447                R60 1
    X2447                R820 -1
    X2447                R825 1
    X2448                OBJ 5.9199999999999999
    X2448                R61 1
    X2448                R800 -1
    X2448                R825 1
    X2449                OBJ 5.9199999999999999
    X2449                R61 1
    X2449                R800 1
    X2449                R825 -1
    X2450                OBJ 4.5599999999999996
    X2450                R62 1
    X2450                R814 -1
    X2450                R825 1
    X2451                OBJ 4.5599999999999996
    X2451                R62 1
    X2451                R814 1
    X2451                R825 -1
    X2452                OBJ 2.71
    X2452                R64 1
    X2452                R825 1
    X2452                R826 -1
    X2453                OBJ 2.71
    X2453                R64 1
    X2453                R825 -1
    X2453                R826 1
    X2454                OBJ 11.82
    X2454                R66 1
    X2454                R822 -1
    X2454                R827 1
    X2455                OBJ 11.82
    X2455                R66 1
    X2455                R822 1
    X2455                R827 -1
    X2456                OBJ 5.9699999999999998
    X2456                R67 1
    X2456                R823 -1
    X2456                R827 1
    X2457                OBJ 5.9699999999999998
    X2457                R67 1
    X2457                R823 1
    X2457                R827 -1
    X2458                OBJ 13.699999999999999
    X2458                R68 1
    X2458                R816 -1
    X2458                R827 1
    X2459                OBJ 13.699999999999999
    X2459                R68 1
    X2459                R816 1
    X2459                R827 -1
    X2460                OBJ 3.8300000000000001
    X2460                R69 1
    X2460                R816 -1
    X2460                R821 1
    X2461                OBJ 3.8300000000000001
    X2461                R69 1
    X2461                R816 1
    X2461                R821 -1
    X2462                OBJ 19.77
    X2462                R71 1
    X2462                R801 -1
    X2462                R828 1
    X2463                OBJ 19.77
    X2463                R71 1
    X2463                R801 1
    X2463                R828 -1
    X2464                OBJ 7.5099999999999998
    X2464                R72 1
    X2464                R807 -1
    X2464                R828 1
    X2465                OBJ 7.5099999999999998
    X2465                R72 1
    X2465                R807 1
    X2465                R828 -1
    X2466                OBJ 4.71
    X2466                R73 1
    X2466                R809 -1
    X2466                R828 1
    X2467                OBJ 4.71
    X2467                R73 1
    X2467                R809 1
    X2467                R828 -1
    X2468                OBJ 5.1399999999999997
    X2468                R74 1
    X2468                R801 1
    X2468                R819 -1
    X2469                OBJ 5.1399999999999997
    X2469                R74 1
    X2469                R801 -1
    X2469                R819 1
    X2470                OBJ 4.1100000000000003
    X2470                R76 1
    X2470                R808 -1
    X2470                R829 1
    X2471                OBJ 4.1100000000000003
    X2471                R76 1
    X2471                R808 1
    X2471                R829 -1
    X2472                OBJ 5.9400000000000004
    X2472                R77 1
    X2472                R819 -1
    X2472                R829 1
    X2473                OBJ 5.9400000000000004
    X2473                R77 1
    X2473                R819 1
    X2473                R829 -1
    X2474                OBJ 5.0700000000000003
    X2474                R79 1
    X2474                R829 1
    X2474                R830 -1
    X2475                OBJ 5.0700000000000003
    X2475                R79 1
    X2475                R829 -1
    X2475                R830 1
    X2476                OBJ 9.0700000000000003
    X2476                R81 1
    X2476                R808 1
    X2476                R831 -1
    X2477                OBJ 9.0700000000000003
    X2477                R81 1
    X2477                R808 -1
    X2477                R831 1
    X2478                OBJ 5.2199999999999998
    X2478                R83 1
    X2478                R814 -1
    X2478                R832 1
    X2479                OBJ 5.2199999999999998
    X2479                R83 1
    X2479                R814 1
    X2479                R832 -1
    X2480                OBJ 7.2000000000000002
    X2480                R84 1
    X2480                R831 -1
    X2480                R832 1
    X2481                OBJ 7.2000000000000002
    X2481                R84 1
    X2481                R831 1
    X2481                R832 -1
    X2482                OBJ 3.27
    X2482                R85 1
    X2482                R830 -1
    X2482                R832 1
    X2483                OBJ 3.27
    X2483                R85 1
    X2483                R830 1
    X2483                R832 -1
    X2484                OBJ 5.3399999999999999
    X2484                R87 1
    X2484                R814 1
    X2484                R833 -1
    X2485                OBJ 5.3399999999999999
    X2485                R87 1
    X2485                R814 -1
    X2485                R833 1
    X2486                OBJ 6.3799999999999999
    X2486                R88 1
    X2486                R803 1
    X2486                R831 -1
    X2487                OBJ 6.3799999999999999
    X2487                R88 1
    X2487                R803 -1
    X2487                R831 1
    X2488                OBJ 6
    X2488                R89 1
    X2488                R819 1
    X2488                R826 -1
    X2489                OBJ 6
    X2489                R89 1
    X2489                R819 -1
    X2489                R826 1
    X2490                OBJ 3.7599999999999998
    X2490                R90 1
    X2490                R815 1
    X2490                R833 -1
    X2491                OBJ 3.7599999999999998
    X2491                R90 1
    X2491                R815 -1
    X2491                R833 1
    X2492                OBJ 7.8300000000000001
    X2492                R91 1
    X2492                R805 -1
    X2492                R831 1
    X2493                OBJ 7.8300000000000001
    X2493                R91 1
    X2493                R805 1
    X2493                R831 -1
    X2494                OBJ 2.1800000000000002
    X2494                R92 1
    X2494                R826 1
    X2494                R830 -1
    X2495                OBJ 2.1800000000000002
    X2495                R92 1
    X2495                R826 -1
    X2495                R830 1
    X2496                OBJ 4
    X2496                R93 1
    X2496                R805 -1
    X2496                R833 1
    X2497                OBJ 4
    X2497                R93 1
    X2497                R805 1
    X2497                R833 -1
    X2498                OBJ 2.5899999999999999
    X2498                R2 1
    X2498                R834 1
    X2498                R835 -1
    X2499                OBJ 2.5899999999999999
    X2499                R2 1
    X2499                R834 -1
    X2499                R835 1
    X2500                OBJ 10.67
    X2500                R4 1
    X2500                R834 1
    X2500                R836 -1
    X2501                OBJ 10.67
    X2501                R4 1
    X2501                R834 -1
    X2501                R836 1
    X2502                OBJ 5.5199999999999996
    X2502                R6 1
    X2502                R834 1
    X2502                R837 -1
    X2503                OBJ 5.5199999999999996
    X2503                R6 1
    X2503                R834 -1
    X2503                R837 1
    X2504                OBJ 5.4000000000000004
    X2504                R8 1
    X2504                R834 1
    X2504                R838 -1
    X2505                OBJ 5.4000000000000004
    X2505                R8 1
    X2505                R834 -1
    X2505                R838 1
    X2506                OBJ 13.630000000000001
    X2506                R11 1
    X2506                R839 1
    X2506                R840 -1
    X2507                OBJ 13.630000000000001
    X2507                R11 1
    X2507                R839 -1
    X2507                R840 1
    X2508                OBJ 7.9400000000000004
    X2508                R13 1
    X2508                R839 1
    X2508                R841 -1
    X2509                OBJ 7.9400000000000004
    X2509                R13 1
    X2509                R839 -1
    X2509                R841 1
    X2510                OBJ 15
    X2510                R15 1
    X2510                R839 1
    X2510                R842 -1
    X2511                OBJ 15
    X2511                R15 1
    X2511                R839 -1
    X2511                R842 1
    X2512                OBJ 7.5999999999999996
    X2512                R18 1
    X2512                R843 1
    X2512                R844 -1
    X2513                OBJ 7.5999999999999996
    X2513                R18 1
    X2513                R843 -1
    X2513                R844 1
    X2514                OBJ 5.0800000000000001
    X2514                R20 1
    X2514                R843 1
    X2514                R845 -1
    X2515                OBJ 5.0800000000000001
    X2515                R20 1
    X2515                R843 -1
    X2515                R845 1
    X2516                OBJ 12.44
    X2516                R22 1
    X2516                R843 1
    X2516                R846 -1
    X2517                OBJ 12.44
    X2517                R22 1
    X2517                R843 -1
    X2517                R846 1
    X2518                OBJ 4.7400000000000002
    X2518                R25 1
    X2518                R847 1
    X2518                R848 -1
    X2519                OBJ 4.7400000000000002
    X2519                R25 1
    X2519                R847 -1
    X2519                R848 1
    X2520                OBJ 4.8700000000000001
    X2520                R26 1
    X2520                R841 -1
    X2520                R847 1
    X2521                OBJ 4.8700000000000001
    X2521                R26 1
    X2521                R841 1
    X2521                R847 -1
    X2522                OBJ 5.5099999999999998
    X2522                R27 1
    X2522                R842 -1
    X2522                R847 1
    X2523                OBJ 5.5099999999999998
    X2523                R27 1
    X2523                R842 1
    X2523                R847 -1
    X2524                OBJ 5.4000000000000004
    X2524                R30 1
    X2524                R849 1
    X2524                R850 -1
    X2525                OBJ 5.4000000000000004
    X2525                R30 1
    X2525                R849 -1
    X2525                R850 1
    X2526                OBJ 3.8100000000000001
    X2526                R31 1
    X2526                R837 -1
    X2526                R849 1
    X2527                OBJ 3.8100000000000001
    X2527                R31 1
    X2527                R837 1
    X2527                R849 -1
    X2528                OBJ 7.5700000000000003
    X2528                R33 1
    X2528                R849 1
    X2528                R851 -1
    X2529                OBJ 7.5700000000000003
    X2529                R33 1
    X2529                R849 -1
    X2529                R851 1
    X2530                OBJ 4.2000000000000002
    X2530                R35 1
    X2530                R849 1
    X2530                R852 -1
    X2531                OBJ 4.2000000000000002
    X2531                R35 1
    X2531                R849 -1
    X2531                R852 1
    X2532                OBJ 7.75
    X2532                R37 1
    X2532                R849 1
    X2532                R853 -1
    X2533                OBJ 7.75
    X2533                R37 1
    X2533                R849 -1
    X2533                R853 1
    X2534                OBJ 6.0999999999999996
    X2534                R39 1
    X2534                R836 -1
    X2534                R854 1
    X2535                OBJ 6.0999999999999996
    X2535                R39 1
    X2535                R836 1
    X2535                R854 -1
    X2536                OBJ 2.3900000000000001
    X2536                R40 1
    X2536                R838 -1
    X2536                R854 1
    X2537                OBJ 2.3900000000000001
    X2537                R40 1
    X2537                R838 1
    X2537                R854 -1
    X2538                OBJ 8.3399999999999999
    X2538                R42 1
    X2538                R844 -1
    X2538                R855 1
    X2539                OBJ 8.3399999999999999
    X2539                R42 1
    X2539                R844 1
    X2539                R855 -1
    X2540                OBJ 7.5599999999999996
    X2540                R43 1
    X2540                R845 -1
    X2540                R855 1
    X2541                OBJ 7.5599999999999996
    X2541                R43 1
    X2541                R845 1
    X2541                R855 -1
    X2542                OBJ 7.4699999999999998
    X2542                R45 1
    X2542                R855 1
    X2542                R856 -1
    X2543                OBJ 7.4699999999999998
    X2543                R45 1
    X2543                R855 -1
    X2543                R856 1
    X2544                OBJ 2.6400000000000001
    X2544                R47 1
    X2544                R835 1
    X2544                R857 -1
    X2545                OBJ 2.6400000000000001
    X2545                R47 1
    X2545                R835 -1
    X2545                R857 1
    X2546                OBJ 3.9300000000000002
    X2546                R48 1
    X2546                R835 1
    X2546                R856 -1
    X2547                OBJ 3.9300000000000002
    X2547                R48 1
    X2547                R835 -1
    X2547                R856 1
    X2548                OBJ 4.3600000000000003
    X2548                R50 1
    X2548                R848 1
    X2548                R858 -1
    X2549                OBJ 4.3600000000000003
    X2549                R50 1
    X2549                R848 -1
    X2549                R858 1
    X2550                OBJ 6.6799999999999997
    X2550                R51 1
    X2550                R848 1
    X2550                R852 -1
    X2551                OBJ 6.6799999999999997
    X2551                R51 1
    X2551                R848 -1
    X2551                R852 1
    X2552                OBJ 7.2199999999999998
    X2552                R53 1
    X2552                R850 1
    X2552                R859 -1
    X2553                OBJ 7.2199999999999998
    X2553                R53 1
    X2553                R850 -1
    X2553                R859 1
    X2554                OBJ 7.7699999999999996
    X2554                R55 1
    X2554                R850 1
    X2554                R860 -1
    X2555                OBJ 7.7699999999999996
    X2555                R55 1
    X2555                R850 -1
    X2555                R860 1
    X2556                OBJ 4.6200000000000001
    X2556                R57 1
    X2556                R836 -1
    X2556                R861 1
    X2557                OBJ 4.6200000000000001
    X2557                R57 1
    X2557                R836 1
    X2557                R861 -1
    X2558                OBJ 6.9000000000000004
    X2558                R58 1
    X2558                R838 -1
    X2558                R861 1
    X2559                OBJ 6.9000000000000004
    X2559                R58 1
    X2559                R838 1
    X2559                R861 -1
    X2560                OBJ 2.75
    X2560                R60 1
    X2560                R857 1
    X2560                R862 -1
    X2561                OBJ 2.75
    X2561                R60 1
    X2561                R857 -1
    X2561                R862 1
    X2562                OBJ 5.9199999999999999
    X2562                R61 1
    X2562                R837 -1
    X2562                R862 1
    X2563                OBJ 5.9199999999999999
    X2563                R61 1
    X2563                R837 1
    X2563                R862 -1
    X2564                OBJ 4.5599999999999996
    X2564                R62 1
    X2564                R851 -1
    X2564                R862 1
    X2565                OBJ 4.5599999999999996
    X2565                R62 1
    X2565                R851 1
    X2565                R862 -1
    X2566                OBJ 2.71
    X2566                R64 1
    X2566                R862 1
    X2566                R863 -1
    X2567                OBJ 2.71
    X2567                R64 1
    X2567                R862 -1
    X2567                R863 1
    X2568                OBJ 11.82
    X2568                R66 1
    X2568                R859 -1
    X2568                R864 1
    X2569                OBJ 11.82
    X2569                R66 1
    X2569                R859 1
    X2569                R864 -1
    X2570                OBJ 5.9699999999999998
    X2570                R67 1
    X2570                R860 -1
    X2570                R864 1
    X2571                OBJ 5.9699999999999998
    X2571                R67 1
    X2571                R860 1
    X2571                R864 -1
    X2572                OBJ 13.699999999999999
    X2572                R68 1
    X2572                R853 -1
    X2572                R864 1
    X2573                OBJ 13.699999999999999
    X2573                R68 1
    X2573                R853 1
    X2573                R864 -1
    X2574                OBJ 3.8300000000000001
    X2574                R69 1
    X2574                R853 -1
    X2574                R858 1
    X2575                OBJ 3.8300000000000001
    X2575                R69 1
    X2575                R853 1
    X2575                R858 -1
    X2576                OBJ 19.77
    X2576                R71 1
    X2576                R838 -1
    X2576                R865 1
    X2577                OBJ 7.5099999999999998
    X2577                R72 1
    X2577                R844 -1
    X2577                R865 1
    X2578                OBJ 4.71
    X2578                R73 1
    X2578                R846 -1
    X2578                R865 1
    X2579                OBJ 5.1399999999999997
    X2579                R74 1
    X2579                R838 1
    X2579                R856 -1
    X2580                OBJ 5.1399999999999997
    X2580                R74 1
    X2580                R838 -1
    X2580                R856 1
    X2581                OBJ 4.1100000000000003
    X2581                R76 1
    X2581                R845 -1
    X2581                R866 1
    X2582                OBJ 4.1100000000000003
    X2582                R76 1
    X2582                R845 1
    X2582                R866 -1
    X2583                OBJ 5.9400000000000004
    X2583                R77 1
    X2583                R856 -1
    X2583                R866 1
    X2584                OBJ 5.9400000000000004
    X2584                R77 1
    X2584                R856 1
    X2584                R866 -1
    X2585                OBJ 5.0700000000000003
    X2585                R79 1
    X2585                R866 1
    X2585                R867 -1
    X2586                OBJ 5.0700000000000003
    X2586                R79 1
    X2586                R866 -1
    X2586                R867 1
    X2587                OBJ 9.0700000000000003
    X2587                R81 1
    X2587                R845 1
    X2587                R868 -1
    X2588                OBJ 9.0700000000000003
    X2588                R81 1
    X2588                R845 -1
    X2588                R868 1
    X2589                OBJ 5.2199999999999998
    X2589                R83 1
    X2589                R851 -1
    X2589                R869 1
    X2590                OBJ 5.2199999999999998
    X2590                R83 1
    X2590                R851 1
    X2590                R869 -1
    X2591                OBJ 7.2000000000000002
    X2591                R84 1
    X2591                R868 -1
    X2591                R869 1
    X2592                OBJ 7.2000000000000002
    X2592                R84 1
    X2592                R868 1
    X2592                R869 -1
    X2593                OBJ 3.27
    X2593                R85 1
    X2593                R867 -1
    X2593                R869 1
    X2594                OBJ 3.27
    X2594                R85 1
    X2594                R867 1
    X2594                R869 -1
    X2595                OBJ 5.3399999999999999
    X2595                R87 1
    X2595                R851 1
    X2595                R870 -1
    X2596                OBJ 5.3399999999999999
    X2596                R87 1
    X2596                R851 -1
    X2596                R870 1
    X2597                OBJ 6.3799999999999999
    X2597                R88 1
    X2597                R840 1
    X2597                R868 -1
    X2598                OBJ 6.3799999999999999
    X2598                R88 1
    X2598                R840 -1
    X2598                R868 1
    X2599                OBJ 6
    X2599                R89 1
    X2599                R856 1
    X2599                R863 -1
    X2600                OBJ 6
    X2600                R89 1
    X2600                R856 -1
    X2600                R863 1
    X2601                OBJ 3.7599999999999998
    X2601                R90 1
    X2601                R852 1
    X2601                R870 -1
    X2602                OBJ 3.7599999999999998
    X2602                R90 1
    X2602                R852 -1
    X2602                R870 1
    X2603                OBJ 7.8300000000000001
    X2603                R91 1
    X2603                R842 -1
    X2603                R868 1
    X2604                OBJ 7.8300000000000001
    X2604                R91 1
    X2604                R842 1
    X2604                R868 -1
    X2605                OBJ 2.1800000000000002
    X2605                R92 1
    X2605                R863 1
    X2605                R867 -1
    X2606                OBJ 2.1800000000000002
    X2606                R92 1
    X2606                R863 -1
    X2606                R867 1
    X2607                OBJ 4
    X2607                R93 1
    X2607                R842 -1
    X2607                R870 1
    X2608                OBJ 4
    X2608                R93 1
    X2608                R842 1
    X2608                R870 -1
    X2609                OBJ 2.5899999999999999
    X2609                R2 1
    X2609                R871 1
    X2609                R872 -1
    X2610                OBJ 2.5899999999999999
    X2610                R2 1
    X2610                R871 -1
    X2610                R872 1
    X2611                OBJ 10.67
    X2611                R4 1
    X2611                R871 1
    X2611                R873 -1
    X2612                OBJ 10.67
    X2612                R4 1
    X2612                R871 -1
    X2612                R873 1
    X2613                OBJ 5.5199999999999996
    X2613                R6 1
    X2613                R871 1
    X2613                R874 -1
    X2614                OBJ 5.5199999999999996
    X2614                R6 1
    X2614                R871 -1
    X2614                R874 1
    X2615                OBJ 5.4000000000000004
    X2615                R8 1
    X2615                R871 1
    X2615                R875 -1
    X2616                OBJ 5.4000000000000004
    X2616                R8 1
    X2616                R871 -1
    X2616                R875 1
    X2617                OBJ 13.630000000000001
    X2617                R11 1
    X2617                R876 1
    X2617                R877 -1
    X2618                OBJ 13.630000000000001
    X2618                R11 1
    X2618                R876 -1
    X2618                R877 1
    X2619                OBJ 7.9400000000000004
    X2619                R13 1
    X2619                R876 1
    X2619                R878 -1
    X2620                OBJ 7.9400000000000004
    X2620                R13 1
    X2620                R876 -1
    X2620                R878 1
    X2621                OBJ 15
    X2621                R15 1
    X2621                R876 1
    X2621                R879 -1
    X2622                OBJ 15
    X2622                R15 1
    X2622                R876 -1
    X2622                R879 1
    X2623                OBJ 7.5999999999999996
    X2623                R18 1
    X2623                R880 1
    X2623                R881 -1
    X2624                OBJ 7.5999999999999996
    X2624                R18 1
    X2624                R880 -1
    X2624                R881 1
    X2625                OBJ 5.0800000000000001
    X2625                R20 1
    X2625                R880 1
    X2625                R882 -1
    X2626                OBJ 5.0800000000000001
    X2626                R20 1
    X2626                R880 -1
    X2626                R882 1
    X2627                OBJ 12.44
    X2627                R22 1
    X2627                R880 1
    X2627                R883 -1
    X2628                OBJ 12.44
    X2628                R22 1
    X2628                R880 -1
    X2628                R883 1
    X2629                OBJ 4.7400000000000002
    X2629                R25 1
    X2629                R884 1
    X2629                R885 -1
    X2630                OBJ 4.7400000000000002
    X2630                R25 1
    X2630                R884 -1
    X2630                R885 1
    X2631                OBJ 4.8700000000000001
    X2631                R26 1
    X2631                R878 -1
    X2631                R884 1
    X2632                OBJ 4.8700000000000001
    X2632                R26 1
    X2632                R878 1
    X2632                R884 -1
    X2633                OBJ 5.5099999999999998
    X2633                R27 1
    X2633                R879 -1
    X2633                R884 1
    X2634                OBJ 5.5099999999999998
    X2634                R27 1
    X2634                R879 1
    X2634                R884 -1
    X2635                OBJ 5.4000000000000004
    X2635                R30 1
    X2635                R886 1
    X2635                R887 -1
    X2636                OBJ 5.4000000000000004
    X2636                R30 1
    X2636                R886 -1
    X2636                R887 1
    X2637                OBJ 3.8100000000000001
    X2637                R31 1
    X2637                R874 -1
    X2637                R886 1
    X2638                OBJ 3.8100000000000001
    X2638                R31 1
    X2638                R874 1
    X2638                R886 -1
    X2639                OBJ 7.5700000000000003
    X2639                R33 1
    X2639                R886 1
    X2639                R888 -1
    X2640                OBJ 7.5700000000000003
    X2640                R33 1
    X2640                R886 -1
    X2640                R888 1
    X2641                OBJ 4.2000000000000002
    X2641                R35 1
    X2641                R886 1
    X2641                R889 -1
    X2642                OBJ 4.2000000000000002
    X2642                R35 1
    X2642                R886 -1
    X2642                R889 1
    X2643                OBJ 7.75
    X2643                R37 1
    X2643                R886 1
    X2643                R890 -1
    X2644                OBJ 7.75
    X2644                R37 1
    X2644                R886 -1
    X2644                R890 1
    X2645                OBJ 6.0999999999999996
    X2645                R39 1
    X2645                R873 -1
    X2645                R891 1
    X2646                OBJ 6.0999999999999996
    X2646                R39 1
    X2646                R873 1
    X2646                R891 -1
    X2647                OBJ 2.3900000000000001
    X2647                R40 1
    X2647                R875 -1
    X2647                R891 1
    X2648                OBJ 2.3900000000000001
    X2648                R40 1
    X2648                R875 1
    X2648                R891 -1
    X2649                OBJ 8.3399999999999999
    X2649                R42 1
    X2649                R881 -1
    X2649                R892 1
    X2650                OBJ 8.3399999999999999
    X2650                R42 1
    X2650                R881 1
    X2650                R892 -1
    X2651                OBJ 7.5599999999999996
    X2651                R43 1
    X2651                R882 -1
    X2651                R892 1
    X2652                OBJ 7.5599999999999996
    X2652                R43 1
    X2652                R882 1
    X2652                R892 -1
    X2653                OBJ 7.4699999999999998
    X2653                R45 1
    X2653                R892 1
    X2653                R893 -1
    X2654                OBJ 7.4699999999999998
    X2654                R45 1
    X2654                R892 -1
    X2654                R893 1
    X2655                OBJ 2.6400000000000001
    X2655                R47 1
    X2655                R872 1
    X2655                R894 -1
    X2656                OBJ 2.6400000000000001
    X2656                R47 1
    X2656                R872 -1
    X2656                R894 1
    X2657                OBJ 3.9300000000000002
    X2657                R48 1
    X2657                R872 1
    X2657                R893 -1
    X2658                OBJ 3.9300000000000002
    X2658                R48 1
    X2658                R872 -1
    X2658                R893 1
    X2659                OBJ 4.3600000000000003
    X2659                R50 1
    X2659                R885 1
    X2659                R895 -1
    X2660                OBJ 4.3600000000000003
    X2660                R50 1
    X2660                R885 -1
    X2660                R895 1
    X2661                OBJ 6.6799999999999997
    X2661                R51 1
    X2661                R885 1
    X2661                R889 -1
    X2662                OBJ 6.6799999999999997
    X2662                R51 1
    X2662                R885 -1
    X2662                R889 1
    X2663                OBJ 7.2199999999999998
    X2663                R53 1
    X2663                R887 1
    X2663                R896 -1
    X2664                OBJ 7.2199999999999998
    X2664                R53 1
    X2664                R887 -1
    X2664                R896 1
    X2665                OBJ 7.7699999999999996
    X2665                R55 1
    X2665                R887 1
    X2665                R897 -1
    X2666                OBJ 7.7699999999999996
    X2666                R55 1
    X2666                R887 -1
    X2666                R897 1
    X2667                OBJ 4.6200000000000001
    X2667                R57 1
    X2667                R873 -1
    X2667                R898 1
    X2668                OBJ 4.6200000000000001
    X2668                R57 1
    X2668                R873 1
    X2668                R898 -1
    X2669                OBJ 6.9000000000000004
    X2669                R58 1
    X2669                R875 -1
    X2669                R898 1
    X2670                OBJ 6.9000000000000004
    X2670                R58 1
    X2670                R875 1
    X2670                R898 -1
    X2671                OBJ 2.75
    X2671                R60 1
    X2671                R894 1
    X2671                R899 -1
    X2672                OBJ 2.75
    X2672                R60 1
    X2672                R894 -1
    X2672                R899 1
    X2673                OBJ 5.9199999999999999
    X2673                R61 1
    X2673                R874 -1
    X2673                R899 1
    X2674                OBJ 5.9199999999999999
    X2674                R61 1
    X2674                R874 1
    X2674                R899 -1
    X2675                OBJ 4.5599999999999996
    X2675                R62 1
    X2675                R888 -1
    X2675                R899 1
    X2676                OBJ 4.5599999999999996
    X2676                R62 1
    X2676                R888 1
    X2676                R899 -1
    X2677                OBJ 2.71
    X2677                R64 1
    X2677                R899 1
    X2677                R900 -1
    X2678                OBJ 2.71
    X2678                R64 1
    X2678                R899 -1
    X2678                R900 1
    X2679                OBJ 11.82
    X2679                R66 1
    X2679                R896 -1
    X2679                R901 1
    X2680                OBJ 11.82
    X2680                R66 1
    X2680                R896 1
    X2680                R901 -1
    X2681                OBJ 5.9699999999999998
    X2681                R67 1
    X2681                R897 -1
    X2681                R901 1
    X2682                OBJ 5.9699999999999998
    X2682                R67 1
    X2682                R897 1
    X2682                R901 -1
    X2683                OBJ 13.699999999999999
    X2683                R68 1
    X2683                R890 -1
    X2683                R901 1
    X2684                OBJ 13.699999999999999
    X2684                R68 1
    X2684                R890 1
    X2684                R901 -1
    X2685                OBJ 3.8300000000000001
    X2685                R69 1
    X2685                R890 -1
    X2685                R895 1
    X2686                OBJ 3.8300000000000001
    X2686                R69 1
    X2686                R890 1
    X2686                R895 -1
    X2687                OBJ 19.77
    X2687                R71 1
    X2687                R875 -1
    X2687                R902 1
    X2688                OBJ 19.77
    X2688                R71 1
    X2688                R875 1
    X2688                R902 -1
    X2689                OBJ 7.5099999999999998
    X2689                R72 1
    X2689                R881 -1
    X2689                R902 1
    X2690                OBJ 7.5099999999999998
    X2690                R72 1
    X2690                R881 1
    X2690                R902 -1
    X2691                OBJ 4.71
    X2691                R73 1
    X2691                R883 -1
    X2691                R902 1
    X2692                OBJ 4.71
    X2692                R73 1
    X2692                R883 1
    X2692                R902 -1
    X2693                OBJ 5.1399999999999997
    X2693                R74 1
    X2693                R875 1
    X2693                R893 -1
    X2694                OBJ 5.1399999999999997
    X2694                R74 1
    X2694                R875 -1
    X2694                R893 1
    X2695                OBJ 4.1100000000000003
    X2695                R76 1
    X2695                R882 -1
    X2695                R903 1
    X2696                OBJ 4.1100000000000003
    X2696                R76 1
    X2696                R882 1
    X2696                R903 -1
    X2697                OBJ 5.9400000000000004
    X2697                R77 1
    X2697                R893 -1
    X2697                R903 1
    X2698                OBJ 5.9400000000000004
    X2698                R77 1
    X2698                R893 1
    X2698                R903 -1
    X2699                OBJ 5.0700000000000003
    X2699                R79 1
    X2699                R903 1
    X2699                R904 -1
    X2700                OBJ 5.0700000000000003
    X2700                R79 1
    X2700                R903 -1
    X2700                R904 1
    X2701                OBJ 9.0700000000000003
    X2701                R81 1
    X2701                R882 -1
    X2701                R905 1
    X2702                OBJ 5.2199999999999998
    X2702                R83 1
    X2702                R888 -1
    X2702                R906 1
    X2703                OBJ 5.2199999999999998
    X2703                R83 1
    X2703                R888 1
    X2703                R906 -1
    X2704                OBJ 7.2000000000000002
    X2704                R84 1
    X2704                R905 1
    X2704                R906 -1
    X2705                OBJ 3.27
    X2705                R85 1
    X2705                R904 -1
    X2705                R906 1
    X2706                OBJ 3.27
    X2706                R85 1
    X2706                R904 1
    X2706                R906 -1
    X2707                OBJ 5.3399999999999999
    X2707                R87 1
    X2707                R888 1
    X2707                R907 -1
    X2708                OBJ 5.3399999999999999
    X2708                R87 1
    X2708                R888 -1
    X2708                R907 1
    X2709                OBJ 6.3799999999999999
    X2709                R88 1
    X2709                R877 -1
    X2709                R905 1
    X2710                OBJ 6
    X2710                R89 1
    X2710                R893 1
    X2710                R900 -1
    X2711                OBJ 6
    X2711                R89 1
    X2711                R893 -1
    X2711                R900 1
    X2712                OBJ 3.7599999999999998
    X2712                R90 1
    X2712                R889 1
    X2712                R907 -1
    X2713                OBJ 3.7599999999999998
    X2713                R90 1
    X2713                R889 -1
    X2713                R907 1
    X2714                OBJ 7.8300000000000001
    X2714                R91 1
    X2714                R879 -1
    X2714                R905 1
    X2715                OBJ 2.1800000000000002
    X2715                R92 1
    X2715                R900 1
    X2715                R904 -1
    X2716                OBJ 2.1800000000000002
    X2716                R92 1
    X2716                R900 -1
    X2716                R904 1
    X2717                OBJ 4
    X2717                R93 1
    X2717                R879 -1
    X2717                R907 1
    X2718                OBJ 4
    X2718                R93 1
    X2718                R879 1
    X2718                R907 -1
    X2719                OBJ 2.5899999999999999
    X2719                R2 1
    X2719                R908 1
    X2719                R909 -1
    X2720                OBJ 2.5899999999999999
    X2720                R2 1
    X2720                R908 -1
    X2720                R909 1
    X2721                OBJ 10.67
    X2721                R4 1
    X2721                R908 1
    X2721                R910 -1
    X2722                OBJ 10.67
    X2722                R4 1
    X2722                R908 -1
    X2722                R910 1
    X2723                OBJ 5.5199999999999996
    X2723                R6 1
    X2723                R908 1
    X2723                R911 -1
    X2724                OBJ 5.5199999999999996
    X2724                R6 1
    X2724                R908 -1
    X2724                R911 1
    X2725                OBJ 5.4000000000000004
    X2725                R8 1
    X2725                R908 1
    X2725                R912 -1
    X2726                OBJ 5.4000000000000004
    X2726                R8 1
    X2726                R908 -1
    X2726                R912 1
    X2727                OBJ 13.630000000000001
    X2727                R11 1
    X2727                R913 1
    X2727                R914 -1
    X2728                OBJ 13.630000000000001
    X2728                R11 1
    X2728                R913 -1
    X2728                R914 1
    X2729                OBJ 7.9400000000000004
    X2729                R13 1
    X2729                R913 1
    X2729                R915 -1
    X2730                OBJ 7.9400000000000004
    X2730                R13 1
    X2730                R913 -1
    X2730                R915 1
    X2731                OBJ 15
    X2731                R15 1
    X2731                R913 1
    X2731                R916 -1
    X2732                OBJ 15
    X2732                R15 1
    X2732                R913 -1
    X2732                R916 1
    X2733                OBJ 7.5999999999999996
    X2733                R18 1
    X2733                R917 1
    X2733                R918 -1
    X2734                OBJ 7.5999999999999996
    X2734                R18 1
    X2734                R917 -1
    X2734                R918 1
    X2735                OBJ 5.0800000000000001
    X2735                R20 1
    X2735                R917 1
    X2735                R919 -1
    X2736                OBJ 5.0800000000000001
    X2736                R20 1
    X2736                R917 -1
    X2736                R919 1
    X2737                OBJ 12.44
    X2737                R22 1
    X2737                R917 1
    X2737                R920 -1
    X2738                OBJ 12.44
    X2738                R22 1
    X2738                R917 -1
    X2738                R920 1
    X2739                OBJ 4.7400000000000002
    X2739                R25 1
    X2739                R921 1
    X2739                R922 -1
    X2740                OBJ 4.8700000000000001
    X2740                R26 1
    X2740                R915 -1
    X2740                R921 1
    X2741                OBJ 5.5099999999999998
    X2741                R27 1
    X2741                R916 -1
    X2741                R921 1
    X2742                OBJ 5.4000000000000004
    X2742                R30 1
    X2742                R923 1
    X2742                R924 -1
    X2743                OBJ 5.4000000000000004
    X2743                R30 1
    X2743                R923 -1
    X2743                R924 1
    X2744                OBJ 3.8100000000000001
    X2744                R31 1
    X2744                R911 -1
    X2744                R923 1
    X2745                OBJ 3.8100000000000001
    X2745                R31 1
    X2745                R911 1
    X2745                R923 -1
    X2746                OBJ 7.5700000000000003
    X2746                R33 1
    X2746                R923 1
    X2746                R925 -1
    X2747                OBJ 7.5700000000000003
    X2747                R33 1
    X2747                R923 -1
    X2747                R925 1
    X2748                OBJ 4.2000000000000002
    X2748                R35 1
    X2748                R923 1
    X2748                R926 -1
    X2749                OBJ 4.2000000000000002
    X2749                R35 1
    X2749                R923 -1
    X2749                R926 1
    X2750                OBJ 7.75
    X2750                R37 1
    X2750                R923 1
    X2750                R927 -1
    X2751                OBJ 7.75
    X2751                R37 1
    X2751                R923 -1
    X2751                R927 1
    X2752                OBJ 6.0999999999999996
    X2752                R39 1
    X2752                R910 -1
    X2752                R928 1
    X2753                OBJ 6.0999999999999996
    X2753                R39 1
    X2753                R910 1
    X2753                R928 -1
    X2754                OBJ 2.3900000000000001
    X2754                R40 1
    X2754                R912 -1
    X2754                R928 1
    X2755                OBJ 2.3900000000000001
    X2755                R40 1
    X2755                R912 1
    X2755                R928 -1
    X2756                OBJ 8.3399999999999999
    X2756                R42 1
    X2756                R918 -1
    X2756                R929 1
    X2757                OBJ 8.3399999999999999
    X2757                R42 1
    X2757                R918 1
    X2757                R929 -1
    X2758                OBJ 7.5599999999999996
    X2758                R43 1
    X2758                R919 -1
    X2758                R929 1
    X2759                OBJ 7.5599999999999996
    X2759                R43 1
    X2759                R919 1
    X2759                R929 -1
    X2760                OBJ 7.4699999999999998
    X2760                R45 1
    X2760                R929 1
    X2760                R930 -1
    X2761                OBJ 7.4699999999999998
    X2761                R45 1
    X2761                R929 -1
    X2761                R930 1
    X2762                OBJ 2.6400000000000001
    X2762                R47 1
    X2762                R909 1
    X2762                R931 -1
    X2763                OBJ 2.6400000000000001
    X2763                R47 1
    X2763                R909 -1
    X2763                R931 1
    X2764                OBJ 3.9300000000000002
    X2764                R48 1
    X2764                R909 1
    X2764                R930 -1
    X2765                OBJ 3.9300000000000002
    X2765                R48 1
    X2765                R909 -1
    X2765                R930 1
    X2766                OBJ 4.3600000000000003
    X2766                R50 1
    X2766                R922 1
    X2766                R932 -1
    X2767                OBJ 4.3600000000000003
    X2767                R50 1
    X2767                R922 -1
    X2767                R932 1
    X2768                OBJ 6.6799999999999997
    X2768                R51 1
    X2768                R922 1
    X2768                R926 -1
    X2769                OBJ 6.6799999999999997
    X2769                R51 1
    X2769                R922 -1
    X2769                R926 1
    X2770                OBJ 7.2199999999999998
    X2770                R53 1
    X2770                R924 1
    X2770                R933 -1
    X2771                OBJ 7.2199999999999998
    X2771                R53 1
    X2771                R924 -1
    X2771                R933 1
    X2772                OBJ 7.7699999999999996
    X2772                R55 1
    X2772                R924 1
    X2772                R934 -1
    X2773                OBJ 7.7699999999999996
    X2773                R55 1
    X2773                R924 -1
    X2773                R934 1
    X2774                OBJ 4.6200000000000001
    X2774                R57 1
    X2774                R910 -1
    X2774                R935 1
    X2775                OBJ 4.6200000000000001
    X2775                R57 1
    X2775                R910 1
    X2775                R935 -1
    X2776                OBJ 6.9000000000000004
    X2776                R58 1
    X2776                R912 -1
    X2776                R935 1
    X2777                OBJ 6.9000000000000004
    X2777                R58 1
    X2777                R912 1
    X2777                R935 -1
    X2778                OBJ 2.75
    X2778                R60 1
    X2778                R931 1
    X2778                R936 -1
    X2779                OBJ 2.75
    X2779                R60 1
    X2779                R931 -1
    X2779                R936 1
    X2780                OBJ 5.9199999999999999
    X2780                R61 1
    X2780                R911 -1
    X2780                R936 1
    X2781                OBJ 5.9199999999999999
    X2781                R61 1
    X2781                R911 1
    X2781                R936 -1
    X2782                OBJ 4.5599999999999996
    X2782                R62 1
    X2782                R925 -1
    X2782                R936 1
    X2783                OBJ 4.5599999999999996
    X2783                R62 1
    X2783                R925 1
    X2783                R936 -1
    X2784                OBJ 2.71
    X2784                R64 1
    X2784                R936 1
    X2784                R937 -1
    X2785                OBJ 2.71
    X2785                R64 1
    X2785                R936 -1
    X2785                R937 1
    X2786                OBJ 11.82
    X2786                R66 1
    X2786                R933 -1
    X2786                R938 1
    X2787                OBJ 11.82
    X2787                R66 1
    X2787                R933 1
    X2787                R938 -1
    X2788                OBJ 5.9699999999999998
    X2788                R67 1
    X2788                R934 -1
    X2788                R938 1
    X2789                OBJ 5.9699999999999998
    X2789                R67 1
    X2789                R934 1
    X2789                R938 -1
    X2790                OBJ 13.699999999999999
    X2790                R68 1
    X2790                R927 -1
    X2790                R938 1
    X2791                OBJ 13.699999999999999
    X2791                R68 1
    X2791                R927 1
    X2791                R938 -1
    X2792                OBJ 3.8300000000000001
    X2792                R69 1
    X2792                R927 -1
    X2792                R932 1
    X2793                OBJ 3.8300000000000001
    X2793                R69 1
    X2793                R927 1
    X2793                R932 -1
    X2794                OBJ 19.77
    X2794                R71 1
    X2794                R912 -1
    X2794                R939 1
    X2795                OBJ 19.77
    X2795                R71 1
    X2795                R912 1
    X2795                R939 -1
    X2796                OBJ 7.5099999999999998
    X2796                R72 1
    X2796                R918 -1
    X2796                R939 1
    X2797                OBJ 7.5099999999999998
    X2797                R72 1
    X2797                R918 1
    X2797                R939 -1
    X2798                OBJ 4.71
    X2798                R73 1
    X2798                R920 -1
    X2798                R939 1
    X2799                OBJ 4.71
    X2799                R73 1
    X2799                R920 1
    X2799                R939 -1
    X2800                OBJ 5.1399999999999997
    X2800                R74 1
    X2800                R912 1
    X2800                R930 -1
    X2801                OBJ 5.1399999999999997
    X2801                R74 1
    X2801                R912 -1
    X2801                R930 1
    X2802                OBJ 4.1100000000000003
    X2802                R76 1
    X2802                R919 -1
    X2802                R940 1
    X2803                OBJ 4.1100000000000003
    X2803                R76 1
    X2803                R919 1
    X2803                R940 -1
    X2804                OBJ 5.9400000000000004
    X2804                R77 1
    X2804                R930 -1
    X2804                R940 1
    X2805                OBJ 5.9400000000000004
    X2805                R77 1
    X2805                R930 1
    X2805                R940 -1
    X2806                OBJ 5.0700000000000003
    X2806                R79 1
    X2806                R940 1
    X2806                R941 -1
    X2807                OBJ 5.0700000000000003
    X2807                R79 1
    X2807                R940 -1
    X2807                R941 1
    X2808                OBJ 9.0700000000000003
    X2808                R81 1
    X2808                R919 1
    X2808                R942 -1
    X2809                OBJ 9.0700000000000003
    X2809                R81 1
    X2809                R919 -1
    X2809                R942 1
    X2810                OBJ 5.2199999999999998
    X2810                R83 1
    X2810                R925 -1
    X2810                R943 1
    X2811                OBJ 5.2199999999999998
    X2811                R83 1
    X2811                R925 1
    X2811                R943 -1
    X2812                OBJ 7.2000000000000002
    X2812                R84 1
    X2812                R942 -1
    X2812                R943 1
    X2813                OBJ 7.2000000000000002
    X2813                R84 1
    X2813                R942 1
    X2813                R943 -1
    X2814                OBJ 3.27
    X2814                R85 1
    X2814                R941 -1
    X2814                R943 1
    X2815                OBJ 3.27
    X2815                R85 1
    X2815                R941 1
    X2815                R943 -1
    X2816                OBJ 5.3399999999999999
    X2816                R87 1
    X2816                R925 1
    X2816                R944 -1
    X2817                OBJ 5.3399999999999999
    X2817                R87 1
    X2817                R925 -1
    X2817                R944 1
    X2818                OBJ 6.3799999999999999
    X2818                R88 1
    X2818                R914 1
    X2818                R942 -1
    X2819                OBJ 6.3799999999999999
    X2819                R88 1
    X2819                R914 -1
    X2819                R942 1
    X2820                OBJ 6
    X2820                R89 1
    X2820                R930 1
    X2820                R937 -1
    X2821                OBJ 6
    X2821                R89 1
    X2821                R930 -1
    X2821                R937 1
    X2822                OBJ 3.7599999999999998
    X2822                R90 1
    X2822                R926 1
    X2822                R944 -1
    X2823                OBJ 3.7599999999999998
    X2823                R90 1
    X2823                R926 -1
    X2823                R944 1
    X2824                OBJ 7.8300000000000001
    X2824                R91 1
    X2824                R916 -1
    X2824                R942 1
    X2825                OBJ 7.8300000000000001
    X2825                R91 1
    X2825                R916 1
    X2825                R942 -1
    X2826                OBJ 2.1800000000000002
    X2826                R92 1
    X2826                R937 1
    X2826                R941 -1
    X2827                OBJ 2.1800000000000002
    X2827                R92 1
    X2827                R937 -1
    X2827                R941 1
    X2828                OBJ 4
    X2828                R93 1
    X2828                R916 -1
    X2828                R944 1
    X2829                OBJ 4
    X2829                R93 1
    X2829                R916 1
    X2829                R944 -1
    X2830                OBJ 2.5899999999999999
    X2830                R2 1
    X2830                R945 1
    X2830                R946 -1
    X2831                OBJ 2.5899999999999999
    X2831                R2 1
    X2831                R945 -1
    X2831                R946 1
    X2832                OBJ 10.67
    X2832                R4 1
    X2832                R945 1
    X2832                R947 -1
    X2833                OBJ 10.67
    X2833                R4 1
    X2833                R945 -1
    X2833                R947 1
    X2834                OBJ 5.5199999999999996
    X2834                R6 1
    X2834                R945 1
    X2834                R948 -1
    X2835                OBJ 5.5199999999999996
    X2835                R6 1
    X2835                R945 -1
    X2835                R948 1
    X2836                OBJ 5.4000000000000004
    X2836                R8 1
    X2836                R945 1
    X2836                R949 -1
    X2837                OBJ 5.4000000000000004
    X2837                R8 1
    X2837                R945 -1
    X2837                R949 1
    X2838                OBJ 13.630000000000001
    X2838                R11 1
    X2838                R950 1
    X2838                R951 -1
    X2839                OBJ 13.630000000000001
    X2839                R11 1
    X2839                R950 -1
    X2839                R951 1
    X2840                OBJ 7.9400000000000004
    X2840                R13 1
    X2840                R950 1
    X2840                R952 -1
    X2841                OBJ 7.9400000000000004
    X2841                R13 1
    X2841                R950 -1
    X2841                R952 1
    X2842                OBJ 15
    X2842                R15 1
    X2842                R950 1
    X2842                R953 -1
    X2843                OBJ 15
    X2843                R15 1
    X2843                R950 -1
    X2843                R953 1
    X2844                OBJ 7.5999999999999996
    X2844                R18 1
    X2844                R954 1
    X2844                R955 -1
    X2845                OBJ 7.5999999999999996
    X2845                R18 1
    X2845                R954 -1
    X2845                R955 1
    X2846                OBJ 5.0800000000000001
    X2846                R20 1
    X2846                R954 1
    X2846                R956 -1
    X2847                OBJ 5.0800000000000001
    X2847                R20 1
    X2847                R954 -1
    X2847                R956 1
    X2848                OBJ 12.44
    X2848                R22 1
    X2848                R954 1
    X2848                R957 -1
    X2849                OBJ 12.44
    X2849                R22 1
    X2849                R954 -1
    X2849                R957 1
    X2850                OBJ 4.7400000000000002
    X2850                R25 1
    X2850                R958 1
    X2850                R959 -1
    X2851                OBJ 4.7400000000000002
    X2851                R25 1
    X2851                R958 -1
    X2851                R959 1
    X2852                OBJ 4.8700000000000001
    X2852                R26 1
    X2852                R952 -1
    X2852                R958 1
    X2853                OBJ 4.8700000000000001
    X2853                R26 1
    X2853                R952 1
    X2853                R958 -1
    X2854                OBJ 5.5099999999999998
    X2854                R27 1
    X2854                R953 -1
    X2854                R958 1
    X2855                OBJ 5.5099999999999998
    X2855                R27 1
    X2855                R953 1
    X2855                R958 -1
    X2856                OBJ 5.4000000000000004
    X2856                R30 1
    X2856                R960 1
    X2856                R961 -1
    X2857                OBJ 5.4000000000000004
    X2857                R30 1
    X2857                R960 -1
    X2857                R961 1
    X2858                OBJ 3.8100000000000001
    X2858                R31 1
    X2858                R948 -1
    X2858                R960 1
    X2859                OBJ 3.8100000000000001
    X2859                R31 1
    X2859                R948 1
    X2859                R960 -1
    X2860                OBJ 7.5700000000000003
    X2860                R33 1
    X2860                R960 1
    X2860                R962 -1
    X2861                OBJ 7.5700000000000003
    X2861                R33 1
    X2861                R960 -1
    X2861                R962 1
    X2862                OBJ 4.2000000000000002
    X2862                R35 1
    X2862                R960 1
    X2862                R963 -1
    X2863                OBJ 4.2000000000000002
    X2863                R35 1
    X2863                R960 -1
    X2863                R963 1
    X2864                OBJ 7.75
    X2864                R37 1
    X2864                R960 1
    X2864                R964 -1
    X2865                OBJ 7.75
    X2865                R37 1
    X2865                R960 -1
    X2865                R964 1
    X2866                OBJ 6.0999999999999996
    X2866                R39 1
    X2866                R947 -1
    X2866                R965 1
    X2867                OBJ 6.0999999999999996
    X2867                R39 1
    X2867                R947 1
    X2867                R965 -1
    X2868                OBJ 2.3900000000000001
    X2868                R40 1
    X2868                R949 -1
    X2868                R965 1
    X2869                OBJ 2.3900000000000001
    X2869                R40 1
    X2869                R949 1
    X2869                R965 -1
    X2870                OBJ 8.3399999999999999
    X2870                R42 1
    X2870                R955 -1
    X2870                R966 1
    X2871                OBJ 8.3399999999999999
    X2871                R42 1
    X2871                R955 1
    X2871                R966 -1
    X2872                OBJ 7.5599999999999996
    X2872                R43 1
    X2872                R956 -1
    X2872                R966 1
    X2873                OBJ 7.5599999999999996
    X2873                R43 1
    X2873                R956 1
    X2873                R966 -1
    X2874                OBJ 7.4699999999999998
    X2874                R45 1
    X2874                R966 -1
    X2874                R967 1
    X2875                OBJ 2.6400000000000001
    X2875                R47 1
    X2875                R946 1
    X2875                R968 -1
    X2876                OBJ 2.6400000000000001
    X2876                R47 1
    X2876                R946 -1
    X2876                R968 1
    X2877                OBJ 3.9300000000000002
    X2877                R48 1
    X2877                R946 -1
    X2877                R967 1
    X2878                OBJ 4.3600000000000003
    X2878                R50 1
    X2878                R959 1
    X2878                R969 -1
    X2879                OBJ 4.3600000000000003
    X2879                R50 1
    X2879                R959 -1
    X2879                R969 1
    X2880                OBJ 6.6799999999999997
    X2880                R51 1
    X2880                R959 1
    X2880                R963 -1
    X2881                OBJ 6.6799999999999997
    X2881                R51 1
    X2881                R959 -1
    X2881                R963 1
    X2882                OBJ 7.2199999999999998
    X2882                R53 1
    X2882                R961 1
    X2882                R970 -1
    X2883                OBJ 7.2199999999999998
    X2883                R53 1
    X2883                R961 -1
    X2883                R970 1
    X2884                OBJ 7.7699999999999996
    X2884                R55 1
    X2884                R961 1
    X2884                R971 -1
    X2885                OBJ 7.7699999999999996
    X2885                R55 1
    X2885                R961 -1
    X2885                R971 1
    X2886                OBJ 4.6200000000000001
    X2886                R57 1
    X2886                R947 -1
    X2886                R972 1
    X2887                OBJ 4.6200000000000001
    X2887                R57 1
    X2887                R947 1
    X2887                R972 -1
    X2888                OBJ 6.9000000000000004
    X2888                R58 1
    X2888                R949 -1
    X2888                R972 1
    X2889                OBJ 6.9000000000000004
    X2889                R58 1
    X2889                R949 1
    X2889                R972 -1
    X2890                OBJ 2.75
    X2890                R60 1
    X2890                R968 1
    X2890                R973 -1
    X2891                OBJ 2.75
    X2891                R60 1
    X2891                R968 -1
    X2891                R973 1
    X2892                OBJ 5.9199999999999999
    X2892                R61 1
    X2892                R948 -1
    X2892                R973 1
    X2893                OBJ 5.9199999999999999
    X2893                R61 1
    X2893                R948 1
    X2893                R973 -1
    X2894                OBJ 4.5599999999999996
    X2894                R62 1
    X2894                R962 -1
    X2894                R973 1
    X2895                OBJ 4.5599999999999996
    X2895                R62 1
    X2895                R962 1
    X2895                R973 -1
    X2896                OBJ 2.71
    X2896                R64 1
    X2896                R973 1
    X2896                R974 -1
    X2897                OBJ 2.71
    X2897                R64 1
    X2897                R973 -1
    X2897                R974 1
    X2898                OBJ 11.82
    X2898                R66 1
    X2898                R970 -1
    X2898                R975 1
    X2899                OBJ 11.82
    X2899                R66 1
    X2899                R970 1
    X2899                R975 -1
    X2900                OBJ 5.9699999999999998
    X2900                R67 1
    X2900                R971 -1
    X2900                R975 1
    X2901                OBJ 5.9699999999999998
    X2901                R67 1
    X2901                R971 1
    X2901                R975 -1
    X2902                OBJ 13.699999999999999
    X2902                R68 1
    X2902                R964 -1
    X2902                R975 1
    X2903                OBJ 13.699999999999999
    X2903                R68 1
    X2903                R964 1
    X2903                R975 -1
    X2904                OBJ 3.8300000000000001
    X2904                R69 1
    X2904                R964 -1
    X2904                R969 1
    X2905                OBJ 3.8300000000000001
    X2905                R69 1
    X2905                R964 1
    X2905                R969 -1
    X2906                OBJ 19.77
    X2906                R71 1
    X2906                R949 -1
    X2906                R976 1
    X2907                OBJ 19.77
    X2907                R71 1
    X2907                R949 1
    X2907                R976 -1
    X2908                OBJ 7.5099999999999998
    X2908                R72 1
    X2908                R955 -1
    X2908                R976 1
    X2909                OBJ 7.5099999999999998
    X2909                R72 1
    X2909                R955 1
    X2909                R976 -1
    X2910                OBJ 4.71
    X2910                R73 1
    X2910                R957 -1
    X2910                R976 1
    X2911                OBJ 4.71
    X2911                R73 1
    X2911                R957 1
    X2911                R976 -1
    X2912                OBJ 5.1399999999999997
    X2912                R74 1
    X2912                R949 -1
    X2912                R967 1
    X2913                OBJ 4.1100000000000003
    X2913                R76 1
    X2913                R956 -1
    X2913                R977 1
    X2914                OBJ 4.1100000000000003
    X2914                R76 1
    X2914                R956 1
    X2914                R977 -1
    X2915                OBJ 5.9400000000000004
    X2915                R77 1
    X2915                R967 1
    X2915                R977 -1
    X2916                OBJ 5.0700000000000003
    X2916                R79 1
    X2916                R977 1
    X2916                R978 -1
    X2917                OBJ 5.0700000000000003
    X2917                R79 1
    X2917                R977 -1
    X2917                R978 1
    X2918                OBJ 9.0700000000000003
    X2918                R81 1
    X2918                R956 1
    X2918                R979 -1
    X2919                OBJ 9.0700000000000003
    X2919                R81 1
    X2919                R956 -1
    X2919                R979 1
    X2920                OBJ 5.2199999999999998
    X2920                R83 1
    X2920                R962 -1
    X2920                R980 1
    X2921                OBJ 5.2199999999999998
    X2921                R83 1
    X2921                R962 1
    X2921                R980 -1
    X2922                OBJ 7.2000000000000002
    X2922                R84 1
    X2922                R979 -1
    X2922                R980 1
    X2923                OBJ 7.2000000000000002
    X2923                R84 1
    X2923                R979 1
    X2923                R980 -1
    X2924                OBJ 3.27
    X2924                R85 1
    X2924                R978 -1
    X2924                R980 1
    X2925                OBJ 3.27
    X2925                R85 1
    X2925                R978 1
    X2925                R980 -1
    X2926                OBJ 5.3399999999999999
    X2926                R87 1
    X2926                R962 1
    X2926                R981 -1
    X2927                OBJ 5.3399999999999999
    X2927                R87 1
    X2927                R962 -1
    X2927                R981 1
    X2928                OBJ 6.3799999999999999
    X2928                R88 1
    X2928                R951 1
    X2928                R979 -1
    X2929                OBJ 6.3799999999999999
    X2929                R88 1
    X2929                R951 -1
    X2929                R979 1
    X2930                OBJ 6
    X2930                R89 1
    X2930                R967 1
    X2930                R974 -1
    X2931                OBJ 3.7599999999999998
    X2931                R90 1
    X2931                R963 1
    X2931                R981 -1
    X2932                OBJ 3.7599999999999998
    X2932                R90 1
    X2932                R963 -1
    X2932                R981 1
    X2933                OBJ 7.8300000000000001
    X2933                R91 1
    X2933                R953 -1
    X2933                R979 1
    X2934                OBJ 7.8300000000000001
    X2934                R91 1
    X2934                R953 1
    X2934                R979 -1
    X2935                OBJ 2.1800000000000002
    X2935                R92 1
    X2935                R974 1
    X2935                R978 -1
    X2936                OBJ 2.1800000000000002
    X2936                R92 1
    X2936                R974 -1
    X2936                R978 1
    X2937                OBJ 4
    X2937                R93 1
    X2937                R953 -1
    X2937                R981 1
    X2938                OBJ 4
    X2938                R93 1
    X2938                R953 1
    X2938                R981 -1
    X2939                OBJ 2.5899999999999999
    X2939                R2 1
    X2939                R982 1
    X2939                R983 -1
    X2940                OBJ 2.5899999999999999
    X2940                R2 1
    X2940                R982 -1
    X2940                R983 1
    X2941                OBJ 10.67
    X2941                R4 1
    X2941                R982 1
    X2941                R984 -1
    X2942                OBJ 10.67
    X2942                R4 1
    X2942                R982 -1
    X2942                R984 1
    X2943                OBJ 5.5199999999999996
    X2943                R6 1
    X2943                R982 1
    X2943                R985 -1
    X2944                OBJ 5.5199999999999996
    X2944                R6 1
    X2944                R982 -1
    X2944                R985 1
    X2945                OBJ 5.4000000000000004
    X2945                R8 1
    X2945                R982 1
    X2945                R986 -1
    X2946                OBJ 5.4000000000000004
    X2946                R8 1
    X2946                R982 -1
    X2946                R986 1
    X2947                OBJ 13.630000000000001
    X2947                R11 1
    X2947                R987 1
    X2947                R988 -1
    X2948                OBJ 13.630000000000001
    X2948                R11 1
    X2948                R987 -1
    X2948                R988 1
    X2949                OBJ 7.9400000000000004
    X2949                R13 1
    X2949                R987 1
    X2949                R989 -1
    X2950                OBJ 7.9400000000000004
    X2950                R13 1
    X2950                R987 -1
    X2950                R989 1
    X2951                OBJ 15
    X2951                R15 1
    X2951                R987 1
    X2951                R990 -1
    X2952                OBJ 15
    X2952                R15 1
    X2952                R987 -1
    X2952                R990 1
    X2953                OBJ 7.5999999999999996
    X2953                R18 1
    X2953                R991 1
    X2953                R992 -1
    X2954                OBJ 7.5999999999999996
    X2954                R18 1
    X2954                R991 -1
    X2954                R992 1
    X2955                OBJ 5.0800000000000001
    X2955                R20 1
    X2955                R991 1
    X2955                R993 -1
    X2956                OBJ 5.0800000000000001
    X2956                R20 1
    X2956                R991 -1
    X2956                R993 1
    X2957                OBJ 12.44
    X2957                R22 1
    X2957                R991 1
    X2957                R994 -1
    X2958                OBJ 12.44
    X2958                R22 1
    X2958                R991 -1
    X2958                R994 1
    X2959                OBJ 4.7400000000000002
    X2959                R25 1
    X2959                R995 1
    X2959                R996 -1
    X2960                OBJ 4.7400000000000002
    X2960                R25 1
    X2960                R995 -1
    X2960                R996 1
    X2961                OBJ 4.8700000000000001
    X2961                R26 1
    X2961                R989 -1
    X2961                R995 1
    X2962                OBJ 4.8700000000000001
    X2962                R26 1
    X2962                R989 1
    X2962                R995 -1
    X2963                OBJ 5.5099999999999998
    X2963                R27 1
    X2963                R990 -1
    X2963                R995 1
    X2964                OBJ 5.5099999999999998
    X2964                R27 1
    X2964                R990 1
    X2964                R995 -1
    X2965                OBJ 5.4000000000000004
    X2965                R30 1
    X2965                R997 1
    X2965                R998 -1
    X2966                OBJ 5.4000000000000004
    X2966                R30 1
    X2966                R997 -1
    X2966                R998 1
    X2967                OBJ 3.8100000000000001
    X2967                R31 1
    X2967                R985 -1
    X2967                R997 1
    X2968                OBJ 3.8100000000000001
    X2968                R31 1
    X2968                R985 1
    X2968                R997 -1
    X2969                OBJ 7.5700000000000003
    X2969                R33 1
    X2969                R997 1
    X2969                R999 -1
    X2970                OBJ 7.5700000000000003
    X2970                R33 1
    X2970                R997 -1
    X2970                R999 1
    X2971                OBJ 4.2000000000000002
    X2971                R35 1
    X2971                R997 1
    X2971                R1000 -1
    X2972                OBJ 4.2000000000000002
    X2972                R35 1
    X2972                R997 -1
    X2972                R1000 1
    X2973                OBJ 7.75
    X2973                R37 1
    X2973                R997 1
    X2973                R1001 -1
    X2974                OBJ 7.75
    X2974                R37 1
    X2974                R997 -1
    X2974                R1001 1
    X2975                OBJ 6.0999999999999996
    X2975                R39 1
    X2975                R984 -1
    X2975                R1002 1
    X2976                OBJ 6.0999999999999996
    X2976                R39 1
    X2976                R984 1
    X2976                R1002 -1
    X2977                OBJ 2.3900000000000001
    X2977                R40 1
    X2977                R986 -1
    X2977                R1002 1
    X2978                OBJ 2.3900000000000001
    X2978                R40 1
    X2978                R986 1
    X2978                R1002 -1
    X2979                OBJ 8.3399999999999999
    X2979                R42 1
    X2979                R992 -1
    X2979                R1003 1
    X2980                OBJ 8.3399999999999999
    X2980                R42 1
    X2980                R992 1
    X2980                R1003 -1
    X2981                OBJ 7.5599999999999996
    X2981                R43 1
    X2981                R993 -1
    X2981                R1003 1
    X2982                OBJ 7.5599999999999996
    X2982                R43 1
    X2982                R993 1
    X2982                R1003 -1
    X2983                OBJ 7.4699999999999998
    X2983                R45 1
    X2983                R1003 1
    X2983                R1004 -1
    X2984                OBJ 7.4699999999999998
    X2984                R45 1
    X2984                R1003 -1
    X2984                R1004 1
    X2985                OBJ 2.6400000000000001
    X2985                R47 1
    X2985                R983 1
    X2985                R1005 -1
    X2986                OBJ 2.6400000000000001
    X2986                R47 1
    X2986                R983 -1
    X2986                R1005 1
    X2987                OBJ 3.9300000000000002
    X2987                R48 1
    X2987                R983 1
    X2987                R1004 -1
    X2988                OBJ 3.9300000000000002
    X2988                R48 1
    X2988                R983 -1
    X2988                R1004 1
    X2989                OBJ 4.3600000000000003
    X2989                R50 1
    X2989                R996 1
    X2989                R1006 -1
    X2990                OBJ 4.3600000000000003
    X2990                R50 1
    X2990                R996 -1
    X2990                R1006 1
    X2991                OBJ 6.6799999999999997
    X2991                R51 1
    X2991                R996 1
    X2991                R1000 -1
    X2992                OBJ 6.6799999999999997
    X2992                R51 1
    X2992                R996 -1
    X2992                R1000 1
    X2993                OBJ 7.2199999999999998
    X2993                R53 1
    X2993                R998 1
    X2993                R1007 -1
    X2994                OBJ 7.2199999999999998
    X2994                R53 1
    X2994                R998 -1
    X2994                R1007 1
    X2995                OBJ 7.7699999999999996
    X2995                R55 1
    X2995                R998 1
    X2995                R1008 -1
    X2996                OBJ 7.7699999999999996
    X2996                R55 1
    X2996                R998 -1
    X2996                R1008 1
    X2997                OBJ 4.6200000000000001
    X2997                R57 1
    X2997                R984 -1
    X2997                R1009 1
    X2998                OBJ 6.9000000000000004
    X2998                R58 1
    X2998                R986 -1
    X2998                R1009 1
    X2999                OBJ 2.75
    X2999                R60 1
    X2999                R1005 1
    X2999                R1010 -1
    X3000                OBJ 2.75
    X3000                R60 1
    X3000                R1005 -1
    X3000                R1010 1
    X3001                OBJ 5.9199999999999999
    X3001                R61 1
    X3001                R985 -1
    X3001                R1010 1
    X3002                OBJ 5.9199999999999999
    X3002                R61 1
    X3002                R985 1
    X3002                R1010 -1
    X3003                OBJ 4.5599999999999996
    X3003                R62 1
    X3003                R999 -1
    X3003                R1010 1
    X3004                OBJ 4.5599999999999996
    X3004                R62 1
    X3004                R999 1
    X3004                R1010 -1
    X3005                OBJ 2.71
    X3005                R64 1
    X3005                R1010 1
    X3005                R1011 -1
    X3006                OBJ 2.71
    X3006                R64 1
    X3006                R1010 -1
    X3006                R1011 1
    X3007                OBJ 11.82
    X3007                R66 1
    X3007                R1007 -1
    X3007                R1012 1
    X3008                OBJ 11.82
    X3008                R66 1
    X3008                R1007 1
    X3008                R1012 -1
    X3009                OBJ 5.9699999999999998
    X3009                R67 1
    X3009                R1008 -1
    X3009                R1012 1
    X3010                OBJ 5.9699999999999998
    X3010                R67 1
    X3010                R1008 1
    X3010                R1012 -1
    X3011                OBJ 13.699999999999999
    X3011                R68 1
    X3011                R1001 -1
    X3011                R1012 1
    X3012                OBJ 13.699999999999999
    X3012                R68 1
    X3012                R1001 1
    X3012                R1012 -1
    X3013                OBJ 3.8300000000000001
    X3013                R69 1
    X3013                R1001 -1
    X3013                R1006 1
    X3014                OBJ 3.8300000000000001
    X3014                R69 1
    X3014                R1001 1
    X3014                R1006 -1
    X3015                OBJ 19.77
    X3015                R71 1
    X3015                R986 -1
    X3015                R1013 1
    X3016                OBJ 19.77
    X3016                R71 1
    X3016                R986 1
    X3016                R1013 -1
    X3017                OBJ 7.5099999999999998
    X3017                R72 1
    X3017                R992 -1
    X3017                R1013 1
    X3018                OBJ 7.5099999999999998
    X3018                R72 1
    X3018                R992 1
    X3018                R1013 -1
    X3019                OBJ 4.71
    X3019                R73 1
    X3019                R994 -1
    X3019                R1013 1
    X3020                OBJ 4.71
    X3020                R73 1
    X3020                R994 1
    X3020                R1013 -1
    X3021                OBJ 5.1399999999999997
    X3021                R74 1
    X3021                R986 1
    X3021                R1004 -1
    X3022                OBJ 5.1399999999999997
    X3022                R74 1
    X3022                R986 -1
    X3022                R1004 1
    X3023                OBJ 4.1100000000000003
    X3023                R76 1
    X3023                R993 -1
    X3023                R1014 1
    X3024                OBJ 4.1100000000000003
    X3024                R76 1
    X3024                R993 1
    X3024                R1014 -1
    X3025                OBJ 5.9400000000000004
    X3025                R77 1
    X3025                R1004 -1
    X3025                R1014 1
    X3026                OBJ 5.9400000000000004
    X3026                R77 1
    X3026                R1004 1
    X3026                R1014 -1
    X3027                OBJ 5.0700000000000003
    X3027                R79 1
    X3027                R1014 1
    X3027                R1015 -1
    X3028                OBJ 5.0700000000000003
    X3028                R79 1
    X3028                R1014 -1
    X3028                R1015 1
    X3029                OBJ 9.0700000000000003
    X3029                R81 1
    X3029                R993 1
    X3029                R1016 -1
    X3030                OBJ 9.0700000000000003
    X3030                R81 1
    X3030                R993 -1
    X3030                R1016 1
    X3031                OBJ 5.2199999999999998
    X3031                R83 1
    X3031                R999 -1
    X3031                R1017 1
    X3032                OBJ 5.2199999999999998
    X3032                R83 1
    X3032                R999 1
    X3032                R1017 -1
    X3033                OBJ 7.2000000000000002
    X3033                R84 1
    X3033                R1016 -1
    X3033                R1017 1
    X3034                OBJ 7.2000000000000002
    X3034                R84 1
    X3034                R1016 1
    X3034                R1017 -1
    X3035                OBJ 3.27
    X3035                R85 1
    X3035                R1015 -1
    X3035                R1017 1
    X3036                OBJ 3.27
    X3036                R85 1
    X3036                R1015 1
    X3036                R1017 -1
    X3037                OBJ 5.3399999999999999
    X3037                R87 1
    X3037                R999 1
    X3037                R1018 -1
    X3038                OBJ 5.3399999999999999
    X3038                R87 1
    X3038                R999 -1
    X3038                R1018 1
    X3039                OBJ 6.3799999999999999
    X3039                R88 1
    X3039                R988 1
    X3039                R1016 -1
    X3040                OBJ 6.3799999999999999
    X3040                R88 1
    X3040                R988 -1
    X3040                R1016 1
    X3041                OBJ 6
    X3041                R89 1
    X3041                R1004 1
    X3041                R1011 -1
    X3042                OBJ 6
    X3042                R89 1
    X3042                R1004 -1
    X3042                R1011 1
    X3043                OBJ 3.7599999999999998
    X3043                R90 1
    X3043                R1000 1
    X3043                R1018 -1
    X3044                OBJ 3.7599999999999998
    X3044                R90 1
    X3044                R1000 -1
    X3044                R1018 1
    X3045                OBJ 7.8300000000000001
    X3045                R91 1
    X3045                R990 -1
    X3045                R1016 1
    X3046                OBJ 7.8300000000000001
    X3046                R91 1
    X3046                R990 1
    X3046                R1016 -1
    X3047                OBJ 2.1800000000000002
    X3047                R92 1
    X3047                R1011 1
    X3047                R1015 -1
    X3048                OBJ 2.1800000000000002
    X3048                R92 1
    X3048                R1011 -1
    X3048                R1015 1
    X3049                OBJ 4
    X3049                R93 1
    X3049                R990 -1
    X3049                R1018 1
    X3050                OBJ 4
    X3050                R93 1
    X3050                R990 1
    X3050                R1018 -1
    X3051                OBJ 2.5899999999999999
    X3051                R2 1
    X3051                R1019 1
    X3051                R1020 -1
    X3052                OBJ 2.5899999999999999
    X3052                R2 1
    X3052                R1019 -1
    X3052                R1020 1
    X3053                OBJ 10.67
    X3053                R4 1
    X3053                R1019 1
    X3053                R1021 -1
    X3054                OBJ 10.67
    X3054                R4 1
    X3054                R1019 -1
    X3054                R1021 1
    X3055                OBJ 5.5199999999999996
    X3055                R6 1
    X3055                R1019 1
    X3055                R1022 -1
    X3056                OBJ 5.5199999999999996
    X3056                R6 1
    X3056                R1019 -1
    X3056                R1022 1
    X3057                OBJ 5.4000000000000004
    X3057                R8 1
    X3057                R1019 1
    X3057                R1023 -1
    X3058                OBJ 5.4000000000000004
    X3058                R8 1
    X3058                R1019 -1
    X3058                R1023 1
    X3059                OBJ 13.630000000000001
    X3059                R11 1
    X3059                R1024 1
    X3059                R1025 -1
    X3060                OBJ 13.630000000000001
    X3060                R11 1
    X3060                R1024 -1
    X3060                R1025 1
    X3061                OBJ 7.9400000000000004
    X3061                R13 1
    X3061                R1024 1
    X3061                R1026 -1
    X3062                OBJ 7.9400000000000004
    X3062                R13 1
    X3062                R1024 -1
    X3062                R1026 1
    X3063                OBJ 15
    X3063                R15 1
    X3063                R1024 1
    X3063                R1027 -1
    X3064                OBJ 15
    X3064                R15 1
    X3064                R1024 -1
    X3064                R1027 1
    X3065                OBJ 7.5999999999999996
    X3065                R18 1
    X3065                R1028 1
    X3065                R1029 -1
    X3066                OBJ 7.5999999999999996
    X3066                R18 1
    X3066                R1028 -1
    X3066                R1029 1
    X3067                OBJ 5.0800000000000001
    X3067                R20 1
    X3067                R1028 1
    X3067                R1030 -1
    X3068                OBJ 5.0800000000000001
    X3068                R20 1
    X3068                R1028 -1
    X3068                R1030 1
    X3069                OBJ 12.44
    X3069                R22 1
    X3069                R1028 1
    X3069                R1031 -1
    X3070                OBJ 12.44
    X3070                R22 1
    X3070                R1028 -1
    X3070                R1031 1
    X3071                OBJ 4.7400000000000002
    X3071                R25 1
    X3071                R1032 1
    X3071                R1033 -1
    X3072                OBJ 4.7400000000000002
    X3072                R25 1
    X3072                R1032 -1
    X3072                R1033 1
    X3073                OBJ 4.8700000000000001
    X3073                R26 1
    X3073                R1026 -1
    X3073                R1032 1
    X3074                OBJ 4.8700000000000001
    X3074                R26 1
    X3074                R1026 1
    X3074                R1032 -1
    X3075                OBJ 5.5099999999999998
    X3075                R27 1
    X3075                R1027 -1
    X3075                R1032 1
    X3076                OBJ 5.5099999999999998
    X3076                R27 1
    X3076                R1027 1
    X3076                R1032 -1
    X3077                OBJ 5.4000000000000004
    X3077                R30 1
    X3077                R1034 1
    X3077                R1035 -1
    X3078                OBJ 5.4000000000000004
    X3078                R30 1
    X3078                R1034 -1
    X3078                R1035 1
    X3079                OBJ 3.8100000000000001
    X3079                R31 1
    X3079                R1022 -1
    X3079                R1034 1
    X3080                OBJ 3.8100000000000001
    X3080                R31 1
    X3080                R1022 1
    X3080                R1034 -1
    X3081                OBJ 7.5700000000000003
    X3081                R33 1
    X3081                R1034 1
    X3081                R1036 -1
    X3082                OBJ 7.5700000000000003
    X3082                R33 1
    X3082                R1034 -1
    X3082                R1036 1
    X3083                OBJ 4.2000000000000002
    X3083                R35 1
    X3083                R1034 -1
    X3083                R1037 1
    X3084                OBJ 7.75
    X3084                R37 1
    X3084                R1034 1
    X3084                R1038 -1
    X3085                OBJ 7.75
    X3085                R37 1
    X3085                R1034 -1
    X3085                R1038 1
    X3086                OBJ 6.0999999999999996
    X3086                R39 1
    X3086                R1021 -1
    X3086                R1039 1
    X3087                OBJ 6.0999999999999996
    X3087                R39 1
    X3087                R1021 1
    X3087                R1039 -1
    X3088                OBJ 2.3900000000000001
    X3088                R40 1
    X3088                R1023 -1
    X3088                R1039 1
    X3089                OBJ 2.3900000000000001
    X3089                R40 1
    X3089                R1023 1
    X3089                R1039 -1
    X3090                OBJ 8.3399999999999999
    X3090                R42 1
    X3090                R1029 -1
    X3090                R1040 1
    X3091                OBJ 8.3399999999999999
    X3091                R42 1
    X3091                R1029 1
    X3091                R1040 -1
    X3092                OBJ 7.5599999999999996
    X3092                R43 1
    X3092                R1030 -1
    X3092                R1040 1
    X3093                OBJ 7.5599999999999996
    X3093                R43 1
    X3093                R1030 1
    X3093                R1040 -1
    X3094                OBJ 7.4699999999999998
    X3094                R45 1
    X3094                R1040 1
    X3094                R1041 -1
    X3095                OBJ 7.4699999999999998
    X3095                R45 1
    X3095                R1040 -1
    X3095                R1041 1
    X3096                OBJ 2.6400000000000001
    X3096                R47 1
    X3096                R1020 1
    X3096                R1042 -1
    X3097                OBJ 2.6400000000000001
    X3097                R47 1
    X3097                R1020 -1
    X3097                R1042 1
    X3098                OBJ 3.9300000000000002
    X3098                R48 1
    X3098                R1020 1
    X3098                R1041 -1
    X3099                OBJ 3.9300000000000002
    X3099                R48 1
    X3099                R1020 -1
    X3099                R1041 1
    X3100                OBJ 4.3600000000000003
    X3100                R50 1
    X3100                R1033 1
    X3100                R1043 -1
    X3101                OBJ 4.3600000000000003
    X3101                R50 1
    X3101                R1033 -1
    X3101                R1043 1
    X3102                OBJ 6.6799999999999997
    X3102                R51 1
    X3102                R1033 -1
    X3102                R1037 1
    X3103                OBJ 7.2199999999999998
    X3103                R53 1
    X3103                R1035 1
    X3103                R1044 -1
    X3104                OBJ 7.2199999999999998
    X3104                R53 1
    X3104                R1035 -1
    X3104                R1044 1
    X3105                OBJ 7.7699999999999996
    X3105                R55 1
    X3105                R1035 1
    X3105                R1045 -1
    X3106                OBJ 7.7699999999999996
    X3106                R55 1
    X3106                R1035 -1
    X3106                R1045 1
    X3107                OBJ 4.6200000000000001
    X3107                R57 1
    X3107                R1021 -1
    X3107                R1046 1
    X3108                OBJ 4.6200000000000001
    X3108                R57 1
    X3108                R1021 1
    X3108                R1046 -1
    X3109                OBJ 6.9000000000000004
    X3109                R58 1
    X3109                R1023 -1
    X3109                R1046 1
    X3110                OBJ 6.9000000000000004
    X3110                R58 1
    X3110                R1023 1
    X3110                R1046 -1
    X3111                OBJ 2.75
    X3111                R60 1
    X3111                R1042 1
    X3111                R1047 -1
    X3112                OBJ 2.75
    X3112                R60 1
    X3112                R1042 -1
    X3112                R1047 1
    X3113                OBJ 5.9199999999999999
    X3113                R61 1
    X3113                R1022 -1
    X3113                R1047 1
    X3114                OBJ 5.9199999999999999
    X3114                R61 1
    X3114                R1022 1
    X3114                R1047 -1
    X3115                OBJ 4.5599999999999996
    X3115                R62 1
    X3115                R1036 -1
    X3115                R1047 1
    X3116                OBJ 4.5599999999999996
    X3116                R62 1
    X3116                R1036 1
    X3116                R1047 -1
    X3117                OBJ 2.71
    X3117                R64 1
    X3117                R1047 1
    X3117                R1048 -1
    X3118                OBJ 2.71
    X3118                R64 1
    X3118                R1047 -1
    X3118                R1048 1
    X3119                OBJ 11.82
    X3119                R66 1
    X3119                R1044 -1
    X3119                R1049 1
    X3120                OBJ 11.82
    X3120                R66 1
    X3120                R1044 1
    X3120                R1049 -1
    X3121                OBJ 5.9699999999999998
    X3121                R67 1
    X3121                R1045 -1
    X3121                R1049 1
    X3122                OBJ 5.9699999999999998
    X3122                R67 1
    X3122                R1045 1
    X3122                R1049 -1
    X3123                OBJ 13.699999999999999
    X3123                R68 1
    X3123                R1038 -1
    X3123                R1049 1
    X3124                OBJ 13.699999999999999
    X3124                R68 1
    X3124                R1038 1
    X3124                R1049 -1
    X3125                OBJ 3.8300000000000001
    X3125                R69 1
    X3125                R1038 -1
    X3125                R1043 1
    X3126                OBJ 3.8300000000000001
    X3126                R69 1
    X3126                R1038 1
    X3126                R1043 -1
    X3127                OBJ 19.77
    X3127                R71 1
    X3127                R1023 -1
    X3127                R1050 1
    X3128                OBJ 19.77
    X3128                R71 1
    X3128                R1023 1
    X3128                R1050 -1
    X3129                OBJ 7.5099999999999998
    X3129                R72 1
    X3129                R1029 -1
    X3129                R1050 1
    X3130                OBJ 7.5099999999999998
    X3130                R72 1
    X3130                R1029 1
    X3130                R1050 -1
    X3131                OBJ 4.71
    X3131                R73 1
    X3131                R1031 -1
    X3131                R1050 1
    X3132                OBJ 4.71
    X3132                R73 1
    X3132                R1031 1
    X3132                R1050 -1
    X3133                OBJ 5.1399999999999997
    X3133                R74 1
    X3133                R1023 1
    X3133                R1041 -1
    X3134                OBJ 5.1399999999999997
    X3134                R74 1
    X3134                R1023 -1
    X3134                R1041 1
    X3135                OBJ 4.1100000000000003
    X3135                R76 1
    X3135                R1030 -1
    X3135                R1051 1
    X3136                OBJ 4.1100000000000003
    X3136                R76 1
    X3136                R1030 1
    X3136                R1051 -1
    X3137                OBJ 5.9400000000000004
    X3137                R77 1
    X3137                R1041 -1
    X3137                R1051 1
    X3138                OBJ 5.9400000000000004
    X3138                R77 1
    X3138                R1041 1
    X3138                R1051 -1
    X3139                OBJ 5.0700000000000003
    X3139                R79 1
    X3139                R1051 1
    X3139                R1052 -1
    X3140                OBJ 5.0700000000000003
    X3140                R79 1
    X3140                R1051 -1
    X3140                R1052 1
    X3141                OBJ 9.0700000000000003
    X3141                R81 1
    X3141                R1030 1
    X3141                R1053 -1
    X3142                OBJ 9.0700000000000003
    X3142                R81 1
    X3142                R1030 -1
    X3142                R1053 1
    X3143                OBJ 5.2199999999999998
    X3143                R83 1
    X3143                R1036 -1
    X3143                R1054 1
    X3144                OBJ 5.2199999999999998
    X3144                R83 1
    X3144                R1036 1
    X3144                R1054 -1
    X3145                OBJ 7.2000000000000002
    X3145                R84 1
    X3145                R1053 -1
    X3145                R1054 1
    X3146                OBJ 7.2000000000000002
    X3146                R84 1
    X3146                R1053 1
    X3146                R1054 -1
    X3147                OBJ 3.27
    X3147                R85 1
    X3147                R1052 -1
    X3147                R1054 1
    X3148                OBJ 3.27
    X3148                R85 1
    X3148                R1052 1
    X3148                R1054 -1
    X3149                OBJ 5.3399999999999999
    X3149                R87 1
    X3149                R1036 1
    X3149                R1055 -1
    X3150                OBJ 5.3399999999999999
    X3150                R87 1
    X3150                R1036 -1
    X3150                R1055 1
    X3151                OBJ 6.3799999999999999
    X3151                R88 1
    X3151                R1025 1
    X3151                R1053 -1
    X3152                OBJ 6.3799999999999999
    X3152                R88 1
    X3152                R1025 -1
    X3152                R1053 1
    X3153                OBJ 6
    X3153                R89 1
    X3153                R1041 1
    X3153                R1048 -1
    X3154                OBJ 6
    X3154                R89 1
    X3154                R1041 -1
    X3154                R1048 1
    X3155                OBJ 3.7599999999999998
    X3155                R90 1
    X3155                R1037 1
    X3155                R1055 -1
    X3156                OBJ 7.8300000000000001
    X3156                R91 1
    X3156                R1027 -1
    X3156                R1053 1
    X3157                OBJ 7.8300000000000001
    X3157                R91 1
    X3157                R1027 1
    X3157                R1053 -1
    X3158                OBJ 2.1800000000000002
    X3158                R92 1
    X3158                R1048 1
    X3158                R1052 -1
    X3159                OBJ 2.1800000000000002
    X3159                R92 1
    X3159                R1048 -1
    X3159                R1052 1
    X3160                OBJ 4
    X3160                R93 1
    X3160                R1027 -1
    X3160                R1055 1
    X3161                OBJ 4
    X3161                R93 1
    X3161                R1027 1
    X3161                R1055 -1
    X3162                OBJ 2.5899999999999999
    X3162                R2 1
    X3162                R1056 1
    X3162                R1057 -1
    X3163                OBJ 2.5899999999999999
    X3163                R2 1
    X3163                R1056 -1
    X3163                R1057 1
    X3164                OBJ 10.67
    X3164                R4 1
    X3164                R1056 1
    X3164                R1058 -1
    X3165                OBJ 10.67
    X3165                R4 1
    X3165                R1056 -1
    X3165                R1058 1
    X3166                OBJ 5.5199999999999996
    X3166                R6 1
    X3166                R1056 1
    X3166                R1059 -1
    X3167                OBJ 5.5199999999999996
    X3167                R6 1
    X3167                R1056 -1
    X3167                R1059 1
    X3168                OBJ 5.4000000000000004
    X3168                R8 1
    X3168                R1056 1
    X3168                R1060 -1
    X3169                OBJ 5.4000000000000004
    X3169                R8 1
    X3169                R1056 -1
    X3169                R1060 1
    X3170                OBJ 13.630000000000001
    X3170                R11 1
    X3170                R1061 1
    X3170                R1062 -1
    X3171                OBJ 13.630000000000001
    X3171                R11 1
    X3171                R1061 -1
    X3171                R1062 1
    X3172                OBJ 7.9400000000000004
    X3172                R13 1
    X3172                R1061 1
    X3172                R1063 -1
    X3173                OBJ 7.9400000000000004
    X3173                R13 1
    X3173                R1061 -1
    X3173                R1063 1
    X3174                OBJ 15
    X3174                R15 1
    X3174                R1061 1
    X3174                R1064 -1
    X3175                OBJ 15
    X3175                R15 1
    X3175                R1061 -1
    X3175                R1064 1
    X3176                OBJ 7.5999999999999996
    X3176                R18 1
    X3176                R1065 1
    X3176                R1066 -1
    X3177                OBJ 7.5999999999999996
    X3177                R18 1
    X3177                R1065 -1
    X3177                R1066 1
    X3178                OBJ 5.0800000000000001
    X3178                R20 1
    X3178                R1065 1
    X3178                R1067 -1
    X3179                OBJ 5.0800000000000001
    X3179                R20 1
    X3179                R1065 -1
    X3179                R1067 1
    X3180                OBJ 12.44
    X3180                R22 1
    X3180                R1065 1
    X3180                R1068 -1
    X3181                OBJ 12.44
    X3181                R22 1
    X3181                R1065 -1
    X3181                R1068 1
    X3182                OBJ 4.7400000000000002
    X3182                R25 1
    X3182                R1069 1
    X3182                R1070 -1
    X3183                OBJ 4.7400000000000002
    X3183                R25 1
    X3183                R1069 -1
    X3183                R1070 1
    X3184                OBJ 4.8700000000000001
    X3184                R26 1
    X3184                R1063 -1
    X3184                R1069 1
    X3185                OBJ 4.8700000000000001
    X3185                R26 1
    X3185                R1063 1
    X3185                R1069 -1
    X3186                OBJ 5.5099999999999998
    X3186                R27 1
    X3186                R1064 -1
    X3186                R1069 1
    X3187                OBJ 5.5099999999999998
    X3187                R27 1
    X3187                R1064 1
    X3187                R1069 -1
    X3188                OBJ 5.4000000000000004
    X3188                R30 1
    X3188                R1071 1
    X3188                R1072 -1
    X3189                OBJ 5.4000000000000004
    X3189                R30 1
    X3189                R1071 -1
    X3189                R1072 1
    X3190                OBJ 3.8100000000000001
    X3190                R31 1
    X3190                R1059 -1
    X3190                R1071 1
    X3191                OBJ 3.8100000000000001
    X3191                R31 1
    X3191                R1059 1
    X3191                R1071 -1
    X3192                OBJ 7.5700000000000003
    X3192                R33 1
    X3192                R1071 1
    X3192                R1073 -1
    X3193                OBJ 7.5700000000000003
    X3193                R33 1
    X3193                R1071 -1
    X3193                R1073 1
    X3194                OBJ 4.2000000000000002
    X3194                R35 1
    X3194                R1071 1
    X3194                R1074 -1
    X3195                OBJ 4.2000000000000002
    X3195                R35 1
    X3195                R1071 -1
    X3195                R1074 1
    X3196                OBJ 7.75
    X3196                R37 1
    X3196                R1071 1
    X3196                R1075 -1
    X3197                OBJ 7.75
    X3197                R37 1
    X3197                R1071 -1
    X3197                R1075 1
    X3198                OBJ 6.0999999999999996
    X3198                R39 1
    X3198                R1058 -1
    X3198                R1076 1
    X3199                OBJ 6.0999999999999996
    X3199                R39 1
    X3199                R1058 1
    X3199                R1076 -1
    X3200                OBJ 2.3900000000000001
    X3200                R40 1
    X3200                R1060 -1
    X3200                R1076 1
    X3201                OBJ 2.3900000000000001
    X3201                R40 1
    X3201                R1060 1
    X3201                R1076 -1
    X3202                OBJ 8.3399999999999999
    X3202                R42 1
    X3202                R1066 -1
    X3202                R1077 1
    X3203                OBJ 8.3399999999999999
    X3203                R42 1
    X3203                R1066 1
    X3203                R1077 -1
    X3204                OBJ 7.5599999999999996
    X3204                R43 1
    X3204                R1067 -1
    X3204                R1077 1
    X3205                OBJ 7.5599999999999996
    X3205                R43 1
    X3205                R1067 1
    X3205                R1077 -1
    X3206                OBJ 7.4699999999999998
    X3206                R45 1
    X3206                R1077 1
    X3206                R1078 -1
    X3207                OBJ 7.4699999999999998
    X3207                R45 1
    X3207                R1077 -1
    X3207                R1078 1
    X3208                OBJ 2.6400000000000001
    X3208                R47 1
    X3208                R1057 1
    X3208                R1079 -1
    X3209                OBJ 2.6400000000000001
    X3209                R47 1
    X3209                R1057 -1
    X3209                R1079 1
    X3210                OBJ 3.9300000000000002
    X3210                R48 1
    X3210                R1057 1
    X3210                R1078 -1
    X3211                OBJ 3.9300000000000002
    X3211                R48 1
    X3211                R1057 -1
    X3211                R1078 1
    X3212                OBJ 4.3600000000000003
    X3212                R50 1
    X3212                R1070 1
    X3212                R1080 -1
    X3213                OBJ 4.3600000000000003
    X3213                R50 1
    X3213                R1070 -1
    X3213                R1080 1
    X3214                OBJ 6.6799999999999997
    X3214                R51 1
    X3214                R1070 1
    X3214                R1074 -1
    X3215                OBJ 6.6799999999999997
    X3215                R51 1
    X3215                R1070 -1
    X3215                R1074 1
    X3216                OBJ 7.2199999999999998
    X3216                R53 1
    X3216                R1072 1
    X3216                R1081 -1
    X3217                OBJ 7.2199999999999998
    X3217                R53 1
    X3217                R1072 -1
    X3217                R1081 1
    X3218                OBJ 7.7699999999999996
    X3218                R55 1
    X3218                R1072 1
    X3218                R1082 -1
    X3219                OBJ 7.7699999999999996
    X3219                R55 1
    X3219                R1072 -1
    X3219                R1082 1
    X3220                OBJ 4.6200000000000001
    X3220                R57 1
    X3220                R1058 -1
    X3220                R1083 1
    X3221                OBJ 4.6200000000000001
    X3221                R57 1
    X3221                R1058 1
    X3221                R1083 -1
    X3222                OBJ 6.9000000000000004
    X3222                R58 1
    X3222                R1060 -1
    X3222                R1083 1
    X3223                OBJ 6.9000000000000004
    X3223                R58 1
    X3223                R1060 1
    X3223                R1083 -1
    X3224                OBJ 2.75
    X3224                R60 1
    X3224                R1079 1
    X3224                R1084 -1
    X3225                OBJ 2.75
    X3225                R60 1
    X3225                R1079 -1
    X3225                R1084 1
    X3226                OBJ 5.9199999999999999
    X3226                R61 1
    X3226                R1059 -1
    X3226                R1084 1
    X3227                OBJ 5.9199999999999999
    X3227                R61 1
    X3227                R1059 1
    X3227                R1084 -1
    X3228                OBJ 4.5599999999999996
    X3228                R62 1
    X3228                R1073 -1
    X3228                R1084 1
    X3229                OBJ 4.5599999999999996
    X3229                R62 1
    X3229                R1073 1
    X3229                R1084 -1
    X3230                OBJ 2.71
    X3230                R64 1
    X3230                R1084 1
    X3230                R1085 -1
    X3231                OBJ 2.71
    X3231                R64 1
    X3231                R1084 -1
    X3231                R1085 1
    X3232                OBJ 11.82
    X3232                R66 1
    X3232                R1081 -1
    X3232                R1086 1
    X3233                OBJ 5.9699999999999998
    X3233                R67 1
    X3233                R1082 -1
    X3233                R1086 1
    X3234                OBJ 13.699999999999999
    X3234                R68 1
    X3234                R1075 -1
    X3234                R1086 1
    X3235                OBJ 3.8300000000000001
    X3235                R69 1
    X3235                R1075 -1
    X3235                R1080 1
    X3236                OBJ 3.8300000000000001
    X3236                R69 1
    X3236                R1075 1
    X3236                R1080 -1
    X3237                OBJ 19.77
    X3237                R71 1
    X3237                R1060 -1
    X3237                R1087 1
    X3238                OBJ 19.77
    X3238                R71 1
    X3238                R1060 1
    X3238                R1087 -1
    X3239                OBJ 7.5099999999999998
    X3239                R72 1
    X3239                R1066 -1
    X3239                R1087 1
    X3240                OBJ 7.5099999999999998
    X3240                R72 1
    X3240                R1066 1
    X3240                R1087 -1
    X3241                OBJ 4.71
    X3241                R73 1
    X3241                R1068 -1
    X3241                R1087 1
    X3242                OBJ 4.71
    X3242                R73 1
    X3242                R1068 1
    X3242                R1087 -1
    X3243                OBJ 5.1399999999999997
    X3243                R74 1
    X3243                R1060 1
    X3243                R1078 -1
    X3244                OBJ 5.1399999999999997
    X3244                R74 1
    X3244                R1060 -1
    X3244                R1078 1
    X3245                OBJ 4.1100000000000003
    X3245                R76 1
    X3245                R1067 -1
    X3245                R1088 1
    X3246                OBJ 4.1100000000000003
    X3246                R76 1
    X3246                R1067 1
    X3246                R1088 -1
    X3247                OBJ 5.9400000000000004
    X3247                R77 1
    X3247                R1078 -1
    X3247                R1088 1
    X3248                OBJ 5.9400000000000004
    X3248                R77 1
    X3248                R1078 1
    X3248                R1088 -1
    X3249                OBJ 5.0700000000000003
    X3249                R79 1
    X3249                R1088 1
    X3249                R1089 -1
    X3250                OBJ 5.0700000000000003
    X3250                R79 1
    X3250                R1088 -1
    X3250                R1089 1
    X3251                OBJ 9.0700000000000003
    X3251                R81 1
    X3251                R1067 1
    X3251                R1090 -1
    X3252                OBJ 9.0700000000000003
    X3252                R81 1
    X3252                R1067 -1
    X3252                R1090 1
    X3253                OBJ 5.2199999999999998
    X3253                R83 1
    X3253                R1073 -1
    X3253                R1091 1
    X3254                OBJ 5.2199999999999998
    X3254                R83 1
    X3254                R1073 1
    X3254                R1091 -1
    X3255                OBJ 7.2000000000000002
    X3255                R84 1
    X3255                R1090 -1
    X3255                R1091 1
    X3256                OBJ 7.2000000000000002
    X3256                R84 1
    X3256                R1090 1
    X3256                R1091 -1
    X3257                OBJ 3.27
    X3257                R85 1
    X3257                R1089 -1
    X3257                R1091 1
    X3258                OBJ 3.27
    X3258                R85 1
    X3258                R1089 1
    X3258                R1091 -1
    X3259                OBJ 5.3399999999999999
    X3259                R87 1
    X3259                R1073 1
    X3259                R1092 -1
    X3260                OBJ 5.3399999999999999
    X3260                R87 1
    X3260                R1073 -1
    X3260                R1092 1
    X3261                OBJ 6.3799999999999999
    X3261                R88 1
    X3261                R1062 1
    X3261                R1090 -1
    X3262                OBJ 6.3799999999999999
    X3262                R88 1
    X3262                R1062 -1
    X3262                R1090 1
    X3263                OBJ 6
    X3263                R89 1
    X3263                R1078 1
    X3263                R1085 -1
    X3264                OBJ 6
    X3264                R89 1
    X3264                R1078 -1
    X3264                R1085 1
    X3265                OBJ 3.7599999999999998
    X3265                R90 1
    X3265                R1074 1
    X3265                R1092 -1
    X3266                OBJ 3.7599999999999998
    X3266                R90 1
    X3266                R1074 -1
    X3266                R1092 1
    X3267                OBJ 7.8300000000000001
    X3267                R91 1
    X3267                R1064 -1
    X3267                R1090 1
    X3268                OBJ 7.8300000000000001
    X3268                R91 1
    X3268                R1064 1
    X3268                R1090 -1
    X3269                OBJ 2.1800000000000002
    X3269                R92 1
    X3269                R1085 1
    X3269                R1089 -1
    X3270                OBJ 2.1800000000000002
    X3270                R92 1
    X3270                R1085 -1
    X3270                R1089 1
    X3271                OBJ 4
    X3271                R93 1
    X3271                R1064 -1
    X3271                R1092 1
    X3272                OBJ 4
    X3272                R93 1
    X3272                R1064 1
    X3272                R1092 -1
    X3273                OBJ 2.5899999999999999
    X3273                R2 1
    X3273                R1093 1
    X3273                R1094 -1
    X3274                OBJ 2.5899999999999999
    X3274                R2 1
    X3274                R1093 -1
    X3274                R1094 1
    X3275                OBJ 10.67
    X3275                R4 1
    X3275                R1093 1
    X3275                R1095 -1
    X3276                OBJ 10.67
    X3276                R4 1
    X3276                R1093 -1
    X3276                R1095 1
    X3277                OBJ 5.5199999999999996
    X3277                R6 1
    X3277                R1093 1
    X3277                R1096 -1
    X3278                OBJ 5.5199999999999996
    X3278                R6 1
    X3278                R1093 -1
    X3278                R1096 1
    X3279                OBJ 5.4000000000000004
    X3279                R8 1
    X3279                R1093 1
    X3279                R1097 -1
    X3280                OBJ 5.4000000000000004
    X3280                R8 1
    X3280                R1093 -1
    X3280                R1097 1
    X3281                OBJ 13.630000000000001
    X3281                R11 1
    X3281                R1098 1
    X3281                R1099 -1
    X3282                OBJ 13.630000000000001
    X3282                R11 1
    X3282                R1098 -1
    X3282                R1099 1
    X3283                OBJ 7.9400000000000004
    X3283                R13 1
    X3283                R1098 1
    X3283                R1100 -1
    X3284                OBJ 7.9400000000000004
    X3284                R13 1
    X3284                R1098 -1
    X3284                R1100 1
    X3285                OBJ 15
    X3285                R15 1
    X3285                R1098 1
    X3285                R1101 -1
    X3286                OBJ 15
    X3286                R15 1
    X3286                R1098 -1
    X3286                R1101 1
    X3287                OBJ 7.5999999999999996
    X3287                R18 1
    X3287                R1102 1
    X3287                R1103 -1
    X3288                OBJ 7.5999999999999996
    X3288                R18 1
    X3288                R1102 -1
    X3288                R1103 1
    X3289                OBJ 5.0800000000000001
    X3289                R20 1
    X3289                R1102 1
    X3289                R1104 -1
    X3290                OBJ 5.0800000000000001
    X3290                R20 1
    X3290                R1102 -1
    X3290                R1104 1
    X3291                OBJ 12.44
    X3291                R22 1
    X3291                R1102 1
    X3291                R1105 -1
    X3292                OBJ 12.44
    X3292                R22 1
    X3292                R1102 -1
    X3292                R1105 1
    X3293                OBJ 4.7400000000000002
    X3293                R25 1
    X3293                R1106 1
    X3293                R1107 -1
    X3294                OBJ 4.7400000000000002
    X3294                R25 1
    X3294                R1106 -1
    X3294                R1107 1
    X3295                OBJ 4.8700000000000001
    X3295                R26 1
    X3295                R1100 -1
    X3295                R1106 1
    X3296                OBJ 4.8700000000000001
    X3296                R26 1
    X3296                R1100 1
    X3296                R1106 -1
    X3297                OBJ 5.5099999999999998
    X3297                R27 1
    X3297                R1101 -1
    X3297                R1106 1
    X3298                OBJ 5.5099999999999998
    X3298                R27 1
    X3298                R1101 1
    X3298                R1106 -1
    X3299                OBJ 5.4000000000000004
    X3299                R30 1
    X3299                R1108 1
    X3299                R1109 -1
    X3300                OBJ 5.4000000000000004
    X3300                R30 1
    X3300                R1108 -1
    X3300                R1109 1
    X3301                OBJ 3.8100000000000001
    X3301                R31 1
    X3301                R1096 -1
    X3301                R1108 1
    X3302                OBJ 3.8100000000000001
    X3302                R31 1
    X3302                R1096 1
    X3302                R1108 -1
    X3303                OBJ 7.5700000000000003
    X3303                R33 1
    X3303                R1108 1
    X3303                R1110 -1
    X3304                OBJ 7.5700000000000003
    X3304                R33 1
    X3304                R1108 -1
    X3304                R1110 1
    X3305                OBJ 4.2000000000000002
    X3305                R35 1
    X3305                R1108 1
    X3305                R1111 -1
    X3306                OBJ 4.2000000000000002
    X3306                R35 1
    X3306                R1108 -1
    X3306                R1111 1
    X3307                OBJ 7.75
    X3307                R37 1
    X3307                R1108 1
    X3307                R1112 -1
    X3308                OBJ 7.75
    X3308                R37 1
    X3308                R1108 -1
    X3308                R1112 1
    X3309                OBJ 6.0999999999999996
    X3309                R39 1
    X3309                R1095 -1
    X3309                R1113 1
    X3310                OBJ 6.0999999999999996
    X3310                R39 1
    X3310                R1095 1
    X3310                R1113 -1
    X3311                OBJ 2.3900000000000001
    X3311                R40 1
    X3311                R1097 -1
    X3311                R1113 1
    X3312                OBJ 2.3900000000000001
    X3312                R40 1
    X3312                R1097 1
    X3312                R1113 -1
    X3313                OBJ 8.3399999999999999
    X3313                R42 1
    X3313                R1103 -1
    X3313                R1114 1
    X3314                OBJ 8.3399999999999999
    X3314                R42 1
    X3314                R1103 1
    X3314                R1114 -1
    X3315                OBJ 7.5599999999999996
    X3315                R43 1
    X3315                R1104 -1
    X3315                R1114 1
    X3316                OBJ 7.5599999999999996
    X3316                R43 1
    X3316                R1104 1
    X3316                R1114 -1
    X3317                OBJ 7.4699999999999998
    X3317                R45 1
    X3317                R1114 1
    X3317                R1115 -1
    X3318                OBJ 7.4699999999999998
    X3318                R45 1
    X3318                R1114 -1
    X3318                R1115 1
    X3319                OBJ 2.6400000000000001
    X3319                R47 1
    X3319                R1094 1
    X3319                R1116 -1
    X3320                OBJ 2.6400000000000001
    X3320                R47 1
    X3320                R1094 -1
    X3320                R1116 1
    X3321                OBJ 3.9300000000000002
    X3321                R48 1
    X3321                R1094 1
    X3321                R1115 -1
    X3322                OBJ 3.9300000000000002
    X3322                R48 1
    X3322                R1094 -1
    X3322                R1115 1
    X3323                OBJ 4.3600000000000003
    X3323                R50 1
    X3323                R1107 1
    X3323                R1117 -1
    X3324                OBJ 4.3600000000000003
    X3324                R50 1
    X3324                R1107 -1
    X3324                R1117 1
    X3325                OBJ 6.6799999999999997
    X3325                R51 1
    X3325                R1107 1
    X3325                R1111 -1
    X3326                OBJ 6.6799999999999997
    X3326                R51 1
    X3326                R1107 -1
    X3326                R1111 1
    X3327                OBJ 7.2199999999999998
    X3327                R53 1
    X3327                R1109 1
    X3327                R1118 -1
    X3328                OBJ 7.2199999999999998
    X3328                R53 1
    X3328                R1109 -1
    X3328                R1118 1
    X3329                OBJ 7.7699999999999996
    X3329                R55 1
    X3329                R1109 1
    X3329                R1119 -1
    X3330                OBJ 7.7699999999999996
    X3330                R55 1
    X3330                R1109 -1
    X3330                R1119 1
    X3331                OBJ 4.6200000000000001
    X3331                R57 1
    X3331                R1095 -1
    X3331                R1120 1
    X3332                OBJ 4.6200000000000001
    X3332                R57 1
    X3332                R1095 1
    X3332                R1120 -1
    X3333                OBJ 6.9000000000000004
    X3333                R58 1
    X3333                R1097 -1
    X3333                R1120 1
    X3334                OBJ 6.9000000000000004
    X3334                R58 1
    X3334                R1097 1
    X3334                R1120 -1
    X3335                OBJ 2.75
    X3335                R60 1
    X3335                R1116 1
    X3335                R1121 -1
    X3336                OBJ 2.75
    X3336                R60 1
    X3336                R1116 -1
    X3336                R1121 1
    X3337                OBJ 5.9199999999999999
    X3337                R61 1
    X3337                R1096 -1
    X3337                R1121 1
    X3338                OBJ 5.9199999999999999
    X3338                R61 1
    X3338                R1096 1
    X3338                R1121 -1
    X3339                OBJ 4.5599999999999996
    X3339                R62 1
    X3339                R1110 -1
    X3339                R1121 1
    X3340                OBJ 4.5599999999999996
    X3340                R62 1
    X3340                R1110 1
    X3340                R1121 -1
    X3341                OBJ 2.71
    X3341                R64 1
    X3341                R1121 -1
    X3341                R1122 1
    X3342                OBJ 11.82
    X3342                R66 1
    X3342                R1118 -1
    X3342                R1123 1
    X3343                OBJ 11.82
    X3343                R66 1
    X3343                R1118 1
    X3343                R1123 -1
    X3344                OBJ 5.9699999999999998
    X3344                R67 1
    X3344                R1119 -1
    X3344                R1123 1
    X3345                OBJ 5.9699999999999998
    X3345                R67 1
    X3345                R1119 1
    X3345                R1123 -1
    X3346                OBJ 13.699999999999999
    X3346                R68 1
    X3346                R1112 -1
    X3346                R1123 1
    X3347                OBJ 13.699999999999999
    X3347                R68 1
    X3347                R1112 1
    X3347                R1123 -1
    X3348                OBJ 3.8300000000000001
    X3348                R69 1
    X3348                R1112 -1
    X3348                R1117 1
    X3349                OBJ 3.8300000000000001
    X3349                R69 1
    X3349                R1112 1
    X3349                R1117 -1
    X3350                OBJ 19.77
    X3350                R71 1
    X3350                R1097 -1
    X3350                R1124 1
    X3351                OBJ 19.77
    X3351                R71 1
    X3351                R1097 1
    X3351                R1124 -1
    X3352                OBJ 7.5099999999999998
    X3352                R72 1
    X3352                R1103 -1
    X3352                R1124 1
    X3353                OBJ 7.5099999999999998
    X3353                R72 1
    X3353                R1103 1
    X3353                R1124 -1
    X3354                OBJ 4.71
    X3354                R73 1
    X3354                R1105 -1
    X3354                R1124 1
    X3355                OBJ 4.71
    X3355                R73 1
    X3355                R1105 1
    X3355                R1124 -1
    X3356                OBJ 5.1399999999999997
    X3356                R74 1
    X3356                R1097 1
    X3356                R1115 -1
    X3357                OBJ 5.1399999999999997
    X3357                R74 1
    X3357                R1097 -1
    X3357                R1115 1
    X3358                OBJ 4.1100000000000003
    X3358                R76 1
    X3358                R1104 -1
    X3358                R1125 1
    X3359                OBJ 4.1100000000000003
    X3359                R76 1
    X3359                R1104 1
    X3359                R1125 -1
    X3360                OBJ 5.9400000000000004
    X3360                R77 1
    X3360                R1115 -1
    X3360                R1125 1
    X3361                OBJ 5.9400000000000004
    X3361                R77 1
    X3361                R1115 1
    X3361                R1125 -1
    X3362                OBJ 5.0700000000000003
    X3362                R79 1
    X3362                R1125 1
    X3362                R1126 -1
    X3363                OBJ 5.0700000000000003
    X3363                R79 1
    X3363                R1125 -1
    X3363                R1126 1
    X3364                OBJ 9.0700000000000003
    X3364                R81 1
    X3364                R1104 1
    X3364                R1127 -1
    X3365                OBJ 9.0700000000000003
    X3365                R81 1
    X3365                R1104 -1
    X3365                R1127 1
    X3366                OBJ 5.2199999999999998
    X3366                R83 1
    X3366                R1110 -1
    X3366                R1128 1
    X3367                OBJ 5.2199999999999998
    X3367                R83 1
    X3367                R1110 1
    X3367                R1128 -1
    X3368                OBJ 7.2000000000000002
    X3368                R84 1
    X3368                R1127 -1
    X3368                R1128 1
    X3369                OBJ 7.2000000000000002
    X3369                R84 1
    X3369                R1127 1
    X3369                R1128 -1
    X3370                OBJ 3.27
    X3370                R85 1
    X3370                R1126 -1
    X3370                R1128 1
    X3371                OBJ 3.27
    X3371                R85 1
    X3371                R1126 1
    X3371                R1128 -1
    X3372                OBJ 5.3399999999999999
    X3372                R87 1
    X3372                R1110 1
    X3372                R1129 -1
    X3373                OBJ 5.3399999999999999
    X3373                R87 1
    X3373                R1110 -1
    X3373                R1129 1
    X3374                OBJ 6.3799999999999999
    X3374                R88 1
    X3374                R1099 1
    X3374                R1127 -1
    X3375                OBJ 6.3799999999999999
    X3375                R88 1
    X3375                R1099 -1
    X3375                R1127 1
    X3376                OBJ 6
    X3376                R89 1
    X3376                R1115 -1
    X3376                R1122 1
    X3377                OBJ 3.7599999999999998
    X3377                R90 1
    X3377                R1111 1
    X3377                R1129 -1
    X3378                OBJ 3.7599999999999998
    X3378                R90 1
    X3378                R1111 -1
    X3378                R1129 1
    X3379                OBJ 7.8300000000000001
    X3379                R91 1
    X3379                R1101 -1
    X3379                R1127 1
    X3380                OBJ 7.8300000000000001
    X3380                R91 1
    X3380                R1101 1
    X3380                R1127 -1
    X3381                OBJ 2.1800000000000002
    X3381                R92 1
    X3381                R1122 1
    X3381                R1126 -1
    X3382                OBJ 4
    X3382                R93 1
    X3382                R1101 -1
    X3382                R1129 1
    X3383                OBJ 4
    X3383                R93 1
    X3383                R1101 1
    X3383                R1129 -1
    X3384                OBJ 2.5899999999999999
    X3384                R2 1
    X3384                R1130 1
    X3384                R1131 -1
    X3385                OBJ 2.5899999999999999
    X3385                R2 1
    X3385                R1130 -1
    X3385                R1131 1
    X3386                OBJ 10.67
    X3386                R4 1
    X3386                R1130 1
    X3386                R1132 -1
    X3387                OBJ 10.67
    X3387                R4 1
    X3387                R1130 -1
    X3387                R1132 1
    X3388                OBJ 5.5199999999999996
    X3388                R6 1
    X3388                R1130 1
    X3388                R1133 -1
    X3389                OBJ 5.5199999999999996
    X3389                R6 1
    X3389                R1130 -1
    X3389                R1133 1
    X3390                OBJ 5.4000000000000004
    X3390                R8 1
    X3390                R1130 1
    X3390                R1134 -1
    X3391                OBJ 5.4000000000000004
    X3391                R8 1
    X3391                R1130 -1
    X3391                R1134 1
    X3392                OBJ 13.630000000000001
    X3392                R11 1
    X3392                R1135 1
    X3392                R1136 -1
    X3393                OBJ 13.630000000000001
    X3393                R11 1
    X3393                R1135 -1
    X3393                R1136 1
    X3394                OBJ 7.9400000000000004
    X3394                R13 1
    X3394                R1135 1
    X3394                R1137 -1
    X3395                OBJ 7.9400000000000004
    X3395                R13 1
    X3395                R1135 -1
    X3395                R1137 1
    X3396                OBJ 15
    X3396                R15 1
    X3396                R1135 1
    X3396                R1138 -1
    X3397                OBJ 15
    X3397                R15 1
    X3397                R1135 -1
    X3397                R1138 1
    X3398                OBJ 7.5999999999999996
    X3398                R18 1
    X3398                R1139 1
    X3398                R1140 -1
    X3399                OBJ 7.5999999999999996
    X3399                R18 1
    X3399                R1139 -1
    X3399                R1140 1
    X3400                OBJ 5.0800000000000001
    X3400                R20 1
    X3400                R1139 1
    X3400                R1141 -1
    X3401                OBJ 5.0800000000000001
    X3401                R20 1
    X3401                R1139 -1
    X3401                R1141 1
    X3402                OBJ 12.44
    X3402                R22 1
    X3402                R1139 -1
    X3402                R1142 1
    X3403                OBJ 4.7400000000000002
    X3403                R25 1
    X3403                R1143 1
    X3403                R1144 -1
    X3404                OBJ 4.7400000000000002
    X3404                R25 1
    X3404                R1143 -1
    X3404                R1144 1
    X3405                OBJ 4.8700000000000001
    X3405                R26 1
    X3405                R1137 -1
    X3405                R1143 1
    X3406                OBJ 4.8700000000000001
    X3406                R26 1
    X3406                R1137 1
    X3406                R1143 -1
    X3407                OBJ 5.5099999999999998
    X3407                R27 1
    X3407                R1138 -1
    X3407                R1143 1
    X3408                OBJ 5.5099999999999998
    X3408                R27 1
    X3408                R1138 1
    X3408                R1143 -1
    X3409                OBJ 5.4000000000000004
    X3409                R30 1
    X3409                R1145 1
    X3409                R1146 -1
    X3410                OBJ 5.4000000000000004
    X3410                R30 1
    X3410                R1145 -1
    X3410                R1146 1
    X3411                OBJ 3.8100000000000001
    X3411                R31 1
    X3411                R1133 -1
    X3411                R1145 1
    X3412                OBJ 3.8100000000000001
    X3412                R31 1
    X3412                R1133 1
    X3412                R1145 -1
    X3413                OBJ 7.5700000000000003
    X3413                R33 1
    X3413                R1145 1
    X3413                R1147 -1
    X3414                OBJ 7.5700000000000003
    X3414                R33 1
    X3414                R1145 -1
    X3414                R1147 1
    X3415                OBJ 4.2000000000000002
    X3415                R35 1
    X3415                R1145 1
    X3415                R1148 -1
    X3416                OBJ 4.2000000000000002
    X3416                R35 1
    X3416                R1145 -1
    X3416                R1148 1
    X3417                OBJ 7.75
    X3417                R37 1
    X3417                R1145 1
    X3417                R1149 -1
    X3418                OBJ 7.75
    X3418                R37 1
    X3418                R1145 -1
    X3418                R1149 1
    X3419                OBJ 6.0999999999999996
    X3419                R39 1
    X3419                R1132 -1
    X3419                R1150 1
    X3420                OBJ 6.0999999999999996
    X3420                R39 1
    X3420                R1132 1
    X3420                R1150 -1
    X3421                OBJ 2.3900000000000001
    X3421                R40 1
    X3421                R1134 -1
    X3421                R1150 1
    X3422                OBJ 2.3900000000000001
    X3422                R40 1
    X3422                R1134 1
    X3422                R1150 -1
    X3423                OBJ 8.3399999999999999
    X3423                R42 1
    X3423                R1140 -1
    X3423                R1151 1
    X3424                OBJ 8.3399999999999999
    X3424                R42 1
    X3424                R1140 1
    X3424                R1151 -1
    X3425                OBJ 7.5599999999999996
    X3425                R43 1
    X3425                R1141 -1
    X3425                R1151 1
    X3426                OBJ 7.5599999999999996
    X3426                R43 1
    X3426                R1141 1
    X3426                R1151 -1
    X3427                OBJ 7.4699999999999998
    X3427                R45 1
    X3427                R1151 1
    X3427                R1152 -1
    X3428                OBJ 7.4699999999999998
    X3428                R45 1
    X3428                R1151 -1
    X3428                R1152 1
    X3429                OBJ 2.6400000000000001
    X3429                R47 1
    X3429                R1131 1
    X3429                R1153 -1
    X3430                OBJ 2.6400000000000001
    X3430                R47 1
    X3430                R1131 -1
    X3430                R1153 1
    X3431                OBJ 3.9300000000000002
    X3431                R48 1
    X3431                R1131 1
    X3431                R1152 -1
    X3432                OBJ 3.9300000000000002
    X3432                R48 1
    X3432                R1131 -1
    X3432                R1152 1
    X3433                OBJ 4.3600000000000003
    X3433                R50 1
    X3433                R1144 1
    X3433                R1154 -1
    X3434                OBJ 4.3600000000000003
    X3434                R50 1
    X3434                R1144 -1
    X3434                R1154 1
    X3435                OBJ 6.6799999999999997
    X3435                R51 1
    X3435                R1144 1
    X3435                R1148 -1
    X3436                OBJ 6.6799999999999997
    X3436                R51 1
    X3436                R1144 -1
    X3436                R1148 1
    X3437                OBJ 7.2199999999999998
    X3437                R53 1
    X3437                R1146 1
    X3437                R1155 -1
    X3438                OBJ 7.2199999999999998
    X3438                R53 1
    X3438                R1146 -1
    X3438                R1155 1
    X3439                OBJ 7.7699999999999996
    X3439                R55 1
    X3439                R1146 1
    X3439                R1156 -1
    X3440                OBJ 7.7699999999999996
    X3440                R55 1
    X3440                R1146 -1
    X3440                R1156 1
    X3441                OBJ 4.6200000000000001
    X3441                R57 1
    X3441                R1132 -1
    X3441                R1157 1
    X3442                OBJ 4.6200000000000001
    X3442                R57 1
    X3442                R1132 1
    X3442                R1157 -1
    X3443                OBJ 6.9000000000000004
    X3443                R58 1
    X3443                R1134 -1
    X3443                R1157 1
    X3444                OBJ 6.9000000000000004
    X3444                R58 1
    X3444                R1134 1
    X3444                R1157 -1
    X3445                OBJ 2.75
    X3445                R60 1
    X3445                R1153 1
    X3445                R1158 -1
    X3446                OBJ 2.75
    X3446                R60 1
    X3446                R1153 -1
    X3446                R1158 1
    X3447                OBJ 5.9199999999999999
    X3447                R61 1
    X3447                R1133 -1
    X3447                R1158 1
    X3448                OBJ 5.9199999999999999
    X3448                R61 1
    X3448                R1133 1
    X3448                R1158 -1
    X3449                OBJ 4.5599999999999996
    X3449                R62 1
    X3449                R1147 -1
    X3449                R1158 1
    X3450                OBJ 4.5599999999999996
    X3450                R62 1
    X3450                R1147 1
    X3450                R1158 -1
    X3451                OBJ 2.71
    X3451                R64 1
    X3451                R1158 1
    X3451                R1159 -1
    X3452                OBJ 2.71
    X3452                R64 1
    X3452                R1158 -1
    X3452                R1159 1
    X3453                OBJ 11.82
    X3453                R66 1
    X3453                R1155 -1
    X3453                R1160 1
    X3454                OBJ 11.82
    X3454                R66 1
    X3454                R1155 1
    X3454                R1160 -1
    X3455                OBJ 5.9699999999999998
    X3455                R67 1
    X3455                R1156 -1
    X3455                R1160 1
    X3456                OBJ 5.9699999999999998
    X3456                R67 1
    X3456                R1156 1
    X3456                R1160 -1
    X3457                OBJ 13.699999999999999
    X3457                R68 1
    X3457                R1149 -1
    X3457                R1160 1
    X3458                OBJ 13.699999999999999
    X3458                R68 1
    X3458                R1149 1
    X3458                R1160 -1
    X3459                OBJ 3.8300000000000001
    X3459                R69 1
    X3459                R1149 -1
    X3459                R1154 1
    X3460                OBJ 3.8300000000000001
    X3460                R69 1
    X3460                R1149 1
    X3460                R1154 -1
    X3461                OBJ 19.77
    X3461                R71 1
    X3461                R1134 -1
    X3461                R1161 1
    X3462                OBJ 19.77
    X3462                R71 1
    X3462                R1134 1
    X3462                R1161 -1
    X3463                OBJ 7.5099999999999998
    X3463                R72 1
    X3463                R1140 -1
    X3463                R1161 1
    X3464                OBJ 7.5099999999999998
    X3464                R72 1
    X3464                R1140 1
    X3464                R1161 -1
    X3465                OBJ 4.71
    X3465                R73 1
    X3465                R1142 1
    X3465                R1161 -1
    X3466                OBJ 5.1399999999999997
    X3466                R74 1
    X3466                R1134 1
    X3466                R1152 -1
    X3467                OBJ 5.1399999999999997
    X3467                R74 1
    X3467                R1134 -1
    X3467                R1152 1
    X3468                OBJ 4.1100000000000003
    X3468                R76 1
    X3468                R1141 -1
    X3468                R1162 1
    X3469                OBJ 4.1100000000000003
    X3469                R76 1
    X3469                R1141 1
    X3469                R1162 -1
    X3470                OBJ 5.9400000000000004
    X3470                R77 1
    X3470                R1152 -1
    X3470                R1162 1
    X3471                OBJ 5.9400000000000004
    X3471                R77 1
    X3471                R1152 1
    X3471                R1162 -1
    X3472                OBJ 5.0700000000000003
    X3472                R79 1
    X3472                R1162 1
    X3472                R1163 -1
    X3473                OBJ 5.0700000000000003
    X3473                R79 1
    X3473                R1162 -1
    X3473                R1163 1
    X3474                OBJ 9.0700000000000003
    X3474                R81 1
    X3474                R1141 1
    X3474                R1164 -1
    X3475                OBJ 9.0700000000000003
    X3475                R81 1
    X3475                R1141 -1
    X3475                R1164 1
    X3476                OBJ 5.2199999999999998
    X3476                R83 1
    X3476                R1147 -1
    X3476                R1165 1
    X3477                OBJ 5.2199999999999998
    X3477                R83 1
    X3477                R1147 1
    X3477                R1165 -1
    X3478                OBJ 7.2000000000000002
    X3478                R84 1
    X3478                R1164 -1
    X3478                R1165 1
    X3479                OBJ 7.2000000000000002
    X3479                R84 1
    X3479                R1164 1
    X3479                R1165 -1
    X3480                OBJ 3.27
    X3480                R85 1
    X3480                R1163 -1
    X3480                R1165 1
    X3481                OBJ 3.27
    X3481                R85 1
    X3481                R1163 1
    X3481                R1165 -1
    X3482                OBJ 5.3399999999999999
    X3482                R87 1
    X3482                R1147 1
    X3482                R1166 -1
    X3483                OBJ 5.3399999999999999
    X3483                R87 1
    X3483                R1147 -1
    X3483                R1166 1
    X3484                OBJ 6.3799999999999999
    X3484                R88 1
    X3484                R1136 1
    X3484                R1164 -1
    X3485                OBJ 6.3799999999999999
    X3485                R88 1
    X3485                R1136 -1
    X3485                R1164 1
    X3486                OBJ 6
    X3486                R89 1
    X3486                R1152 1
    X3486                R1159 -1
    X3487                OBJ 6
    X3487                R89 1
    X3487                R1152 -1
    X3487                R1159 1
    X3488                OBJ 3.7599999999999998
    X3488                R90 1
    X3488                R1148 1
    X3488                R1166 -1
    X3489                OBJ 3.7599999999999998
    X3489                R90 1
    X3489                R1148 -1
    X3489                R1166 1
    X3490                OBJ 7.8300000000000001
    X3490                R91 1
    X3490                R1138 -1
    X3490                R1164 1
    X3491                OBJ 7.8300000000000001
    X3491                R91 1
    X3491                R1138 1
    X3491                R1164 -1
    X3492                OBJ 2.1800000000000002
    X3492                R92 1
    X3492                R1159 1
    X3492                R1163 -1
    X3493                OBJ 2.1800000000000002
    X3493                R92 1
    X3493                R1159 -1
    X3493                R1163 1
    X3494                OBJ 4
    X3494                R93 1
    X3494                R1138 -1
    X3494                R1166 1
    X3495                OBJ 4
    X3495                R93 1
    X3495                R1138 1
    X3495                R1166 -1
    X3496                OBJ 2.5899999999999999
    X3496                R2 1
    X3496                R1167 1
    X3496                R1168 -1
    X3497                OBJ 2.5899999999999999
    X3497                R2 1
    X3497                R1167 -1
    X3497                R1168 1
    X3498                OBJ 10.67
    X3498                R4 1
    X3498                R1167 1
    X3498                R1169 -1
    X3499                OBJ 10.67
    X3499                R4 1
    X3499                R1167 -1
    X3499                R1169 1
    X3500                OBJ 5.5199999999999996
    X3500                R6 1
    X3500                R1167 1
    X3500                R1170 -1
    X3501                OBJ 5.5199999999999996
    X3501                R6 1
    X3501                R1167 -1
    X3501                R1170 1
    X3502                OBJ 5.4000000000000004
    X3502                R8 1
    X3502                R1167 1
    X3502                R1171 -1
    X3503                OBJ 5.4000000000000004
    X3503                R8 1
    X3503                R1167 -1
    X3503                R1171 1
    X3504                OBJ 13.630000000000001
    X3504                R11 1
    X3504                R1172 1
    X3504                R1173 -1
    X3505                OBJ 13.630000000000001
    X3505                R11 1
    X3505                R1172 -1
    X3505                R1173 1
    X3506                OBJ 7.9400000000000004
    X3506                R13 1
    X3506                R1172 1
    X3506                R1174 -1
    X3507                OBJ 7.9400000000000004
    X3507                R13 1
    X3507                R1172 -1
    X3507                R1174 1
    X3508                OBJ 15
    X3508                R15 1
    X3508                R1172 1
    X3508                R1175 -1
    X3509                OBJ 15
    X3509                R15 1
    X3509                R1172 -1
    X3509                R1175 1
    X3510                OBJ 7.5999999999999996
    X3510                R18 1
    X3510                R1176 1
    X3510                R1177 -1
    X3511                OBJ 7.5999999999999996
    X3511                R18 1
    X3511                R1176 -1
    X3511                R1177 1
    X3512                OBJ 5.0800000000000001
    X3512                R20 1
    X3512                R1176 1
    X3512                R1178 -1
    X3513                OBJ 5.0800000000000001
    X3513                R20 1
    X3513                R1176 -1
    X3513                R1178 1
    X3514                OBJ 12.44
    X3514                R22 1
    X3514                R1176 1
    X3514                R1179 -1
    X3515                OBJ 12.44
    X3515                R22 1
    X3515                R1176 -1
    X3515                R1179 1
    X3516                OBJ 4.7400000000000002
    X3516                R25 1
    X3516                R1180 1
    X3516                R1181 -1
    X3517                OBJ 4.7400000000000002
    X3517                R25 1
    X3517                R1180 -1
    X3517                R1181 1
    X3518                OBJ 4.8700000000000001
    X3518                R26 1
    X3518                R1174 -1
    X3518                R1180 1
    X3519                OBJ 4.8700000000000001
    X3519                R26 1
    X3519                R1174 1
    X3519                R1180 -1
    X3520                OBJ 5.5099999999999998
    X3520                R27 1
    X3520                R1175 -1
    X3520                R1180 1
    X3521                OBJ 5.5099999999999998
    X3521                R27 1
    X3521                R1175 1
    X3521                R1180 -1
    X3522                OBJ 5.4000000000000004
    X3522                R30 1
    X3522                R1182 1
    X3522                R1183 -1
    X3523                OBJ 5.4000000000000004
    X3523                R30 1
    X3523                R1182 -1
    X3523                R1183 1
    X3524                OBJ 3.8100000000000001
    X3524                R31 1
    X3524                R1170 -1
    X3524                R1182 1
    X3525                OBJ 3.8100000000000001
    X3525                R31 1
    X3525                R1170 1
    X3525                R1182 -1
    X3526                OBJ 7.5700000000000003
    X3526                R33 1
    X3526                R1182 1
    X3526                R1184 -1
    X3527                OBJ 7.5700000000000003
    X3527                R33 1
    X3527                R1182 -1
    X3527                R1184 1
    X3528                OBJ 4.2000000000000002
    X3528                R35 1
    X3528                R1182 1
    X3528                R1185 -1
    X3529                OBJ 4.2000000000000002
    X3529                R35 1
    X3529                R1182 -1
    X3529                R1185 1
    X3530                OBJ 7.75
    X3530                R37 1
    X3530                R1182 1
    X3530                R1186 -1
    X3531                OBJ 7.75
    X3531                R37 1
    X3531                R1182 -1
    X3531                R1186 1
    X3532                OBJ 6.0999999999999996
    X3532                R39 1
    X3532                R1169 -1
    X3532                R1187 1
    X3533                OBJ 6.0999999999999996
    X3533                R39 1
    X3533                R1169 1
    X3533                R1187 -1
    X3534                OBJ 2.3900000000000001
    X3534                R40 1
    X3534                R1171 -1
    X3534                R1187 1
    X3535                OBJ 2.3900000000000001
    X3535                R40 1
    X3535                R1171 1
    X3535                R1187 -1
    X3536                OBJ 8.3399999999999999
    X3536                R42 1
    X3536                R1177 -1
    X3536                R1188 1
    X3537                OBJ 8.3399999999999999
    X3537                R42 1
    X3537                R1177 1
    X3537                R1188 -1
    X3538                OBJ 7.5599999999999996
    X3538                R43 1
    X3538                R1178 -1
    X3538                R1188 1
    X3539                OBJ 7.5599999999999996
    X3539                R43 1
    X3539                R1178 1
    X3539                R1188 -1
    X3540                OBJ 7.4699999999999998
    X3540                R45 1
    X3540                R1188 1
    X3540                R1189 -1
    X3541                OBJ 7.4699999999999998
    X3541                R45 1
    X3541                R1188 -1
    X3541                R1189 1
    X3542                OBJ 2.6400000000000001
    X3542                R47 1
    X3542                R1168 1
    X3542                R1190 -1
    X3543                OBJ 2.6400000000000001
    X3543                R47 1
    X3543                R1168 -1
    X3543                R1190 1
    X3544                OBJ 3.9300000000000002
    X3544                R48 1
    X3544                R1168 1
    X3544                R1189 -1
    X3545                OBJ 3.9300000000000002
    X3545                R48 1
    X3545                R1168 -1
    X3545                R1189 1
    X3546                OBJ 4.3600000000000003
    X3546                R50 1
    X3546                R1181 1
    X3546                R1191 -1
    X3547                OBJ 4.3600000000000003
    X3547                R50 1
    X3547                R1181 -1
    X3547                R1191 1
    X3548                OBJ 6.6799999999999997
    X3548                R51 1
    X3548                R1181 1
    X3548                R1185 -1
    X3549                OBJ 6.6799999999999997
    X3549                R51 1
    X3549                R1181 -1
    X3549                R1185 1
    X3550                OBJ 7.2199999999999998
    X3550                R53 1
    X3550                R1183 -1
    X3550                R1192 1
    X3551                OBJ 7.7699999999999996
    X3551                R55 1
    X3551                R1183 1
    X3551                R1193 -1
    X3552                OBJ 7.7699999999999996
    X3552                R55 1
    X3552                R1183 -1
    X3552                R1193 1
    X3553                OBJ 4.6200000000000001
    X3553                R57 1
    X3553                R1169 -1
    X3553                R1194 1
    X3554                OBJ 4.6200000000000001
    X3554                R57 1
    X3554                R1169 1
    X3554                R1194 -1
    X3555                OBJ 6.9000000000000004
    X3555                R58 1
    X3555                R1171 -1
    X3555                R1194 1
    X3556                OBJ 6.9000000000000004
    X3556                R58 1
    X3556                R1171 1
    X3556                R1194 -1
    X3557                OBJ 2.75
    X3557                R60 1
    X3557                R1190 1
    X3557                R1195 -1
    X3558                OBJ 2.75
    X3558                R60 1
    X3558                R1190 -1
    X3558                R1195 1
    X3559                OBJ 5.9199999999999999
    X3559                R61 1
    X3559                R1170 -1
    X3559                R1195 1
    X3560                OBJ 5.9199999999999999
    X3560                R61 1
    X3560                R1170 1
    X3560                R1195 -1
    X3561                OBJ 4.5599999999999996
    X3561                R62 1
    X3561                R1184 -1
    X3561                R1195 1
    X3562                OBJ 4.5599999999999996
    X3562                R62 1
    X3562                R1184 1
    X3562                R1195 -1
    X3563                OBJ 2.71
    X3563                R64 1
    X3563                R1195 1
    X3563                R1196 -1
    X3564                OBJ 2.71
    X3564                R64 1
    X3564                R1195 -1
    X3564                R1196 1
    X3565                OBJ 11.82
    X3565                R66 1
    X3565                R1192 1
    X3565                R1197 -1
    X3566                OBJ 5.9699999999999998
    X3566                R67 1
    X3566                R1193 -1
    X3566                R1197 1
    X3567                OBJ 5.9699999999999998
    X3567                R67 1
    X3567                R1193 1
    X3567                R1197 -1
    X3568                OBJ 13.699999999999999
    X3568                R68 1
    X3568                R1186 -1
    X3568                R1197 1
    X3569                OBJ 13.699999999999999
    X3569                R68 1
    X3569                R1186 1
    X3569                R1197 -1
    X3570                OBJ 3.8300000000000001
    X3570                R69 1
    X3570                R1186 -1
    X3570                R1191 1
    X3571                OBJ 3.8300000000000001
    X3571                R69 1
    X3571                R1186 1
    X3571                R1191 -1
    X3572                OBJ 19.77
    X3572                R71 1
    X3572                R1171 -1
    X3572                R1198 1
    X3573                OBJ 19.77
    X3573                R71 1
    X3573                R1171 1
    X3573                R1198 -1
    X3574                OBJ 7.5099999999999998
    X3574                R72 1
    X3574                R1177 -1
    X3574                R1198 1
    X3575                OBJ 7.5099999999999998
    X3575                R72 1
    X3575                R1177 1
    X3575                R1198 -1
    X3576                OBJ 4.71
    X3576                R73 1
    X3576                R1179 -1
    X3576                R1198 1
    X3577                OBJ 4.71
    X3577                R73 1
    X3577                R1179 1
    X3577                R1198 -1
    X3578                OBJ 5.1399999999999997
    X3578                R74 1
    X3578                R1171 1
    X3578                R1189 -1
    X3579                OBJ 5.1399999999999997
    X3579                R74 1
    X3579                R1171 -1
    X3579                R1189 1
    X3580                OBJ 4.1100000000000003
    X3580                R76 1
    X3580                R1178 -1
    X3580                R1199 1
    X3581                OBJ 4.1100000000000003
    X3581                R76 1
    X3581                R1178 1
    X3581                R1199 -1
    X3582                OBJ 5.9400000000000004
    X3582                R77 1
    X3582                R1189 -1
    X3582                R1199 1
    X3583                OBJ 5.9400000000000004
    X3583                R77 1
    X3583                R1189 1
    X3583                R1199 -1
    X3584                OBJ 5.0700000000000003
    X3584                R79 1
    X3584                R1199 1
    X3584                R1200 -1
    X3585                OBJ 5.0700000000000003
    X3585                R79 1
    X3585                R1199 -1
    X3585                R1200 1
    X3586                OBJ 9.0700000000000003
    X3586                R81 1
    X3586                R1178 1
    X3586                R1201 -1
    X3587                OBJ 9.0700000000000003
    X3587                R81 1
    X3587                R1178 -1
    X3587                R1201 1
    X3588                OBJ 5.2199999999999998
    X3588                R83 1
    X3588                R1184 -1
    X3588                R1202 1
    X3589                OBJ 5.2199999999999998
    X3589                R83 1
    X3589                R1184 1
    X3589                R1202 -1
    X3590                OBJ 7.2000000000000002
    X3590                R84 1
    X3590                R1201 -1
    X3590                R1202 1
    X3591                OBJ 7.2000000000000002
    X3591                R84 1
    X3591                R1201 1
    X3591                R1202 -1
    X3592                OBJ 3.27
    X3592                R85 1
    X3592                R1200 -1
    X3592                R1202 1
    X3593                OBJ 3.27
    X3593                R85 1
    X3593                R1200 1
    X3593                R1202 -1
    X3594                OBJ 5.3399999999999999
    X3594                R87 1
    X3594                R1184 1
    X3594                R1203 -1
    X3595                OBJ 5.3399999999999999
    X3595                R87 1
    X3595                R1184 -1
    X3595                R1203 1
    X3596                OBJ 6.3799999999999999
    X3596                R88 1
    X3596                R1173 1
    X3596                R1201 -1
    X3597                OBJ 6.3799999999999999
    X3597                R88 1
    X3597                R1173 -1
    X3597                R1201 1
    X3598                OBJ 6
    X3598                R89 1
    X3598                R1189 1
    X3598                R1196 -1
    X3599                OBJ 6
    X3599                R89 1
    X3599                R1189 -1
    X3599                R1196 1
    X3600                OBJ 3.7599999999999998
    X3600                R90 1
    X3600                R1185 1
    X3600                R1203 -1
    X3601                OBJ 3.7599999999999998
    X3601                R90 1
    X3601                R1185 -1
    X3601                R1203 1
    X3602                OBJ 7.8300000000000001
    X3602                R91 1
    X3602                R1175 -1
    X3602                R1201 1
    X3603                OBJ 7.8300000000000001
    X3603                R91 1
    X3603                R1175 1
    X3603                R1201 -1
    X3604                OBJ 2.1800000000000002
    X3604                R92 1
    X3604                R1196 1
    X3604                R1200 -1
    X3605                OBJ 2.1800000000000002
    X3605                R92 1
    X3605                R1196 -1
    X3605                R1200 1
    X3606                OBJ 4
    X3606                R93 1
    X3606                R1175 -1
    X3606                R1203 1
    X3607                OBJ 4
    X3607                R93 1
    X3607                R1175 1
    X3607                R1203 -1
    X3608                OBJ 2.5899999999999999
    X3608                R2 1
    X3608                R1204 1
    X3608                R1205 -1
    X3609                OBJ 2.5899999999999999
    X3609                R2 1
    X3609                R1204 -1
    X3609                R1205 1
    X3610                OBJ 10.67
    X3610                R4 1
    X3610                R1204 1
    X3610                R1206 -1
    X3611                OBJ 10.67
    X3611                R4 1
    X3611                R1204 -1
    X3611                R1206 1
    X3612                OBJ 5.5199999999999996
    X3612                R6 1
    X3612                R1204 1
    X3612                R1207 -1
    X3613                OBJ 5.5199999999999996
    X3613                R6 1
    X3613                R1204 -1
    X3613                R1207 1
    X3614                OBJ 5.4000000000000004
    X3614                R8 1
    X3614                R1204 1
    X3614                R1208 -1
    X3615                OBJ 5.4000000000000004
    X3615                R8 1
    X3615                R1204 -1
    X3615                R1208 1
    X3616                OBJ 13.630000000000001
    X3616                R11 1
    X3616                R1209 1
    X3616                R1210 -1
    X3617                OBJ 13.630000000000001
    X3617                R11 1
    X3617                R1209 -1
    X3617                R1210 1
    X3618                OBJ 7.9400000000000004
    X3618                R13 1
    X3618                R1209 1
    X3618                R1211 -1
    X3619                OBJ 7.9400000000000004
    X3619                R13 1
    X3619                R1209 -1
    X3619                R1211 1
    X3620                OBJ 15
    X3620                R15 1
    X3620                R1209 1
    X3620                R1212 -1
    X3621                OBJ 15
    X3621                R15 1
    X3621                R1209 -1
    X3621                R1212 1
    X3622                OBJ 7.5999999999999996
    X3622                R18 1
    X3622                R1213 1
    X3622                R1214 -1
    X3623                OBJ 7.5999999999999996
    X3623                R18 1
    X3623                R1213 -1
    X3623                R1214 1
    X3624                OBJ 5.0800000000000001
    X3624                R20 1
    X3624                R1213 1
    X3624                R1215 -1
    X3625                OBJ 5.0800000000000001
    X3625                R20 1
    X3625                R1213 -1
    X3625                R1215 1
    X3626                OBJ 12.44
    X3626                R22 1
    X3626                R1213 1
    X3626                R1216 -1
    X3627                OBJ 12.44
    X3627                R22 1
    X3627                R1213 -1
    X3627                R1216 1
    X3628                OBJ 4.7400000000000002
    X3628                R25 1
    X3628                R1217 1
    X3628                R1218 -1
    X3629                OBJ 4.7400000000000002
    X3629                R25 1
    X3629                R1217 -1
    X3629                R1218 1
    X3630                OBJ 4.8700000000000001
    X3630                R26 1
    X3630                R1211 -1
    X3630                R1217 1
    X3631                OBJ 4.8700000000000001
    X3631                R26 1
    X3631                R1211 1
    X3631                R1217 -1
    X3632                OBJ 5.5099999999999998
    X3632                R27 1
    X3632                R1212 -1
    X3632                R1217 1
    X3633                OBJ 5.5099999999999998
    X3633                R27 1
    X3633                R1212 1
    X3633                R1217 -1
    X3634                OBJ 5.4000000000000004
    X3634                R30 1
    X3634                R1219 1
    X3634                R1220 -1
    X3635                OBJ 5.4000000000000004
    X3635                R30 1
    X3635                R1219 -1
    X3635                R1220 1
    X3636                OBJ 3.8100000000000001
    X3636                R31 1
    X3636                R1207 -1
    X3636                R1219 1
    X3637                OBJ 3.8100000000000001
    X3637                R31 1
    X3637                R1207 1
    X3637                R1219 -1
    X3638                OBJ 7.5700000000000003
    X3638                R33 1
    X3638                R1219 1
    X3638                R1221 -1
    X3639                OBJ 7.5700000000000003
    X3639                R33 1
    X3639                R1219 -1
    X3639                R1221 1
    X3640                OBJ 4.2000000000000002
    X3640                R35 1
    X3640                R1219 1
    X3640                R1222 -1
    X3641                OBJ 4.2000000000000002
    X3641                R35 1
    X3641                R1219 -1
    X3641                R1222 1
    X3642                OBJ 7.75
    X3642                R37 1
    X3642                R1219 1
    X3642                R1223 -1
    X3643                OBJ 7.75
    X3643                R37 1
    X3643                R1219 -1
    X3643                R1223 1
    X3644                OBJ 6.0999999999999996
    X3644                R39 1
    X3644                R1206 -1
    X3644                R1224 1
    X3645                OBJ 6.0999999999999996
    X3645                R39 1
    X3645                R1206 1
    X3645                R1224 -1
    X3646                OBJ 2.3900000000000001
    X3646                R40 1
    X3646                R1208 -1
    X3646                R1224 1
    X3647                OBJ 2.3900000000000001
    X3647                R40 1
    X3647                R1208 1
    X3647                R1224 -1
    X3648                OBJ 8.3399999999999999
    X3648                R42 1
    X3648                R1214 -1
    X3648                R1225 1
    X3649                OBJ 8.3399999999999999
    X3649                R42 1
    X3649                R1214 1
    X3649                R1225 -1
    X3650                OBJ 7.5599999999999996
    X3650                R43 1
    X3650                R1215 -1
    X3650                R1225 1
    X3651                OBJ 7.5599999999999996
    X3651                R43 1
    X3651                R1215 1
    X3651                R1225 -1
    X3652                OBJ 7.4699999999999998
    X3652                R45 1
    X3652                R1225 1
    X3652                R1226 -1
    X3653                OBJ 7.4699999999999998
    X3653                R45 1
    X3653                R1225 -1
    X3653                R1226 1
    X3654                OBJ 2.6400000000000001
    X3654                R47 1
    X3654                R1205 1
    X3654                R1227 -1
    X3655                OBJ 2.6400000000000001
    X3655                R47 1
    X3655                R1205 -1
    X3655                R1227 1
    X3656                OBJ 3.9300000000000002
    X3656                R48 1
    X3656                R1205 1
    X3656                R1226 -1
    X3657                OBJ 3.9300000000000002
    X3657                R48 1
    X3657                R1205 -1
    X3657                R1226 1
    X3658                OBJ 4.3600000000000003
    X3658                R50 1
    X3658                R1218 1
    X3658                R1228 -1
    X3659                OBJ 4.3600000000000003
    X3659                R50 1
    X3659                R1218 -1
    X3659                R1228 1
    X3660                OBJ 6.6799999999999997
    X3660                R51 1
    X3660                R1218 1
    X3660                R1222 -1
    X3661                OBJ 6.6799999999999997
    X3661                R51 1
    X3661                R1218 -1
    X3661                R1222 1
    X3662                OBJ 7.2199999999999998
    X3662                R53 1
    X3662                R1220 1
    X3662                R1229 -1
    X3663                OBJ 7.2199999999999998
    X3663                R53 1
    X3663                R1220 -1
    X3663                R1229 1
    X3664                OBJ 7.7699999999999996
    X3664                R55 1
    X3664                R1220 -1
    X3664                R1230 1
    X3665                OBJ 4.6200000000000001
    X3665                R57 1
    X3665                R1206 -1
    X3665                R1231 1
    X3666                OBJ 4.6200000000000001
    X3666                R57 1
    X3666                R1206 1
    X3666                R1231 -1
    X3667                OBJ 6.9000000000000004
    X3667                R58 1
    X3667                R1208 -1
    X3667                R1231 1
    X3668                OBJ 6.9000000000000004
    X3668                R58 1
    X3668                R1208 1
    X3668                R1231 -1
    X3669                OBJ 2.75
    X3669                R60 1
    X3669                R1227 1
    X3669                R1232 -1
    X3670                OBJ 2.75
    X3670                R60 1
    X3670                R1227 -1
    X3670                R1232 1
    X3671                OBJ 5.9199999999999999
    X3671                R61 1
    X3671                R1207 -1
    X3671                R1232 1
    X3672                OBJ 5.9199999999999999
    X3672                R61 1
    X3672                R1207 1
    X3672                R1232 -1
    X3673                OBJ 4.5599999999999996
    X3673                R62 1
    X3673                R1221 -1
    X3673                R1232 1
    X3674                OBJ 4.5599999999999996
    X3674                R62 1
    X3674                R1221 1
    X3674                R1232 -1
    X3675                OBJ 2.71
    X3675                R64 1
    X3675                R1232 1
    X3675                R1233 -1
    X3676                OBJ 2.71
    X3676                R64 1
    X3676                R1232 -1
    X3676                R1233 1
    X3677                OBJ 11.82
    X3677                R66 1
    X3677                R1229 -1
    X3677                R1234 1
    X3678                OBJ 11.82
    X3678                R66 1
    X3678                R1229 1
    X3678                R1234 -1
    X3679                OBJ 5.9699999999999998
    X3679                R67 1
    X3679                R1230 1
    X3679                R1234 -1
    X3680                OBJ 13.699999999999999
    X3680                R68 1
    X3680                R1223 -1
    X3680                R1234 1
    X3681                OBJ 13.699999999999999
    X3681                R68 1
    X3681                R1223 1
    X3681                R1234 -1
    X3682                OBJ 3.8300000000000001
    X3682                R69 1
    X3682                R1223 -1
    X3682                R1228 1
    X3683                OBJ 3.8300000000000001
    X3683                R69 1
    X3683                R1223 1
    X3683                R1228 -1
    X3684                OBJ 19.77
    X3684                R71 1
    X3684                R1208 -1
    X3684                R1235 1
    X3685                OBJ 19.77
    X3685                R71 1
    X3685                R1208 1
    X3685                R1235 -1
    X3686                OBJ 7.5099999999999998
    X3686                R72 1
    X3686                R1214 -1
    X3686                R1235 1
    X3687                OBJ 7.5099999999999998
    X3687                R72 1
    X3687                R1214 1
    X3687                R1235 -1
    X3688                OBJ 4.71
    X3688                R73 1
    X3688                R1216 -1
    X3688                R1235 1
    X3689                OBJ 4.71
    X3689                R73 1
    X3689                R1216 1
    X3689                R1235 -1
    X3690                OBJ 5.1399999999999997
    X3690                R74 1
    X3690                R1208 1
    X3690                R1226 -1
    X3691                OBJ 5.1399999999999997
    X3691                R74 1
    X3691                R1208 -1
    X3691                R1226 1
    X3692                OBJ 4.1100000000000003
    X3692                R76 1
    X3692                R1215 -1
    X3692                R1236 1
    X3693                OBJ 4.1100000000000003
    X3693                R76 1
    X3693                R1215 1
    X3693                R1236 -1
    X3694                OBJ 5.9400000000000004
    X3694                R77 1
    X3694                R1226 -1
    X3694                R1236 1
    X3695                OBJ 5.9400000000000004
    X3695                R77 1
    X3695                R1226 1
    X3695                R1236 -1
    X3696                OBJ 5.0700000000000003
    X3696                R79 1
    X3696                R1236 1
    X3696                R1237 -1
    X3697                OBJ 5.0700000000000003
    X3697                R79 1
    X3697                R1236 -1
    X3697                R1237 1
    X3698                OBJ 9.0700000000000003
    X3698                R81 1
    X3698                R1215 1
    X3698                R1238 -1
    X3699                OBJ 9.0700000000000003
    X3699                R81 1
    X3699                R1215 -1
    X3699                R1238 1
    X3700                OBJ 5.2199999999999998
    X3700                R83 1
    X3700                R1221 -1
    X3700                R1239 1
    X3701                OBJ 5.2199999999999998
    X3701                R83 1
    X3701                R1221 1
    X3701                R1239 -1
    X3702                OBJ 7.2000000000000002
    X3702                R84 1
    X3702                R1238 -1
    X3702                R1239 1
    X3703                OBJ 7.2000000000000002
    X3703                R84 1
    X3703                R1238 1
    X3703                R1239 -1
    X3704                OBJ 3.27
    X3704                R85 1
    X3704                R1237 -1
    X3704                R1239 1
    X3705                OBJ 3.27
    X3705                R85 1
    X3705                R1237 1
    X3705                R1239 -1
    X3706                OBJ 5.3399999999999999
    X3706                R87 1
    X3706                R1221 1
    X3706                R1240 -1
    X3707                OBJ 5.3399999999999999
    X3707                R87 1
    X3707                R1221 -1
    X3707                R1240 1
    X3708                OBJ 6.3799999999999999
    X3708                R88 1
    X3708                R1210 1
    X3708                R1238 -1
    X3709                OBJ 6.3799999999999999
    X3709                R88 1
    X3709                R1210 -1
    X3709                R1238 1
    X3710                OBJ 6
    X3710                R89 1
    X3710                R1226 1
    X3710                R1233 -1
    X3711                OBJ 6
    X3711                R89 1
    X3711                R1226 -1
    X3711                R1233 1
    X3712                OBJ 3.7599999999999998
    X3712                R90 1
    X3712                R1222 1
    X3712                R1240 -1
    X3713                OBJ 3.7599999999999998
    X3713                R90 1
    X3713                R1222 -1
    X3713                R1240 1
    X3714                OBJ 7.8300000000000001
    X3714                R91 1
    X3714                R1212 -1
    X3714                R1238 1
    X3715                OBJ 7.8300000000000001
    X3715                R91 1
    X3715                R1212 1
    X3715                R1238 -1
    X3716                OBJ 2.1800000000000002
    X3716                R92 1
    X3716                R1233 1
    X3716                R1237 -1
    X3717                OBJ 2.1800000000000002
    X3717                R92 1
    X3717                R1233 -1
    X3717                R1237 1
    X3718                OBJ 4
    X3718                R93 1
    X3718                R1212 -1
    X3718                R1240 1
    X3719                OBJ 4
    X3719                R93 1
    X3719                R1212 1
    X3719                R1240 -1
    X3720                OBJ 2.5899999999999999
    X3720                R2 1
    X3720                R1241 1
    X3720                R1242 -1
    X3721                OBJ 2.5899999999999999
    X3721                R2 1
    X3721                R1241 -1
    X3721                R1242 1
    X3722                OBJ 10.67
    X3722                R4 1
    X3722                R1241 1
    X3722                R1243 -1
    X3723                OBJ 10.67
    X3723                R4 1
    X3723                R1241 -1
    X3723                R1243 1
    X3724                OBJ 5.5199999999999996
    X3724                R6 1
    X3724                R1241 1
    X3724                R1244 -1
    X3725                OBJ 5.5199999999999996
    X3725                R6 1
    X3725                R1241 -1
    X3725                R1244 1
    X3726                OBJ 5.4000000000000004
    X3726                R8 1
    X3726                R1241 1
    X3726                R1245 -1
    X3727                OBJ 5.4000000000000004
    X3727                R8 1
    X3727                R1241 -1
    X3727                R1245 1
    X3728                OBJ 13.630000000000001
    X3728                R11 1
    X3728                R1246 1
    X3728                R1247 -1
    X3729                OBJ 13.630000000000001
    X3729                R11 1
    X3729                R1246 -1
    X3729                R1247 1
    X3730                OBJ 7.9400000000000004
    X3730                R13 1
    X3730                R1246 1
    X3730                R1248 -1
    X3731                OBJ 7.9400000000000004
    X3731                R13 1
    X3731                R1246 -1
    X3731                R1248 1
    X3732                OBJ 15
    X3732                R15 1
    X3732                R1246 1
    X3732                R1249 -1
    X3733                OBJ 15
    X3733                R15 1
    X3733                R1246 -1
    X3733                R1249 1
    X3734                OBJ 7.5999999999999996
    X3734                R18 1
    X3734                R1250 1
    X3734                R1251 -1
    X3735                OBJ 7.5999999999999996
    X3735                R18 1
    X3735                R1250 -1
    X3735                R1251 1
    X3736                OBJ 5.0800000000000001
    X3736                R20 1
    X3736                R1250 1
    X3736                R1252 -1
    X3737                OBJ 5.0800000000000001
    X3737                R20 1
    X3737                R1250 -1
    X3737                R1252 1
    X3738                OBJ 12.44
    X3738                R22 1
    X3738                R1250 1
    X3738                R1253 -1
    X3739                OBJ 12.44
    X3739                R22 1
    X3739                R1250 -1
    X3739                R1253 1
    X3740                OBJ 4.7400000000000002
    X3740                R25 1
    X3740                R1254 1
    X3740                R1255 -1
    X3741                OBJ 4.7400000000000002
    X3741                R25 1
    X3741                R1254 -1
    X3741                R1255 1
    X3742                OBJ 4.8700000000000001
    X3742                R26 1
    X3742                R1248 -1
    X3742                R1254 1
    X3743                OBJ 4.8700000000000001
    X3743                R26 1
    X3743                R1248 1
    X3743                R1254 -1
    X3744                OBJ 5.5099999999999998
    X3744                R27 1
    X3744                R1249 -1
    X3744                R1254 1
    X3745                OBJ 5.5099999999999998
    X3745                R27 1
    X3745                R1249 1
    X3745                R1254 -1
    X3746                OBJ 5.4000000000000004
    X3746                R30 1
    X3746                R1256 1
    X3746                R1257 -1
    X3747                OBJ 5.4000000000000004
    X3747                R30 1
    X3747                R1256 -1
    X3747                R1257 1
    X3748                OBJ 3.8100000000000001
    X3748                R31 1
    X3748                R1244 -1
    X3748                R1256 1
    X3749                OBJ 3.8100000000000001
    X3749                R31 1
    X3749                R1244 1
    X3749                R1256 -1
    X3750                OBJ 7.5700000000000003
    X3750                R33 1
    X3750                R1256 1
    X3750                R1258 -1
    X3751                OBJ 7.5700000000000003
    X3751                R33 1
    X3751                R1256 -1
    X3751                R1258 1
    X3752                OBJ 4.2000000000000002
    X3752                R35 1
    X3752                R1256 1
    X3752                R1259 -1
    X3753                OBJ 4.2000000000000002
    X3753                R35 1
    X3753                R1256 -1
    X3753                R1259 1
    X3754                OBJ 7.75
    X3754                R37 1
    X3754                R1256 1
    X3754                R1260 -1
    X3755                OBJ 7.75
    X3755                R37 1
    X3755                R1256 -1
    X3755                R1260 1
    X3756                OBJ 6.0999999999999996
    X3756                R39 1
    X3756                R1243 -1
    X3756                R1261 1
    X3757                OBJ 6.0999999999999996
    X3757                R39 1
    X3757                R1243 1
    X3757                R1261 -1
    X3758                OBJ 2.3900000000000001
    X3758                R40 1
    X3758                R1245 -1
    X3758                R1261 1
    X3759                OBJ 2.3900000000000001
    X3759                R40 1
    X3759                R1245 1
    X3759                R1261 -1
    X3760                OBJ 8.3399999999999999
    X3760                R42 1
    X3760                R1251 -1
    X3760                R1262 1
    X3761                OBJ 8.3399999999999999
    X3761                R42 1
    X3761                R1251 1
    X3761                R1262 -1
    X3762                OBJ 7.5599999999999996
    X3762                R43 1
    X3762                R1252 -1
    X3762                R1262 1
    X3763                OBJ 7.5599999999999996
    X3763                R43 1
    X3763                R1252 1
    X3763                R1262 -1
    X3764                OBJ 7.4699999999999998
    X3764                R45 1
    X3764                R1262 1
    X3764                R1263 -1
    X3765                OBJ 7.4699999999999998
    X3765                R45 1
    X3765                R1262 -1
    X3765                R1263 1
    X3766                OBJ 2.6400000000000001
    X3766                R47 1
    X3766                R1242 1
    X3766                R1264 -1
    X3767                OBJ 2.6400000000000001
    X3767                R47 1
    X3767                R1242 -1
    X3767                R1264 1
    X3768                OBJ 3.9300000000000002
    X3768                R48 1
    X3768                R1242 1
    X3768                R1263 -1
    X3769                OBJ 3.9300000000000002
    X3769                R48 1
    X3769                R1242 -1
    X3769                R1263 1
    X3770                OBJ 4.3600000000000003
    X3770                R50 1
    X3770                R1255 1
    X3770                R1265 -1
    X3771                OBJ 4.3600000000000003
    X3771                R50 1
    X3771                R1255 -1
    X3771                R1265 1
    X3772                OBJ 6.6799999999999997
    X3772                R51 1
    X3772                R1255 1
    X3772                R1259 -1
    X3773                OBJ 6.6799999999999997
    X3773                R51 1
    X3773                R1255 -1
    X3773                R1259 1
    X3774                OBJ 7.2199999999999998
    X3774                R53 1
    X3774                R1257 1
    X3774                R1266 -1
    X3775                OBJ 7.2199999999999998
    X3775                R53 1
    X3775                R1257 -1
    X3775                R1266 1
    X3776                OBJ 7.7699999999999996
    X3776                R55 1
    X3776                R1257 1
    X3776                R1267 -1
    X3777                OBJ 7.7699999999999996
    X3777                R55 1
    X3777                R1257 -1
    X3777                R1267 1
    X3778                OBJ 4.6200000000000001
    X3778                R57 1
    X3778                R1243 -1
    X3778                R1268 1
    X3779                OBJ 4.6200000000000001
    X3779                R57 1
    X3779                R1243 1
    X3779                R1268 -1
    X3780                OBJ 6.9000000000000004
    X3780                R58 1
    X3780                R1245 -1
    X3780                R1268 1
    X3781                OBJ 6.9000000000000004
    X3781                R58 1
    X3781                R1245 1
    X3781                R1268 -1
    X3782                OBJ 2.75
    X3782                R60 1
    X3782                R1264 1
    X3782                R1269 -1
    X3783                OBJ 2.75
    X3783                R60 1
    X3783                R1264 -1
    X3783                R1269 1
    X3784                OBJ 5.9199999999999999
    X3784                R61 1
    X3784                R1244 -1
    X3784                R1269 1
    X3785                OBJ 5.9199999999999999
    X3785                R61 1
    X3785                R1244 1
    X3785                R1269 -1
    X3786                OBJ 4.5599999999999996
    X3786                R62 1
    X3786                R1258 -1
    X3786                R1269 1
    X3787                OBJ 4.5599999999999996
    X3787                R62 1
    X3787                R1258 1
    X3787                R1269 -1
    X3788                OBJ 2.71
    X3788                R64 1
    X3788                R1269 1
    X3788                R1270 -1
    X3789                OBJ 2.71
    X3789                R64 1
    X3789                R1269 -1
    X3789                R1270 1
    X3790                OBJ 11.82
    X3790                R66 1
    X3790                R1266 -1
    X3790                R1271 1
    X3791                OBJ 11.82
    X3791                R66 1
    X3791                R1266 1
    X3791                R1271 -1
    X3792                OBJ 5.9699999999999998
    X3792                R67 1
    X3792                R1267 -1
    X3792                R1271 1
    X3793                OBJ 5.9699999999999998
    X3793                R67 1
    X3793                R1267 1
    X3793                R1271 -1
    X3794                OBJ 13.699999999999999
    X3794                R68 1
    X3794                R1260 -1
    X3794                R1271 1
    X3795                OBJ 13.699999999999999
    X3795                R68 1
    X3795                R1260 1
    X3795                R1271 -1
    X3796                OBJ 3.8300000000000001
    X3796                R69 1
    X3796                R1260 -1
    X3796                R1265 1
    X3797                OBJ 3.8300000000000001
    X3797                R69 1
    X3797                R1260 1
    X3797                R1265 -1
    X3798                OBJ 19.77
    X3798                R71 1
    X3798                R1245 -1
    X3798                R1272 1
    X3799                OBJ 19.77
    X3799                R71 1
    X3799                R1245 1
    X3799                R1272 -1
    X3800                OBJ 7.5099999999999998
    X3800                R72 1
    X3800                R1251 -1
    X3800                R1272 1
    X3801                OBJ 7.5099999999999998
    X3801                R72 1
    X3801                R1251 1
    X3801                R1272 -1
    X3802                OBJ 4.71
    X3802                R73 1
    X3802                R1253 -1
    X3802                R1272 1
    X3803                OBJ 4.71
    X3803                R73 1
    X3803                R1253 1
    X3803                R1272 -1
    X3804                OBJ 5.1399999999999997
    X3804                R74 1
    X3804                R1245 1
    X3804                R1263 -1
    X3805                OBJ 5.1399999999999997
    X3805                R74 1
    X3805                R1245 -1
    X3805                R1263 1
    X3806                OBJ 4.1100000000000003
    X3806                R76 1
    X3806                R1252 -1
    X3806                R1273 1
    X3807                OBJ 4.1100000000000003
    X3807                R76 1
    X3807                R1252 1
    X3807                R1273 -1
    X3808                OBJ 5.9400000000000004
    X3808                R77 1
    X3808                R1263 -1
    X3808                R1273 1
    X3809                OBJ 5.9400000000000004
    X3809                R77 1
    X3809                R1263 1
    X3809                R1273 -1
    X3810                OBJ 5.0700000000000003
    X3810                R79 1
    X3810                R1273 1
    X3810                R1274 -1
    X3811                OBJ 5.0700000000000003
    X3811                R79 1
    X3811                R1273 -1
    X3811                R1274 1
    X3812                OBJ 9.0700000000000003
    X3812                R81 1
    X3812                R1252 1
    X3812                R1275 -1
    X3813                OBJ 9.0700000000000003
    X3813                R81 1
    X3813                R1252 -1
    X3813                R1275 1
    X3814                OBJ 5.2199999999999998
    X3814                R83 1
    X3814                R1258 -1
    X3814                R1276 1
    X3815                OBJ 5.2199999999999998
    X3815                R83 1
    X3815                R1258 1
    X3815                R1276 -1
    X3816                OBJ 7.2000000000000002
    X3816                R84 1
    X3816                R1275 -1
    X3816                R1276 1
    X3817                OBJ 7.2000000000000002
    X3817                R84 1
    X3817                R1275 1
    X3817                R1276 -1
    X3818                OBJ 3.27
    X3818                R85 1
    X3818                R1274 -1
    X3818                R1276 1
    X3819                OBJ 3.27
    X3819                R85 1
    X3819                R1274 1
    X3819                R1276 -1
    X3820                OBJ 5.3399999999999999
    X3820                R87 1
    X3820                R1258 -1
    X3820                R1277 1
    X3821                OBJ 6.3799999999999999
    X3821                R88 1
    X3821                R1247 1
    X3821                R1275 -1
    X3822                OBJ 6.3799999999999999
    X3822                R88 1
    X3822                R1247 -1
    X3822                R1275 1
    X3823                OBJ 6
    X3823                R89 1
    X3823                R1263 1
    X3823                R1270 -1
    X3824                OBJ 6
    X3824                R89 1
    X3824                R1263 -1
    X3824                R1270 1
    X3825                OBJ 3.7599999999999998
    X3825                R90 1
    X3825                R1259 -1
    X3825                R1277 1
    X3826                OBJ 7.8300000000000001
    X3826                R91 1
    X3826                R1249 -1
    X3826                R1275 1
    X3827                OBJ 7.8300000000000001
    X3827                R91 1
    X3827                R1249 1
    X3827                R1275 -1
    X3828                OBJ 2.1800000000000002
    X3828                R92 1
    X3828                R1270 1
    X3828                R1274 -1
    X3829                OBJ 2.1800000000000002
    X3829                R92 1
    X3829                R1270 -1
    X3829                R1274 1
    X3830                OBJ 4
    X3830                R93 1
    X3830                R1249 -1
    X3830                R1277 1
    X3831                OBJ 2.5899999999999999
    X3831                R2 1
    X3831                R1278 1
    X3831                R1279 -1
    X3832                OBJ 2.5899999999999999
    X3832                R2 1
    X3832                R1278 -1
    X3832                R1279 1
    X3833                OBJ 10.67
    X3833                R4 1
    X3833                R1278 1
    X3833                R1280 -1
    X3834                OBJ 10.67
    X3834                R4 1
    X3834                R1278 -1
    X3834                R1280 1
    X3835                OBJ 5.5199999999999996
    X3835                R6 1
    X3835                R1278 1
    X3835                R1281 -1
    X3836                OBJ 5.5199999999999996
    X3836                R6 1
    X3836                R1278 -1
    X3836                R1281 1
    X3837                OBJ 5.4000000000000004
    X3837                R8 1
    X3837                R1278 1
    X3837                R1282 -1
    X3838                OBJ 5.4000000000000004
    X3838                R8 1
    X3838                R1278 -1
    X3838                R1282 1
    X3839                OBJ 13.630000000000001
    X3839                R11 1
    X3839                R1283 1
    X3839                R1284 -1
    X3840                OBJ 13.630000000000001
    X3840                R11 1
    X3840                R1283 -1
    X3840                R1284 1
    X3841                OBJ 7.9400000000000004
    X3841                R13 1
    X3841                R1283 -1
    X3841                R1285 1
    X3842                OBJ 15
    X3842                R15 1
    X3842                R1283 1
    X3842                R1286 -1
    X3843                OBJ 15
    X3843                R15 1
    X3843                R1283 -1
    X3843                R1286 1
    X3844                OBJ 7.5999999999999996
    X3844                R18 1
    X3844                R1287 1
    X3844                R1288 -1
    X3845                OBJ 7.5999999999999996
    X3845                R18 1
    X3845                R1287 -1
    X3845                R1288 1
    X3846                OBJ 5.0800000000000001
    X3846                R20 1
    X3846                R1287 1
    X3846                R1289 -1
    X3847                OBJ 5.0800000000000001
    X3847                R20 1
    X3847                R1287 -1
    X3847                R1289 1
    X3848                OBJ 12.44
    X3848                R22 1
    X3848                R1287 1
    X3848                R1290 -1
    X3849                OBJ 12.44
    X3849                R22 1
    X3849                R1287 -1
    X3849                R1290 1
    X3850                OBJ 4.7400000000000002
    X3850                R25 1
    X3850                R1291 1
    X3850                R1292 -1
    X3851                OBJ 4.7400000000000002
    X3851                R25 1
    X3851                R1291 -1
    X3851                R1292 1
    X3852                OBJ 4.8700000000000001
    X3852                R26 1
    X3852                R1285 1
    X3852                R1291 -1
    X3853                OBJ 5.5099999999999998
    X3853                R27 1
    X3853                R1286 -1
    X3853                R1291 1
    X3854                OBJ 5.5099999999999998
    X3854                R27 1
    X3854                R1286 1
    X3854                R1291 -1
    X3855                OBJ 5.4000000000000004
    X3855                R30 1
    X3855                R1293 1
    X3855                R1294 -1
    X3856                OBJ 5.4000000000000004
    X3856                R30 1
    X3856                R1293 -1
    X3856                R1294 1
    X3857                OBJ 3.8100000000000001
    X3857                R31 1
    X3857                R1281 -1
    X3857                R1293 1
    X3858                OBJ 3.8100000000000001
    X3858                R31 1
    X3858                R1281 1
    X3858                R1293 -1
    X3859                OBJ 7.5700000000000003
    X3859                R33 1
    X3859                R1293 1
    X3859                R1295 -1
    X3860                OBJ 7.5700000000000003
    X3860                R33 1
    X3860                R1293 -1
    X3860                R1295 1
    X3861                OBJ 4.2000000000000002
    X3861                R35 1
    X3861                R1293 1
    X3861                R1296 -1
    X3862                OBJ 4.2000000000000002
    X3862                R35 1
    X3862                R1293 -1
    X3862                R1296 1
    X3863                OBJ 7.75
    X3863                R37 1
    X3863                R1293 1
    X3863                R1297 -1
    X3864                OBJ 7.75
    X3864                R37 1
    X3864                R1293 -1
    X3864                R1297 1
    X3865                OBJ 6.0999999999999996
    X3865                R39 1
    X3865                R1280 -1
    X3865                R1298 1
    X3866                OBJ 6.0999999999999996
    X3866                R39 1
    X3866                R1280 1
    X3866                R1298 -1
    X3867                OBJ 2.3900000000000001
    X3867                R40 1
    X3867                R1282 -1
    X3867                R1298 1
    X3868                OBJ 2.3900000000000001
    X3868                R40 1
    X3868                R1282 1
    X3868                R1298 -1
    X3869                OBJ 8.3399999999999999
    X3869                R42 1
    X3869                R1288 -1
    X3869                R1299 1
    X3870                OBJ 8.3399999999999999
    X3870                R42 1
    X3870                R1288 1
    X3870                R1299 -1
    X3871                OBJ 7.5599999999999996
    X3871                R43 1
    X3871                R1289 -1
    X3871                R1299 1
    X3872                OBJ 7.5599999999999996
    X3872                R43 1
    X3872                R1289 1
    X3872                R1299 -1
    X3873                OBJ 7.4699999999999998
    X3873                R45 1
    X3873                R1299 1
    X3873                R1300 -1
    X3874                OBJ 7.4699999999999998
    X3874                R45 1
    X3874                R1299 -1
    X3874                R1300 1
    X3875                OBJ 2.6400000000000001
    X3875                R47 1
    X3875                R1279 1
    X3875                R1301 -1
    X3876                OBJ 2.6400000000000001
    X3876                R47 1
    X3876                R1279 -1
    X3876                R1301 1
    X3877                OBJ 3.9300000000000002
    X3877                R48 1
    X3877                R1279 1
    X3877                R1300 -1
    X3878                OBJ 3.9300000000000002
    X3878                R48 1
    X3878                R1279 -1
    X3878                R1300 1
    X3879                OBJ 4.3600000000000003
    X3879                R50 1
    X3879                R1292 1
    X3879                R1302 -1
    X3880                OBJ 4.3600000000000003
    X3880                R50 1
    X3880                R1292 -1
    X3880                R1302 1
    X3881                OBJ 6.6799999999999997
    X3881                R51 1
    X3881                R1292 1
    X3881                R1296 -1
    X3882                OBJ 6.6799999999999997
    X3882                R51 1
    X3882                R1292 -1
    X3882                R1296 1
    X3883                OBJ 7.2199999999999998
    X3883                R53 1
    X3883                R1294 1
    X3883                R1303 -1
    X3884                OBJ 7.2199999999999998
    X3884                R53 1
    X3884                R1294 -1
    X3884                R1303 1
    X3885                OBJ 7.7699999999999996
    X3885                R55 1
    X3885                R1294 1
    X3885                R1304 -1
    X3886                OBJ 7.7699999999999996
    X3886                R55 1
    X3886                R1294 -1
    X3886                R1304 1
    X3887                OBJ 4.6200000000000001
    X3887                R57 1
    X3887                R1280 -1
    X3887                R1305 1
    X3888                OBJ 4.6200000000000001
    X3888                R57 1
    X3888                R1280 1
    X3888                R1305 -1
    X3889                OBJ 6.9000000000000004
    X3889                R58 1
    X3889                R1282 -1
    X3889                R1305 1
    X3890                OBJ 6.9000000000000004
    X3890                R58 1
    X3890                R1282 1
    X3890                R1305 -1
    X3891                OBJ 2.75
    X3891                R60 1
    X3891                R1301 1
    X3891                R1306 -1
    X3892                OBJ 2.75
    X3892                R60 1
    X3892                R1301 -1
    X3892                R1306 1
    X3893                OBJ 5.9199999999999999
    X3893                R61 1
    X3893                R1281 -1
    X3893                R1306 1
    X3894                OBJ 5.9199999999999999
    X3894                R61 1
    X3894                R1281 1
    X3894                R1306 -1
    X3895                OBJ 4.5599999999999996
    X3895                R62 1
    X3895                R1295 -1
    X3895                R1306 1
    X3896                OBJ 4.5599999999999996
    X3896                R62 1
    X3896                R1295 1
    X3896                R1306 -1
    X3897                OBJ 2.71
    X3897                R64 1
    X3897                R1306 1
    X3897                R1307 -1
    X3898                OBJ 2.71
    X3898                R64 1
    X3898                R1306 -1
    X3898                R1307 1
    X3899                OBJ 11.82
    X3899                R66 1
    X3899                R1303 -1
    X3899                R1308 1
    X3900                OBJ 11.82
    X3900                R66 1
    X3900                R1303 1
    X3900                R1308 -1
    X3901                OBJ 5.9699999999999998
    X3901                R67 1
    X3901                R1304 -1
    X3901                R1308 1
    X3902                OBJ 5.9699999999999998
    X3902                R67 1
    X3902                R1304 1
    X3902                R1308 -1
    X3903                OBJ 13.699999999999999
    X3903                R68 1
    X3903                R1297 -1
    X3903                R1308 1
    X3904                OBJ 13.699999999999999
    X3904                R68 1
    X3904                R1297 1
    X3904                R1308 -1
    X3905                OBJ 3.8300000000000001
    X3905                R69 1
    X3905                R1297 -1
    X3905                R1302 1
    X3906                OBJ 3.8300000000000001
    X3906                R69 1
    X3906                R1297 1
    X3906                R1302 -1
    X3907                OBJ 19.77
    X3907                R71 1
    X3907                R1282 -1
    X3907                R1309 1
    X3908                OBJ 19.77
    X3908                R71 1
    X3908                R1282 1
    X3908                R1309 -1
    X3909                OBJ 7.5099999999999998
    X3909                R72 1
    X3909                R1288 -1
    X3909                R1309 1
    X3910                OBJ 7.5099999999999998
    X3910                R72 1
    X3910                R1288 1
    X3910                R1309 -1
    X3911                OBJ 4.71
    X3911                R73 1
    X3911                R1290 -1
    X3911                R1309 1
    X3912                OBJ 4.71
    X3912                R73 1
    X3912                R1290 1
    X3912                R1309 -1
    X3913                OBJ 5.1399999999999997
    X3913                R74 1
    X3913                R1282 1
    X3913                R1300 -1
    X3914                OBJ 5.1399999999999997
    X3914                R74 1
    X3914                R1282 -1
    X3914                R1300 1
    X3915                OBJ 4.1100000000000003
    X3915                R76 1
    X3915                R1289 -1
    X3915                R1310 1
    X3916                OBJ 4.1100000000000003
    X3916                R76 1
    X3916                R1289 1
    X3916                R1310 -1
    X3917                OBJ 5.9400000000000004
    X3917                R77 1
    X3917                R1300 -1
    X3917                R1310 1
    X3918                OBJ 5.9400000000000004
    X3918                R77 1
    X3918                R1300 1
    X3918                R1310 -1
    X3919                OBJ 5.0700000000000003
    X3919                R79 1
    X3919                R1310 1
    X3919                R1311 -1
    X3920                OBJ 5.0700000000000003
    X3920                R79 1
    X3920                R1310 -1
    X3920                R1311 1
    X3921                OBJ 9.0700000000000003
    X3921                R81 1
    X3921                R1289 1
    X3921                R1312 -1
    X3922                OBJ 9.0700000000000003
    X3922                R81 1
    X3922                R1289 -1
    X3922                R1312 1
    X3923                OBJ 5.2199999999999998
    X3923                R83 1
    X3923                R1295 -1
    X3923                R1313 1
    X3924                OBJ 5.2199999999999998
    X3924                R83 1
    X3924                R1295 1
    X3924                R1313 -1
    X3925                OBJ 7.2000000000000002
    X3925                R84 1
    X3925                R1312 -1
    X3925                R1313 1
    X3926                OBJ 7.2000000000000002
    X3926                R84 1
    X3926                R1312 1
    X3926                R1313 -1
    X3927                OBJ 3.27
    X3927                R85 1
    X3927                R1311 -1
    X3927                R1313 1
    X3928                OBJ 3.27
    X3928                R85 1
    X3928                R1311 1
    X3928                R1313 -1
    X3929                OBJ 5.3399999999999999
    X3929                R87 1
    X3929                R1295 1
    X3929                R1314 -1
    X3930                OBJ 5.3399999999999999
    X3930                R87 1
    X3930                R1295 -1
    X3930                R1314 1
    X3931                OBJ 6.3799999999999999
    X3931                R88 1
    X3931                R1284 1
    X3931                R1312 -1
    X3932                OBJ 6.3799999999999999
    X3932                R88 1
    X3932                R1284 -1
    X3932                R1312 1
    X3933                OBJ 6
    X3933                R89 1
    X3933                R1300 1
    X3933                R1307 -1
    X3934                OBJ 6
    X3934                R89 1
    X3934                R1300 -1
    X3934                R1307 1
    X3935                OBJ 3.7599999999999998
    X3935                R90 1
    X3935                R1296 1
    X3935                R1314 -1
    X3936                OBJ 3.7599999999999998
    X3936                R90 1
    X3936                R1296 -1
    X3936                R1314 1
    X3937                OBJ 7.8300000000000001
    X3937                R91 1
    X3937                R1286 -1
    X3937                R1312 1
    X3938                OBJ 7.8300000000000001
    X3938                R91 1
    X3938                R1286 1
    X3938                R1312 -1
    X3939                OBJ 2.1800000000000002
    X3939                R92 1
    X3939                R1307 1
    X3939                R1311 -1
    X3940                OBJ 2.1800000000000002
    X3940                R92 1
    X3940                R1307 -1
    X3940                R1311 1
    X3941                OBJ 4
    X3941                R93 1
    X3941                R1286 -1
    X3941                R1314 1
    X3942                OBJ 4
    X3942                R93 1
    X3942                R1286 1
    X3942                R1314 -1
    X3943                OBJ 2.5899999999999999
    X3943                R2 1
    X3943                R1315 1
    X3943                R1316 -1
    X3944                OBJ 2.5899999999999999
    X3944                R2 1
    X3944                R1315 -1
    X3944                R1316 1
    X3945                OBJ 10.67
    X3945                R4 1
    X3945                R1315 1
    X3945                R1317 -1
    X3946                OBJ 10.67
    X3946                R4 1
    X3946                R1315 -1
    X3946                R1317 1
    X3947                OBJ 5.5199999999999996
    X3947                R6 1
    X3947                R1315 1
    X3947                R1318 -1
    X3948                OBJ 5.5199999999999996
    X3948                R6 1
    X3948                R1315 -1
    X3948                R1318 1
    X3949                OBJ 5.4000000000000004
    X3949                R8 1
    X3949                R1315 1
    X3949                R1319 -1
    X3950                OBJ 5.4000000000000004
    X3950                R8 1
    X3950                R1315 -1
    X3950                R1319 1
    X3951                OBJ 13.630000000000001
    X3951                R11 1
    X3951                R1320 1
    X3951                R1321 -1
    X3952                OBJ 13.630000000000001
    X3952                R11 1
    X3952                R1320 -1
    X3952                R1321 1
    X3953                OBJ 7.9400000000000004
    X3953                R13 1
    X3953                R1320 1
    X3953                R1322 -1
    X3954                OBJ 7.9400000000000004
    X3954                R13 1
    X3954                R1320 -1
    X3954                R1322 1
    X3955                OBJ 15
    X3955                R15 1
    X3955                R1320 1
    X3955                R1323 -1
    X3956                OBJ 15
    X3956                R15 1
    X3956                R1320 -1
    X3956                R1323 1
    X3957                OBJ 7.5999999999999996
    X3957                R18 1
    X3957                R1324 1
    X3957                R1325 -1
    X3958                OBJ 7.5999999999999996
    X3958                R18 1
    X3958                R1324 -1
    X3958                R1325 1
    X3959                OBJ 5.0800000000000001
    X3959                R20 1
    X3959                R1324 1
    X3959                R1326 -1
    X3960                OBJ 5.0800000000000001
    X3960                R20 1
    X3960                R1324 -1
    X3960                R1326 1
    X3961                OBJ 12.44
    X3961                R22 1
    X3961                R1324 1
    X3961                R1327 -1
    X3962                OBJ 12.44
    X3962                R22 1
    X3962                R1324 -1
    X3962                R1327 1
    X3963                OBJ 4.7400000000000002
    X3963                R25 1
    X3963                R1328 1
    X3963                R1329 -1
    X3964                OBJ 4.7400000000000002
    X3964                R25 1
    X3964                R1328 -1
    X3964                R1329 1
    X3965                OBJ 4.8700000000000001
    X3965                R26 1
    X3965                R1322 -1
    X3965                R1328 1
    X3966                OBJ 4.8700000000000001
    X3966                R26 1
    X3966                R1322 1
    X3966                R1328 -1
    X3967                OBJ 5.5099999999999998
    X3967                R27 1
    X3967                R1323 -1
    X3967                R1328 1
    X3968                OBJ 5.5099999999999998
    X3968                R27 1
    X3968                R1323 1
    X3968                R1328 -1
    X3969                OBJ 5.4000000000000004
    X3969                R30 1
    X3969                R1330 1
    X3969                R1331 -1
    X3970                OBJ 5.4000000000000004
    X3970                R30 1
    X3970                R1330 -1
    X3970                R1331 1
    X3971                OBJ 3.8100000000000001
    X3971                R31 1
    X3971                R1318 -1
    X3971                R1330 1
    X3972                OBJ 3.8100000000000001
    X3972                R31 1
    X3972                R1318 1
    X3972                R1330 -1
    X3973                OBJ 7.5700000000000003
    X3973                R33 1
    X3973                R1330 1
    X3973                R1332 -1
    X3974                OBJ 7.5700000000000003
    X3974                R33 1
    X3974                R1330 -1
    X3974                R1332 1
    X3975                OBJ 4.2000000000000002
    X3975                R35 1
    X3975                R1330 1
    X3975                R1333 -1
    X3976                OBJ 4.2000000000000002
    X3976                R35 1
    X3976                R1330 -1
    X3976                R1333 1
    X3977                OBJ 7.75
    X3977                R37 1
    X3977                R1330 -1
    X3977                R1334 1
    X3978                OBJ 6.0999999999999996
    X3978                R39 1
    X3978                R1317 -1
    X3978                R1335 1
    X3979                OBJ 6.0999999999999996
    X3979                R39 1
    X3979                R1317 1
    X3979                R1335 -1
    X3980                OBJ 2.3900000000000001
    X3980                R40 1
    X3980                R1319 -1
    X3980                R1335 1
    X3981                OBJ 2.3900000000000001
    X3981                R40 1
    X3981                R1319 1
    X3981                R1335 -1
    X3982                OBJ 8.3399999999999999
    X3982                R42 1
    X3982                R1325 -1
    X3982                R1336 1
    X3983                OBJ 8.3399999999999999
    X3983                R42 1
    X3983                R1325 1
    X3983                R1336 -1
    X3984                OBJ 7.5599999999999996
    X3984                R43 1
    X3984                R1326 -1
    X3984                R1336 1
    X3985                OBJ 7.5599999999999996
    X3985                R43 1
    X3985                R1326 1
    X3985                R1336 -1
    X3986                OBJ 7.4699999999999998
    X3986                R45 1
    X3986                R1336 1
    X3986                R1337 -1
    X3987                OBJ 7.4699999999999998
    X3987                R45 1
    X3987                R1336 -1
    X3987                R1337 1
    X3988                OBJ 2.6400000000000001
    X3988                R47 1
    X3988                R1316 1
    X3988                R1338 -1
    X3989                OBJ 2.6400000000000001
    X3989                R47 1
    X3989                R1316 -1
    X3989                R1338 1
    X3990                OBJ 3.9300000000000002
    X3990                R48 1
    X3990                R1316 1
    X3990                R1337 -1
    X3991                OBJ 3.9300000000000002
    X3991                R48 1
    X3991                R1316 -1
    X3991                R1337 1
    X3992                OBJ 4.3600000000000003
    X3992                R50 1
    X3992                R1329 1
    X3992                R1339 -1
    X3993                OBJ 4.3600000000000003
    X3993                R50 1
    X3993                R1329 -1
    X3993                R1339 1
    X3994                OBJ 6.6799999999999997
    X3994                R51 1
    X3994                R1329 1
    X3994                R1333 -1
    X3995                OBJ 6.6799999999999997
    X3995                R51 1
    X3995                R1329 -1
    X3995                R1333 1
    X3996                OBJ 7.2199999999999998
    X3996                R53 1
    X3996                R1331 1
    X3996                R1340 -1
    X3997                OBJ 7.2199999999999998
    X3997                R53 1
    X3997                R1331 -1
    X3997                R1340 1
    X3998                OBJ 7.7699999999999996
    X3998                R55 1
    X3998                R1331 1
    X3998                R1341 -1
    X3999                OBJ 7.7699999999999996
    X3999                R55 1
    X3999                R1331 -1
    X3999                R1341 1
    X4000                OBJ 4.6200000000000001
    X4000                R57 1
    X4000                R1317 -1
    X4000                R1342 1
    X4001                OBJ 4.6200000000000001
    X4001                R57 1
    X4001                R1317 1
    X4001                R1342 -1
    X4002                OBJ 6.9000000000000004
    X4002                R58 1
    X4002                R1319 -1
    X4002                R1342 1
    X4003                OBJ 6.9000000000000004
    X4003                R58 1
    X4003                R1319 1
    X4003                R1342 -1
    X4004                OBJ 2.75
    X4004                R60 1
    X4004                R1338 1
    X4004                R1343 -1
    X4005                OBJ 2.75
    X4005                R60 1
    X4005                R1338 -1
    X4005                R1343 1
    X4006                OBJ 5.9199999999999999
    X4006                R61 1
    X4006                R1318 -1
    X4006                R1343 1
    X4007                OBJ 5.9199999999999999
    X4007                R61 1
    X4007                R1318 1
    X4007                R1343 -1
    X4008                OBJ 4.5599999999999996
    X4008                R62 1
    X4008                R1332 -1
    X4008                R1343 1
    X4009                OBJ 4.5599999999999996
    X4009                R62 1
    X4009                R1332 1
    X4009                R1343 -1
    X4010                OBJ 2.71
    X4010                R64 1
    X4010                R1343 1
    X4010                R1344 -1
    X4011                OBJ 2.71
    X4011                R64 1
    X4011                R1343 -1
    X4011                R1344 1
    X4012                OBJ 11.82
    X4012                R66 1
    X4012                R1340 -1
    X4012                R1345 1
    X4013                OBJ 11.82
    X4013                R66 1
    X4013                R1340 1
    X4013                R1345 -1
    X4014                OBJ 5.9699999999999998
    X4014                R67 1
    X4014                R1341 -1
    X4014                R1345 1
    X4015                OBJ 5.9699999999999998
    X4015                R67 1
    X4015                R1341 1
    X4015                R1345 -1
    X4016                OBJ 13.699999999999999
    X4016                R68 1
    X4016                R1334 1
    X4016                R1345 -1
    X4017                OBJ 3.8300000000000001
    X4017                R69 1
    X4017                R1334 1
    X4017                R1339 -1
    X4018                OBJ 19.77
    X4018                R71 1
    X4018                R1319 -1
    X4018                R1346 1
    X4019                OBJ 19.77
    X4019                R71 1
    X4019                R1319 1
    X4019                R1346 -1
    X4020                OBJ 7.5099999999999998
    X4020                R72 1
    X4020                R1325 -1
    X4020                R1346 1
    X4021                OBJ 7.5099999999999998
    X4021                R72 1
    X4021                R1325 1
    X4021                R1346 -1
    X4022                OBJ 4.71
    X4022                R73 1
    X4022                R1327 -1
    X4022                R1346 1
    X4023                OBJ 4.71
    X4023                R73 1
    X4023                R1327 1
    X4023                R1346 -1
    X4024                OBJ 5.1399999999999997
    X4024                R74 1
    X4024                R1319 1
    X4024                R1337 -1
    X4025                OBJ 5.1399999999999997
    X4025                R74 1
    X4025                R1319 -1
    X4025                R1337 1
    X4026                OBJ 4.1100000000000003
    X4026                R76 1
    X4026                R1326 -1
    X4026                R1347 1
    X4027                OBJ 4.1100000000000003
    X4027                R76 1
    X4027                R1326 1
    X4027                R1347 -1
    X4028                OBJ 5.9400000000000004
    X4028                R77 1
    X4028                R1337 -1
    X4028                R1347 1
    X4029                OBJ 5.9400000000000004
    X4029                R77 1
    X4029                R1337 1
    X4029                R1347 -1
    X4030                OBJ 5.0700000000000003
    X4030                R79 1
    X4030                R1347 1
    X4030                R1348 -1
    X4031                OBJ 5.0700000000000003
    X4031                R79 1
    X4031                R1347 -1
    X4031                R1348 1
    X4032                OBJ 9.0700000000000003
    X4032                R81 1
    X4032                R1326 1
    X4032                R1349 -1
    X4033                OBJ 9.0700000000000003
    X4033                R81 1
    X4033                R1326 -1
    X4033                R1349 1
    X4034                OBJ 5.2199999999999998
    X4034                R83 1
    X4034                R1332 -1
    X4034                R1350 1
    X4035                OBJ 5.2199999999999998
    X4035                R83 1
    X4035                R1332 1
    X4035                R1350 -1
    X4036                OBJ 7.2000000000000002
    X4036                R84 1
    X4036                R1349 -1
    X4036                R1350 1
    X4037                OBJ 7.2000000000000002
    X4037                R84 1
    X4037                R1349 1
    X4037                R1350 -1
    X4038                OBJ 3.27
    X4038                R85 1
    X4038                R1348 -1
    X4038                R1350 1
    X4039                OBJ 3.27
    X4039                R85 1
    X4039                R1348 1
    X4039                R1350 -1
    X4040                OBJ 5.3399999999999999
    X4040                R87 1
    X4040                R1332 1
    X4040                R1351 -1
    X4041                OBJ 5.3399999999999999
    X4041                R87 1
    X4041                R1332 -1
    X4041                R1351 1
    X4042                OBJ 6.3799999999999999
    X4042                R88 1
    X4042                R1321 1
    X4042                R1349 -1
    X4043                OBJ 6.3799999999999999
    X4043                R88 1
    X4043                R1321 -1
    X4043                R1349 1
    X4044                OBJ 6
    X4044                R89 1
    X4044                R1337 1
    X4044                R1344 -1
    X4045                OBJ 6
    X4045                R89 1
    X4045                R1337 -1
    X4045                R1344 1
    X4046                OBJ 3.7599999999999998
    X4046                R90 1
    X4046                R1333 1
    X4046                R1351 -1
    X4047                OBJ 3.7599999999999998
    X4047                R90 1
    X4047                R1333 -1
    X4047                R1351 1
    X4048                OBJ 7.8300000000000001
    X4048                R91 1
    X4048                R1323 -1
    X4048                R1349 1
    X4049                OBJ 7.8300000000000001
    X4049                R91 1
    X4049                R1323 1
    X4049                R1349 -1
    X4050                OBJ 2.1800000000000002
    X4050                R92 1
    X4050                R1344 1
    X4050                R1348 -1
    X4051                OBJ 2.1800000000000002
    X4051                R92 1
    X4051                R1344 -1
    X4051                R1348 1
    X4052                OBJ 4
    X4052                R93 1
    X4052                R1323 -1
    X4052                R1351 1
    X4053                OBJ 4
    X4053                R93 1
    X4053                R1323 1
    X4053                R1351 -1
    X4054                OBJ 2.5899999999999999
    X4054                R2 1
    X4054                R1352 1
    X4054                R1353 -1
    X4055                OBJ 2.5899999999999999
    X4055                R2 1
    X4055                R1352 -1
    X4055                R1353 1
    X4056                OBJ 10.67
    X4056                R4 1
    X4056                R1352 1
    X4056                R1354 -1
    X4057                OBJ 10.67
    X4057                R4 1
    X4057                R1352 -1
    X4057                R1354 1
    X4058                OBJ 5.5199999999999996
    X4058                R6 1
    X4058                R1352 1
    X4058                R1355 -1
    X4059                OBJ 5.5199999999999996
    X4059                R6 1
    X4059                R1352 -1
    X4059                R1355 1
    X4060                OBJ 5.4000000000000004
    X4060                R8 1
    X4060                R1352 1
    X4060                R1356 -1
    X4061                OBJ 5.4000000000000004
    X4061                R8 1
    X4061                R1352 -1
    X4061                R1356 1
    X4062                OBJ 13.630000000000001
    X4062                R11 1
    X4062                R1357 1
    X4062                R1358 -1
    X4063                OBJ 13.630000000000001
    X4063                R11 1
    X4063                R1357 -1
    X4063                R1358 1
    X4064                OBJ 7.9400000000000004
    X4064                R13 1
    X4064                R1357 1
    X4064                R1359 -1
    X4065                OBJ 7.9400000000000004
    X4065                R13 1
    X4065                R1357 -1
    X4065                R1359 1
    X4066                OBJ 15
    X4066                R15 1
    X4066                R1357 -1
    X4066                R1360 1
    X4067                OBJ 7.5999999999999996
    X4067                R18 1
    X4067                R1361 1
    X4067                R1362 -1
    X4068                OBJ 7.5999999999999996
    X4068                R18 1
    X4068                R1361 -1
    X4068                R1362 1
    X4069                OBJ 5.0800000000000001
    X4069                R20 1
    X4069                R1361 1
    X4069                R1363 -1
    X4070                OBJ 5.0800000000000001
    X4070                R20 1
    X4070                R1361 -1
    X4070                R1363 1
    X4071                OBJ 12.44
    X4071                R22 1
    X4071                R1361 1
    X4071                R1364 -1
    X4072                OBJ 12.44
    X4072                R22 1
    X4072                R1361 -1
    X4072                R1364 1
    X4073                OBJ 4.7400000000000002
    X4073                R25 1
    X4073                R1365 1
    X4073                R1366 -1
    X4074                OBJ 4.7400000000000002
    X4074                R25 1
    X4074                R1365 -1
    X4074                R1366 1
    X4075                OBJ 4.8700000000000001
    X4075                R26 1
    X4075                R1359 -1
    X4075                R1365 1
    X4076                OBJ 4.8700000000000001
    X4076                R26 1
    X4076                R1359 1
    X4076                R1365 -1
    X4077                OBJ 5.5099999999999998
    X4077                R27 1
    X4077                R1360 1
    X4077                R1365 -1
    X4078                OBJ 5.4000000000000004
    X4078                R30 1
    X4078                R1367 1
    X4078                R1368 -1
    X4079                OBJ 5.4000000000000004
    X4079                R30 1
    X4079                R1367 -1
    X4079                R1368 1
    X4080                OBJ 3.8100000000000001
    X4080                R31 1
    X4080                R1355 -1
    X4080                R1367 1
    X4081                OBJ 3.8100000000000001
    X4081                R31 1
    X4081                R1355 1
    X4081                R1367 -1
    X4082                OBJ 7.5700000000000003
    X4082                R33 1
    X4082                R1367 1
    X4082                R1369 -1
    X4083                OBJ 7.5700000000000003
    X4083                R33 1
    X4083                R1367 -1
    X4083                R1369 1
    X4084                OBJ 4.2000000000000002
    X4084                R35 1
    X4084                R1367 1
    X4084                R1370 -1
    X4085                OBJ 4.2000000000000002
    X4085                R35 1
    X4085                R1367 -1
    X4085                R1370 1
    X4086                OBJ 7.75
    X4086                R37 1
    X4086                R1367 1
    X4086                R1371 -1
    X4087                OBJ 7.75
    X4087                R37 1
    X4087                R1367 -1
    X4087                R1371 1
    X4088                OBJ 6.0999999999999996
    X4088                R39 1
    X4088                R1354 -1
    X4088                R1372 1
    X4089                OBJ 6.0999999999999996
    X4089                R39 1
    X4089                R1354 1
    X4089                R1372 -1
    X4090                OBJ 2.3900000000000001
    X4090                R40 1
    X4090                R1356 -1
    X4090                R1372 1
    X4091                OBJ 2.3900000000000001
    X4091                R40 1
    X4091                R1356 1
    X4091                R1372 -1
    X4092                OBJ 8.3399999999999999
    X4092                R42 1
    X4092                R1362 -1
    X4092                R1373 1
    X4093                OBJ 8.3399999999999999
    X4093                R42 1
    X4093                R1362 1
    X4093                R1373 -1
    X4094                OBJ 7.5599999999999996
    X4094                R43 1
    X4094                R1363 -1
    X4094                R1373 1
    X4095                OBJ 7.5599999999999996
    X4095                R43 1
    X4095                R1363 1
    X4095                R1373 -1
    X4096                OBJ 7.4699999999999998
    X4096                R45 1
    X4096                R1373 1
    X4096                R1374 -1
    X4097                OBJ 7.4699999999999998
    X4097                R45 1
    X4097                R1373 -1
    X4097                R1374 1
    X4098                OBJ 2.6400000000000001
    X4098                R47 1
    X4098                R1353 1
    X4098                R1375 -1
    X4099                OBJ 2.6400000000000001
    X4099                R47 1
    X4099                R1353 -1
    X4099                R1375 1
    X4100                OBJ 3.9300000000000002
    X4100                R48 1
    X4100                R1353 1
    X4100                R1374 -1
    X4101                OBJ 3.9300000000000002
    X4101                R48 1
    X4101                R1353 -1
    X4101                R1374 1
    X4102                OBJ 4.3600000000000003
    X4102                R50 1
    X4102                R1366 1
    X4102                R1376 -1
    X4103                OBJ 4.3600000000000003
    X4103                R50 1
    X4103                R1366 -1
    X4103                R1376 1
    X4104                OBJ 6.6799999999999997
    X4104                R51 1
    X4104                R1366 1
    X4104                R1370 -1
    X4105                OBJ 6.6799999999999997
    X4105                R51 1
    X4105                R1366 -1
    X4105                R1370 1
    X4106                OBJ 7.2199999999999998
    X4106                R53 1
    X4106                R1368 1
    X4106                R1377 -1
    X4107                OBJ 7.2199999999999998
    X4107                R53 1
    X4107                R1368 -1
    X4107                R1377 1
    X4108                OBJ 7.7699999999999996
    X4108                R55 1
    X4108                R1368 1
    X4108                R1378 -1
    X4109                OBJ 7.7699999999999996
    X4109                R55 1
    X4109                R1368 -1
    X4109                R1378 1
    X4110                OBJ 4.6200000000000001
    X4110                R57 1
    X4110                R1354 -1
    X4110                R1379 1
    X4111                OBJ 4.6200000000000001
    X4111                R57 1
    X4111                R1354 1
    X4111                R1379 -1
    X4112                OBJ 6.9000000000000004
    X4112                R58 1
    X4112                R1356 -1
    X4112                R1379 1
    X4113                OBJ 6.9000000000000004
    X4113                R58 1
    X4113                R1356 1
    X4113                R1379 -1
    X4114                OBJ 2.75
    X4114                R60 1
    X4114                R1375 1
    X4114                R1380 -1
    X4115                OBJ 2.75
    X4115                R60 1
    X4115                R1375 -1
    X4115                R1380 1
    X4116                OBJ 5.9199999999999999
    X4116                R61 1
    X4116                R1355 -1
    X4116                R1380 1
    X4117                OBJ 5.9199999999999999
    X4117                R61 1
    X4117                R1355 1
    X4117                R1380 -1
    X4118                OBJ 4.5599999999999996
    X4118                R62 1
    X4118                R1369 -1
    X4118                R1380 1
    X4119                OBJ 4.5599999999999996
    X4119                R62 1
    X4119                R1369 1
    X4119                R1380 -1
    X4120                OBJ 2.71
    X4120                R64 1
    X4120                R1380 1
    X4120                R1381 -1
    X4121                OBJ 2.71
    X4121                R64 1
    X4121                R1380 -1
    X4121                R1381 1
    X4122                OBJ 11.82
    X4122                R66 1
    X4122                R1377 -1
    X4122                R1382 1
    X4123                OBJ 11.82
    X4123                R66 1
    X4123                R1377 1
    X4123                R1382 -1
    X4124                OBJ 5.9699999999999998
    X4124                R67 1
    X4124                R1378 -1
    X4124                R1382 1
    X4125                OBJ 5.9699999999999998
    X4125                R67 1
    X4125                R1378 1
    X4125                R1382 -1
    X4126                OBJ 13.699999999999999
    X4126                R68 1
    X4126                R1371 -1
    X4126                R1382 1
    X4127                OBJ 13.699999999999999
    X4127                R68 1
    X4127                R1371 1
    X4127                R1382 -1
    X4128                OBJ 3.8300000000000001
    X4128                R69 1
    X4128                R1371 -1
    X4128                R1376 1
    X4129                OBJ 3.8300000000000001
    X4129                R69 1
    X4129                R1371 1
    X4129                R1376 -1
    X4130                OBJ 19.77
    X4130                R71 1
    X4130                R1356 -1
    X4130                R1383 1
    X4131                OBJ 19.77
    X4131                R71 1
    X4131                R1356 1
    X4131                R1383 -1
    X4132                OBJ 7.5099999999999998
    X4132                R72 1
    X4132                R1362 -1
    X4132                R1383 1
    X4133                OBJ 7.5099999999999998
    X4133                R72 1
    X4133                R1362 1
    X4133                R1383 -1
    X4134                OBJ 4.71
    X4134                R73 1
    X4134                R1364 -1
    X4134                R1383 1
    X4135                OBJ 4.71
    X4135                R73 1
    X4135                R1364 1
    X4135                R1383 -1
    X4136                OBJ 5.1399999999999997
    X4136                R74 1
    X4136                R1356 1
    X4136                R1374 -1
    X4137                OBJ 5.1399999999999997
    X4137                R74 1
    X4137                R1356 -1
    X4137                R1374 1
    X4138                OBJ 4.1100000000000003
    X4138                R76 1
    X4138                R1363 -1
    X4138                R1384 1
    X4139                OBJ 4.1100000000000003
    X4139                R76 1
    X4139                R1363 1
    X4139                R1384 -1
    X4140                OBJ 5.9400000000000004
    X4140                R77 1
    X4140                R1374 -1
    X4140                R1384 1
    X4141                OBJ 5.9400000000000004
    X4141                R77 1
    X4141                R1374 1
    X4141                R1384 -1
    X4142                OBJ 5.0700000000000003
    X4142                R79 1
    X4142                R1384 1
    X4142                R1385 -1
    X4143                OBJ 9.0700000000000003
    X4143                R81 1
    X4143                R1363 1
    X4143                R1386 -1
    X4144                OBJ 9.0700000000000003
    X4144                R81 1
    X4144                R1363 -1
    X4144                R1386 1
    X4145                OBJ 5.2199999999999998
    X4145                R83 1
    X4145                R1369 -1
    X4145                R1387 1
    X4146                OBJ 5.2199999999999998
    X4146                R83 1
    X4146                R1369 1
    X4146                R1387 -1
    X4147                OBJ 7.2000000000000002
    X4147                R84 1
    X4147                R1386 -1
    X4147                R1387 1
    X4148                OBJ 7.2000000000000002
    X4148                R84 1
    X4148                R1386 1
    X4148                R1387 -1
    X4149                OBJ 3.27
    X4149                R85 1
    X4149                R1385 -1
    X4149                R1387 1
    X4150                OBJ 5.3399999999999999
    X4150                R87 1
    X4150                R1369 1
    X4150                R1388 -1
    X4151                OBJ 5.3399999999999999
    X4151                R87 1
    X4151                R1369 -1
    X4151                R1388 1
    X4152                OBJ 6.3799999999999999
    X4152                R88 1
    X4152                R1358 1
    X4152                R1386 -1
    X4153                OBJ 6.3799999999999999
    X4153                R88 1
    X4153                R1358 -1
    X4153                R1386 1
    X4154                OBJ 6
    X4154                R89 1
    X4154                R1374 1
    X4154                R1381 -1
    X4155                OBJ 6
    X4155                R89 1
    X4155                R1374 -1
    X4155                R1381 1
    X4156                OBJ 3.7599999999999998
    X4156                R90 1
    X4156                R1370 1
    X4156                R1388 -1
    X4157                OBJ 3.7599999999999998
    X4157                R90 1
    X4157                R1370 -1
    X4157                R1388 1
    X4158                OBJ 7.8300000000000001
    X4158                R91 1
    X4158                R1360 1
    X4158                R1386 -1
    X4159                OBJ 2.1800000000000002
    X4159                R92 1
    X4159                R1381 1
    X4159                R1385 -1
    X4160                OBJ 4
    X4160                R93 1
    X4160                R1360 1
    X4160                R1388 -1
RHS
    RHS                  OBJ -0
    RHS                  R0 0
    RHS                  R1 -1770
    RHS                  R2 0
    RHS                  R3 -7256
    RHS                  R4 0
    RHS                  R5 -3190
    RHS                  R6 0
    RHS                  R7 -11252
    RHS                  R8 0
    RHS                  R9 0
    RHS                  R10 -2384
    RHS                  R11 0
    RHS                  R12 -524
    RHS                  R13 0
    RHS                  R14 -366
    RHS                  R15 0
    RHS                  R16 0
    RHS                  R17 -1878
    RHS                  R18 0
    RHS                  R19 -1580
    RHS                  R20 0
    RHS                  R21 -1702
    RHS                  R22 0
    RHS                  R23 0
    RHS                  R24 -750
    RHS                  R25 0
    RHS                  R26 0
    RHS                  R27 0
    RHS                  R28 0
    RHS                  R29 -780
    RHS                  R30 0
    RHS                  R31 0
    RHS                  R32 -2846
    RHS                  R33 0
    RHS                  R34 -1252
    RHS                  R35 0
    RHS                  R36 -3364
    RHS                  R37 0
    RHS                  R38 71492
    RHS                  R39 0
    RHS                  R40 0
    RHS                  R41 -1808
    RHS                  R42 0
    RHS                  R43 0
    RHS                  R44 -2348
    RHS                  R45 0
    RHS                  R46 -3592
    RHS                  R47 0
    RHS                  R48 0
    RHS                  R49 -3374
    RHS                  R50 0
    RHS                  R51 0
    RHS                  R52 -746
    RHS                  R53 0
    RHS                  R54 -1346
    RHS                  R55 0
    RHS                  R56 -878
    RHS                  R57 0
    RHS                  R58 0
    RHS                  R59 -3234
    RHS                  R60 0
    RHS                  R61 0
    RHS                  R62 0
    RHS                  R63 -1856
    RHS                  R64 0
    RHS                  R65 -634
    RHS                  R66 0
    RHS                  R67 0
    RHS                  R68 0
    RHS                  R69 0
    RHS                  R70 -1144
    RHS                  R71 0
    RHS                  R72 0
    RHS                  R73 0
    RHS                  R74 0
    RHS                  R75 -1770
    RHS                  R76 0
    RHS                  R77 0
    RHS                  R78 -1268
    RHS                  R79 0
    RHS                  R80 -2596
    RHS                  R81 0
    RHS                  R82 -3012
    RHS                  R83 0
    RHS                  R84 0
    RHS                  R85 0
    RHS                  R86 -992
    RHS                  R87 0
    RHS                  R88 0
    RHS                  R89 0
    RHS                  R90 0
    RHS                  R91 0
    RHS                  R92 0
    RHS                  R93 0
    RHS                  R94 0
    RHS                  R95 -936
    RHS                  R96 -2720
    RHS                  R97 -3546
    RHS                  R98 -3002
    RHS                  R99 0
    RHS                  R100 -1566
    RHS                  R101 -444
    RHS                  R102 -348
    RHS                  R103 0
    RHS                  R104 -990
    RHS                  R105 -964
    RHS                  R106 -910
    RHS                  R107 0
    RHS                  R108 -778
    RHS                  R109 49606
    RHS                  R110 -796
    RHS                  R111 -2442
    RHS                  R112 -1652
    RHS                  R113 -3816
    RHS                  R114 -2884
    RHS                  R115 -912
    RHS                  R116 -1120
    RHS                  R117 -2518
    RHS                  R118 -3756
    RHS                  R119 -482
    RHS                  R120 -938
    RHS                  R121 -272
    RHS                  R122 -2672
    RHS                  R123 -1378
    RHS                  R124 -430
    RHS                  R125 -574
    RHS                  R126 -1062
    RHS                  R127 -852
    RHS                  R128 -1806
    RHS                  R129 -2142
    RHS                  R130 -898
    RHS                  R131 43922
    RHS                  R132 -1496
    RHS                  R133 -2722
    RHS                  R134 -2206
    RHS                  R135 -3630
    RHS                  R136 -358
    RHS                  R137 -1192
    RHS                  R138 -284
    RHS                  R139 -212
    RHS                  R140 -930
    RHS                  R141 -858
    RHS                  R142 -804
    RHS                  R143 -776
    RHS                  R144 -202
    RHS                  R145 -434
    RHS                  R146 -1766
    RHS                  R147 -458
    RHS                  R148 -1650
    RHS                  R149 -756
    RHS                  R150 -1916
    RHS                  R151 -3252
    RHS                  R152 -836
    RHS                  R153 -1244
    RHS                  R154 -3280
    RHS                  R155 -1930
    RHS                  R156 -374
    RHS                  R157 -672
    RHS                  R158 -272
    RHS                  R159 -2224
    RHS                  R160 -1188
    RHS                  R161 -312
    RHS                  R162 -506
    RHS                  R163 -936
    RHS                  R164 -702
    RHS                  R165 -1346
    RHS                  R166 -1660
    RHS                  R167 -538
    RHS                  R168 0
    RHS                  R169 0
    RHS                  R170 0
    RHS                  R171 0
    RHS                  R172 -3500
    RHS                  R173 0
    RHS                  R174 -2546
    RHS                  R175 -946
    RHS                  R176 -708
    RHS                  R177 0
    RHS                  R178 -1414
    RHS                  R179 -1412
    RHS                  R180 -1304
    RHS                  R181 0
    RHS                  R182 0
    RHS                  R183 0
    RHS                  R184 0
    RHS                  R185 -3366
    RHS                  R186 -2236
    RHS                  R187 -9814
    RHS                  R188 0
    RHS                  R189 0
    RHS                  R190 -1448
    RHS                  R191 0
    RHS                  R192 43590
    RHS                  R193 -584
    RHS                  R194 -1210
    RHS                  R195 0
    RHS                  R196 0
    RHS                  R197 -1758
    RHS                  R198 0
    RHS                  R199 -772
    RHS                  R200 -1484
    RHS                  R201 -1108
    RHS                  R202 -2968
    RHS                  R203 -3174
    RHS                  R204 -1838
    RHS                  R205 0
    RHS                  R206 0
    RHS                  R207 43170
    RHS                  R208 -2982
    RHS                  R209 -6420
    RHS                  R210 0
    RHS                  R211 -2232
    RHS                  R212 -494
    RHS                  R213 -334
    RHS                  R214 0
    RHS                  R215 -1698
    RHS                  R216 -1392
    RHS                  R217 -1580
    RHS                  R218 0
    RHS                  R219 0
    RHS                  R220 0
    RHS                  R221 0
    RHS                  R222 -2588
    RHS                  R223 -1158
    RHS                  R224 -3238
    RHS                  R225 0
    RHS                  R226 0
    RHS                  R227 -1768
    RHS                  R228 0
    RHS                  R229 -3198
    RHS                  R230 -780
    RHS                  R231 -1368
    RHS                  R232 0
    RHS                  R233 0
    RHS                  R234 -1582
    RHS                  R235 -642
    RHS                  R236 -1078
    RHS                  R237 -1504
    RHS                  R238 -1136
    RHS                  R239 -2392
    RHS                  R240 -2672
    RHS                  R241 -934
    RHS                  R242 0
    RHS                  R243 0
    RHS                  R244 -3060
    RHS                  R245 -3020
    RHS                  R246 -3994
    RHS                  R247 0
    RHS                  R248 -1592
    RHS                  R249 -406
    RHS                  R250 -316
    RHS                  R251 0
    RHS                  R252 -1116
    RHS                  R253 -1114
    RHS                  R254 -998
    RHS                  R255 0
    RHS                  R256 0
    RHS                  R257 0
    RHS                  R258 0
    RHS                  R259 -2488
    RHS                  R260 -1130
    RHS                  R261 -2684
    RHS                  R262 0
    RHS                  R263 0
    RHS                  R264 -1682
    RHS                  R265 42308
    RHS                  R266 -2754
    RHS                  R267 -448
    RHS                  R268 -814
    RHS                  R269 0
    RHS                  R270 -4292
    RHS                  R271 -2010
    RHS                  R272 -380
    RHS                  R273 -626
    RHS                  R274 -1334
    RHS                  R275 -1030
    RHS                  R276 -1852
    RHS                  R277 -2424
    RHS                  R278 -744
    RHS                  R279 0
    RHS                  R280 0
    RHS                  R281 -2842
    RHS                  R282 -2778
    RHS                  R283 -3518
    RHS                  R284 0
    RHS                  R285 -1678
    RHS                  R286 -432
    RHS                  R287 -360
    RHS                  R288 0
    RHS                  R289 -1118
    RHS                  R290 -1178
    RHS                  R291 -1000
    RHS                  R292 0
    RHS                  R293 0
    RHS                  R294 0
    RHS                  R295 0
    RHS                  R296 -3204
    RHS                  R297 -1328
    RHS                  R298 -2828
    RHS                  R299 0
    RHS                  R300 0
    RHS                  R301 -1550
    RHS                  R302 0
    RHS                  R303 -2986
    RHS                  R304 -430
    RHS                  R305 -802
    RHS                  R306 0
    RHS                  R307 40080
    RHS                  R308 -2754
    RHS                  R309 -378
    RHS                  R310 -622
    RHS                  R311 -1414
    RHS                  R312 -1258
    RHS                  R313 -2004
    RHS                  R314 -2778
    RHS                  R315 -840
    RHS                  R316 0
    RHS                  R317 0
    RHS                  R318 0
    RHS                  R319 0
    RHS                  R320 33798
    RHS                  R321 0
    RHS                  R322 -2462
    RHS                  R323 -542
    RHS                  R324 -386
    RHS                  R325 0
    RHS                  R326 -1932
    RHS                  R327 -1680
    RHS                  R328 -1732
    RHS                  R329 0
    RHS                  R330 0
    RHS                  R331 0
    RHS                  R332 0
    RHS                  R333 -3020
    RHS                  R334 -1316
    RHS                  R335 -3464
    RHS                  R336 0
    RHS                  R337 0
    RHS                  R338 -2864
    RHS                  R339 0
    RHS                  R340 0
    RHS                  R341 -742
    RHS                  R342 -1352
    RHS                  R343 0
    RHS                  R344 0
    RHS                  R345 -2054
    RHS                  R346 0
    RHS                  R347 0
    RHS                  R348 -1934
    RHS                  R349 -1354
    RHS                  R350 -2710
    RHS                  R351 -3224
    RHS                  R352 -1030
    RHS                  R353 0
    RHS                  R354 -566
    RHS                  R355 -1714
    RHS                  R356 -1106
    RHS                  R357 -2018
    RHS                  R358 0
    RHS                  R359 -1520
    RHS                  R360 -306
    RHS                  R361 -218
    RHS                  R362 33602
    RHS                  R363 -1550
    RHS                  R364 -1538
    RHS                  R365 -1166
    RHS                  R366 -206
    RHS                  R367 -406
    RHS                  R368 -1098
    RHS                  R369 -276
    RHS                  R370 -1304
    RHS                  R371 -558
    RHS                  R372 -1514
    RHS                  R373 -1924
    RHS                  R374 -1300
    RHS                  R375 -908
    RHS                  R376 -1248
    RHS                  R377 -1600
    RHS                  R378 -238
    RHS                  R379 -446
    RHS                  R380 -196
    RHS                  R381 -1280
    RHS                  R382 -862
    RHS                  R383 -220
    RHS                  R384 -624
    RHS                  R385 -1174
    RHS                  R386 -580
    RHS                  R387 -1670
    RHS                  R388 -1836
    RHS                  R389 -432
    RHS                  R390 0
    RHS                  R391 0
    RHS                  R392 0
    RHS                  R393 29548
    RHS                  R394 -3334
    RHS                  R395 0
    RHS                  R396 -1510
    RHS                  R397 -408
    RHS                  R398 -306
    RHS                  R399 0
    RHS                  R400 -1012
    RHS                  R401 -962
    RHS                  R402 -924
    RHS                  R403 0
    RHS                  R404 0
    RHS                  R405 0
    RHS                  R406 0
    RHS                  R407 -2214
    RHS                  R408 -1206
    RHS                  R409 -3102
    RHS                  R410 0
    RHS                  R411 0
    RHS                  R412 -1218
    RHS                  R413 0
    RHS                  R414 -3026
    RHS                  R415 -518
    RHS                  R416 -938
    RHS                  R417 0
    RHS                  R418 0
    RHS                  R419 -1400
    RHS                  R420 -420
    RHS                  R421 -586
    RHS                  R422 -1078
    RHS                  R423 -838
    RHS                  R424 -1722
    RHS                  R425 -2070
    RHS                  R426 -756
    RHS                  R427 0
    RHS                  R428 -528
    RHS                  R429 -1524
    RHS                  R430 -946
    RHS                  R431 -1932
    RHS                  R432 0
    RHS                  R433 -1016
    RHS                  R434 -228
    RHS                  R435 -164
    RHS                  R436 0
    RHS                  R437 -1142
    RHS                  R438 -942
    RHS                  R439 -848
    RHS                  R440 0
    RHS                  R441 -314
    RHS                  R442 0
    RHS                  R443 -234
    RHS                  R444 -1050
    RHS                  R445 -452
    RHS                  R446 -1216
    RHS                  R447 0
    RHS                  R448 23518
    RHS                  R449 -950
    RHS                  R450 -1110
    RHS                  R451 -1268
    RHS                  R452 -200
    RHS                  R453 -368
    RHS                  R454 -184
    RHS                  R455 -1102
    RHS                  R456 -748
    RHS                  R457 -180
    RHS                  R458 -494
    RHS                  R459 -1030
    RHS                  R460 -478
    RHS                  R461 -1140
    RHS                  R462 -1390
    RHS                  R463 -340
    RHS                  R464 0
    RHS                  R465 0
    RHS                  R466 0
    RHS                  R467 0
    RHS                  R468 0
    RHS                  R469 0
    RHS                  R470 -2398
    RHS                  R471 -556
    RHS                  R472 -510
    RHS                  R473 0
    RHS                  R474 0
    RHS                  R475 0
    RHS                  R476 -1222
    RHS                  R477 0
    RHS                  R478 0
    RHS                  R479 0
    RHS                  R480 0
    RHS                  R481 -3474
    RHS                  R482 -1206
    RHS                  R483 -2866
    RHS                  R484 0
    RHS                  R485 0
    RHS                  R486 -1538
    RHS                  R487 0
    RHS                  R488 0
    RHS                  R489 -398
    RHS                  R490 -754
    RHS                  R491 0
    RHS                  R492 0
    RHS                  R493 -2148
    RHS                  R494 0
    RHS                  R495 0
    RHS                  R496 0
    RHS                  R497 -1756
    RHS                  R498 -3400
    RHS                  R499 23160
    RHS                  R500 -934
    RHS                  R501 0
    RHS                  R502 20530
    RHS                  R503 -1384
    RHS                  R504 -1086
    RHS                  R505 -2128
    RHS                  R506 0
    RHS                  R507 -682
    RHS                  R508 -170
    RHS                  R509 -130
    RHS                  R510 0
    RHS                  R511 -508
    RHS                  R512 -500
    RHS                  R513 -448
    RHS                  R514 0
    RHS                  R515 -258
    RHS                  R516 0
    RHS                  R517 -234
    RHS                  R518 -976
    RHS                  R519 -430
    RHS                  R520 -1074
    RHS                  R521 0
    RHS                  R522 0
    RHS                  R523 -976
    RHS                  R524 -1960
    RHS                  R525 -1100
    RHS                  R526 -186
    RHS                  R527 -336
    RHS                  R528 -152
    RHS                  R529 -1382
    RHS                  R530 -818
    RHS                  R531 -158
    RHS                  R532 -280
    RHS                  R533 -618
    RHS                  R534 -430
    RHS                  R535 -790
    RHS                  R536 -1038
    RHS                  R537 -298
    RHS                  R538 0
    RHS                  R539 0
    RHS                  R540 0
    RHS                  R541 0
    RHS                  R542 0
    RHS                  R543 0
    RHS                  R544 -1854
    RHS                  R545 -492
    RHS                  R546 -490
    RHS                  R547 0
    RHS                  R548 0
    RHS                  R549 0
    RHS                  R550 -994
    RHS                  R551 0
    RHS                  R552 0
    RHS                  R553 0
    RHS                  R554 0
    RHS                  R555 17794
    RHS                  R556 -1584
    RHS                  R557 -2972
    RHS                  R558 0
    RHS                  R559 0
    RHS                  R560 -1274
    RHS                  R561 0
    RHS                  R562 0
    RHS                  R563 -400
    RHS                  R564 -770
    RHS                  R565 0
    RHS                  R566 0
    RHS                  R567 -2084
    RHS                  R568 0
    RHS                  R569 0
    RHS                  R570 0
    RHS                  R571 -1422
    RHS                  R572 -2360
    RHS                  R573 0
    RHS                  R574 -1098
    RHS                  R575 0
    RHS                  R576 0
    RHS                  R577 -696
    RHS                  R578 -658
    RHS                  R579 -784
    RHS                  R580 0
    RHS                  R581 -688
    RHS                  R582 -280
    RHS                  R583 -258
    RHS                  R584 0
    RHS                  R585 -348
    RHS                  R586 -366
    RHS                  R587 -320
    RHS                  R588 0
    RHS                  R589 15520
    RHS                  R590 0
    RHS                  R591 -172
    RHS                  R592 -874
    RHS                  R593 -508
    RHS                  R594 -1506
    RHS                  R595 0
    RHS                  R596 0
    RHS                  R597 -352
    RHS                  R598 -638
    RHS                  R599 -2238
    RHS                  R600 -124
    RHS                  R601 -248
    RHS                  R602 -80
    RHS                  R603 -708
    RHS                  R604 -438
    RHS                  R605 -126
    RHS                  R606 -182
    RHS                  R607 -378
    RHS                  R608 -276
    RHS                  R609 -838
    RHS                  R610 -852
    RHS                  R611 -584
    RHS                  R612 0
    RHS                  R613 0
    RHS                  R614 0
    RHS                  R615 0
    RHS                  R616 0
    RHS                  R617 0
    RHS                  R618 -1142
    RHS                  R619 -260
    RHS                  R620 -206
    RHS                  R621 0
    RHS                  R622 -864
    RHS                  R623 -1362
    RHS                  R624 -718
    RHS                  R625 0
    RHS                  R626 0
    RHS                  R627 0
    RHS                  R628 0
    RHS                  R629 -1398
    RHS                  R630 -552
    RHS                  R631 -1390
    RHS                  R632 0
    RHS                  R633 0
    RHS                  R634 -1086
    RHS                  R635 0
    RHS                  R636 0
    RHS                  R637 -210
    RHS                  R638 -392
    RHS                  R639 0
    RHS                  R640 0
    RHS                  R641 -1102
    RHS                  R642 0
    RHS                  R643 0
    RHS                  R644 15466
    RHS                  R645 -728
    RHS                  R646 -1406
    RHS                  R647 -2240
    RHS                  R648 -410
    RHS                  R649 0
    RHS                  R650 -206
    RHS                  R651 -666
    RHS                  R652 -480
    RHS                  R653 -716
    RHS                  R654 13842
    RHS                  R655 -840
    RHS                  R656 -324
    RHS                  R657 -124
    RHS                  R658 -388
    RHS                  R659 -344
    RHS                  R660 -324
    RHS                  R661 -328
    RHS                  R662 -166
    RHS                  R663 -252
    RHS                  R664 -508
    RHS                  R665 -128
    RHS                  R666 -556
    RHS                  R667 -270
    RHS                  R668 -854
    RHS                  R669 -698
    RHS                  R670 -284
    RHS                  R671 -288
    RHS                  R672 -484
    RHS                  R673 -928
    RHS                  R674 -108
    RHS                  R675 -212
    RHS                  R676 -72
    RHS                  R677 -508
    RHS                  R678 -316
    RHS                  R679 -110
    RHS                  R680 -190
    RHS                  R681 -312
    RHS                  R682 -214
    RHS                  R683 -774
    RHS                  R684 -646
    RHS                  R685 -224
    RHS                  R686 0
    RHS                  R687 0
    RHS                  R688 0
    RHS                  R689 0
    RHS                  R690 0
    RHS                  R691 0
    RHS                  R692 -1246
    RHS                  R693 -266
    RHS                  R694 -180
    RHS                  R695 0
    RHS                  R696 13116
    RHS                  R697 -918
    RHS                  R698 -1816
    RHS                  R699 0
    RHS                  R700 0
    RHS                  R701 0
    RHS                  R702 0
    RHS                  R703 -1102
    RHS                  R704 -488
    RHS                  R705 -1362
    RHS                  R706 0
    RHS                  R707 0
    RHS                  R708 -800
    RHS                  R709 0
    RHS                  R710 0
    RHS                  R711 -228
    RHS                  R712 -426
    RHS                  R713 0
    RHS                  R714 0
    RHS                  R715 -720
    RHS                  R716 0
    RHS                  R717 0
    RHS                  R718 0
    RHS                  R719 -482
    RHS                  R720 -1302
    RHS                  R721 -1402
    RHS                  R722 -378
    RHS                  R723 0
    RHS                  R724 0
    RHS                  R725 0
    RHS                  R726 0
    RHS                  R727 0
    RHS                  R728 0
    RHS                  R729 13106
    RHS                  R730 -612
    RHS                  R731 -378
    RHS                  R732 0
    RHS                  R733 0
    RHS                  R734 0
    RHS                  R735 -1166
    RHS                  R736 0
    RHS                  R737 0
    RHS                  R738 0
    RHS                  R739 0
    RHS                  R740 0
    RHS                  R741 -822
    RHS                  R742 -2336
    RHS                  R743 0
    RHS                  R744 0
    RHS                  R745 -978
    RHS                  R746 0
    RHS                  R747 0
    RHS                  R748 0
    RHS                  R749 -652
    RHS                  R750 0
    RHS                  R751 0
    RHS                  R752 -1070
    RHS                  R753 0
    RHS                  R754 0
    RHS                  R755 0
    RHS                  R756 -750
    RHS                  R757 -3656
    RHS                  R758 0
    RHS                  R759 -686
    RHS                  R760 0
    RHS                  R761 0
    RHS                  R762 0
    RHS                  R763 0
    RHS                  R764 0
    RHS                  R765 0
    RHS                  R766 -1282
    RHS                  R767 -264
    RHS                  R768 -202
    RHS                  R769 0
    RHS                  R770 0
    RHS                  R771 12408
    RHS                  R772 -758
    RHS                  R773 0
    RHS                  R774 0
    RHS                  R775 0
    RHS                  R776 0
    RHS                  R777 -1240
    RHS                  R778 -506
    RHS                  R779 -1316
    RHS                  R780 0
    RHS                  R781 0
    RHS                  R782 -806
    RHS                  R783 0
    RHS                  R784 0
    RHS                  R785 -198
    RHS                  R786 -372
    RHS                  R787 0
    RHS                  R788 0
    RHS                  R789 -840
    RHS                  R790 0
    RHS                  R791 0
    RHS                  R792 0
    RHS                  R793 -580
    RHS                  R794 -1588
    RHS                  R795 -2066
    RHS                  R796 -390
    RHS                  R797 0
    RHS                  R798 0
    RHS                  R799 -768
    RHS                  R800 -894
    RHS                  R801 -796
    RHS                  R802 0
    RHS                  R803 -388
    RHS                  R804 -110
    RHS                  R805 -78
    RHS                  R806 0
    RHS                  R807 -256
    RHS                  R808 -238
    RHS                  R809 -238
    RHS                  R810 0
    RHS                  R811 0
    RHS                  R812 0
    RHS                  R813 10458
    RHS                  R814 -514
    RHS                  R815 -288
    RHS                  R816 -904
    RHS                  R817 0
    RHS                  R818 0
    RHS                  R819 -282
    RHS                  R820 -594
    RHS                  R821 -822
    RHS                  R822 -168
    RHS                  R823 -310
    RHS                  R824 -76
    RHS                  R825 -572
    RHS                  R826 -310
    RHS                  R827 -128
    RHS                  R828 -150
    RHS                  R829 -258
    RHS                  R830 -196
    RHS                  R831 -434
    RHS                  R832 -496
    RHS                  R833 -190
    RHS                  R834 0
    RHS                  R835 0
    RHS                  R836 0
    RHS                  R837 0
    RHS                  R838 -1154
    RHS                  R839 0
    RHS                  R840 -668
    RHS                  R841 -142
    RHS                  R842 -92
    RHS                  R843 0
    RHS                  R844 -906
    RHS                  R845 -428
    RHS                  R846 -1186
    RHS                  R847 0
    RHS                  R848 0
    RHS                  R849 0
    RHS                  R850 0
    RHS                  R851 -612
    RHS                  R852 -268
    RHS                  R853 -752
    RHS                  R854 0
    RHS                  R855 0
    RHS                  R856 -410
    RHS                  R857 0
    RHS                  R858 0
    RHS                  R859 -144
    RHS                  R860 -274
    RHS                  R861 0
    RHS                  R862 0
    RHS                  R863 -376
    RHS                  R864 0
    RHS                  R865 9720
    RHS                  R866 -418
    RHS                  R867 -270
    RHS                  R868 -684
    RHS                  R869 -716
    RHS                  R870 -220
    RHS                  R871 0
    RHS                  R872 0
    RHS                  R873 0
    RHS                  R874 0
    RHS                  R875 0
    RHS                  R876 0
    RHS                  R877 0
    RHS                  R878 -648
    RHS                  R879 -516
    RHS                  R880 0
    RHS                  R881 0
    RHS                  R882 0
    RHS                  R883 -1180
    RHS                  R884 0
    RHS                  R885 0
    RHS                  R886 0
    RHS                  R887 0
    RHS                  R888 0
    RHS                  R889 0
    RHS                  R890 -2656
    RHS                  R891 0
    RHS                  R892 0
    RHS                  R893 0
    RHS                  R894 0
    RHS                  R895 0
    RHS                  R896 0
    RHS                  R897 -702
    RHS                  R898 0
    RHS                  R899 0
    RHS                  R900 -1328
    RHS                  R901 0
    RHS                  R902 0
    RHS                  R903 0
    RHS                  R904 -940
    RHS                  R905 8810
    RHS                  R906 0
    RHS                  R907 -840
    RHS                  R908 0
    RHS                  R909 -120
    RHS                  R910 -330
    RHS                  R911 -286
    RHS                  R912 -370
    RHS                  R913 0
    RHS                  R914 -406
    RHS                  R915 -244
    RHS                  R916 -128
    RHS                  R917 0
    RHS                  R918 -172
    RHS                  R919 -184
    RHS                  R920 -158
    RHS                  R921 8364
    RHS                  R922 -314
    RHS                  R923 -326
    RHS                  R924 -74
    RHS                  R925 -384
    RHS                  R926 -196
    RHS                  R927 -620
    RHS                  R928 -356
    RHS                  R929 -152
    RHS                  R930 -164
    RHS                  R931 -286
    RHS                  R932 -792
    RHS                  R933 -56
    RHS                  R934 -114
    RHS                  R935 -38
    RHS                  R936 -314
    RHS                  R937 -202
    RHS                  R938 -60
    RHS                  R939 -90
    RHS                  R940 -184
    RHS                  R941 -128
    RHS                  R942 -492
    RHS                  R943 -426
    RHS                  R944 -198
    RHS                  R945 0
    RHS                  R946 0
    RHS                  R947 0
    RHS                  R948 0
    RHS                  R949 0
    RHS                  R950 0
    RHS                  R951 0
    RHS                  R952 -238
    RHS                  R953 -182
    RHS                  R954 0
    RHS                  R955 0
    RHS                  R956 0
    RHS                  R957 -678
    RHS                  R958 0
    RHS                  R959 0
    RHS                  R960 0
    RHS                  R961 0
    RHS                  R962 0
    RHS                  R963 -546
    RHS                  R964 -1396
    RHS                  R965 0
    RHS                  R966 0
    RHS                  R967 6652
    RHS                  R968 0
    RHS                  R969 0
    RHS                  R970 0
    RHS                  R971 -412
    RHS                  R972 0
    RHS                  R973 0
    RHS                  R974 -1080
    RHS                  R975 0
    RHS                  R976 0
    RHS                  R977 0
    RHS                  R978 -596
    RHS                  R979 -1138
    RHS                  R980 0
    RHS                  R981 -386
    RHS                  R982 0
    RHS                  R983 0
    RHS                  R984 -880
    RHS                  R985 -298
    RHS                  R986 -716
    RHS                  R987 0
    RHS                  R988 -236
    RHS                  R989 -58
    RHS                  R990 -40
    RHS                  R991 0
    RHS                  R992 -198
    RHS                  R993 -158
    RHS                  R994 -180
    RHS                  R995 0
    RHS                  R996 0
    RHS                  R997 0
    RHS                  R998 0
    RHS                  R999 -266
    RHS                  R1000 -124
    RHS                  R1001 -348
    RHS                  R1002 0
    RHS                  R1003 0
    RHS                  R1004 -212
    RHS                  R1005 -322
    RHS                  R1006 -348
    RHS                  R1007 -70
    RHS                  R1008 -122
    RHS                  R1009 6150
    RHS                  R1010 -296
    RHS                  R1011 -176
    RHS                  R1012 -58
    RHS                  R1013 -116
    RHS                  R1014 -172
    RHS                  R1015 -114
    RHS                  R1016 -256
    RHS                  R1017 -294
    RHS                  R1018 -92
    RHS                  R1019 0
    RHS                  R1020 0
    RHS                  R1021 0
    RHS                  R1022 0
    RHS                  R1023 0
    RHS                  R1024 0
    RHS                  R1025 0
    RHS                  R1026 -252
    RHS                  R1027 -228
    RHS                  R1028 0
    RHS                  R1029 0
    RHS                  R1030 0
    RHS                  R1031 -444
    RHS                  R1032 0
    RHS                  R1033 0
    RHS                  R1034 0
    RHS                  R1035 0
    RHS                  R1036 0
    RHS                  R1037 6062
    RHS                  R1038 -1906
    RHS                  R1039 0
    RHS                  R1040 0
    RHS                  R1041 0
    RHS                  R1042 0
    RHS                  R1043 0
    RHS                  R1044 0
    RHS                  R1045 -388
    RHS                  R1046 0
    RHS                  R1047 0
    RHS                  R1048 -738
    RHS                  R1049 0
    RHS                  R1050 0
    RHS                  R1051 0
    RHS                  R1052 -456
    RHS                  R1053 -994
    RHS                  R1054 0
    RHS                  R1055 -656
    RHS                  R1056 0
    RHS                  R1057 0
    RHS                  R1058 0
    RHS                  R1059 0
    RHS                  R1060 -636
    RHS                  R1061 0
    RHS                  R1062 -328
    RHS                  R1063 -90
    RHS                  R1064 -56
    RHS                  R1065 0
    RHS                  R1066 -210
    RHS                  R1067 -184
    RHS                  R1068 -200
    RHS                  R1069 0
    RHS                  R1070 0
    RHS                  R1071 0
    RHS                  R1072 0
    RHS                  R1073 -372
    RHS                  R1074 -186
    RHS                  R1075 -690
    RHS                  R1076 0
    RHS                  R1077 0
    RHS                  R1078 -198
    RHS                  R1079 0
    RHS                  R1080 -608
    RHS                  R1081 -130
    RHS                  R1082 -332
    RHS                  R1083 0
    RHS                  R1084 0
    RHS                  R1085 -208
    RHS                  R1086 5770
    RHS                  R1087 -134
    RHS                  R1088 -190
    RHS                  R1089 -152
    RHS                  R1090 -350
    RHS                  R1091 -368
    RHS                  R1092 -148
    RHS                  R1093 0
    RHS                  R1094 0
    RHS                  R1095 0
    RHS                  R1096 0
    RHS                  R1097 0
    RHS                  R1098 0
    RHS                  R1099 0
    RHS                  R1100 0
    RHS                  R1101 -234
    RHS                  R1102 0
    RHS                  R1103 0
    RHS                  R1104 0
    RHS                  R1105 0
    RHS                  R1106 0
    RHS                  R1107 0
    RHS                  R1108 0
    RHS                  R1109 0
    RHS                  R1110 0
    RHS                  R1111 0
    RHS                  R1112 -1636
    RHS                  R1113 0
    RHS                  R1114 0
    RHS                  R1115 0
    RHS                  R1116 0
    RHS                  R1117 0
    RHS                  R1118 0
    RHS                  R1119 0
    RHS                  R1120 0
    RHS                  R1121 0
    RHS                  R1122 3562
    RHS                  R1123 0
    RHS                  R1124 0
    RHS                  R1125 0
    RHS                  R1126 -1198
    RHS                  R1127 0
    RHS                  R1128 0
    RHS                  R1129 -494
    RHS                  R1130 0
    RHS                  R1131 0
    RHS                  R1132 0
    RHS                  R1133 0
    RHS                  R1134 0
    RHS                  R1135 0
    RHS                  R1136 0
    RHS                  R1137 -250
    RHS                  R1138 -164
    RHS                  R1139 0
    RHS                  R1140 0
    RHS                  R1141 0
    RHS                  R1142 3486
    RHS                  R1143 0
    RHS                  R1144 0
    RHS                  R1145 0
    RHS                  R1146 0
    RHS                  R1147 0
    RHS                  R1148 0
    RHS                  R1149 -1262
    RHS                  R1150 0
    RHS                  R1151 0
    RHS                  R1152 0
    RHS                  R1153 0
    RHS                  R1154 0
    RHS                  R1155 0
    RHS                  R1156 -404
    RHS                  R1157 0
    RHS                  R1158 0
    RHS                  R1159 -630
    RHS                  R1160 0
    RHS                  R1161 0
    RHS                  R1162 0
    RHS                  R1163 -428
    RHS                  R1164 0
    RHS                  R1165 0
    RHS                  R1166 -348
    RHS                  R1167 0
    RHS                  R1168 0
    RHS                  R1169 0
    RHS                  R1170 0
    RHS                  R1171 0
    RHS                  R1172 0
    RHS                  R1173 -336
    RHS                  R1174 -86
    RHS                  R1175 -56
    RHS                  R1176 0
    RHS                  R1177 0
    RHS                  R1178 0
    RHS                  R1179 -216
    RHS                  R1180 0
    RHS                  R1181 0
    RHS                  R1182 0
    RHS                  R1183 0
    RHS                  R1184 0
    RHS                  R1185 -198
    RHS                  R1186 -630
    RHS                  R1187 0
    RHS                  R1188 0
    RHS                  R1189 -228
    RHS                  R1190 0
    RHS                  R1191 0
    RHS                  R1192 2986
    RHS                  R1193 -322
    RHS                  R1194 0
    RHS                  R1195 0
    RHS                  R1196 -234
    RHS                  R1197 0
    RHS                  R1198 0
    RHS                  R1199 0
    RHS                  R1200 -166
    RHS                  R1201 -362
    RHS                  R1202 0
    RHS                  R1203 -152
    RHS                  R1204 0
    RHS                  R1205 0
    RHS                  R1206 0
    RHS                  R1207 0
    RHS                  R1208 0
    RHS                  R1209 0
    RHS                  R1210 0
    RHS                  R1211 0
    RHS                  R1212 -110
    RHS                  R1213 0
    RHS                  R1214 0
    RHS                  R1215 0
    RHS                  R1216 0
    RHS                  R1217 0
    RHS                  R1218 0
    RHS                  R1219 0
    RHS                  R1220 0
    RHS                  R1221 0
    RHS                  R1222 0
    RHS                  R1223 -1370
    RHS                  R1224 0
    RHS                  R1225 0
    RHS                  R1226 0
    RHS                  R1227 0
    RHS                  R1228 0
    RHS                  R1229 0
    RHS                  R1230 2530
    RHS                  R1231 0
    RHS                  R1232 0
    RHS                  R1233 -434
    RHS                  R1234 0
    RHS                  R1235 0
    RHS                  R1236 0
    RHS                  R1237 -316
    RHS                  R1238 0
    RHS                  R1239 0
    RHS                  R1240 -300
    RHS                  R1241 0
    RHS                  R1242 0
    RHS                  R1243 0
    RHS                  R1244 0
    RHS                  R1245 0
    RHS                  R1246 0
    RHS                  R1247 0
    RHS                  R1248 0
    RHS                  R1249 -242
    RHS                  R1250 0
    RHS                  R1251 0
    RHS                  R1252 0
    RHS                  R1253 0
    RHS                  R1254 0
    RHS                  R1255 0
    RHS                  R1256 0
    RHS                  R1257 0
    RHS                  R1258 0
    RHS                  R1259 0
    RHS                  R1260 -1358
    RHS                  R1261 0
    RHS                  R1262 0
    RHS                  R1263 0
    RHS                  R1264 0
    RHS                  R1265 0
    RHS                  R1266 0
    RHS                  R1267 0
    RHS                  R1268 0
    RHS                  R1269 0
    RHS                  R1270 0
    RHS                  R1271 0
    RHS                  R1272 0
    RHS                  R1273 0
    RHS                  R1274 -340
    RHS                  R1275 0
    RHS                  R1276 0
    RHS                  R1277 1940
    RHS                  R1278 0
    RHS                  R1279 0
    RHS                  R1280 0
    RHS                  R1281 0
    RHS                  R1282 0
    RHS                  R1283 0
    RHS                  R1284 0
    RHS                  R1285 1788
    RHS                  R1286 -128
    RHS                  R1287 0
    RHS                  R1288 0
    RHS                  R1289 0
    RHS                  R1290 0
    RHS                  R1291 0
    RHS                  R1292 0
    RHS                  R1293 0
    RHS                  R1294 0
    RHS                  R1295 0
    RHS                  R1296 0
    RHS                  R1297 -828
    RHS                  R1298 0
    RHS                  R1299 0
    RHS                  R1300 0
    RHS                  R1301 0
    RHS                  R1302 0
    RHS                  R1303 0
    RHS                  R1304 -168
    RHS                  R1305 0
    RHS                  R1306 0
    RHS                  R1307 -274
    RHS                  R1308 0
    RHS                  R1309 0
    RHS                  R1310 0
    RHS                  R1311 -176
    RHS                  R1312 0
    RHS                  R1313 0
    RHS                  R1314 -214
    RHS                  R1315 0
    RHS                  R1316 0
    RHS                  R1317 0
    RHS                  R1318 0
    RHS                  R1319 0
    RHS                  R1320 0
    RHS                  R1321 0
    RHS                  R1322 0
    RHS                  R1323 -568
    RHS                  R1324 0
    RHS                  R1325 0
    RHS                  R1326 0
    RHS                  R1327 0
    RHS                  R1328 0
    RHS                  R1329 0
    RHS                  R1330 0
    RHS                  R1331 0
    RHS                  R1332 0
    RHS                  R1333 0
    RHS                  R1334 1590
    RHS                  R1335 0
    RHS                  R1336 0
    RHS                  R1337 0
    RHS                  R1338 0
    RHS                  R1339 0
    RHS                  R1340 0
    RHS                  R1341 0
    RHS                  R1342 0
    RHS                  R1343 0
    RHS                  R1344 0
    RHS                  R1345 0
    RHS                  R1346 0
    RHS                  R1347 0
    RHS                  R1348 -1022
    RHS                  R1349 0
    RHS                  R1350 0
    RHS                  R1351 0
    RHS                  R1352 0
    RHS                  R1353 0
    RHS                  R1354 0
    RHS                  R1355 0
    RHS                  R1356 0
    RHS                  R1357 0
    RHS                  R1358 0
    RHS                  R1359 0
    RHS                  R1360 154
    RHS                  R1361 0
    RHS                  R1362 0
    RHS                  R1363 0
    RHS                  R1364 0
    RHS                  R1365 0
    RHS                  R1366 0
    RHS                  R1367 0
    RHS                  R1368 0
    RHS                  R1369 0
    RHS                  R1370 0
    RHS                  R1371 0
    RHS                  R1372 0
    RHS                  R1373 0
    RHS                  R1374 0
    RHS                  R1375 0
    RHS                  R1376 0
    RHS                  R1377 0
    RHS                  R1378 0
    RHS                  R1379 0
    RHS                  R1380 0
    RHS                  R1381 0
    RHS                  R1382 0
    RHS                  R1383 0
    RHS                  R1384 0
    RHS                  R1385 -154
    RHS                  R1386 0
    RHS                  R1387 0
    RHS                  R1388 0
    RHS                  R1389 -1
    RHS                  R1390 -1
    RHS                  R1391 -1
    RHS                  R1392 -1
    RHS                  R1393 -1
    RHS                  R1394 -1
    RHS                  R1395 -1
    RHS                  R1396 -1
    RHS                  R1397 -1
    RHS                  R1398 -1
    RHS                  R1399 -1
    RHS                  R1400 -1
    RHS                  R1401 -1
    RHS                  R1402 -1
    RHS                  R1403 -1
    RHS                  R1404 -1
    RHS                  R1405 -1
    RHS                  R1406 -1
    RHS                  R1407 -1
    RHS                  R1408 -1
    RHS                  R1409 -1
    RHS                  R1410 -1
    RHS                  R1411 -1
    RHS                  R1412 -1
    RHS                  R1413 -1
    RHS                  R1414 -1
    RHS                  R1415 -1
    RHS                  R1416 -1
    RHS                  R1417 -1
    RHS                  R1418 -1
    RHS                  R1419 -1
    RHS                  R1420 -1
    RHS                  R1421 -1
    RHS                  R1422 -1
    RHS                  R1423 -1
    RHS                  R1424 -1
    RHS                  R1425 -1
    RHS                  R1426 -1
    RHS                  R1427 -1
    RHS                  R1428 -1
    RHS                  R1429 -1
    RHS                  R1430 -1
    RHS                  R1431 -1
    RHS                  R1432 -1
    RHS                  R1433 -1
    RHS                  R1434 -1
    RHS                  R1435 -1
    RHS                  R1436 -1
    RHS                  R1437 -1
    RHS                  R1438 -1
    RHS                  R1439 -1
    RHS                  R1440 -1
    RHS                  R1441 -1
    RHS                  R1442 -1
    RHS                  R1443 -1
    RHS                  R1444 -1
    RHS                  R1445 -1
BOUNDS
 	FR BND X0
 	LO BND X0 0
 	UP BND X0 1
 	FR BND X1
 	LO BND X1 0
 	UP BND X1 1
 	FR BND X2
 	LO BND X2 0
 	UP BND X2 1
 	FR BND X3
 	LO BND X3 0
 	UP BND X3 1
 	FR BND X4
 	LO BND X4 0
 	UP BND X4 1
 	FR BND X5
 	LO BND X5 0
 	UP BND X5 1
 	FR BND X6
 	LO BND X6 0
 	UP BND X6 1
 	FR BND X7
 	LO BND X7 0
 	UP BND X7 1
 	FR BND X8
 	LO BND X8 0
 	UP BND X8 1
 	FR BND X9
 	LO BND X9 0
 	UP BND X9 1
 	FR BND X10
 	LO BND X10 0
 	UP BND X10 1
 	FR BND X11
 	LO BND X11 0
 	UP BND X11 1
 	FR BND X12
 	LO BND X12 0
 	UP BND X12 1
 	FR BND X13
 	LO BND X13 0
 	UP BND X13 1
 	FR BND X14
 	LO BND X14 0
 	UP BND X14 1
 	FR BND X15
 	LO BND X15 0
 	UP BND X15 1
 	FR BND X16
 	LO BND X16 0
 	UP BND X16 1
 	FR BND X17
 	LO BND X17 0
 	UP BND X17 1
 	FR BND X18
 	LO BND X18 0
 	UP BND X18 1
 	FR BND X19
 	LO BND X19 0
 	UP BND X19 1
 	FR BND X20
 	LO BND X20 0
 	UP BND X20 1
 	FR BND X21
 	LO BND X21 0
 	UP BND X21 1
 	FR BND X22
 	LO BND X22 0
 	UP BND X22 1
 	FR BND X23
 	LO BND X23 0
 	UP BND X23 1
 	FR BND X24
 	LO BND X24 0
 	UP BND X24 1
 	FR BND X25
 	LO BND X25 0
 	UP BND X25 1
 	FR BND X26
 	LO BND X26 0
 	UP BND X26 1
 	FR BND X27
 	LO BND X27 0
 	UP BND X27 1
 	FR BND X28
 	LO BND X28 0
 	UP BND X28 1
 	FR BND X29
 	LO BND X29 0
 	UP BND X29 1
 	FR BND X30
 	LO BND X30 0
 	UP BND X30 1
 	FR BND X31
 	LO BND X31 0
 	UP BND X31 1
 	FR BND X32
 	LO BND X32 0
 	UP BND X32 1
 	FR BND X33
 	LO BND X33 0
 	UP BND X33 1
 	FR BND X34
 	LO BND X34 0
 	UP BND X34 1
 	FR BND X35
 	LO BND X35 0
 	UP BND X35 1
 	FR BND X36
 	LO BND X36 0
 	UP BND X36 1
 	FR BND X37
 	LO BND X37 0
 	UP BND X37 1
 	FR BND X38
 	LO BND X38 0
 	UP BND X38 1
 	FR BND X39
 	LO BND X39 0
 	UP BND X39 1
 	FR BND X40
 	LO BND X40 0
 	UP BND X40 1
 	FR BND X41
 	LO BND X41 0
 	UP BND X41 1
 	FR BND X42
 	LO BND X42 0
 	UP BND X42 1
 	FR BND X43
 	LO BND X43 0
 	UP BND X43 1
 	FR BND X44
 	LO BND X44 0
 	UP BND X44 1
 	FR BND X45
 	LO BND X45 0
 	UP BND X45 1
 	FR BND X46
 	LO BND X46 0
 	UP BND X46 1
 	FR BND X47
 	LO BND X47 0
 	UP BND X47 1
 	FR BND X48
 	LO BND X48 0
 	UP BND X48 1
 	FR BND X49
 	LO BND X49 0
 	UP BND X49 1
 	FR BND X50
 	LO BND X50 0
 	UP BND X50 1
 	FR BND X51
 	LO BND X51 0
 	UP BND X51 1
 	FR BND X52
 	LO BND X52 0
 	UP BND X52 1
 	FR BND X53
 	LO BND X53 0
 	UP BND X53 1
 	FR BND X54
 	LO BND X54 0
 	UP BND X54 1
 	FR BND X55
 	LO BND X55 0
 	UP BND X55 1
 	FR BND X56
 	LO BND X56 0
 	UP BND X56 1
 	FR BND X57
 	LO BND X57 0
 	UP BND X57 1
 	FR BND X58
 	LO BND X58 0
 	UP BND X58 1
 	FR BND X59
 	LO BND X59 0
 	UP BND X59 1
 	FR BND X60
 	LO BND X60 0
 	UP BND X60 1
 	FR BND X61
 	LO BND X61 0
 	UP BND X61 1
 	FR BND X62
 	LO BND X62 0
 	UP BND X62 1
 	FR BND X63
 	LO BND X63 0
 	UP BND X63 1
 	FR BND X64
 	LO BND X64 0
 	UP BND X64 1
 	FR BND X65
 	LO BND X65 0
 	UP BND X65 1
 	FR BND X66
 	LO BND X66 0
 	UP BND X66 1
 	FR BND X67
 	LO BND X67 0
 	UP BND X67 1
 	FR BND X68
 	LO BND X68 0
 	UP BND X68 1
 	FR BND X69
 	LO BND X69 0
 	UP BND X69 1
 	FR BND X70
 	LO BND X70 0
 	UP BND X70 1
 	FR BND X71
 	LO BND X71 0
 	UP BND X71 1
 	FR BND X72
 	LO BND X72 0
 	UP BND X72 1
 	FR BND X73
 	LO BND X73 0
 	UP BND X73 1
 	FR BND X74
 	LO BND X74 0
 	UP BND X74 1
 	FR BND X75
 	LO BND X75 0
 	UP BND X75 1
 	FR BND X76
 	LO BND X76 0
 	UP BND X76 1
 	FR BND X77
 	LO BND X77 0
 	UP BND X77 1
 	FR BND X78
 	LO BND X78 0
 	UP BND X78 1
 	FR BND X79
 	LO BND X79 0
 	UP BND X79 1
 	FR BND X80
 	LO BND X80 0
 	UP BND X80 1
 	FR BND X81
 	LO BND X81 0
 	UP BND X81 1
 	FR BND X82
 	LO BND X82 0
 	UP BND X82 1
 	FR BND X83
 	LO BND X83 0
 	UP BND X83 1
 	FR BND X84
 	LO BND X84 0
 	UP BND X84 1
 	FR BND X85
 	LO BND X85 0
 	UP BND X85 1
 	FR BND X86
 	LO BND X86 0
 	UP BND X86 1
 	FR BND X87
 	LO BND X87 0
 	UP BND X87 1
 	FR BND X88
 	LO BND X88 0
 	UP BND X88 1
 	FR BND X89
 	LO BND X89 0
 	UP BND X89 1
 	FR BND X90
 	LO BND X90 0
 	UP BND X90 1
 	FR BND X91
 	LO BND X91 0
 	UP BND X91 1
 	FR BND X92
 	LO BND X92 0
 	UP BND X92 1
 	FR BND X93
 	LO BND X93 0
 	UP BND X93 1
 	FR BND X94
 	LO BND X94 0
 	UP BND X94 1
 	FR BND X95
 	LO BND X95 0
 	UP BND X95 1
 	FR BND X96
 	LO BND X96 0
 	UP BND X96 1
 	FR BND X97
 	LO BND X97 0
 	UP BND X97 1
 	FR BND X98
 	LO BND X98 0
 	UP BND X98 1
 	FR BND X99
 	LO BND X99 0
 	UP BND X99 1
 	FR BND X100
 	LO BND X100 0
 	UP BND X100 1
 	FR BND X101
 	LO BND X101 0
 	UP BND X101 1
 	FR BND X102
 	LO BND X102 0
 	UP BND X102 1
 	FR BND X103
 	LO BND X103 0
 	UP BND X103 1
 	FR BND X104
 	LO BND X104 0
 	UP BND X104 1
 	FR BND X105
 	LO BND X105 0
 	UP BND X105 1
 	FR BND X106
 	LO BND X106 0
 	UP BND X106 1
 	FR BND X107
 	LO BND X107 0
 	UP BND X107 1
 	FR BND X108
 	LO BND X108 0
 	UP BND X108 1
 	FR BND X109
 	LO BND X109 0
 	UP BND X109 1
 	FR BND X110
 	LO BND X110 0
 	UP BND X110 1
 	FR BND X111
 	LO BND X111 0
 	UP BND X111 1
 	FR BND X112
 	LO BND X112 0
 	UP BND X112 1
 	FR BND X113
 	LO BND X113 0
 	UP BND X113 1
 	FR BND X114
 	LO BND X114 0
 	UP BND X114 1
 	FR BND X115
 	LO BND X115 0
 	UP BND X115 1
 	FR BND X116
 	LO BND X116 0
 	UP BND X116 1
 	FR BND X117
 	LO BND X117 0
 	UP BND X117 1
 	FR BND X118
 	LO BND X118 0
 	UP BND X118 1
 	FR BND X119
 	LO BND X119 0
 	UP BND X119 1
 	FR BND X120
 	LO BND X120 0
 	UP BND X120 1
 	FR BND X121
 	LO BND X121 0
 	UP BND X121 1
 	FR BND X122
 	LO BND X122 0
 	UP BND X122 1
 	FR BND X123
 	LO BND X123 0
 	UP BND X123 1
 	FR BND X124
 	LO BND X124 0
 	UP BND X124 1
 	FR BND X125
 	LO BND X125 0
 	UP BND X125 1
 	FR BND X126
 	LO BND X126 0
 	UP BND X126 1
 	FR BND X127
 	LO BND X127 0
 	UP BND X127 1
 	FR BND X128
 	LO BND X128 0
 	UP BND X128 1
 	FR BND X129
 	LO BND X129 0
 	UP BND X129 1
 	FR BND X130
 	LO BND X130 0
 	UP BND X130 1
 	FR BND X131
 	LO BND X131 0
 	UP BND X131 1
 	FR BND X132
 	LO BND X132 0
 	UP BND X132 1
 	FR BND X133
 	LO BND X133 0
 	UP BND X133 1
 	FR BND X134
 	LO BND X134 0
 	UP BND X134 1
 	FR BND X135
 	LO BND X135 0
 	UP BND X135 1
 	FR BND X136
 	LO BND X136 0
 	UP BND X136 1
 	FR BND X137
 	LO BND X137 0
 	UP BND X137 1
 	FR BND X138
 	LO BND X138 0
 	UP BND X138 1
 	FR BND X139
 	LO BND X139 0
 	UP BND X139 1
 	FR BND X140
 	LO BND X140 0
 	UP BND X140 1
 	FR BND X141
 	LO BND X141 0
 	UP BND X141 1
 	FR BND X142
 	LO BND X142 0
 	UP BND X142 1
 	FR BND X143
 	LO BND X143 0
 	UP BND X143 1
 	FR BND X144
 	LO BND X144 0
 	UP BND X144 1
 	FR BND X145
 	LO BND X145 0
 	UP BND X145 1
 	FR BND X146
 	LO BND X146 0
 	UP BND X146 1
 	FR BND X147
 	LO BND X147 0
 	UP BND X147 1
 	FR BND X148
 	LO BND X148 0
 	UP BND X148 1
 	FR BND X149
 	LO BND X149 0
 	UP BND X149 1
 	FR BND X150
 	LO BND X150 0
 	UP BND X150 1
 	FR BND X151
 	LO BND X151 0
 	UP BND X151 1
 	FR BND X152
 	LO BND X152 0
 	UP BND X152 1
 	FR BND X153
 	LO BND X153 0
 	UP BND X153 1
 	FR BND X154
 	LO BND X154 0
 	UP BND X154 1
 	FR BND X155
 	LO BND X155 0
 	UP BND X155 1
 	FR BND X156
 	LO BND X156 0
 	UP BND X156 1
 	FR BND X157
 	LO BND X157 0
 	UP BND X157 1
 	FR BND X158
 	LO BND X158 0
 	UP BND X158 1
 	FR BND X159
 	LO BND X159 0
 	UP BND X159 1
 	FR BND X160
 	LO BND X160 0
 	UP BND X160 1
 	FR BND X161
 	LO BND X161 0
 	UP BND X161 1
 	FR BND X162
 	LO BND X162 0
 	UP BND X162 1
 	FR BND X163
 	LO BND X163 0
 	UP BND X163 1
 	FR BND X164
 	LO BND X164 0
 	UP BND X164 1
 	FR BND X165
 	LO BND X165 0
 	UP BND X165 1
 	FR BND X166
 	LO BND X166 0
 	UP BND X166 1
 	FR BND X167
 	LO BND X167 0
 	UP BND X167 1
 	FR BND X168
 	LO BND X168 0
 	UP BND X168 1
 	FR BND X169
 	LO BND X169 0
 	UP BND X169 1
 	FR BND X170
 	LO BND X170 0
 	UP BND X170 1
 	FR BND X171
 	LO BND X171 0
 	FR BND X172
 	LO BND X172 0
 	FR BND X173
 	LO BND X173 0
 	FR BND X174
 	LO BND X174 0
 	FR BND X175
 	LO BND X175 0
 	FR BND X176
 	LO BND X176 0
 	FR BND X177
 	LO BND X177 0
 	FR BND X178
 	LO BND X178 0
 	FR BND X179
 	LO BND X179 0
 	FR BND X180
 	LO BND X180 0
 	FR BND X181
 	LO BND X181 0
 	FR BND X182
 	LO BND X182 0
 	FR BND X183
 	LO BND X183 0
 	FR BND X184
 	LO BND X184 0
 	FR BND X185
 	LO BND X185 0
 	FR BND X186
 	LO BND X186 0
 	FR BND X187
 	LO BND X187 0
 	FR BND X188
 	LO BND X188 0
 	FR BND X189
 	LO BND X189 0
 	FR BND X190
 	LO BND X190 0
 	FR BND X191
 	LO BND X191 0
 	FR BND X192
 	LO BND X192 0
 	FR BND X193
 	LO BND X193 0
 	FR BND X194
 	LO BND X194 0
 	FR BND X195
 	LO BND X195 0
 	FR BND X196
 	LO BND X196 0
 	FR BND X197
 	LO BND X197 0
 	FR BND X198
 	LO BND X198 0
 	FR BND X199
 	LO BND X199 0
 	FR BND X200
 	LO BND X200 0
 	FR BND X201
 	LO BND X201 0
 	FR BND X202
 	LO BND X202 0
 	FR BND X203
 	LO BND X203 0
 	FR BND X204
 	LO BND X204 0
 	FR BND X205
 	LO BND X205 0
 	FR BND X206
 	LO BND X206 0
 	FR BND X207
 	LO BND X207 0
 	FR BND X208
 	LO BND X208 0
 	FR BND X209
 	LO BND X209 0
 	FR BND X210
 	LO BND X210 0
 	FR BND X211
 	LO BND X211 0
 	FR BND X212
 	LO BND X212 0
 	FR BND X213
 	LO BND X213 0
 	FR BND X214
 	LO BND X214 0
 	FR BND X215
 	LO BND X215 0
 	FR BND X216
 	LO BND X216 0
 	FR BND X217
 	LO BND X217 0
 	FR BND X218
 	LO BND X218 0
 	FR BND X219
 	LO BND X219 0
 	FR BND X220
 	LO BND X220 0
 	FR BND X221
 	LO BND X221 0
 	FR BND X222
 	LO BND X222 0
 	FR BND X223
 	LO BND X223 0
 	FR BND X224
 	LO BND X224 0
 	FR BND X225
 	LO BND X225 0
 	FR BND X226
 	LO BND X226 0
 	FR BND X227
 	LO BND X227 0
 	FR BND X228
 	LO BND X228 0
 	FR BND X229
 	LO BND X229 0
 	FR BND X230
 	LO BND X230 0
 	FR BND X231
 	LO BND X231 0
 	FR BND X232
 	LO BND X232 0
 	FR BND X233
 	LO BND X233 0
 	FR BND X234
 	LO BND X234 0
 	FR BND X235
 	LO BND X235 0
 	FR BND X236
 	LO BND X236 0
 	FR BND X237
 	LO BND X237 0
 	FR BND X238
 	LO BND X238 0
 	FR BND X239
 	LO BND X239 0
 	FR BND X240
 	LO BND X240 0
 	FR BND X241
 	LO BND X241 0
 	FR BND X242
 	LO BND X242 0
 	FR BND X243
 	LO BND X243 0
 	FR BND X244
 	LO BND X244 0
 	FR BND X245
 	LO BND X245 0
 	FR BND X246
 	LO BND X246 0
 	FR BND X247
 	LO BND X247 0
 	FR BND X248
 	LO BND X248 0
 	FR BND X249
 	LO BND X249 0
 	FR BND X250
 	LO BND X250 0
 	FR BND X251
 	LO BND X251 0
 	FR BND X252
 	LO BND X252 0
 	FR BND X253
 	LO BND X253 0
 	FR BND X254
 	LO BND X254 0
 	FR BND X255
 	LO BND X255 0
 	FR BND X256
 	LO BND X256 0
 	FR BND X257
 	LO BND X257 0
 	FR BND X258
 	LO BND X258 0
 	FR BND X259
 	LO BND X259 0
 	FR BND X260
 	LO BND X260 0
 	FR BND X261
 	LO BND X261 0
 	FR BND X262
 	LO BND X262 0
 	FR BND X263
 	LO BND X263 0
 	FR BND X264
 	LO BND X264 0
 	FR BND X265
 	LO BND X265 0
 	FR BND X266
 	LO BND X266 0
 	FR BND X267
 	LO BND X267 0
 	FR BND X268
 	LO BND X268 0
 	FR BND X269
 	LO BND X269 0
 	FR BND X270
 	LO BND X270 0
 	FR BND X271
 	LO BND X271 0
 	FR BND X272
 	LO BND X272 0
 	FR BND X273
 	LO BND X273 0
 	FR BND X274
 	LO BND X274 0
 	FR BND X275
 	LO BND X275 0
 	FR BND X276
 	LO BND X276 0
 	FR BND X277
 	LO BND X277 0
 	FR BND X278
 	LO BND X278 0
 	FR BND X279
 	LO BND X279 0
 	FR BND X280
 	LO BND X280 0
 	FR BND X281
 	LO BND X281 0
 	FR BND X282
 	LO BND X282 0
 	FR BND X283
 	LO BND X283 0
 	FR BND X284
 	LO BND X284 0
 	FR BND X285
 	LO BND X285 0
 	FR BND X286
 	LO BND X286 0
 	FR BND X287
 	LO BND X287 0
 	FR BND X288
 	LO BND X288 0
 	FR BND X289
 	LO BND X289 0
 	FR BND X290
 	LO BND X290 0
 	FR BND X291
 	LO BND X291 0
 	FR BND X292
 	LO BND X292 0
 	FR BND X293
 	LO BND X293 0
 	FR BND X294
 	LO BND X294 0
 	FR BND X295
 	LO BND X295 0
 	FR BND X296
 	LO BND X296 0
 	FR BND X297
 	LO BND X297 0
 	FR BND X298
 	LO BND X298 0
 	FR BND X299
 	LO BND X299 0
 	FR BND X300
 	LO BND X300 0
 	FR BND X301
 	LO BND X301 0
 	FR BND X302
 	LO BND X302 0
 	FR BND X303
 	LO BND X303 0
 	FR BND X304
 	LO BND X304 0
 	FR BND X305
 	LO BND X305 0
 	FR BND X306
 	LO BND X306 0
 	FR BND X307
 	LO BND X307 0
 	FR BND X308
 	LO BND X308 0
 	FR BND X309
 	LO BND X309 0
 	FR BND X310
 	LO BND X310 0
 	FR BND X311
 	LO BND X311 0
 	FR BND X312
 	LO BND X312 0
 	FR BND X313
 	LO BND X313 0
 	FR BND X314
 	LO BND X314 0
 	FR BND X315
 	LO BND X315 0
 	FR BND X316
 	LO BND X316 0
 	FR BND X317
 	LO BND X317 0
 	FR BND X318
 	LO BND X318 0
 	FR BND X319
 	LO BND X319 0
 	FR BND X320
 	LO BND X320 0
 	FR BND X321
 	LO BND X321 0
 	FR BND X322
 	LO BND X322 0
 	FR BND X323
 	LO BND X323 0
 	FR BND X324
 	LO BND X324 0
 	FR BND X325
 	LO BND X325 0
 	FR BND X326
 	LO BND X326 0
 	FR BND X327
 	LO BND X327 0
 	FR BND X328
 	LO BND X328 0
 	FR BND X329
 	LO BND X329 0
 	FR BND X330
 	LO BND X330 0
 	FR BND X331
 	LO BND X331 0
 	FR BND X332
 	LO BND X332 0
 	FR BND X333
 	LO BND X333 0
 	FR BND X334
 	LO BND X334 0
 	FR BND X335
 	LO BND X335 0
 	FR BND X336
 	LO BND X336 0
 	FR BND X337
 	LO BND X337 0
 	FR BND X338
 	LO BND X338 0
 	FR BND X339
 	LO BND X339 0
 	FR BND X340
 	LO BND X340 0
 	FR BND X341
 	LO BND X341 0
 	FR BND X342
 	LO BND X342 0
 	FR BND X343
 	LO BND X343 0
 	FR BND X344
 	LO BND X344 0
 	FR BND X345
 	LO BND X345 0
 	FR BND X346
 	LO BND X346 0
 	FR BND X347
 	LO BND X347 0
 	FR BND X348
 	LO BND X348 0
 	FR BND X349
 	LO BND X349 0
 	FR BND X350
 	LO BND X350 0
 	FR BND X351
 	LO BND X351 0
 	FR BND X352
 	LO BND X352 0
 	FR BND X353
 	LO BND X353 0
 	FR BND X354
 	LO BND X354 0
 	FR BND X355
 	LO BND X355 0
 	FR BND X356
 	LO BND X356 0
 	FR BND X357
 	LO BND X357 0
 	FR BND X358
 	LO BND X358 0
 	FR BND X359
 	LO BND X359 0
 	FR BND X360
 	LO BND X360 0
 	FR BND X361
 	LO BND X361 0
 	FR BND X362
 	LO BND X362 0
 	FR BND X363
 	LO BND X363 0
 	FR BND X364
 	LO BND X364 0
 	FR BND X365
 	LO BND X365 0
 	FR BND X366
 	LO BND X366 0
 	FR BND X367
 	LO BND X367 0
 	FR BND X368
 	LO BND X368 0
 	FR BND X369
 	LO BND X369 0
 	FR BND X370
 	LO BND X370 0
 	FR BND X371
 	LO BND X371 0
 	FR BND X372
 	LO BND X372 0
 	FR BND X373
 	LO BND X373 0
 	FR BND X374
 	LO BND X374 0
 	FR BND X375
 	LO BND X375 0
 	FR BND X376
 	LO BND X376 0
 	FR BND X377
 	LO BND X377 0
 	FR BND X378
 	LO BND X378 0
 	FR BND X379
 	LO BND X379 0
 	FR BND X380
 	LO BND X380 0
 	FR BND X381
 	LO BND X381 0
 	FR BND X382
 	LO BND X382 0
 	FR BND X383
 	LO BND X383 0
 	FR BND X384
 	LO BND X384 0
 	FR BND X385
 	LO BND X385 0
 	FR BND X386
 	LO BND X386 0
 	FR BND X387
 	LO BND X387 0
 	FR BND X388
 	LO BND X388 0
 	FR BND X389
 	LO BND X389 0
 	FR BND X390
 	LO BND X390 0
 	FR BND X391
 	LO BND X391 0
 	FR BND X392
 	LO BND X392 0
 	FR BND X393
 	LO BND X393 0
 	FR BND X394
 	LO BND X394 0
 	FR BND X395
 	LO BND X395 0
 	FR BND X396
 	LO BND X396 0
 	FR BND X397
 	LO BND X397 0
 	FR BND X398
 	LO BND X398 0
 	FR BND X399
 	LO BND X399 0
 	FR BND X400
 	LO BND X400 0
 	FR BND X401
 	LO BND X401 0
 	FR BND X402
 	LO BND X402 0
 	FR BND X403
 	LO BND X403 0
 	FR BND X404
 	LO BND X404 0
 	FR BND X405
 	LO BND X405 0
 	FR BND X406
 	LO BND X406 0
 	FR BND X407
 	LO BND X407 0
 	FR BND X408
 	LO BND X408 0
 	FR BND X409
 	LO BND X409 0
 	FR BND X410
 	LO BND X410 0
 	FR BND X411
 	LO BND X411 0
 	FR BND X412
 	LO BND X412 0
 	FR BND X413
 	LO BND X413 0
 	FR BND X414
 	LO BND X414 0
 	FR BND X415
 	LO BND X415 0
 	FR BND X416
 	LO BND X416 0
 	FR BND X417
 	LO BND X417 0
 	FR BND X418
 	LO BND X418 0
 	FR BND X419
 	LO BND X419 0
 	FR BND X420
 	LO BND X420 0
 	FR BND X421
 	LO BND X421 0
 	FR BND X422
 	LO BND X422 0
 	FR BND X423
 	LO BND X423 0
 	FR BND X424
 	LO BND X424 0
 	FR BND X425
 	LO BND X425 0
 	FR BND X426
 	LO BND X426 0
 	FR BND X427
 	LO BND X427 0
 	FR BND X428
 	LO BND X428 0
 	FR BND X429
 	LO BND X429 0
 	FR BND X430
 	LO BND X430 0
 	FR BND X431
 	LO BND X431 0
 	FR BND X432
 	LO BND X432 0
 	FR BND X433
 	LO BND X433 0
 	FR BND X434
 	LO BND X434 0
 	FR BND X435
 	LO BND X435 0
 	FR BND X436
 	LO BND X436 0
 	FR BND X437
 	LO BND X437 0
 	FR BND X438
 	LO BND X438 0
 	FR BND X439
 	LO BND X439 0
 	FR BND X440
 	LO BND X440 0
 	FR BND X441
 	LO BND X441 0
 	FR BND X442
 	LO BND X442 0
 	FR BND X443
 	LO BND X443 0
 	FR BND X444
 	LO BND X444 0
 	FR BND X445
 	LO BND X445 0
 	FR BND X446
 	LO BND X446 0
 	FR BND X447
 	LO BND X447 0
 	FR BND X448
 	LO BND X448 0
 	FR BND X449
 	LO BND X449 0
 	FR BND X450
 	LO BND X450 0
 	FR BND X451
 	LO BND X451 0
 	FR BND X452
 	LO BND X452 0
 	FR BND X453
 	LO BND X453 0
 	FR BND X454
 	LO BND X454 0
 	FR BND X455
 	LO BND X455 0
 	FR BND X456
 	LO BND X456 0
 	FR BND X457
 	LO BND X457 0
 	FR BND X458
 	LO BND X458 0
 	FR BND X459
 	LO BND X459 0
 	FR BND X460
 	LO BND X460 0
 	FR BND X461
 	LO BND X461 0
 	FR BND X462
 	LO BND X462 0
 	FR BND X463
 	LO BND X463 0
 	FR BND X464
 	LO BND X464 0
 	FR BND X465
 	LO BND X465 0
 	FR BND X466
 	LO BND X466 0
 	FR BND X467
 	LO BND X467 0
 	FR BND X468
 	LO BND X468 0
 	FR BND X469
 	LO BND X469 0
 	FR BND X470
 	LO BND X470 0
 	FR BND X471
 	LO BND X471 0
 	FR BND X472
 	LO BND X472 0
 	FR BND X473
 	LO BND X473 0
 	FR BND X474
 	LO BND X474 0
 	FR BND X475
 	LO BND X475 0
 	FR BND X476
 	LO BND X476 0
 	FR BND X477
 	LO BND X477 0
 	FR BND X478
 	LO BND X478 0
 	FR BND X479
 	LO BND X479 0
 	FR BND X480
 	LO BND X480 0
 	FR BND X481
 	LO BND X481 0
 	FR BND X482
 	LO BND X482 0
 	FR BND X483
 	LO BND X483 0
 	FR BND X484
 	LO BND X484 0
 	FR BND X485
 	LO BND X485 0
 	FR BND X486
 	LO BND X486 0
 	FR BND X487
 	LO BND X487 0
 	FR BND X488
 	LO BND X488 0
 	FR BND X489
 	LO BND X489 0
 	FR BND X490
 	LO BND X490 0
 	FR BND X491
 	LO BND X491 0
 	FR BND X492
 	LO BND X492 0
 	FR BND X493
 	LO BND X493 0
 	FR BND X494
 	LO BND X494 0
 	FR BND X495
 	LO BND X495 0
 	FR BND X496
 	LO BND X496 0
 	FR BND X497
 	LO BND X497 0
 	FR BND X498
 	LO BND X498 0
 	FR BND X499
 	LO BND X499 0
 	FR BND X500
 	LO BND X500 0
 	FR BND X501
 	LO BND X501 0
 	FR BND X502
 	LO BND X502 0
 	FR BND X503
 	LO BND X503 0
 	FR BND X504
 	LO BND X504 0
 	FR BND X505
 	LO BND X505 0
 	FR BND X506
 	LO BND X506 0
 	FR BND X507
 	LO BND X507 0
 	FR BND X508
 	LO BND X508 0
 	FR BND X509
 	LO BND X509 0
 	FR BND X510
 	LO BND X510 0
 	FR BND X511
 	LO BND X511 0
 	FR BND X512
 	LO BND X512 0
 	FR BND X513
 	LO BND X513 0
 	FR BND X514
 	LO BND X514 0
 	FR BND X515
 	LO BND X515 0
 	FR BND X516
 	LO BND X516 0
 	FR BND X517
 	LO BND X517 0
 	FR BND X518
 	LO BND X518 0
 	FR BND X519
 	LO BND X519 0
 	FR BND X520
 	LO BND X520 0
 	FR BND X521
 	LO BND X521 0
 	FR BND X522
 	LO BND X522 0
 	FR BND X523
 	LO BND X523 0
 	FR BND X524
 	LO BND X524 0
 	FR BND X525
 	LO BND X525 0
 	FR BND X526
 	LO BND X526 0
 	FR BND X527
 	LO BND X527 0
 	FR BND X528
 	LO BND X528 0
 	FR BND X529
 	LO BND X529 0
 	FR BND X530
 	LO BND X530 0
 	FR BND X531
 	LO BND X531 0
 	FR BND X532
 	LO BND X532 0
 	FR BND X533
 	LO BND X533 0
 	FR BND X534
 	LO BND X534 0
 	FR BND X535
 	LO BND X535 0
 	FR BND X536
 	LO BND X536 0
 	FR BND X537
 	LO BND X537 0
 	FR BND X538
 	LO BND X538 0
 	FR BND X539
 	LO BND X539 0
 	FR BND X540
 	LO BND X540 0
 	FR BND X541
 	LO BND X541 0
 	FR BND X542
 	LO BND X542 0
 	FR BND X543
 	LO BND X543 0
 	FR BND X544
 	LO BND X544 0
 	FR BND X545
 	LO BND X545 0
 	FR BND X546
 	LO BND X546 0
 	FR BND X547
 	LO BND X547 0
 	FR BND X548
 	LO BND X548 0
 	FR BND X549
 	LO BND X549 0
 	FR BND X550
 	LO BND X550 0
 	FR BND X551
 	LO BND X551 0
 	FR BND X552
 	LO BND X552 0
 	FR BND X553
 	LO BND X553 0
 	FR BND X554
 	LO BND X554 0
 	FR BND X555
 	LO BND X555 0
 	FR BND X556
 	LO BND X556 0
 	FR BND X557
 	LO BND X557 0
 	FR BND X558
 	LO BND X558 0
 	FR BND X559
 	LO BND X559 0
 	FR BND X560
 	LO BND X560 0
 	FR BND X561
 	LO BND X561 0
 	FR BND X562
 	LO BND X562 0
 	FR BND X563
 	LO BND X563 0
 	FR BND X564
 	LO BND X564 0
 	FR BND X565
 	LO BND X565 0
 	FR BND X566
 	LO BND X566 0
 	FR BND X567
 	LO BND X567 0
 	FR BND X568
 	LO BND X568 0
 	FR BND X569
 	LO BND X569 0
 	FR BND X570
 	LO BND X570 0
 	FR BND X571
 	LO BND X571 0
 	FR BND X572
 	LO BND X572 0
 	FR BND X573
 	LO BND X573 0
 	FR BND X574
 	LO BND X574 0
 	FR BND X575
 	LO BND X575 0
 	FR BND X576
 	LO BND X576 0
 	FR BND X577
 	LO BND X577 0
 	FR BND X578
 	LO BND X578 0
 	FR BND X579
 	LO BND X579 0
 	FR BND X580
 	LO BND X580 0
 	FR BND X581
 	LO BND X581 0
 	FR BND X582
 	LO BND X582 0
 	FR BND X583
 	LO BND X583 0
 	FR BND X584
 	LO BND X584 0
 	FR BND X585
 	LO BND X585 0
 	FR BND X586
 	LO BND X586 0
 	FR BND X587
 	LO BND X587 0
 	FR BND X588
 	LO BND X588 0
 	FR BND X589
 	LO BND X589 0
 	FR BND X590
 	LO BND X590 0
 	FR BND X591
 	LO BND X591 0
 	FR BND X592
 	LO BND X592 0
 	FR BND X593
 	LO BND X593 0
 	FR BND X594
 	LO BND X594 0
 	FR BND X595
 	LO BND X595 0
 	FR BND X596
 	LO BND X596 0
 	FR BND X597
 	LO BND X597 0
 	FR BND X598
 	LO BND X598 0
 	FR BND X599
 	LO BND X599 0
 	FR BND X600
 	LO BND X600 0
 	FR BND X601
 	LO BND X601 0
 	FR BND X602
 	LO BND X602 0
 	FR BND X603
 	LO BND X603 0
 	FR BND X604
 	LO BND X604 0
 	FR BND X605
 	LO BND X605 0
 	FR BND X606
 	LO BND X606 0
 	FR BND X607
 	LO BND X607 0
 	FR BND X608
 	LO BND X608 0
 	FR BND X609
 	LO BND X609 0
 	FR BND X610
 	LO BND X610 0
 	FR BND X611
 	LO BND X611 0
 	FR BND X612
 	LO BND X612 0
 	FR BND X613
 	LO BND X613 0
 	FR BND X614
 	LO BND X614 0
 	FR BND X615
 	LO BND X615 0
 	FR BND X616
 	LO BND X616 0
 	FR BND X617
 	LO BND X617 0
 	FR BND X618
 	LO BND X618 0
 	FR BND X619
 	LO BND X619 0
 	FR BND X620
 	LO BND X620 0
 	FR BND X621
 	LO BND X621 0
 	FR BND X622
 	LO BND X622 0
 	FR BND X623
 	LO BND X623 0
 	FR BND X624
 	LO BND X624 0
 	FR BND X625
 	LO BND X625 0
 	FR BND X626
 	LO BND X626 0
 	FR BND X627
 	LO BND X627 0
 	FR BND X628
 	LO BND X628 0
 	FR BND X629
 	LO BND X629 0
 	FR BND X630
 	LO BND X630 0
 	FR BND X631
 	LO BND X631 0
 	FR BND X632
 	LO BND X632 0
 	FR BND X633
 	LO BND X633 0
 	FR BND X634
 	LO BND X634 0
 	FR BND X635
 	LO BND X635 0
 	FR BND X636
 	LO BND X636 0
 	FR BND X637
 	LO BND X637 0
 	FR BND X638
 	LO BND X638 0
 	FR BND X639
 	LO BND X639 0
 	FR BND X640
 	LO BND X640 0
 	FR BND X641
 	LO BND X641 0
 	FR BND X642
 	LO BND X642 0
 	FR BND X643
 	LO BND X643 0
 	FR BND X644
 	LO BND X644 0
 	FR BND X645
 	LO BND X645 0
 	FR BND X646
 	LO BND X646 0
 	FR BND X647
 	LO BND X647 0
 	FR BND X648
 	LO BND X648 0
 	FR BND X649
 	LO BND X649 0
 	FR BND X650
 	LO BND X650 0
 	FR BND X651
 	LO BND X651 0
 	FR BND X652
 	LO BND X652 0
 	FR BND X653
 	LO BND X653 0
 	FR BND X654
 	LO BND X654 0
 	FR BND X655
 	LO BND X655 0
 	FR BND X656
 	LO BND X656 0
 	FR BND X657
 	LO BND X657 0
 	FR BND X658
 	LO BND X658 0
 	FR BND X659
 	LO BND X659 0
 	FR BND X660
 	LO BND X660 0
 	FR BND X661
 	LO BND X661 0
 	FR BND X662
 	LO BND X662 0
 	FR BND X663
 	LO BND X663 0
 	FR BND X664
 	LO BND X664 0
 	FR BND X665
 	LO BND X665 0
 	FR BND X666
 	LO BND X666 0
 	FR BND X667
 	LO BND X667 0
 	FR BND X668
 	LO BND X668 0
 	FR BND X669
 	LO BND X669 0
 	FR BND X670
 	LO BND X670 0
 	FR BND X671
 	LO BND X671 0
 	FR BND X672
 	LO BND X672 0
 	FR BND X673
 	LO BND X673 0
 	FR BND X674
 	LO BND X674 0
 	FR BND X675
 	LO BND X675 0
 	FR BND X676
 	LO BND X676 0
 	FR BND X677
 	LO BND X677 0
 	FR BND X678
 	LO BND X678 0
 	FR BND X679
 	LO BND X679 0
 	FR BND X680
 	LO BND X680 0
 	FR BND X681
 	LO BND X681 0
 	FR BND X682
 	LO BND X682 0
 	FR BND X683
 	LO BND X683 0
 	FR BND X684
 	LO BND X684 0
 	FR BND X685
 	LO BND X685 0
 	FR BND X686
 	LO BND X686 0
 	FR BND X687
 	LO BND X687 0
 	FR BND X688
 	LO BND X688 0
 	FR BND X689
 	LO BND X689 0
 	FR BND X690
 	LO BND X690 0
 	FR BND X691
 	LO BND X691 0
 	FR BND X692
 	LO BND X692 0
 	FR BND X693
 	LO BND X693 0
 	FR BND X694
 	LO BND X694 0
 	FR BND X695
 	LO BND X695 0
 	FR BND X696
 	LO BND X696 0
 	FR BND X697
 	LO BND X697 0
 	FR BND X698
 	LO BND X698 0
 	FR BND X699
 	LO BND X699 0
 	FR BND X700
 	LO BND X700 0
 	FR BND X701
 	LO BND X701 0
 	FR BND X702
 	LO BND X702 0
 	FR BND X703
 	LO BND X703 0
 	FR BND X704
 	LO BND X704 0
 	FR BND X705
 	LO BND X705 0
 	FR BND X706
 	LO BND X706 0
 	FR BND X707
 	LO BND X707 0
 	FR BND X708
 	LO BND X708 0
 	FR BND X709
 	LO BND X709 0
 	FR BND X710
 	LO BND X710 0
 	FR BND X711
 	LO BND X711 0
 	FR BND X712
 	LO BND X712 0
 	FR BND X713
 	LO BND X713 0
 	FR BND X714
 	LO BND X714 0
 	FR BND X715
 	LO BND X715 0
 	FR BND X716
 	LO BND X716 0
 	FR BND X717
 	LO BND X717 0
 	FR BND X718
 	LO BND X718 0
 	FR BND X719
 	LO BND X719 0
 	FR BND X720
 	LO BND X720 0
 	FR BND X721
 	LO BND X721 0
 	FR BND X722
 	LO BND X722 0
 	FR BND X723
 	LO BND X723 0
 	FR BND X724
 	LO BND X724 0
 	FR BND X725
 	LO BND X725 0
 	FR BND X726
 	LO BND X726 0
 	FR BND X727
 	LO BND X727 0
 	FR BND X728
 	LO BND X728 0
 	FR BND X729
 	LO BND X729 0
 	FR BND X730
 	LO BND X730 0
 	FR BND X731
 	LO BND X731 0
 	FR BND X732
 	LO BND X732 0
 	FR BND X733
 	LO BND X733 0
 	FR BND X734
 	LO BND X734 0
 	FR BND X735
 	LO BND X735 0
 	FR BND X736
 	LO BND X736 0
 	FR BND X737
 	LO BND X737 0
 	FR BND X738
 	LO BND X738 0
 	FR BND X739
 	LO BND X739 0
 	FR BND X740
 	LO BND X740 0
 	FR BND X741
 	LO BND X741 0
 	FR BND X742
 	LO BND X742 0
 	FR BND X743
 	LO BND X743 0
 	FR BND X744
 	LO BND X744 0
 	FR BND X745
 	LO BND X745 0
 	FR BND X746
 	LO BND X746 0
 	FR BND X747
 	LO BND X747 0
 	FR BND X748
 	LO BND X748 0
 	FR BND X749
 	LO BND X749 0
 	FR BND X750
 	LO BND X750 0
 	FR BND X751
 	LO BND X751 0
 	FR BND X752
 	LO BND X752 0
 	FR BND X753
 	LO BND X753 0
 	FR BND X754
 	LO BND X754 0
 	FR BND X755
 	LO BND X755 0
 	FR BND X756
 	LO BND X756 0
 	FR BND X757
 	LO BND X757 0
 	FR BND X758
 	LO BND X758 0
 	FR BND X759
 	LO BND X759 0
 	FR BND X760
 	LO BND X760 0
 	FR BND X761
 	LO BND X761 0
 	FR BND X762
 	LO BND X762 0
 	FR BND X763
 	LO BND X763 0
 	FR BND X764
 	LO BND X764 0
 	FR BND X765
 	LO BND X765 0
 	FR BND X766
 	LO BND X766 0
 	FR BND X767
 	LO BND X767 0
 	FR BND X768
 	LO BND X768 0
 	FR BND X769
 	LO BND X769 0
 	FR BND X770
 	LO BND X770 0
 	FR BND X771
 	LO BND X771 0
 	FR BND X772
 	LO BND X772 0
 	FR BND X773
 	LO BND X773 0
 	FR BND X774
 	LO BND X774 0
 	FR BND X775
 	LO BND X775 0
 	FR BND X776
 	LO BND X776 0
 	FR BND X777
 	LO BND X777 0
 	FR BND X778
 	LO BND X778 0
 	FR BND X779
 	LO BND X779 0
 	FR BND X780
 	LO BND X780 0
 	FR BND X781
 	LO BND X781 0
 	FR BND X782
 	LO BND X782 0
 	FR BND X783
 	LO BND X783 0
 	FR BND X784
 	LO BND X784 0
 	FR BND X785
 	LO BND X785 0
 	FR BND X786
 	LO BND X786 0
 	FR BND X787
 	LO BND X787 0
 	FR BND X788
 	LO BND X788 0
 	FR BND X789
 	LO BND X789 0
 	FR BND X790
 	LO BND X790 0
 	FR BND X791
 	LO BND X791 0
 	FR BND X792
 	LO BND X792 0
 	FR BND X793
 	LO BND X793 0
 	FR BND X794
 	LO BND X794 0
 	FR BND X795
 	LO BND X795 0
 	FR BND X796
 	LO BND X796 0
 	FR BND X797
 	LO BND X797 0
 	FR BND X798
 	LO BND X798 0
 	FR BND X799
 	LO BND X799 0
 	FR BND X800
 	LO BND X800 0
 	FR BND X801
 	LO BND X801 0
 	FR BND X802
 	LO BND X802 0
 	FR BND X803
 	LO BND X803 0
 	FR BND X804
 	LO BND X804 0
 	FR BND X805
 	LO BND X805 0
 	FR BND X806
 	LO BND X806 0
 	FR BND X807
 	LO BND X807 0
 	FR BND X808
 	LO BND X808 0
 	FR BND X809
 	LO BND X809 0
 	FR BND X810
 	LO BND X810 0
 	FR BND X811
 	LO BND X811 0
 	FR BND X812
 	LO BND X812 0
 	FR BND X813
 	LO BND X813 0
 	FR BND X814
 	LO BND X814 0
 	FR BND X815
 	LO BND X815 0
 	FR BND X816
 	LO BND X816 0
 	FR BND X817
 	LO BND X817 0
 	FR BND X818
 	LO BND X818 0
 	FR BND X819
 	LO BND X819 0
 	FR BND X820
 	LO BND X820 0
 	FR BND X821
 	LO BND X821 0
 	FR BND X822
 	LO BND X822 0
 	FR BND X823
 	LO BND X823 0
 	FR BND X824
 	LO BND X824 0
 	FR BND X825
 	LO BND X825 0
 	FR BND X826
 	LO BND X826 0
 	FR BND X827
 	LO BND X827 0
 	FR BND X828
 	LO BND X828 0
 	FR BND X829
 	LO BND X829 0
 	FR BND X830
 	LO BND X830 0
 	FR BND X831
 	LO BND X831 0
 	FR BND X832
 	LO BND X832 0
 	FR BND X833
 	LO BND X833 0
 	FR BND X834
 	LO BND X834 0
 	FR BND X835
 	LO BND X835 0
 	FR BND X836
 	LO BND X836 0
 	FR BND X837
 	LO BND X837 0
 	FR BND X838
 	LO BND X838 0
 	FR BND X839
 	LO BND X839 0
 	FR BND X840
 	LO BND X840 0
 	FR BND X841
 	LO BND X841 0
 	FR BND X842
 	LO BND X842 0
 	FR BND X843
 	LO BND X843 0
 	FR BND X844
 	LO BND X844 0
 	FR BND X845
 	LO BND X845 0
 	FR BND X846
 	LO BND X846 0
 	FR BND X847
 	LO BND X847 0
 	FR BND X848
 	LO BND X848 0
 	FR BND X849
 	LO BND X849 0
 	FR BND X850
 	LO BND X850 0
 	FR BND X851
 	LO BND X851 0
 	FR BND X852
 	LO BND X852 0
 	FR BND X853
 	LO BND X853 0
 	FR BND X854
 	LO BND X854 0
 	FR BND X855
 	LO BND X855 0
 	FR BND X856
 	LO BND X856 0
 	FR BND X857
 	LO BND X857 0
 	FR BND X858
 	LO BND X858 0
 	FR BND X859
 	LO BND X859 0
 	FR BND X860
 	LO BND X860 0
 	FR BND X861
 	LO BND X861 0
 	FR BND X862
 	LO BND X862 0
 	FR BND X863
 	LO BND X863 0
 	FR BND X864
 	LO BND X864 0
 	FR BND X865
 	LO BND X865 0
 	FR BND X866
 	LO BND X866 0
 	FR BND X867
 	LO BND X867 0
 	FR BND X868
 	LO BND X868 0
 	FR BND X869
 	LO BND X869 0
 	FR BND X870
 	LO BND X870 0
 	FR BND X871
 	LO BND X871 0
 	FR BND X872
 	LO BND X872 0
 	FR BND X873
 	LO BND X873 0
 	FR BND X874
 	LO BND X874 0
 	FR BND X875
 	LO BND X875 0
 	FR BND X876
 	LO BND X876 0
 	FR BND X877
 	LO BND X877 0
 	FR BND X878
 	LO BND X878 0
 	FR BND X879
 	LO BND X879 0
 	FR BND X880
 	LO BND X880 0
 	FR BND X881
 	LO BND X881 0
 	FR BND X882
 	LO BND X882 0
 	FR BND X883
 	LO BND X883 0
 	FR BND X884
 	LO BND X884 0
 	FR BND X885
 	LO BND X885 0
 	FR BND X886
 	LO BND X886 0
 	FR BND X887
 	LO BND X887 0
 	FR BND X888
 	LO BND X888 0
 	FR BND X889
 	LO BND X889 0
 	FR BND X890
 	LO BND X890 0
 	FR BND X891
 	LO BND X891 0
 	FR BND X892
 	LO BND X892 0
 	FR BND X893
 	LO BND X893 0
 	FR BND X894
 	LO BND X894 0
 	FR BND X895
 	LO BND X895 0
 	FR BND X896
 	LO BND X896 0
 	FR BND X897
 	LO BND X897 0
 	FR BND X898
 	LO BND X898 0
 	FR BND X899
 	LO BND X899 0
 	FR BND X900
 	LO BND X900 0
 	FR BND X901
 	LO BND X901 0
 	FR BND X902
 	LO BND X902 0
 	FR BND X903
 	LO BND X903 0
 	FR BND X904
 	LO BND X904 0
 	FR BND X905
 	LO BND X905 0
 	FR BND X906
 	LO BND X906 0
 	FR BND X907
 	LO BND X907 0
 	FR BND X908
 	LO BND X908 0
 	FR BND X909
 	LO BND X909 0
 	FR BND X910
 	LO BND X910 0
 	FR BND X911
 	LO BND X911 0
 	FR BND X912
 	LO BND X912 0
 	FR BND X913
 	LO BND X913 0
 	FR BND X914
 	LO BND X914 0
 	FR BND X915
 	LO BND X915 0
 	FR BND X916
 	LO BND X916 0
 	FR BND X917
 	LO BND X917 0
 	FR BND X918
 	LO BND X918 0
 	FR BND X919
 	LO BND X919 0
 	FR BND X920
 	LO BND X920 0
 	FR BND X921
 	LO BND X921 0
 	FR BND X922
 	LO BND X922 0
 	FR BND X923
 	LO BND X923 0
 	FR BND X924
 	LO BND X924 0
 	FR BND X925
 	LO BND X925 0
 	FR BND X926
 	LO BND X926 0
 	FR BND X927
 	LO BND X927 0
 	FR BND X928
 	LO BND X928 0
 	FR BND X929
 	LO BND X929 0
 	FR BND X930
 	LO BND X930 0
 	FR BND X931
 	LO BND X931 0
 	FR BND X932
 	LO BND X932 0
 	FR BND X933
 	LO BND X933 0
 	FR BND X934
 	LO BND X934 0
 	FR BND X935
 	LO BND X935 0
 	FR BND X936
 	LO BND X936 0
 	FR BND X937
 	LO BND X937 0
 	FR BND X938
 	LO BND X938 0
 	FR BND X939
 	LO BND X939 0
 	FR BND X940
 	LO BND X940 0
 	FR BND X941
 	LO BND X941 0
 	FR BND X942
 	LO BND X942 0
 	FR BND X943
 	LO BND X943 0
 	FR BND X944
 	LO BND X944 0
 	FR BND X945
 	LO BND X945 0
 	FR BND X946
 	LO BND X946 0
 	FR BND X947
 	LO BND X947 0
 	FR BND X948
 	LO BND X948 0
 	FR BND X949
 	LO BND X949 0
 	FR BND X950
 	LO BND X950 0
 	FR BND X951
 	LO BND X951 0
 	FR BND X952
 	LO BND X952 0
 	FR BND X953
 	LO BND X953 0
 	FR BND X954
 	LO BND X954 0
 	FR BND X955
 	LO BND X955 0
 	FR BND X956
 	LO BND X956 0
 	FR BND X957
 	LO BND X957 0
 	FR BND X958
 	LO BND X958 0
 	FR BND X959
 	LO BND X959 0
 	FR BND X960
 	LO BND X960 0
 	FR BND X961
 	LO BND X961 0
 	FR BND X962
 	LO BND X962 0
 	FR BND X963
 	LO BND X963 0
 	FR BND X964
 	LO BND X964 0
 	FR BND X965
 	LO BND X965 0
 	FR BND X966
 	LO BND X966 0
 	FR BND X967
 	LO BND X967 0
 	FR BND X968
 	LO BND X968 0
 	FR BND X969
 	LO BND X969 0
 	FR BND X970
 	LO BND X970 0
 	FR BND X971
 	LO BND X971 0
 	FR BND X972
 	LO BND X972 0
 	FR BND X973
 	LO BND X973 0
 	FR BND X974
 	LO BND X974 0
 	FR BND X975
 	LO BND X975 0
 	FR BND X976
 	LO BND X976 0
 	FR BND X977
 	LO BND X977 0
 	FR BND X978
 	LO BND X978 0
 	FR BND X979
 	LO BND X979 0
 	FR BND X980
 	LO BND X980 0
 	FR BND X981
 	LO BND X981 0
 	FR BND X982
 	LO BND X982 0
 	FR BND X983
 	LO BND X983 0
 	FR BND X984
 	LO BND X984 0
 	FR BND X985
 	LO BND X985 0
 	FR BND X986
 	LO BND X986 0
 	FR BND X987
 	LO BND X987 0
 	FR BND X988
 	LO BND X988 0
 	FR BND X989
 	LO BND X989 0
 	FR BND X990
 	LO BND X990 0
 	FR BND X991
 	LO BND X991 0
 	FR BND X992
 	LO BND X992 0
 	FR BND X993
 	LO BND X993 0
 	FR BND X994
 	LO BND X994 0
 	FR BND X995
 	LO BND X995 0
 	FR BND X996
 	LO BND X996 0
 	FR BND X997
 	LO BND X997 0
 	FR BND X998
 	LO BND X998 0
 	FR BND X999
 	LO BND X999 0
 	FR BND X1000
 	LO BND X1000 0
 	FR BND X1001
 	LO BND X1001 0
 	FR BND X1002
 	LO BND X1002 0
 	FR BND X1003
 	LO BND X1003 0
 	FR BND X1004
 	LO BND X1004 0
 	FR BND X1005
 	LO BND X1005 0
 	FR BND X1006
 	LO BND X1006 0
 	FR BND X1007
 	LO BND X1007 0
 	FR BND X1008
 	LO BND X1008 0
 	FR BND X1009
 	LO BND X1009 0
 	FR BND X1010
 	LO BND X1010 0
 	FR BND X1011
 	LO BND X1011 0
 	FR BND X1012
 	LO BND X1012 0
 	FR BND X1013
 	LO BND X1013 0
 	FR BND X1014
 	LO BND X1014 0
 	FR BND X1015
 	LO BND X1015 0
 	FR BND X1016
 	LO BND X1016 0
 	FR BND X1017
 	LO BND X1017 0
 	FR BND X1018
 	LO BND X1018 0
 	FR BND X1019
 	LO BND X1019 0
 	FR BND X1020
 	LO BND X1020 0
 	FR BND X1021
 	LO BND X1021 0
 	FR BND X1022
 	LO BND X1022 0
 	FR BND X1023
 	LO BND X1023 0
 	FR BND X1024
 	LO BND X1024 0
 	FR BND X1025
 	LO BND X1025 0
 	FR BND X1026
 	LO BND X1026 0
 	FR BND X1027
 	LO BND X1027 0
 	FR BND X1028
 	LO BND X1028 0
 	FR BND X1029
 	LO BND X1029 0
 	FR BND X1030
 	LO BND X1030 0
 	FR BND X1031
 	LO BND X1031 0
 	FR BND X1032
 	LO BND X1032 0
 	FR BND X1033
 	LO BND X1033 0
 	FR BND X1034
 	LO BND X1034 0
 	FR BND X1035
 	LO BND X1035 0
 	FR BND X1036
 	LO BND X1036 0
 	FR BND X1037
 	LO BND X1037 0
 	FR BND X1038
 	LO BND X1038 0
 	FR BND X1039
 	LO BND X1039 0
 	FR BND X1040
 	LO BND X1040 0
 	FR BND X1041
 	LO BND X1041 0
 	FR BND X1042
 	LO BND X1042 0
 	FR BND X1043
 	LO BND X1043 0
 	FR BND X1044
 	LO BND X1044 0
 	FR BND X1045
 	LO BND X1045 0
 	FR BND X1046
 	LO BND X1046 0
 	FR BND X1047
 	LO BND X1047 0
 	FR BND X1048
 	LO BND X1048 0
 	FR BND X1049
 	LO BND X1049 0
 	FR BND X1050
 	LO BND X1050 0
 	FR BND X1051
 	LO BND X1051 0
 	FR BND X1052
 	LO BND X1052 0
 	FR BND X1053
 	LO BND X1053 0
 	FR BND X1054
 	LO BND X1054 0
 	FR BND X1055
 	LO BND X1055 0
 	FR BND X1056
 	LO BND X1056 0
 	FR BND X1057
 	LO BND X1057 0
 	FR BND X1058
 	LO BND X1058 0
 	FR BND X1059
 	LO BND X1059 0
 	FR BND X1060
 	LO BND X1060 0
 	FR BND X1061
 	LO BND X1061 0
 	FR BND X1062
 	LO BND X1062 0
 	FR BND X1063
 	LO BND X1063 0
 	FR BND X1064
 	LO BND X1064 0
 	FR BND X1065
 	LO BND X1065 0
 	FR BND X1066
 	LO BND X1066 0
 	FR BND X1067
 	LO BND X1067 0
 	FR BND X1068
 	LO BND X1068 0
 	FR BND X1069
 	LO BND X1069 0
 	FR BND X1070
 	LO BND X1070 0
 	FR BND X1071
 	LO BND X1071 0
 	FR BND X1072
 	LO BND X1072 0
 	FR BND X1073
 	LO BND X1073 0
 	FR BND X1074
 	LO BND X1074 0
 	FR BND X1075
 	LO BND X1075 0
 	FR BND X1076
 	LO BND X1076 0
 	FR BND X1077
 	LO BND X1077 0
 	FR BND X1078
 	LO BND X1078 0
 	FR BND X1079
 	LO BND X1079 0
 	FR BND X1080
 	LO BND X1080 0
 	FR BND X1081
 	LO BND X1081 0
 	FR BND X1082
 	LO BND X1082 0
 	FR BND X1083
 	LO BND X1083 0
 	FR BND X1084
 	LO BND X1084 0
 	FR BND X1085
 	LO BND X1085 0
 	FR BND X1086
 	LO BND X1086 0
 	FR BND X1087
 	LO BND X1087 0
 	FR BND X1088
 	LO BND X1088 0
 	FR BND X1089
 	LO BND X1089 0
 	FR BND X1090
 	LO BND X1090 0
 	FR BND X1091
 	LO BND X1091 0
 	FR BND X1092
 	LO BND X1092 0
 	FR BND X1093
 	LO BND X1093 0
 	FR BND X1094
 	LO BND X1094 0
 	FR BND X1095
 	LO BND X1095 0
 	FR BND X1096
 	LO BND X1096 0
 	FR BND X1097
 	LO BND X1097 0
 	FR BND X1098
 	LO BND X1098 0
 	FR BND X1099
 	LO BND X1099 0
 	FR BND X1100
 	LO BND X1100 0
 	FR BND X1101
 	LO BND X1101 0
 	FR BND X1102
 	LO BND X1102 0
 	FR BND X1103
 	LO BND X1103 0
 	FR BND X1104
 	LO BND X1104 0
 	FR BND X1105
 	LO BND X1105 0
 	FR BND X1106
 	LO BND X1106 0
 	FR BND X1107
 	LO BND X1107 0
 	FR BND X1108
 	LO BND X1108 0
 	FR BND X1109
 	LO BND X1109 0
 	FR BND X1110
 	LO BND X1110 0
 	FR BND X1111
 	LO BND X1111 0
 	FR BND X1112
 	LO BND X1112 0
 	FR BND X1113
 	LO BND X1113 0
 	FR BND X1114
 	LO BND X1114 0
 	FR BND X1115
 	LO BND X1115 0
 	FR BND X1116
 	LO BND X1116 0
 	FR BND X1117
 	LO BND X1117 0
 	FR BND X1118
 	LO BND X1118 0
 	FR BND X1119
 	LO BND X1119 0
 	FR BND X1120
 	LO BND X1120 0
 	FR BND X1121
 	LO BND X1121 0
 	FR BND X1122
 	LO BND X1122 0
 	FR BND X1123
 	LO BND X1123 0
 	FR BND X1124
 	LO BND X1124 0
 	FR BND X1125
 	LO BND X1125 0
 	FR BND X1126
 	LO BND X1126 0
 	FR BND X1127
 	LO BND X1127 0
 	FR BND X1128
 	LO BND X1128 0
 	FR BND X1129
 	LO BND X1129 0
 	FR BND X1130
 	LO BND X1130 0
 	FR BND X1131
 	LO BND X1131 0
 	FR BND X1132
 	LO BND X1132 0
 	FR BND X1133
 	LO BND X1133 0
 	FR BND X1134
 	LO BND X1134 0
 	FR BND X1135
 	LO BND X1135 0
 	FR BND X1136
 	LO BND X1136 0
 	FR BND X1137
 	LO BND X1137 0
 	FR BND X1138
 	LO BND X1138 0
 	FR BND X1139
 	LO BND X1139 0
 	FR BND X1140
 	LO BND X1140 0
 	FR BND X1141
 	LO BND X1141 0
 	FR BND X1142
 	LO BND X1142 0
 	FR BND X1143
 	LO BND X1143 0
 	FR BND X1144
 	LO BND X1144 0
 	FR BND X1145
 	LO BND X1145 0
 	FR BND X1146
 	LO BND X1146 0
 	FR BND X1147
 	LO BND X1147 0
 	FR BND X1148
 	LO BND X1148 0
 	FR BND X1149
 	LO BND X1149 0
 	FR BND X1150
 	LO BND X1150 0
 	FR BND X1151
 	LO BND X1151 0
 	FR BND X1152
 	LO BND X1152 0
 	FR BND X1153
 	LO BND X1153 0
 	FR BND X1154
 	LO BND X1154 0
 	FR BND X1155
 	LO BND X1155 0
 	FR BND X1156
 	LO BND X1156 0
 	FR BND X1157
 	LO BND X1157 0
 	FR BND X1158
 	LO BND X1158 0
 	FR BND X1159
 	LO BND X1159 0
 	FR BND X1160
 	LO BND X1160 0
 	FR BND X1161
 	LO BND X1161 0
 	FR BND X1162
 	LO BND X1162 0
 	FR BND X1163
 	LO BND X1163 0
 	FR BND X1164
 	LO BND X1164 0
 	FR BND X1165
 	LO BND X1165 0
 	FR BND X1166
 	LO BND X1166 0
 	FR BND X1167
 	LO BND X1167 0
 	FR BND X1168
 	LO BND X1168 0
 	FR BND X1169
 	LO BND X1169 0
 	FR BND X1170
 	LO BND X1170 0
 	FR BND X1171
 	LO BND X1171 0
 	FR BND X1172
 	LO BND X1172 0
 	FR BND X1173
 	LO BND X1173 0
 	FR BND X1174
 	LO BND X1174 0
 	FR BND X1175
 	LO BND X1175 0
 	FR BND X1176
 	LO BND X1176 0
 	FR BND X1177
 	LO BND X1177 0
 	FR BND X1178
 	LO BND X1178 0
 	FR BND X1179
 	LO BND X1179 0
 	FR BND X1180
 	LO BND X1180 0
 	FR BND X1181
 	LO BND X1181 0
 	FR BND X1182
 	LO BND X1182 0
 	FR BND X1183
 	LO BND X1183 0
 	FR BND X1184
 	LO BND X1184 0
 	FR BND X1185
 	LO BND X1185 0
 	FR BND X1186
 	LO BND X1186 0
 	FR BND X1187
 	LO BND X1187 0
 	FR BND X1188
 	LO BND X1188 0
 	FR BND X1189
 	LO BND X1189 0
 	FR BND X1190
 	LO BND X1190 0
 	FR BND X1191
 	LO BND X1191 0
 	FR BND X1192
 	LO BND X1192 0
 	FR BND X1193
 	LO BND X1193 0
 	FR BND X1194
 	LO BND X1194 0
 	FR BND X1195
 	LO BND X1195 0
 	FR BND X1196
 	LO BND X1196 0
 	FR BND X1197
 	LO BND X1197 0
 	FR BND X1198
 	LO BND X1198 0
 	FR BND X1199
 	LO BND X1199 0
 	FR BND X1200
 	LO BND X1200 0
 	FR BND X1201
 	LO BND X1201 0
 	FR BND X1202
 	LO BND X1202 0
 	FR BND X1203
 	LO BND X1203 0
 	FR BND X1204
 	LO BND X1204 0
 	FR BND X1205
 	LO BND X1205 0
 	FR BND X1206
 	LO BND X1206 0
 	FR BND X1207
 	LO BND X1207 0
 	FR BND X1208
 	LO BND X1208 0
 	FR BND X1209
 	LO BND X1209 0
 	FR BND X1210
 	LO BND X1210 0
 	FR BND X1211
 	LO BND X1211 0
 	FR BND X1212
 	LO BND X1212 0
 	FR BND X1213
 	LO BND X1213 0
 	FR BND X1214
 	LO BND X1214 0
 	FR BND X1215
 	LO BND X1215 0
 	FR BND X1216
 	LO BND X1216 0
 	FR BND X1217
 	LO BND X1217 0
 	FR BND X1218
 	LO BND X1218 0
 	FR BND X1219
 	LO BND X1219 0
 	FR BND X1220
 	LO BND X1220 0
 	FR BND X1221
 	LO BND X1221 0
 	FR BND X1222
 	LO BND X1222 0
 	FR BND X1223
 	LO BND X1223 0
 	FR BND X1224
 	LO BND X1224 0
 	FR BND X1225
 	LO BND X1225 0
 	FR BND X1226
 	LO BND X1226 0
 	FR BND X1227
 	LO BND X1227 0
 	FR BND X1228
 	LO BND X1228 0
 	FR BND X1229
 	LO BND X1229 0
 	FR BND X1230
 	LO BND X1230 0
 	FR BND X1231
 	LO BND X1231 0
 	FR BND X1232
 	LO BND X1232 0
 	FR BND X1233
 	LO BND X1233 0
 	FR BND X1234
 	LO BND X1234 0
 	FR BND X1235
 	LO BND X1235 0
 	FR BND X1236
 	LO BND X1236 0
 	FR BND X1237
 	LO BND X1237 0
 	FR BND X1238
 	LO BND X1238 0
 	FR BND X1239
 	LO BND X1239 0
 	FR BND X1240
 	LO BND X1240 0
 	FR BND X1241
 	LO BND X1241 0
 	FR BND X1242
 	LO BND X1242 0
 	FR BND X1243
 	LO BND X1243 0
 	FR BND X1244
 	LO BND X1244 0
 	FR BND X1245
 	LO BND X1245 0
 	FR BND X1246
 	LO BND X1246 0
 	FR BND X1247
 	LO BND X1247 0
 	FR BND X1248
 	LO BND X1248 0
 	FR BND X1249
 	LO BND X1249 0
 	FR BND X1250
 	LO BND X1250 0
 	FR BND X1251
 	LO BND X1251 0
 	FR BND X1252
 	LO BND X1252 0
 	FR BND X1253
 	LO BND X1253 0
 	FR BND X1254
 	LO BND X1254 0
 	FR BND X1255
 	LO BND X1255 0
 	FR BND X1256
 	LO BND X1256 0
 	FR BND X1257
 	LO BND X1257 0
 	FR BND X1258
 	LO BND X1258 0
 	FR BND X1259
 	LO BND X1259 0
 	FR BND X1260
 	LO BND X1260 0
 	FR BND X1261
 	LO BND X1261 0
 	FR BND X1262
 	LO BND X1262 0
 	FR BND X1263
 	LO BND X1263 0
 	FR BND X1264
 	LO BND X1264 0
 	FR BND X1265
 	LO BND X1265 0
 	FR BND X1266
 	LO BND X1266 0
 	FR BND X1267
 	LO BND X1267 0
 	FR BND X1268
 	LO BND X1268 0
 	FR BND X1269
 	LO BND X1269 0
 	FR BND X1270
 	LO BND X1270 0
 	FR BND X1271
 	LO BND X1271 0
 	FR BND X1272
 	LO BND X1272 0
 	FR BND X1273
 	LO BND X1273 0
 	FR BND X1274
 	LO BND X1274 0
 	FR BND X1275
 	LO BND X1275 0
 	FR BND X1276
 	LO BND X1276 0
 	FR BND X1277
 	LO BND X1277 0
 	FR BND X1278
 	LO BND X1278 0
 	FR BND X1279
 	LO BND X1279 0
 	FR BND X1280
 	LO BND X1280 0
 	FR BND X1281
 	LO BND X1281 0
 	FR BND X1282
 	LO BND X1282 0
 	FR BND X1283
 	LO BND X1283 0
 	FR BND X1284
 	LO BND X1284 0
 	FR BND X1285
 	LO BND X1285 0
 	FR BND X1286
 	LO BND X1286 0
 	FR BND X1287
 	LO BND X1287 0
 	FR BND X1288
 	LO BND X1288 0
 	FR BND X1289
 	LO BND X1289 0
 	FR BND X1290
 	LO BND X1290 0
 	FR BND X1291
 	LO BND X1291 0
 	FR BND X1292
 	LO BND X1292 0
 	FR BND X1293
 	LO BND X1293 0
 	FR BND X1294
 	LO BND X1294 0
 	FR BND X1295
 	LO BND X1295 0
 	FR BND X1296
 	LO BND X1296 0
 	FR BND X1297
 	LO BND X1297 0
 	FR BND X1298
 	LO BND X1298 0
 	FR BND X1299
 	LO BND X1299 0
 	FR BND X1300
 	LO BND X1300 0
 	FR BND X1301
 	LO BND X1301 0
 	FR BND X1302
 	LO BND X1302 0
 	FR BND X1303
 	LO BND X1303 0
 	FR BND X1304
 	LO BND X1304 0
 	FR BND X1305
 	LO BND X1305 0
 	FR BND X1306
 	LO BND X1306 0
 	FR BND X1307
 	LO BND X1307 0
 	FR BND X1308
 	LO BND X1308 0
 	FR BND X1309
 	LO BND X1309 0
 	FR BND X1310
 	LO BND X1310 0
 	FR BND X1311
 	LO BND X1311 0
 	FR BND X1312
 	LO BND X1312 0
 	FR BND X1313
 	LO BND X1313 0
 	FR BND X1314
 	LO BND X1314 0
 	FR BND X1315
 	LO BND X1315 0
 	FR BND X1316
 	LO BND X1316 0
 	FR BND X1317
 	LO BND X1317 0
 	FR BND X1318
 	LO BND X1318 0
 	FR BND X1319
 	LO BND X1319 0
 	FR BND X1320
 	LO BND X1320 0
 	FR BND X1321
 	LO BND X1321 0
 	FR BND X1322
 	LO BND X1322 0
 	FR BND X1323
 	LO BND X1323 0
 	FR BND X1324
 	LO BND X1324 0
 	FR BND X1325
 	LO BND X1325 0
 	FR BND X1326
 	LO BND X1326 0
 	FR BND X1327
 	LO BND X1327 0
 	FR BND X1328
 	LO BND X1328 0
 	FR BND X1329
 	LO BND X1329 0
 	FR BND X1330
 	LO BND X1330 0
 	FR BND X1331
 	LO BND X1331 0
 	FR BND X1332
 	LO BND X1332 0
 	FR BND X1333
 	LO BND X1333 0
 	FR BND X1334
 	LO BND X1334 0
 	FR BND X1335
 	LO BND X1335 0
 	FR BND X1336
 	LO BND X1336 0
 	FR BND X1337
 	LO BND X1337 0
 	FR BND X1338
 	LO BND X1338 0
 	FR BND X1339
 	LO BND X1339 0
 	FR BND X1340
 	LO BND X1340 0
 	FR BND X1341
 	LO BND X1341 0
 	FR BND X1342
 	LO BND X1342 0
 	FR BND X1343
 	LO BND X1343 0
 	FR BND X1344
 	LO BND X1344 0
 	FR BND X1345
 	LO BND X1345 0
 	FR BND X1346
 	LO BND X1346 0
 	FR BND X1347
 	LO BND X1347 0
 	FR BND X1348
 	LO BND X1348 0
 	FR BND X1349
 	LO BND X1349 0
 	FR BND X1350
 	LO BND X1350 0
 	FR BND X1351
 	LO BND X1351 0
 	FR BND X1352
 	LO BND X1352 0
 	FR BND X1353
 	LO BND X1353 0
 	FR BND X1354
 	LO BND X1354 0
 	FR BND X1355
 	LO BND X1355 0
 	FR BND X1356
 	LO BND X1356 0
 	FR BND X1357
 	LO BND X1357 0
 	FR BND X1358
 	LO BND X1358 0
 	FR BND X1359
 	LO BND X1359 0
 	FR BND X1360
 	LO BND X1360 0
 	FR BND X1361
 	LO BND X1361 0
 	FR BND X1362
 	LO BND X1362 0
 	FR BND X1363
 	LO BND X1363 0
 	FR BND X1364
 	LO BND X1364 0
 	FR BND X1365
 	LO BND X1365 0
 	FR BND X1366
 	LO BND X1366 0
 	FR BND X1367
 	LO BND X1367 0
 	FR BND X1368
 	LO BND X1368 0
 	FR BND X1369
 	LO BND X1369 0
 	FR BND X1370
 	LO BND X1370 0
 	FR BND X1371
 	LO BND X1371 0
 	FR BND X1372
 	LO BND X1372 0
 	FR BND X1373
 	LO BND X1373 0
 	FR BND X1374
 	LO BND X1374 0
 	FR BND X1375
 	LO BND X1375 0
 	FR BND X1376
 	LO BND X1376 0
 	FR BND X1377
 	LO BND X1377 0
 	FR BND X1378
 	LO BND X1378 0
 	FR BND X1379
 	LO BND X1379 0
 	FR BND X1380
 	LO BND X1380 0
 	FR BND X1381
 	LO BND X1381 0
 	FR BND X1382
 	LO BND X1382 0
 	FR BND X1383
 	LO BND X1383 0
 	FR BND X1384
 	LO BND X1384 0
 	FR BND X1385
 	LO BND X1385 0
 	FR BND X1386
 	LO BND X1386 0
 	FR BND X1387
 	LO BND X1387 0
 	FR BND X1388
 	LO BND X1388 0
 	FR BND X1389
 	LO BND X1389 0
 	FR BND X1390
 	LO BND X1390 0
 	FR BND X1391
 	LO BND X1391 0
 	FR BND X1392
 	LO BND X1392 0
 	FR BND X1393
 	LO BND X1393 0
 	FR BND X1394
 	LO BND X1394 0
 	FR BND X1395
 	LO BND X1395 0
 	FR BND X1396
 	LO BND X1396 0
 	FR BND X1397
 	LO BND X1397 0
 	FR BND X1398
 	LO BND X1398 0
 	FR BND X1399
 	LO BND X1399 0
 	FR BND X1400
 	LO BND X1400 0
 	FR BND X1401
 	LO BND X1401 0
 	FR BND X1402
 	LO BND X1402 0
 	FR BND X1403
 	LO BND X1403 0
 	FR BND X1404
 	LO BND X1404 0
 	FR BND X1405
 	LO BND X1405 0
 	FR BND X1406
 	LO BND X1406 0
 	FR BND X1407
 	LO BND X1407 0
 	FR BND X1408
 	LO BND X1408 0
 	FR BND X1409
 	LO BND X1409 0
 	FR BND X1410
 	LO BND X1410 0
 	FR BND X1411
 	LO BND X1411 0
 	FR BND X1412
 	LO BND X1412 0
 	FR BND X1413
 	LO BND X1413 0
 	FR BND X1414
 	LO BND X1414 0
 	FR BND X1415
 	LO BND X1415 0
 	FR BND X1416
 	LO BND X1416 0
 	FR BND X1417
 	LO BND X1417 0
 	FR BND X1418
 	LO BND X1418 0
 	FR BND X1419
 	LO BND X1419 0
 	FR BND X1420
 	LO BND X1420 0
 	FR BND X1421
 	LO BND X1421 0
 	FR BND X1422
 	LO BND X1422 0
 	FR BND X1423
 	LO BND X1423 0
 	FR BND X1424
 	LO BND X1424 0
 	FR BND X1425
 	LO BND X1425 0
 	FR BND X1426
 	LO BND X1426 0
 	FR BND X1427
 	LO BND X1427 0
 	FR BND X1428
 	LO BND X1428 0
 	FR BND X1429
 	LO BND X1429 0
 	FR BND X1430
 	LO BND X1430 0
 	FR BND X1431
 	LO BND X1431 0
 	FR BND X1432
 	LO BND X1432 0
 	FR BND X1433
 	LO BND X1433 0
 	FR BND X1434
 	LO BND X1434 0
 	FR BND X1435
 	LO BND X1435 0
 	FR BND X1436
 	LO BND X1436 0
 	FR BND X1437
 	LO BND X1437 0
 	FR BND X1438
 	LO BND X1438 0
 	FR BND X1439
 	LO BND X1439 0
 	FR BND X1440
 	LO BND X1440 0
 	FR BND X1441
 	LO BND X1441 0
 	FR BND X1442
 	LO BND X1442 0
 	FR BND X1443
 	LO BND X1443 0
 	FR BND X1444
 	LO BND X1444 0
 	FR BND X1445
 	LO BND X1445 0
 	FR BND X1446
 	LO BND X1446 0
 	FR BND X1447
 	LO BND X1447 0
 	FR BND X1448
 	LO BND X1448 0
 	FR BND X1449
 	LO BND X1449 0
 	FR BND X1450
 	LO BND X1450 0
 	FR BND X1451
 	LO BND X1451 0
 	FR BND X1452
 	LO BND X1452 0
 	FR BND X1453
 	LO BND X1453 0
 	FR BND X1454
 	LO BND X1454 0
 	FR BND X1455
 	LO BND X1455 0
 	FR BND X1456
 	LO BND X1456 0
 	FR BND X1457
 	LO BND X1457 0
 	FR BND X1458
 	LO BND X1458 0
 	FR BND X1459
 	LO BND X1459 0
 	FR BND X1460
 	LO BND X1460 0
 	FR BND X1461
 	LO BND X1461 0
 	FR BND X1462
 	LO BND X1462 0
 	FR BND X1463
 	LO BND X1463 0
 	FR BND X1464
 	LO BND X1464 0
 	FR BND X1465
 	LO BND X1465 0
 	FR BND X1466
 	LO BND X1466 0
 	FR BND X1467
 	LO BND X1467 0
 	FR BND X1468
 	LO BND X1468 0
 	FR BND X1469
 	LO BND X1469 0
 	FR BND X1470
 	LO BND X1470 0
 	FR BND X1471
 	LO BND X1471 0
 	FR BND X1472
 	LO BND X1472 0
 	FR BND X1473
 	LO BND X1473 0
 	FR BND X1474
 	LO BND X1474 0
 	FR BND X1475
 	LO BND X1475 0
 	FR BND X1476
 	LO BND X1476 0
 	FR BND X1477
 	LO BND X1477 0
 	FR BND X1478
 	LO BND X1478 0
 	FR BND X1479
 	LO BND X1479 0
 	FR BND X1480
 	LO BND X1480 0
 	FR BND X1481
 	LO BND X1481 0
 	FR BND X1482
 	LO BND X1482 0
 	FR BND X1483
 	LO BND X1483 0
 	FR BND X1484
 	LO BND X1484 0
 	FR BND X1485
 	LO BND X1485 0
 	FR BND X1486
 	LO BND X1486 0
 	FR BND X1487
 	LO BND X1487 0
 	FR BND X1488
 	LO BND X1488 0
 	FR BND X1489
 	LO BND X1489 0
 	FR BND X1490
 	LO BND X1490 0
 	FR BND X1491
 	LO BND X1491 0
 	FR BND X1492
 	LO BND X1492 0
 	FR BND X1493
 	LO BND X1493 0
 	FR BND X1494
 	LO BND X1494 0
 	FR BND X1495
 	LO BND X1495 0
 	FR BND X1496
 	LO BND X1496 0
 	FR BND X1497
 	LO BND X1497 0
 	FR BND X1498
 	LO BND X1498 0
 	FR BND X1499
 	LO BND X1499 0
 	FR BND X1500
 	LO BND X1500 0
 	FR BND X1501
 	LO BND X1501 0
 	FR BND X1502
 	LO BND X1502 0
 	FR BND X1503
 	LO BND X1503 0
 	FR BND X1504
 	LO BND X1504 0
 	FR BND X1505
 	LO BND X1505 0
 	FR BND X1506
 	LO BND X1506 0
 	FR BND X1507
 	LO BND X1507 0
 	FR BND X1508
 	LO BND X1508 0
 	FR BND X1509
 	LO BND X1509 0
 	FR BND X1510
 	LO BND X1510 0
 	FR BND X1511
 	LO BND X1511 0
 	FR BND X1512
 	LO BND X1512 0
 	FR BND X1513
 	LO BND X1513 0
 	FR BND X1514
 	LO BND X1514 0
 	FR BND X1515
 	LO BND X1515 0
 	FR BND X1516
 	LO BND X1516 0
 	FR BND X1517
 	LO BND X1517 0
 	FR BND X1518
 	LO BND X1518 0
 	FR BND X1519
 	LO BND X1519 0
 	FR BND X1520
 	LO BND X1520 0
 	FR BND X1521
 	LO BND X1521 0
 	FR BND X1522
 	LO BND X1522 0
 	FR BND X1523
 	LO BND X1523 0
 	FR BND X1524
 	LO BND X1524 0
 	FR BND X1525
 	LO BND X1525 0
 	FR BND X1526
 	LO BND X1526 0
 	FR BND X1527
 	LO BND X1527 0
 	FR BND X1528
 	LO BND X1528 0
 	FR BND X1529
 	LO BND X1529 0
 	FR BND X1530
 	LO BND X1530 0
 	FR BND X1531
 	LO BND X1531 0
 	FR BND X1532
 	LO BND X1532 0
 	FR BND X1533
 	LO BND X1533 0
 	FR BND X1534
 	LO BND X1534 0
 	FR BND X1535
 	LO BND X1535 0
 	FR BND X1536
 	LO BND X1536 0
 	FR BND X1537
 	LO BND X1537 0
 	FR BND X1538
 	LO BND X1538 0
 	FR BND X1539
 	LO BND X1539 0
 	FR BND X1540
 	LO BND X1540 0
 	FR BND X1541
 	LO BND X1541 0
 	FR BND X1542
 	LO BND X1542 0
 	FR BND X1543
 	LO BND X1543 0
 	FR BND X1544
 	LO BND X1544 0
 	FR BND X1545
 	LO BND X1545 0
 	FR BND X1546
 	LO BND X1546 0
 	FR BND X1547
 	LO BND X1547 0
 	FR BND X1548
 	LO BND X1548 0
 	FR BND X1549
 	LO BND X1549 0
 	FR BND X1550
 	LO BND X1550 0
 	FR BND X1551
 	LO BND X1551 0
 	FR BND X1552
 	LO BND X1552 0
 	FR BND X1553
 	LO BND X1553 0
 	FR BND X1554
 	LO BND X1554 0
 	FR BND X1555
 	LO BND X1555 0
 	FR BND X1556
 	LO BND X1556 0
 	FR BND X1557
 	LO BND X1557 0
 	FR BND X1558
 	LO BND X1558 0
 	FR BND X1559
 	LO BND X1559 0
 	FR BND X1560
 	LO BND X1560 0
 	FR BND X1561
 	LO BND X1561 0
 	FR BND X1562
 	LO BND X1562 0
 	FR BND X1563
 	LO BND X1563 0
 	FR BND X1564
 	LO BND X1564 0
 	FR BND X1565
 	LO BND X1565 0
 	FR BND X1566
 	LO BND X1566 0
 	FR BND X1567
 	LO BND X1567 0
 	FR BND X1568
 	LO BND X1568 0
 	FR BND X1569
 	LO BND X1569 0
 	FR BND X1570
 	LO BND X1570 0
 	FR BND X1571
 	LO BND X1571 0
 	FR BND X1572
 	LO BND X1572 0
 	FR BND X1573
 	LO BND X1573 0
 	FR BND X1574
 	LO BND X1574 0
 	FR BND X1575
 	LO BND X1575 0
 	FR BND X1576
 	LO BND X1576 0
 	FR BND X1577
 	LO BND X1577 0
 	FR BND X1578
 	LO BND X1578 0
 	FR BND X1579
 	LO BND X1579 0
 	FR BND X1580
 	LO BND X1580 0
 	FR BND X1581
 	LO BND X1581 0
 	FR BND X1582
 	LO BND X1582 0
 	FR BND X1583
 	LO BND X1583 0
 	FR BND X1584
 	LO BND X1584 0
 	FR BND X1585
 	LO BND X1585 0
 	FR BND X1586
 	LO BND X1586 0
 	FR BND X1587
 	LO BND X1587 0
 	FR BND X1588
 	LO BND X1588 0
 	FR BND X1589
 	LO BND X1589 0
 	FR BND X1590
 	LO BND X1590 0
 	FR BND X1591
 	LO BND X1591 0
 	FR BND X1592
 	LO BND X1592 0
 	FR BND X1593
 	LO BND X1593 0
 	FR BND X1594
 	LO BND X1594 0
 	FR BND X1595
 	LO BND X1595 0
 	FR BND X1596
 	LO BND X1596 0
 	FR BND X1597
 	LO BND X1597 0
 	FR BND X1598
 	LO BND X1598 0
 	FR BND X1599
 	LO BND X1599 0
 	FR BND X1600
 	LO BND X1600 0
 	FR BND X1601
 	LO BND X1601 0
 	FR BND X1602
 	LO BND X1602 0
 	FR BND X1603
 	LO BND X1603 0
 	FR BND X1604
 	LO BND X1604 0
 	FR BND X1605
 	LO BND X1605 0
 	FR BND X1606
 	LO BND X1606 0
 	FR BND X1607
 	LO BND X1607 0
 	FR BND X1608
 	LO BND X1608 0
 	FR BND X1609
 	LO BND X1609 0
 	FR BND X1610
 	LO BND X1610 0
 	FR BND X1611
 	LO BND X1611 0
 	FR BND X1612
 	LO BND X1612 0
 	FR BND X1613
 	LO BND X1613 0
 	FR BND X1614
 	LO BND X1614 0
 	FR BND X1615
 	LO BND X1615 0
 	FR BND X1616
 	LO BND X1616 0
 	FR BND X1617
 	LO BND X1617 0
 	FR BND X1618
 	LO BND X1618 0
 	FR BND X1619
 	LO BND X1619 0
 	FR BND X1620
 	LO BND X1620 0
 	FR BND X1621
 	LO BND X1621 0
 	FR BND X1622
 	LO BND X1622 0
 	FR BND X1623
 	LO BND X1623 0
 	FR BND X1624
 	LO BND X1624 0
 	FR BND X1625
 	LO BND X1625 0
 	FR BND X1626
 	LO BND X1626 0
 	FR BND X1627
 	LO BND X1627 0
 	FR BND X1628
 	LO BND X1628 0
 	FR BND X1629
 	LO BND X1629 0
 	FR BND X1630
 	LO BND X1630 0
 	FR BND X1631
 	LO BND X1631 0
 	FR BND X1632
 	LO BND X1632 0
 	FR BND X1633
 	LO BND X1633 0
 	FR BND X1634
 	LO BND X1634 0
 	FR BND X1635
 	LO BND X1635 0
 	FR BND X1636
 	LO BND X1636 0
 	FR BND X1637
 	LO BND X1637 0
 	FR BND X1638
 	LO BND X1638 0
 	FR BND X1639
 	LO BND X1639 0
 	FR BND X1640
 	LO BND X1640 0
 	FR BND X1641
 	LO BND X1641 0
 	FR BND X1642
 	LO BND X1642 0
 	FR BND X1643
 	LO BND X1643 0
 	FR BND X1644
 	LO BND X1644 0
 	FR BND X1645
 	LO BND X1645 0
 	FR BND X1646
 	LO BND X1646 0
 	FR BND X1647
 	LO BND X1647 0
 	FR BND X1648
 	LO BND X1648 0
 	FR BND X1649
 	LO BND X1649 0
 	FR BND X1650
 	LO BND X1650 0
 	FR BND X1651
 	LO BND X1651 0
 	FR BND X1652
 	LO BND X1652 0
 	FR BND X1653
 	LO BND X1653 0
 	FR BND X1654
 	LO BND X1654 0
 	FR BND X1655
 	LO BND X1655 0
 	FR BND X1656
 	LO BND X1656 0
 	FR BND X1657
 	LO BND X1657 0
 	FR BND X1658
 	LO BND X1658 0
 	FR BND X1659
 	LO BND X1659 0
 	FR BND X1660
 	LO BND X1660 0
 	FR BND X1661
 	LO BND X1661 0
 	FR BND X1662
 	LO BND X1662 0
 	FR BND X1663
 	LO BND X1663 0
 	FR BND X1664
 	LO BND X1664 0
 	FR BND X1665
 	LO BND X1665 0
 	FR BND X1666
 	LO BND X1666 0
 	FR BND X1667
 	LO BND X1667 0
 	FR BND X1668
 	LO BND X1668 0
 	FR BND X1669
 	LO BND X1669 0
 	FR BND X1670
 	LO BND X1670 0
 	FR BND X1671
 	LO BND X1671 0
 	FR BND X1672
 	LO BND X1672 0
 	FR BND X1673
 	LO BND X1673 0
 	FR BND X1674
 	LO BND X1674 0
 	FR BND X1675
 	LO BND X1675 0
 	FR BND X1676
 	LO BND X1676 0
 	FR BND X1677
 	LO BND X1677 0
 	FR BND X1678
 	LO BND X1678 0
 	FR BND X1679
 	LO BND X1679 0
 	FR BND X1680
 	LO BND X1680 0
 	FR BND X1681
 	LO BND X1681 0
 	FR BND X1682
 	LO BND X1682 0
 	FR BND X1683
 	LO BND X1683 0
 	FR BND X1684
 	LO BND X1684 0
 	FR BND X1685
 	LO BND X1685 0
 	FR BND X1686
 	LO BND X1686 0
 	FR BND X1687
 	LO BND X1687 0
 	FR BND X1688
 	LO BND X1688 0
 	FR BND X1689
 	LO BND X1689 0
 	FR BND X1690
 	LO BND X1690 0
 	FR BND X1691
 	LO BND X1691 0
 	FR BND X1692
 	LO BND X1692 0
 	FR BND X1693
 	LO BND X1693 0
 	FR BND X1694
 	LO BND X1694 0
 	FR BND X1695
 	LO BND X1695 0
 	FR BND X1696
 	LO BND X1696 0
 	FR BND X1697
 	LO BND X1697 0
 	FR BND X1698
 	LO BND X1698 0
 	FR BND X1699
 	LO BND X1699 0
 	FR BND X1700
 	LO BND X1700 0
 	FR BND X1701
 	LO BND X1701 0
 	FR BND X1702
 	LO BND X1702 0
 	FR BND X1703
 	LO BND X1703 0
 	FR BND X1704
 	LO BND X1704 0
 	FR BND X1705
 	LO BND X1705 0
 	FR BND X1706
 	LO BND X1706 0
 	FR BND X1707
 	LO BND X1707 0
 	FR BND X1708
 	LO BND X1708 0
 	FR BND X1709
 	LO BND X1709 0
 	FR BND X1710
 	LO BND X1710 0
 	FR BND X1711
 	LO BND X1711 0
 	FR BND X1712
 	LO BND X1712 0
 	FR BND X1713
 	LO BND X1713 0
 	FR BND X1714
 	LO BND X1714 0
 	FR BND X1715
 	LO BND X1715 0
 	FR BND X1716
 	LO BND X1716 0
 	FR BND X1717
 	LO BND X1717 0
 	FR BND X1718
 	LO BND X1718 0
 	FR BND X1719
 	LO BND X1719 0
 	FR BND X1720
 	LO BND X1720 0
 	FR BND X1721
 	LO BND X1721 0
 	FR BND X1722
 	LO BND X1722 0
 	FR BND X1723
 	LO BND X1723 0
 	FR BND X1724
 	LO BND X1724 0
 	FR BND X1725
 	LO BND X1725 0
 	FR BND X1726
 	LO BND X1726 0
 	FR BND X1727
 	LO BND X1727 0
 	FR BND X1728
 	LO BND X1728 0
 	FR BND X1729
 	LO BND X1729 0
 	FR BND X1730
 	LO BND X1730 0
 	FR BND X1731
 	LO BND X1731 0
 	FR BND X1732
 	LO BND X1732 0
 	FR BND X1733
 	LO BND X1733 0
 	FR BND X1734
 	LO BND X1734 0
 	FR BND X1735
 	LO BND X1735 0
 	FR BND X1736
 	LO BND X1736 0
 	FR BND X1737
 	LO BND X1737 0
 	FR BND X1738
 	LO BND X1738 0
 	FR BND X1739
 	LO BND X1739 0
 	FR BND X1740
 	LO BND X1740 0
 	FR BND X1741
 	LO BND X1741 0
 	FR BND X1742
 	LO BND X1742 0
 	FR BND X1743
 	LO BND X1743 0
 	FR BND X1744
 	LO BND X1744 0
 	FR BND X1745
 	LO BND X1745 0
 	FR BND X1746
 	LO BND X1746 0
 	FR BND X1747
 	LO BND X1747 0
 	FR BND X1748
 	LO BND X1748 0
 	FR BND X1749
 	LO BND X1749 0
 	FR BND X1750
 	LO BND X1750 0
 	FR BND X1751
 	LO BND X1751 0
 	FR BND X1752
 	LO BND X1752 0
 	FR BND X1753
 	LO BND X1753 0
 	FR BND X1754
 	LO BND X1754 0
 	FR BND X1755
 	LO BND X1755 0
 	FR BND X1756
 	LO BND X1756 0
 	FR BND X1757
 	LO BND X1757 0
 	FR BND X1758
 	LO BND X1758 0
 	FR BND X1759
 	LO BND X1759 0
 	FR BND X1760
 	LO BND X1760 0
 	FR BND X1761
 	LO BND X1761 0
 	FR BND X1762
 	LO BND X1762 0
 	FR BND X1763
 	LO BND X1763 0
 	FR BND X1764
 	LO BND X1764 0
 	FR BND X1765
 	LO BND X1765 0
 	FR BND X1766
 	LO BND X1766 0
 	FR BND X1767
 	LO BND X1767 0
 	FR BND X1768
 	LO BND X1768 0
 	FR BND X1769
 	LO BND X1769 0
 	FR BND X1770
 	LO BND X1770 0
 	FR BND X1771
 	LO BND X1771 0
 	FR BND X1772
 	LO BND X1772 0
 	FR BND X1773
 	LO BND X1773 0
 	FR BND X1774
 	LO BND X1774 0
 	FR BND X1775
 	LO BND X1775 0
 	FR BND X1776
 	LO BND X1776 0
 	FR BND X1777
 	LO BND X1777 0
 	FR BND X1778
 	LO BND X1778 0
 	FR BND X1779
 	LO BND X1779 0
 	FR BND X1780
 	LO BND X1780 0
 	FR BND X1781
 	LO BND X1781 0
 	FR BND X1782
 	LO BND X1782 0
 	FR BND X1783
 	LO BND X1783 0
 	FR BND X1784
 	LO BND X1784 0
 	FR BND X1785
 	LO BND X1785 0
 	FR BND X1786
 	LO BND X1786 0
 	FR BND X1787
 	LO BND X1787 0
 	FR BND X1788
 	LO BND X1788 0
 	FR BND X1789
 	LO BND X1789 0
 	FR BND X1790
 	LO BND X1790 0
 	FR BND X1791
 	LO BND X1791 0
 	FR BND X1792
 	LO BND X1792 0
 	FR BND X1793
 	LO BND X1793 0
 	FR BND X1794
 	LO BND X1794 0
 	FR BND X1795
 	LO BND X1795 0
 	FR BND X1796
 	LO BND X1796 0
 	FR BND X1797
 	LO BND X1797 0
 	FR BND X1798
 	LO BND X1798 0
 	FR BND X1799
 	LO BND X1799 0
 	FR BND X1800
 	LO BND X1800 0
 	FR BND X1801
 	LO BND X1801 0
 	FR BND X1802
 	LO BND X1802 0
 	FR BND X1803
 	LO BND X1803 0
 	FR BND X1804
 	LO BND X1804 0
 	FR BND X1805
 	LO BND X1805 0
 	FR BND X1806
 	LO BND X1806 0
 	FR BND X1807
 	LO BND X1807 0
 	FR BND X1808
 	LO BND X1808 0
 	FR BND X1809
 	LO BND X1809 0
 	FR BND X1810
 	LO BND X1810 0
 	FR BND X1811
 	LO BND X1811 0
 	FR BND X1812
 	LO BND X1812 0
 	FR BND X1813
 	LO BND X1813 0
 	FR BND X1814
 	LO BND X1814 0
 	FR BND X1815
 	LO BND X1815 0
 	FR BND X1816
 	LO BND X1816 0
 	FR BND X1817
 	LO BND X1817 0
 	FR BND X1818
 	LO BND X1818 0
 	FR BND X1819
 	LO BND X1819 0
 	FR BND X1820
 	LO BND X1820 0
 	FR BND X1821
 	LO BND X1821 0
 	FR BND X1822
 	LO BND X1822 0
 	FR BND X1823
 	LO BND X1823 0
 	FR BND X1824
 	LO BND X1824 0
 	FR BND X1825
 	LO BND X1825 0
 	FR BND X1826
 	LO BND X1826 0
 	FR BND X1827
 	LO BND X1827 0
 	FR BND X1828
 	LO BND X1828 0
 	FR BND X1829
 	LO BND X1829 0
 	FR BND X1830
 	LO BND X1830 0
 	FR BND X1831
 	LO BND X1831 0
 	FR BND X1832
 	LO BND X1832 0
 	FR BND X1833
 	LO BND X1833 0
 	FR BND X1834
 	LO BND X1834 0
 	FR BND X1835
 	LO BND X1835 0
 	FR BND X1836
 	LO BND X1836 0
 	FR BND X1837
 	LO BND X1837 0
 	FR BND X1838
 	LO BND X1838 0
 	FR BND X1839
 	LO BND X1839 0
 	FR BND X1840
 	LO BND X1840 0
 	FR BND X1841
 	LO BND X1841 0
 	FR BND X1842
 	LO BND X1842 0
 	FR BND X1843
 	LO BND X1843 0
 	FR BND X1844
 	LO BND X1844 0
 	FR BND X1845
 	LO BND X1845 0
 	FR BND X1846
 	LO BND X1846 0
 	FR BND X1847
 	LO BND X1847 0
 	FR BND X1848
 	LO BND X1848 0
 	FR BND X1849
 	LO BND X1849 0
 	FR BND X1850
 	LO BND X1850 0
 	FR BND X1851
 	LO BND X1851 0
 	FR BND X1852
 	LO BND X1852 0
 	FR BND X1853
 	LO BND X1853 0
 	FR BND X1854
 	LO BND X1854 0
 	FR BND X1855
 	LO BND X1855 0
 	FR BND X1856
 	LO BND X1856 0
 	FR BND X1857
 	LO BND X1857 0
 	FR BND X1858
 	LO BND X1858 0
 	FR BND X1859
 	LO BND X1859 0
 	FR BND X1860
 	LO BND X1860 0
 	FR BND X1861
 	LO BND X1861 0
 	FR BND X1862
 	LO BND X1862 0
 	FR BND X1863
 	LO BND X1863 0
 	FR BND X1864
 	LO BND X1864 0
 	FR BND X1865
 	LO BND X1865 0
 	FR BND X1866
 	LO BND X1866 0
 	FR BND X1867
 	LO BND X1867 0
 	FR BND X1868
 	LO BND X1868 0
 	FR BND X1869
 	LO BND X1869 0
 	FR BND X1870
 	LO BND X1870 0
 	FR BND X1871
 	LO BND X1871 0
 	FR BND X1872
 	LO BND X1872 0
 	FR BND X1873
 	LO BND X1873 0
 	FR BND X1874
 	LO BND X1874 0
 	FR BND X1875
 	LO BND X1875 0
 	FR BND X1876
 	LO BND X1876 0
 	FR BND X1877
 	LO BND X1877 0
 	FR BND X1878
 	LO BND X1878 0
 	FR BND X1879
 	LO BND X1879 0
 	FR BND X1880
 	LO BND X1880 0
 	FR BND X1881
 	LO BND X1881 0
 	FR BND X1882
 	LO BND X1882 0
 	FR BND X1883
 	LO BND X1883 0
 	FR BND X1884
 	LO BND X1884 0
 	FR BND X1885
 	LO BND X1885 0
 	FR BND X1886
 	LO BND X1886 0
 	FR BND X1887
 	LO BND X1887 0
 	FR BND X1888
 	LO BND X1888 0
 	FR BND X1889
 	LO BND X1889 0
 	FR BND X1890
 	LO BND X1890 0
 	FR BND X1891
 	LO BND X1891 0
 	FR BND X1892
 	LO BND X1892 0
 	FR BND X1893
 	LO BND X1893 0
 	FR BND X1894
 	LO BND X1894 0
 	FR BND X1895
 	LO BND X1895 0
 	FR BND X1896
 	LO BND X1896 0
 	FR BND X1897
 	LO BND X1897 0
 	FR BND X1898
 	LO BND X1898 0
 	FR BND X1899
 	LO BND X1899 0
 	FR BND X1900
 	LO BND X1900 0
 	FR BND X1901
 	LO BND X1901 0
 	FR BND X1902
 	LO BND X1902 0
 	FR BND X1903
 	LO BND X1903 0
 	FR BND X1904
 	LO BND X1904 0
 	FR BND X1905
 	LO BND X1905 0
 	FR BND X1906
 	LO BND X1906 0
 	FR BND X1907
 	LO BND X1907 0
 	FR BND X1908
 	LO BND X1908 0
 	FR BND X1909
 	LO BND X1909 0
 	FR BND X1910
 	LO BND X1910 0
 	FR BND X1911
 	LO BND X1911 0
 	FR BND X1912
 	LO BND X1912 0
 	FR BND X1913
 	LO BND X1913 0
 	FR BND X1914
 	LO BND X1914 0
 	FR BND X1915
 	LO BND X1915 0
 	FR BND X1916
 	LO BND X1916 0
 	FR BND X1917
 	LO BND X1917 0
 	FR BND X1918
 	LO BND X1918 0
 	FR BND X1919
 	LO BND X1919 0
 	FR BND X1920
 	LO BND X1920 0
 	FR BND X1921
 	LO BND X1921 0
 	FR BND X1922
 	LO BND X1922 0
 	FR BND X1923
 	LO BND X1923 0
 	FR BND X1924
 	LO BND X1924 0
 	FR BND X1925
 	LO BND X1925 0
 	FR BND X1926
 	LO BND X1926 0
 	FR BND X1927
 	LO BND X1927 0
 	FR BND X1928
 	LO BND X1928 0
 	FR BND X1929
 	LO BND X1929 0
 	FR BND X1930
 	LO BND X1930 0
 	FR BND X1931
 	LO BND X1931 0
 	FR BND X1932
 	LO BND X1932 0
 	FR BND X1933
 	LO BND X1933 0
 	FR BND X1934
 	LO BND X1934 0
 	FR BND X1935
 	LO BND X1935 0
 	FR BND X1936
 	LO BND X1936 0
 	FR BND X1937
 	LO BND X1937 0
 	FR BND X1938
 	LO BND X1938 0
 	FR BND X1939
 	LO BND X1939 0
 	FR BND X1940
 	LO BND X1940 0
 	FR BND X1941
 	LO BND X1941 0
 	FR BND X1942
 	LO BND X1942 0
 	FR BND X1943
 	LO BND X1943 0
 	FR BND X1944
 	LO BND X1944 0
 	FR BND X1945
 	LO BND X1945 0
 	FR BND X1946
 	LO BND X1946 0
 	FR BND X1947
 	LO BND X1947 0
 	FR BND X1948
 	LO BND X1948 0
 	FR BND X1949
 	LO BND X1949 0
 	FR BND X1950
 	LO BND X1950 0
 	FR BND X1951
 	LO BND X1951 0
 	FR BND X1952
 	LO BND X1952 0
 	FR BND X1953
 	LO BND X1953 0
 	FR BND X1954
 	LO BND X1954 0
 	FR BND X1955
 	LO BND X1955 0
 	FR BND X1956
 	LO BND X1956 0
 	FR BND X1957
 	LO BND X1957 0
 	FR BND X1958
 	LO BND X1958 0
 	FR BND X1959
 	LO BND X1959 0
 	FR BND X1960
 	LO BND X1960 0
 	FR BND X1961
 	LO BND X1961 0
 	FR BND X1962
 	LO BND X1962 0
 	FR BND X1963
 	LO BND X1963 0
 	FR BND X1964
 	LO BND X1964 0
 	FR BND X1965
 	LO BND X1965 0
 	FR BND X1966
 	LO BND X1966 0
 	FR BND X1967
 	LO BND X1967 0
 	FR BND X1968
 	LO BND X1968 0
 	FR BND X1969
 	LO BND X1969 0
 	FR BND X1970
 	LO BND X1970 0
 	FR BND X1971
 	LO BND X1971 0
 	FR BND X1972
 	LO BND X1972 0
 	FR BND X1973
 	LO BND X1973 0
 	FR BND X1974
 	LO BND X1974 0
 	FR BND X1975
 	LO BND X1975 0
 	FR BND X1976
 	LO BND X1976 0
 	FR BND X1977
 	LO BND X1977 0
 	FR BND X1978
 	LO BND X1978 0
 	FR BND X1979
 	LO BND X1979 0
 	FR BND X1980
 	LO BND X1980 0
 	FR BND X1981
 	LO BND X1981 0
 	FR BND X1982
 	LO BND X1982 0
 	FR BND X1983
 	LO BND X1983 0
 	FR BND X1984
 	LO BND X1984 0
 	FR BND X1985
 	LO BND X1985 0
 	FR BND X1986
 	LO BND X1986 0
 	FR BND X1987
 	LO BND X1987 0
 	FR BND X1988
 	LO BND X1988 0
 	FR BND X1989
 	LO BND X1989 0
 	FR BND X1990
 	LO BND X1990 0
 	FR BND X1991
 	LO BND X1991 0
 	FR BND X1992
 	LO BND X1992 0
 	FR BND X1993
 	LO BND X1993 0
 	FR BND X1994
 	LO BND X1994 0
 	FR BND X1995
 	LO BND X1995 0
 	FR BND X1996
 	LO BND X1996 0
 	FR BND X1997
 	LO BND X1997 0
 	FR BND X1998
 	LO BND X1998 0
 	FR BND X1999
 	LO BND X1999 0
 	FR BND X2000
 	LO BND X2000 0
 	FR BND X2001
 	LO BND X2001 0
 	FR BND X2002
 	LO BND X2002 0
 	FR BND X2003
 	LO BND X2003 0
 	FR BND X2004
 	LO BND X2004 0
 	FR BND X2005
 	LO BND X2005 0
 	FR BND X2006
 	LO BND X2006 0
 	FR BND X2007
 	LO BND X2007 0
 	FR BND X2008
 	LO BND X2008 0
 	FR BND X2009
 	LO BND X2009 0
 	FR BND X2010
 	LO BND X2010 0
 	FR BND X2011
 	LO BND X2011 0
 	FR BND X2012
 	LO BND X2012 0
 	FR BND X2013
 	LO BND X2013 0
 	FR BND X2014
 	LO BND X2014 0
 	FR BND X2015
 	LO BND X2015 0
 	FR BND X2016
 	LO BND X2016 0
 	FR BND X2017
 	LO BND X2017 0
 	FR BND X2018
 	LO BND X2018 0
 	FR BND X2019
 	LO BND X2019 0
 	FR BND X2020
 	LO BND X2020 0
 	FR BND X2021
 	LO BND X2021 0
 	FR BND X2022
 	LO BND X2022 0
 	FR BND X2023
 	LO BND X2023 0
 	FR BND X2024
 	LO BND X2024 0
 	FR BND X2025
 	LO BND X2025 0
 	FR BND X2026
 	LO BND X2026 0
 	FR BND X2027
 	LO BND X2027 0
 	FR BND X2028
 	LO BND X2028 0
 	FR BND X2029
 	LO BND X2029 0
 	FR BND X2030
 	LO BND X2030 0
 	FR BND X2031
 	LO BND X2031 0
 	FR BND X2032
 	LO BND X2032 0
 	FR BND X2033
 	LO BND X2033 0
 	FR BND X2034
 	LO BND X2034 0
 	FR BND X2035
 	LO BND X2035 0
 	FR BND X2036
 	LO BND X2036 0
 	FR BND X2037
 	LO BND X2037 0
 	FR BND X2038
 	LO BND X2038 0
 	FR BND X2039
 	LO BND X2039 0
 	FR BND X2040
 	LO BND X2040 0
 	FR BND X2041
 	LO BND X2041 0
 	FR BND X2042
 	LO BND X2042 0
 	FR BND X2043
 	LO BND X2043 0
 	FR BND X2044
 	LO BND X2044 0
 	FR BND X2045
 	LO BND X2045 0
 	FR BND X2046
 	LO BND X2046 0
 	FR BND X2047
 	LO BND X2047 0
 	FR BND X2048
 	LO BND X2048 0
 	FR BND X2049
 	LO BND X2049 0
 	FR BND X2050
 	LO BND X2050 0
 	FR BND X2051
 	LO BND X2051 0
 	FR BND X2052
 	LO BND X2052 0
 	FR BND X2053
 	LO BND X2053 0
 	FR BND X2054
 	LO BND X2054 0
 	FR BND X2055
 	LO BND X2055 0
 	FR BND X2056
 	LO BND X2056 0
 	FR BND X2057
 	LO BND X2057 0
 	FR BND X2058
 	LO BND X2058 0
 	FR BND X2059
 	LO BND X2059 0
 	FR BND X2060
 	LO BND X2060 0
 	FR BND X2061
 	LO BND X2061 0
 	FR BND X2062
 	LO BND X2062 0
 	FR BND X2063
 	LO BND X2063 0
 	FR BND X2064
 	LO BND X2064 0
 	FR BND X2065
 	LO BND X2065 0
 	FR BND X2066
 	LO BND X2066 0
 	FR BND X2067
 	LO BND X2067 0
 	FR BND X2068
 	LO BND X2068 0
 	FR BND X2069
 	LO BND X2069 0
 	FR BND X2070
 	LO BND X2070 0
 	FR BND X2071
 	LO BND X2071 0
 	FR BND X2072
 	LO BND X2072 0
 	FR BND X2073
 	LO BND X2073 0
 	FR BND X2074
 	LO BND X2074 0
 	FR BND X2075
 	LO BND X2075 0
 	FR BND X2076
 	LO BND X2076 0
 	FR BND X2077
 	LO BND X2077 0
 	FR BND X2078
 	LO BND X2078 0
 	FR BND X2079
 	LO BND X2079 0
 	FR BND X2080
 	LO BND X2080 0
 	FR BND X2081
 	LO BND X2081 0
 	FR BND X2082
 	LO BND X2082 0
 	FR BND X2083
 	LO BND X2083 0
 	FR BND X2084
 	LO BND X2084 0
 	FR BND X2085
 	LO BND X2085 0
 	FR BND X2086
 	LO BND X2086 0
 	FR BND X2087
 	LO BND X2087 0
 	FR BND X2088
 	LO BND X2088 0
 	FR BND X2089
 	LO BND X2089 0
 	FR BND X2090
 	LO BND X2090 0
 	FR BND X2091
 	LO BND X2091 0
 	FR BND X2092
 	LO BND X2092 0
 	FR BND X2093
 	LO BND X2093 0
 	FR BND X2094
 	LO BND X2094 0
 	FR BND X2095
 	LO BND X2095 0
 	FR BND X2096
 	LO BND X2096 0
 	FR BND X2097
 	LO BND X2097 0
 	FR BND X2098
 	LO BND X2098 0
 	FR BND X2099
 	LO BND X2099 0
 	FR BND X2100
 	LO BND X2100 0
 	FR BND X2101
 	LO BND X2101 0
 	FR BND X2102
 	LO BND X2102 0
 	FR BND X2103
 	LO BND X2103 0
 	FR BND X2104
 	LO BND X2104 0
 	FR BND X2105
 	LO BND X2105 0
 	FR BND X2106
 	LO BND X2106 0
 	FR BND X2107
 	LO BND X2107 0
 	FR BND X2108
 	LO BND X2108 0
 	FR BND X2109
 	LO BND X2109 0
 	FR BND X2110
 	LO BND X2110 0
 	FR BND X2111
 	LO BND X2111 0
 	FR BND X2112
 	LO BND X2112 0
 	FR BND X2113
 	LO BND X2113 0
 	FR BND X2114
 	LO BND X2114 0
 	FR BND X2115
 	LO BND X2115 0
 	FR BND X2116
 	LO BND X2116 0
 	FR BND X2117
 	LO BND X2117 0
 	FR BND X2118
 	LO BND X2118 0
 	FR BND X2119
 	LO BND X2119 0
 	FR BND X2120
 	LO BND X2120 0
 	FR BND X2121
 	LO BND X2121 0
 	FR BND X2122
 	LO BND X2122 0
 	FR BND X2123
 	LO BND X2123 0
 	FR BND X2124
 	LO BND X2124 0
 	FR BND X2125
 	LO BND X2125 0
 	FR BND X2126
 	LO BND X2126 0
 	FR BND X2127
 	LO BND X2127 0
 	FR BND X2128
 	LO BND X2128 0
 	FR BND X2129
 	LO BND X2129 0
 	FR BND X2130
 	LO BND X2130 0
 	FR BND X2131
 	LO BND X2131 0
 	FR BND X2132
 	LO BND X2132 0
 	FR BND X2133
 	LO BND X2133 0
 	FR BND X2134
 	LO BND X2134 0
 	FR BND X2135
 	LO BND X2135 0
 	FR BND X2136
 	LO BND X2136 0
 	FR BND X2137
 	LO BND X2137 0
 	FR BND X2138
 	LO BND X2138 0
 	FR BND X2139
 	LO BND X2139 0
 	FR BND X2140
 	LO BND X2140 0
 	FR BND X2141
 	LO BND X2141 0
 	FR BND X2142
 	LO BND X2142 0
 	FR BND X2143
 	LO BND X2143 0
 	FR BND X2144
 	LO BND X2144 0
 	FR BND X2145
 	LO BND X2145 0
 	FR BND X2146
 	LO BND X2146 0
 	FR BND X2147
 	LO BND X2147 0
 	FR BND X2148
 	LO BND X2148 0
 	FR BND X2149
 	LO BND X2149 0
 	FR BND X2150
 	LO BND X2150 0
 	FR BND X2151
 	LO BND X2151 0
 	FR BND X2152
 	LO BND X2152 0
 	FR BND X2153
 	LO BND X2153 0
 	FR BND X2154
 	LO BND X2154 0
 	FR BND X2155
 	LO BND X2155 0
 	FR BND X2156
 	LO BND X2156 0
 	FR BND X2157
 	LO BND X2157 0
 	FR BND X2158
 	LO BND X2158 0
 	FR BND X2159
 	LO BND X2159 0
 	FR BND X2160
 	LO BND X2160 0
 	FR BND X2161
 	LO BND X2161 0
 	FR BND X2162
 	LO BND X2162 0
 	FR BND X2163
 	LO BND X2163 0
 	FR BND X2164
 	LO BND X2164 0
 	FR BND X2165
 	LO BND X2165 0
 	FR BND X2166
 	LO BND X2166 0
 	FR BND X2167
 	LO BND X2167 0
 	FR BND X2168
 	LO BND X2168 0
 	FR BND X2169
 	LO BND X2169 0
 	FR BND X2170
 	LO BND X2170 0
 	FR BND X2171
 	LO BND X2171 0
 	FR BND X2172
 	LO BND X2172 0
 	FR BND X2173
 	LO BND X2173 0
 	FR BND X2174
 	LO BND X2174 0
 	FR BND X2175
 	LO BND X2175 0
 	FR BND X2176
 	LO BND X2176 0
 	FR BND X2177
 	LO BND X2177 0
 	FR BND X2178
 	LO BND X2178 0
 	FR BND X2179
 	LO BND X2179 0
 	FR BND X2180
 	LO BND X2180 0
 	FR BND X2181
 	LO BND X2181 0
 	FR BND X2182
 	LO BND X2182 0
 	FR BND X2183
 	LO BND X2183 0
 	FR BND X2184
 	LO BND X2184 0
 	FR BND X2185
 	LO BND X2185 0
 	FR BND X2186
 	LO BND X2186 0
 	FR BND X2187
 	LO BND X2187 0
 	FR BND X2188
 	LO BND X2188 0
 	FR BND X2189
 	LO BND X2189 0
 	FR BND X2190
 	LO BND X2190 0
 	FR BND X2191
 	LO BND X2191 0
 	FR BND X2192
 	LO BND X2192 0
 	FR BND X2193
 	LO BND X2193 0
 	FR BND X2194
 	LO BND X2194 0
 	FR BND X2195
 	LO BND X2195 0
 	FR BND X2196
 	LO BND X2196 0
 	FR BND X2197
 	LO BND X2197 0
 	FR BND X2198
 	LO BND X2198 0
 	FR BND X2199
 	LO BND X2199 0
 	FR BND X2200
 	LO BND X2200 0
 	FR BND X2201
 	LO BND X2201 0
 	FR BND X2202
 	LO BND X2202 0
 	FR BND X2203
 	LO BND X2203 0
 	FR BND X2204
 	LO BND X2204 0
 	FR BND X2205
 	LO BND X2205 0
 	FR BND X2206
 	LO BND X2206 0
 	FR BND X2207
 	LO BND X2207 0
 	FR BND X2208
 	LO BND X2208 0
 	FR BND X2209
 	LO BND X2209 0
 	FR BND X2210
 	LO BND X2210 0
 	FR BND X2211
 	LO BND X2211 0
 	FR BND X2212
 	LO BND X2212 0
 	FR BND X2213
 	LO BND X2213 0
 	FR BND X2214
 	LO BND X2214 0
 	FR BND X2215
 	LO BND X2215 0
 	FR BND X2216
 	LO BND X2216 0
 	FR BND X2217
 	LO BND X2217 0
 	FR BND X2218
 	LO BND X2218 0
 	FR BND X2219
 	LO BND X2219 0
 	FR BND X2220
 	LO BND X2220 0
 	FR BND X2221
 	LO BND X2221 0
 	FR BND X2222
 	LO BND X2222 0
 	FR BND X2223
 	LO BND X2223 0
 	FR BND X2224
 	LO BND X2224 0
 	FR BND X2225
 	LO BND X2225 0
 	FR BND X2226
 	LO BND X2226 0
 	FR BND X2227
 	LO BND X2227 0
 	FR BND X2228
 	LO BND X2228 0
 	FR BND X2229
 	LO BND X2229 0
 	FR BND X2230
 	LO BND X2230 0
 	FR BND X2231
 	LO BND X2231 0
 	FR BND X2232
 	LO BND X2232 0
 	FR BND X2233
 	LO BND X2233 0
 	FR BND X2234
 	LO BND X2234 0
 	FR BND X2235
 	LO BND X2235 0
 	FR BND X2236
 	LO BND X2236 0
 	FR BND X2237
 	LO BND X2237 0
 	FR BND X2238
 	LO BND X2238 0
 	FR BND X2239
 	LO BND X2239 0
 	FR BND X2240
 	LO BND X2240 0
 	FR BND X2241
 	LO BND X2241 0
 	FR BND X2242
 	LO BND X2242 0
 	FR BND X2243
 	LO BND X2243 0
 	FR BND X2244
 	LO BND X2244 0
 	FR BND X2245
 	LO BND X2245 0
 	FR BND X2246
 	LO BND X2246 0
 	FR BND X2247
 	LO BND X2247 0
 	FR BND X2248
 	LO BND X2248 0
 	FR BND X2249
 	LO BND X2249 0
 	FR BND X2250
 	LO BND X2250 0
 	FR BND X2251
 	LO BND X2251 0
 	FR BND X2252
 	LO BND X2252 0
 	FR BND X2253
 	LO BND X2253 0
 	FR BND X2254
 	LO BND X2254 0
 	FR BND X2255
 	LO BND X2255 0
 	FR BND X2256
 	LO BND X2256 0
 	FR BND X2257
 	LO BND X2257 0
 	FR BND X2258
 	LO BND X2258 0
 	FR BND X2259
 	LO BND X2259 0
 	FR BND X2260
 	LO BND X2260 0
 	FR BND X2261
 	LO BND X2261 0
 	FR BND X2262
 	LO BND X2262 0
 	FR BND X2263
 	LO BND X2263 0
 	FR BND X2264
 	LO BND X2264 0
 	FR BND X2265
 	LO BND X2265 0
 	FR BND X2266
 	LO BND X2266 0
 	FR BND X2267
 	LO BND X2267 0
 	FR BND X2268
 	LO BND X2268 0
 	FR BND X2269
 	LO BND X2269 0
 	FR BND X2270
 	LO BND X2270 0
 	FR BND X2271
 	LO BND X2271 0
 	FR BND X2272
 	LO BND X2272 0
 	FR BND X2273
 	LO BND X2273 0
 	FR BND X2274
 	LO BND X2274 0
 	FR BND X2275
 	LO BND X2275 0
 	FR BND X2276
 	LO BND X2276 0
 	FR BND X2277
 	LO BND X2277 0
 	FR BND X2278
 	LO BND X2278 0
 	FR BND X2279
 	LO BND X2279 0
 	FR BND X2280
 	LO BND X2280 0
 	FR BND X2281
 	LO BND X2281 0
 	FR BND X2282
 	LO BND X2282 0
 	FR BND X2283
 	LO BND X2283 0
 	FR BND X2284
 	LO BND X2284 0
 	FR BND X2285
 	LO BND X2285 0
 	FR BND X2286
 	LO BND X2286 0
 	FR BND X2287
 	LO BND X2287 0
 	FR BND X2288
 	LO BND X2288 0
 	FR BND X2289
 	LO BND X2289 0
 	FR BND X2290
 	LO BND X2290 0
 	FR BND X2291
 	LO BND X2291 0
 	FR BND X2292
 	LO BND X2292 0
 	FR BND X2293
 	LO BND X2293 0
 	FR BND X2294
 	LO BND X2294 0
 	FR BND X2295
 	LO BND X2295 0
 	FR BND X2296
 	LO BND X2296 0
 	FR BND X2297
 	LO BND X2297 0
 	FR BND X2298
 	LO BND X2298 0
 	FR BND X2299
 	LO BND X2299 0
 	FR BND X2300
 	LO BND X2300 0
 	FR BND X2301
 	LO BND X2301 0
 	FR BND X2302
 	LO BND X2302 0
 	FR BND X2303
 	LO BND X2303 0
 	FR BND X2304
 	LO BND X2304 0
 	FR BND X2305
 	LO BND X2305 0
 	FR BND X2306
 	LO BND X2306 0
 	FR BND X2307
 	LO BND X2307 0
 	FR BND X2308
 	LO BND X2308 0
 	FR BND X2309
 	LO BND X2309 0
 	FR BND X2310
 	LO BND X2310 0
 	FR BND X2311
 	LO BND X2311 0
 	FR BND X2312
 	LO BND X2312 0
 	FR BND X2313
 	LO BND X2313 0
 	FR BND X2314
 	LO BND X2314 0
 	FR BND X2315
 	LO BND X2315 0
 	FR BND X2316
 	LO BND X2316 0
 	FR BND X2317
 	LO BND X2317 0
 	FR BND X2318
 	LO BND X2318 0
 	FR BND X2319
 	LO BND X2319 0
 	FR BND X2320
 	LO BND X2320 0
 	FR BND X2321
 	LO BND X2321 0
 	FR BND X2322
 	LO BND X2322 0
 	FR BND X2323
 	LO BND X2323 0
 	FR BND X2324
 	LO BND X2324 0
 	FR BND X2325
 	LO BND X2325 0
 	FR BND X2326
 	LO BND X2326 0
 	FR BND X2327
 	LO BND X2327 0
 	FR BND X2328
 	LO BND X2328 0
 	FR BND X2329
 	LO BND X2329 0
 	FR BND X2330
 	LO BND X2330 0
 	FR BND X2331
 	LO BND X2331 0
 	FR BND X2332
 	LO BND X2332 0
 	FR BND X2333
 	LO BND X2333 0
 	FR BND X2334
 	LO BND X2334 0
 	FR BND X2335
 	LO BND X2335 0
 	FR BND X2336
 	LO BND X2336 0
 	FR BND X2337
 	LO BND X2337 0
 	FR BND X2338
 	LO BND X2338 0
 	FR BND X2339
 	LO BND X2339 0
 	FR BND X2340
 	LO BND X2340 0
 	FR BND X2341
 	LO BND X2341 0
 	FR BND X2342
 	LO BND X2342 0
 	FR BND X2343
 	LO BND X2343 0
 	FR BND X2344
 	LO BND X2344 0
 	FR BND X2345
 	LO BND X2345 0
 	FR BND X2346
 	LO BND X2346 0
 	FR BND X2347
 	LO BND X2347 0
 	FR BND X2348
 	LO BND X2348 0
 	FR BND X2349
 	LO BND X2349 0
 	FR BND X2350
 	LO BND X2350 0
 	FR BND X2351
 	LO BND X2351 0
 	FR BND X2352
 	LO BND X2352 0
 	FR BND X2353
 	LO BND X2353 0
 	FR BND X2354
 	LO BND X2354 0
 	FR BND X2355
 	LO BND X2355 0
 	FR BND X2356
 	LO BND X2356 0
 	FR BND X2357
 	LO BND X2357 0
 	FR BND X2358
 	LO BND X2358 0
 	FR BND X2359
 	LO BND X2359 0
 	FR BND X2360
 	LO BND X2360 0
 	FR BND X2361
 	LO BND X2361 0
 	FR BND X2362
 	LO BND X2362 0
 	FR BND X2363
 	LO BND X2363 0
 	FR BND X2364
 	LO BND X2364 0
 	FR BND X2365
 	LO BND X2365 0
 	FR BND X2366
 	LO BND X2366 0
 	FR BND X2367
 	LO BND X2367 0
 	FR BND X2368
 	LO BND X2368 0
 	FR BND X2369
 	LO BND X2369 0
 	FR BND X2370
 	LO BND X2370 0
 	FR BND X2371
 	LO BND X2371 0
 	FR BND X2372
 	LO BND X2372 0
 	FR BND X2373
 	LO BND X2373 0
 	FR BND X2374
 	LO BND X2374 0
 	FR BND X2375
 	LO BND X2375 0
 	FR BND X2376
 	LO BND X2376 0
 	FR BND X2377
 	LO BND X2377 0
 	FR BND X2378
 	LO BND X2378 0
 	FR BND X2379
 	LO BND X2379 0
 	FR BND X2380
 	LO BND X2380 0
 	FR BND X2381
 	LO BND X2381 0
 	FR BND X2382
 	LO BND X2382 0
 	FR BND X2383
 	LO BND X2383 0
 	FR BND X2384
 	LO BND X2384 0
 	FR BND X2385
 	LO BND X2385 0
 	FR BND X2386
 	LO BND X2386 0
 	FR BND X2387
 	LO BND X2387 0
 	FR BND X2388
 	LO BND X2388 0
 	FR BND X2389
 	LO BND X2389 0
 	FR BND X2390
 	LO BND X2390 0
 	FR BND X2391
 	LO BND X2391 0
 	FR BND X2392
 	LO BND X2392 0
 	FR BND X2393
 	LO BND X2393 0
 	FR BND X2394
 	LO BND X2394 0
 	FR BND X2395
 	LO BND X2395 0
 	FR BND X2396
 	LO BND X2396 0
 	FR BND X2397
 	LO BND X2397 0
 	FR BND X2398
 	LO BND X2398 0
 	FR BND X2399
 	LO BND X2399 0
 	FR BND X2400
 	LO BND X2400 0
 	FR BND X2401
 	LO BND X2401 0
 	FR BND X2402
 	LO BND X2402 0
 	FR BND X2403
 	LO BND X2403 0
 	FR BND X2404
 	LO BND X2404 0
 	FR BND X2405
 	LO BND X2405 0
 	FR BND X2406
 	LO BND X2406 0
 	FR BND X2407
 	LO BND X2407 0
 	FR BND X2408
 	LO BND X2408 0
 	FR BND X2409
 	LO BND X2409 0
 	FR BND X2410
 	LO BND X2410 0
 	FR BND X2411
 	LO BND X2411 0
 	FR BND X2412
 	LO BND X2412 0
 	FR BND X2413
 	LO BND X2413 0
 	FR BND X2414
 	LO BND X2414 0
 	FR BND X2415
 	LO BND X2415 0
 	FR BND X2416
 	LO BND X2416 0
 	FR BND X2417
 	LO BND X2417 0
 	FR BND X2418
 	LO BND X2418 0
 	FR BND X2419
 	LO BND X2419 0
 	FR BND X2420
 	LO BND X2420 0
 	FR BND X2421
 	LO BND X2421 0
 	FR BND X2422
 	LO BND X2422 0
 	FR BND X2423
 	LO BND X2423 0
 	FR BND X2424
 	LO BND X2424 0
 	FR BND X2425
 	LO BND X2425 0
 	FR BND X2426
 	LO BND X2426 0
 	FR BND X2427
 	LO BND X2427 0
 	FR BND X2428
 	LO BND X2428 0
 	FR BND X2429
 	LO BND X2429 0
 	FR BND X2430
 	LO BND X2430 0
 	FR BND X2431
 	LO BND X2431 0
 	FR BND X2432
 	LO BND X2432 0
 	FR BND X2433
 	LO BND X2433 0
 	FR BND X2434
 	LO BND X2434 0
 	FR BND X2435
 	LO BND X2435 0
 	FR BND X2436
 	LO BND X2436 0
 	FR BND X2437
 	LO BND X2437 0
 	FR BND X2438
 	LO BND X2438 0
 	FR BND X2439
 	LO BND X2439 0
 	FR BND X2440
 	LO BND X2440 0
 	FR BND X2441
 	LO BND X2441 0
 	FR BND X2442
 	LO BND X2442 0
 	FR BND X2443
 	LO BND X2443 0
 	FR BND X2444
 	LO BND X2444 0
 	FR BND X2445
 	LO BND X2445 0
 	FR BND X2446
 	LO BND X2446 0
 	FR BND X2447
 	LO BND X2447 0
 	FR BND X2448
 	LO BND X2448 0
 	FR BND X2449
 	LO BND X2449 0
 	FR BND X2450
 	LO BND X2450 0
 	FR BND X2451
 	LO BND X2451 0
 	FR BND X2452
 	LO BND X2452 0
 	FR BND X2453
 	LO BND X2453 0
 	FR BND X2454
 	LO BND X2454 0
 	FR BND X2455
 	LO BND X2455 0
 	FR BND X2456
 	LO BND X2456 0
 	FR BND X2457
 	LO BND X2457 0
 	FR BND X2458
 	LO BND X2458 0
 	FR BND X2459
 	LO BND X2459 0
 	FR BND X2460
 	LO BND X2460 0
 	FR BND X2461
 	LO BND X2461 0
 	FR BND X2462
 	LO BND X2462 0
 	FR BND X2463
 	LO BND X2463 0
 	FR BND X2464
 	LO BND X2464 0
 	FR BND X2465
 	LO BND X2465 0
 	FR BND X2466
 	LO BND X2466 0
 	FR BND X2467
 	LO BND X2467 0
 	FR BND X2468
 	LO BND X2468 0
 	FR BND X2469
 	LO BND X2469 0
 	FR BND X2470
 	LO BND X2470 0
 	FR BND X2471
 	LO BND X2471 0
 	FR BND X2472
 	LO BND X2472 0
 	FR BND X2473
 	LO BND X2473 0
 	FR BND X2474
 	LO BND X2474 0
 	FR BND X2475
 	LO BND X2475 0
 	FR BND X2476
 	LO BND X2476 0
 	FR BND X2477
 	LO BND X2477 0
 	FR BND X2478
 	LO BND X2478 0
 	FR BND X2479
 	LO BND X2479 0
 	FR BND X2480
 	LO BND X2480 0
 	FR BND X2481
 	LO BND X2481 0
 	FR BND X2482
 	LO BND X2482 0
 	FR BND X2483
 	LO BND X2483 0
 	FR BND X2484
 	LO BND X2484 0
 	FR BND X2485
 	LO BND X2485 0
 	FR BND X2486
 	LO BND X2486 0
 	FR BND X2487
 	LO BND X2487 0
 	FR BND X2488
 	LO BND X2488 0
 	FR BND X2489
 	LO BND X2489 0
 	FR BND X2490
 	LO BND X2490 0
 	FR BND X2491
 	LO BND X2491 0
 	FR BND X2492
 	LO BND X2492 0
 	FR BND X2493
 	LO BND X2493 0
 	FR BND X2494
 	LO BND X2494 0
 	FR BND X2495
 	LO BND X2495 0
 	FR BND X2496
 	LO BND X2496 0
 	FR BND X2497
 	LO BND X2497 0
 	FR BND X2498
 	LO BND X2498 0
 	FR BND X2499
 	LO BND X2499 0
 	FR BND X2500
 	LO BND X2500 0
 	FR BND X2501
 	LO BND X2501 0
 	FR BND X2502
 	LO BND X2502 0
 	FR BND X2503
 	LO BND X2503 0
 	FR BND X2504
 	LO BND X2504 0
 	FR BND X2505
 	LO BND X2505 0
 	FR BND X2506
 	LO BND X2506 0
 	FR BND X2507
 	LO BND X2507 0
 	FR BND X2508
 	LO BND X2508 0
 	FR BND X2509
 	LO BND X2509 0
 	FR BND X2510
 	LO BND X2510 0
 	FR BND X2511
 	LO BND X2511 0
 	FR BND X2512
 	LO BND X2512 0
 	FR BND X2513
 	LO BND X2513 0
 	FR BND X2514
 	LO BND X2514 0
 	FR BND X2515
 	LO BND X2515 0
 	FR BND X2516
 	LO BND X2516 0
 	FR BND X2517
 	LO BND X2517 0
 	FR BND X2518
 	LO BND X2518 0
 	FR BND X2519
 	LO BND X2519 0
 	FR BND X2520
 	LO BND X2520 0
 	FR BND X2521
 	LO BND X2521 0
 	FR BND X2522
 	LO BND X2522 0
 	FR BND X2523
 	LO BND X2523 0
 	FR BND X2524
 	LO BND X2524 0
 	FR BND X2525
 	LO BND X2525 0
 	FR BND X2526
 	LO BND X2526 0
 	FR BND X2527
 	LO BND X2527 0
 	FR BND X2528
 	LO BND X2528 0
 	FR BND X2529
 	LO BND X2529 0
 	FR BND X2530
 	LO BND X2530 0
 	FR BND X2531
 	LO BND X2531 0
 	FR BND X2532
 	LO BND X2532 0
 	FR BND X2533
 	LO BND X2533 0
 	FR BND X2534
 	LO BND X2534 0
 	FR BND X2535
 	LO BND X2535 0
 	FR BND X2536
 	LO BND X2536 0
 	FR BND X2537
 	LO BND X2537 0
 	FR BND X2538
 	LO BND X2538 0
 	FR BND X2539
 	LO BND X2539 0
 	FR BND X2540
 	LO BND X2540 0
 	FR BND X2541
 	LO BND X2541 0
 	FR BND X2542
 	LO BND X2542 0
 	FR BND X2543
 	LO BND X2543 0
 	FR BND X2544
 	LO BND X2544 0
 	FR BND X2545
 	LO BND X2545 0
 	FR BND X2546
 	LO BND X2546 0
 	FR BND X2547
 	LO BND X2547 0
 	FR BND X2548
 	LO BND X2548 0
 	FR BND X2549
 	LO BND X2549 0
 	FR BND X2550
 	LO BND X2550 0
 	FR BND X2551
 	LO BND X2551 0
 	FR BND X2552
 	LO BND X2552 0
 	FR BND X2553
 	LO BND X2553 0
 	FR BND X2554
 	LO BND X2554 0
 	FR BND X2555
 	LO BND X2555 0
 	FR BND X2556
 	LO BND X2556 0
 	FR BND X2557
 	LO BND X2557 0
 	FR BND X2558
 	LO BND X2558 0
 	FR BND X2559
 	LO BND X2559 0
 	FR BND X2560
 	LO BND X2560 0
 	FR BND X2561
 	LO BND X2561 0
 	FR BND X2562
 	LO BND X2562 0
 	FR BND X2563
 	LO BND X2563 0
 	FR BND X2564
 	LO BND X2564 0
 	FR BND X2565
 	LO BND X2565 0
 	FR BND X2566
 	LO BND X2566 0
 	FR BND X2567
 	LO BND X2567 0
 	FR BND X2568
 	LO BND X2568 0
 	FR BND X2569
 	LO BND X2569 0
 	FR BND X2570
 	LO BND X2570 0
 	FR BND X2571
 	LO BND X2571 0
 	FR BND X2572
 	LO BND X2572 0
 	FR BND X2573
 	LO BND X2573 0
 	FR BND X2574
 	LO BND X2574 0
 	FR BND X2575
 	LO BND X2575 0
 	FR BND X2576
 	LO BND X2576 0
 	FR BND X2577
 	LO BND X2577 0
 	FR BND X2578
 	LO BND X2578 0
 	FR BND X2579
 	LO BND X2579 0
 	FR BND X2580
 	LO BND X2580 0
 	FR BND X2581
 	LO BND X2581 0
 	FR BND X2582
 	LO BND X2582 0
 	FR BND X2583
 	LO BND X2583 0
 	FR BND X2584
 	LO BND X2584 0
 	FR BND X2585
 	LO BND X2585 0
 	FR BND X2586
 	LO BND X2586 0
 	FR BND X2587
 	LO BND X2587 0
 	FR BND X2588
 	LO BND X2588 0
 	FR BND X2589
 	LO BND X2589 0
 	FR BND X2590
 	LO BND X2590 0
 	FR BND X2591
 	LO BND X2591 0
 	FR BND X2592
 	LO BND X2592 0
 	FR BND X2593
 	LO BND X2593 0
 	FR BND X2594
 	LO BND X2594 0
 	FR BND X2595
 	LO BND X2595 0
 	FR BND X2596
 	LO BND X2596 0
 	FR BND X2597
 	LO BND X2597 0
 	FR BND X2598
 	LO BND X2598 0
 	FR BND X2599
 	LO BND X2599 0
 	FR BND X2600
 	LO BND X2600 0
 	FR BND X2601
 	LO BND X2601 0
 	FR BND X2602
 	LO BND X2602 0
 	FR BND X2603
 	LO BND X2603 0
 	FR BND X2604
 	LO BND X2604 0
 	FR BND X2605
 	LO BND X2605 0
 	FR BND X2606
 	LO BND X2606 0
 	FR BND X2607
 	LO BND X2607 0
 	FR BND X2608
 	LO BND X2608 0
 	FR BND X2609
 	LO BND X2609 0
 	FR BND X2610
 	LO BND X2610 0
 	FR BND X2611
 	LO BND X2611 0
 	FR BND X2612
 	LO BND X2612 0
 	FR BND X2613
 	LO BND X2613 0
 	FR BND X2614
 	LO BND X2614 0
 	FR BND X2615
 	LO BND X2615 0
 	FR BND X2616
 	LO BND X2616 0
 	FR BND X2617
 	LO BND X2617 0
 	FR BND X2618
 	LO BND X2618 0
 	FR BND X2619
 	LO BND X2619 0
 	FR BND X2620
 	LO BND X2620 0
 	FR BND X2621
 	LO BND X2621 0
 	FR BND X2622
 	LO BND X2622 0
 	FR BND X2623
 	LO BND X2623 0
 	FR BND X2624
 	LO BND X2624 0
 	FR BND X2625
 	LO BND X2625 0
 	FR BND X2626
 	LO BND X2626 0
 	FR BND X2627
 	LO BND X2627 0
 	FR BND X2628
 	LO BND X2628 0
 	FR BND X2629
 	LO BND X2629 0
 	FR BND X2630
 	LO BND X2630 0
 	FR BND X2631
 	LO BND X2631 0
 	FR BND X2632
 	LO BND X2632 0
 	FR BND X2633
 	LO BND X2633 0
 	FR BND X2634
 	LO BND X2634 0
 	FR BND X2635
 	LO BND X2635 0
 	FR BND X2636
 	LO BND X2636 0
 	FR BND X2637
 	LO BND X2637 0
 	FR BND X2638
 	LO BND X2638 0
 	FR BND X2639
 	LO BND X2639 0
 	FR BND X2640
 	LO BND X2640 0
 	FR BND X2641
 	LO BND X2641 0
 	FR BND X2642
 	LO BND X2642 0
 	FR BND X2643
 	LO BND X2643 0
 	FR BND X2644
 	LO BND X2644 0
 	FR BND X2645
 	LO BND X2645 0
 	FR BND X2646
 	LO BND X2646 0
 	FR BND X2647
 	LO BND X2647 0
 	FR BND X2648
 	LO BND X2648 0
 	FR BND X2649
 	LO BND X2649 0
 	FR BND X2650
 	LO BND X2650 0
 	FR BND X2651
 	LO BND X2651 0
 	FR BND X2652
 	LO BND X2652 0
 	FR BND X2653
 	LO BND X2653 0
 	FR BND X2654
 	LO BND X2654 0
 	FR BND X2655
 	LO BND X2655 0
 	FR BND X2656
 	LO BND X2656 0
 	FR BND X2657
 	LO BND X2657 0
 	FR BND X2658
 	LO BND X2658 0
 	FR BND X2659
 	LO BND X2659 0
 	FR BND X2660
 	LO BND X2660 0
 	FR BND X2661
 	LO BND X2661 0
 	FR BND X2662
 	LO BND X2662 0
 	FR BND X2663
 	LO BND X2663 0
 	FR BND X2664
 	LO BND X2664 0
 	FR BND X2665
 	LO BND X2665 0
 	FR BND X2666
 	LO BND X2666 0
 	FR BND X2667
 	LO BND X2667 0
 	FR BND X2668
 	LO BND X2668 0
 	FR BND X2669
 	LO BND X2669 0
 	FR BND X2670
 	LO BND X2670 0
 	FR BND X2671
 	LO BND X2671 0
 	FR BND X2672
 	LO BND X2672 0
 	FR BND X2673
 	LO BND X2673 0
 	FR BND X2674
 	LO BND X2674 0
 	FR BND X2675
 	LO BND X2675 0
 	FR BND X2676
 	LO BND X2676 0
 	FR BND X2677
 	LO BND X2677 0
 	FR BND X2678
 	LO BND X2678 0
 	FR BND X2679
 	LO BND X2679 0
 	FR BND X2680
 	LO BND X2680 0
 	FR BND X2681
 	LO BND X2681 0
 	FR BND X2682
 	LO BND X2682 0
 	FR BND X2683
 	LO BND X2683 0
 	FR BND X2684
 	LO BND X2684 0
 	FR BND X2685
 	LO BND X2685 0
 	FR BND X2686
 	LO BND X2686 0
 	FR BND X2687
 	LO BND X2687 0
 	FR BND X2688
 	LO BND X2688 0
 	FR BND X2689
 	LO BND X2689 0
 	FR BND X2690
 	LO BND X2690 0
 	FR BND X2691
 	LO BND X2691 0
 	FR BND X2692
 	LO BND X2692 0
 	FR BND X2693
 	LO BND X2693 0
 	FR BND X2694
 	LO BND X2694 0
 	FR BND X2695
 	LO BND X2695 0
 	FR BND X2696
 	LO BND X2696 0
 	FR BND X2697
 	LO BND X2697 0
 	FR BND X2698
 	LO BND X2698 0
 	FR BND X2699
 	LO BND X2699 0
 	FR BND X2700
 	LO BND X2700 0
 	FR BND X2701
 	LO BND X2701 0
 	FR BND X2702
 	LO BND X2702 0
 	FR BND X2703
 	LO BND X2703 0
 	FR BND X2704
 	LO BND X2704 0
 	FR BND X2705
 	LO BND X2705 0
 	FR BND X2706
 	LO BND X2706 0
 	FR BND X2707
 	LO BND X2707 0
 	FR BND X2708
 	LO BND X2708 0
 	FR BND X2709
 	LO BND X2709 0
 	FR BND X2710
 	LO BND X2710 0
 	FR BND X2711
 	LO BND X2711 0
 	FR BND X2712
 	LO BND X2712 0
 	FR BND X2713
 	LO BND X2713 0
 	FR BND X2714
 	LO BND X2714 0
 	FR BND X2715
 	LO BND X2715 0
 	FR BND X2716
 	LO BND X2716 0
 	FR BND X2717
 	LO BND X2717 0
 	FR BND X2718
 	LO BND X2718 0
 	FR BND X2719
 	LO BND X2719 0
 	FR BND X2720
 	LO BND X2720 0
 	FR BND X2721
 	LO BND X2721 0
 	FR BND X2722
 	LO BND X2722 0
 	FR BND X2723
 	LO BND X2723 0
 	FR BND X2724
 	LO BND X2724 0
 	FR BND X2725
 	LO BND X2725 0
 	FR BND X2726
 	LO BND X2726 0
 	FR BND X2727
 	LO BND X2727 0
 	FR BND X2728
 	LO BND X2728 0
 	FR BND X2729
 	LO BND X2729 0
 	FR BND X2730
 	LO BND X2730 0
 	FR BND X2731
 	LO BND X2731 0
 	FR BND X2732
 	LO BND X2732 0
 	FR BND X2733
 	LO BND X2733 0
 	FR BND X2734
 	LO BND X2734 0
 	FR BND X2735
 	LO BND X2735 0
 	FR BND X2736
 	LO BND X2736 0
 	FR BND X2737
 	LO BND X2737 0
 	FR BND X2738
 	LO BND X2738 0
 	FR BND X2739
 	LO BND X2739 0
 	FR BND X2740
 	LO BND X2740 0
 	FR BND X2741
 	LO BND X2741 0
 	FR BND X2742
 	LO BND X2742 0
 	FR BND X2743
 	LO BND X2743 0
 	FR BND X2744
 	LO BND X2744 0
 	FR BND X2745
 	LO BND X2745 0
 	FR BND X2746
 	LO BND X2746 0
 	FR BND X2747
 	LO BND X2747 0
 	FR BND X2748
 	LO BND X2748 0
 	FR BND X2749
 	LO BND X2749 0
 	FR BND X2750
 	LO BND X2750 0
 	FR BND X2751
 	LO BND X2751 0
 	FR BND X2752
 	LO BND X2752 0
 	FR BND X2753
 	LO BND X2753 0
 	FR BND X2754
 	LO BND X2754 0
 	FR BND X2755
 	LO BND X2755 0
 	FR BND X2756
 	LO BND X2756 0
 	FR BND X2757
 	LO BND X2757 0
 	FR BND X2758
 	LO BND X2758 0
 	FR BND X2759
 	LO BND X2759 0
 	FR BND X2760
 	LO BND X2760 0
 	FR BND X2761
 	LO BND X2761 0
 	FR BND X2762
 	LO BND X2762 0
 	FR BND X2763
 	LO BND X2763 0
 	FR BND X2764
 	LO BND X2764 0
 	FR BND X2765
 	LO BND X2765 0
 	FR BND X2766
 	LO BND X2766 0
 	FR BND X2767
 	LO BND X2767 0
 	FR BND X2768
 	LO BND X2768 0
 	FR BND X2769
 	LO BND X2769 0
 	FR BND X2770
 	LO BND X2770 0
 	FR BND X2771
 	LO BND X2771 0
 	FR BND X2772
 	LO BND X2772 0
 	FR BND X2773
 	LO BND X2773 0
 	FR BND X2774
 	LO BND X2774 0
 	FR BND X2775
 	LO BND X2775 0
 	FR BND X2776
 	LO BND X2776 0
 	FR BND X2777
 	LO BND X2777 0
 	FR BND X2778
 	LO BND X2778 0
 	FR BND X2779
 	LO BND X2779 0
 	FR BND X2780
 	LO BND X2780 0
 	FR BND X2781
 	LO BND X2781 0
 	FR BND X2782
 	LO BND X2782 0
 	FR BND X2783
 	LO BND X2783 0
 	FR BND X2784
 	LO BND X2784 0
 	FR BND X2785
 	LO BND X2785 0
 	FR BND X2786
 	LO BND X2786 0
 	FR BND X2787
 	LO BND X2787 0
 	FR BND X2788
 	LO BND X2788 0
 	FR BND X2789
 	LO BND X2789 0
 	FR BND X2790
 	LO BND X2790 0
 	FR BND X2791
 	LO BND X2791 0
 	FR BND X2792
 	LO BND X2792 0
 	FR BND X2793
 	LO BND X2793 0
 	FR BND X2794
 	LO BND X2794 0
 	FR BND X2795
 	LO BND X2795 0
 	FR BND X2796
 	LO BND X2796 0
 	FR BND X2797
 	LO BND X2797 0
 	FR BND X2798
 	LO BND X2798 0
 	FR BND X2799
 	LO BND X2799 0
 	FR BND X2800
 	LO BND X2800 0
 	FR BND X2801
 	LO BND X2801 0
 	FR BND X2802
 	LO BND X2802 0
 	FR BND X2803
 	LO BND X2803 0
 	FR BND X2804
 	LO BND X2804 0
 	FR BND X2805
 	LO BND X2805 0
 	FR BND X2806
 	LO BND X2806 0
 	FR BND X2807
 	LO BND X2807 0
 	FR BND X2808
 	LO BND X2808 0
 	FR BND X2809
 	LO BND X2809 0
 	FR BND X2810
 	LO BND X2810 0
 	FR BND X2811
 	LO BND X2811 0
 	FR BND X2812
 	LO BND X2812 0
 	FR BND X2813
 	LO BND X2813 0
 	FR BND X2814
 	LO BND X2814 0
 	FR BND X2815
 	LO BND X2815 0
 	FR BND X2816
 	LO BND X2816 0
 	FR BND X2817
 	LO BND X2817 0
 	FR BND X2818
 	LO BND X2818 0
 	FR BND X2819
 	LO BND X2819 0
 	FR BND X2820
 	LO BND X2820 0
 	FR BND X2821
 	LO BND X2821 0
 	FR BND X2822
 	LO BND X2822 0
 	FR BND X2823
 	LO BND X2823 0
 	FR BND X2824
 	LO BND X2824 0
 	FR BND X2825
 	LO BND X2825 0
 	FR BND X2826
 	LO BND X2826 0
 	FR BND X2827
 	LO BND X2827 0
 	FR BND X2828
 	LO BND X2828 0
 	FR BND X2829
 	LO BND X2829 0
 	FR BND X2830
 	LO BND X2830 0
 	FR BND X2831
 	LO BND X2831 0
 	FR BND X2832
 	LO BND X2832 0
 	FR BND X2833
 	LO BND X2833 0
 	FR BND X2834
 	LO BND X2834 0
 	FR BND X2835
 	LO BND X2835 0
 	FR BND X2836
 	LO BND X2836 0
 	FR BND X2837
 	LO BND X2837 0
 	FR BND X2838
 	LO BND X2838 0
 	FR BND X2839
 	LO BND X2839 0
 	FR BND X2840
 	LO BND X2840 0
 	FR BND X2841
 	LO BND X2841 0
 	FR BND X2842
 	LO BND X2842 0
 	FR BND X2843
 	LO BND X2843 0
 	FR BND X2844
 	LO BND X2844 0
 	FR BND X2845
 	LO BND X2845 0
 	FR BND X2846
 	LO BND X2846 0
 	FR BND X2847
 	LO BND X2847 0
 	FR BND X2848
 	LO BND X2848 0
 	FR BND X2849
 	LO BND X2849 0
 	FR BND X2850
 	LO BND X2850 0
 	FR BND X2851
 	LO BND X2851 0
 	FR BND X2852
 	LO BND X2852 0
 	FR BND X2853
 	LO BND X2853 0
 	FR BND X2854
 	LO BND X2854 0
 	FR BND X2855
 	LO BND X2855 0
 	FR BND X2856
 	LO BND X2856 0
 	FR BND X2857
 	LO BND X2857 0
 	FR BND X2858
 	LO BND X2858 0
 	FR BND X2859
 	LO BND X2859 0
 	FR BND X2860
 	LO BND X2860 0
 	FR BND X2861
 	LO BND X2861 0
 	FR BND X2862
 	LO BND X2862 0
 	FR BND X2863
 	LO BND X2863 0
 	FR BND X2864
 	LO BND X2864 0
 	FR BND X2865
 	LO BND X2865 0
 	FR BND X2866
 	LO BND X2866 0
 	FR BND X2867
 	LO BND X2867 0
 	FR BND X2868
 	LO BND X2868 0
 	FR BND X2869
 	LO BND X2869 0
 	FR BND X2870
 	LO BND X2870 0
 	FR BND X2871
 	LO BND X2871 0
 	FR BND X2872
 	LO BND X2872 0
 	FR BND X2873
 	LO BND X2873 0
 	FR BND X2874
 	LO BND X2874 0
 	FR BND X2875
 	LO BND X2875 0
 	FR BND X2876
 	LO BND X2876 0
 	FR BND X2877
 	LO BND X2877 0
 	FR BND X2878
 	LO BND X2878 0
 	FR BND X2879
 	LO BND X2879 0
 	FR BND X2880
 	LO BND X2880 0
 	FR BND X2881
 	LO BND X2881 0
 	FR BND X2882
 	LO BND X2882 0
 	FR BND X2883
 	LO BND X2883 0
 	FR BND X2884
 	LO BND X2884 0
 	FR BND X2885
 	LO BND X2885 0
 	FR BND X2886
 	LO BND X2886 0
 	FR BND X2887
 	LO BND X2887 0
 	FR BND X2888
 	LO BND X2888 0
 	FR BND X2889
 	LO BND X2889 0
 	FR BND X2890
 	LO BND X2890 0
 	FR BND X2891
 	LO BND X2891 0
 	FR BND X2892
 	LO BND X2892 0
 	FR BND X2893
 	LO BND X2893 0
 	FR BND X2894
 	LO BND X2894 0
 	FR BND X2895
 	LO BND X2895 0
 	FR BND X2896
 	LO BND X2896 0
 	FR BND X2897
 	LO BND X2897 0
 	FR BND X2898
 	LO BND X2898 0
 	FR BND X2899
 	LO BND X2899 0
 	FR BND X2900
 	LO BND X2900 0
 	FR BND X2901
 	LO BND X2901 0
 	FR BND X2902
 	LO BND X2902 0
 	FR BND X2903
 	LO BND X2903 0
 	FR BND X2904
 	LO BND X2904 0
 	FR BND X2905
 	LO BND X2905 0
 	FR BND X2906
 	LO BND X2906 0
 	FR BND X2907
 	LO BND X2907 0
 	FR BND X2908
 	LO BND X2908 0
 	FR BND X2909
 	LO BND X2909 0
 	FR BND X2910
 	LO BND X2910 0
 	FR BND X2911
 	LO BND X2911 0
 	FR BND X2912
 	LO BND X2912 0
 	FR BND X2913
 	LO BND X2913 0
 	FR BND X2914
 	LO BND X2914 0
 	FR BND X2915
 	LO BND X2915 0
 	FR BND X2916
 	LO BND X2916 0
 	FR BND X2917
 	LO BND X2917 0
 	FR BND X2918
 	LO BND X2918 0
 	FR BND X2919
 	LO BND X2919 0
 	FR BND X2920
 	LO BND X2920 0
 	FR BND X2921
 	LO BND X2921 0
 	FR BND X2922
 	LO BND X2922 0
 	FR BND X2923
 	LO BND X2923 0
 	FR BND X2924
 	LO BND X2924 0
 	FR BND X2925
 	LO BND X2925 0
 	FR BND X2926
 	LO BND X2926 0
 	FR BND X2927
 	LO BND X2927 0
 	FR BND X2928
 	LO BND X2928 0
 	FR BND X2929
 	LO BND X2929 0
 	FR BND X2930
 	LO BND X2930 0
 	FR BND X2931
 	LO BND X2931 0
 	FR BND X2932
 	LO BND X2932 0
 	FR BND X2933
 	LO BND X2933 0
 	FR BND X2934
 	LO BND X2934 0
 	FR BND X2935
 	LO BND X2935 0
 	FR BND X2936
 	LO BND X2936 0
 	FR BND X2937
 	LO BND X2937 0
 	FR BND X2938
 	LO BND X2938 0
 	FR BND X2939
 	LO BND X2939 0
 	FR BND X2940
 	LO BND X2940 0
 	FR BND X2941
 	LO BND X2941 0
 	FR BND X2942
 	LO BND X2942 0
 	FR BND X2943
 	LO BND X2943 0
 	FR BND X2944
 	LO BND X2944 0
 	FR BND X2945
 	LO BND X2945 0
 	FR BND X2946
 	LO BND X2946 0
 	FR BND X2947
 	LO BND X2947 0
 	FR BND X2948
 	LO BND X2948 0
 	FR BND X2949
 	LO BND X2949 0
 	FR BND X2950
 	LO BND X2950 0
 	FR BND X2951
 	LO BND X2951 0
 	FR BND X2952
 	LO BND X2952 0
 	FR BND X2953
 	LO BND X2953 0
 	FR BND X2954
 	LO BND X2954 0
 	FR BND X2955
 	LO BND X2955 0
 	FR BND X2956
 	LO BND X2956 0
 	FR BND X2957
 	LO BND X2957 0
 	FR BND X2958
 	LO BND X2958 0
 	FR BND X2959
 	LO BND X2959 0
 	FR BND X2960
 	LO BND X2960 0
 	FR BND X2961
 	LO BND X2961 0
 	FR BND X2962
 	LO BND X2962 0
 	FR BND X2963
 	LO BND X2963 0
 	FR BND X2964
 	LO BND X2964 0
 	FR BND X2965
 	LO BND X2965 0
 	FR BND X2966
 	LO BND X2966 0
 	FR BND X2967
 	LO BND X2967 0
 	FR BND X2968
 	LO BND X2968 0
 	FR BND X2969
 	LO BND X2969 0
 	FR BND X2970
 	LO BND X2970 0
 	FR BND X2971
 	LO BND X2971 0
 	FR BND X2972
 	LO BND X2972 0
 	FR BND X2973
 	LO BND X2973 0
 	FR BND X2974
 	LO BND X2974 0
 	FR BND X2975
 	LO BND X2975 0
 	FR BND X2976
 	LO BND X2976 0
 	FR BND X2977
 	LO BND X2977 0
 	FR BND X2978
 	LO BND X2978 0
 	FR BND X2979
 	LO BND X2979 0
 	FR BND X2980
 	LO BND X2980 0
 	FR BND X2981
 	LO BND X2981 0
 	FR BND X2982
 	LO BND X2982 0
 	FR BND X2983
 	LO BND X2983 0
 	FR BND X2984
 	LO BND X2984 0
 	FR BND X2985
 	LO BND X2985 0
 	FR BND X2986
 	LO BND X2986 0
 	FR BND X2987
 	LO BND X2987 0
 	FR BND X2988
 	LO BND X2988 0
 	FR BND X2989
 	LO BND X2989 0
 	FR BND X2990
 	LO BND X2990 0
 	FR BND X2991
 	LO BND X2991 0
 	FR BND X2992
 	LO BND X2992 0
 	FR BND X2993
 	LO BND X2993 0
 	FR BND X2994
 	LO BND X2994 0
 	FR BND X2995
 	LO BND X2995 0
 	FR BND X2996
 	LO BND X2996 0
 	FR BND X2997
 	LO BND X2997 0
 	FR BND X2998
 	LO BND X2998 0
 	FR BND X2999
 	LO BND X2999 0
 	FR BND X3000
 	LO BND X3000 0
 	FR BND X3001
 	LO BND X3001 0
 	FR BND X3002
 	LO BND X3002 0
 	FR BND X3003
 	LO BND X3003 0
 	FR BND X3004
 	LO BND X3004 0
 	FR BND X3005
 	LO BND X3005 0
 	FR BND X3006
 	LO BND X3006 0
 	FR BND X3007
 	LO BND X3007 0
 	FR BND X3008
 	LO BND X3008 0
 	FR BND X3009
 	LO BND X3009 0
 	FR BND X3010
 	LO BND X3010 0
 	FR BND X3011
 	LO BND X3011 0
 	FR BND X3012
 	LO BND X3012 0
 	FR BND X3013
 	LO BND X3013 0
 	FR BND X3014
 	LO BND X3014 0
 	FR BND X3015
 	LO BND X3015 0
 	FR BND X3016
 	LO BND X3016 0
 	FR BND X3017
 	LO BND X3017 0
 	FR BND X3018
 	LO BND X3018 0
 	FR BND X3019
 	LO BND X3019 0
 	FR BND X3020
 	LO BND X3020 0
 	FR BND X3021
 	LO BND X3021 0
 	FR BND X3022
 	LO BND X3022 0
 	FR BND X3023
 	LO BND X3023 0
 	FR BND X3024
 	LO BND X3024 0
 	FR BND X3025
 	LO BND X3025 0
 	FR BND X3026
 	LO BND X3026 0
 	FR BND X3027
 	LO BND X3027 0
 	FR BND X3028
 	LO BND X3028 0
 	FR BND X3029
 	LO BND X3029 0
 	FR BND X3030
 	LO BND X3030 0
 	FR BND X3031
 	LO BND X3031 0
 	FR BND X3032
 	LO BND X3032 0
 	FR BND X3033
 	LO BND X3033 0
 	FR BND X3034
 	LO BND X3034 0
 	FR BND X3035
 	LO BND X3035 0
 	FR BND X3036
 	LO BND X3036 0
 	FR BND X3037
 	LO BND X3037 0
 	FR BND X3038
 	LO BND X3038 0
 	FR BND X3039
 	LO BND X3039 0
 	FR BND X3040
 	LO BND X3040 0
 	FR BND X3041
 	LO BND X3041 0
 	FR BND X3042
 	LO BND X3042 0
 	FR BND X3043
 	LO BND X3043 0
 	FR BND X3044
 	LO BND X3044 0
 	FR BND X3045
 	LO BND X3045 0
 	FR BND X3046
 	LO BND X3046 0
 	FR BND X3047
 	LO BND X3047 0
 	FR BND X3048
 	LO BND X3048 0
 	FR BND X3049
 	LO BND X3049 0
 	FR BND X3050
 	LO BND X3050 0
 	FR BND X3051
 	LO BND X3051 0
 	FR BND X3052
 	LO BND X3052 0
 	FR BND X3053
 	LO BND X3053 0
 	FR BND X3054
 	LO BND X3054 0
 	FR BND X3055
 	LO BND X3055 0
 	FR BND X3056
 	LO BND X3056 0
 	FR BND X3057
 	LO BND X3057 0
 	FR BND X3058
 	LO BND X3058 0
 	FR BND X3059
 	LO BND X3059 0
 	FR BND X3060
 	LO BND X3060 0
 	FR BND X3061
 	LO BND X3061 0
 	FR BND X3062
 	LO BND X3062 0
 	FR BND X3063
 	LO BND X3063 0
 	FR BND X3064
 	LO BND X3064 0
 	FR BND X3065
 	LO BND X3065 0
 	FR BND X3066
 	LO BND X3066 0
 	FR BND X3067
 	LO BND X3067 0
 	FR BND X3068
 	LO BND X3068 0
 	FR BND X3069
 	LO BND X3069 0
 	FR BND X3070
 	LO BND X3070 0
 	FR BND X3071
 	LO BND X3071 0
 	FR BND X3072
 	LO BND X3072 0
 	FR BND X3073
 	LO BND X3073 0
 	FR BND X3074
 	LO BND X3074 0
 	FR BND X3075
 	LO BND X3075 0
 	FR BND X3076
 	LO BND X3076 0
 	FR BND X3077
 	LO BND X3077 0
 	FR BND X3078
 	LO BND X3078 0
 	FR BND X3079
 	LO BND X3079 0
 	FR BND X3080
 	LO BND X3080 0
 	FR BND X3081
 	LO BND X3081 0
 	FR BND X3082
 	LO BND X3082 0
 	FR BND X3083
 	LO BND X3083 0
 	FR BND X3084
 	LO BND X3084 0
 	FR BND X3085
 	LO BND X3085 0
 	FR BND X3086
 	LO BND X3086 0
 	FR BND X3087
 	LO BND X3087 0
 	FR BND X3088
 	LO BND X3088 0
 	FR BND X3089
 	LO BND X3089 0
 	FR BND X3090
 	LO BND X3090 0
 	FR BND X3091
 	LO BND X3091 0
 	FR BND X3092
 	LO BND X3092 0
 	FR BND X3093
 	LO BND X3093 0
 	FR BND X3094
 	LO BND X3094 0
 	FR BND X3095
 	LO BND X3095 0
 	FR BND X3096
 	LO BND X3096 0
 	FR BND X3097
 	LO BND X3097 0
 	FR BND X3098
 	LO BND X3098 0
 	FR BND X3099
 	LO BND X3099 0
 	FR BND X3100
 	LO BND X3100 0
 	FR BND X3101
 	LO BND X3101 0
 	FR BND X3102
 	LO BND X3102 0
 	FR BND X3103
 	LO BND X3103 0
 	FR BND X3104
 	LO BND X3104 0
 	FR BND X3105
 	LO BND X3105 0
 	FR BND X3106
 	LO BND X3106 0
 	FR BND X3107
 	LO BND X3107 0
 	FR BND X3108
 	LO BND X3108 0
 	FR BND X3109
 	LO BND X3109 0
 	FR BND X3110
 	LO BND X3110 0
 	FR BND X3111
 	LO BND X3111 0
 	FR BND X3112
 	LO BND X3112 0
 	FR BND X3113
 	LO BND X3113 0
 	FR BND X3114
 	LO BND X3114 0
 	FR BND X3115
 	LO BND X3115 0
 	FR BND X3116
 	LO BND X3116 0
 	FR BND X3117
 	LO BND X3117 0
 	FR BND X3118
 	LO BND X3118 0
 	FR BND X3119
 	LO BND X3119 0
 	FR BND X3120
 	LO BND X3120 0
 	FR BND X3121
 	LO BND X3121 0
 	FR BND X3122
 	LO BND X3122 0
 	FR BND X3123
 	LO BND X3123 0
 	FR BND X3124
 	LO BND X3124 0
 	FR BND X3125
 	LO BND X3125 0
 	FR BND X3126
 	LO BND X3126 0
 	FR BND X3127
 	LO BND X3127 0
 	FR BND X3128
 	LO BND X3128 0
 	FR BND X3129
 	LO BND X3129 0
 	FR BND X3130
 	LO BND X3130 0
 	FR BND X3131
 	LO BND X3131 0
 	FR BND X3132
 	LO BND X3132 0
 	FR BND X3133
 	LO BND X3133 0
 	FR BND X3134
 	LO BND X3134 0
 	FR BND X3135
 	LO BND X3135 0
 	FR BND X3136
 	LO BND X3136 0
 	FR BND X3137
 	LO BND X3137 0
 	FR BND X3138
 	LO BND X3138 0
 	FR BND X3139
 	LO BND X3139 0
 	FR BND X3140
 	LO BND X3140 0
 	FR BND X3141
 	LO BND X3141 0
 	FR BND X3142
 	LO BND X3142 0
 	FR BND X3143
 	LO BND X3143 0
 	FR BND X3144
 	LO BND X3144 0
 	FR BND X3145
 	LO BND X3145 0
 	FR BND X3146
 	LO BND X3146 0
 	FR BND X3147
 	LO BND X3147 0
 	FR BND X3148
 	LO BND X3148 0
 	FR BND X3149
 	LO BND X3149 0
 	FR BND X3150
 	LO BND X3150 0
 	FR BND X3151
 	LO BND X3151 0
 	FR BND X3152
 	LO BND X3152 0
 	FR BND X3153
 	LO BND X3153 0
 	FR BND X3154
 	LO BND X3154 0
 	FR BND X3155
 	LO BND X3155 0
 	FR BND X3156
 	LO BND X3156 0
 	FR BND X3157
 	LO BND X3157 0
 	FR BND X3158
 	LO BND X3158 0
 	FR BND X3159
 	LO BND X3159 0
 	FR BND X3160
 	LO BND X3160 0
 	FR BND X3161
 	LO BND X3161 0
 	FR BND X3162
 	LO BND X3162 0
 	FR BND X3163
 	LO BND X3163 0
 	FR BND X3164
 	LO BND X3164 0
 	FR BND X3165
 	LO BND X3165 0
 	FR BND X3166
 	LO BND X3166 0
 	FR BND X3167
 	LO BND X3167 0
 	FR BND X3168
 	LO BND X3168 0
 	FR BND X3169
 	LO BND X3169 0
 	FR BND X3170
 	LO BND X3170 0
 	FR BND X3171
 	LO BND X3171 0
 	FR BND X3172
 	LO BND X3172 0
 	FR BND X3173
 	LO BND X3173 0
 	FR BND X3174
 	LO BND X3174 0
 	FR BND X3175
 	LO BND X3175 0
 	FR BND X3176
 	LO BND X3176 0
 	FR BND X3177
 	LO BND X3177 0
 	FR BND X3178
 	LO BND X3178 0
 	FR BND X3179
 	LO BND X3179 0
 	FR BND X3180
 	LO BND X3180 0
 	FR BND X3181
 	LO BND X3181 0
 	FR BND X3182
 	LO BND X3182 0
 	FR BND X3183
 	LO BND X3183 0
 	FR BND X3184
 	LO BND X3184 0
 	FR BND X3185
 	LO BND X3185 0
 	FR BND X3186
 	LO BND X3186 0
 	FR BND X3187
 	LO BND X3187 0
 	FR BND X3188
 	LO BND X3188 0
 	FR BND X3189
 	LO BND X3189 0
 	FR BND X3190
 	LO BND X3190 0
 	FR BND X3191
 	LO BND X3191 0
 	FR BND X3192
 	LO BND X3192 0
 	FR BND X3193
 	LO BND X3193 0
 	FR BND X3194
 	LO BND X3194 0
 	FR BND X3195
 	LO BND X3195 0
 	FR BND X3196
 	LO BND X3196 0
 	FR BND X3197
 	LO BND X3197 0
 	FR BND X3198
 	LO BND X3198 0
 	FR BND X3199
 	LO BND X3199 0
 	FR BND X3200
 	LO BND X3200 0
 	FR BND X3201
 	LO BND X3201 0
 	FR BND X3202
 	LO BND X3202 0
 	FR BND X3203
 	LO BND X3203 0
 	FR BND X3204
 	LO BND X3204 0
 	FR BND X3205
 	LO BND X3205 0
 	FR BND X3206
 	LO BND X3206 0
 	FR BND X3207
 	LO BND X3207 0
 	FR BND X3208
 	LO BND X3208 0
 	FR BND X3209
 	LO BND X3209 0
 	FR BND X3210
 	LO BND X3210 0
 	FR BND X3211
 	LO BND X3211 0
 	FR BND X3212
 	LO BND X3212 0
 	FR BND X3213
 	LO BND X3213 0
 	FR BND X3214
 	LO BND X3214 0
 	FR BND X3215
 	LO BND X3215 0
 	FR BND X3216
 	LO BND X3216 0
 	FR BND X3217
 	LO BND X3217 0
 	FR BND X3218
 	LO BND X3218 0
 	FR BND X3219
 	LO BND X3219 0
 	FR BND X3220
 	LO BND X3220 0
 	FR BND X3221
 	LO BND X3221 0
 	FR BND X3222
 	LO BND X3222 0
 	FR BND X3223
 	LO BND X3223 0
 	FR BND X3224
 	LO BND X3224 0
 	FR BND X3225
 	LO BND X3225 0
 	FR BND X3226
 	LO BND X3226 0
 	FR BND X3227
 	LO BND X3227 0
 	FR BND X3228
 	LO BND X3228 0
 	FR BND X3229
 	LO BND X3229 0
 	FR BND X3230
 	LO BND X3230 0
 	FR BND X3231
 	LO BND X3231 0
 	FR BND X3232
 	LO BND X3232 0
 	FR BND X3233
 	LO BND X3233 0
 	FR BND X3234
 	LO BND X3234 0
 	FR BND X3235
 	LO BND X3235 0
 	FR BND X3236
 	LO BND X3236 0
 	FR BND X3237
 	LO BND X3237 0
 	FR BND X3238
 	LO BND X3238 0
 	FR BND X3239
 	LO BND X3239 0
 	FR BND X3240
 	LO BND X3240 0
 	FR BND X3241
 	LO BND X3241 0
 	FR BND X3242
 	LO BND X3242 0
 	FR BND X3243
 	LO BND X3243 0
 	FR BND X3244
 	LO BND X3244 0
 	FR BND X3245
 	LO BND X3245 0
 	FR BND X3246
 	LO BND X3246 0
 	FR BND X3247
 	LO BND X3247 0
 	FR BND X3248
 	LO BND X3248 0
 	FR BND X3249
 	LO BND X3249 0
 	FR BND X3250
 	LO BND X3250 0
 	FR BND X3251
 	LO BND X3251 0
 	FR BND X3252
 	LO BND X3252 0
 	FR BND X3253
 	LO BND X3253 0
 	FR BND X3254
 	LO BND X3254 0
 	FR BND X3255
 	LO BND X3255 0
 	FR BND X3256
 	LO BND X3256 0
 	FR BND X3257
 	LO BND X3257 0
 	FR BND X3258
 	LO BND X3258 0
 	FR BND X3259
 	LO BND X3259 0
 	FR BND X3260
 	LO BND X3260 0
 	FR BND X3261
 	LO BND X3261 0
 	FR BND X3262
 	LO BND X3262 0
 	FR BND X3263
 	LO BND X3263 0
 	FR BND X3264
 	LO BND X3264 0
 	FR BND X3265
 	LO BND X3265 0
 	FR BND X3266
 	LO BND X3266 0
 	FR BND X3267
 	LO BND X3267 0
 	FR BND X3268
 	LO BND X3268 0
 	FR BND X3269
 	LO BND X3269 0
 	FR BND X3270
 	LO BND X3270 0
 	FR BND X3271
 	LO BND X3271 0
 	FR BND X3272
 	LO BND X3272 0
 	FR BND X3273
 	LO BND X3273 0
 	FR BND X3274
 	LO BND X3274 0
 	FR BND X3275
 	LO BND X3275 0
 	FR BND X3276
 	LO BND X3276 0
 	FR BND X3277
 	LO BND X3277 0
 	FR BND X3278
 	LO BND X3278 0
 	FR BND X3279
 	LO BND X3279 0
 	FR BND X3280
 	LO BND X3280 0
 	FR BND X3281
 	LO BND X3281 0
 	FR BND X3282
 	LO BND X3282 0
 	FR BND X3283
 	LO BND X3283 0
 	FR BND X3284
 	LO BND X3284 0
 	FR BND X3285
 	LO BND X3285 0
 	FR BND X3286
 	LO BND X3286 0
 	FR BND X3287
 	LO BND X3287 0
 	FR BND X3288
 	LO BND X3288 0
 	FR BND X3289
 	LO BND X3289 0
 	FR BND X3290
 	LO BND X3290 0
 	FR BND X3291
 	LO BND X3291 0
 	FR BND X3292
 	LO BND X3292 0
 	FR BND X3293
 	LO BND X3293 0
 	FR BND X3294
 	LO BND X3294 0
 	FR BND X3295
 	LO BND X3295 0
 	FR BND X3296
 	LO BND X3296 0
 	FR BND X3297
 	LO BND X3297 0
 	FR BND X3298
 	LO BND X3298 0
 	FR BND X3299
 	LO BND X3299 0
 	FR BND X3300
 	LO BND X3300 0
 	FR BND X3301
 	LO BND X3301 0
 	FR BND X3302
 	LO BND X3302 0
 	FR BND X3303
 	LO BND X3303 0
 	FR BND X3304
 	LO BND X3304 0
 	FR BND X3305
 	LO BND X3305 0
 	FR BND X3306
 	LO BND X3306 0
 	FR BND X3307
 	LO BND X3307 0
 	FR BND X3308
 	LO BND X3308 0
 	FR BND X3309
 	LO BND X3309 0
 	FR BND X3310
 	LO BND X3310 0
 	FR BND X3311
 	LO BND X3311 0
 	FR BND X3312
 	LO BND X3312 0
 	FR BND X3313
 	LO BND X3313 0
 	FR BND X3314
 	LO BND X3314 0
 	FR BND X3315
 	LO BND X3315 0
 	FR BND X3316
 	LO BND X3316 0
 	FR BND X3317
 	LO BND X3317 0
 	FR BND X3318
 	LO BND X3318 0
 	FR BND X3319
 	LO BND X3319 0
 	FR BND X3320
 	LO BND X3320 0
 	FR BND X3321
 	LO BND X3321 0
 	FR BND X3322
 	LO BND X3322 0
 	FR BND X3323
 	LO BND X3323 0
 	FR BND X3324
 	LO BND X3324 0
 	FR BND X3325
 	LO BND X3325 0
 	FR BND X3326
 	LO BND X3326 0
 	FR BND X3327
 	LO BND X3327 0
 	FR BND X3328
 	LO BND X3328 0
 	FR BND X3329
 	LO BND X3329 0
 	FR BND X3330
 	LO BND X3330 0
 	FR BND X3331
 	LO BND X3331 0
 	FR BND X3332
 	LO BND X3332 0
 	FR BND X3333
 	LO BND X3333 0
 	FR BND X3334
 	LO BND X3334 0
 	FR BND X3335
 	LO BND X3335 0
 	FR BND X3336
 	LO BND X3336 0
 	FR BND X3337
 	LO BND X3337 0
 	FR BND X3338
 	LO BND X3338 0
 	FR BND X3339
 	LO BND X3339 0
 	FR BND X3340
 	LO BND X3340 0
 	FR BND X3341
 	LO BND X3341 0
 	FR BND X3342
 	LO BND X3342 0
 	FR BND X3343
 	LO BND X3343 0
 	FR BND X3344
 	LO BND X3344 0
 	FR BND X3345
 	LO BND X3345 0
 	FR BND X3346
 	LO BND X3346 0
 	FR BND X3347
 	LO BND X3347 0
 	FR BND X3348
 	LO BND X3348 0
 	FR BND X3349
 	LO BND X3349 0
 	FR BND X3350
 	LO BND X3350 0
 	FR BND X3351
 	LO BND X3351 0
 	FR BND X3352
 	LO BND X3352 0
 	FR BND X3353
 	LO BND X3353 0
 	FR BND X3354
 	LO BND X3354 0
 	FR BND X3355
 	LO BND X3355 0
 	FR BND X3356
 	LO BND X3356 0
 	FR BND X3357
 	LO BND X3357 0
 	FR BND X3358
 	LO BND X3358 0
 	FR BND X3359
 	LO BND X3359 0
 	FR BND X3360
 	LO BND X3360 0
 	FR BND X3361
 	LO BND X3361 0
 	FR BND X3362
 	LO BND X3362 0
 	FR BND X3363
 	LO BND X3363 0
 	FR BND X3364
 	LO BND X3364 0
 	FR BND X3365
 	LO BND X3365 0
 	FR BND X3366
 	LO BND X3366 0
 	FR BND X3367
 	LO BND X3367 0
 	FR BND X3368
 	LO BND X3368 0
 	FR BND X3369
 	LO BND X3369 0
 	FR BND X3370
 	LO BND X3370 0
 	FR BND X3371
 	LO BND X3371 0
 	FR BND X3372
 	LO BND X3372 0
 	FR BND X3373
 	LO BND X3373 0
 	FR BND X3374
 	LO BND X3374 0
 	FR BND X3375
 	LO BND X3375 0
 	FR BND X3376
 	LO BND X3376 0
 	FR BND X3377
 	LO BND X3377 0
 	FR BND X3378
 	LO BND X3378 0
 	FR BND X3379
 	LO BND X3379 0
 	FR BND X3380
 	LO BND X3380 0
 	FR BND X3381
 	LO BND X3381 0
 	FR BND X3382
 	LO BND X3382 0
 	FR BND X3383
 	LO BND X3383 0
 	FR BND X3384
 	LO BND X3384 0
 	FR BND X3385
 	LO BND X3385 0
 	FR BND X3386
 	LO BND X3386 0
 	FR BND X3387
 	LO BND X3387 0
 	FR BND X3388
 	LO BND X3388 0
 	FR BND X3389
 	LO BND X3389 0
 	FR BND X3390
 	LO BND X3390 0
 	FR BND X3391
 	LO BND X3391 0
 	FR BND X3392
 	LO BND X3392 0
 	FR BND X3393
 	LO BND X3393 0
 	FR BND X3394
 	LO BND X3394 0
 	FR BND X3395
 	LO BND X3395 0
 	FR BND X3396
 	LO BND X3396 0
 	FR BND X3397
 	LO BND X3397 0
 	FR BND X3398
 	LO BND X3398 0
 	FR BND X3399
 	LO BND X3399 0
 	FR BND X3400
 	LO BND X3400 0
 	FR BND X3401
 	LO BND X3401 0
 	FR BND X3402
 	LO BND X3402 0
 	FR BND X3403
 	LO BND X3403 0
 	FR BND X3404
 	LO BND X3404 0
 	FR BND X3405
 	LO BND X3405 0
 	FR BND X3406
 	LO BND X3406 0
 	FR BND X3407
 	LO BND X3407 0
 	FR BND X3408
 	LO BND X3408 0
 	FR BND X3409
 	LO BND X3409 0
 	FR BND X3410
 	LO BND X3410 0
 	FR BND X3411
 	LO BND X3411 0
 	FR BND X3412
 	LO BND X3412 0
 	FR BND X3413
 	LO BND X3413 0
 	FR BND X3414
 	LO BND X3414 0
 	FR BND X3415
 	LO BND X3415 0
 	FR BND X3416
 	LO BND X3416 0
 	FR BND X3417
 	LO BND X3417 0
 	FR BND X3418
 	LO BND X3418 0
 	FR BND X3419
 	LO BND X3419 0
 	FR BND X3420
 	LO BND X3420 0
 	FR BND X3421
 	LO BND X3421 0
 	FR BND X3422
 	LO BND X3422 0
 	FR BND X3423
 	LO BND X3423 0
 	FR BND X3424
 	LO BND X3424 0
 	FR BND X3425
 	LO BND X3425 0
 	FR BND X3426
 	LO BND X3426 0
 	FR BND X3427
 	LO BND X3427 0
 	FR BND X3428
 	LO BND X3428 0
 	FR BND X3429
 	LO BND X3429 0
 	FR BND X3430
 	LO BND X3430 0
 	FR BND X3431
 	LO BND X3431 0
 	FR BND X3432
 	LO BND X3432 0
 	FR BND X3433
 	LO BND X3433 0
 	FR BND X3434
 	LO BND X3434 0
 	FR BND X3435
 	LO BND X3435 0
 	FR BND X3436
 	LO BND X3436 0
 	FR BND X3437
 	LO BND X3437 0
 	FR BND X3438
 	LO BND X3438 0
 	FR BND X3439
 	LO BND X3439 0
 	FR BND X3440
 	LO BND X3440 0
 	FR BND X3441
 	LO BND X3441 0
 	FR BND X3442
 	LO BND X3442 0
 	FR BND X3443
 	LO BND X3443 0
 	FR BND X3444
 	LO BND X3444 0
 	FR BND X3445
 	LO BND X3445 0
 	FR BND X3446
 	LO BND X3446 0
 	FR BND X3447
 	LO BND X3447 0
 	FR BND X3448
 	LO BND X3448 0
 	FR BND X3449
 	LO BND X3449 0
 	FR BND X3450
 	LO BND X3450 0
 	FR BND X3451
 	LO BND X3451 0
 	FR BND X3452
 	LO BND X3452 0
 	FR BND X3453
 	LO BND X3453 0
 	FR BND X3454
 	LO BND X3454 0
 	FR BND X3455
 	LO BND X3455 0
 	FR BND X3456
 	LO BND X3456 0
 	FR BND X3457
 	LO BND X3457 0
 	FR BND X3458
 	LO BND X3458 0
 	FR BND X3459
 	LO BND X3459 0
 	FR BND X3460
 	LO BND X3460 0
 	FR BND X3461
 	LO BND X3461 0
 	FR BND X3462
 	LO BND X3462 0
 	FR BND X3463
 	LO BND X3463 0
 	FR BND X3464
 	LO BND X3464 0
 	FR BND X3465
 	LO BND X3465 0
 	FR BND X3466
 	LO BND X3466 0
 	FR BND X3467
 	LO BND X3467 0
 	FR BND X3468
 	LO BND X3468 0
 	FR BND X3469
 	LO BND X3469 0
 	FR BND X3470
 	LO BND X3470 0
 	FR BND X3471
 	LO BND X3471 0
 	FR BND X3472
 	LO BND X3472 0
 	FR BND X3473
 	LO BND X3473 0
 	FR BND X3474
 	LO BND X3474 0
 	FR BND X3475
 	LO BND X3475 0
 	FR BND X3476
 	LO BND X3476 0
 	FR BND X3477
 	LO BND X3477 0
 	FR BND X3478
 	LO BND X3478 0
 	FR BND X3479
 	LO BND X3479 0
 	FR BND X3480
 	LO BND X3480 0
 	FR BND X3481
 	LO BND X3481 0
 	FR BND X3482
 	LO BND X3482 0
 	FR BND X3483
 	LO BND X3483 0
 	FR BND X3484
 	LO BND X3484 0
 	FR BND X3485
 	LO BND X3485 0
 	FR BND X3486
 	LO BND X3486 0
 	FR BND X3487
 	LO BND X3487 0
 	FR BND X3488
 	LO BND X3488 0
 	FR BND X3489
 	LO BND X3489 0
 	FR BND X3490
 	LO BND X3490 0
 	FR BND X3491
 	LO BND X3491 0
 	FR BND X3492
 	LO BND X3492 0
 	FR BND X3493
 	LO BND X3493 0
 	FR BND X3494
 	LO BND X3494 0
 	FR BND X3495
 	LO BND X3495 0
 	FR BND X3496
 	LO BND X3496 0
 	FR BND X3497
 	LO BND X3497 0
 	FR BND X3498
 	LO BND X3498 0
 	FR BND X3499
 	LO BND X3499 0
 	FR BND X3500
 	LO BND X3500 0
 	FR BND X3501
 	LO BND X3501 0
 	FR BND X3502
 	LO BND X3502 0
 	FR BND X3503
 	LO BND X3503 0
 	FR BND X3504
 	LO BND X3504 0
 	FR BND X3505
 	LO BND X3505 0
 	FR BND X3506
 	LO BND X3506 0
 	FR BND X3507
 	LO BND X3507 0
 	FR BND X3508
 	LO BND X3508 0
 	FR BND X3509
 	LO BND X3509 0
 	FR BND X3510
 	LO BND X3510 0
 	FR BND X3511
 	LO BND X3511 0
 	FR BND X3512
 	LO BND X3512 0
 	FR BND X3513
 	LO BND X3513 0
 	FR BND X3514
 	LO BND X3514 0
 	FR BND X3515
 	LO BND X3515 0
 	FR BND X3516
 	LO BND X3516 0
 	FR BND X3517
 	LO BND X3517 0
 	FR BND X3518
 	LO BND X3518 0
 	FR BND X3519
 	LO BND X3519 0
 	FR BND X3520
 	LO BND X3520 0
 	FR BND X3521
 	LO BND X3521 0
 	FR BND X3522
 	LO BND X3522 0
 	FR BND X3523
 	LO BND X3523 0
 	FR BND X3524
 	LO BND X3524 0
 	FR BND X3525
 	LO BND X3525 0
 	FR BND X3526
 	LO BND X3526 0
 	FR BND X3527
 	LO BND X3527 0
 	FR BND X3528
 	LO BND X3528 0
 	FR BND X3529
 	LO BND X3529 0
 	FR BND X3530
 	LO BND X3530 0
 	FR BND X3531
 	LO BND X3531 0
 	FR BND X3532
 	LO BND X3532 0
 	FR BND X3533
 	LO BND X3533 0
 	FR BND X3534
 	LO BND X3534 0
 	FR BND X3535
 	LO BND X3535 0
 	FR BND X3536
 	LO BND X3536 0
 	FR BND X3537
 	LO BND X3537 0
 	FR BND X3538
 	LO BND X3538 0
 	FR BND X3539
 	LO BND X3539 0
 	FR BND X3540
 	LO BND X3540 0
 	FR BND X3541
 	LO BND X3541 0
 	FR BND X3542
 	LO BND X3542 0
 	FR BND X3543
 	LO BND X3543 0
 	FR BND X3544
 	LO BND X3544 0
 	FR BND X3545
 	LO BND X3545 0
 	FR BND X3546
 	LO BND X3546 0
 	FR BND X3547
 	LO BND X3547 0
 	FR BND X3548
 	LO BND X3548 0
 	FR BND X3549
 	LO BND X3549 0
 	FR BND X3550
 	LO BND X3550 0
 	FR BND X3551
 	LO BND X3551 0
 	FR BND X3552
 	LO BND X3552 0
 	FR BND X3553
 	LO BND X3553 0
 	FR BND X3554
 	LO BND X3554 0
 	FR BND X3555
 	LO BND X3555 0
 	FR BND X3556
 	LO BND X3556 0
 	FR BND X3557
 	LO BND X3557 0
 	FR BND X3558
 	LO BND X3558 0
 	FR BND X3559
 	LO BND X3559 0
 	FR BND X3560
 	LO BND X3560 0
 	FR BND X3561
 	LO BND X3561 0
 	FR BND X3562
 	LO BND X3562 0
 	FR BND X3563
 	LO BND X3563 0
 	FR BND X3564
 	LO BND X3564 0
 	FR BND X3565
 	LO BND X3565 0
 	FR BND X3566
 	LO BND X3566 0
 	FR BND X3567
 	LO BND X3567 0
 	FR BND X3568
 	LO BND X3568 0
 	FR BND X3569
 	LO BND X3569 0
 	FR BND X3570
 	LO BND X3570 0
 	FR BND X3571
 	LO BND X3571 0
 	FR BND X3572
 	LO BND X3572 0
 	FR BND X3573
 	LO BND X3573 0
 	FR BND X3574
 	LO BND X3574 0
 	FR BND X3575
 	LO BND X3575 0
 	FR BND X3576
 	LO BND X3576 0
 	FR BND X3577
 	LO BND X3577 0
 	FR BND X3578
 	LO BND X3578 0
 	FR BND X3579
 	LO BND X3579 0
 	FR BND X3580
 	LO BND X3580 0
 	FR BND X3581
 	LO BND X3581 0
 	FR BND X3582
 	LO BND X3582 0
 	FR BND X3583
 	LO BND X3583 0
 	FR BND X3584
 	LO BND X3584 0
 	FR BND X3585
 	LO BND X3585 0
 	FR BND X3586
 	LO BND X3586 0
 	FR BND X3587
 	LO BND X3587 0
 	FR BND X3588
 	LO BND X3588 0
 	FR BND X3589
 	LO BND X3589 0
 	FR BND X3590
 	LO BND X3590 0
 	FR BND X3591
 	LO BND X3591 0
 	FR BND X3592
 	LO BND X3592 0
 	FR BND X3593
 	LO BND X3593 0
 	FR BND X3594
 	LO BND X3594 0
 	FR BND X3595
 	LO BND X3595 0
 	FR BND X3596
 	LO BND X3596 0
 	FR BND X3597
 	LO BND X3597 0
 	FR BND X3598
 	LO BND X3598 0
 	FR BND X3599
 	LO BND X3599 0
 	FR BND X3600
 	LO BND X3600 0
 	FR BND X3601
 	LO BND X3601 0
 	FR BND X3602
 	LO BND X3602 0
 	FR BND X3603
 	LO BND X3603 0
 	FR BND X3604
 	LO BND X3604 0
 	FR BND X3605
 	LO BND X3605 0
 	FR BND X3606
 	LO BND X3606 0
 	FR BND X3607
 	LO BND X3607 0
 	FR BND X3608
 	LO BND X3608 0
 	FR BND X3609
 	LO BND X3609 0
 	FR BND X3610
 	LO BND X3610 0
 	FR BND X3611
 	LO BND X3611 0
 	FR BND X3612
 	LO BND X3612 0
 	FR BND X3613
 	LO BND X3613 0
 	FR BND X3614
 	LO BND X3614 0
 	FR BND X3615
 	LO BND X3615 0
 	FR BND X3616
 	LO BND X3616 0
 	FR BND X3617
 	LO BND X3617 0
 	FR BND X3618
 	LO BND X3618 0
 	FR BND X3619
 	LO BND X3619 0
 	FR BND X3620
 	LO BND X3620 0
 	FR BND X3621
 	LO BND X3621 0
 	FR BND X3622
 	LO BND X3622 0
 	FR BND X3623
 	LO BND X3623 0
 	FR BND X3624
 	LO BND X3624 0
 	FR BND X3625
 	LO BND X3625 0
 	FR BND X3626
 	LO BND X3626 0
 	FR BND X3627
 	LO BND X3627 0
 	FR BND X3628
 	LO BND X3628 0
 	FR BND X3629
 	LO BND X3629 0
 	FR BND X3630
 	LO BND X3630 0
 	FR BND X3631
 	LO BND X3631 0
 	FR BND X3632
 	LO BND X3632 0
 	FR BND X3633
 	LO BND X3633 0
 	FR BND X3634
 	LO BND X3634 0
 	FR BND X3635
 	LO BND X3635 0
 	FR BND X3636
 	LO BND X3636 0
 	FR BND X3637
 	LO BND X3637 0
 	FR BND X3638
 	LO BND X3638 0
 	FR BND X3639
 	LO BND X3639 0
 	FR BND X3640
 	LO BND X3640 0
 	FR BND X3641
 	LO BND X3641 0
 	FR BND X3642
 	LO BND X3642 0
 	FR BND X3643
 	LO BND X3643 0
 	FR BND X3644
 	LO BND X3644 0
 	FR BND X3645
 	LO BND X3645 0
 	FR BND X3646
 	LO BND X3646 0
 	FR BND X3647
 	LO BND X3647 0
 	FR BND X3648
 	LO BND X3648 0
 	FR BND X3649
 	LO BND X3649 0
 	FR BND X3650
 	LO BND X3650 0
 	FR BND X3651
 	LO BND X3651 0
 	FR BND X3652
 	LO BND X3652 0
 	FR BND X3653
 	LO BND X3653 0
 	FR BND X3654
 	LO BND X3654 0
 	FR BND X3655
 	LO BND X3655 0
 	FR BND X3656
 	LO BND X3656 0
 	FR BND X3657
 	LO BND X3657 0
 	FR BND X3658
 	LO BND X3658 0
 	FR BND X3659
 	LO BND X3659 0
 	FR BND X3660
 	LO BND X3660 0
 	FR BND X3661
 	LO BND X3661 0
 	FR BND X3662
 	LO BND X3662 0
 	FR BND X3663
 	LO BND X3663 0
 	FR BND X3664
 	LO BND X3664 0
 	FR BND X3665
 	LO BND X3665 0
 	FR BND X3666
 	LO BND X3666 0
 	FR BND X3667
 	LO BND X3667 0
 	FR BND X3668
 	LO BND X3668 0
 	FR BND X3669
 	LO BND X3669 0
 	FR BND X3670
 	LO BND X3670 0
 	FR BND X3671
 	LO BND X3671 0
 	FR BND X3672
 	LO BND X3672 0
 	FR BND X3673
 	LO BND X3673 0
 	FR BND X3674
 	LO BND X3674 0
 	FR BND X3675
 	LO BND X3675 0
 	FR BND X3676
 	LO BND X3676 0
 	FR BND X3677
 	LO BND X3677 0
 	FR BND X3678
 	LO BND X3678 0
 	FR BND X3679
 	LO BND X3679 0
 	FR BND X3680
 	LO BND X3680 0
 	FR BND X3681
 	LO BND X3681 0
 	FR BND X3682
 	LO BND X3682 0
 	FR BND X3683
 	LO BND X3683 0
 	FR BND X3684
 	LO BND X3684 0
 	FR BND X3685
 	LO BND X3685 0
 	FR BND X3686
 	LO BND X3686 0
 	FR BND X3687
 	LO BND X3687 0
 	FR BND X3688
 	LO BND X3688 0
 	FR BND X3689
 	LO BND X3689 0
 	FR BND X3690
 	LO BND X3690 0
 	FR BND X3691
 	LO BND X3691 0
 	FR BND X3692
 	LO BND X3692 0
 	FR BND X3693
 	LO BND X3693 0
 	FR BND X3694
 	LO BND X3694 0
 	FR BND X3695
 	LO BND X3695 0
 	FR BND X3696
 	LO BND X3696 0
 	FR BND X3697
 	LO BND X3697 0
 	FR BND X3698
 	LO BND X3698 0
 	FR BND X3699
 	LO BND X3699 0
 	FR BND X3700
 	LO BND X3700 0
 	FR BND X3701
 	LO BND X3701 0
 	FR BND X3702
 	LO BND X3702 0
 	FR BND X3703
 	LO BND X3703 0
 	FR BND X3704
 	LO BND X3704 0
 	FR BND X3705
 	LO BND X3705 0
 	FR BND X3706
 	LO BND X3706 0
 	FR BND X3707
 	LO BND X3707 0
 	FR BND X3708
 	LO BND X3708 0
 	FR BND X3709
 	LO BND X3709 0
 	FR BND X3710
 	LO BND X3710 0
 	FR BND X3711
 	LO BND X3711 0
 	FR BND X3712
 	LO BND X3712 0
 	FR BND X3713
 	LO BND X3713 0
 	FR BND X3714
 	LO BND X3714 0
 	FR BND X3715
 	LO BND X3715 0
 	FR BND X3716
 	LO BND X3716 0
 	FR BND X3717
 	LO BND X3717 0
 	FR BND X3718
 	LO BND X3718 0
 	FR BND X3719
 	LO BND X3719 0
 	FR BND X3720
 	LO BND X3720 0
 	FR BND X3721
 	LO BND X3721 0
 	FR BND X3722
 	LO BND X3722 0
 	FR BND X3723
 	LO BND X3723 0
 	FR BND X3724
 	LO BND X3724 0
 	FR BND X3725
 	LO BND X3725 0
 	FR BND X3726
 	LO BND X3726 0
 	FR BND X3727
 	LO BND X3727 0
 	FR BND X3728
 	LO BND X3728 0
 	FR BND X3729
 	LO BND X3729 0
 	FR BND X3730
 	LO BND X3730 0
 	FR BND X3731
 	LO BND X3731 0
 	FR BND X3732
 	LO BND X3732 0
 	FR BND X3733
 	LO BND X3733 0
 	FR BND X3734
 	LO BND X3734 0
 	FR BND X3735
 	LO BND X3735 0
 	FR BND X3736
 	LO BND X3736 0
 	FR BND X3737
 	LO BND X3737 0
 	FR BND X3738
 	LO BND X3738 0
 	FR BND X3739
 	LO BND X3739 0
 	FR BND X3740
 	LO BND X3740 0
 	FR BND X3741
 	LO BND X3741 0
 	FR BND X3742
 	LO BND X3742 0
 	FR BND X3743
 	LO BND X3743 0
 	FR BND X3744
 	LO BND X3744 0
 	FR BND X3745
 	LO BND X3745 0
 	FR BND X3746
 	LO BND X3746 0
 	FR BND X3747
 	LO BND X3747 0
 	FR BND X3748
 	LO BND X3748 0
 	FR BND X3749
 	LO BND X3749 0
 	FR BND X3750
 	LO BND X3750 0
 	FR BND X3751
 	LO BND X3751 0
 	FR BND X3752
 	LO BND X3752 0
 	FR BND X3753
 	LO BND X3753 0
 	FR BND X3754
 	LO BND X3754 0
 	FR BND X3755
 	LO BND X3755 0
 	FR BND X3756
 	LO BND X3756 0
 	FR BND X3757
 	LO BND X3757 0
 	FR BND X3758
 	LO BND X3758 0
 	FR BND X3759
 	LO BND X3759 0
 	FR BND X3760
 	LO BND X3760 0
 	FR BND X3761
 	LO BND X3761 0
 	FR BND X3762
 	LO BND X3762 0
 	FR BND X3763
 	LO BND X3763 0
 	FR BND X3764
 	LO BND X3764 0
 	FR BND X3765
 	LO BND X3765 0
 	FR BND X3766
 	LO BND X3766 0
 	FR BND X3767
 	LO BND X3767 0
 	FR BND X3768
 	LO BND X3768 0
 	FR BND X3769
 	LO BND X3769 0
 	FR BND X3770
 	LO BND X3770 0
 	FR BND X3771
 	LO BND X3771 0
 	FR BND X3772
 	LO BND X3772 0
 	FR BND X3773
 	LO BND X3773 0
 	FR BND X3774
 	LO BND X3774 0
 	FR BND X3775
 	LO BND X3775 0
 	FR BND X3776
 	LO BND X3776 0
 	FR BND X3777
 	LO BND X3777 0
 	FR BND X3778
 	LO BND X3778 0
 	FR BND X3779
 	LO BND X3779 0
 	FR BND X3780
 	LO BND X3780 0
 	FR BND X3781
 	LO BND X3781 0
 	FR BND X3782
 	LO BND X3782 0
 	FR BND X3783
 	LO BND X3783 0
 	FR BND X3784
 	LO BND X3784 0
 	FR BND X3785
 	LO BND X3785 0
 	FR BND X3786
 	LO BND X3786 0
 	FR BND X3787
 	LO BND X3787 0
 	FR BND X3788
 	LO BND X3788 0
 	FR BND X3789
 	LO BND X3789 0
 	FR BND X3790
 	LO BND X3790 0
 	FR BND X3791
 	LO BND X3791 0
 	FR BND X3792
 	LO BND X3792 0
 	FR BND X3793
 	LO BND X3793 0
 	FR BND X3794
 	LO BND X3794 0
 	FR BND X3795
 	LO BND X3795 0
 	FR BND X3796
 	LO BND X3796 0
 	FR BND X3797
 	LO BND X3797 0
 	FR BND X3798
 	LO BND X3798 0
 	FR BND X3799
 	LO BND X3799 0
 	FR BND X3800
 	LO BND X3800 0
 	FR BND X3801
 	LO BND X3801 0
 	FR BND X3802
 	LO BND X3802 0
 	FR BND X3803
 	LO BND X3803 0
 	FR BND X3804
 	LO BND X3804 0
 	FR BND X3805
 	LO BND X3805 0
 	FR BND X3806
 	LO BND X3806 0
 	FR BND X3807
 	LO BND X3807 0
 	FR BND X3808
 	LO BND X3808 0
 	FR BND X3809
 	LO BND X3809 0
 	FR BND X3810
 	LO BND X3810 0
 	FR BND X3811
 	LO BND X3811 0
 	FR BND X3812
 	LO BND X3812 0
 	FR BND X3813
 	LO BND X3813 0
 	FR BND X3814
 	LO BND X3814 0
 	FR BND X3815
 	LO BND X3815 0
 	FR BND X3816
 	LO BND X3816 0
 	FR BND X3817
 	LO BND X3817 0
 	FR BND X3818
 	LO BND X3818 0
 	FR BND X3819
 	LO BND X3819 0
 	FR BND X3820
 	LO BND X3820 0
 	FR BND X3821
 	LO BND X3821 0
 	FR BND X3822
 	LO BND X3822 0
 	FR BND X3823
 	LO BND X3823 0
 	FR BND X3824
 	LO BND X3824 0
 	FR BND X3825
 	LO BND X3825 0
 	FR BND X3826
 	LO BND X3826 0
 	FR BND X3827
 	LO BND X3827 0
 	FR BND X3828
 	LO BND X3828 0
 	FR BND X3829
 	LO BND X3829 0
 	FR BND X3830
 	LO BND X3830 0
 	FR BND X3831
 	LO BND X3831 0
 	FR BND X3832
 	LO BND X3832 0
 	FR BND X3833
 	LO BND X3833 0
 	FR BND X3834
 	LO BND X3834 0
 	FR BND X3835
 	LO BND X3835 0
 	FR BND X3836
 	LO BND X3836 0
 	FR BND X3837
 	LO BND X3837 0
 	FR BND X3838
 	LO BND X3838 0
 	FR BND X3839
 	LO BND X3839 0
 	FR BND X3840
 	LO BND X3840 0
 	FR BND X3841
 	LO BND X3841 0
 	FR BND X3842
 	LO BND X3842 0
 	FR BND X3843
 	LO BND X3843 0
 	FR BND X3844
 	LO BND X3844 0
 	FR BND X3845
 	LO BND X3845 0
 	FR BND X3846
 	LO BND X3846 0
 	FR BND X3847
 	LO BND X3847 0
 	FR BND X3848
 	LO BND X3848 0
 	FR BND X3849
 	LO BND X3849 0
 	FR BND X3850
 	LO BND X3850 0
 	FR BND X3851
 	LO BND X3851 0
 	FR BND X3852
 	LO BND X3852 0
 	FR BND X3853
 	LO BND X3853 0
 	FR BND X3854
 	LO BND X3854 0
 	FR BND X3855
 	LO BND X3855 0
 	FR BND X3856
 	LO BND X3856 0
 	FR BND X3857
 	LO BND X3857 0
 	FR BND X3858
 	LO BND X3858 0
 	FR BND X3859
 	LO BND X3859 0
 	FR BND X3860
 	LO BND X3860 0
 	FR BND X3861
 	LO BND X3861 0
 	FR BND X3862
 	LO BND X3862 0
 	FR BND X3863
 	LO BND X3863 0
 	FR BND X3864
 	LO BND X3864 0
 	FR BND X3865
 	LO BND X3865 0
 	FR BND X3866
 	LO BND X3866 0
 	FR BND X3867
 	LO BND X3867 0
 	FR BND X3868
 	LO BND X3868 0
 	FR BND X3869
 	LO BND X3869 0
 	FR BND X3870
 	LO BND X3870 0
 	FR BND X3871
 	LO BND X3871 0
 	FR BND X3872
 	LO BND X3872 0
 	FR BND X3873
 	LO BND X3873 0
 	FR BND X3874
 	LO BND X3874 0
 	FR BND X3875
 	LO BND X3875 0
 	FR BND X3876
 	LO BND X3876 0
 	FR BND X3877
 	LO BND X3877 0
 	FR BND X3878
 	LO BND X3878 0
 	FR BND X3879
 	LO BND X3879 0
 	FR BND X3880
 	LO BND X3880 0
 	FR BND X3881
 	LO BND X3881 0
 	FR BND X3882
 	LO BND X3882 0
 	FR BND X3883
 	LO BND X3883 0
 	FR BND X3884
 	LO BND X3884 0
 	FR BND X3885
 	LO BND X3885 0
 	FR BND X3886
 	LO BND X3886 0
 	FR BND X3887
 	LO BND X3887 0
 	FR BND X3888
 	LO BND X3888 0
 	FR BND X3889
 	LO BND X3889 0
 	FR BND X3890
 	LO BND X3890 0
 	FR BND X3891
 	LO BND X3891 0
 	FR BND X3892
 	LO BND X3892 0
 	FR BND X3893
 	LO BND X3893 0
 	FR BND X3894
 	LO BND X3894 0
 	FR BND X3895
 	LO BND X3895 0
 	FR BND X3896
 	LO BND X3896 0
 	FR BND X3897
 	LO BND X3897 0
 	FR BND X3898
 	LO BND X3898 0
 	FR BND X3899
 	LO BND X3899 0
 	FR BND X3900
 	LO BND X3900 0
 	FR BND X3901
 	LO BND X3901 0
 	FR BND X3902
 	LO BND X3902 0
 	FR BND X3903
 	LO BND X3903 0
 	FR BND X3904
 	LO BND X3904 0
 	FR BND X3905
 	LO BND X3905 0
 	FR BND X3906
 	LO BND X3906 0
 	FR BND X3907
 	LO BND X3907 0
 	FR BND X3908
 	LO BND X3908 0
 	FR BND X3909
 	LO BND X3909 0
 	FR BND X3910
 	LO BND X3910 0
 	FR BND X3911
 	LO BND X3911 0
 	FR BND X3912
 	LO BND X3912 0
 	FR BND X3913
 	LO BND X3913 0
 	FR BND X3914
 	LO BND X3914 0
 	FR BND X3915
 	LO BND X3915 0
 	FR BND X3916
 	LO BND X3916 0
 	FR BND X3917
 	LO BND X3917 0
 	FR BND X3918
 	LO BND X3918 0
 	FR BND X3919
 	LO BND X3919 0
 	FR BND X3920
 	LO BND X3920 0
 	FR BND X3921
 	LO BND X3921 0
 	FR BND X3922
 	LO BND X3922 0
 	FR BND X3923
 	LO BND X3923 0
 	FR BND X3924
 	LO BND X3924 0
 	FR BND X3925
 	LO BND X3925 0
 	FR BND X3926
 	LO BND X3926 0
 	FR BND X3927
 	LO BND X3927 0
 	FR BND X3928
 	LO BND X3928 0
 	FR BND X3929
 	LO BND X3929 0
 	FR BND X3930
 	LO BND X3930 0
 	FR BND X3931
 	LO BND X3931 0
 	FR BND X3932
 	LO BND X3932 0
 	FR BND X3933
 	LO BND X3933 0
 	FR BND X3934
 	LO BND X3934 0
 	FR BND X3935
 	LO BND X3935 0
 	FR BND X3936
 	LO BND X3936 0
 	FR BND X3937
 	LO BND X3937 0
 	FR BND X3938
 	LO BND X3938 0
 	FR BND X3939
 	LO BND X3939 0
 	FR BND X3940
 	LO BND X3940 0
 	FR BND X3941
 	LO BND X3941 0
 	FR BND X3942
 	LO BND X3942 0
 	FR BND X3943
 	LO BND X3943 0
 	FR BND X3944
 	LO BND X3944 0
 	FR BND X3945
 	LO BND X3945 0
 	FR BND X3946
 	LO BND X3946 0
 	FR BND X3947
 	LO BND X3947 0
 	FR BND X3948
 	LO BND X3948 0
 	FR BND X3949
 	LO BND X3949 0
 	FR BND X3950
 	LO BND X3950 0
 	FR BND X3951
 	LO BND X3951 0
 	FR BND X3952
 	LO BND X3952 0
 	FR BND X3953
 	LO BND X3953 0
 	FR BND X3954
 	LO BND X3954 0
 	FR BND X3955
 	LO BND X3955 0
 	FR BND X3956
 	LO BND X3956 0
 	FR BND X3957
 	LO BND X3957 0
 	FR BND X3958
 	LO BND X3958 0
 	FR BND X3959
 	LO BND X3959 0
 	FR BND X3960
 	LO BND X3960 0
 	FR BND X3961
 	LO BND X3961 0
 	FR BND X3962
 	LO BND X3962 0
 	FR BND X3963
 	LO BND X3963 0
 	FR BND X3964
 	LO BND X3964 0
 	FR BND X3965
 	LO BND X3965 0
 	FR BND X3966
 	LO BND X3966 0
 	FR BND X3967
 	LO BND X3967 0
 	FR BND X3968
 	LO BND X3968 0
 	FR BND X3969
 	LO BND X3969 0
 	FR BND X3970
 	LO BND X3970 0
 	FR BND X3971
 	LO BND X3971 0
 	FR BND X3972
 	LO BND X3972 0
 	FR BND X3973
 	LO BND X3973 0
 	FR BND X3974
 	LO BND X3974 0
 	FR BND X3975
 	LO BND X3975 0
 	FR BND X3976
 	LO BND X3976 0
 	FR BND X3977
 	LO BND X3977 0
 	FR BND X3978
 	LO BND X3978 0
 	FR BND X3979
 	LO BND X3979 0
 	FR BND X3980
 	LO BND X3980 0
 	FR BND X3981
 	LO BND X3981 0
 	FR BND X3982
 	LO BND X3982 0
 	FR BND X3983
 	LO BND X3983 0
 	FR BND X3984
 	LO BND X3984 0
 	FR BND X3985
 	LO BND X3985 0
 	FR BND X3986
 	LO BND X3986 0
 	FR BND X3987
 	LO BND X3987 0
 	FR BND X3988
 	LO BND X3988 0
 	FR BND X3989
 	LO BND X3989 0
 	FR BND X3990
 	LO BND X3990 0
 	FR BND X3991
 	LO BND X3991 0
 	FR BND X3992
 	LO BND X3992 0
 	FR BND X3993
 	LO BND X3993 0
 	FR BND X3994
 	LO BND X3994 0
 	FR BND X3995
 	LO BND X3995 0
 	FR BND X3996
 	LO BND X3996 0
 	FR BND X3997
 	LO BND X3997 0
 	FR BND X3998
 	LO BND X3998 0
 	FR BND X3999
 	LO BND X3999 0
 	FR BND X4000
 	LO BND X4000 0
 	FR BND X4001
 	LO BND X4001 0
 	FR BND X4002
 	LO BND X4002 0
 	FR BND X4003
 	LO BND X4003 0
 	FR BND X4004
 	LO BND X4004 0
 	FR BND X4005
 	LO BND X4005 0
 	FR BND X4006
 	LO BND X4006 0
 	FR BND X4007
 	LO BND X4007 0
 	FR BND X4008
 	LO BND X4008 0
 	FR BND X4009
 	LO BND X4009 0
 	FR BND X4010
 	LO BND X4010 0
 	FR BND X4011
 	LO BND X4011 0
 	FR BND X4012
 	LO BND X4012 0
 	FR BND X4013
 	LO BND X4013 0
 	FR BND X4014
 	LO BND X4014 0
 	FR BND X4015
 	LO BND X4015 0
 	FR BND X4016
 	LO BND X4016 0
 	FR BND X4017
 	LO BND X4017 0
 	FR BND X4018
 	LO BND X4018 0
 	FR BND X4019
 	LO BND X4019 0
 	FR BND X4020
 	LO BND X4020 0
 	FR BND X4021
 	LO BND X4021 0
 	FR BND X4022
 	LO BND X4022 0
 	FR BND X4023
 	LO BND X4023 0
 	FR BND X4024
 	LO BND X4024 0
 	FR BND X4025
 	LO BND X4025 0
 	FR BND X4026
 	LO BND X4026 0
 	FR BND X4027
 	LO BND X4027 0
 	FR BND X4028
 	LO BND X4028 0
 	FR BND X4029
 	LO BND X4029 0
 	FR BND X4030
 	LO BND X4030 0
 	FR BND X4031
 	LO BND X4031 0
 	FR BND X4032
 	LO BND X4032 0
 	FR BND X4033
 	LO BND X4033 0
 	FR BND X4034
 	LO BND X4034 0
 	FR BND X4035
 	LO BND X4035 0
 	FR BND X4036
 	LO BND X4036 0
 	FR BND X4037
 	LO BND X4037 0
 	FR BND X4038
 	LO BND X4038 0
 	FR BND X4039
 	LO BND X4039 0
 	FR BND X4040
 	LO BND X4040 0
 	FR BND X4041
 	LO BND X4041 0
 	FR BND X4042
 	LO BND X4042 0
 	FR BND X4043
 	LO BND X4043 0
 	FR BND X4044
 	LO BND X4044 0
 	FR BND X4045
 	LO BND X4045 0
 	FR BND X4046
 	LO BND X4046 0
 	FR BND X4047
 	LO BND X4047 0
 	FR BND X4048
 	LO BND X4048 0
 	FR BND X4049
 	LO BND X4049 0
 	FR BND X4050
 	LO BND X4050 0
 	FR BND X4051
 	LO BND X4051 0
 	FR BND X4052
 	LO BND X4052 0
 	FR BND X4053
 	LO BND X4053 0
 	FR BND X4054
 	LO BND X4054 0
 	FR BND X4055
 	LO BND X4055 0
 	FR BND X4056
 	LO BND X4056 0
 	FR BND X4057
 	LO BND X4057 0
 	FR BND X4058
 	LO BND X4058 0
 	FR BND X4059
 	LO BND X4059 0
 	FR BND X4060
 	LO BND X4060 0
 	FR BND X4061
 	LO BND X4061 0
 	FR BND X4062
 	LO BND X4062 0
 	FR BND X4063
 	LO BND X4063 0
 	FR BND X4064
 	LO BND X4064 0
 	FR BND X4065
 	LO BND X4065 0
 	FR BND X4066
 	LO BND X4066 0
 	FR BND X4067
 	LO BND X4067 0
 	FR BND X4068
 	LO BND X4068 0
 	FR BND X4069
 	LO BND X4069 0
 	FR BND X4070
 	LO BND X4070 0
 	FR BND X4071
 	LO BND X4071 0
 	FR BND X4072
 	LO BND X4072 0
 	FR BND X4073
 	LO BND X4073 0
 	FR BND X4074
 	LO BND X4074 0
 	FR BND X4075
 	LO BND X4075 0
 	FR BND X4076
 	LO BND X4076 0
 	FR BND X4077
 	LO BND X4077 0
 	FR BND X4078
 	LO BND X4078 0
 	FR BND X4079
 	LO BND X4079 0
 	FR BND X4080
 	LO BND X4080 0
 	FR BND X4081
 	LO BND X4081 0
 	FR BND X4082
 	LO BND X4082 0
 	FR BND X4083
 	LO BND X4083 0
 	FR BND X4084
 	LO BND X4084 0
 	FR BND X4085
 	LO BND X4085 0
 	FR BND X4086
 	LO BND X4086 0
 	FR BND X4087
 	LO BND X4087 0
 	FR BND X4088
 	LO BND X4088 0
 	FR BND X4089
 	LO BND X4089 0
 	FR BND X4090
 	LO BND X4090 0
 	FR BND X4091
 	LO BND X4091 0
 	FR BND X4092
 	LO BND X4092 0
 	FR BND X4093
 	LO BND X4093 0
 	FR BND X4094
 	LO BND X4094 0
 	FR BND X4095
 	LO BND X4095 0
 	FR BND X4096
 	LO BND X4096 0
 	FR BND X4097
 	LO BND X4097 0
 	FR BND X4098
 	LO BND X4098 0
 	FR BND X4099
 	LO BND X4099 0
 	FR BND X4100
 	LO BND X4100 0
 	FR BND X4101
 	LO BND X4101 0
 	FR BND X4102
 	LO BND X4102 0
 	FR BND X4103
 	LO BND X4103 0
 	FR BND X4104
 	LO BND X4104 0
 	FR BND X4105
 	LO BND X4105 0
 	FR BND X4106
 	LO BND X4106 0
 	FR BND X4107
 	LO BND X4107 0
 	FR BND X4108
 	LO BND X4108 0
 	FR BND X4109
 	LO BND X4109 0
 	FR BND X4110
 	LO BND X4110 0
 	FR BND X4111
 	LO BND X4111 0
 	FR BND X4112
 	LO BND X4112 0
 	FR BND X4113
 	LO BND X4113 0
 	FR BND X4114
 	LO BND X4114 0
 	FR BND X4115
 	LO BND X4115 0
 	FR BND X4116
 	LO BND X4116 0
 	FR BND X4117
 	LO BND X4117 0
 	FR BND X4118
 	LO BND X4118 0
 	FR BND X4119
 	LO BND X4119 0
 	FR BND X4120
 	LO BND X4120 0
 	FR BND X4121
 	LO BND X4121 0
 	FR BND X4122
 	LO BND X4122 0
 	FR BND X4123
 	LO BND X4123 0
 	FR BND X4124
 	LO BND X4124 0
 	FR BND X4125
 	LO BND X4125 0
 	FR BND X4126
 	LO BND X4126 0
 	FR BND X4127
 	LO BND X4127 0
 	FR BND X4128
 	LO BND X4128 0
 	FR BND X4129
 	LO BND X4129 0
 	FR BND X4130
 	LO BND X4130 0
 	FR BND X4131
 	LO BND X4131 0
 	FR BND X4132
 	LO BND X4132 0
 	FR BND X4133
 	LO BND X4133 0
 	FR BND X4134
 	LO BND X4134 0
 	FR BND X4135
 	LO BND X4135 0
 	FR BND X4136
 	LO BND X4136 0
 	FR BND X4137
 	LO BND X4137 0
 	FR BND X4138
 	LO BND X4138 0
 	FR BND X4139
 	LO BND X4139 0
 	FR BND X4140
 	LO BND X4140 0
 	FR BND X4141
 	LO BND X4141 0
 	FR BND X4142
 	LO BND X4142 0
 	FR BND X4143
 	LO BND X4143 0
 	FR BND X4144
 	LO BND X4144 0
 	FR BND X4145
 	LO BND X4145 0
 	FR BND X4146
 	LO BND X4146 0
 	FR BND X4147
 	LO BND X4147 0
 	FR BND X4148
 	LO BND X4148 0
 	FR BND X4149
 	LO BND X4149 0
 	FR BND X4150
 	LO BND X4150 0
 	FR BND X4151
 	LO BND X4151 0
 	FR BND X4152
 	LO BND X4152 0
 	FR BND X4153
 	LO BND X4153 0
 	FR BND X4154
 	LO BND X4154 0
 	FR BND X4155
 	LO BND X4155 0
 	FR BND X4156
 	LO BND X4156 0
 	FR BND X4157
 	LO BND X4157 0
 	FR BND X4158
 	LO BND X4158 0
 	FR BND X4159
 	LO BND X4159 0
 	FR BND X4160
 	LO BND X4160 0
ENDATA
